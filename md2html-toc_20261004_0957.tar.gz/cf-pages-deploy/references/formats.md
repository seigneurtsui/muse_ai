# 格式与接口

## CLI

```text
cf_pages_deploy.py [--env-file FILE] [--verbose] [--log-file FILE] <command> ...
```

子命令：

| 命令 | 关键参数 | 说明 |
|---|---|---|
| `deploy` | `--config` / `--dir`+`--project-name` / `--discover-root`；`--branch`；`--only`；`--force`；`--retry-failed`；`--dry-run`；`--jobs`；`--retries`；`--timeout`；`--state`；`--report`；`--json` | 部署一个或多个项目 |
| `discover` | `--root`；`--branch`；`--name-prefix`；`--output` | 扫描父目录，输出/写出一份 `pages:` 配置 |
| `list` | `--json` | 列出账户下的 Pages 项目 |

顶层选项 `--env-file`、`--verbose`、`--log-file` 必须写在子命令之前。

## 配置（YAML）

```yaml
pages:
  <项目名>:
    source_dir: <目录 或 单个 .html 文件>   # 相对配置文件目录解析
    branch: main                              # 默认 main
    create_if_missing: true                   # 默认 true
    commit_message: <可选>
    skip_caching: <可选，默认 false>
```

- 项目名必须匹配 `^[a-z0-9](?:[a-z0-9-]{0,56}[a-z0-9])?$`，否则报 `invalid_project_name`。
- `source_dir` 不存在报 `source_not_found`；单文件必须是以 `.html`/`.htm` 结尾，否则报 `source_not_html_file`。

## 状态文件

默认与配置文件同目录，名为 `.cf_pages_deploy_state.json`（`--state` 可改）。

```jsonc
{
  "version": "1.0.0",
  "pages": {
    "<项目名>": {
      "status": "success | failed",
      "branch": "main",
      "content_sha256": "…",     // 目录树或文件的稳定哈希
      "url": "https://….pages.dev",
      "source": "/abs/path",
      "updated_at": "ISO-8601",
      "reason": "…"               // 仅失败时
    }
  }
}
```

`skipped` 结果不会写入状态（避免把已有成功记录降级）。

## 报告（`--json` / `--report`）

```jsonc
{
  "version": "1.0.0",
  "generated_at": "ISO-8601",
  "status": "complete | partial_failure | dry_run",
  "dry_run": false,
  "summary": { "total": 0, "success": 0, "planned": 0, "skipped": 0, "failed": 0 },
  "results": [
    {
      "name": "voyage",
      "source": "/abs/path",
      "status": "success | skipped | failed | planned",
      "url": "https://….pages.dev",
      "branch": "main",
      "mode": "dir | file",
      "files": 12, "bytes": 34567, "html_files": 3,
      "content_sha256": "…",
      "created_project": true,
      "warnings": ["no_html_files"],
      "reason": "unchanged | retry_failed_skip | wrangler_failed | …",
      "detail": "…",              // 失败时 wrangler 输出尾部（截断）
      "elapsed_seconds": 1.23
    }
  ],
  "elapsed_seconds": 4.56,
  "state_path": "…",
  "report_path": "…"
}
```

## 退出码

- `0`：批次全部成功（或 `--dry-run` 完成）。
- `2`：批次运行但至少一个项目失败。
- `1`：无法启动（配置/凭证/参数/依赖错误）。

## 依赖错误码

`requests_dependency_missing`、`yaml_dependency_missing`、`wrangler_not_found`、
`credentials_missing`、`config_not_found`、`config_has_no_pages`、`no_input_specified`。
