# 格式与接口

## CLI

```text
vercel_html_deploy.py [--env-file FILE] [--verbose] [--log-file FILE] <command> ...
```

子命令：

| 命令 | 关键参数 | 说明 |
|---|---|---|
| `deploy` | `--config` / `--dir`+`--project-name` / `--discover-root`；`--scope`；`--name-prefix`；`--prod`/`--preview`；`--only`；`--force`；`--retry-failed`；`--dry-run`；`--jobs`；`--retries`；`--timeout`；`--state`；`--report`；`--keep`；`--json` | 部署一个或多个项目 |
| `discover` | `--root`；`--scope`；`--name-prefix`；`--output` | 扫描父目录，输出/写出一份 `deployments:` 配置 |
| `list` | `--json` | 列出 scope 下的 Vercel 项目 |

顶层选项 `--env-file`、`--verbose`、`--log-file` 必须写在子命令之前。`prod` 默认取自每个部署项的配置（缺省 true）；命令行 `--prod` / `--preview` 会覆盖所有部署项的 `prod`，未指定时保留配置值。 `--dir` 单目标模式无配置项时 `prod` 默认 true。

## 配置（YAML）

```yaml
defaults:                          # 可选
  <任意 DeploymentSpec 字段>        # 合并进每个 deployment；部署项自身的键优先
deployments:                       # 也可写作 projects:
  <项目名>:
    source_dir: <目录 或单个 .html 文件>   # 相对配置文件目录解析
    mode: static | collection      # 默认 static
    scope: <Vercel team/scope>     # 覆盖环境变量
    prod: true | false             # 默认 true（--prod）
    create_if_missing: true | false # 默认 true
    archive: "tgz" | "none" | false # 上传压缩格式；默认 tgz
    # --- collection 专属（缺省值见括号）---
    prod_url: <站点生产域名>        # 供 TOC 页生成绝对链接/CSV
    title: <TOC 标题>              # "🗂️ 内容目录"
    subtitle: <TOC 副标题>         # "自动生成的索引页"
    item_label: <条目量词>          # "条目"
    slug_prefix: <slug 前缀>        # "item"
    slug_algo: md5 | sha1 | sha256 # md5
    slug_len: <哈希截断长度>        # 6（范围 4–40）
    min_bytes: <最小文件字节>       # 1000
    exclude_email: true | false    # 默认 true，跳过文件名含 "-email" 的文档
    root_mode: latest | none       # latest：把最新一篇发布为根 index.html
```

- 项目名必须匹配 `^[a-z0-9](?:[a-z0-9._-]{0,98}[a-z0-9])?$`，否则报 `invalid_project_name:<name>`。
- `source_dir` 不存在报 `source_not_found`；`static` 单文件必须是以 `.html`/`.htm` 结尾，否则报 `source_not_html_file`。
- `invalid_mode:<name>` 表示 `mode` 不是 static/collection；`invalid_slug_algo:<algo>` 表示 slug 算法非法。

## 状态文件

默认与配置文件同目录，名为 `.vercel_html_deploy_state.json`（`--state` 可改；无 `--config` 时为 cwd 下同名文件）。

```jsonc
{
  "version": "1.0.0",
  "deployments": {
    "<项目名>": {
      "status": "success | failed",
      "fingerprint": "…",          // 输入指纹（见 implementation.md）
      "url": "https://….vercel.app",
      "source": "/abs/path",
      "mode": "static | collection",
      "production": true,
      "updated_at": "ISO-8601",
      "reason": "…"                // 仅失败时
    }
  }
}
```

`skipped` 结果不会写入状态（避免把已有成功记录降级）。

## 报告（`--json` / `--report`）

```jsonc
{
  "version": "1.0.0",
  "generated_at": "ISO-8601",
  "status": "complete | partial_failure | dry_run",
  "dry_run": false,
  "summary": { "total": 0, "success": 0, "planned": 0, "skipped": 0, "failed": 0 },
  "results": [
    {
      "name": "zhongnanshan",
      "source": "/abs/path",
      "status": "success | skipped | failed | planned",
      "url": "https://….vercel.app",     // 成功时的部署 URL（可能为 null）
      "production": true,
      "mode": "static | collection",
      "fingerprint": "…",
      "created_project": true,
      "items": 12,                        // collection 模式的条目数
      "files": 34,                        // static 目录模式的文件数
      "reason": "unchanged | retry_failed_skip | deploy_failed | project_missing | …",
      "detail": "…",                      // 失败时 CLI 输出尾部（截断）
      "elapsed_seconds": 1.23
    }
  ],
  "elapsed_seconds": 4.56,
  "state_path": "…",                     // 仅真实部署（非 dry-run）
  "report_path": "…"                     // 仅 --report
}
```

## 退出码

- `0`：批次全部成功（或 `--dry-run` 完成）。
- `2`：批次运行但至少一个项目失败。
- `1`：无法启动（配置/凭证/参数/依赖错误）。

## 错误码

`config_not_found`、`config_parse_failed`、`config_not_a_mapping`、`config_defaults_not_a_mapping`、
`config_has_no_deployments`、`invalid_deployment_config:<name>`、`invalid_project_name:<name>`、
`invalid_mode:<name>`、`invalid_slug_algo:<algo>`、`source_not_found`、`source_not_html_file`、
`collection_source_not_directory`、`collection_found_no_items`、`discover_root_not_directory`、
`discover_found_no_sites`、`no_input_specified`、`only_matched_nothing`、`project_name_required`、
`credentials_missing`、`vercel_not_found`、`yaml_dependency_missing`、`invalid_jobs_value`、
`project_create_failed`、`project_missing`、`deploy_failed`、`project_list_failed`、
`project_list_invalid_json`。
