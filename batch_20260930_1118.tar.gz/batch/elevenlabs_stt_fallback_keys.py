#!/usr/bin/env python3
"""
ElevenLabs Speech-to-Text CLI v210 (Merged with Key Fallback)
==============================================================
增强版：支持实时费用监控、多模型对比、批量费用汇总、多 Key fallback

新增功能：
- ✅ ELEVENLABS_API_KEYS 多 Key 配置
- ✅ 自动 fallback 模式：配额耗尽、认证错误立即切换 Key
- ✅ 临时错误短暂重试后再切换
- ✅ 实时流式转录的实时费用监控（--realtime-with-cost）
- ✅ 多模型费用对比（--compare-models）
- ✅ 批量汇总所有文件的总费用（--batch-summary）

依赖：
pip install -U elevenlabs rich websockets pydub

环境变量：
export ELEVENLABS_API_KEYS='["sk_key_1", "sk_key_2"]'
# 或兼容旧配置:
export ELEVENLABS_API_KEY="your-api-key"

示例：
python elevenlabs_stt_v210_merged.py audio.mp3
python elevenlabs_stt_v210_merged.py --file audio.mp3 --realtime-with-cost
python elevenlabs_stt_v210_merged.py --file lecture.mp3 --compare-models scribe_v2,scribe_v2_realtime
python elevenlabs_stt_v210_merged.py --dir ~/Downloads/recordings --batch-summary
"""

import argparse
import asyncio
import inspect
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Callable

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn
    HAS_RICH = True
except ImportError:
    HAS_RICH = False

try:
    from elevenlabs import ElevenLabs
    HAS_ELEVENLABS = True
except ImportError:
    HAS_ELEVENLABS = False

try:
    import websockets  # noqa: F401
    HAS_WEBSOCKETS = True
except ImportError:
    HAS_WEBSOCKETS = False

try:
    from pydub import AudioSegment
    HAS_PYDUB = True
except ImportError:
    HAS_PYDUB = False

# ============================================================
# 常量
# ============================================================

# ~ ELEVENLABS_API_KEY = ""


ELEVENLABS_API_KEY='sk_bf2dddeecf2c2d502ae54e60e3f43ed347b20a1859641d80'



ELEVENLABS_API_KEYS='["sk_bf2dddeecf2c2d502ae54e60e3f43ed347b20a1859641d80", "sk_17885b6cd70f96f2b9ea3791f297940a40aff42996e81a42", "sk_02194383af646ee13e09d7e288f288cb08418801cd13f2a1", "sk_4b7135f39ab6302c5d3e9625a9587f40ae898d39bc51d6b4", "sk_3b0711c2d90ae1948d498888acbac88b55ac2d21bbecffe49", "sk_19e4f3074bdc4b9c10d53016bdaf90266249ff34c3709b3b", "sk_33857340a423af2330a13032b16246e7c12f22c65234b5e8", "sk_752c7664cdf506835ee273b2d09b854940df9875fdc66e3a", "sk_852d15ccd92cf35eb3f44df62674967315a34f7ff8fe77a3", "sk_06a776ef58f7eecece709e65073ce34b39d6f0e05104a737", "sk_e700b31c32a84d98084fcad162331e1de5542d98a3652872"]'





MAX_FILE_SIZE_DIRECT = 1 * 1024 * 1024 * 1024
MAX_FILE_SIZE_CLOUD = 2 * 1024 * 1024 * 1024
DEFAULT_CHUNK_DURATION_MS = 10 * 60 * 1000
DEFAULT_OUTPUT_DIR = Path.home() / "Downloads" / "speech2txt_11labs"

SUPPORTED_AUDIO = [".mp3", ".wav", ".m4a", ".flac", ".ogg", ".webm", ".aac", ".aiff", ".opus"]
SUPPORTED_VIDEO = [".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm", ".mpeg", ".3gpp"]
SUPPORTED_FORMATS = SUPPORTED_AUDIO + SUPPORTED_VIDEO
OUTPUT_FORMATS = ["txt", "srt", "vtt", "json", "segmented_json"]
ENTITY_TYPES = ["pii", "phi", "pci", "offensive_language"]

STT_PRICING = {
    "scribe_v2": {
        "base_per_hour": 0.22,
        "entity_detection_per_hour": 0.070,
        "keyterms_per_hour": 0.050,
    },
    "scribe_v2_realtime": {
        "base_per_hour": 0.39,
        "entity_detection_per_hour": 0.0,
        "keyterms_per_hour": 0.0,
    },
}

DEFAULT_STT_BASE_RATE_PER_HOUR = 0.22
console = Console() if HAS_RICH else None

# ============================================================
# 基础工具
# ============================================================

def log(message: str, level: str = "info") -> None:
    icons = {"error": "✗", "success": "✓", "warning": "⚠", "info": "ℹ"}
    if HAS_RICH:
        styles = {"error": "red bold", "success": "green bold", "warning": "yellow bold", "info": "cyan"}
        console.print(f"[{styles.get(level, 'cyan')}]{icons.get(level, 'ℹ')}[/] {message}")
    else:
        print(f"{icons.get(level, 'ℹ')} {message}")

def safe_float(value: Any, default: float = 0.0) -> float:
    if value is None:
        return default
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return float(value)
    except (TypeError, ValueError):
        return default

def ensure_output_dir(output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir

def get_file_ext(filename: str) -> str:
    return Path(filename).suffix.lower()

def is_supported_format(filename: str) -> bool:
    return get_file_ext(filename) in SUPPORTED_FORMATS

def _result_to_dict(result: Any) -> Dict[str, Any]:
    if result is None:
        return {}
    if hasattr(result, "model_dump"):
        return result.model_dump()
    if isinstance(result, dict):
        return result
    return {"text": getattr(result, "text", "")}

def get_supported_callable_kwargs(method: Any, kwargs: Dict[str, Any]) -> Dict[str, Any]:
    try:
        signature = inspect.signature(method)
        parameters = signature.parameters
        if any(param.kind == inspect.Parameter.VAR_KEYWORD for param in parameters.values()):
            return kwargs
        accepted = set(parameters)
        unsupported = sorted(key for key in kwargs if key not in accepted)
        if unsupported:
            log(f"当前 elevenlabs SDK 不支持参数，已忽略：{', '.join(unsupported)}", "warning")
        return {key: value for key, value in kwargs.items() if key in accepted}
    except (TypeError, ValueError):
        return kwargs

# ============================================================
# 多 Key 配置与错误分类
# ============================================================

def get_elevenlabs_api_keys(explicit_key: Optional[str] = None) -> List[str]:
    raw = explicit_key or os.environ.get("ELEVENLABS_API_KEYS", ELEVENLABS_API_KEYS) or os.environ.get("ELEVENLABS_API_KEY", ELEVENLABS_API_KEY)
    if not raw:
        raise RuntimeError("请设置 ELEVENLABS_API_KEYS 或兼容变量 ELEVENLABS_API_KEY")
    raw = raw.strip()
    values: List[str] = []
    if raw.startswith("["):
        try:
            parsed = json.loads(raw)
            if not isinstance(parsed, list):
                raise ValueError("ELEVENLABS_API_KEYS JSON 必须是数组")
            values = [str(item).strip() for item in parsed if str(item).strip()]
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"ELEVENLABS_API_KEYS JSON 格式错误：{exc}") from exc
    else:
        values = [item.strip() for item in raw.replace("\n", ",").split(",") if item.strip()]
    deduped: List[str] = []
    for key in values:
        if key not in deduped:
            deduped.append(key)
    if not deduped:
        raise RuntimeError("ELEVENLABS_API_KEYS 为空")
    return deduped

def _error_text(error: Any) -> str:
    parts = [str(error), str(getattr(error, "body", "") or "")]
    response = getattr(error, "response", None)
    if response is not None:
        try:
            parts.append(response.text)
        except Exception:
            pass
    return " ".join(parts).lower()

def _error_status(error: Any) -> Optional[int]:
    for obj in (error, getattr(error, "response", None)):
        status = getattr(obj, "status_code", None) or getattr(obj, "status", None)
        if status is not None:
            try:
                return int(status)
            except (TypeError, ValueError):
                pass
    return None

def is_immediate_key_switch_error(error: Any) -> bool:
    status = _error_status(error)
    text = _error_text(error)
    immediate_statuses = {401, 402, 403, 429}
    keywords = (
        "quota_exceeded", "quota exceeded", "exceed the quota", "exceeded the quota",
        "insufficient quota", "usage quota", "quota limit", "rate_limit_exceeded",
        "concurrent_limit_exceeded", "subscription limit", "credits exhausted",
        "billing required", "invalid api key", "invalid_api_key",
        "authentication failed", "auth_error",
    )
    return status in immediate_statuses or any(keyword in text for keyword in keywords)

def is_transient_error(error: Any) -> bool:
    status = _error_status(error)
    text = _error_text(error)
    return status in {408, 425, 500, 502, 503, 504} or any(
        keyword in text for keyword in ("timeout", "temporarily unavailable", "connection reset", "network")
    )

def _retry_delay(attempt: int) -> float:
    return min(2.0, 0.25 * (2 ** attempt))

# ============================================================
# 多 Key SDK 客户端包装
# ============================================================

class FallbackElevenLabs:
    def __init__(self, api_keys: List[str]):
        if not HAS_ELEVENLABS:
            raise RuntimeError("请先安装 elevenlabs：pip install -U elevenlabs")
        self.api_keys = api_keys
        self.current_index = 0
        self._clients: Dict[str, Any] = {}
        self.speech_to_text = _FallbackSpeechToText(self)
        self.single_use_token = _FallbackTokenAPI(self)

    def _client(self, api_key: str) -> Any:
        if api_key not in self._clients:
            self._clients[api_key] = ElevenLabs(api_key=api_key)
        return self._clients[api_key]

    def _call(self, operation: Callable[[Any], Any], description: str = "ElevenLabs 请求") -> Any:
        errors: List[Dict[str, Any]] = []
        ordered = list(range(self.current_index, len(self.api_keys))) + list(range(0, self.current_index))
        for key_index in ordered:
            api_key = self.api_keys[key_index]
            max_attempts = 2
            for attempt in range(max_attempts):
                try:
                    log(f"{description}：尝试 API Key #{key_index + 1}/{len(self.api_keys)}")
                    value = operation(self._client(api_key))
                    self.current_index = key_index
                    log(f"{description}成功：使用 API Key #{key_index + 1}", "success")
                    return value
                except Exception as exc:
                    status = _error_status(exc)
                    errors.append({"key_index": key_index, "attempt": attempt + 1, "status": status, "error": str(exc)})
                    if is_immediate_key_switch_error(exc):
                        log(f"API Key #{key_index + 1} 配额/认证错误，立即切换下一个 Key", "warning")
                        break
                    if is_transient_error(exc) and attempt + 1 < max_attempts:
                        delay = _retry_delay(attempt)
                        log(f"临时错误，{delay:.2f}s 后重试当前 Key", "warning")
                        time.sleep(delay)
                    else:
                        log(f"API Key #{key_index + 1} 请求失败，切换下一个 Key：{exc}", "warning")
                        break
        raise RuntimeError(f"所有 ELEVENLABS_API_KEYS 都失败：{json.dumps(errors, ensure_ascii=False)}")


class _FallbackConvert:
    def __init__(self, owner: FallbackElevenLabs):
        self.owner = owner

    def __call__(self, *, file: Any = None, **kwargs: Any) -> Any:
        return self.owner._call(lambda client: client.speech_to_text.convert(file=file, **kwargs), "STT 转录")


class _FallbackRawConvert:
    def __init__(self, owner: FallbackElevenLabs):
        self.owner = owner

    def __call__(self, *, file: Any = None, **kwargs: Any) -> Any:
        return self.owner._call(lambda client: client.speech_to_text.with_raw_response.convert(file=file, **kwargs), "STT 原始响应")


class _FallbackSpeechToText:
    def __init__(self, owner: FallbackElevenLabs):
        self.convert = _FallbackConvert(owner)
        self.with_raw_response = type("RawResponse", (), {"convert": _FallbackRawConvert(owner)})()
        self.realtime = _FallbackRealtime(owner)


class _FallbackRealtime:
    def __init__(self, owner: FallbackElevenLabs):
        self.owner = owner

    def connect(self, **kwargs: Any) -> Any:
        return _FallbackRealtimeContext(self.owner, kwargs)


class _FallbackRealtimeContext:
    def __init__(self, owner: FallbackElevenLabs, kwargs: Dict[str, Any]):
        self.owner = owner
        self.kwargs = kwargs
        self.connection = None

    async def __aenter__(self) -> Any:
        errors: List[str] = []
        ordered = list(range(self.owner.current_index, len(self.owner.api_keys))) + list(range(0, self.owner.current_index))
        for key_index in ordered:
            api_key = self.owner.api_keys[key_index]
            try:
                log(f"实时 STT：尝试 API Key #{key_index + 1}/{len(self.owner.api_keys)}")
                client = self.owner._client(api_key)
                self.connection = await _maybe_await(client.speech_to_text.realtime.connect(**self.kwargs))
                self.owner.current_index = key_index
                log(f"实时 STT 连接成功：API Key #{key_index + 1}", "success")
                return self.connection
            except Exception as exc:
                errors.append(str(exc))
                if is_immediate_key_switch_error(exc):
                    log("实时 STT 配额/认证错误，立即切换下一个 Key", "warning")
                else:
                    log(f"实时 STT 连接失败，切换下一个 Key：{exc}", "warning")
        raise RuntimeError(f"所有 API Key 的实时连接都失败：{errors}")

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> Any:
        if self.connection is not None:
            return await _maybe_await(self.connection.__aexit__(exc_type, exc, tb))
        return False

    def __getattr__(self, name: str) -> Any:
        if self.connection is None:
            raise RuntimeError("实时连接尚未建立")
        return getattr(self.connection, name)


class _FallbackTokenAPI:
    def __init__(self, owner: FallbackElevenLabs):
        self.owner = owner

    def create(self, **kwargs: Any) -> Any:
        return self.owner._call(lambda client: client.single_use_token.create(**kwargs), "创建单次令牌")


async def _maybe_await(value: Any) -> Any:
    if hasattr(value, "__await__"):
        return await value
    return value


def init_client_with_fallback(api_key: Optional[str] = None) -> FallbackElevenLabs:
    return FallbackElevenLabs(get_elevenlabs_api_keys(api_key))

# ============================================================
# 费用报告
# ============================================================

def get_stt_pricing(model: str) -> Dict[str, float]:
    if model in STT_PRICING:
        return dict(STT_PRICING[model])
    return {
        "base_per_hour": DEFAULT_STT_BASE_RATE_PER_HOUR,
        "entity_detection_per_hour": 0.0,
        "keyterms_per_hour": 0.0,
    }

def calculate_stt_cost(
    result: Dict[str, Any], model: str,
    entity_detection: Optional[List[str]] = None, keyterms: Optional[List[str]] = None,
    duration_secs: Optional[float] = None, request_count: int = 1,
    request_ids: Optional[List[str]] = None,
) -> Dict[str, Any]:
    result_dict = _result_to_dict(result)
    raw_duration = duration_secs if duration_secs is not None else result_dict.get("audio_duration_secs")
    actual_duration_secs = max(0.0, safe_float(raw_duration, 0.0))
    pricing = get_stt_pricing(model)
    billable_hours = actual_duration_secs / 3600.0
    base_rate = pricing["base_per_hour"]
    entity_rate = pricing["entity_detection_per_hour"] if entity_detection else 0.0
    keyterms_rate = pricing["keyterms_per_hour"] if keyterms else 0.0
    base_cost = billable_hours * base_rate
    entity_cost = billable_hours * entity_rate
    keyterms_cost = billable_hours * keyterms_rate
    return {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "currency": "USD",
        "model": model,
        "request_count": max(1, int(safe_float(request_count, 1.0))),
        "request_ids": [x for x in (request_ids or []) if x and x != "N/A"],
        "actual_audio_duration_secs": round(actual_duration_secs, 3),
        "billable_audio_hours": round(billable_hours, 9),
        "options": {"entity_detection": entity_detection or [], "keyterms_enabled": bool(keyterms)},
        "rates_usd_per_audio_hour": {
            "base": base_rate, "entity_detection": entity_rate, "keyterms": keyterms_rate,
            "effective_total": base_rate + entity_rate + keyterms_rate,
        },
        "cost_usd": {
            "base": round(base_cost, 8), "entity_detection": round(entity_cost, 8),
            "keyterms": round(keyterms_cost, 8), "total": round(base_cost + entity_cost + keyterms_cost, 8),
        },
        "pricing_note": "按公开 API 费率和实际音频时长估算；不代表最终账单。",
    }

def save_cost_report(cost_report: Dict[str, Any], output_path: Path) -> Path:
    ensure_output_dir(output_path.parent)
    with open(output_path, "w", encoding="utf-8") as output_file:
        json.dump(cost_report, output_file, indent=2, ensure_ascii=False)
    log(f"费用报告已保存：{output_path}", "success")
    return output_path

def print_cost_report(cost_report: Dict[str, Any]) -> None:
    duration = safe_float(cost_report.get("actual_audio_duration_secs"))
    costs = cost_report.get("cost_usd") or {}
    rates = cost_report.get("rates_usd_per_audio_hour") or {}
    if HAS_RICH:
        table = Table(title="实际费用报告")
        table.add_column("指标", style="cyan")
        table.add_column("值", style="green")
        table.add_row("计费时长", f"{duration:.3f} 秒")
        table.add_row("基础费率", f"${safe_float(rates.get('base')):.3f} / 小时")
        table.add_row("实体检测附加", f"${safe_float(rates.get('entity_detection')):.3f} / 小时")
        table.add_row("关键词附加", f"${safe_float(rates.get('keyterms')):.3f} / 小时")
        table.add_row("本次估算费用", f"${safe_float(costs.get('total')):.8f}")
        table.add_row("API 请求数", str(cost_report.get("request_count", 1)))
        console.print(table)
    else:
        log(f"计费时长：{duration:.3f} 秒")
        log(f"本次估算费用：${safe_float(costs.get('total')):.8f}", "success")

def attach_cost_report(
    result: Dict[str, Any], output_path: Path, model: str,
    entity_detection: Optional[List[str]], keyterms: Optional[List[str]],
    request_ids: Optional[List[str]] = None, display: bool = True,
) -> Tuple[Dict[str, Any], Path]:
    request_count = max(1, int(safe_float(result.get("chunks_count"), 1.0)))
    duration_secs = max(0.0, safe_float(result.get("audio_duration_secs"), 0.0))
    report = calculate_stt_cost(result, model, entity_detection, keyterms, duration_secs, request_count, request_ids)
    cost_path = output_path.with_name(f"{output_path.stem}_cost.json")
    save_cost_report(report, cost_path)
    if display:
        print_cost_report(report)
    return report, cost_path

# ============================================================
# 实时费用监控
# ============================================================

def print_realtime_cost_update(
    model: str, elapsed_secs: float,
    entity_detection: Optional[List[str]] = None, keyterms: Optional[List[str]] = None,
) -> Dict[str, Any]:
    pricing = get_stt_pricing(model)
    billable_hours = elapsed_secs / 3600.0
    base_rate = pricing["base_per_hour"]
    entity_rate = pricing["entity_detection_per_hour"] if entity_detection else 0.0
    keyterms_rate = pricing["keyterms_per_hour"] if keyterms else 0.0
    base_cost = billable_hours * base_rate
    entity_cost = billable_hours * entity_rate
    keyterms_cost = billable_hours * keyterms_rate
    total_cost = base_cost + entity_cost + keyterms_cost
    cost_update = {
        "model": model, "elapsed_secs": round(elapsed_secs, 2), "billable_hours": round(billable_hours, 9),
        "rates_usd_per_audio_hour": {
            "base": base_rate, "entity_detection": entity_rate, "keyterms": keyterms_rate,
            "effective_total": base_rate + entity_rate + keyterms_rate,
        },
        "cost_usd": {
            "base": round(base_cost, 8), "entity_detection": round(entity_cost, 8),
            "keyterms": round(keyterms_cost, 8), "total": round(total_cost, 8),
        },
        "timestamp": datetime.now().isoformat(timespec="seconds"),
    }
    if HAS_RICH:
        console.print(f"[cyan]⏱ 实时费用更新[/] {elapsed_secs:.1f}s | [green]${total_cost:.6f}[/] (@ ${base_rate + entity_rate + keyterms_rate:.2f}/hr)")
    else:
        log(f"⏱ 实时费用：{elapsed_secs:.1f}s | ${total_cost:.6f}")
    return cost_update

def save_realtime_cost_log(cost_updates: List[Dict[str, Any]], final_cost_report: Dict[str, Any], output_path: Path) -> Path:
    ensure_output_dir(output_path.parent)
    log_data = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "realtime_updates": cost_updates, "final_report": final_cost_report,
        "total_updates": len(cost_updates),
    }
    with open(output_path, "w", encoding="utf-8") as output_file:
        json.dump(log_data, output_file, indent=2, ensure_ascii=False)
    log(f"实时费用日志已保存：{output_path}", "success")
    return output_path

# ============================================================
# 多模型费用对比
# ============================================================

def compare_models_cost(
    client: FallbackElevenLabs, file_path: Path, models: List[str], output_dir: Path,
    entity_detection: Optional[List[str]] = None, keyterms: Optional[List[str]] = None,
    **kwargs: Any,
) -> Dict[str, Any]:
    ensure_output_dir(output_dir)
    comparison_results: List[Dict[str, Any]] = []
    all_cost_reports: List[Dict[str, Any]] = []
    log(f"开始多模型对比：{file_path.name}", "info")
    log(f"模型列表：{', '.join(models)}")
    for index, model in enumerate(models, 1):
        log(f"\n--- 模型 {index}/{len(models)}: {model} ---", "info")
        try:
            result = transcribe_file(
                client=client, file_path=file_path, model=model, auto_split=True,
                chunk_duration_ms=DEFAULT_CHUNK_DURATION_MS, max_file_size=MAX_FILE_SIZE_DIRECT, **kwargs,
            )
            output_path = output_dir / f"{file_path.stem}_{model}.{kwargs.get('output_format', 'txt')}"
            save_result(result, output_path, kwargs.get('output_format', 'txt'))
            cost_report, cost_path = attach_cost_report(
                result=result, output_path=output_path, model=model,
                entity_detection=entity_detection, keyterms=keyterms, display=False,
            )
            comparison_results.append({
                "model": model, "duration_secs": safe_float(result.get("audio_duration_secs")),
                "cost_usd": safe_float(cost_report.get("cost_usd", {}).get("total")),
                "output_file": str(output_path), "cost_file": str(cost_path),
            })
            all_cost_reports.append(cost_report)
            log(f"模型 {model} 完成：${safe_float(cost_report.get('cost_usd', {}).get('total')):.6f}", "success")
        except Exception as exc:
            log(f"模型 {model} 失败：{exc}", "error")
            comparison_results.append({"model": model, "error": str(exc), "cost_usd": None})
    valid_results = [r for r in comparison_results if r.get("cost_usd") is not None]
    if valid_results:
        cheapest = min(valid_results, key=lambda x: x["cost_usd"])
        most_expensive = max(valid_results, key=lambda x: x["cost_usd"])
        savings = most_expensive["cost_usd"] - cheapest["cost_usd"]
    else:
        cheapest = None
        most_expensive = None
        savings = 0.0
    comparison_report = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "file": str(file_path), "models_tested": len(models),
        "successful_models": len(valid_results), "failed_models": len(models) - len(valid_results),
        "results": comparison_results,
        "cheapest_model": cheapest["model"] if cheapest else None,
        "cheapest_cost_usd": cheapest["cost_usd"] if cheapest else None,
        "most_expensive_model": most_expensive["model"] if most_expensive else None,
        "most_expensive_cost_usd": most_expensive["cost_usd"] if most_expensive else None,
        "potential_savings_usd": round(savings, 8), "all_cost_reports": all_cost_reports,
    }
    comparison_path = output_dir / f"{file_path.stem}_model_comparison.json"
    with open(comparison_path, "w", encoding="utf-8") as output_file:
        json.dump(comparison_report, output_file, indent=2, ensure_ascii=False)
    log(f"\n模型对比报告已保存：{comparison_path}", "success")
    if HAS_RICH:
        table = Table(title="多模型费用对比")
        table.add_column("模型", style="cyan")
        table.add_column("时长 (秒)", justify="right")
        table.add_column("费用 (USD)", justify="right", style="green")
        table.add_column("状态", style="yellow")
        for r in comparison_results:
            status = "✓" if r.get("cost_usd") else "✗"
            table.add_row(
                r["model"],
                f"{r.get('duration_secs', 0):.1f}" if r.get("duration_secs") else "N/A",
                f"${r.get('cost_usd', 0):.6f}" if r.get("cost_usd") is not None else "N/A",
                status,
            )
        if cheapest and savings > 0:
            table.add_row("[bold]节省[/]", "", f"[green]${savings:.6f}[/]", f"选择 {cheapest['model']}")
        console.print(table)
    else:
        log("\n多模型费用对比摘要：")
        for r in comparison_results:
            status = "✓" if r.get("cost_usd") else "✗"
            cost_str = f"${r.get('cost_usd', 0):.6f}" if r.get("cost_usd") is not None else "N/A"
            log(f" {r['model']}: {cost_str} {status}")
        if cheapest and savings > 0:
            log(f" 最便宜：{cheapest['model']} (${cheapest['cost_usd']:.6f})")
            log(f" 可节省：${savings:.6f}")
    return comparison_report

# ============================================================
# 批量费用汇总
# ============================================================

def batch_transcribe_with_summary(
    client: FallbackElevenLabs, input_paths: List[Path], output_dir: Path,
    model: str = "scribe_v2", output_format: str = "txt", diarize: bool = False,
    keyterms: Optional[List[str]] = None, entity_detection: Optional[List[str]] = None,
    auto_split: bool = True, chunk_duration_ms: int = DEFAULT_CHUNK_DURATION_MS,
    max_file_size: int = MAX_FILE_SIZE_DIRECT, **kwargs: Any,
) -> Tuple[List[Path], Dict[str, Any]]:
    ensure_output_dir(output_dir)
    saved_files: List[Path] = []
    all_cost_reports: List[Dict[str, Any]] = []
    file_results: List[Dict[str, Any]] = []
    log(f"开始批量转录：{len(input_paths)} 个文件", "info")
    for index, file_path in enumerate(input_paths, 1):
        log(f"\n--- 批量转录 {index}/{len(input_paths)}: {file_path.name} ---", "info")
        try:
            result = transcribe_file(
                client=client, file_path=file_path, model=model, auto_split=auto_split,
                chunk_duration_ms=chunk_duration_ms, max_file_size=max_file_size,
                diarize=diarize, keyterms=keyterms, entity_detection=entity_detection, **kwargs,
            )
            output_path = output_dir / f"{file_path.stem}.{output_format}"
            save_result(result, output_path, output_format, include_speakers=diarize)
            cost_report, cost_path = attach_cost_report(
                result=result, output_path=output_path, model=model,
                entity_detection=entity_detection, keyterms=keyterms, display=False,
            )
            saved_files.append(output_path)
            all_cost_reports.append(cost_report)
            file_results.append({
                "file": str(file_path), "output_file": str(output_path), "cost_file": str(cost_path),
                "duration_secs": safe_float(result.get("audio_duration_secs")),
                "cost_usd": safe_float(cost_report.get("cost_usd", {}).get("total")), "status": "success",
            })
            log(f"完成：{file_path.name} | ${safe_float(cost_report.get('cost_usd', {}).get('total')):.6f}", "success")
        except Exception as exc:
            log(f"失败：{file_path.name} - {exc}", "error")
            file_results.append({"file": str(file_path), "error": str(exc), "status": "failed", "cost_usd": 0.0})
    successful_files = [r for r in file_results if r.get("status") == "success"]
    failed_files = [r for r in file_results if r.get("status") == "failed"]
    total_duration = sum(r.get("duration_secs", 0) for r in successful_files)
    total_cost = sum(r.get("cost_usd", 0) for r in successful_files)
    avg_cost = total_cost / len(successful_files) if successful_files else 0.0
    batch_summary = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "batch_id": datetime.now().strftime("%Y-%m-%d_%H-%M-%S"),
        "model": model, "output_format": output_format,
        "statistics": {
            "total_files": len(input_paths), "successful_files": len(successful_files),
            "failed_files": len(failed_files),
            "success_rate": round(len(successful_files) / len(input_paths) * 100, 2) if input_paths else 0.0,
            "total_audio_duration_secs": round(total_duration, 3),
            "total_audio_duration_hours": round(total_duration / 3600, 6),
            "total_cost_usd": round(total_cost, 8),
            "average_cost_per_file_usd": round(avg_cost, 8),
            "average_duration_per_file_secs": round(total_duration / len(successful_files), 3) if successful_files else 0.0,
        },
        "pricing": {
            "base_rate_per_hour": get_stt_pricing(model)["base_per_hour"],
            "entity_detection_rate": get_stt_pricing(model)["entity_detection_per_hour"] if entity_detection else 0.0,
            "keyterms_rate": get_stt_pricing(model)["keyterms_per_hour"] if keyterms else 0.0,
        },
        "files": file_results, "all_cost_reports": all_cost_reports,
    }
    summary_path = output_dir / "batch_summary.json"
    with open(summary_path, "w", encoding="utf-8") as output_file:
        json.dump(batch_summary, output_file, indent=2, ensure_ascii=False)
    log(f"\n批量汇总报告已保存：{summary_path}", "success")
    if HAS_RICH:
        table = Table(title="批量转录汇总")
        table.add_column("指标", style="cyan")
        table.add_column("值", style="green")
        table.add_row("总文件数", str(len(input_paths)))
        table.add_row("成功", str(len(successful_files)))
        table.add_row("失败", str(len(failed_files)))
        table.add_row("成功率", f"{batch_summary['statistics']['success_rate']}%")
        table.add_row("总时长", f"{total_duration / 3600:.2f} 小时 ({total_duration:.1f} 秒)")
        table.add_row("总费用", f"${total_cost:.6f}")
        table.add_row("平均每文件", f"${avg_cost:.6f}")
        console.print(table)
    else:
        log("\n批量转录汇总：")
        log(f"  总文件数：{len(input_paths)}")
        log(f"  成功：{len(successful_files)}, 失败：{len(failed_files)}")
        log(f"  总时长：{total_duration / 3600:.2f} 小时")
        log(f"  总费用：${total_cost:.6f}")
        log(f"  平均每文件：${avg_cost:.6f}")
    return saved_files, batch_summary

# ============================================================
# 音频分段与合并
# ============================================================

def get_audio_duration_ms(file_path: Path) -> float:
    if not HAS_PYDUB:
        return 0.0
    try:
        return float(len(AudioSegment.from_file(str(file_path))))
    except Exception:
        return 0.0

def split_audio(file_path: Path, chunk_duration_ms: int = DEFAULT_CHUNK_DURATION_MS, output_dir: Optional[Path] = None) -> List[Path]:
    if not HAS_PYDUB:
        raise RuntimeError("自动分段需要 pydub 和 ffmpeg：pip install pydub")
    output_dir = output_dir or file_path.parent
    output_dir.mkdir(parents=True, exist_ok=True)
    audio = AudioSegment.from_file(str(file_path))
    total_duration_ms = len(audio)
    chunks: List[Path] = []
    start_ms = 0
    index = 0
    log(f"正在分割音频：{file_path.name}")
    log(f"  总时长：{total_duration_ms / 1000:.1f} 秒")
    while start_ms < total_duration_ms:
        end_ms = min(start_ms + chunk_duration_ms, total_duration_ms)
        chunk_path = output_dir / f"{file_path.stem}_chunk{index:03d}{file_path.suffix}"
        audio[start_ms:end_ms].export(str(chunk_path), format=file_path.suffix.lstrip("."))
        chunks.append(chunk_path)
        log(f"  片段 {index + 1}: {start_ms / 1000:.1f}s - {end_ms / 1000:.1f}s")
        start_ms = end_ms
        index += 1
    log(f"分割完成：{len(chunks)} 个片段", "success")
    return chunks

def concatenate_transcriptions(results: List[Dict[str, Any]], chunk_durations_ms: Optional[List[float]] = None) -> Dict[str, Any]:
    if not results:
        return {"text": "", "words": [], "audio_duration_secs": 0.0}
    full_text: List[str] = []
    all_words: List[Dict[str, Any]] = []
    time_offset_ms = 0.0
    for index, raw_result in enumerate(results):
        result = _result_to_dict(raw_result)
        full_text.append(result.get("text", ""))
        if chunk_durations_ms and index > 0:
            time_offset_ms += safe_float(chunk_durations_ms[index - 1])
        for word in result.get("words", []) or []:
            new_word = dict(word)
            if "start" in new_word:
                new_word["start"] = safe_float(new_word["start"]) + time_offset_ms / 1000.0
            if "end" in new_word:
                new_word["end"] = safe_float(new_word["end"]) + time_offset_ms / 1000.0
            all_words.append(new_word)
    if chunk_durations_ms:
        total_duration = sum(safe_float(value) for value in chunk_durations_ms) / 1000.0
    elif all_words:
        total_duration = max(safe_float(word.get("end")) for word in all_words)
    else:
        total_duration = 0.0
    first = _result_to_dict(results[0])
    return {
        "text": " ".join(part for part in full_text if part).strip(),
        "words": all_words, "language_code": first.get("language_code"),
        "language_probability": first.get("language_probability"),
        "audio_duration_secs": total_duration, "segments_count": len(results),
    }

# ============================================================
# ElevenLabs 转录请求
# ============================================================

def _build_transcription_kwargs(
    model: str, language_code: Optional[str] = None, timestamps_granularity: str = "word",
    diarize: bool = False, num_speakers: Optional[int] = None, detect_speaker_roles: bool = False,
    use_speaker_library: bool = False, keyterms: Optional[List[str]] = None,
    tag_audio_events: bool = True, entity_detection: Optional[List[str]] = None,
    no_verbatim: bool = False, use_multi_channel: bool = False,
    multichannel_output_style: str = "separate", temperature: Optional[float] = None,
    seed: Optional[int] = None, additional_formats: Optional[List[str]] = None,
) -> Dict[str, Any]:
    kwargs: Dict[str, Any] = {
        "model_id": model, "timestamps_granularity": timestamps_granularity,
        "tag_audio_events": tag_audio_events,
    }
    if language_code:
        kwargs["language_code"] = language_code
    if diarize:
        kwargs["diarize"] = True
    if num_speakers:
        kwargs["num_speakers"] = num_speakers
    if detect_speaker_roles:
        kwargs["detect_speaker_roles"] = True
    if use_speaker_library:
        kwargs["use_speaker_library"] = True
    if keyterms:
        kwargs["keyterms"] = keyterms
    if entity_detection:
        kwargs["entity_detection"] = entity_detection
    if no_verbatim:
        kwargs["no_verbatim"] = True
    if use_multi_channel:
        kwargs["use_multi_channel"] = True
        kwargs["multichannel_output_style"] = multichannel_output_style
    if temperature is not None:
        kwargs["temperature"] = temperature
    if seed is not None:
        kwargs["seed"] = seed
    if additional_formats:
        kwargs["additional_formats"] = additional_formats
    return kwargs

def _transcribe_single_file(client: FallbackElevenLabs, file_path: Path, model: str = "scribe_v2", **kwargs: Any) -> Dict[str, Any]:
    request_kwargs = _build_transcription_kwargs(model=model, **kwargs)
    request_kwargs = get_supported_callable_kwargs(client.speech_to_text.convert, request_kwargs)
    with open(file_path, "rb") as audio_file:
        result = client.speech_to_text.convert(file=audio_file, **request_kwargs)
    return _result_to_dict(result)

def transcribe_with_raw_response(client: FallbackElevenLabs, file_path: Path, model: str = "scribe_v2", **kwargs: Any) -> Tuple[Dict[str, Any], Dict[str, str]]:
    request_kwargs = _build_transcription_kwargs(model=model, **kwargs)
    method = client.speech_to_text.with_raw_response.convert
    request_kwargs = get_supported_callable_kwargs(method, request_kwargs)
    with open(file_path, "rb") as audio_file:
        response = method(file=audio_file, **request_kwargs)
    headers = getattr(response, "headers", {}) or {}
    return _result_to_dict(response.data), {
        "request_id": headers.get("request-id", headers.get("x-request-id", "N/A")),
        "content_length": headers.get("content-length", "N/A"),
    }

def transcribe_file(client: FallbackElevenLabs, file_path: Path, model: str = "scribe_v2", auto_split: bool = True, chunk_duration_ms: int = DEFAULT_CHUNK_DURATION_MS, max_file_size: int = MAX_FILE_SIZE_DIRECT, **kwargs: Any) -> Dict[str, Any]:
    if not file_path.exists():
        raise FileNotFoundError(f"文件不存在：{file_path}")
    if not is_supported_format(file_path.name):
        raise ValueError(f"不支持的文件格式：{get_file_ext(file_path)}")
    file_size = file_path.stat().st_size
    needs_split = auto_split and file_size > max_file_size
    log(f"正在转录：{file_path.name}")
    log(f"  文件大小：{file_size / 1024 / 1024:.1f} MB")
    log(f"  模型：{model}")
    log(f"  说话人识别：{'开启' if kwargs.get('diarize') else '关闭'}")
    if kwargs.get("keyterms"):
        log(f"  关键词：{', '.join(kwargs['keyterms'])}")
    if not needs_split:
        return _transcribe_single_file(client, file_path, model=model, **kwargs)
    log(f"文件超过 {max_file_size / 1024 / 1024:.0f} MB，开始自动分段", "warning")
    chunk_dir = file_path.parent / f"{file_path.stem}_chunks"
    chunk_paths = split_audio(file_path, chunk_duration_ms, chunk_dir)
    results: List[Dict[str, Any]] = []
    durations_ms: List[float] = []
    try:
        for index, chunk_path in enumerate(chunk_paths, 1):
            log(f"--- 转录片段 {index}/{len(chunk_paths)}: {chunk_path.name} ---")
            try:
                result = _transcribe_single_file(client, chunk_path, model=model, **kwargs)
                results.append(result)
                api_duration_ms = safe_float(result.get("audio_duration_secs")) * 1000.0
                durations_ms.append(api_duration_ms if api_duration_ms > 0 else get_audio_duration_ms(chunk_path))
                log(f"片段 {index} 转录完成", "success")
            except Exception as exc:
                results.append({"text": "", "words": []})
                durations_ms.append(get_audio_duration_ms(chunk_path))
                log(f"片段 {index} 转录失败：{exc}", "error")
        merged = concatenate_transcriptions(results, durations_ms)
        merged["chunks_count"] = len(chunk_paths)
        merged["chunks_success"] = sum(1 for item in results if item.get("text"))
        log(f"合并完成：{merged['chunks_success']}/{len(chunk_paths)} 个片段成功", "success")
        return merged
    finally:
        for chunk_path in chunk_paths:
            try:
                chunk_path.unlink(missing_ok=True)
            except OSError:
                pass
        try:
            chunk_dir.rmdir()
        except OSError:
            pass

def transcribe_url(client: FallbackElevenLabs, source_url: str, model: str = "scribe_v2", **kwargs: Any) -> Dict[str, Any]:
    log(f"正在转录 URL: {source_url}")
    request_kwargs = _build_transcription_kwargs(model=model, **kwargs)
    request_kwargs["source_url"] = source_url
    request_kwargs = get_supported_callable_kwargs(client.speech_to_text.convert, request_kwargs)
    result = client.speech_to_text.convert(**request_kwargs)
    return _result_to_dict(result)

def transcribe_cloud_storage(client: FallbackElevenLabs, cloud_url: str, model: str = "scribe_v2", **kwargs: Any) -> Dict[str, Any]:
    log(f"正在从云端存储转录：{cloud_url}")
    request_kwargs = _build_transcription_kwargs(model=model, **kwargs)
    request_kwargs["cloud_storage_url"] = cloud_url
    request_kwargs = get_supported_callable_kwargs(client.speech_to_text.convert, request_kwargs)
    result = client.speech_to_text.convert(**request_kwargs)
    return _result_to_dict(result)

def transcribe_with_webhook(client: FallbackElevenLabs, file_path: Path, webhook_url: str, webhook_id: Optional[str] = None, webhook_metadata: Optional[Dict[str, Any]] = None, model: str = "scribe_v2", **kwargs: Any) -> Dict[str, Any]:
    if not file_path.exists():
        raise FileNotFoundError(f"文件不存在：{file_path}")
    log(f"正在提交 Webhook 转录：{file_path.name}")
    request_kwargs = _build_transcription_kwargs(model=model, **kwargs)
    request_kwargs["webhook"] = True
    request_kwargs["webhook_url"] = webhook_url
    if webhook_id:
        request_kwargs["webhook_id"] = webhook_id
    if webhook_metadata:
        request_kwargs["webhook_metadata"] = json.dumps(webhook_metadata, ensure_ascii=False)
    request_kwargs = get_supported_callable_kwargs(client.speech_to_text.convert, request_kwargs)
    with open(file_path, "rb") as audio_file:
        result = client.speech_to_text.convert(file=audio_file, **request_kwargs)
    log(f"Webhook 转录已提交，结果将发送到：{webhook_url}", "success")
    return _result_to_dict(result)

# ============================================================
# 输出
# ============================================================

def format_time_srt(seconds: float) -> str:
    seconds = safe_float(seconds)
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int((seconds % 1) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"

def format_time_vtt(seconds: float) -> str:
    seconds = safe_float(seconds)
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int((seconds % 1) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}.{millis:03d}"

def _subtitle_groups(result: Dict[str, Any], include_speakers: bool = False) -> List[Tuple[float, float, str]]:
    words = [word for word in (result.get("words") or []) if word.get("type") == "word"]
    if not words:
        return []
    groups: List[Tuple[float, float, str]] = []
    current: List[Dict[str, Any]] = []
    current_speaker: Optional[str] = None
    group_start = 0.0
    for word in words:
        speaker = word.get("speaker_id")
        start = safe_float(word.get("start"))
        if not current:
            current = [word]
            current_speaker = speaker
            group_start = start
            continue
        previous_end = safe_float(current[-1].get("end"))
        if speaker != current_speaker or start - previous_end > 0.5:
            text = " ".join(item.get("text", "") for item in current).strip()
            if include_speakers and current_speaker:
                text = f"[{current_speaker}] {text}"
            groups.append((group_start, previous_end, text))
            current = [word]
            current_speaker = speaker
            group_start = start
        else:
            current.append(word)
    if current:
        end = safe_float(current[-1].get("end"))
        text = " ".join(item.get("text", "") for item in current).strip()
        if include_speakers and current_speaker:
            text = f"[{current_speaker}] {text}"
        groups.append((group_start, end, text))
    return groups

def generate_srt(result: Dict[str, Any], include_speakers: bool = False) -> str:
    groups = _subtitle_groups(result, include_speakers)
    if not groups:
        return result.get("text", "")
    lines: List[str] = []
    for index, (start, end, text) in enumerate(groups, 1):
        lines.extend([str(index), f"{format_time_srt(start)} --> {format_time_srt(end)}", text, ""])
    return "\n".join(lines)

def generate_vtt(result: Dict[str, Any], include_speakers: bool = False) -> str:
    groups = _subtitle_groups(result, include_speakers)
    if not groups:
        return f"WEBVTT\n\n{result.get('text', '')}"
    lines = ["WEBVTT", ""]
    for start, end, text in groups:
        lines.extend([f"{format_time_vtt(start)} --> {format_time_vtt(end)}", text, ""])
    return "\n".join(lines)

def generate_segmented_json(result: Dict[str, Any]) -> Dict[str, Any]:
    words = [word for word in (result.get("words") or []) if word.get("type") == "word"]
    segments: List[Dict[str, Any]] = []
    current: Optional[Dict[str, Any]] = None
    for word in words:
        speaker = word.get("speaker_id")
        if current is None or speaker != current["speaker"]:
            if current:
                segments.append(current)
            current = {"speaker": speaker, "words": [word], "start": word.get("start", 0.0), "end": word.get("end", 0.0)}
        else:
            current["words"].append(word)
            current["end"] = word.get("end", current["end"])
    if current:
        segments.append(current)
    return {
        "text": result.get("text", ""), "language_code": result.get("language_code"),
        "language_probability": result.get("language_probability"),
        "audio_duration_secs": result.get("audio_duration_secs"), "segments": segments,
    }

def save_result(result: Dict[str, Any], output_path: Path, output_format: str = "txt", include_timestamps: bool = False, include_speakers: bool = False) -> Path:
    del include_timestamps
    ensure_output_dir(output_path.parent)
    if output_format == "txt":
        with open(output_path, "w", encoding="utf-8") as output_file:
            output_file.write(result.get("text", ""))
    elif output_format == "srt":
        with open(output_path, "w", encoding="utf-8") as output_file:
            output_file.write(generate_srt(result, include_speakers))
    elif output_format == "vtt":
        with open(output_path, "w", encoding="utf-8") as output_file:
            output_file.write(generate_vtt(result, include_speakers))
    elif output_format == "segmented_json":
        with open(output_path, "w", encoding="utf-8") as output_file:
            json.dump(generate_segmented_json(result), output_file, indent=2, ensure_ascii=False)
    else:
        with open(output_path, "w", encoding="utf-8") as output_file:
            json.dump(result, output_file, indent=2, ensure_ascii=False)
    log(f"已保存：{output_path}", "success")
    return output_path

def print_result_summary(result: Dict[str, Any]) -> None:
    language = result.get("language_code") or "N/A"
    probability = safe_float(result.get("language_probability"))
    duration = safe_float(result.get("audio_duration_secs"))
    text = result.get("text") or ""
    words = result.get("words") or []
    word_count = sum(1 for word in words if word.get("type") == "word")
    speakers = {word.get("speaker_id") for word in words if word.get("speaker_id")}
    if HAS_RICH:
        table = Table(title="转录结果摘要")
        table.add_column("指标", style="cyan")
        table.add_column("值", style="green")
        table.add_row("语言", f"{language} ({probability:.0%})")
        table.add_row("时长", f"{duration:.1f} 秒")
        table.add_row("文本长度", f"{len(text)} 字符")
        table.add_row("单词数", str(word_count))
        if speakers:
            table.add_row("说话人数", str(len(speakers)))
        console.print(table)
    else:
        log(f"语言：{language} ({probability:.0%})")
        log(f"时长：{duration:.1f} 秒")
        log(f"文本长度：{len(text)} 字符")
        log(f"单词数：{word_count}")

def print_transcript(result: Dict[str, Any], show_speakers: bool = False) -> None:
    text = result.get("text") or ""
    if HAS_RICH:
        if show_speakers:
            groups = _subtitle_groups(result, include_speakers=True)
            if groups:
                console.print("\n".join(group[2] for group in groups))
                return
        display_text = text[:2000] + "..." if len(text) > 2000 else text
        console.print(Panel(display_text, title="转录文本", border_style="cyan"))
    else:
        print(text[:2000] + "..." if len(text) > 2000 else text)

# ============================================================
# 批量与实时转录
# ============================================================

def scan_directory(dir_path: Path, extensions: List[str]) -> List[Path]:
    files: List[Path] = []
    for extension in extensions:
        files.extend(dir_path.rglob(f"*{extension}"))
    return sorted(set(files))

def batch_transcribe(client: FallbackElevenLabs, input_paths: List[Path], output_dir: Path, model: str = "scribe_v2", output_format: str = "txt", diarize: bool = False, keyterms: Optional[List[str]] = None, entity_detection: Optional[List[str]] = None, auto_split: bool = True, chunk_duration_ms: int = DEFAULT_CHUNK_DURATION_MS, max_file_size: int = MAX_FILE_SIZE_DIRECT, **kwargs: Any) -> List[Path]:
    ensure_output_dir(output_dir)
    saved_files: List[Path] = []
    for index, file_path in enumerate(input_paths, 1):
        log(f"--- 批量转录 {index}/{len(input_paths)}: {file_path.name} ---")
        try:
            result = transcribe_file(
                client=client, file_path=file_path, model=model, diarize=diarize,
                keyterms=keyterms, entity_detection=entity_detection, auto_split=auto_split,
                chunk_duration_ms=chunk_duration_ms, max_file_size=max_file_size, **kwargs,
            )
            output_path = output_dir / f"{file_path.stem}.{output_format}"
            save_result(result, output_path, output_format, include_speakers=diarize)
            attach_cost_report(result, output_path, model, entity_detection, keyterms)
            saved_files.append(output_path)
            log(f"完成：{file_path.name}", "success")
        except Exception as exc:
            log(f"失败：{file_path.name} - {exc}", "error")
    log(f"批量转录完成：{len(saved_files)}/{len(input_paths)} 个文件", "success")
    return saved_files

async def realtime_transcribe_stream(client: FallbackElevenLabs, source_url: str, model: str = "scribe_v2_realtime", include_timestamps: bool = True, keyterms: Optional[List[str]] = None, no_verbatim: bool = False, output_path: Optional[Path] = None) -> Dict[str, Any]:
    if not HAS_WEBSOCKETS:
        raise RuntimeError("实时转录需要 websockets：pip install websockets")
    connect_kwargs: Dict[str, Any] = {"model_id": model, "include_timestamps": include_timestamps}
    if keyterms:
        connect_kwargs["keyterms"] = keyterms
    if no_verbatim:
        connect_kwargs["no_verbatim"] = True
    partial: List[str] = []
    committed: List[str] = []
    events: List[Dict[str, Any]] = []
    async with client.speech_to_text.realtime.connect(**connect_kwargs) as connection:
        await connection.stream_url(source_url)
        async for event in connection:
            event_type = getattr(event, "type", "unknown")
            event_text = getattr(event, "text", "")
            events.append({"type": event_type, "text": event_text, "timestamp": datetime.now().isoformat()})
            if event_type == "partial_transcript":
                partial.append(event_text)
                log(f"[部分] {event_text}")
            elif event_type == "committed_transcript":
                committed.append(event_text)
                log(f"[最终] {event_text}", "success")
            elif event_type == "error":
                log(f"[错误] {event_text}", "error")
    result = {
        "text": " ".join(committed) if committed else " ".join(partial),
        "partial_transcripts": partial, "committed_transcripts": committed,
        "events": events, "model": model, "source_url": source_url,
    }
    if output_path:
        ensure_output_dir(output_path.parent)
        with open(output_path, "w", encoding="utf-8") as output_file:
            json.dump(result, output_file, indent=2, ensure_ascii=False)
        log(f"已保存：{output_path}", "success")
    return result

def realtime_transcribe_file(client: FallbackElevenLabs, file_path: Path, model: str = "scribe_v2_realtime", include_timestamps: bool = True, keyterms: Optional[List[str]] = None, no_verbatim: bool = False, output_path: Optional[Path] = None) -> Dict[str, Any]:
    if not file_path.exists():
        raise FileNotFoundError(f"文件不存在：{file_path}")
    if not HAS_WEBSOCKETS:
        raise RuntimeError("实时转录需要 websockets：pip install websockets")
    async def run() -> Dict[str, Any]:
        connect_kwargs: Dict[str, Any] = {"model_id": model, "include_timestamps": include_timestamps}
        if keyterms:
            connect_kwargs["keyterms"] = keyterms
        if no_verbatim:
            connect_kwargs["no_verbatim"] = True
        partial: List[str] = []
        committed: List[str] = []
        async with client.speech_to_text.realtime.connect(**connect_kwargs) as connection:
            await connection.stream_file(str(file_path))
            async for event in connection:
                event_type = getattr(event, "type", "unknown")
                event_text = getattr(event, "text", "")
                if event_type == "partial_transcript":
                    partial.append(event_text)
                    log(f"[部分] {event_text}")
                elif event_type == "committed_transcript":
                    committed.append(event_text)
                    log(f"[最终] {event_text}", "success")
        return {
            "text": " ".join(committed) if committed else " ".join(partial),
            "partial_transcripts": partial, "committed_transcripts": committed,
            "model": model, "file": str(file_path),
        }
    result = asyncio.run(run())
    if output_path:
        ensure_output_dir(output_path.parent)
        with open(output_path, "w", encoding="utf-8") as output_file:
            json.dump(result, output_file, indent=2, ensure_ascii=False)
        log(f"已保存：{output_path}", "success")
    return result

# ============================================================
# 带实时费用监控的转录
# ============================================================

async def realtime_transcribe_with_cost_monitoring(
    client: FallbackElevenLabs, file_path: Path, model: str = "scribe_v2_realtime",
    include_timestamps: bool = True, keyterms: Optional[List[str]] = None,
    no_verbatim: bool = False, output_path: Optional[Path] = None,
    entity_detection: Optional[List[str]] = None, cost_update_interval_secs: float = 10.0,
) -> Tuple[Dict[str, Any], Dict[str, Any], Path]:
    if not file_path.exists():
        raise FileNotFoundError(f"文件不存在：{file_path}")
    if not HAS_WEBSOCKETS:
        raise RuntimeError("实时转录需要 websockets：pip install websockets")
    local_duration_secs = get_audio_duration_ms(file_path) / 1000.0
    log(f"本地音频时长：{local_duration_secs:.1f} 秒", "info")
    async def run() -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
        connect_kwargs: Dict[str, Any] = {"model_id": model, "include_timestamps": include_timestamps}
        if keyterms:
            connect_kwargs["keyterms"] = keyterms
        if no_verbatim:
            connect_kwargs["no_verbatim"] = True
        partial: List[str] = []
        committed: List[str] = []
        cost_updates: List[Dict[str, Any]] = []
        start_time = time.time()
        last_cost_update = 0.0
        async with client.speech_to_text.realtime.connect(**connect_kwargs) as connection:
            await connection.stream_file(str(file_path))
            async for event in connection:
                elapsed = time.time() - start_time
                if elapsed - last_cost_update >= cost_update_interval_secs:
                    cost_update = print_realtime_cost_update(model=model, elapsed_secs=elapsed, entity_detection=entity_detection, keyterms=keyterms)
                    cost_updates.append(cost_update)
                    last_cost_update = elapsed
                event_type = getattr(event, "type", "unknown")
                event_text = getattr(event, "text", "")
                if event_type == "partial_transcript":
                    partial.append(event_text)
                    log(f"[部分] {event_text}")
                elif event_type == "committed_transcript":
                    committed.append(event_text)
                    log(f"[最终] {event_text}", "success")
                elif event_type == "error":
                    log(f"[错误] {event_text}", "error")
        final_elapsed = time.time() - start_time
        final_cost_update = print_realtime_cost_update(model=model, elapsed_secs=final_elapsed, entity_detection=entity_detection, keyterms=keyterms)
        cost_updates.append(final_cost_update)
        result = {
            "text": " ".join(committed) if committed else " ".join(partial),
            "partial_transcripts": partial, "committed_transcripts": committed,
            "model": model, "file": str(file_path),
            "local_duration_secs": local_duration_secs, "actual_duration_secs": final_elapsed,
        }
        return result, cost_updates
    result, cost_updates = await run()
    final_cost_report = calculate_stt_cost(
        result={"audio_duration_secs": local_duration_secs}, model=model,
        entity_detection=entity_detection, keyterms=keyterms,
        duration_secs=local_duration_secs, request_count=1, request_ids=[],
    )
    if output_path:
        ensure_output_dir(output_path.parent)
        cost_log_path = output_path.with_name(f"{output_path.stem}_realtime_cost.json")
        save_realtime_cost_log(cost_updates, final_cost_report, cost_log_path)
        with open(output_path, "w", encoding="utf-8") as output_file:
            json.dump(result, output_file, indent=2, ensure_ascii=False)
        log(f"已保存：{output_path}", "success")
        log("\n最终费用报告：", "success")
        print_cost_report(final_cost_report)
        return result, final_cost_report, cost_log_path
    return result, final_cost_report, Path("N/A")

# ============================================================
# CLI
# ============================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="ElevenLabs Speech-to-Text CLI v210（多 Key fallback + 实时费用监控 + 多模型对比 + 批量汇总）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    input_group = parser.add_argument_group("输入方式")
    input_group.add_argument("file_positional", nargs="?", help="音频/视频文件路径（可替代 --file）")
    input_group.add_argument("--file", "-f", help="音频/视频文件路径")
    input_group.add_argument("--url", "-u", help="在线音频/视频 URL")
    input_group.add_argument("--dir", "-d", help="批量处理目录")
    input_group.add_argument("--cloud-url", help="云端存储 URL")
    output_group = parser.add_argument_group("输出设置")
    output_group.add_argument("--output", "-o", help="输出文件路径")
    output_group.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR), help=f"输出目录（默认：{DEFAULT_OUTPUT_DIR}）")
    output_group.add_argument("--output-format", "-F", default="txt", choices=OUTPUT_FORMATS, help="输出格式（默认：txt）")
    model_group = parser.add_argument_group("模型设置")
    model_group.add_argument("--model", "-m", default="scribe_v2", help="模型 ID（默认：scribe_v2）")
    model_group.add_argument("--language", "-l", help="语言代码")
    model_group.add_argument("--temperature", type=float, help="输出随机性")
    model_group.add_argument("--seed", type=int, help="确定性输出种子")
    ts_group = parser.add_argument_group("时间戳")
    ts_group.add_argument("--timestamps", action="store_true", help="启用单词级时间戳")
    ts_group.add_argument("--timestamp-granularity", choices=["none", "word", "character"], default="word")
    speaker_group = parser.add_argument_group("说话人识别")
    speaker_group.add_argument("--diarize", action="store_true", help="启用说话人识别")
    speaker_group.add_argument("--num-speakers", type=int, help="最大说话人数")
    speaker_group.add_argument("--detect-roles", action="store_true", help="检测 agent/customer 角色")
    speaker_group.add_argument("--use-speaker-library", action="store_true", help="匹配已注册的说话人档案")
    split_group = parser.add_argument_group("大文件分割")
    split_group.add_argument("--no-split", action="store_true", help="禁用自动分割")
    split_group.add_argument("--chunk-duration", type=int, default=600, help="分段秒数（默认 600）")
    split_group.add_argument("--max-file-size", type=int, default=1024, help="触发分段的文件大小 MB（默认 1024）")
    trans_group = parser.add_argument_group("转录选项")
    trans_group.add_argument("--keyterms", nargs="+", help="关键词提示")
    trans_group.add_argument("--tag-audio-events", action="store_true", default=True, help="检测非语音声音（默认开启）")
    trans_group.add_argument("--no-tag-audio-events", action="store_true", help="禁用非语音声音检测")
    trans_group.add_argument("--entity-detection", nargs="+", choices=ENTITY_TYPES, help="实体检测类型")
    trans_group.add_argument("--no-verbatim", action="store_true", help="移除填充词和假启动")
    trans_group.add_argument("--multi-channel", action="store_true", help="多声道分离转录")
    trans_group.add_argument("--multichannel-style", choices=["separate", "combined"], default="separate")
    realtime_group = parser.add_argument_group("实时转录（增强版）")
    realtime_group.add_argument("--realtime-stream", action="store_true", help="使用实时流式转录（旧版，无费用监控）")
    realtime_group.add_argument("--realtime-with-cost", action="store_true", help="使用实时流式转录并监控费用（新版）")
    realtime_group.add_argument("--cost-update-interval", type=float, default=10.0, help="实时费用更新间隔秒数（默认 10 秒）")
    compare_group = parser.add_argument_group("多模型对比")
    compare_group.add_argument("--compare-models", help="逗号分隔的模型列表，例如：scribe_v2,scribe_v2_realtime")
    batch_group = parser.add_argument_group("批量汇总")
    batch_group.add_argument("--batch-summary", action="store_true", help="批量转录后生成总费用汇总报告")
    webhook_group = parser.add_argument_group("Webhook")
    webhook_group.add_argument("--webhook", help="Webhook URL（异步提交）")
    webhook_group.add_argument("--webhook-id", help="Webhook ID")
    webhook_group.add_argument("--webhook-metadata", help="Webhook 元数据 JSON")
    auth_group = parser.add_argument_group("认证与调试")
    auth_group.add_argument("--get-token", action="store_true", help="获取单次使用令牌")
    auth_group.add_argument("--track", action="store_true", help="在单文件请求中记录 request-id")
    auth_group.add_argument("--api-key", help="ElevenLabs API Key（或设置 ELEVENLABS_API_KEYS）")
    display_group = parser.add_argument_group("显示选项")
    display_group.add_argument("--show-speakers", action="store_true", help="显示说话人标签")
    display_group.add_argument("--no-summary", action="store_true", help="不显示摘要")
    display_group.add_argument("--no-text", action="store_true", help="不显示文本")
    display_group.add_argument("--json", action="store_true", help="输出 JSON")
    return parser


def build_common_kwargs(args: argparse.Namespace) -> Dict[str, Any]:
    return {
        "language_code": args.language,
        "timestamps_granularity": args.timestamp_granularity if args.timestamps else "none",
        "diarize": args.diarize, "num_speakers": args.num_speakers,
        "detect_speaker_roles": args.detect_roles, "use_speaker_library": args.use_speaker_library,
        "keyterms": args.keyterms, "tag_audio_events": not args.no_tag_audio_events,
        "entity_detection": args.entity_detection, "no_verbatim": args.no_verbatim,
        "use_multi_channel": args.multi_channel, "multichannel_output_style": args.multichannel_style,
        "temperature": args.temperature, "seed": args.seed,
    }

def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if not args.file:
        args.file = args.file_positional
    client = init_client_with_fallback(args.api_key)
    if args.get_token:
        token = client.single_use_token.create(token_type="batch_scribe")
        if args.json:
            print(json.dumps({"token": token}, ensure_ascii=False, indent=2))
        else:
            log(f"令牌：{token}", "success")
        return
    output_dir = Path(args.output_dir).expanduser()
    common_kwargs = build_common_kwargs(args)
    if args.compare_models:
        if not args.file:
            parser.error("--compare-models 需要 --file 参数")
        local_file = Path(args.file).expanduser()
        models = [m.strip() for m in args.compare_models.split(",")]
        comparison_report = compare_models_cost(
            client=client, file_path=local_file, models=models, output_dir=output_dir,
            entity_detection=args.entity_detection, keyterms=args.keyterms,
            **{key: value for key, value in common_kwargs.items() if key not in {"diarize", "keyterms", "entity_detection"}},
        )
        if args.json:
            print(json.dumps(comparison_report, ensure_ascii=False, indent=2))
        return
    if args.dir:
        directory = Path(args.dir).expanduser()
        if not directory.exists():
            parser.error(f"目录不存在：{directory}")
        files = scan_directory(directory, SUPPORTED_FORMATS)
        if not files:
            parser.error(f"未找到支持的音视频文件：{directory}")
        log(f"找到 {len(files)} 个音视频文件")
        if args.batch_summary:
            saved, batch_summary = batch_transcribe_with_summary(
                client=client, input_paths=files, output_dir=output_dir, model=args.model,
                output_format=args.output_format, diarize=args.diarize, keyterms=args.keyterms,
                entity_detection=args.entity_detection, auto_split=not args.no_split,
                chunk_duration_ms=args.chunk_duration * 1000, max_file_size=args.max_file_size * 1024 * 1024,
                **{key: value for key, value in common_kwargs.items() if key not in {"diarize", "keyterms", "entity_detection"}},
            )
            if args.json:
                print(json.dumps(batch_summary, ensure_ascii=False, indent=2))
        else:
            saved = batch_transcribe(
                client=client, input_paths=files, output_dir=output_dir, model=args.model,
                output_format=args.output_format, diarize=args.diarize, keyterms=args.keyterms,
                entity_detection=args.entity_detection, auto_split=not args.no_split,
                chunk_duration_ms=args.chunk_duration * 1000, max_file_size=args.max_file_size * 1024 * 1024,
                **{key: value for key, value in common_kwargs.items() if key not in {"diarize", "keyterms", "entity_detection"}},
            )
            if args.json:
                print(json.dumps({"files": [str(path) for path in saved], "count": len(saved)}, ensure_ascii=False, indent=2))
        return
    if not args.file and not args.url and not args.cloud_url:
        parser.print_help()
        return
    if args.realtime_with_cost:
        if args.url:
            parser.error("--realtime-with-cost 目前只支持本地文件")
        if args.file:
            local_file = Path(args.file).expanduser()
            output_path = output_dir / f"realtime_{local_file.stem}_with_cost.json"
            result, final_cost_report, cost_log_path = asyncio.run(
                realtime_transcribe_with_cost_monitoring(
                    client=client, file_path=local_file, model=args.model,
                    include_timestamps=args.timestamps, keyterms=args.keyterms,
                    no_verbatim=args.no_verbatim, output_path=output_path,
                    entity_detection=args.entity_detection, cost_update_interval_secs=args.cost_update_interval,
                )
            )
            if args.json:
                print(json.dumps({
                    "result": result, "final_cost_report": final_cost_report,
                    "cost_log_path": str(cost_log_path),
                }, ensure_ascii=False, indent=2))
            return
    if args.realtime_stream:
        if args.url:
            output_path = output_dir / f"realtime_{Path(args.url).stem or 'url'}.json"
            result = asyncio.run(realtime_transcribe_stream(client, args.url, args.model, args.timestamps, args.keyterms, args.no_verbatim, output_path))
        elif args.file:
            local_file = Path(args.file).expanduser()
            output_path = output_dir / f"realtime_{local_file.stem}.json"
            result = realtime_transcribe_file(client, local_file, args.model, args.timestamps, args.keyterms, args.no_verbatim, output_path)
        else:
            parser.error("实时转录需要 --file 或 --url")
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        elif result.get("text"):
            print(f"\n转录文本：\n{result['text']}")
            log("实时会话通常无法从 SDK 响应取得最终时长，未生成费用报告。", "warning")
        return
    try:
        if args.webhook:
            if not args.file:
                parser.error("Webhook 转录需要 --file")
            metadata = json.loads(args.webhook_metadata) if args.webhook_metadata else None
            transcribe_with_webhook(
                client=client, file_path=Path(args.file).expanduser(), webhook_url=args.webhook,
                webhook_id=args.webhook_id, webhook_metadata=metadata, model=args.model, **common_kwargs,
            )
            log("Webhook 已提交；最终费用应在回调收到实际时长后计算。", "warning")
            return
        request_ids: List[str] = []
        if args.cloud_url:
            result = transcribe_cloud_storage(client, args.cloud_url, args.model, **common_kwargs)
            source_name = Path(args.cloud_url).stem or "cloud_transcript"
        elif args.url:
            result = transcribe_url(client, args.url, args.model, **common_kwargs)
            source_name = Path(args.url).stem or "url_transcript"
        else:
            local_file = Path(args.file).expanduser()
            source_name = local_file.stem
            limit_bytes = args.max_file_size * 1024 * 1024
            if args.track and local_file.stat().st_size <= limit_bytes:
                result, headers = transcribe_with_raw_response(client, local_file, args.model, **common_kwargs)
                request_ids.append(headers.get("request_id", "N/A"))
                log(f"Request ID: {headers.get('request_id', 'N/A')}")
            else:
                result = transcribe_file(
                    client=client, file_path=local_file, model=args.model,
                    auto_split=not args.no_split, chunk_duration_ms=args.chunk_duration * 1000,
                    max_file_size=limit_bytes, **common_kwargs,
                )
        if not args.no_summary:
            print_result_summary(result)
        if not args.no_text:
            print_transcript(result, args.show_speakers)
        output_path = Path(args.output).expanduser() if args.output else output_dir / f"{source_name}.{args.output_format}"
        save_result(result, output_path, args.output_format, args.timestamps, args.diarize)
        cost_report, cost_path = attach_cost_report(
            result=result, output_path=output_path, model=args.model,
            entity_detection=args.entity_detection, keyterms=args.keyterms,
            request_ids=request_ids, display=not args.json,
        )
        if args.json:
            print(json.dumps({
                "text": result.get("text"), "language_code": result.get("language_code"),
                "language_probability": result.get("language_probability"),
                "audio_duration_secs": result.get("audio_duration_secs"),
                "output_path": str(output_path), "cost_report_path": str(cost_path),
                "estimated_cost_usd": (cost_report.get("cost_usd") or {}).get("total"),
            }, ensure_ascii=False, indent=2))
    except Exception as exc:
        log(f"转录失败：{exc}", "error")
        sys.exit(1)

if __name__ == "__main__":
    main()
