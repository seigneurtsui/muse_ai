"""Synthetic protocol fixtures, NOT genuine model inference."""

from __future__ import annotations
import codecs
import contextlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import ai_batch_translator as app
import current_session_ai as ai
import file_support as files


# Test-only responses. The actual invoking model is exercised separately.
def fixture_translate(text, target="English"):
    pairs = {
        "你好": "Hello" if target == "English" else "Bonjour",
        "世界": "world" if target == "English" else "monde",
        "欢迎": "Welcome" if target == "English" else "Bienvenue",
        "说明": "Description",
        "标题": "Title",
        "内容": "Content",
        "项目": "Project",
        "学习": "Study",
    }
    for wrong, right in pairs.items():
        text = text.replace(wrong, right)
    return text


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.input = self.root / "input"
        self.input.mkdir()
        self.output = self.root / "output"
        self.doc = self.input / "demo.txt"
        self.doc.write_text("你好，世界。\n")

    def args(self, *extra):
        return app.build_parser().parse_args(
            [
                "--file",
                str(self.doc),
                "--target-language",
                "English",
                "--output",
                str(self.output),
                *extra,
            ]
        )

    def directory_args(self, *extra):
        return app.build_parser().parse_args(
            [
                "--directory",
                str(self.input),
                "--target-language",
                "English",
                "--output",
                str(self.output),
                *extra,
            ]
        )

    def answer(self, result, transform=fixture_translate):
        for descriptor in result["pending_requests"]:
            packet = json.loads(Path(descriptor["request_path"]).read_text())
            answer = {
                "request_id": packet["request_id"],
                "translations": [
                    {
                        "id": row["id"],
                        "text": transform(
                            row["text"], packet["payload"]["target_language"]
                        ),
                    }
                    for row in packet["payload"]["items"]
                ],
            }
            Path(descriptor["response_path"]).write_text(
                json.dumps(answer, ensure_ascii=False)
            )

    def finish(self, args=None, transform=fixture_translate):
        result, code = app.start(args or self.args())
        for _ in range(200):
            if code != 10:
                return result, code
            self.answer(result, transform)
            result, code = app.resume(result["job_dir"])
        self.fail("fixture failed to finish")

    def data(self, path):
        return json.loads(Path(path).read_text())

    def cli(self, *args, stdin=None):
        return subprocess.run(
            [sys.executable, "-B", str(ROOT / "scripts/ai_batch_translator.py"), *args],
            input=stdin,
            capture_output=True,
            timeout=30,
        )

    def test_language_aliases_multiple_targets_and_collision_checks(self):
        self.assertEqual(app.canonical_language("EN-gb"), "British English")
        self.assertEqual(app.canonical_language("zh-Hant"), "Traditional Chinese")
        self.assertEqual(
            app.target_languages(["英语,en", "fr,法语"], "Chinese"),
            ["English", "French"],
        )
        for targets in ([""], ["Auto"], ["Chinese"], ["Test(A),Test A"]):
            with self.subTest(targets=targets), self.assertRaises(
                files.TranslationError
            ):
                app.target_languages(targets, "Chinese")

    def test_dry_run_creates_no_directory_request_or_model(self):
        with patch.object(
            ai.CurrentSessionAI, "request", side_effect=AssertionError("no model")
        ):
            result, code = app.start(self.args("--dry-run"))
        self.assertEqual(code, 0)
        self.assertEqual(result["status"], "dry_run")
        self.assertFalse(result["writes"])
        self.assertFalse(self.output.exists())

    def test_missing_response_is_pending_not_success(self):
        result, code = app.start(self.args())
        self.assertEqual(code, 10)
        self.assertEqual(result["completed"], 0)
        self.assertEqual(result["results"][0]["status"], "awaiting_ai")
        self.assertFalse(list((Path(result["job_dir"]) / "files").rglob("*.txt")))
        self.assertNotIn("你好", json.dumps(result, ensure_ascii=False))
        packet = self.data(result["pending_requests"][0]["request_path"])
        self.assertEqual(packet["payload"]["target_language"], "English")

    def test_complete_two_languages_source_and_line_endings_preserved(self):
        self.doc.write_bytes(
            codecs.BOM_UTF8 + "  你好，世界。\r\n\r\n欢迎！\n".encode()
        )
        original = self.doc.read_bytes()
        result, code = self.finish(self.args("--target-language", "French"))
        self.assertEqual(code, 0, result)
        self.assertEqual(result["completed"], 2)
        self.assertEqual(
            {r["target_language"] for r in result["results"]}, {"English", "French"}
        )
        for row in result["results"]:
            raw = Path(row["output"]).read_bytes()
            self.assertTrue(raw.startswith(codecs.BOM_UTF8 + b"  "))
            self.assertEqual(raw.count(b"\r\n"), 2)
            self.assertEqual(raw.count(b"\n"), 3)
            self.assertEqual(row["provider"], ai.PROVIDER)
            self.assertGreater(row["ai_changed_units"], 0)
        self.assertEqual(self.doc.read_bytes(), original)

    def test_recursive_same_basename_preserves_layout(self):
        for name in ("first", "second"):
            directory = self.input / name
            directory.mkdir()
            (directory / "demo.txt").write_text("欢迎。")
        result, code = self.finish(self.directory_args())
        self.assertEqual(code, 0)
        self.assertEqual(result["completed"], 3)
        outputs = {
            Path(r["output"]).relative_to(Path(result["job_dir"]) / "files").as_posix()
            for r in result["results"]
        }
        self.assertEqual(
            outputs,
            {
                "english/demo.english.txt",
                "english/first/demo.english.txt",
                "english/second/demo.english.txt",
            },
        )

    def test_hidden_links_output_subtree_and_nonrecursive_excluded(self):
        (self.input / ".hidden.txt").write_text("你好")
        (self.input / "link.txt").symlink_to(self.doc)
        nested = self.input / "nested"
        nested.mkdir()
        (nested / "inside.txt").write_text("你好")
        output = self.input / "generated"
        output.mkdir()
        (output / "old.txt").write_text("你好")
        args = self.directory_args(
            "--dry-run", "--output", str(output), "--no-recursive"
        )
        result, code = app.start(args)
        self.assertEqual(code, 0)
        self.assertEqual(result["total_tasks"], 1)
        self.assertEqual(
            {r["reason"] for r in result["excluded"]},
            {"link_not_followed", "output_excluded"},
        )

    def test_portable_name_collision_blocked_before_output(self):
        # Case-insensitive OS cannot hold two case-only names, so use a language
        # slug collision which is portable and checked before any output creation.
        with self.assertRaisesRegex(files.TranslationError, "slug_collision"):
            app.start(self.args("--target-language", "Test(A),Test A"))
        self.assertFalse(self.output.exists())

    def test_no_supported_files_and_filter_rejection(self):
        self.doc.unlink()
        (self.input / "binary.pdf").write_bytes(b"%PDF-fake")
        result, code = app.start(self.directory_args())
        self.assertEqual(code, 1)
        self.assertEqual(result["status"], "no_supported_files")
        with self.assertRaisesRegex(
            files.TranslationError, "unsupported_extension_filter"
        ):
            app.start(self.directory_args("--extensions", "pdf"))
        self.assertFalse(self.output.exists())

    def test_malformed_json_preflights_whole_batch_before_requests(self):
        (self.input / "broken.json").write_text("{bad")
        with self.assertRaises(Exception):
            app.start(self.directory_args())
        self.assertFalse(self.output.exists())

    def test_json_csv_subtitle_markdown_pipeline(self):
        self.doc.unlink()
        cases = {
            "data.json": '{ "name": "你好", "count": 12, "ok": true }\n',
            "data.csv": '标题,内容\r\n"你好，世界",12\r\n',
            "sub.srt": "1\r\n00:00:01,000 --> 00:00:03,000\r\n你好\r\n123\r\n\r\n",
            "page.md": "# 标题\n\n[你好](https://example.test/世界)\n\n```txt\n你好\n```\n",
        }
        for name, text in cases.items():
            (self.input / name).write_bytes(text.encode())
        result, code = self.finish(self.directory_args())
        self.assertEqual(code, 0, result)
        self.assertEqual(result["completed"], 4)
        produced = {
            Path(row["output"]).suffix: Path(row["output"]).read_bytes()
            for row in result["results"]
        }
        self.assertEqual(
            json.loads(produced[".json"]), {"name": "Hello", "count": 12, "ok": True}
        )
        self.assertIn(b"00:00:01,000 --> 00:00:03,000\r\n", produced[".srt"])
        self.assertIn(b"\r\n123\r\n", produced[".srt"])
        self.assertIn("https://example.test/世界".encode(), produced[".md"])
        self.assertIn("```txt\n你好\n```".encode(), produced[".md"])
        self.assertIn(b",12\r\n", produced[".csv"])

    def test_utf16_same_and_utf8_default_for_other_languages(self):
        self.doc.write_bytes(codecs.BOM_UTF16_LE + "你好。\r\n".encode("utf-16-le"))
        result, code = self.finish(self.args("--output-encoding", "same"))
        self.assertEqual(code, 0)
        raw = Path(result["results"][0]["output"]).read_bytes()
        self.assertTrue(raw.startswith(codecs.BOM_UTF16_LE))
        self.assertEqual(raw[2:].decode("utf-16-le"), "Hello。\r\n")
        result, code = self.finish()
        self.assertEqual(code, 0)
        self.assertEqual(Path(result["results"][0]["output"]).read_text(), "Hello。\n")

    def test_unrepresentable_output_is_failure_not_lossy_replacement(self):
        self.doc.write_bytes("你好".encode("gbk"))
        result, code = self.finish(
            self.args("--encoding", "gbk", "--output-encoding", "same"),
            lambda s, t: "مرحبا",
        )
        self.assertEqual(code, 1)
        self.assertEqual(
            result["results"][0]["reason"],
            "output_encoding_cannot_represent_translation",
        )
        self.assertFalse(list((Path(result["job_dir"]) / "files").rglob("*.txt")))

    def test_unchanged_response_is_explicit_review_not_translation_success(self):
        result, code = self.finish(transform=lambda s, t: s)
        self.assertEqual(code, 1)
        self.assertEqual(result["translated"], 0)
        self.assertEqual(result["needs_review"], 1)
        self.assertEqual(result["results"][0]["status"], "checked_unchanged")
        self.assertGreater(result["results"][0]["ai_checked_units"], 0)

    def test_empty_and_numbers_only_are_not_claimed_ai_translations(self):
        for content in ("", "123\r\n\r\n"):
            self.doc.write_bytes(content.encode())
            with patch.object(
                ai.CurrentSessionAI, "request", side_effect=AssertionError("no model")
            ):
                result, code = app.start(self.args())
            self.assertEqual(code, 0)
            self.assertEqual(result["no_translatable_text"], 1)
            self.assertEqual(result["translated"], 0)
            self.assertEqual(
                Path(result["results"][0]["output"]).read_bytes(), content.encode()
            )

    def test_completed_resume_is_idempotent_without_model_or_rewrite(self):
        result, code = self.finish()
        path = Path(result["results"][0]["output"])
        mtime = path.stat().st_mtime_ns
        with patch.object(
            ai.CurrentSessionAI, "request", side_effect=AssertionError("no new model")
        ):
            resumed, code = app.resume(result["job_dir"])
        self.assertEqual(code, 0)
        self.assertEqual(path.stat().st_mtime_ns, mtime)
        self.assertEqual(resumed["completed"], 1)

    def test_accepted_answers_survive_original_response_removal(self):
        result, code = self.finish()
        job = Path(result["job_dir"])
        for path in (job / ".work/ai").glob("*.response.json"):
            path.unlink()
        # Force reconstruction using validated accepted groups and existing intent.
        (job / ".work/completed/000000.json").unlink()
        with patch.object(
            ai.CurrentSessionAI, "request", side_effect=AssertionError("accepted reuse")
        ):
            result, code = app.resume(job)
        self.assertEqual(code, 0)
        self.assertEqual(result["completed"], 1)

    def test_input_snapshot_manifest_and_completed_output_tampering_blocked(self):
        for mode in ("input", "snapshot", "manifest", "output"):
            with self.subTest(mode=mode):
                self.doc.write_text("你好")
                result, code = self.finish()
                job = Path(result["job_dir"])
                if mode == "input":
                    path = self.doc
                elif mode == "snapshot":
                    path = job / ".work/docs/000000.json"
                elif mode == "manifest":
                    path = job / "manifest.json"
                else:
                    path = Path(result["results"][0]["output"])
                old = path.read_bytes()
                path.write_bytes(old + b" ")
                if mode in ("input", "snapshot"):
                    with self.assertRaises(files.TranslationError):
                        app.resume(job)
                elif mode == "manifest":
                    # Whitespace alone is not a semantic manifest mutation.
                    value = self.data(path)
                    value["options"]["source_language"] = "French"
                    path.write_text(json.dumps(value))
                    with self.assertRaisesRegex(
                        files.TranslationError, "manifest_changed"
                    ):
                        app.resume(job)
                else:
                    result, code = app.resume(job)
                    self.assertEqual(code, 1)
                    self.assertEqual(
                        result["results"][0]["reason"],
                        "completed_output_or_receipt_changed",
                    )
                    self.assertEqual(path.read_bytes(), old + b" ")

    def test_bad_response_ids_empty_and_structural_mutation_are_invalid(self):
        for modify in (
            lambda d: d.update(request_id="0" * 64),
            lambda d: d["translations"][0].update(id=True),
            lambda d: d["translations"][0].update(text=""),
            lambda d: d["translations"][0].update(text="Hello\nInjected"),
        ):
            result, code = app.start(self.args())
            self.answer(result)
            desc = result["pending_requests"][0]
            data = self.data(desc["response_path"])
            modify(data)
            Path(desc["response_path"]).write_text(json.dumps(data))
            result, code = app.resume(result["job_dir"])
            self.assertEqual(code, 1)
            self.assertEqual(result["results"][0]["status"], "invalid_ai_response")
            self.assertEqual(result["completed"], 0)

    def test_invalid_answer_can_be_fixed_explicitly(self):
        result, code = app.start(self.args())
        desc = result["pending_requests"][0]
        Path(desc["response_path"]).write_text("{}")
        result, code = app.resume(result["job_dir"])
        self.assertEqual(code, 1)
        self.answer(result)
        result, code = app.resume(result["job_dir"])
        self.assertEqual(code, 0)

    def test_response_symlink_or_fifo_rejected_without_reading(self):
        for mode in ("link", "fifo"):
            if mode == "fifo" and not hasattr(os, "mkfifo"):
                continue
            result, code = app.start(self.args())
            desc = result["pending_requests"][0]
            path = Path(desc["response_path"])
            if mode == "link":
                path.symlink_to(self.doc)
            else:
                os.mkfifo(path)
            result, code = app.resume(result["job_dir"])
            self.assertEqual(code, 1)
            self.assertEqual(result["results"][0]["status"], "invalid_ai_response")

    def test_job_lock_not_removed_by_competing_resume(self):
        result, code = app.start(self.args())
        lock = Path(result["job_dir"]) / ".lock"
        lock.mkdir()
        with self.assertRaisesRegex(files.TranslationError, "job_locked"):
            app.resume(result["job_dir"])
        self.assertTrue(lock.exists())

    def test_unowned_output_is_never_overwritten(self):
        result, code = app.start(self.args())
        job = Path(result["job_dir"])
        path = job / "files/english/demo.english.txt"
        path.parent.mkdir(parents=True)
        path.write_text("user work")
        self.answer(result)
        result, code = app.resume(job)
        self.assertEqual(code, 1)
        self.assertEqual(result["results"][0]["reason"], "unowned_output_exists")
        self.assertEqual(path.read_text(), "user work")

    def test_output_intent_recovers_after_receipt_failure(self):
        result, code = app.start(self.args())
        self.answer(result)
        original = app.write_json

        def fail(path, value, *a, **kw):
            if path.parent.name == "completed":
                raise OSError("synthetic receipt failure")
            return original(path, value, *a, **kw)

        with patch.object(app, "write_json", side_effect=fail):
            result, code = app.resume(result["job_dir"])
        self.assertEqual(code, 1)
        job = Path(result["job_dir"])
        path = job / "files/english/demo.english.txt"
        self.assertTrue(path.exists())
        mtime = path.stat().st_mtime_ns
        result, code = app.resume(job)
        self.assertEqual(code, 0)
        self.assertEqual(path.stat().st_mtime_ns, mtime)

    def test_reports_failure_retains_actual_completion_in_stdout(self):
        result, code = app.start(self.args())
        self.answer(result)
        with patch.object(
            app, "write_reports", side_effect=OSError("synthetic report failure")
        ):
            result, code = app.resume(result["job_dir"])
        self.assertEqual(code, 2)
        self.assertEqual(result["status"], "report_error")
        self.assertEqual(result["completed"], 1)
        self.assertTrue(Path(result["results"][0]["output"]).exists())

    def test_long_document_multiple_windows_and_out_of_order_answers(self):
        self.doc.write_text(("你好，世界。" * 40 + "\n") * 5)
        args = self.args(
            "--chunk-chars", "128", "--batch-chars", "256", "--request-window", "2"
        )
        result, code = app.start(args)
        self.assertEqual(code, 10)
        self.assertEqual(len(result["pending_requests"]), 2)
        selected = dict(result)
        selected["pending_requests"] = result["pending_requests"][1:]
        self.answer(selected)
        result, code = app.resume(result["job_dir"], 2)
        self.assertEqual(code, 10)
        count = 0
        while code == 10 and count < 100:
            self.assertLessEqual(len(result["pending_requests"]), 2)
            self.answer(result)
            result, code = app.resume(result["job_dir"], 2)
            count += 1
        self.assertEqual(code, 0, result)
        self.assertGreater(count, 1)
        raw = Path(result["results"][0]["output"]).read_bytes()
        self.assertEqual(raw.count(b"\n"), 5)
        self.assertEqual(raw.count(b"Hello"), 200)

    def test_real_cli_dry_run_help_inline_stdin_and_saved_option_rejection(self):
        process = self.cli("--language-help")
        self.assertEqual(process.returncode, 0)
        self.assertIn(b"English", process.stdout)
        process = self.cli(
            "--file",
            str(self.doc),
            "--target-language",
            "en",
            "--output",
            str(self.output),
            "--dry-run",
        )
        self.assertEqual(process.returncode, 0)
        self.assertEqual(json.loads(process.stdout)["status"], "dry_run")
        self.assertFalse(self.output.exists())
        process = self.cli(
            "--stdin",
            "--target-language",
            "en",
            "--output",
            str(self.output),
            stdin="你好\n".encode(),
        )
        self.assertEqual(process.returncode, 10)
        result = json.loads(process.stdout)
        process = self.cli("--resume", result["job_dir"], "--target-language", "fr")
        self.assertEqual(process.returncode, 2)
        self.assertEqual(
            json.loads(process.stdout)["reason"],
            "resume_uses_saved_options_start_new_job_to_change",
        )
        args = app.build_parser().parse_args(
            ["--text", "你好", "--target-language", "en", "--output", str(self.output)]
        )
        result, code = self.finish(args)
        self.assertEqual(code, 0)
        self.assertEqual(result["results"][0]["source"], "inline_text.txt")

    def test_runs_have_unique_names_and_private_state(self):
        first, code = app.start(self.args())
        second, code = app.start(self.args())
        self.assertNotEqual(first["job_dir"], second["job_dir"])
        if os.name == "posix":
            self.assertEqual(Path(first["job_dir"]).stat().st_mode & 0o077, 0)
            self.assertEqual(
                (Path(first["job_dir"]) / "manifest.json").stat().st_mode & 0o077, 0
            )

    def test_limits_and_safe_json_boundaries(self):
        with patch.object(app, "MAX_BATCH", 2), self.assertRaisesRegex(
            files.TranslationError, "batch_over"
        ):
            app.start(self.args())
        self.assertFalse(self.output.exists())
        for raw in (b'{"x":1,"x":2}', b'{"x":NaN}'):
            with self.assertRaises(files.TranslationError):
                files.loads(raw)
        for value in ("../escape", "/absolute", "C:/root", "a\\b", "a/../b"):
            with self.assertRaises(files.TranslationError):
                files.relative_path(value)
        for raw in (b"\xff", codecs.BOM_UTF32_LE + b"abcd", b"a\0b"):
            with self.assertRaises(files.TranslationError):
                files.decode(raw, "utf-8")

    def test_natural_internal_spaces_around_numbers_without_changed_line_margins(self):
        self.doc.write_bytes("  支持3种语言。\r\n".encode())
        result, code = self.finish(
            transform=lambda s, t: {"支持": "Supports ", "种语言。": " languages."}[s]
        )
        self.assertEqual(code, 0, result)
        self.assertEqual(
            Path(result["results"][0]["output"]).read_bytes(),
            b"  Supports 3 languages.\r\n",
        )

    def test_bounded_neighbor_context_and_edge_permissions_reach_model(self):
        self.doc.write_text("欢迎{name}来到3个项目。")
        result, code = app.start(self.args())
        packet = self.data(result["pending_requests"][0]["request_path"])
        rows = packet["payload"]["items"]
        self.assertEqual(rows[0]["context"]["after"], "{name}来到3个项目。")
        self.assertFalse(rows[0]["context"]["allow_leading_space"])
        self.assertTrue(rows[0]["context"]["allow_trailing_space"])
        self.assertTrue(rows[-1]["context"]["allow_leading_space"])
        self.assertFalse(rows[-1]["context"]["allow_trailing_space"])
        for row in rows:
            self.assertLessEqual(len(row["context"]["before"]), 120)
            self.assertLessEqual(len(row["context"]["after"]), 120)
        self.answer(result, lambda s, t: " " + s)
        result, code = app.resume(result["job_dir"])
        self.assertEqual(code, 1)
        self.assertEqual(result["results"][0]["status"], "invalid_ai_response")

    def test_runtime_needs_no_third_party_packages(self):
        process = subprocess.run(
            [
                sys.executable,
                "-S",
                "-B",
                str(ROOT / "scripts/ai_batch_translator.py"),
                "--file",
                str(self.doc),
                "--target-language",
                "en",
                "--output",
                str(self.output),
                "--dry-run",
            ],
            capture_output=True,
            timeout=30,
        )
        self.assertEqual(process.returncode, 0, process.stderr)
        self.assertEqual(json.loads(process.stdout)["status"], "dry_run")


if __name__ == "__main__":
    unittest.main()
