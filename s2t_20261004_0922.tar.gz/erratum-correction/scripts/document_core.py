"""Offline, standard-library document segmentation and ordered local correction.

Offsets are Python string offsets, not byte offsets. No file is written here.
See references/formats.md for the deliberately conservative format subset.
"""

from __future__ import annotations

from dataclasses import dataclass
from difflib import SequenceMatcher
import json
from pathlib import Path
import re
from typing import Any, Sequence
import unicodedata

MAX_DICTIONARY_BYTES = 2 * 1024 * 1024
MAX_DIFF_PRODUCT = 4_000_000
MAX_DIFF_CHARACTERS = 100_000
SUPPORTED_EXTENSIONS = frozenset(
    {".txt", ".md", ".markdown", ".srt", ".vtt", ".ass", ".ssa"}
)


class DocumentError(ValueError):
    """A diagnostic code only: never embeds document contents or file paths."""

    def __init__(self, code: str):
        self.code = (
            code
            if isinstance(code, str) and re.fullmatch(r"[a-z][a-z0-9_]{0,79}", code)
            else "document_error"
        )
        super().__init__(self.code)


@dataclass(frozen=True, slots=True)
class TextSegment:
    start: int
    end: int
    text: str
    line: int | None = None


@dataclass(frozen=True, slots=True)
class _Line:
    start: int
    end: int
    text: str
    number: int


_NEWLINES = frozenset("\r\n\x85\u2028\u2029")
# Whole tokens must be preserved, not merely their punctuation characters.
_TOKEN = re.compile(
    r"""<(?:[^<>"']|"[^"]*"|'[^']*')*>|\{[^{}]*\}|\\[^\r\n]?|"""
    r"&(?:\#[0-9]+|\#x[0-9a-fA-F]+|[A-Za-z][A-Za-z0-9]*);|"
    r"(?:https?://|mailto:)[^\s<>\[\]{}]+|-->",
    re.DOTALL,
)
_RAW_HTML_OPEN = re.compile(r"<(pre|code|script|style)(?:\s[^>]*|)>", re.I)
_LINK_LABEL = re.compile(r"\[([^\]\[\r\n]*)\]")


def _text(value: str) -> None:
    if not isinstance(value, str):
        raise DocumentError("text_type")


def _protected_character(char: str) -> bool:
    return char.isspace() or unicodedata.category(char)[0] in "CPSZ"


def _signature(text: str) -> list[str]:
    result: list[str] = []
    pos = 0
    while pos < len(text):
        if text.startswith("<!--", pos):
            close = text.find("-->", pos + 4)
            end = len(text) if close < 0 else close + 3
            result.append(text[pos:end])
            pos = end
            continue
        token = _TOKEN.match(text, pos) if text[pos] in "<>{\\&hm-" else None
        if token:
            result.append(token.group())
            pos = token.end()
        elif _protected_character(text[pos]):
            # Keep whitespace runs as runs: splitting or merging them is a change.
            end = pos + 1
            if text[pos].isspace():
                while end < len(text) and text[end].isspace():
                    end += 1
            result.append(text[pos:end])
            pos = end
        else:
            pos += 1
    return result


def validate_replacement(before: str, after: str) -> None:
    """Raise DocumentError unless a single text segment changes conservatively.

    Whitespace runs, controls, punctuation, symbols, tags, entities, URLs and
    backslash escapes must remain identical and ordered. Edge whitespace is
    exact. This is a structural guard, not a judgment of linguistic correctness.
    """
    _text(before)
    _text(after)
    if "\x00" in before or "\x00" in after:
        raise DocumentError("replacement_nul")
    if any(char in _NEWLINES for char in before + after):
        raise DocumentError("replacement_newline")
    if before.strip() and not after.strip():
        raise DocumentError("replacement_empty")
    if (
        before[: len(before) - len(before.lstrip())]
        != after[: len(after) - len(after.lstrip())]
        or before[len(before.rstrip()) :] != after[len(after.rstrip()) :]
        or _signature(before) != _signature(after)
    ):
        raise DocumentError("replacement_structure")


def _lines(content: str) -> list[_Line]:
    result = []
    for number, match in enumerate(
        re.finditer(r"[^\r\n]*(?:\r\n|\r|\n|$)", content), 1
    ):
        if match.start() == len(content):
            break
        start = match.start()
        end = match.end()
        while end > start and content[end - 1] in "\r\n":
            end -= 1
        if start == 0 and content.startswith("\ufeff"):
            start += 1
        result.append(_Line(start, end, content[start:end], number))
    return result


def _blocks(lines: Sequence[_Line]) -> list[list[_Line]]:
    result: list[list[_Line]] = []
    block: list[_Line] = []
    for line in lines:
        if not line.text.strip():
            if block:
                result.append(block)
                block = []
        else:
            block.append(line)
    if block:
        result.append(block)
    return result


def _merge_ranges(ranges: Sequence[tuple[int, int]]) -> list[tuple[int, int]]:
    merged: list[tuple[int, int]] = []
    for start, end in sorted(ranges):
        if start >= end:
            continue
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(end, merged[-1][1]))
        else:
            merged.append((start, end))
    return merged


def _gaps(start: int, end: int, ranges: Sequence[tuple[int, int]]):
    pos = start
    for left, right in ranges:
        if left > pos:
            yield pos, min(left, end)
        pos = max(pos, right)
        if pos >= end:
            return
    if pos < end:
        yield pos, end


def _add_segment(
    result: list[TextSegment], content: str, start: int, end: int, line: int
) -> None:
    while start < end and content[start].isspace():
        start += 1
    while end > start and content[end - 1].isspace():
        end -= 1
    if start < end:
        result.append(TextSegment(start, end, content[start:end], line))


def _inline_ranges(
    text: str, markdown: bool = False, references: set[str] | None = None
) -> list[tuple[int, int]]:
    """Identify protected tokens; Markdown code spans can span physical lines."""
    ranges: list[tuple[int, int]] = []
    next_tick: dict[int, tuple[int, int]] = {}
    if markdown:
        following: dict[int, tuple[int, int]] = {}
        for match in reversed(list(re.finditer(r"`+", text))):
            width = match.end() - match.start()
            if width in following:
                next_tick[match.start()] = following[width]
            following[width] = (match.start(), match.end())
    pos = 0
    while pos < len(text):
        char = text[pos]
        end = pos
        if markdown and char == "`":
            run_end = pos + 1
            while run_end < len(text) and text[run_end] == "`":
                run_end += 1
            # An unmatched delimiter is protected through its physical line.
            end = next_tick[pos][1] if pos in next_tick else _line_end(text, run_end)
        elif text.startswith("<!--", pos):
            close = text.find("-->", pos + 4)
            end = len(text) if close < 0 else close + 3
        elif markdown and char == "<" and (raw := _RAW_HTML_OPEN.match(text, pos)):
            close = re.compile(r"</" + raw.group(1) + r"\s*>", re.I).search(
                text, raw.end()
            )
            end = len(text) if close is None else close.end()
        elif markdown and char == "]" and pos + 1 < len(text) and text[pos + 1] == "(":
            end = _destination_end(text, pos + 1)
        elif markdown and char == "]" and pos + 1 < len(text) and text[pos + 1] == "[":
            close = text.find("]", pos + 2)
            end = _line_end(text, pos) if close < 0 else close + 1
        elif markdown and char == "[":
            label_match = _LINK_LABEL.match(text, pos)
            if label_match:
                close = label_match.end()
                label = " ".join(label_match[1].split()).casefold()
                if text.startswith("[]", close):
                    end = close + 2  # Collapsed reference: label is the identifier.
                elif (
                    references
                    and label in references
                    and text[close : close + 1] not in ("(", "[")
                ):
                    end = close
        if end == pos:
            token = _TOKEN.match(text, pos) if char in "<>{\\&hm-" else None
            if token:
                end = token.end()
            elif unicodedata.category(char)[0] == "C" or char in _NEWLINES:
                end = pos + 1
            elif markdown and char in "[]()*_!#~|<>`":
                end = pos + 1
        if end > pos:
            ranges.append((pos, end))
            pos = end
        else:
            pos += 1
    return ranges


def _line_end(text: str, start: int) -> int:
    positions = [text.find(char, start) for char in "\r\n"]
    return min((pos for pos in positions if pos >= 0), default=len(text))


def _destination_end(text: str, opening: int) -> int:
    depth = 1
    pos = opening + 1
    quote = ""
    while pos < len(text):
        char = text[pos]
        if char == "\\":
            pos += 2
            continue
        if quote:
            if char == quote:
                quote = ""
        elif char in "\"'" and (pos == opening + 1 or text[pos - 1].isspace()):
            quote = char
        elif char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                return pos + 1
        pos += 1
    # A broken destination must never turn its URL/title into editable prose.
    return len(text)


def _line_segments(content: str, line: _Line) -> list[TextSegment]:
    result: list[TextSegment] = []
    ranges = [(line.start + a, line.start + b) for a, b in _inline_ranges(line.text)]
    for start, end in _gaps(line.start, line.end, ranges):
        _add_segment(result, content, start, end, line.number)
    return result


_FENCE = re.compile(
    r"^[ \t]*(?:>[ \t]*)*(?:(?:[-+*]|[0-9]+[.)])[ \t]+)?(?P<run>`{3,}|~{3,})(?P<info>.*)$"
)
_MD_PREFIX = re.compile(
    r"^[ \t]*(?:>[ \t]*)*(?:(?:#{1,6}|[-+*]|[0-9]+[.)])[ \t]+(?:\[[ xX]\][ \t]+)?)?"
)
_REFERENCE = re.compile(r"^[ \t]{0,3}\[([^\]]+)\]:")


def _markdown(content: str, lines: Sequence[_Line]) -> list[TextSegment]:
    protected: list[tuple[int, int]] = []
    decoration: list[tuple[int, int]] = []
    references: set[str] = set()
    fence: tuple[str, int] | None = None
    frontmatter = (
        lines[0].text.strip()
        if lines and lines[0].text.strip() in ("---", "+++")
        else None
    )
    for index, line in enumerate(lines):
        match = _FENCE.fullmatch(line.text)
        if frontmatter:
            protected.append((line.start, line.end))
            if index and line.text.strip() in (
                frontmatter,
                "..." if frontmatter == "---" else "+++",
            ):
                frontmatter = None
        elif fence:
            protected.append((line.start, line.end))
            if (
                match
                and match["run"][0] == fence[0]
                and len(match["run"]) >= fence[1]
                and not match["info"].strip()
            ):
                fence = None
        elif match:
            protected.append((line.start, line.end))
            fence = (match["run"][0], len(match["run"]))
        elif line.text.startswith(("    ", "\t")):
            protected.append((line.start, line.end))
        elif reference := _REFERENCE.match(line.text):
            protected.append((line.start, line.end))
            references.add(" ".join(reference[1].split()).casefold())
        else:
            prefix = _MD_PREFIX.match(line.text)
            if prefix and prefix.end():
                decoration.append((line.start, line.start + prefix.end()))
    protected = _merge_ranges(protected)
    inline = []
    for start, end in _gaps(0, len(content), protected):
        inline.extend(
            (start + a, start + b)
            for a, b in _inline_ranges(content[start:end], True, references)
        )
    protected = _merge_ranges(protected + inline + decoration)
    result: list[TextSegment] = []
    # Walk both ordered lists once, instead of rescanning all ranges per line.
    cursor = 0
    for line in lines:
        while cursor < len(protected) and protected[cursor][1] <= line.start:
            cursor += 1
        local = []
        index = cursor
        while index < len(protected) and protected[index][0] < line.end:
            local.append(
                (
                    max(line.start, protected[index][0]),
                    min(line.end, protected[index][1]),
                )
            )
            index += 1
        for start, end in _gaps(line.start, line.end, local):
            _add_segment(result, content, start, end, line.number)
    return result


_SRT_TIME = r"[0-9]{2,9}:[0-5][0-9]:[0-5][0-9],[0-9]{3}"
_VTT_TIME = r"(?:[0-9]{2,9}:)?[0-5][0-9]:[0-5][0-9]\.[0-9]{3}"
_SRT_TIMING = re.compile(
    rf"[ \t]*(?P<start>{_SRT_TIME})[ \t]+-->[ \t]+(?P<end>{_SRT_TIME})[ \t]*"
)
_VTT_TIMING = re.compile(
    rf"[ \t]*(?P<start>{_VTT_TIME})[ \t]+-->[ \t]+(?P<end>{_VTT_TIME})(?P<settings>(?:[ \t]+[^\s]+)*)[ \t]*"
)
_ASS_TIME = re.compile(r"[0-9]{1,9}:[0-5][0-9]:[0-5][0-9]\.[0-9]{2}")


def _time_value(text: str) -> int:
    parts = text.replace(",", ".").split(":")
    seconds, fraction = parts[-1].split(".")
    minutes = int(parts[-2])
    hours = int(parts[0]) if len(parts) == 3 else 0
    return ((hours * 60 + minutes) * 60 + int(seconds)) * 1000 + int(
        fraction.ljust(3, "0")
    )


def _time_order(start: str, end: str) -> None:
    if _time_value(end) <= _time_value(start):
        raise DocumentError("subtitle_time_order")


def _vtt_settings(settings: str) -> None:
    seen: set[str] = set()
    patterns = {
        "vertical": r"(?:rl|lr)",
        "line": r"(?:auto|-?[0-9]+|[0-9]+(?:\.[0-9]+)?%)(?:,(?:start|center|end))?",
        "position": r"[0-9]+(?:\.[0-9]+)?%(?:,(?:line-left|center|line-right|auto))?",
        "size": r"[0-9]+(?:\.[0-9]+)?%",
        "align": r"(?:start|center|end|left|right)",
        "region": r"[^\s:]+",
    }
    for setting in settings.split():
        key, separator, value = setting.partition(":")
        if (
            not separator
            or key not in patterns
            or key in seen
            or not re.fullmatch(patterns[key], value)
        ):
            raise DocumentError("vtt_settings")
        if "%" in value:
            try:
                percentage = float(value.split("%", 1)[0])
            except ValueError:
                raise DocumentError("vtt_settings") from None
            if not 0 <= percentage <= 100:
                raise DocumentError("vtt_settings")
        seen.add(key)


def _subtitles(content: str, lines: Sequence[_Line], vtt: bool) -> list[TextSegment]:
    blocks = _blocks(lines)
    if not blocks:
        raise DocumentError("subtitle_structure")
    if vtt:
        header = blocks.pop(0)
        if not re.fullmatch(r"WEBVTT(?:[ \t].*)?", header[0].text) or any(
            "-->" in line.text for line in header
        ):
            raise DocumentError("vtt_header")
        if lines and header[0] is not lines[0]:
            raise DocumentError("vtt_header")
    result: list[TextSegment] = []
    for block in blocks:
        if vtt and (
            re.match(r"NOTE(?:[ \t]|$)", block[0].text)
            or block[0].text in ("STYLE", "REGION")
        ):
            continue
        timing_index = 0
        if not vtt:
            if not re.fullmatch(r"[ \t]*[0-9]+[ \t]*", block[0].text):
                raise DocumentError("srt_index")
            timing_index = 1
        elif not _VTT_TIMING.fullmatch(block[0].text):
            if "-->" in block[0].text:
                raise DocumentError("subtitle_timing")
            timing_index = 1  # Optional VTT cue identifier.
        if len(block) <= timing_index + 1:
            raise DocumentError("subtitle_structure")
        timing = (_VTT_TIMING if vtt else _SRT_TIMING).fullmatch(
            block[timing_index].text
        )
        if timing is None:
            raise DocumentError("subtitle_timing")
        _time_order(timing["start"], timing["end"])
        if vtt:
            _vtt_settings(timing["settings"])
        for line in block[timing_index + 1 :]:
            # A complete timing line here is ambiguous (usually a missing blank
            # separator), unlike ordinary dialogue merely containing an arrow.
            if _SRT_TIMING.fullmatch(line.text) or _VTT_TIMING.fullmatch(line.text):
                raise DocumentError("subtitle_missing_separator")
            result.extend(_line_segments(content, line))
    return result


def _ass_text(content: str, line: _Line, text_start: int) -> list[TextSegment]:
    result: list[TextSegment] = []
    pos = text_start
    drawing = False
    while pos < line.end:
        if content[pos] == "{":
            close = content.find("}", pos + 1, line.end)
            if close < 0 or "{" in content[pos + 1 : close]:
                raise DocumentError("ass_override")
            tag = content[pos + 1 : close]
            for mode in re.finditer(r"\\p(?![A-Za-z])([^\\]*)", tag):
                value = mode[1].strip()
                if not re.fullmatch(r"[0-9]+", value):
                    raise DocumentError("ass_drawing_mode")
                drawing = any(char != "0" for char in value)
            pos = close + 1
        elif content[pos] == "}":
            raise DocumentError("ass_override")
        else:
            end = pos
            while end < line.end and content[end] not in "{}":
                end += 1
            if not drawing:
                fragment = _Line(pos, end, content[pos:end], line.number)
                result.extend(_line_segments(content, fragment))
            pos = end
    return result


def _ass(content: str, lines: Sequence[_Line]) -> list[TextSegment]:
    result: list[TextSegment] = []
    section = ""
    found_events = False
    fields: list[str] | None = None
    for line in lines:
        stripped = line.text.strip()
        if not stripped or stripped.startswith(";"):
            continue
        if stripped.startswith("["):
            if not re.fullmatch(r"\[[^\[\]]+\]", stripped):
                raise DocumentError("ass_section")
            section = stripped[1:-1].casefold()
            if section == "events":
                found_events = True
                fields = None
            continue
        key, separator, value = line.text.partition(":")
        key = key.strip().casefold()
        if section != "events":
            if key in ("dialogue", "comment"):
                raise DocumentError("ass_event_section")
            continue
        if not separator:
            raise DocumentError("ass_event")
        if key == "format":
            fields = [field.strip().casefold() for field in value.split(",")]
            if (
                not all(fields)
                or len(fields) != len(set(fields))
                or not {"start", "end", "text"}.issubset(fields)
            ):
                raise DocumentError("ass_format")
            if fields[-1] != "text":
                raise DocumentError("ass_text_position")
        elif key in ("dialogue", "comment"):
            if fields is None:
                raise DocumentError("ass_missing_format")
            parts = value.split(",", len(fields) - 1)
            if len(parts) != len(fields):
                raise DocumentError("ass_event")
            start, end = (
                parts[fields.index("start")].strip(),
                parts[fields.index("end")].strip(),
            )
            if not _ASS_TIME.fullmatch(start) or not _ASS_TIME.fullmatch(end):
                raise DocumentError("subtitle_timing")
            _time_order(start, end)
            result.extend(_ass_text(content, line, line.end - len(parts[-1])))
        else:
            raise DocumentError("ass_event_type")
    if not found_events:
        raise DocumentError("ass_events_missing")
    return result


def extract_segments(content: str, ext: str) -> list[TextSegment]:
    """Extract ordered, nonoverlapping visible text; all other bytes stay put."""
    _text(content)
    if not isinstance(ext, str) or ext.lower() not in SUPPORTED_EXTENSIONS:
        raise DocumentError("unsupported_extension")
    if "\x00" in content:
        raise DocumentError("document_nul")
    lines = _lines(content)
    ext = ext.lower()
    if ext in (".md", ".markdown"):
        return _markdown(content, lines)
    if ext in (".srt", ".vtt"):
        return _subtitles(content, lines, ext == ".vtt")
    if ext in (".ass", ".ssa"):
        return _ass(content, lines)
    return [segment for line in lines for segment in _line_segments(content, line)]


def apply_segments(
    content: str, segments: Sequence[TextSegment], new_texts: Sequence[str]
) -> str:
    """Validate then reconstruct in one forward join: O(input + output size).

    Segments must already be in ascending order, as extract_segments returns.
    This never guesses offsets, silently truncates zip(), or sorts bad input.
    """
    _text(content)
    if len(segments) != len(new_texts):
        raise DocumentError("segment_cardinality")
    output: list[str] = []
    cursor = 0
    for segment, replacement in zip(segments, new_texts):
        if not isinstance(segment, TextSegment):
            raise DocumentError("segment_type")
        if (
            type(segment.start) is not int
            or type(segment.end) is not int
            or not 0 <= segment.start < segment.end <= len(content)
        ):
            raise DocumentError("segment_range")
        if segment.start < cursor:
            raise DocumentError("segment_overlap_or_order")
        if content[segment.start : segment.end] != segment.text:
            raise DocumentError("segment_content")
        validate_replacement(segment.text, replacement)
        output.append(content[cursor : segment.start])
        output.append(replacement)
        cursor = segment.end
    output.append(content[cursor:])
    return "".join(output)


class HomophoneCorrector:
    """Exact ordered sequential replacements, compatible with the source tool."""

    def __init__(self, json_path: str | Path):
        self.json_path = Path(json_path)
        self.pairs: list[tuple[str, str]] = []
        self.self_maps: list[str] = []
        self.metadata_keys: list[str] = []
        self.script_sensitive: dict[str, dict[str, str]] = {}
        try:
            with self.json_path.open("rb") as stream:
                payload = stream.read(MAX_DICTIONARY_BYTES + 1)
        except (OSError, ValueError):
            raise DocumentError("dictionary_read") from None
        if len(payload) > MAX_DICTIONARY_BYTES:
            raise DocumentError("dictionary_too_large")

        def object_pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
            result: dict[str, Any] = {}
            for key, value in items:
                if key in result:
                    raise DocumentError(
                        "dictionary_duplicate_key"
                        if result[key] == value
                        else "dictionary_conflicting_key"
                    )
                result[key] = value
            return result

        def invalid_constant(value: str) -> None:
            raise DocumentError("dictionary_json")

        try:
            data = json.loads(
                payload.decode("utf-8-sig"),
                object_pairs_hook=object_pairs,
                parse_constant=invalid_constant,
            )
        except DocumentError:
            raise
        except (UnicodeError, ValueError, RecursionError):
            raise DocumentError("dictionary_json") from None
        if not isinstance(data, dict):
            raise DocumentError("dictionary_table")
        if {"_schema", "_review_only", "_approved_non_roundtrip"}.issubset(data):
            raise DocumentError("dictionary_source_requires_build")
        sensitive = data.get("_script_sensitive", {})
        if not isinstance(sensitive, dict) or len(sensitive) > 1000:
            raise DocumentError("dictionary_script_sensitive")
        for wrong, options in sensitive.items():
            if not isinstance(options, dict) or set(options) != {
                "simplified",
                "traditional",
            }:
                raise DocumentError("dictionary_script_sensitive")
            values = [wrong, options["simplified"], options["traditional"]]
            if any(
                not isinstance(value, str)
                or not value
                or len(value) > 100
                or any(char.isspace() or ord(char) < 32 for char in value)
                for value in values
            ):
                raise DocumentError("dictionary_script_sensitive")
            if (
                wrong.startswith("_")
                or wrong in data
                or options["simplified"] == options["traditional"]
            ):
                raise DocumentError("dictionary_script_sensitive")
            self.script_sensitive[wrong] = dict(options)
        for wrong, right in data.items():
            if wrong.startswith("_"):
                self.metadata_keys.append(wrong)
                continue
            if not wrong.strip() or not isinstance(right, str) or not right.strip():
                raise DocumentError("dictionary_rule")
            if any(char in _NEWLINES or char == "\x00" for char in wrong + right):
                raise DocumentError("dictionary_rule")
            if wrong == right:
                self.self_maps.append(wrong)
            else:
                self.pairs.append((wrong, right))

    def correct(self, text: str) -> tuple[str, int]:
        corrected, hits, _ = self.correct_with_details(text)
        return corrected, hits

    def correct_with_details(
        self, text: str
    ) -> tuple[str, int, list[tuple[str, str, int]]]:
        _text(text)
        hits = 0
        matched_rules: list[tuple[str, str, int]] = []
        for wrong, right in self.pairs:
            count = text.count(wrong)
            if count:
                hits += count
                matched_rules.append((wrong, right, count))
                text = text.replace(wrong, right)
        return text, hits, matched_rules


def contains_chinese(text: str) -> bool:
    """Match the source tool's CJK Unified Ideographs (U+4E00–U+9FFF)."""
    _text(text)
    return bool(re.search(r"[\u4e00-\u9fff]", text))


def extract_ai_error_terms(before: str, after: str) -> list[dict[str, Any]]:
    """Original SequenceMatcher opcodes and precise offsets, with a hard bound.

    No heuristic fallback or prefix trimming changes the original alignment.
    Callers must handle diff_too_large; no AI or network operation occurs here.
    """
    _text(before)
    _text(after)
    if before == after:
        return []
    if (
        len(before) + len(after) > MAX_DIFF_CHARACTERS
        or len(before) * len(after) > MAX_DIFF_PRODUCT
    ):
        raise DocumentError("diff_too_large")
    errors = []
    for tag, i1, i2, j1, j2 in SequenceMatcher(
        None, before, after, autojunk=False
    ).get_opcodes():
        if tag != "equal":
            errors.append(
                {
                    "before": before[i1:i2],
                    "after": after[j1:j2],
                    "type": tag,
                    "before_start": i1,
                    "before_end": i2,
                    "after_start": j1,
                    "after_end": j2,
                }
            )
    return errors
