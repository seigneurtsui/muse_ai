'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  AdapterError,
  buildCliArgs,
  classifyError,
  parseArgs,
  query,
  recordAirlines,
  shanghaiDatePlusDays,
} = require('./flight_query.cjs');

test('parses Chinese city flags, date, limit, and official CLI arguments', () => {
  const options = parseArgs([
    '--from',
    '北京',
    '--to',
    '上海',
    '--date',
    '2099-01-02',
    '--limit',
    '3',
  ]);
  assert.equal(options.from, '北京');
  assert.equal(options.to, '上海');
  assert.equal(options.date, '2099-01-02');
  assert.equal(options.limit, 3);
  assert.deepEqual(buildCliArgs(options), [
    'search-flight',
    '--origin',
    '北京',
    '--destination',
    '上海',
    '--dep-date',
    '2099-01-02',
    '--sort-type',
    '3',
  ]);
});

test('accepts airport-code aliases and defaults to Shanghai date plus seven days', () => {
  const now = new Date('2026-10-02T15:00:00.000Z');
  const options = parseArgs(['--origin', 'PEK', '--destination', 'SHA']);
  assert.equal(options.from, 'PEK');
  assert.equal(options.to, 'SHA');
  assert.equal(shanghaiDatePlusDays(7, now), '2026-10-09');
});

test('parses and applies repeatable airline preferences without changing raw records', () => {
  const options = parseArgs([
    '--from', '北京', '--to', '上海', '--date', '2099-01-02',
    '--prefer-airline', '中国国际航空, MU', '--prefer-airline', '厦门航空',
  ]);
  assert.deepEqual(options.preferredAirlines, ['中国国际航空', 'MU', '厦门航空']);
  const records = [
    { journeys: [{ segments: [{ marketingAirlineName: '中国国际航空', marketingAirlineCode: 'CA' }] }] },
    { journeys: [{ segments: [{ carrierName: '厦门航空', carrierCode: 'MF' }] }] },
    { journeys: [{ segments: [{ marketingAirlineName: '其他航空' }] }] },
  ];
  const result = query({ ...options, limit: 10 }, {
    runner: () => ({ exitCode: 0, stdout: JSON.stringify({ status: 0, data: { itemList: records } }), stderr: '' }),
  });
  assert.deepEqual(recordAirlines(records[0]), ['中国国际航空', 'CA']);
  assert.equal(result.availableCount, 3);
  assert.equal(result.filteredCount, 2);
  assert.deepEqual(result.results, records.slice(0, 2));
  assert.deepEqual(result.query.filters.preferredAirlines, ['中国国际航空', 'MU', '厦门航空']);
});

test('limits but does not rewrite or fabricate upstream records', () => {
  const records = [
    { ticketPrice: '419.00', journeys: [{ segments: [{ marketingTransportNo: 'KN5977' }] }] },
    { adultPrice: '¥500.0', journeys: [] },
  ];
  const result = query(
    { from: '北京', to: '上海', date: '2099-01-02', limit: 1 },
    {
      now: new Date('2026-10-02T09:00:00.000Z'),
      runner: () => ({
        exitCode: 0,
        stdout: JSON.stringify({ status: 0, message: 'success', data: { itemList: records } }),
        stderr: '',
      }),
    },
  );
  assert.equal(result.source, 'FlyAI official CLI (@fly-ai/flyai-cli@1.0.16)');
  assert.equal(result.timestamp, '2026-10-02T09:00:00.000Z');
  assert.equal(result.availableCount, 2);
  assert.equal(result.resultCount, 1);
  assert.deepEqual(result.results, [records[0]]);
});

test('classifies quota and authentication failures clearly', () => {
  assert.equal(classifyError('HTTP 429 quota exceeded', 1).code, 'TRIAL_QUOTA_EXCEEDED');
  assert.equal(classifyError('HTTP 401 unauthorized API key', 1).code, 'TRIAL_AUTH_REQUIRED');
});

test('filters direct flights and sorts by numeric fare', () => {
  const records = [
    {
      ticketPrice: '500.00',
      journeys: [{ segments: [
        { depDateTime: '2099-01-02 09:00:00', arrDateTime: '2099-01-02 15:00:00' },
      ], totalDuration: '360' }],
    },
    {
      ticketPrice: '220.50',
      journeys: [{ segments: [
        { depDateTime: '2099-01-02 10:00:00', arrDateTime: '2099-01-02 12:00:00' },
        { depDateTime: '2099-01-02 13:00:00', arrDateTime: '2099-01-02 14:00:00' },
      ], totalDuration: '240', transferDuration: '60' }],
    },
  ];
  const result = query(
    { from: '北京', to: '厦门', date: '2099-01-02', limit: 10, directOnly: true, sort: 'price' },
    {
      runner: () => ({
        exitCode: 0,
        stdout: JSON.stringify({ status: 0, message: 'success', data: { itemList: records } }),
        stderr: '',
      }),
    },
  );
  assert.equal(result.availableCount, 2);
  assert.equal(result.filteredCount, 1);
  assert.deepEqual(result.results, [records[0]]);
});

test('does not accept a non-success payload as flight data', () => {
  assert.throws(
    () => query(
      { from: '北京', to: '上海', date: '2099-01-02', limit: 1 },
      {
        runner: () => ({
          exitCode: 1,
          stdout: JSON.stringify({ status: 429, message: 'quota exceeded', data: { itemList: [] } }),
          stderr: '',
        }),
      },
    ),
    (error) => error instanceof AdapterError && error.code === 'TRIAL_QUOTA_EXCEEDED',
  );
});
