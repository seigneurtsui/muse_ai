# 验证

## 自动测试

```bash
cd "$HOME/.config/freebuff/skills/html-toc-index"
python3 -B -m black --config /dev/null scripts/build_toc_index.py tests/test_build_toc_index.py
PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest discover -s tests
```

结果：**39 tests, OK**（Python 3.12.10）。`black --check` 通过（exit 0，两文件均未改动）。
脚本仅依赖标准库；未安装任何第三方包。

覆盖范围（`tests/test_build_toc_index.py`）：

- `clean_text` 折叠空白与全角空格；`parse_filename_timestamp` 两种前缀格式与无前缀；
  `extract_title` 清洗残留时间戳、文件名回退、忽略 `untitled`。
- 摘要截断、剥离 `<script>` 且统计字数；从正文提取日期。
- `compute_doc_id` 稳定、长度 6、随文件名与内容变化。
- `guess_tags`：词典命中、`email 版`、2–4 字候选词回退、`未分类` 兜底。
- `load_places_file`：缺失回退内置、自定义文件忽略注释、`None` 返回内置副本。
- `scan_files`：跳过 `index.html`、非 HTML、符号链接；递归；`--exclude-pattern`。
- `inject_doc_toc`：新增锚点与浮动目录、幂等（不重复注入）、少于 2 标题不注入、
  保留已有 id 并为重复标题生成 `-1` 后缀。
- `write_atomic` 创建与替换；`full_update` 生成 `doc-*`；`incremental_update` 跳过未变、
  清理过期；`clean_output` 只删本工具产物、保留无关文件。
- `export_json`/`export_markdown`/`export_txt` 内容与不含正文。
- `render_index` 无残留 `__TOKEN__`、内嵌 `DATA` 可解析、页面标题转义。
- `run()`：完成写索引、dry-run 不写任何文件、空输入为 complete、
  `output_within_input`/`output_equals_input`/`input_not_found` 被拒、
  单文件读取失败（mock）→ `partial_failure` 且退出码 2、`--inject-doc-toc` 报告 `toc_items`。
- `_normalize_argv` 保留以 `-` 开头的值；真实子进程 `--exclude-pattern -email` 生效。
- CLI：`--help`/`--version` 退出 0；真实子进程 dry-run 与正式运行退出 0；坏输入以 `--json`
  返回 `{"status":"error",...}` 且退出 1。

## 端到端 smoke test（真实文件系统）

一个含子目录、`<title>` 带时间戳、无 `<title>` 与 `-email` 文件的目录，执行：

```bash
python3 scripts/build_toc_index.py "$IN" -o "$OUT" --recursive --inject-doc-toc \
  --export-json --export-markdown --export-txt --exclude-pattern '-email' --json
```

实际结果：

- `status=complete`，`summary={scanned:3, total:3, written:3, skipped:0, deleted:0, failed:0}`
  （`-email` 文件被排除；递归扫描到子目录文档）。
- 标题：`20240101T120000==z--南京周末` → `南京周末`，tags `['南京']`；无 `<title>` 文件回退文件名。
- 输出树：`index.html`、`doc-<id>/index.html`（3 个）、`data.json`、`INDEX.md`、`file_list.txt`。
- `--inject-doc-toc` 生效：每篇 `toc_items=3`，文档含 `data-doc-toc="1"` 与标题锚点。
- 索引页无残留 `__TOKEN__`，内嵌 `const DATA = [...]` 可被 `json.loads` 解析。

### 内嵌 JS 语法检查（node v22.20.0）

从生成的 `index.html` 与每个 `doc-*/index.html` 中抽取 `<script>`，用 `node --check` 校验：

- 索引页脚本：`INDEX_JS_OK`。
- 每个注入文档目录后的脚本：`DOC_JS_OK doc-1d1a93`、`DOC_JS_OK doc-4abc45`、`DOC_JS_OK doc-a5810d`。

### 增量/幂等 smoke

- 相同参数 `--incremental` 重跑：`skipped:1`，文档内目录块仍为 1 个（未重复注入）。
- 源内容变更后 `--incremental`：`written:1, deleted:1`（内容寻址的新 `doc_id`，旧目录被清理）。
- 删除源文件后 `--incremental`：`deleted:1`，过期 `doc-*` 目录被移除。
- 输出位于输入内部时：`{"status":"error","reason":"output_within_input"}`，退出码 1。

## 未执行 / 限制

- 未在真实浏览器中做视觉回归；前端通过内嵌 `DATA` 的 JSON 解析与 `node --check` 语法检查验证，
  交互逻辑（搜索/排序/分页/标签）未做 DOM 级自动化测试。
- 未处理超大目录（数万文件的磁盘/内存上限）；并行上限固定为 8。
