'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const net = require('node:net');
const { setTimeout: sleep } = require('node:timers/promises');
const { createReadeckSession } = require('../lib/readeck');
const { buildReadeckHtml } = require('../lib/markdown');
const { request } = require('../lib/transport');

const DOC = { title: 'Selected answer', content: '# Heading\n\nOnly selected **content**.', tags: ['notes'] };
const TOKEN = 'synthetic-test-token-not-a-credential';
const ID = 'BookmarkId123';
const ready = { id: ID, state: 0, loaded: true, has_article: true };

async function listen(server, port = 0) {
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, '127.0.0.1', resolve);
  });
  return server.address().port;
}
async function shutdown(server) {
  await new Promise(resolve => {
    server.close(resolve);
    server.closeAllConnections?.();
  });
}
async function freePort() {
  const server = net.createServer();
  const port = await listen(server);
  await shutdown(server);
  return port;
}
async function assertPortReleased(port) {
  const server = net.createServer();
  await listen(server, port);
  await shutdown(server);
}
function json(res, status, data, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json', ...headers });
  res.end(JSON.stringify(data));
}
function accept(res, headers = {}) { json(res, 202, { message: 'queued' }, { 'Bookmark-Id': ID, ...headers }); }

async function fixture(t, handler, overrides = {}) {
  const received = [];
  const handlerErrors = [];
  const server = http.createServer(async (req, res) => {
    try {
      const parts = [];
      for await (const part of req) parts.push(part);
      const text = Buffer.concat(parts).toString();
      const item = { method: req.method, path: req.url, headers: req.headers, body: text ? JSON.parse(text) : null };
      received.push(item);
      await handler(item, res, received);
    } catch (error) {
      handlerErrors.push(error);
      if (!res.headersSent) json(res, 500, {}); else res.end();
    }
  });
  const servicePort = await listen(server);
  const port = await freePort();
  const config = { url: `http://127.0.0.1:${servicePort}`, token: TOKEN,
    callbackUrl: `http://127.0.0.1:${port}`, bind: '127.0.0.1', port,
    timeoutMs: 300, captureTimeoutMs: 250, pollIntervalMs: 10, ...overrides };
  const session = await createReadeckSession(config);
  t.after(async () => {
    await session.close();
    await shutdown(server);
    assert.deepEqual(handlerErrors, []);
  });
  return { session, received, config, port };
}

function rawCallback(url, path, method = 'GET', headers = {}) {
  const target = new URL(url);
  return new Promise((resolve, reject) => {
    const req = http.request({ hostname: target.hostname, port: target.port, path, method, headers,
      agent: false }, res => {
      const chunks = [];
      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, data: Buffer.concat(chunks).toString() }));
      res.on('error', reject);
    });
    req.on('error', reject);
    req.end();
  });
}

function safeError(error, code, uncertain, auth = false) {
  assert.equal(error.code, code);
  assert.equal(error.message, code);
  assert.equal(error.uncertain, uncertain);
  assert.equal(error.auth, auth);
  const printed = error.stack + JSON.stringify(error);
  for (const secret of [TOKEN, 'private-response-body', DOC.content]) assert.ok(!printed.includes(secret));
  assert.equal(error.cause, undefined);
  return true;
}

test('post once, persist acknowledgment before polling, await delayed HTML capture and article readiness', async t => {
  let accepted = false;
  let fetched = false;
  let source;
  let fetchTask;
  let polls = 0;
  const f = await fixture(t, async (item, res) => {
    assert.equal(item.headers.authorization, 'Bearer ' + TOKEN);
    if (item.method === 'POST') {
      source = item.body.url;
      assert.deepEqual(Object.keys(item.body).sort(), ['labels', 'title', 'url']);
      assert.equal(item.body.title, DOC.title);
      assert.deepEqual(item.body.labels, DOC.tags);
      assert.match(new URL(source).pathname, /^\/temp\/[a-f0-9]{48}$/);
      accept(res, { Location: '/api/bookmarks/' + ID });
    } else {
      assert.equal(accepted, true);
      assert.equal(item.path, '/api/bookmarks/' + ID);
      polls++;
      if (!fetchTask) fetchTask = sleep(25).then(async () => {
        const page = await request(source);
        assert.equal(page.status, 200);
        assert.match(page.data, /Only selected <strong>content<\/strong>/);
        assert.ok(!page.data.includes(TOKEN));
        fetched = true;
      });
      json(res, 200, fetched ? ready : { id: ID, state: 2, loaded: false, has_article: false });
    }
  });
  const result = await f.session.publish(DOC, { onAccepted: async value => {
    assert.deepEqual(value, { remoteId: ID });
    await sleep(10);
    accepted = true;
  } });
  await fetchTask;
  assert.deepEqual(result, { status: 'submitted', remoteId: ID, accepted: true,
    callbackReceived: true, callbackHeadReceived: false, captureComplete: true, pollFailed: false });
  assert.ok(polls >= 2);
  assert.equal(f.received.filter(item => item.method === 'POST').length, 1);
  await assertPortReleased(f.port);
  await assert.rejects(request(source, { timeoutMs: 100 }));
});

for (const scenario of [
  { name: 'ready without any callback', data: ready },
  { name: 'loading without callback', data: { id: ID, state: 2, loaded: false } },
  { name: 'loaded boolean alone is insufficient', data: { id: ID, loaded: true, has_article: true } },
  { name: 'GET alone does not establish capture completion', data: { id: ID, state: 2, loaded: false }, callback: 'GET' },
  { name: 'HEAD does not count as receiving HTML', data: ready, callback: 'HEAD' },
]) {
  test(`pending_capture: ${scenario.name}`, async t => {
    const f = await fixture(t, async (item, res) => {
      if (item.method === 'POST') {
        if (scenario.callback) await request(item.body.url, { method: scenario.callback });
        accept(res);
      } else json(res, 200, scenario.data);
    }, { captureTimeoutMs: 65 });
    const result = await f.session.publish(DOC);
    assert.equal(result.status, 'pending_capture');
    assert.equal(result.remoteId, ID);
    assert.equal(result.callbackReceived, scenario.callback === 'GET');
    assert.equal(result.callbackHeadReceived, scenario.callback === 'HEAD');
    await assertPortReleased(f.port);
    assert.equal(f.received.filter(item => item.method === 'POST').length, 1);
  });
}

for (const [data, code] of [
  [{ id: ID, state: 1, loaded: true, has_article: true, errors: ['private-response-body'] }, 'READECK_CAPTURE_FAILED'],
  [{ id: ID, state: 0, loaded: true, has_article: false }, 'READECK_CAPTURE_NO_ARTICLE'],
]) {
  test(`${code} keeps accepted ID and never recreates`, async t => {
    const persisted = [];
    const f = await fixture(t, async (item, res) => {
      if (item.method === 'POST') { await request(item.body.url); accept(res); }
      else json(res, 200, data);
    });
    await assert.rejects(f.session.publish(DOC, { onAccepted: value => { persisted.push(value); } }), error => {
      safeError(error, code, false);
      assert.equal(error.accepted, true);
      assert.equal(error.remoteId, ID);
      return true;
    });
    assert.deepEqual(persisted, [{ remoteId: ID }]);
    assert.deepEqual(f.received.map(item => item.method), ['POST', 'GET']);
    await assertPortReleased(f.port);
  });
}

test('callback serves only the exact opaque path, GET/HEAD, no filesystem or query routes', async t => {
  const f = await fixture(t, async (item, res) => {
    if (item.method !== 'POST') return json(res, 200, ready);
    const source = item.body.url;
    const path = new URL(source).pathname;
    for (const wrong of ['/', '/temp/', '/.env', '/server.js', '/temp/../server.js', '/temp/%2e%2e/server.js',
      path + '?x=1', path + '/', path.replace('/temp/', '/%74emp/'), '/temp/not-the-token']) {
      assert.equal((await rawCallback(source, wrong)).status, 404);
    }
    for (const method of ['POST', 'PUT', 'DELETE', 'OPTIONS']) {
      const response = await rawCallback(source, path, method);
      assert.equal(response.status, 405);
      assert.equal(response.headers.allow, 'GET, HEAD');
    }
    const head = await rawCallback(source, path, 'HEAD');
    assert.equal(head.status, 200);
    assert.equal(head.data, '');
    assert.ok(Number(head.headers['content-length']) > 0);
    assert.equal((await rawCallback(source, path, 'GET', { 'Content-Length': '1' })).status, 400);
    const page = await rawCallback(source, path);
    assert.equal(page.status, 200);
    assert.equal(page.headers['content-type'], 'text/html; charset=utf-8');
    assert.equal(page.headers['cache-control'], 'no-store');
    assert.equal(page.headers['referrer-policy'], 'no-referrer');
    assert.match(page.headers['content-security-policy'], /default-src 'none'/);
    assert.ok(!JSON.stringify(page).includes(TOKEN));
    accept(res);
  });
  const result = await f.session.publish(DOC);
  assert.equal(result.status, 'submitted');
  assert.equal(result.callbackHeadReceived, true);
  await assertPortReleased(f.port);
});

const badAcknowledgments = [
  { name: 'missing ID', headers: {}, data: { message: 'private-response-body' } },
  { name: 'empty ID', headers: { 'Bookmark-Id': '' } },
  { name: 'path injection', headers: { 'Bookmark-Id': '../bad' } },
  { name: 'URL injection', data: { id: 'https://other.invalid' } },
  { name: 'numeric ID', data: { id: 123 } },
  { name: 'header injection in JSON ID', data: { id: 'bad\r\nAuthorization: private-response-body' } },
  { name: 'oversized ID', data: { id: 'a'.repeat(129) } },
  { name: 'conflicting IDs', headers: { 'Bookmark-Id': ID }, data: { id: 'different' } },
  { name: 'foreign Location', headers: { Location: 'http://other.invalid/api/bookmarks/' + ID } },
  { name: 'query Location', headers: { Location: '/api/bookmarks/' + ID + '?x=1' } },
  { name: 'fragment Location', headers: { Location: '/api/bookmarks/' + ID + '#secret' } },
  { name: 'encoded Location', headers: { Location: '/api/bookmarks/%2e%2e' } },
  { name: 'dot segment Location', headers: { Location: '/api/bookmarks/x/../' + ID } },
  { name: 'unrelated Location', headers: { Location: '/other/' + ID } },
  { name: 'ID with extra path segment', headers: { Location: '/api/bookmarks/' + ID + '/article' } },
];
for (const scenario of badAcknowledgments) {
  test(`ambiguous create acknowledgment: ${scenario.name}`, async t => {
    let saved = false;
    const f = await fixture(t, (_, res) => json(res, 202, scenario.data || {}, scenario.headers));
    await assert.rejects(f.session.publish(DOC, { onAccepted: () => { saved = true; } }), error =>
      safeError(error, 'READECK_INVALID_ACKNOWLEDGMENT', true));
    assert.equal(saved, false);
    assert.equal(f.received.length, 1);
    await assertPortReleased(f.port);
  });
}

for (const kind of ['body', 'location', 'absolute-location']) {
  test(`accept ID from ${kind} and preserve service base path`, async t => {
    const f = await fixture(t, async (item, res) => {
      assert.ok(item.path.startsWith('/readeck/api/bookmarks'));
      if (item.method === 'POST') {
        await request(item.body.url);
        const location = (kind === 'absolute-location' ? f.config.url.replace('/readeck', '') : '') + '/readeck/api/bookmarks/' + ID;
        json(res, 202, kind === 'body' ? { id: ID } : {}, kind === 'body' ? {} : { Location: location });
      } else json(res, 200, ready);
    });
    await f.session.close();
    f.config.url += '/readeck';
    const session = await createReadeckSession(f.config);
    t.after(() => session.close());
    assert.equal((await session.publish(DOC)).status, 'submitted');
    await assertPortReleased(f.port);
  });
}

for (const status of [400, 401, 403, 429, 500, 503, 302]) {
  test(`create HTTP ${status} classifies rejection/ambiguity without exposing body`, async t => {
    const f = await fixture(t, (_, res) => json(res, status, { error: TOKEN + 'private-response-body' }, { Location: 'http://other.invalid/' }));
    const uncertain = status < 400 || status >= 500;
    await assert.rejects(f.session.publish(DOC), error => safeError(error,
      uncertain ? 'READECK_CREATE_UNCERTAIN' : 'READECK_CREATE_REJECTED', uncertain, status === 401 || status === 403));
    assert.equal(f.received.length, 1);
    await assertPortReleased(f.port);
  });
}

test('create timeout is uncertain, bounded, never retried and releases listener', async t => {
  const f = await fixture(t, () => {}, { timeoutMs: 35 });
  const start = Date.now();
  await assert.rejects(f.session.publish(DOC), error => safeError(error, 'READECK_CREATE_UNCERTAIN', true));
  assert.ok(Date.now() - start < 1000);
  assert.equal(f.received.length, 1);
  await assertPortReleased(f.port);
});

test('capture deadline bounds a slower details request independently of request timeout', async t => {
  const f = await fixture(t, (item, res) => {
    if (item.method === 'POST') accept(res);
  }, { timeoutMs: 1000, captureTimeoutMs: 45 });
  const start = Date.now();
  const result = await f.session.publish(DOC);
  assert.equal(result.status, 'pending_capture');
  assert.equal(result.pollFailed, true);
  assert.ok(Date.now() - start < 500);
  assert.equal(f.received.filter(item => item.method === 'POST').length, 1);
  await assertPortReleased(f.port);
});

test('network exceptions and injected messages never escape', async t => {
  const f = await fixture(t, () => {}, { requestFn: async () => {
    throw Object.assign(new Error(TOKEN + DOC.content), { code: 'private-response-body' });
  } });
  await assert.rejects(f.session.publish(DOC), error => safeError(error, 'READECK_CREATE_UNCERTAIN', true));
  await assertPortReleased(f.port);
});

for (const scenario of ['timeout', 'malformed', 'wrong-id', 'server-error', 'redirect', 'auth']) {
  test(`poll ${scenario} never issues another create`, async t => {
    const f = await fixture(t, (item, res) => {
      if (item.method === 'POST') return accept(res);
      if (scenario === 'timeout') return;
      if (scenario === 'malformed') return json(res, 200, { message: 'private-response-body' });
      if (scenario === 'wrong-id') return json(res, 200, { ...ready, id: 'AnotherId' });
      json(res, scenario === 'auth' ? 403 : scenario === 'redirect' ? 302 : 503, { message: 'private-response-body' });
    }, { timeoutMs: 30, captureTimeoutMs: 90 });
    if (scenario === 'auth') {
      await assert.rejects(f.session.publish(DOC), error => {
        safeError(error, 'READECK_POLL_REJECTED', false, true);
        assert.equal(error.remoteId, ID);
        assert.equal(error.accepted, true);
        return true;
      });
    } else {
      const result = await f.session.publish(DOC);
      assert.equal(result.status, 'pending_capture');
      assert.equal(result.pollFailed, true);
    }
    assert.equal(f.received.filter(item => item.method === 'POST').length, 1);
    await assertPortReleased(f.port);
  });
}

for (const hang of [false, true]) {
  test(`acceptance persistence ${hang ? 'timeout' : 'failure'} is safe and stops before polling`, async t => {
    const f = await fixture(t, (_, res) => accept(res), { captureTimeoutMs: 35 });
    await assert.rejects(f.session.publish(DOC, { onAccepted: () => {
      if (hang) return new Promise(() => {});
      throw new Error(TOKEN + 'private-response-body');
    } }), error => {
      safeError(error, 'READECK_ACCEPTANCE_PERSIST_FAILED', true);
      assert.equal(error.remoteId, ID);
      assert.equal(error.accepted, true);
      return true;
    });
    assert.equal(f.received.length, 1);
    await assertPortReleased(f.port);
  });
}

test('explicit close stops in-flight polling and destroys incomplete callback sockets', async t => {
  let callbackSocket;
  let signalAccepted;
  const accepted = new Promise(resolve => { signalAccepted = resolve; });
  const f = await fixture(t, (item, res) => {
    if (item.method === 'POST') return accept(res);
    json(res, 200, { id: ID, state: 2, loaded: false });
  });
  const publishing = f.session.publish(DOC, { onAccepted: signalAccepted });
  await accepted;
  callbackSocket = net.connect(f.port, '127.0.0.1');
  t.after(() => callbackSocket.destroy());
  await new Promise((resolve, reject) => { callbackSocket.once('connect', resolve); callbackSocket.once('error', reject); });
  callbackSocket.write('GET /temp/incomplete HTTP/1.1\r\n');
  await f.session.close();
  assert.equal((await publishing).status, 'pending_capture');
  await f.session.close();
  await assertPortReleased(f.port);
  await assert.rejects(f.session.publish(DOC), error => safeError(error, 'READECK_SESSION_CLOSED', false));
});

test('immediate close during startup cannot leave a late listener or send a POST', async t => {
  const f = await fixture(t, (_, res) => accept(res));
  const publishing = f.session.publish(DOC);
  const rejected = assert.rejects(publishing, error => safeError(error, 'READECK_CALLBACK_LISTEN_FAILED', false));
  await f.session.close();
  await rejected;
  await sleep(20);
  assert.equal(f.received.length, 0);
  await assertPortReleased(f.port);
});

test('parallel publish is rejected without cancelling the first publication', async t => {
  const f = await fixture(t, async (item, res) => {
    if (item.method === 'POST') { await request(item.body.url); accept(res); }
    else json(res, 200, ready);
  });
  const publishing = f.session.publish(DOC);
  await assert.rejects(f.session.publish(DOC), error => safeError(error, 'READECK_SESSION_BUSY', false));
  assert.equal((await publishing).status, 'submitted');
  assert.equal(f.received.filter(item => item.method === 'POST').length, 1);
  await assertPortReleased(f.port);
});

test('session supports sequential publications with distinct ephemeral sources', async t => {
  const sources = [];
  const f = await fixture(t, async (item, res) => {
    if (item.method === 'POST') { sources.push(item.body.url); await request(item.body.url); accept(res); }
    else json(res, 200, ready);
  });
  assert.equal((await f.session.publish(DOC)).status, 'submitted');
  await assertPortReleased(f.port);
  assert.equal((await f.session.publish(DOC)).status, 'submitted');
  assert.equal(sources.length, 2);
  assert.notEqual(sources[0], sources[1]);
  await assertPortReleased(f.port);
});

test('same-origin Location userinfo is rejected even when host and ID match', async t => {
  const f = await fixture(t, (_, res) => {
    const location = f.config.url.replace('http://', 'http://@') + '/api/bookmarks/' + ID;
    accept(res, { Location: location });
  });
  await assert.rejects(f.session.publish(DOC), error => safeError(error, 'READECK_INVALID_ACKNOWLEDGMENT', true));
  assert.equal(f.received.length, 1);
  await assertPortReleased(f.port);
});

test('busy listener is rejected before any create and does not disturb its owner', async t => {
  const occupied = http.createServer((_, res) => res.end('owner'));
  const port = await listen(occupied);
  t.after(() => shutdown(occupied));
  const f = await fixture(t, (_, res) => accept(res), { port });
  await assert.rejects(f.session.publish(DOC), error => safeError(error, 'READECK_CALLBACK_LISTEN_FAILED', false));
  assert.equal(f.received.length, 0);
  assert.equal((await request(`http://127.0.0.1:${port}`)).data, 'owner');
});

test('invalid callback URLs, binds, ports and deadlines fail before networking', async () => {
  const config = { url: 'https://service.invalid', token: TOKEN, callbackUrl: 'https://callback.invalid', port: 34567 };
  for (const callbackUrl of ['file:///tmp/a', 'ftp://callback.invalid', 'https://u:p@callback.invalid',
    'https://@callback.invalid', 'https://callback.invalid/?x=1', 'https://callback.invalid/#x',
    'https://callback.invalid/?', 'https://callback.invalid/#', 'https://callback.invalid/prefix',
    'https://callback.invalid/a/..', 'https://callback.invalid/%2e', 'http://callback.invalid:0',
    'http://0.0.0.0', 'http://[::]', 'http://callback.invalid\\evil', ' https://callback.invalid']) {
    await assert.rejects(createReadeckSession({ ...config, callbackUrl }), error => safeError(error, 'READECK_INVALID_CALLBACK_URL', false));
  }
  for (const port of [0, -1, 65536, '34567', 1.5, NaN, undefined]) {
    await assert.rejects(createReadeckSession({ ...config, port }), error => safeError(error, 'READECK_INVALID_PORT', false));
  }
  for (const bind of ['', '*', 'callback.invalid', '/tmp/socket', '127.0.0.1\n', 'fe80::1%en0']) {
    await assert.rejects(createReadeckSession({ ...config, bind }), error => safeError(error, 'READECK_INVALID_BIND', false));
  }
  for (const item of [{ timeoutMs: 0 }, { timeoutMs: 120001 }, { captureTimeoutMs: Infinity },
    { captureTimeoutMs: 300001 }, { pollIntervalMs: 0 }, { pollIntervalMs: 10001 }]) {
    await assert.rejects(createReadeckSession({ ...config, ...item }), error => safeError(error, 'READECK_INVALID_TIMEOUT', false));
  }
});

test('invalid documents do not open listener or submit', async t => {
  const f = await fixture(t, (_, res) => accept(res));
  for (const doc of [null, { ...DOC, title: '' }, { ...DOC, content: '' }, { ...DOC, tags: 'tag' },
    { ...DOC, content: 'x'.repeat(1024 * 1024 + 1) }, { ...DOC, tags: Array(101).fill('tag') }]) {
    await assert.rejects(f.session.publish(doc), error => safeError(error, 'READECK_INVALID_DOCUMENT', false));
  }
  await assert.rejects(f.session.publish({ ...DOC, content: '<'.repeat(1024 * 1024) }),
    error => safeError(error, 'READECK_DOCUMENT_TOO_LARGE', false));
  assert.equal(f.received.length, 0);
  await assertPortReleased(f.port);
});

test('original renderer retains headings, lists, tables, quotes, code and emphasis', () => {
  const html = buildReadeckHtml('Title <safe>', [
    '# Heading', '', '**bold** *italic* ~~deleted~~', '', '> quote', '', '- first', '- second', '',
    '1. ordered', '', '| A | B |', '| --- | --- |', '| c | d |', '', '---', '',
    '```js', '<script>code & only</script>', '```', '', '`<inline>`',
  ].join('\n'));
  for (const fragment of ['<title>Title &lt;safe&gt;</title>', '<h1>Heading</h1>', '<strong>bold</strong>',
    '<em>italic</em>', '<del>deleted</del>', '<blockquote>', '<ul>', '<ol>', '<th>A</th>', '<td>d</td>',
    '<hr>', '<pre><code class="language-js">&lt;script&gt;code &amp; only&lt;/script&gt;', '<code>&lt;inline&gt;</code>']) {
    assert.ok(html.includes(fragment), fragment);
  }
});

test('malicious Markdown cannot create scripts, unsafe hrefs, attributes or image loads', () => {
  const html = buildReadeckHtml('</title><script>bad</script>', [
    '<img src=x onerror=alert(1)>', '[x](javascript:alert(1))', '[x](JaVaScRiPt:evil)',
    '[x](data:text/html,bad)', '[x](vbscript:evil)', '[x](jav&#x61;script:evil)',
    '[x](javascript&colon;evil)', '[x](java\tscript:evil)', '[x](//evil.invalid)',
    '[x](https://safe.invalid/" onmouseover="bad)', '[x](https://safe.invalid/`" autofocus="bad`)',
    '[x](https://safe.invalid/&#34;onmouseover=bad)', '[x](https://user:pass@evil.invalid)',
    '[<svg onload=bad>](https://safe.invalid/)', '![photo](https://evil.invalid/image.png)',
    '[safe **label**](https://safe.invalid/a_b_c?q=1&next=2)',
  ].join('\n'));
  assert.ok(!/<script|<img|<svg/i.test(html));
  const anchors = [...html.matchAll(/<a\b([^>]*)>/g)];
  assert.equal(anchors.length, 3);
  for (const [, attrs] of anchors) {
    assert.match(attrs, /^ href="https:\/\/safe\.invalid\/[^"<>]*" rel="noreferrer noopener"$/);
    assert.ok(!attrs.includes('<code>'));
  }
  assert.match(html, /href="https:\/\/safe\.invalid\/a_b_c\?q=1&amp;next=2"/);
  assert.match(html, /&amp;#34;onmouseover=bad/);
  assert.match(html, /safe <strong>label<\/strong>/);
});

test('renderer placeholder-like input is not substituted or expanded inside protected code', () => {
  const html = buildReadeckHtml('title', [
    '%%CB_0%%', '', '%%IC_0%%', '', 'ARSMARK0Z', '',
    '```txt', '%%IC_0%% <img src=x>', 'ARSMARK1Z', '```', '', '`%%CB_0%%`',
  ].join('\n'));
  assert.match(html, /<p>%%CB_0%%<\/p>/);
  assert.match(html, /<p>%%IC_0%%<\/p>/);
  assert.match(html, /<pre><code class="language-txt">%%IC_0%% &lt;img src=x&gt;/);
  assert.match(html, /<code>%%CB_0%%<\/code>/);
  assert.equal((html.match(/<pre>/g) || []).length, 1);
  assert.equal((html.match(/<code(?:>| )/g) || []).length, 2);
});
