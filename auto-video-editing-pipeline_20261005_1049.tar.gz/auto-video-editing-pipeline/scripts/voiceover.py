#!/usr/bin/env python3
"""Opt-in output-timeline voiceover via the installed Edge TTS CLI.

Only an explicit JSON script enables synthesis. This adapter has no TTS engine,
AI processing, source-video access, or source-audio mixer of its own.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

EDGE_TTS_SCRIPT = Path.home() / ".config/omnirush/skills/edge-tts/scripts/tts.py"
SAMPLE_RATE = 48000
CHANNELS = 2
FRAME_BYTES = CHANNELS * 2  # stereo signed 16-bit PCM
CACHE_VERSION = 1
PRIVACY_NOTE = (
    "Microsoft Edge cloud TTS receives the supplied script text for uncached "
    "lines. No video or source audio is uploaded. AI/semantic, translation and "
    "automatic highlight features are disabled."
)


def _number(value, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a finite number")
    try:
        result = float(value)
    except (OverflowError, ValueError) as exc:
        raise ValueError(f"{name} must be finite") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key!r}")
        result[key] = value
    return result


def _load_lines(script_path: Path, video_id: str, duration: float) -> list[dict]:
    if script_path is None:
        raise ValueError("voiceover requires an explicitly supplied JSON script path")
    if not isinstance(video_id, str) or not video_id.strip():
        raise ValueError("video_id must be a non-empty string (required for batch keys)")
    try:
        document = json.loads(
            Path(script_path).expanduser().read_text(encoding="utf-8-sig"),
            object_pairs_hook=_unique_object,
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read voiceover JSON script: {script_path}: {exc}") from exc
    if not isinstance(document, dict) or set(document) not in ({"lines"}, {"videos"}):
        raise ValueError("script must contain exactly 'lines' or 'videos', not both")
    if "videos" in document:
        videos = document["videos"]
        if not isinstance(videos, dict) or not videos:
            raise ValueError("'videos' must be a non-empty object keyed by video id")
        if video_id not in videos:
            raise ValueError(f"batch voiceover script has no entry for video id {video_id!r}")
        document = videos[video_id]
    if not isinstance(document, dict) or set(document) != {"lines"}:
        raise ValueError("each selected video must contain exactly 'lines'")
    lines = document["lines"]
    if not isinstance(lines, list) or not lines:
        raise ValueError("'lines' must be a non-empty array")
    result = []
    for index, line in enumerate(lines, 1):
        label = f"voiceover line {index}"
        if not isinstance(line, dict) or set(line) != {"text", "start", "end"}:
            raise ValueError(f"{label} must contain exactly text, start and end")
        text = line["text"]
        if not isinstance(text, str) or not text.strip():
            raise ValueError(f"{label} text must be a non-empty string")
        # One entire supplied line becomes one SRT cue; no word splitting or AI.
        if any(ord(char) < 32 for char in text):
            raise ValueError(f"{label} text must be one line without control characters")
        start = _number(line["start"], f"{label} start")
        end = _number(line["end"], f"{label} end")
        if start < 0 or end <= start or end > duration:
            raise ValueError(
                f"{label} has an out-of-bounds or empty interval: "
                f"require 0 <= start < end <= output duration ({duration:g}s)"
            )
        result.append({"line": index, "text": text.strip(), "start": start, "end": end})
    result.sort(key=lambda line: line["start"])
    for previous, current in zip(result, result[1:]):
        if current["start"] < previous["end"]:
            raise ValueError(
                f"voiceover lines {previous['line']} and {current['line']} overlap; "
                "declared windows must not overlap"
            )
    return result


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_text(data: dict) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n"


def _cache_identity(text: str, voice: str, rate: str, volume: str) -> tuple[str, dict]:
    config = {
        "version": CACHE_VERSION, "engine": "installed-edge-tts-cli", "provider": "edge",
        "text": text, "voice": voice, "rate": rate, "volume": volume,
        "pronunciation": "normal", "ai_features": False,
    }
    encoded = json.dumps(config, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest(), config


def _run(command: list[str], *, timeout: int = 1800) -> subprocess.CompletedProcess:
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError(f"voiceover command failed: {command[0]}: {exc}") from exc
    if result.returncode:
        # Never echo Edge CLI output: it can contain private script text.
        detail = "" if command[0] == sys.executable else f": {result.stderr[-1000:]}"
        raise RuntimeError(f"voiceover command failed ({command[0]}, exit {result.returncode}){detail}")
    return result


def _probe_audio(path: Path) -> dict:
    if not path.is_file() or not path.stat().st_size:
        raise ValueError(f"voiceover audio is missing or empty: {path}")
    result = _run([
        "ffprobe", "-v", "error", "-select_streams", "a", "-show_streams",
        "-show_format", "-of", "json", str(path),
    ], timeout=120)
    try:
        info = json.loads(result.stdout)
        streams = info.get("streams", [])
        if len(streams) != 1 or streams[0].get("codec_type") != "audio":
            raise ValueError("expected exactly one audio stream")
        duration = float(streams[0].get("duration", info.get("format", {}).get("duration", "nan")))
        if not math.isfinite(duration) or duration <= 0:
            raise ValueError("audio duration must be finite and positive")
    except (TypeError, KeyError, ValueError) as exc:
        raise ValueError(f"invalid voiceover audio probe: {path}: {exc}") from exc
    return {"stream": streams[0], "duration": duration}


def _decode_audio(path: Path, pcm_path: Path) -> dict:
    probe = _probe_audio(path)
    # A successful probe is not sufficient: decode the entire file and fail on
    # decoding errors. Decoded samples exclude MP3 encoder delay/padding.
    _run([
        "ffmpeg", "-nostdin", "-v", "error", "-xerror", "-err_detect", "explode", "-y",
        "-i", str(path), "-map", "0:a:0", "-vn", "-ar", str(SAMPLE_RATE),
        "-ac", str(CHANNELS), "-c:a", "pcm_s16le", "-f", "s16le", str(pcm_path),
    ])
    size = pcm_path.stat().st_size
    if size <= 0 or size % FRAME_BYTES:
        raise ValueError(f"voiceover audio has no complete decoded PCM frames: {path}")
    frames = size // FRAME_BYTES
    return {"frames": frames, "duration": frames / SAMPLE_RATE, "probe_duration": probe["duration"]}


def _synthesize(text: str, output: Path, *, voice: str, rate: str, volume: str) -> None:
    if not EDGE_TTS_SCRIPT.is_file():
        raise RuntimeError(f"installed Edge TTS CLI not found: {EDGE_TTS_SCRIPT}")
    with tempfile.TemporaryDirectory(prefix="edge-input-", dir=output.parent) as temp:
        root = Path(temp)
        source = root / "line.txt"
        source.write_text(text, encoding="utf-8")
        # An explicitly supplied empty keyword file suppresses the installed
        # CLI's otherwise automatic AI highlighting, even without --ass.
        no_keywords = root / "no-highlight.txt"
        no_keywords.write_text("# Explicitly disable automatic AI highlighting.\n", encoding="utf-8")
        _run([
            sys.executable, str(EDGE_TTS_SCRIPT), "--provider=edge", f"--file={source}",
            f"--output={output}", f"--voice={voice}", f"--rate={rate}", f"--volume={volume}",
            f"--highlight-keyword-file={no_keywords}", "--punctuation-mode=keep",
            "--pron-fix-mode=normal", "--no-chinese-confirm", "--no-subscribe-overlay",
            # Avoid automatic long-text splitting; the Edge engine still owns
            # its internal transport. No --semantic / --srt / --ass is passed.
            f"--max-chars={max(2000, len(text) + 1)}",
        ])
    # The installed CLI can exit zero after failed synthesis; validation by the
    # caller, not its exit status alone, determines whether audio is usable.


def _cached_line(line: dict, cache_dir: Path, work_dir: Path, config: dict) -> dict:
    key, identity = _cache_identity(line["text"], config["voice"], config["rate"], config["volume"])
    audio = cache_dir / f"{key}.mp3"
    metadata_path = cache_dir / f"{key}.json"
    pcm = work_dir / f"line-{line['line']:03d}.pcm"
    hit = False
    metadata = None
    if audio.is_file() and metadata_path.is_file():
        try:
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            if metadata["key"] != key or metadata["identity"] != identity:
                raise ValueError("cache identity mismatch")
            if metadata["audio_sha256"] != _sha256(audio):
                raise ValueError("cache audio hash mismatch")
            measured = _decode_audio(audio, pcm)
            hit = True
        except (OSError, ValueError, KeyError, TypeError, RuntimeError):
            # A corrupt/hash-mismatched/undecodable entry is never trusted.
            # The explicit script still authorizes regenerating this one line.
            metadata = None
    if not hit:
        candidate = work_dir / f"synthesis-{line['line']:03d}.mp3"
        _synthesize(line["text"], candidate, **{name: config[name] for name in ("voice", "rate", "volume")})
        measured = _decode_audio(candidate, pcm)
        metadata = {
            "key": key, "identity": identity, "audio_sha256": _sha256(candidate),
            "duration": measured["duration"], "probe_duration": measured["probe_duration"],
            "cli_path": str(EDGE_TTS_SCRIPT),
            "cli_sha256": _sha256(EDGE_TTS_SCRIPT) if EDGE_TTS_SCRIPT.is_file() else None,
            "privacy_note": PRIVACY_NOTE,
        }
        staged_metadata = work_dir / f"cache-{line['line']:03d}.json"
        staged_metadata.write_text(_json_text(metadata), encoding="utf-8")
        candidate.replace(audio)
        staged_metadata.replace(metadata_path)
    stable_name = f"voiceover_{line['line']:03d}.mp3"
    copied = work_dir / stable_name
    shutil.copyfile(audio, copied)
    if _sha256(copied) != metadata["audio_sha256"]:
        raise RuntimeError("voiceover audio changed while copying from cache; retry preparation")
    return {
        **line, **measured, "cache_key": key, "cache_hit": hit,
        "cache_path": str(audio), "audio_sha256": metadata["audio_sha256"],
        "cli_sha256": metadata.get("cli_sha256"), "audio_name": stable_name, "pcm_path": pcm,
    }


def _write_silence(handle, frames: int) -> None:
    block = b"\0" * (SAMPLE_RATE * FRAME_BYTES)
    remaining = frames * FRAME_BYTES
    while remaining > 0:
        count = min(remaining, len(block))
        handle.write(block[:count])
        remaining -= count


def _assemble(lines: list[dict], total_frames: int, work_dir: Path) -> Path:
    # Sequential on-disk PCM assembly keeps memory and command argument count
    # bounded regardless of script length; FFmpeg owns decoding and encoding.
    raw = work_dir / "timeline.pcm"
    cursor = 0
    with raw.open("wb") as destination:
        for line in lines:
            _write_silence(destination, line["start_frame"] - cursor)
            with line["pcm_path"].open("rb") as source:
                shutil.copyfileobj(source, destination, length=1024 * 1024)
            cursor = line["start_frame"] + line["frames"]
        _write_silence(destination, total_frames - cursor)
    audio = work_dir / "voiceover.wav"
    _run([
        "ffmpeg", "-nostdin", "-v", "error", "-y", "-f", "s16le", "-ar", str(SAMPLE_RATE),
        "-ac", str(CHANNELS), "-i", str(raw), "-c:a", "pcm_s16le", str(audio),
    ])
    probe = _probe_audio(audio)
    stream = probe["stream"]
    if stream.get("codec_name") != "pcm_s16le" or int(stream.get("sample_rate", 0)) != SAMPLE_RATE or stream.get("channels") != CHANNELS:
        raise ValueError("assembled voiceover must be stereo 48 kHz PCM s16le WAV")
    if abs(probe["duration"] - total_frames / SAMPLE_RATE) > 1 / SAMPLE_RATE:
        raise ValueError("assembled voiceover does not cover the full output duration")
    _run([
        "ffmpeg", "-nostdin", "-v", "error", "-xerror", "-err_detect", "explode",
        "-i", str(audio), "-map", "0:a:0", "-f", "null", "-",
    ])
    return audio


def _srt_time(milliseconds: int) -> str:
    seconds, millis = divmod(milliseconds, 1000)
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d},{millis:03d}"


def prepare_voiceover(
    script_path: Path, video_id: str, output_dir: Path, duration: float, *,
    voice: str = "zh-CN-YunxiNeural", rate: str = "+0%", volume: str = "+0%",
    duck_db: float = -12.0,
) -> dict:
    """Prepare a full output-timeline track, full-line SRT and auditable manifest.

    Return keys: audio_path, captions_path, manifest_path, intervals (start/end
    seconds on the output timeline), duck_db and duration. No source ducking is
    performed here. Invalid scripts are rejected before any cloud synthesis.
    """
    duration = _number(duration, "output duration")
    if duration <= 0:
        raise ValueError("output duration must be positive")
    sample_count = duration * SAMPLE_RATE
    if not math.isfinite(sample_count):
        raise ValueError("output duration is too large for a 48 kHz sample timeline")
    total_frames = round(sample_count)
    if total_frames <= 0:
        raise ValueError("output duration must cover at least one 48 kHz sample")
    duck_db = _number(duck_db, "duck_db")
    if duck_db > 0:
        raise ValueError("duck_db must be zero or negative (source attenuation in dB)")
    if not isinstance(voice, str) or not re.fullmatch(r"[A-Za-z0-9_-]+", voice):
        raise ValueError("voice must be a non-empty Edge voice identifier")
    for name, value in (("rate", rate), ("volume", volume)):
        if not isinstance(value, str) or not re.fullmatch(r"[+-]\d+%", value):
            raise ValueError(f"{name} must be a signed percentage such as +0% or -10%")
    lines = _load_lines(script_path, video_id, duration)
    for tool in ("ffprobe", "ffmpeg"):
        if not shutil.which(tool):
            raise RuntimeError(f"voiceover requires {tool} on PATH")
    output_dir = Path(output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    cache_dir = output_dir / ".voiceover_cache"
    cache_dir.mkdir(exist_ok=True)
    config = {"voice": voice, "rate": rate, "volume": volume, "duck_db": duck_db}
    with tempfile.TemporaryDirectory(prefix=".voiceover-work-", dir=output_dir) as temp:
        work_dir = Path(temp)
        prepared = []
        intervals = []
        cues = []
        for line in lines:
            row = _cached_line(line, cache_dir, work_dir, config)
            row["start_frame"] = round(line["start"] * SAMPLE_RATE)
            end_frame = row["start_frame"] + row["frames"]
            if (row["duration"] > line["end"] - line["start"] + 1e-9
                    or end_frame > math.floor(line["end"] * SAMPLE_RATE + 1e-8)
                    or end_frame > total_frames):
                raise ValueError(
                    f"voiceover line {line['line']} speech takes {row['duration']:.6f}s but "
                    f"window [{line['start']:g}, {line['end']:g}] allows "
                    f"{line['end'] - line['start']:.6f}s on the 48 kHz timeline. "
                    "Shorten the text, explicitly choose a faster rate, or widen/move "
                    "the window within output duration. Speech was not truncated or compressed."
                )
            row["placed_start"] = row["start_frame"] / SAMPLE_RATE
            row["speech_end"] = end_frame / SAMPLE_RATE
            # SRT has millisecond precision: round inward, never beyond speech
            # or the declared end. The audio/ducking timeline is sample-accurate.
            start_ms = math.ceil(row["placed_start"] * 1000 - 1e-8)
            end_ms = math.floor(row["speech_end"] * 1000 + 1e-8)
            if end_ms <= start_ms:
                raise ValueError(f"voiceover line {line['line']} is too short for a millisecond SRT cue")
            cues.append(f"{len(cues) + 1}\n{_srt_time(start_ms)} --> {_srt_time(end_ms)}\n{line['text']}\n\n")
            intervals.append({"start": row["placed_start"], "end": row["speech_end"]})
            prepared.append(row)
        audio = _assemble(prepared, total_frames, work_dir)
        captions = work_dir / "voiceover.srt"
        captions.write_text("".join(cues), encoding="utf-8")
        manifest_path = output_dir / "voiceover_manifest.json"
        result = {
            "audio_path": str(output_dir / audio.name),
            "captions_path": str(output_dir / captions.name),
            "manifest_path": str(manifest_path), "intervals": intervals,
            "duck_db": duck_db, "duration": total_frames / SAMPLE_RATE,
        }
        manifest = {
            "version": 1, "video_id": video_id,
            "script_path": str(Path(script_path).expanduser().resolve()),
            "script_sha256": _sha256(Path(script_path).expanduser()),
            "requested_duration": duration, "config": config,
            "engine": {"name": "edge-tts", "provider": "edge", "cli_path": str(EDGE_TTS_SCRIPT),
                       "invocation": "subprocess using sys.executable", "ai_features": False,
                       "privacy_note": PRIVACY_NOTE},
            "format": {"codec": "pcm_s16le", "sample_rate": SAMPLE_RATE, "channels": CHANNELS},
            "lines": [{**{key: value for key, value in row.items() if key != "pcm_path"},
                       "audio_path": str(output_dir / row["audio_name"])} for row in prepared],
            "audio_sha256": _sha256(audio), "captions_sha256": _sha256(captions), **result,
        }
        staged_manifest = work_dir / manifest_path.name
        staged_manifest.write_text(_json_text(manifest), encoding="utf-8")
        # Publish only after every line fits and the assembled track validates.
        for row in prepared:
            (work_dir / row["audio_name"]).replace(output_dir / row["audio_name"])
        audio.replace(Path(result["audio_path"]))
        captions.replace(Path(result["captions_path"]))
        staged_manifest.replace(manifest_path)
    return result
