# 验证

## 自动测试

```bash
cd "$HOME/.config/freebuff/skills/md2html-toc"
python3 -B -m black --config /dev/null scripts/md2html_toc.py tests/test_md2html.py
PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest discover -s tests
```

结果：**16 tests, OK**（Python 3.12.10；Python-Markdown 3.10.2；Bleach 6.4.0）。

覆盖范围（`tests/test_md2html.py`）：

- 默认清洗移除 `<script>`、`onclick`、`javascript:`；`--unsafe-raw-html` 保留原始 HTML。
- TOC ID 唯一、转义并包含标题层级（H1–H6）。
- 表格包裹、围栏代码类名、相对 `.md` 链接改写、外链 `target`/`rel`。
- front matter `title` 用作 `<title>` 且不渲染为正文。
- 递归布局；隐藏文件与符号链接被跳过。
- `--dry-run` 不产生输出或报告。
- 同 stem 碰撞在写任何文件前报错且不创建输出目录。
- 已有输出默认跳过（mtime 不变），`--overwrite` 覆盖。
- `--copy-assets` 内容哈希命名、限制在输入树内。
- 输入/输出重叠、符号链接输出失败关闭。
- 无效编码记为 `text_decode_failed`，报告不含正文。
- 原子输出失败时目标文件不出现。
- CLI `--help` 与真实子进程调用返回码 0。
- 目录条目/文件数上限与 `markdown_dependency_missing`。

## 端到端 smoke test

在一个临时目录中以真实 CLI 运行（递归 + `--copy-assets`），验证：

- `summary` 为 `{total: 2, success: 2, skipped: 0, failed: 0}`，`status` 为 `complete`。
- 输出树为 `guide/intro.html`、`guide/next.html`、`guide/assets/pic-<sha12>.png` 及两个报告。
- `data-md-toc="1"`、锚点 `#intro-draft`（原文含 `<draft>`）、`href="next.html#deep"`、
  外链 `target`/`rel`、`class="table-wrap"`、`<pre><code class="language-python">`。
- 安全模式输出不含 `<script`；`--unsafe-raw-html` 输出含增强脚本。
- 隐藏文件与符号链接未生成 HTML。
