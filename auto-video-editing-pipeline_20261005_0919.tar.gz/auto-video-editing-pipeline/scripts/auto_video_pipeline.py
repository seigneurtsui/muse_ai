#!/usr/bin/env python3
"""Batch local video editing orchestrator.

This script deliberately delegates STT, errata, script conversion, ASS styling,
and notifications to the mature installed skills. It owns only orchestration,
FFmpeg rendering, badge injection, state, and QA.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

try:
    from .srt_utils import retime_srt
except ImportError:  # direct CLI execution
    from srt_utils import retime_srt


ROOT = Path(__file__).resolve().parent.parent
SKILLS = Path.home() / ".config/omnirush/skills"
STT_ADAPTER = ROOT / "scripts/stt_adapter.py"
ERRATUM_ADAPTER = ROOT / "scripts/erratum_adapter.py"
ASS_SCRIPT = SKILLS / "srt-ass-studio/scripts/srt_ass.py"
S2T_SCRIPT = SKILLS / "s2t/scripts/chinese_converter_cli.py"
NOTIFY_SCRIPT = SKILLS / "multiple-channel-notifier/scripts/notify.py"
RENDER_SCRIPT = ROOT / "scripts/render_video.py"
QA_SCRIPT = ROOT / "scripts/qa_video.py"
BADGE_SCRIPT = ROOT / "scripts/inject_badge.py"
ERRATUM_DICTIONARY = SKILLS / "erratum-correction/assets/chinese_homophone_errors.json"
MEDIA_EXTENSIONS = {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v", ".ts", ".flv", ".wmv"}


class PipelineError(RuntimeError):
    pass


def now_slug() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M")


def safe_slug(value: str) -> str:
    value = re.sub(r"[^\w.-]+", "_", value, flags=re.UNICODE).strip("._")
    return value[:100] or "video_batch"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_json(command: list[str], *, cwd: Path | None = None, allow_failure: bool = False) -> tuple[int, dict | None, str, str]:
    completed = subprocess.run(command, cwd=str(cwd) if cwd else None, capture_output=True, text=True)
    data = None
    text = completed.stdout.strip()
    if text:
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            # Some delegated tools print progress before a pretty-printed JSON object.
            for start in (index for index, char in enumerate(text) if char == "{"):
                try:
                    data = json.loads(text[start:])
                    break
                except json.JSONDecodeError:
                    continue
            # Or print progress followed by a one-line JSON object.
            for line in reversed(text.splitlines()):
                if data is not None:
                    break
                try:
                    data = json.loads(line)
                    break
                except json.JSONDecodeError:
                    continue
    if completed.returncode and not allow_failure:
        detail = (completed.stderr or completed.stdout or "command failed")[-4000:]
        raise PipelineError(f"command failed ({completed.returncode}): {' '.join(command[:4])}\n{detail}")
    return completed.returncode, data, completed.stdout, completed.stderr


def probe(path: Path) -> dict:
    code, data, stdout, stderr = run_json(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)])
    if not data:
        raise PipelineError(f"ffprobe returned no JSON for {path}")
    return data


def collect_inputs(values: list[str], output_root: Path | None = None) -> list[Path]:
    found: dict[str, Path] = {}
    for value in values:
        path = Path(value).expanduser().resolve()
        if not path.exists():
            raise PipelineError(f"input does not exist: {path}")
        candidates = path.rglob("*") if path.is_dir() else [path]
        for candidate in candidates:
            if not candidate.is_file() or candidate.name.startswith(".") or candidate.suffix.lower() not in MEDIA_EXTENSIONS:
                continue
            if output_root and candidate.resolve() == output_root.resolve():
                continue
            found[str(candidate.resolve())] = candidate.resolve()
    if not found:
        raise PipelineError("no supported video files found")
    return sorted(found.values(), key=lambda item: str(item).casefold())


def video_id(path: Path) -> str:
    return f"{safe_slug(path.stem)}_{hashlib.sha256(str(path).encode()).hexdigest()[:10]}"


def resolution_for(record: dict, args: argparse.Namespace) -> tuple[int, int]:
    if args.width and args.height:
        return args.width, args.height
    if args.canvas == "vertical":
        return 1080, 1920
    if args.canvas == "landscape":
        return 1920, 1080
    if args.canvas == "square":
        return 1080, 1080
    stream = next((item for item in record["probe"].get("streams", []) if item.get("codec_type") == "video"), {})
    return int(stream.get("width", 1920)), int(stream.get("height", 1080))


def font_family_from_file(path: Path) -> str:
    """Resolve a font file to the family name libass/fontconfig should use."""
    path = path.expanduser().resolve()
    if not path.is_file():
        raise PipelineError(f"subtitle font file not found: {path}")
    try:
        completed = subprocess.run(
            ["fc-scan", "--format", "%{family}\n", str(path)],
            capture_output=True, text=True, check=True,
        )
        family = next((line.split(",", 1)[0].strip() for line in completed.stdout.splitlines() if line.strip()), "")
        if family:
            return family
    except (OSError, subprocess.CalledProcessError):
        pass
    try:
        from PIL import ImageFont
        return ImageFont.truetype(str(path), 24).getname()[0]
    except Exception as exc:
        raise PipelineError(f"cannot resolve subtitle font family: {path}") from exc


def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def save_state(batch: Path, state: dict) -> None:
    write_json(batch / "state.json", state)


def load_or_create_batch(args: argparse.Namespace) -> tuple[Path, dict]:
    if args.resume_batch:
        batch = args.resume_batch.expanduser().resolve()
        state_path = batch / "state.json"
        if not state_path.is_file():
            raise PipelineError("resume batch has no state.json")
        return batch, json.loads(state_path.read_text(encoding="utf-8"))
    output_root = args.out_root.expanduser().resolve()
    project = safe_slug(args.project or (Path(args.inputs[0]).stem if args.inputs else "video_batch"))
    batch = output_root / f"{now_slug()}_{project}"
    batch.mkdir(parents=True, exist_ok=False)
    sources = collect_inputs(args.inputs, batch)
    records = []
    for source in sources:
        record = {"id": video_id(source), "source": str(source), "source_sha256": sha256(source), "probe": probe(source), "stages": {}, "warnings": []}
        record["paths"] = {}
        records.append(record)
    state = {"version": 2, "created_at": datetime.now().isoformat(timespec="seconds"), "batch": str(batch), "options": vars(args).copy(), "videos": records, "erratum_job": None}
    # argparse Path values are not JSON serializable.
    state["options"] = {key: str(value) if isinstance(value, Path) else value for key, value in state["options"].items()}
    write_json(batch / "batch.json", state)
    save_state(batch, state)
    write_project_md(batch, state)
    return batch, state


def write_project_md(batch: Path, state: dict) -> None:
    lines = ["# Auto Video Editing Pipeline", "", f"批次：`{batch}`", f"创建时间：{state.get('created_at', '')}", "", "## 输入", ""]
    for item in state.get("videos", []):
        probe_data = item.get("probe", {})
        stream = next((s for s in probe_data.get("streams", []) if s.get("codec_type") == "video"), {})
        lines.append(f"- `{item['source']}` — {stream.get('width')}x{stream.get('height')} / {stream.get('avg_frame_rate')} / SHA-256 `{item['source_sha256']}`")
    lines += ["", "## 工作规则", "", "- 源视频 immutable。", "- STT：faster-whisper-stt，phrase-level / lower-confidence。", "- 字幕纠错：erratum-correction 当前会话模型 + 本批次专名白名单。", "- 字幕：s2t（明确字形冲突时）→ srt-ass-studio → badge → FFmpeg 最后烧录。", "- 交付前必须通过 preview/final decode、媒体规格、字幕时间轴和抽帧 QA。", ""]
    (batch / "project.md").write_text("\n".join(lines), encoding="utf-8")


def set_path(record: dict, key: str, path: Path) -> None:
    record.setdefault("paths", {})[key] = str(path)


def run_stt(batch: Path, state: dict, args: argparse.Namespace) -> None:
    pending = [item for item in state["videos"] if not Path(item.get("paths", {}).get("raw_srt", "")).is_file()]
    if not pending:
        return
    job_root = batch / "stt"
    report_path = job_root / "report.json"
    command = [sys.executable, str(STT_ADAPTER), "--job-root", str(job_root), "--report", str(report_path), "--model", args.model, "--language", args.language or "auto", "--chunk-duration", str(args.chunk_duration), "--resume"]
    for item in pending:
        command += ["--source", item["source"]]
    code, _, _, stderr = run_json(command, allow_failure=True)
    report = json.loads(report_path.read_text(encoding="utf-8")) if report_path.is_file() else {"results": []}
    by_source = {str(Path(row.get("source", "")).resolve()): row for row in report.get("results", [])}
    by_job = {Path(row.get("job_dir", "")).resolve().name: row for row in report.get("results", []) if row.get("job_dir")}
    for item in pending:
        # The mature STT merger may report its internal job placeholder as
        # `source`; the stable job directory is the authoritative identity.
        row = by_source.get(str(Path(item["source"]).resolve())) or by_job.get(item["id"])
        if not row or not row.get("success"):
            item["stages"]["stt"] = {"status": "failed", "error": row.get("error") if row else stderr[-1000:]}
            continue
        job_dir = Path(row["job_dir"])
        clean = job_dir / "subtitle_clean.srt"
        transcript = job_dir / "transcript_merged.txt"
        if not clean.is_file() or clean.stat().st_size == 0:
            item["stages"]["stt"] = {"status": "failed", "error": "subtitle_clean.srt missing or empty"}
            continue
        video_dir = batch / "videos" / item["id"]
        raw_srt = video_dir / "transcripts" / "subtitle_clean.srt"
        raw_txt = video_dir / "transcripts" / "transcript_merged.txt"
        raw_srt.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(clean, raw_srt)
        if transcript.is_file():
            shutil.copy2(transcript, raw_txt)
        set_path(item, "raw_srt", raw_srt)
        if transcript.is_file():
            set_path(item, "raw_txt", raw_txt)
        item["stt"] = {"engine": "faster-whisper-stt", "confidence": "lower-confidence phrase-level", "job_dir": str(job_dir)}
        item["stages"]["stt"] = {"status": "complete"}
    save_state(batch, state)


def copy_erratum_inputs(batch: Path, state: dict) -> tuple[Path, dict[str, str]]:
    input_dir = batch / "erratum" / "input"
    input_dir.mkdir(parents=True, exist_ok=True)
    mapping: dict[str, str] = {}
    for item in state["videos"]:
        raw = Path(item.get("paths", {}).get("raw_srt", ""))
        if not raw.is_file() or Path(item.get("paths", {}).get("corrected_srt", "")).is_file():
            continue
        name = f"{item['id']}.srt"
        destination = input_dir / name
        if not destination.is_file() or sha256(destination) != sha256(raw):
            shutil.copy2(raw, destination)
        mapping[name] = item["id"]
    write_json(batch / "erratum" / "map.json", mapping)
    return input_dir, mapping


def finish_erratum_outputs(batch: Path, state: dict, report: dict, mapping: dict[str, str]) -> None:
    for row in report.get("documents", []):
        if row.get("status") not in {"corrected", "local_only", "no_ai_needed"}:
            continue
        source_name = Path(row.get("source", "")).name
        item_id = mapping.get(source_name)
        output = Path(row.get("output", ""))
        if not item_id or not output.is_file():
            continue
        item = next((value for value in state["videos"] if value["id"] == item_id), None)
        if not item:
            continue
        destination = batch / "videos" / item_id / "corrections" / f"{item_id}_corrected.srt"
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(output, destination)
        set_path(item, "corrected_srt", destination)
        item["stages"]["erratum"] = {"status": row["status"], "job_dir": state.get("erratum_job")}


def run_erratum(batch: Path, state: dict, args: argparse.Namespace) -> int | None:
    input_dir, mapping = copy_erratum_inputs(batch, state)
    if not any(input_dir.glob("*.srt")):
        return None
    whitelist_path = args.whitelist_file.expanduser().resolve()
    if state.get("erratum_job"):
        command = [sys.executable, str(ERRATUM_ADAPTER), "--resume", state["erratum_job"], "--whitelist-file", str(whitelist_path), "--request-window", "4"]
    else:
        root = batch / "erratum" / "runs"
        command = [sys.executable, str(ERRATUM_ADAPTER), "--input", str(input_dir), "--output-root", str(root), "--whitelist-file", str(whitelist_path), "--homophone-json", str(ERRATUM_DICTIONARY), "--request-window", "4"]
        if args.no_ai_correct:
            command.append("--no-ai")
    code, data, stdout, stderr = run_json(command, allow_failure=True)
    if data and data.get("job_dir"):
        state["erratum_job"] = data["job_dir"]
    save_state(batch, state)
    if code == 10 or (data and data.get("status") == "awaiting_ai"):
        print(json.dumps({"status": "awaiting_ai", "job_dir": state.get("erratum_job"), "pending_requests": data.get("pending_requests", []) if data else []}, ensure_ascii=False, indent=2))
        return 10
    if code not in (0, 1) or not data:
        raise PipelineError(stderr[-4000:] or stdout[-4000:] or "erratum-correction failed")
    finish_erratum_outputs(batch, state, data, mapping)
    failed = sum(row.get("status") in {"failed", "invalid_ai_response"} for row in data.get("documents", []))
    save_state(batch, state)
    if failed:
        print(json.dumps({"status": "erratum_failed", "failed": failed, "report": data.get("report_path")}, ensure_ascii=False))
    return None


def maybe_convert_s2t(item: dict, batch: Path, args: argparse.Namespace) -> Path:
    corrected = Path(item["paths"]["corrected_srt"])
    target = args.subtitle_lang
    source_script = args.source_script
    mode = None
    if target == "zh-Hant" and source_script == "zh-Hans":
        mode = "s2t"
    elif target in {"zh-Hans", "zh"} and source_script == "zh-Hant":
        mode = "t2s"
    if not mode:
        return corrected
    output_root = batch / "videos" / item["id"] / "s2t"
    command = [sys.executable, str(S2T_SCRIPT), "-m", mode, "-i", str(corrected), "-o", str(output_root), "--engine", "auto", "--output-encoding", "utf-8"]
    code, data, stdout, stderr = run_json(command, allow_failure=True)
    if code != 0:
        raise PipelineError(stderr[-2000:] or stdout[-2000:] or "s2t conversion failed")
    converted = sorted(output_root.rglob("*_converted.srt"))
    if len(converted) != 1:
        raise PipelineError("s2t completed without exactly one converted SRT")
    item["stages"]["s2t"] = {"status": "complete", "mode": mode, "report": data}
    return converted[0]


def ass_for(item: dict, batch: Path, args: argparse.Namespace, srt: Path, width: int, height: int) -> Path:
    output_root = batch / "videos" / item["id"] / "ass_runs" / str(time.time_ns())
    command = [sys.executable, str(ASS_SCRIPT), str(srt), "--output-root", str(output_root), "--preset", args.preset, "--workers", "1", "--width", str(width), "--height", str(height)]
    language = str(args.subtitle_lang).lower()
    if language.startswith("zh"):
        font_name = args.subtitle_font_name or font_family_from_file(args.subtitle_font_file)
        command += ["--font-name", font_name, "--font-size", str(args.subtitle_font_size)]
    elif args.subtitle_font_name:
        command += ["--font-name", args.subtitle_font_name, "--font-size", str(args.subtitle_font_size)]
    if args.effect:
        command += ["--effect", args.effect]
    if args.position:
        command += ["--position", args.position]
    if args.languages:
        command += ["--languages", args.languages]
    if args.separate_languages:
        command += ["--separate-languages", args.separate_languages]
    if args.source_script != "auto":
        command += ["--source-language", args.source_script]
    for term in args.highlight:
        command += ["--highlight", term]
    if args.highlight:
        highlight_font = args.highlight_font_name
        if args.highlight_font_file:
            highlight_font = font_family_from_file(args.highlight_font_file)
        if highlight_font:
            command += ["--highlight-font", highlight_font]
        if args.highlight_color:
            command += ["--highlight-color", args.highlight_color]
        if args.highlight_size:
            scale = args.highlight_size / args.subtitle_font_size
            if not 1 <= scale <= 2:
                raise PipelineError("highlight size must be between 1x and 2x the main subtitle size for srt-ass-studio")
            command += ["--highlight-scale", f"{scale:.6f}"]
    code, data, stdout, stderr = run_json(command, allow_failure=True)
    if code != 0:
        raise PipelineError(stderr[-3000:] or stdout[-3000:] or "srt-ass-studio failed")
    candidates = sorted(output_root.rglob("*.ass"))
    if len(candidates) != 1:
        raise PipelineError("srt-ass-studio did not produce exactly one ASS file")
    destination = batch / "videos" / item["id"] / "subtitles" / f"{item['id']}.ass"
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(candidates[0], destination)
    item["stages"]["ass"] = {"status": "complete", "report": data}
    return destination


def badge_for(item: dict, args: argparse.Namespace, ass: Path, duration: float) -> Path:
    if not args.badge_text:
        return ass
    start = args.badge_start
    end = min(args.badge_end, duration)
    if end <= start:
        raise PipelineError("badge lies outside the final output timeline")
    destination = ass.with_name(ass.stem + "_badge.ass")
    badge_font = args.badge_font_name or args.badge_font
    if args.badge_font_file:
        badge_font = font_family_from_file(args.badge_font_file)
    command = [sys.executable, str(BADGE_SCRIPT), "--input", str(ass), "--output", str(destination), "--text", args.badge_text, "--start", str(start), "--end", str(end), "--position", args.badge_position, "--font", badge_font, "--size", str(args.badge_size), "--color", args.badge_color, "--outline-color", args.badge_outline_color, "--back-color", args.badge_back_color, "--outline", str(args.badge_outline), "--shadow", str(args.badge_shadow), "--anim", args.badge_anim, "--fade-in-ms", str(args.badge_fade_in_ms), "--fade-out-ms", str(args.badge_fade_out_ms)]
    code, _, stdout, stderr = run_json(command, allow_failure=True)
    if code != 0 or not destination.is_file():
        raise PipelineError(stderr[-2000:] or stdout[-2000:] or "badge injection failed")
    item.setdefault("badges", []).append({"text": args.badge_text, "start": start, "end": end, "position": args.badge_position, "duration": end - start})
    return destination


def render_and_qa(item: dict, batch: Path, args: argparse.Namespace, srt: Path, ass: Path, width: int, height: int) -> None:
    video_dir = batch / "videos" / item["id"]
    duration = float(item["probe"].get("format", {}).get("duration") or 0)
    output_duration = ((args.trim_end if args.trim_end is not None else duration) - args.trim_start) / args.speed
    if args.preview:
        preview = video_dir / "preview.mp4"
        command = [sys.executable, str(RENDER_SCRIPT), "--source", item["source"], "--subtitle", str(ass), "--output", str(preview), "--width", str(width), "--height", str(height), "--fps", str(args.fps), "--speed", str(args.speed), "--trim-start", str(args.trim_start), "--crf", str(args.crf), "--preset", args.video_preset, "--preview"]
        if args.trim_end is not None:
            command += ["--trim-end", str(args.trim_end)]
        if args.loudnorm:
            command.append("--loudnorm")
        code, _, stdout, stderr = run_json(command, allow_failure=True)
        if code != 0:
            raise PipelineError(stderr[-3000:] or stdout[-3000:] or "preview render failed")
        qa_dir = video_dir / "qa" / "preview"
        qa_command = [sys.executable, str(QA_SCRIPT), "--video", str(preview), "--output", str(qa_dir), "--srt", str(srt), "--ass", str(ass), "--fps", str(args.fps)]
        qa_command += ["--width", str(max(2, round(width * min(1.0, 720 / max(width, height))) // 2 * 2)), "--height", str(max(2, round(height * min(1.0, 720 / max(width, height))) // 2 * 2))]
        qcode, qdata, qstdout, qstderr = run_json(qa_command, allow_failure=True)
        item["stages"]["preview_qa"] = {"status": "complete" if qcode == 0 else "failed", "report": qdata}
        if qcode != 0:
            raise PipelineError(qstderr[-2000:] or "preview QA failed")
    final = video_dir / "final.mp4"
    command = [sys.executable, str(RENDER_SCRIPT), "--source", item["source"], "--subtitle", str(ass), "--output", str(final), "--width", str(width), "--height", str(height), "--fps", str(args.fps), "--speed", str(args.speed), "--trim-start", str(args.trim_start), "--crf", str(args.crf), "--preset", args.video_preset]
    if args.trim_end is not None:
        command += ["--trim-end", str(args.trim_end)]
    if args.loudnorm:
        command.append("--loudnorm")
    code, _, stdout, stderr = run_json(command, allow_failure=True)
    if code != 0:
        raise PipelineError(stderr[-3000:] or stdout[-3000:] or "final render failed")
    qa_dir = video_dir / "qa" / "final"
    qa_command = [sys.executable, str(QA_SCRIPT), "--video", str(final), "--output", str(qa_dir), "--srt", str(srt), "--ass", str(ass), "--width", str(width), "--height", str(height), "--fps", str(args.fps)]
    qcode, qdata, qstdout, qstderr = run_json(qa_command, allow_failure=True)
    item["stages"]["final_qa"] = {"status": "complete" if qcode == 0 else "failed", "report": qdata}
    set_path(item, "final", final)
    if qcode != 0:
        raise PipelineError(qstderr[-2000:] or "final QA failed")


def process_videos(batch: Path, state: dict, args: argparse.Namespace) -> None:
    for item in state["videos"]:
        if item.get("stages", {}).get("final_qa", {}).get("status") == "complete" and (args.resume or args.resume_batch) and not args.force_render:
            continue
        raw = Path(item.get("paths", {}).get("raw_srt", ""))
        corrected = Path(item.get("paths", {}).get("corrected_srt", ""))
        if not raw.is_file() or not corrected.is_file():
            item["stages"]["edit"] = {"status": "failed", "error": "STT or correction output missing"}
            continue
        try:
            video_dir = batch / "videos" / item["id"]
            width, height = resolution_for(item, args)
            source_srt = maybe_convert_s2t(item, batch, args)
            timed_srt = video_dir / "subtitles" / f"{item['id']}_timeline.srt"
            timing = retime_srt(source_srt, timed_srt, speed=args.speed, trim_start=args.trim_start, trim_end=args.trim_end)
            set_path(item, "timeline_srt", timed_srt)
            item["timing"] = timing
            ass = ass_for(item, batch, args, timed_srt, width, height)
            final_duration = timing["output_duration"]
            ass = badge_for(item, args, ass, final_duration)
            set_path(item, "ass", ass)
            if args.stop_for_review and not args.approve_review:
                review = video_dir / "review.md"
                review.write_text(f"# 审核包\n\n- 源文件：`{item['source']}`\n- 字幕事件：{timing['output_cues']}\n- 输出画布：{width}x{height}\n- 速度：{args.speed}x\n- ASS：`{ass}`\n\n请检查字幕、badge、裁切和样式；确认后用 `--resume-batch {batch}` 加 `--approve-review` 继续。\n", encoding="utf-8")
                item["stages"]["edit"] = {"status": "awaiting_review", "review": str(review)}
                continue
            render_and_qa(item, batch, args, timed_srt, ass, width, height)
            item["stages"]["edit"] = {"status": "complete"}
        except Exception as exc:
            item["stages"]["edit"] = {"status": "failed", "error": str(exc)}
        save_state(batch, state)


def notify(batch: Path, state: dict, args: argparse.Namespace) -> dict:
    if not (args.notify_channels or args.notify_all):
        return {"status": "disabled"}
    succeeded = sum(item.get("stages", {}).get("edit", {}).get("status") == "complete" for item in state["videos"])
    failed = len(state["videos"]) - succeeded
    success = failed == 0
    if args.notify_when == "success" and not success:
        return {"status": "skipped"}
    if args.notify_when == "failure" and success:
        return {"status": "skipped"}
    command = [sys.executable, str(NOTIFY_SCRIPT), "send", "--title", "视频批处理结果", "--content", f"视频批处理结束：共 {len(state['videos'])} 个，成功 {succeeded} 个，失败 {failed} 个。"]
    if args.notify_channels:
        command += ["--channels", args.notify_channels]
    check_code, check_data, _, check_err = run_json(command + ["--dry-run"], allow_failure=True)
    if check_code != 0 or not check_data or check_data.get("status") not in {"dry_run", "disabled"}:
        return {"status": "failed", "message": "notifier preflight failed"}
    if args.notify_dry_run:
        return {"status": "dry_run"}
    send_code, send_data, _, send_err = run_json(command, allow_failure=True)
    return {"status": "accepted" if send_code == 0 and send_data else "failed", "accepted": send_data.get("accepted", 0) if send_data else 0}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("inputs", nargs="*", help="视频文件、多个视频文件或目录")
    parser.add_argument("--out-root", type=Path, default=Path.home() / "Downloads/auto_video_editing_pipeline")
    parser.add_argument("--project")
    parser.add_argument("--resume-batch", type=Path)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--language")
    parser.add_argument("--model", default=str(Path.home() / "lavoro/translate/whisper/models/faster-whisper-large-v3-turbo-int8"))
    parser.add_argument("--chunk-duration", type=int, default=900)
    parser.add_argument("--whitelist-file", type=Path, default=ROOT / "ai_whitelist.txt")
    parser.add_argument("--no-ai-correct", action="store_true")
    parser.add_argument("--subtitle-lang", default="zh-Hans")
    parser.add_argument("--source-script", choices=("auto", "zh-Hans", "zh-Hant"), default="zh-Hans")
    parser.add_argument("--preset", default="cinematic")
    parser.add_argument("--effect")
    parser.add_argument("--position", choices=("bottom", "top", "center"))
    parser.add_argument("--highlight", action="append", default=[])
    parser.add_argument("--languages", help="显式启用 srt-ass-studio 翻译，如 source,en")
    parser.add_argument("--separate-languages")
    parser.add_argument("--canvas", choices=("auto", "vertical", "landscape", "square"), default="auto")
    parser.add_argument("--width", type=int)
    parser.add_argument("--height", type=int)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--speed", type=float, default=1.0)
    parser.add_argument("--trim-start", type=float, default=0.0)
    parser.add_argument("--trim-end", type=float)
    parser.add_argument("--crf", type=int, default=18)
    parser.add_argument("--video-preset", default="medium")
    parser.add_argument("--loudnorm", action="store_true")
    parser.add_argument("--preview", action="store_true")
    parser.add_argument("--force-render", action="store_true", help="重新生成 ASS、成片和 QA，复用已有 STT/勘误结果")
    parser.add_argument("--stop-for-review", action="store_true")
    parser.add_argument("--approve-review", action="store_true")
    parser.add_argument("--badge-text")
    parser.add_argument("--badge-start", type=float, default=0.4)
    parser.add_argument("--badge-end", type=float, default=2.0)
    parser.add_argument("--badge-position", choices=sorted({"top-left", "top-center", "top-right", "center-left", "center", "center-right", "bottom-left", "bottom-center", "bottom-right"}), default="top-center")
    parser.add_argument("--badge-font", default="Noto Sans CJK SC")
    parser.add_argument("--badge-font-file", type=Path, help="badge 字体文件；自动解析为字体族名")
    parser.add_argument("--badge-font-name", help="直接指定 badge 字体族名")
    parser.add_argument("--badge-size", type=int, default=72)
    parser.add_argument("--badge-color", default="FFFFFF")
    parser.add_argument("--badge-outline-color", default="151515")
    parser.add_argument("--badge-back-color", default="80000000")
    parser.add_argument("--badge-outline", type=int, default=3)
    parser.add_argument("--badge-shadow", type=int, default=1)
    parser.add_argument("--badge-anim", choices=("none", "fade", "pop", "zoom", "fly"), default="none")
    parser.add_argument("--badge-fade-in-ms", type=int, default=120)
    parser.add_argument("--badge-fade-out-ms", type=int, default=250)
    parser.add_argument("--subtitle-font-size", type=int, default=200, help="中文主字幕字号；默认 200")
    parser.add_argument("--subtitle-font-name", help="字幕字体族名；优先于 --subtitle-font-file")
    parser.add_argument("--subtitle-font-file", type=Path, default=Path.home() / "Library/Fonts/字魂龙腾楷书.ttf", help="中文主字幕字体文件")
    parser.add_argument("--highlight-font-file", type=Path, help="highlight keyword 字体文件；自动解析为字体族名")
    parser.add_argument("--highlight-font-name", help="直接指定 highlight keyword 字体族名")
    parser.add_argument("--highlight-size", type=int, help="highlight keyword 独立字号")
    parser.add_argument("--highlight-color", help="highlight keyword 独立颜色，如 FFD166")
    notify_group = parser.add_mutually_exclusive_group()
    notify_group.add_argument("--notify-channels")
    notify_group.add_argument("--notify-all", action="store_true")
    parser.add_argument("--notify-when", choices=("always", "success", "failure"), default="always")
    parser.add_argument("--notify-dry-run", action="store_true")
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    if args.resume_batch is None and not args.inputs:
        raise SystemExit("provide inputs or --resume-batch")
    if not args.whitelist_file.expanduser().is_file():
        raise SystemExit(f"whitelist file not found: {args.whitelist_file}")
    if args.speed <= 0 or args.trim_start < 0 or (args.trim_end is not None and args.trim_end <= args.trim_start):
        raise SystemExit("invalid speed or trim range")
    if args.dry_run:
        sources = collect_inputs(args.inputs, args.out_root)
        plan = []
        for source in sources:
            media = probe(source)
            stream = next((s for s in media.get("streams", []) if s.get("codec_type") == "video"), {})
            plan.append({"source": str(source), "duration": media.get("format", {}).get("duration"), "resolution": [stream.get("width"), stream.get("height")], "fps": stream.get("avg_frame_rate"), "bytes": source.stat().st_size})
        print(json.dumps({"status": "dry_run", "total": len(plan), "files": plan, "delegates": {"stt": str(STT_ADAPTER), "erratum": str(ERRATUM_ADAPTER), "s2t": str(S2T_SCRIPT), "ass": str(ASS_SCRIPT), "notifier": str(NOTIFY_SCRIPT)}}, ensure_ascii=False, indent=2))
        return 0
    batch, state = load_or_create_batch(args)
    state["options"] = {
        key: str(value) if isinstance(value, Path) else value
        for key, value in vars(args).items()
    }
    save_state(batch, state)
    # A resume command may intentionally approve a previous review gate.
    if args.approve_review:
        for item in state["videos"]:
            if item.get("stages", {}).get("edit", {}).get("status") == "awaiting_review":
                item["stages"]["edit"]["review_approved"] = True
    run_stt(batch, state, args)
    erratum_code = run_erratum(batch, state, args)
    if erratum_code == 10:
        return 10
    process_videos(batch, state, args)
    state["notification"] = notify(batch, state, args)
    succeeded = sum(item.get("stages", {}).get("edit", {}).get("status") == "complete" for item in state["videos"])
    failed = len(state["videos"]) - succeeded
    state["status"] = "complete" if failed == 0 else "partial_failure"
    state["summary"] = {"total": len(state["videos"]), "succeeded": succeeded, "failed": failed}
    save_state(batch, state)
    write_json(batch / "batch_report.json", state)
    print(json.dumps({"status": state["status"], "batch": str(batch), "summary": state["summary"], "notification": state.get("notification")}, ensure_ascii=False, indent=2))
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except PipelineError as exc:
        print(json.dumps({"status": "error", "message": str(exc)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(2)
