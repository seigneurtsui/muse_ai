# 适配与验证记录

## 私有经验积累与受控发布（当前）

新增 `scripts/learning_store.py`、`scripts/learn_dictionary.py`、`scripts/dictionary_releases.py` 及对应学习/发布回归测试，纠错入口增加 `--learn / --no-learn / --learning-store`。普通未开启学习的运行方式和当前模型协议不变。

**150 项测试通过，0 失败，0 跳过。** 其中原单源词表版本的 90 项仍通过。覆盖候选提取、完整成品/响应/回执核验、输入和报告篡改拒绝、内容去重、局部词表反馈排除、敏感/数量/教学语境过滤、明确审核与修订校验、冲突、隐私默认、分页、续跑继承/禁用、审核后新增证据失效、批准后暂存、发布计划/目标哈希绑定、合作锁、部分写入/恢复、精确字节回退、候选账本失败重试，以及终态重试不撤销后来的人工复核。

本机检查命令：

```bash
cd ~/.config/omnirush/skills/erratum-correction
python3 -B -m unittest discover -s tests -v
python3 -B scripts/build_dictionary.py --check
python3 -B scripts/learn_dictionary.py --help
```

日志 `/tmp/erratum-learning-tests.log`；构建检查 `/tmp/erratum-learning-build-check.json` 返回 `up_to_date`。13 个 Python 源/测试文件用 `compile()` 和 `ast.parse(feature_version=(3,10))` 通过编译及 Python 3.10 语法检查，交付目录无 `.pyc`。真实环境是 macOS x86_64 / Python 3.12.10 / OpenCC 1.4.1；不宣称其他 OS 或 Python 3.10 解释器实测。全套测试中的模型回答为机械合成 fixture，不是真正模型推理。

另进行了真正的当前会话模型合成验证：先由真实 CLI 生成两份请求，本会话逐项回答 `数据统记→数据统计` 与 `數據統記→數據統計`，保持原字形和换行；续跑继承 `--learn`。结果 2 篇完成、1 个 pending 候选、1 份内容证据、1 份重复内容被合并，自动批准数为 0。随后仅对临时副本使用明确标注的测试审核，真实 CLI 完成 stage→publish→release-status→rollback，确认新规则有简繁运行形式、回退后三个文件字节完全还原，重复采集不增加证据也不自动恢复被拒绝条目。**模拟审核不是用户批准真实词条，本技能正式源、运行表和构建报告均未被测试发布修改。**

现场证据：
`/private/var/folders/7v/zvv6rv994qq1fhy6yn2sdkb40000gn/T/erratum-learning-smoke-l8rdmw4k/verification.json`

OmniRush 1.0.15 原生加载器再次识别 `erratum-correction`，诊断为空。原 `/tmp/erratum_correction/` 三份输入、归档原表及正式词表三产物的哈希再次核验未变。没有读取或修改 `.env`，没有扫描私人历史目录、处理真实用户文档、安装依赖、调用外部模型、发通知或上传内容。

操作/隐私/界限见 [learning.md](learning.md)。发布是三个各自原子并落盘的写入，**不是跨文件事务**；恢复只接受已知前/后字节，未知改动拒绝覆盖。锁是合作锁，不能消除不遵守锁的其他进程在最终检查后的竞态。回退只保证原字节，不保证文件元数据还原。候选过滤不是完整隐私脱敏或语言正确性证明；审批标记不是独立身份认证。

**没有为本扩展重新取得清洁安全扫描结论；首版 SkillSpector 的 98/100 CRITICAL / DO_NOT_INSTALL / partial 原始发现和人工 CAUTION 意见继续保留在下文，功能通过不等于扫描通过。**

## 词表单源化更新（上一版）

人工维护改为 `assets/chinese_homophone_errors.source.json`，构建器 `scripts/build_dictionary.py` 使用已安装的 OpenCC 生成原路径的运行 JSON。未把整篇文档转换为简体再转回繁体，普通勘误仍不依赖 OpenCC。

- 原表合并为 399 个不同简体规则；清理 133 个无效果同值项。
- 新增 60 个词组级候选；101 个上下文歧义/合法用法/误切词边界的旧规则移入 `_review_only`，原件另存，不自动执行旧建议。
- 启用源规则 358 条：340 条可静态展开为 **601 条简繁匹配**；18 条原串同形但简繁目标不同，只作为当前会话 AI 的候选，不猜测或覆盖同名键。
- 运行表 22,526 字节；此次生成无未解决冲突、无转换后同值的繁体错误、无需审批的往返差异。

**当时 90 项测试通过，0 失败，0 跳过**（原 64 项加 26 项词表/兼容性测试）；语法编译及 Python 3.10 语法解析通过。新增检查涵盖生成稳定性、简繁去重、目标冲突、转换消错、往返审批指纹、循环/级联、停用规则、只读检查/安全写入、误把维护源当运行表的拒绝，以及全部 601 条运行规则的匹配结果与目标不再被修改。

`python3 -B scripts/build_dictionary.py --check` 实测 `up_to_date`，环境为 macOS Python 3.12.10、OpenCC 1.4.1。`python -S` 的真实子进程还验证了没有第三方 site-packages 的勘误运行；OpenCC 仅构建时需要。未声称其他 OS 或 OpenCC 发行包的实机验证。

当前会话另实际完成两篇合成简/繁文档：本地修正 `按步就班→按部就班`，AI 根据语境分别选择 `全神贯注` 和 `全神貫注`；`独创技术/獨創技術` 不再被误改。2 篇完成、4 个 AI 检查片段、2 个 AI 修改片段、2 处本地替换，原文哈希、繁体 CRLF 和输出字节均核验。现场为：
`/private/var/folders/7v/zvv6rv994qq1fhy6yn2sdkb40000gn/T/erratum-dict-v2-7v8wtlb6/verification.json`。

原先的三篇合成批次也真实恢复成功，保持原词表快照及成品修改时间；回归测试另外覆盖了更换词表后未完成旧批次继续使用自身快照。固定 AI 提示和协议未改，未切换模型、读取 `.env` 或处理用户真实文档。

详见 `dictionary.md`、`dictionary-migration.json` 与 `dictionary-build.json`。日志：`/tmp/erratum-dictionary-all-tests.log`。**以下保留首版安装记录；首版的安全扫描警告不是本次更新已通过安全扫描的证明，此次没有宣称取得清洁扫描认证。**

## 原项目保留和替换范围（首版历史）

来源 `/tmp/erratum_correction/` 的三个文件未修改。原始 SHA-256 位于 `source-hashes.json`；原脚本只做源码/AST 检查，未执行，没有复制其 provider 配置。
首次安装时 `assets/chinese_homophone_errors.json` 与提供的原词表逐字节一致；本次更新已将这份原件原样归档为 `references/legacy-dictionary.json`。原件有 534 个唯一键，400 条有效替换、133 条不生效的同值映射、1 条元数据，没有重复/冲突键；当前运行表数量见上文。

复用的主体行为：

- `HomophoneCorrector` 按原 JSON 顺序进行 `count` / `replace`，记录逐条命中次数，忽略 `_` 元数据和自映射；不擅自重排为最长匹配或同时替换。
- `TextSegment` 的区间提取和回填机制，文本/Markdown/字幕各自提取正文。
- 先词表、后 AI；只送含中文的正文片段，按字符预算合并；保留 `--no-ai`。
- `SequenceMatcher(..., autojunk=False)` 的普通长度精细差异和原有 `error_terms` 字段、修改前后及字符位置。
- 原入口文件名、主要 CLI 参数、默认输出根目录、`_corrected` 文件名、JSON/TXT 报告。

替换和修复：

- `_call_one_provider` 现在位于 `scripts/current_session_ai.py`，只委托 `CurrentSessionAI.request()`；没有外部服务商、API Key、HTTP 客户端或 TLS 降级，也不启动另一个 OmniRush 模型进程。
- 缺响应是 `awaiting_ai`，不能像原 `(all-failed)` 分支一样把 Step 1 副本统计为 AI 检查完成。
- 精确 JSON ID/数量/顺序校验取代宽松的 `[序号] 文本` 解析，不会因缺号、错序或 `.strip()` 丢失内容。
- SRT/VTT 结构解析不再把任意纯数字和包含箭头的台词跳过。ASS/SSA 读取 Events Format，保护绘图及转义。保守格式支持边界见 `formats.md`。
- 文件按字节解码/编码，保留 BOM、CRLF/LF/CR、空行和首尾空白。默认同编码写入；无法表示新字符时明确失败。
- 输出保留目录层次，避免不同目录同名文件覆盖；批次名含秒及随机标识，避免同分钟重跑覆盖。
- 预检、输入哈希、快照、锁、输出写入意图、独占原子发布、完成记录和报告错误状态防止不确定操作被伪装成完成。

文件 I/O/编码惯例参考了已安装 `s2t` 的实现，但新技能自带独立模块，运行不依赖其他技能路径。

## 当前会话模型接入

Python 不具有一个能自动绑定当前前台模型的隐式私有 API。为保证使用当前会话，而非新 CLI 的默认模型，采用原有 ebook 技能已使用的本地交接模式：

`准备局部候选 → 请求 JSON → 当前 OmniRush 会话读取并生成响应 → 验证并恢复 → 发布成品`

请求 ID 绑定协议、固定校对指令、来源快照和片段。请求及响应只落在本批次私有工作区，不通过命令行参数传递正文，不读取认证文件或 `.env`。
已验证请求按连续进度接受并缓存，后续恢复不重新解析旧的原始响应或重新要求模型回答；最终回填时重新校验接受记录。已完成输出需哈希一致才可复用，不重写文件。

本地文件协议不能独立证明填写者身份。自动化单元测试使用明确标注的合成 provider stub；下面单独记录真正由当前会话模型生成的验证，不把 stub 测试当真实 AI 调用。

## 实际自动化检查

环境：macOS x86_64，Python 3.12.10，标准库，无新增安装依赖。

```bash
cd ~/.config/omnirush/skills/erratum-correction
python3 -m unittest discover -s tests -v
python3 -m py_compile scripts/*.py tests/*.py
```

**64 项测试通过，0 失败，0 跳过。** 所有脚本和测试通过 Python 3.10 语法解析；没有声称在 Python 3.10 解释器或其他操作系统实机跑过全套。

其中 34 项文档核心测试覆盖严格结构解析、替换约束、词表顺序/级联、重复 JSON 键、随机格式保持、10000 片段回填、精细差异界限。30 项集成测试覆盖：

- 单文件/目录、递归和同名布局、隐藏项、嵌套输出、源/响应链接拒绝。
- 真 CLI 子进程的本地模式；当前会话协议的模拟答案，不是真正外部 AI。
- 请求缺失/无效/改正、错序/缺号/数字改动拒绝、乱序到达、长行片段复原。
- 本地规则误改时 AI 可依据原文撤销；无中文不虚报 AI 检查次数。
- 接受记录缓存、响应文件不再存在时恢复、成品幂等复用、源/快照/成品篡改检测。
- 输出完成但回执失败后的按意图恢复、已有文件/锁不被删除、原子写失败清理。
- 整批预检、缺词表/编码/预算失败、UTF-16 字幕与 BOM、Big5、不可表示字符。
- 报告失败仍保留实际完成结果；长行使用明确标记的有界变更范围。
- 快照中的 BOM 只能选择明确支持的四种值，不允许任意十六进制数据成为输出前缀。

日志：`/tmp/erratum-tests.log`。

## 当前模型真实合成验证

输入仅为 `assets/demo.txt`、`assets/demo.md`、`assets/demo.srt` 三份合成材料，未处理其他用户文档。
先实际运行入口，得到退出 10 和三个请求。本会话读取完整请求，并使用当前模型逐项生成三个响应 JSON；没有外部 AI/API、另一 CLI 会话或规则函数代填此次模型答案。

再次 `--resume` 后：

- **3 篇完成，0 失败，0 待处理请求。**
- 10 个 AI 检查片段，5 个 AI 修改片段，2 处词表替换。
- 词表：`神农家 → 神农架`。
- 当前模型按上下文：`财物报表 → 财务报表`、`盈利壮况 → 盈利状况`、合同语境中的 `检察 → 检查`。
- 保留 TXT 开头两个空格；SRT 时间轴、CRLF 数量、`123` 和箭头台词均核验。
- Markdown 可见链接标签完成本地纠错，URL 中的原字保留，代码块未改。
- 源文件和输出读回的 SHA-256 均核对；再恢复一次，没有重写成品，修改时间保持不变。

现场：
`/private/tmp/erratum-verification.lELGT9/20261003_203541_0cdca5627c/`

摘要证据：`/tmp/erratum-verification.lELGT9/evidence.json`。

## 性能和明确限制

改进基于算法/流程而非未经测量的速度倍数：回填改为前向 join，避免原来逐段复制整个文档；已接受 AI 请求持久化复用，恢复不重新请求；长行有界分片，有上下文；过大差异不进入无界二次复杂度比较，而明确报告合并变更范围。

未执行跨机器吞吐基准，不能宣称具体加速倍数。中文识别保留原 U+4E00–U+9FFF 规则；仅包含罕见扩展区汉字的片段可能不送 AI。片段过长时 original 为 null，上下文及命中的局部词表规则有长度限制；这不是能理解整本书的无限上下文校对。

原词表有真实歧义，如 `官服→官府`、`发奋→发愤`、`仓促→仓猝`、`窜改→篡改`。保持原表不代表认可每条替换在所有上下文正确，默认 AI 同时看到替换前和候选文字来复核；`--no-ai` 必须如实标记 local_only。

结构校验和提示词不能保证每处语言判断都正确，重要专名、引文、法律/财务材料仍需人工复核。Markdown 是有限词法保护，不是完整 AST；SRT/VTT/ASS 接受保守的明确语法子集，详见格式文档。

没有修改全局模型、账户配置、`.env` 或原项目；没有依赖下载、通知、文档发布，或自动删除用户历史批次。

## 原生加载与静态安全扫描（首版历史）

OmniRush 1.0.15 的原生 `loadSkillsFromDir` 识别 `erratum-correction`，诊断数组为空。Python 源文件已用本机既有 Black 26.5.1 格式化，格式化后重新执行了全部测试；未安装格式化工具或改动全局设置。

**扫描器原始结论保留：SkillSpector 2.12.0 / `--no-llm`，98/100、CRITICAL、DO_NOT_INSTALL、partial，退出码 1。** 6 条发现，含 3 条 HIGH。这不是通过扫描或低风险认证。初始报告 `scan.json`、包含测试字节码的中间报告 `formatted-scan.json`、最终源码交付扫描 `final-scan.json` 均保留在 `/tmp/erratum-verification.lELGT9/`。已清理本次生成的 `__pycache__`，不分发编译字节码；未加抑制规则、扫描排除项或基线。

逐条复核，而非仅看分数：

1. **AE1 / HIGH**：脚本被标为静态覆盖不完整。实际追踪 SkillSpector 的 `security_reconstruction._directives/_classify_directive`，定位在勘误报告的差异类型条件枚举附近（格式化后约第 100 行）；分类器返回 `active=False, limited=True`，上层仍记为“obfuscated_instruction_text”。该处是普通差异报告数据，不是执行或解码隐藏指令。入口、协议和文档模块已逐项源码审阅；不声称扫描器因此完成了分析。
2. **LP1 / HIGH**：扫描器的 `mcp_least_privilege._CAPABILITY_PATTERNS` 用裸单词正则 `\\brequests\\b` 判为网络能力。这里匹配的是普通“待处理请求”列表名称和注释；生产脚本没有导入 HTTP/requests/socket 客户端，没有外部 AI URL、网络发送或子模型进程。没有为了消除此项而额外声明不需要的网络权限，也没有删除正常请求处理逻辑。
3. **OH1 / HIGH** 与 **AST4 / MEDIUM**：均定位到测试中启动真实 CLI 的同一 `subprocess.run`。`self.output` 是 `TemporaryDirectory` 下构造的本地目录，而非模型输出；参数列表是当前解释器、固定本技能入口、合成输入/输出路径和 `--no-ai`，无 shell，也没有模型响应进入命令参数。生产脚本不调用 subprocess。模型 JSON 仅在校验后作为文本回填。
4. **RA2 × 2 / MEDIUM**：元数据 `file_write`/工具声明和后面的安装路径被跨行匹配为持久化（普通/规范化视图各一次）。实际只有用户选择的批次文件、响应、接受记录和锁；没有 cron、启动脚本、自动加载钩子或全局配置写入。

另有 `document_core.py` 的 `static_parse_limit`，以及两个运行示例路径的 `reference_missing`，均保留为分析缺口。文档核心实际只做字符串解析/回填、JSON 词表读取和有界差异计算；未发现动态代码执行或联网入口。

**人工复核意见：CAUTION。** 功能测试和实际模型流程通过；上述三条 HIGH 的具体触发点未呈现其声称的危险行为，但静态工具仍给出高风险且覆盖不完整，因此不能把“人工解释”写成“扫描通过”。重要资料使用前应审阅源码/报告，并先用副本小批量验证。
