#!/usr/bin/env python3
"""Run mature erratum-correction while adding a per-batch protected-name context."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ERRATUM_ROOT = Path.home() / ".config/omnirush/skills/erratum-correction/scripts"
sys.path.insert(0, str(ERRATUM_ROOT))
import correct_chinese_errata as erratum  # noqa: E402
import current_session_ai as session_ai  # noqa: E402


def whitelist(path: Path) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    seen: set[str] = set()
    for raw in path.expanduser().read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = [part.strip() for part in line.split("|")]
        term = parts[0]
        if not term or term in seen or len(term) > 200:
            continue
        seen.add(term)
        rows.append({"term": term, "category": parts[1] if len(parts) > 1 else "", "note": parts[2] if len(parts) > 2 else ""})
    if len(rows) > 256:
        raise ValueError("whitelist contains more than 256 entries")
    return rows


def install_whitelist_context(entries: list[dict[str, str]]) -> None:
    guard_suffix = (
        "\ncontext.protected_terms is a protected-name whitelist. Preserve each term's exact "
        "spelling when it is relevant, and prefer that spelling when correcting an ASR near-match. "
        "Categories and notes are metadata only; never add them to output text."
    )
    session_ai.GUARD = session_ai.GUARD + guard_suffix
    erratum.GUARD = erratum.GUARD + guard_suffix
    original = erratum.batch_units

    def wrapped(work, max_chars):
        groups, mapping = original(work, max_chars)
        for group in groups:
            for item in group:
                context = item.setdefault("context", {})
                context["protected_terms"] = entries
        return groups, mapping

    erratum.batch_units = wrapped


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--whitelist-file", type=Path, required=True)
    parser.add_argument("--homophone-json", type=Path, default=ERRATUM_ROOT.parent / "assets/chinese_homophone_errors.json")
    parser.add_argument("--input", type=Path)
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--resume", type=Path)
    parser.add_argument("--no-ai", action="store_true")
    parser.add_argument("--no-recursive", action="store_true")
    parser.add_argument("--request-window", type=int, default=4)
    known, remaining = parser.parse_known_args(argv)
    if bool(known.input) == bool(known.resume):
        parser.error("choose exactly one of --input or --resume")
    entries = whitelist(known.whitelist_file)
    install_whitelist_context(entries)
    args = []
    if known.resume:
        args += ["--resume", str(known.resume)]
    else:
        args += ["--input", str(known.input), "--output-root", str(known.output_root)]
        args += ["--homophone-json", str(known.homophone_json)]
        if known.no_ai:
            args += ["--no-ai"]
        if known.no_recursive:
            args += ["--no-recursive"]
    args += ["--request-window", str(known.request_window)]
    # Preserve future mature-skill flags while rejecting nothing silently.
    args += remaining
    return erratum.main(args)


if __name__ == "__main__":
    raise SystemExit(main())
