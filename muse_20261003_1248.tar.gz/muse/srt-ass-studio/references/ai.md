# Optional OmniRush AI adapter

Normal subtitle parsing, styling, rendering and conversion are local operations;
they do **not** need AI. Only an explicit translation or AI-keyword operation
should call this adapter. AI sends the supplied text to the user's existing
OmniRush service and consumes that account's allowance. Obtain permission before
sending private subtitles. Do not silently enable AI or fall back to another
provider when a request fails.

## Requirements and API

- Python 3.10+, standard library only.
- macOS or Linux/POSIX. Windows requests fail before launching: the adapter uses
  POSIX process groups and nonblocking pipe selectors for reliable cleanup.
- An installed `omnirush` executable, with the user already signed in through
  the normal `omnirush login` flow. The adapter never opens credential files,
  extracts tokens, prints credentials, changes accounts, or calls credential
  export commands.

The importable module is `scripts/omnirush_ai.py`:

```python
from omnirush_ai import AIError, OmniRushAI, request_provider

client = OmniRushAI(model=None, timeout=180, executable="omnirush")
try:
    result = client.request(
        'Translate subtitle text into French. Return {"cues":[{"id":1,"text":"..."}]} '
        'with all input IDs preserved exactly and no extra entries.',
        {"cues": [{"id": 1, "text": "Good morning."}]},
    )
except AIError as error:
    # This message deliberately contains no raw CLI diagnostics or subtitle text.
    print(str(error))
else:
    print(client.provider, client.model)  # metadata, not subtitle content
    # Validate the task-specific schema and cue IDs before applying result.
```

Public API:

```python
class AIError(Exception): ...

class OmniRushAI:
    def __init__(self, model: str | None = None, timeout: float = 180,
                 executable: str = "omnirush"): ...
    @property
    def model(self) -> str | None: ...
    @property
    def provider(self) -> str: ...  # always "omnirush"
    def request(self, system: str, payload: dict) -> dict: ...


def request_provider(system: str, payload: dict, *, model: str | None = None,
                     timeout: float = 180, executable: str = "omnirush") -> dict: ...
```

Construction and import make no AI requests. Each `request` starts one isolated
CLI invocation. The convenience function constructs a client and performs that
same operation; use the class when you also need model metadata. Instances are
for sequential use, not concurrent calls. The executable is a single name/path,
not a shell command containing arguments.

The returned dictionary is exactly the model's JSON object, without added
provider/model keys or schema rewriting. The caller must check its own response
schema, lengths, cue IDs, ordering and language before accepting it. Valid JSON
alone does not establish that a translation or keyword choice is correct.

## Provider and model inheritance

1. An explicit `model` argument takes precedence. It may include a `:effort`
   suffix or an `omnirush/` prefix; the latter is stripped before passing the ID.
2. Otherwise, inherit the current `OMNIRUSH_MODEL`. The current session provider
   must be absent, empty, or `OMNIRUSH_PROVIDER=omnirush`. An inherited different
   provider is rejected rather than accidentally using its model. An explicit
   OmniRush model can be supplied from an unrelated-provider environment.
3. If no model is provided or inherited, omit `--model` and defer to the installed
   OmniRush launcher's model-selection policy. The adapter has **no hardcoded
   model** and does not inspect or edit saved settings. In installed 1.0.15, the
   launcher itself inserts its product default when `OMNIRUSH_MODEL` is absent;
   this can differ from a model saved in the underlying agent core's settings.

`provider` is always `omnirush`. Before a successful request, `model` is the
requested/inherited ID, or `None` when deferring to the launcher. After success,
it is the final assistant event's `responseModel`, when present, otherwise
`model`. Subsequent calls still request the originally selected model rather
than silently switching to a returned alias. CLI model matching can resolve an
ID/alias to another ID, so check the post-request property if identity matters.
This is CLI/provider-reported metadata, **not independent model attestation**.
The no-extension invocation intentionally does not enable the normal SOTA
attestation extension. Missing model identity or a final provider other than
`omnirush` is rejected. No other provider or HTTP API is attempted.

## Isolation and exact invocation

The installed OmniRush 1.0.15 launcher and bundled core parser/help were checked
for these flags. The adapter uses the launcher, not a copied token or a separate
AI integration. Its argument list is equivalent to:

```text
omnirush --engine pi --print --mode json
  --provider omnirush --models omnirush/*
  --no-tools --no-extensions --no-skills
  --no-prompt-templates --no-themes --no-context-files
  --no-session --no-yolo --no-approve
  --system-prompt <fixed subtitle-data safety instruction>
  --append-system-prompt ""
  [--model <explicit-or-inherited-model>]
```

This is an argv list, **not a shell command**. Both the task-specific `system`
argument and `payload` are encoded as `{"task": ..., "payload": ...}` and sent
over stdin. Neither appears in the process arguments, a temporary prompt file,
or an adapter log. Only the fixed, non-private safety instruction is in argv.
Its rules designate subtitle text, filenames and all nested payload values as
untrusted data, never instructions. It prohibits credential disclosure, tool
use, external actions and obeying instructions embedded in subtitle text.
Prompt injection remains a model-quality concern; task-specific output checks
are still essential.

Both system-prompt sources are explicitly overridden: `--no-context-files`
alone disables AGENTS/CLAUDE discovery but **does not disable** global
`SYSTEM.md` or `APPEND_SYSTEM.md`. The empty append override prevents those
additional instructions from being loaded. The temporary, empty working
directory is removed after the request, including on error. It is not used as
an account/configuration directory, and no prompt or response files are created.
No saved conversation is opened or written (`--no-session`).

Child-only environment overrides disable automatic CLI updates, private crash
report collection/delivery, verbose debug diagnostics, the welcome banner and
yolo mode. The current account/configuration paths and connection settings stay
inherited; the parent environment and global settings are not changed. Engine
`pi` is selected explicitly so an `OMNIRUSH_ENGINE=opencode` setting cannot route
the request to a different wire protocol with different isolation semantics.
This is an engine choice, not an AI provider/model change.

The executable and existing CLI installation/configuration are trusted. This is
not an OS sandbox: the launcher still performs its normal account bootstrap and
may refresh its model catalog or managed extension files even though extensions
are not loaded for the request. The adapter does not implement a separate login,
authentication refresh mechanism, token cache, notification or upload mechanism.
`--no-session` does not promise anything about the service's own retention policy.

## Bounds, errors and process cleanup

Hard limits (UTF-8 bytes):

| Item | Maximum |
| --- | ---: |
| stdin envelope (instructions plus payload) | 256 KiB |
| final assistant response text | 1 MiB |
| complete stdout JSON event stream | 8 MiB |
| drained stderr | 256 KiB |
| request lifetime | `timeout`, default 180 seconds |

Batch large subtitles before requesting AI. Exceeding a bound fails rather than
truncating inputs or accepting partial outputs. The byte limits bound local
buffering, not server tokens/cost: this CLI integration does not expose a strict
per-request output-token budget. Killing a timed-out client does not guarantee
that the service stops already-started work or stops accounting for it.

The adapter starts a fresh POSIX session/process group, writes stdin and drains
stdout/stderr concurrently with nonblocking selectors, and enforces one elapsed
clock deadline. It terminates the group and then sends SIGKILL, including to
children of an already-exited launcher, and reaps the direct process. Cleanup
also runs on interruption. A deliberately detached process outside the group
is outside this guarantee; tools and extensions that could normally spawn such
work are disabled. Windows is explicitly unsupported rather than pretending
that terminating a launcher also terminates its children.

JSON mode is a stream of events, not the response object itself. The adapter:

- Splits JSONL on LF, not Unicode line separators that can occur in subtitle text.
- Uses the final authoritative assistant `message_end`; ignores streaming deltas
  and thinking content instead of concatenating partial snapshots.
- Requires a terminating newline, `agent_settled`, `stopReason="stop"`, and valid
  OmniRush provider/model metadata. The installed runtime emits these fields.
- Rejects nonzero process exits, malformed/empty/truncated streams, failed retries,
  error/aborted/length-limited answers, unexpected tools and missing final text.
- Accepts exactly one response JSON object, optionally wrapped in one outer
  ` ```json ` or plain ` ``` ` markdown fence. It does not search prose with a
  broad regex, repair broken JSON, accept trailing commentary, or accept arrays.
- Rejects duplicate JSON keys, non-finite numbers and non-UTF-8 subtitle strings.
- Discards stderr without logging, returning or interpolating it into exceptions.
  Errors from malformed JSON also suppress the original exception context.

On failure, use the safe `AIError` message and independently check `omnirush`
installation, sign-in, account/model access or quota. Do not paste raw subtitle
payloads or credential-bearing CLI debug logs into a bug report. The adapter
never retries itself or falls back to another model/provider; OmniRush's own
internal automatic retry policy may make more than one service attempt during
one invocation, within the adapter's elapsed-time bound.

Older/future runtimes with incompatible flags or without the required final
JSON events fail closed. Do not weaken isolation flags to make a failing version
work; inspect that version's supported protocol first.

## Verification and sources

Offline test command:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s ~/.config/omnirush/skills/srt-ass-studio/tests \
  -p test_omnirush_ai.py -v
```

The tests use a synthetic executable and synthetic JSON events, never real
credentials or subtitle files. They cover the public API, model inheritance,
all isolation flags, stdin-only private data, strict JSON handling, nonzero
exits/stderr redaction, size limits, deadlines and child-process cleanup.

One tiny live synthetic smoke request was performed with the adapter's exact
flags above, inherited model selection and the existing logged-in account:
`{"probe":"synthetic"}` asking only for `{"ok":true}`. It passed in 10.91 seconds;
the final events reported provider `omnirush`, model `gpt-6-astra`, and the exact
expected result. No user files, subtitles or notification request were sent.
That result validates this installed CLI/account combination, not future
availability, translation quality or independently attested model identity.

Implementation was checked against installed OmniRush 1.0.15 `src/bin.js`,
`src/lib.js`, `src/runtime.js`, and the bundled core parser, resource loader and
print-mode implementation. The bundled docs directory was absent. The following
official upstream references were read completely; installed behavior, not a
newer upstream example, determines the flags used here:

- [CLI](https://raw.githubusercontent.com/badlogic/pi-mono/main/packages/coding-agent/docs/cli.md)
- [CLI integration](https://raw.githubusercontent.com/badlogic/pi-mono/main/packages/coding-agent/docs/cli-integration.md)
- [JSON events](https://raw.githubusercontent.com/badlogic/pi-mono/main/packages/coding-agent/docs/json.md)
- [Message types](https://raw.githubusercontent.com/badlogic/pi-mono/main/packages/coding-agent/docs/message-types.md)
- [Environment variables](https://raw.githubusercontent.com/badlogic/pi-mono/main/packages/coding-agent/docs/environment-variables.md)
- [Configuration](https://raw.githubusercontent.com/badlogic/pi-mono/main/packages/coding-agent/docs/configuration.md)
- [Models](https://raw.githubusercontent.com/badlogic/pi-mono/main/packages/coding-agent/docs/models.md)
- [Security](https://raw.githubusercontent.com/badlogic/pi-mono/main/packages/coding-agent/docs/security.md)
