'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const smtpDir = path.resolve(__dirname, '../../smtp-email');
const nodemailer = require(path.join(smtpDir, 'node_modules/nodemailer'));
const smtp = require(path.join(smtpDir, 'index.js'));

test('SMTP reads only isolated .env, never process credentials; setup cannot overwrite it', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'smtp-config-test-'));
  const dir = path.join(temp, '.config/omnirush');
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, '.env');
  const content = 'UNRELATED=keep\nSMTP_HOST=example.test\nSMTP_PORT=587\nSMTP_USER=fixture-user\nSMTP_PASS=fixture-password\n';
  fs.writeFileSync(file, content);
  const originalHome = os.homedir;
  const originalTransport = nodemailer.createTransport;
  const oldPass = process.env.SMTP_PASS;
  try {
    os.homedir = () => temp;
    process.env.SMTP_PASS = 'must-not-use';
    let transport;
    nodemailer.createTransport = (options) => {
      transport = options;
      return { verify: async () => true, sendMail: async () => ({ messageId: '<fixture>', rejected: [] }) };
    };
    const result = await smtp.sendSmtpEmail({ to: 'test@example.com', subject: 'fixture', text: 'fixture' });
    assert.equal(result.success, true);
    assert.equal(transport.auth.pass, 'fixture-password');
    assert.equal(transport.requireTLS, true);
    const setup = spawnSync(process.execPath, [path.join(smtpDir, 'index.js'), 'setup'], { env: { ...process.env, HOME: temp }, encoding: 'utf8' });
    assert.notEqual(setup.status, 0);
    assert.equal(fs.readFileSync(file, 'utf8'), content);
  } finally {
    os.homedir = originalHome;
    nodemailer.createTransport = originalTransport;
    if (oldPass === undefined) delete process.env.SMTP_PASS; else process.env.SMTP_PASS = oldPass;
    fs.rmSync(temp, { recursive: true, force: true });
  }
});
