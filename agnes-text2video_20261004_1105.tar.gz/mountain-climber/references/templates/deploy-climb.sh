#!/bin/bash
# ============================================================
# deploy-climb.sh — 一键部署登山路线指挥页到 line.allez.cc.cd
#
# 用法:
#   bash deploy-climb.sh                              # 部署默认目录 ~/Downloads/mountain-climber/
#   bash deploy-climb.sh ~/Downloads/my-climb/        # 部署指定目录
#
# 流程:
#   1. 部署 index.html → Vercel (toc 项目)
#   2. line.allez.cc.cd 自动指向最新登山路线
#   3. 本地 index.html 自动备份为 index-🏔️-{山名}-{日期}.html
# ============================================================

set -uo pipefail

# —— 配置 ——
VERCEL_TOKEN_FILE="$HOME/.config/opencode/.env"
BASE_DIR="$HOME/Downloads/mountain-climber"
VERCEL_PROJECT="toc"
VERCEL_SCOPE="seigneurtsuis-projects"

# —— 从 .env 读取配置 ——
load_env() {
  local key="$1"
  grep -s -o "$key=[^[:space:]]*" "$VERCEL_TOKEN_FILE" | head -1 | cut -d= -f2- || echo ""
}
TOKEN=$(load_env "VERCEL_TOKEN")

# —— 目标目录 ——
TARGET="${1:-$BASE_DIR}"
TARGET="$(cd "$TARGET" 2>/dev/null && pwd || echo "")"

if [ -z "$TARGET" ] || [ ! -f "$TARGET/index.html" ]; then
  echo "❌ 错误: 目标目录不存在或缺少 index.html" >&2
  echo "用法: $0 [包含 index.html 的目录]" >&2
  echo "  默认: $BASE_DIR" >&2
  exit 1
fi

# —— 提取山名 ——
MOUNTAIN_NAME="登山路线"
H1=$(grep -o '<h1>[^<]*</h1>' "$TARGET/index.html" 2>/dev/null | head -1 | sed 's/<[^>]*>//g' | xargs)
[ -n "$H1" ] && MOUNTAIN_NAME="$H1"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🏔️  路线: $MOUNTAIN_NAME"
echo "  📂  目录: $TARGET"
echo "  🌐  域名: https://line.allez.cc.cd"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# —— 1. 部署到 Vercel ——
echo ""
echo "📤 部署中..."
vercel deploy "$TARGET" \
  --prod \
  --token "$TOKEN" \
  --scope "$VERCEL_SCOPE" \
  --project "$VERCEL_PROJECT" \
  -y 2>&1 || {
    echo "❌ 部署失败" >&2
    exit 1
  }

echo ""
echo "✅ 部署完成 → https://line.allez.cc.cd"

# —— 2. 重命名本地 index.html 防止下次覆盖 ——
SLUG=$(echo "$MOUNTAIN_NAME" | sed 's/[ 　]/-/g' | sed 's/--*/-/g' | sed 's/[()]//g' | sed 's/-$//')
DATE=$(date +%Y%m%d)
if [ -f "$TARGET/index.html" ]; then
  mv "$TARGET/index.html" "$TARGET/index-${SLUG}-${DATE}.html"
  echo "📁 本地备份: index.html → index-${SLUG}-${DATE}.html"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🎉 全部完成！"
echo "  🌐 https://line.allez.cc.cd"
echo "  📁 index.html → index-${SLUG}-${DATE}.html"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
