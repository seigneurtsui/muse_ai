---
name: faster-whisper-stt
description: "Local batch STT with faster-whisper: CPU int8, long-audio auto-chunking with resume, dual-layer credit/ending-subtitle filtering, SRT+TXT output. Use when the user asks to transcribe audio/video locally (语音转文字, 转写, 字幕, transcribe, STT, subtitles) without cloud upload, or asks for offline Whisper transcription of files or directories."
version: 1.0.0
metadata:
  needs:
    pythonPackages:
      - faster-whisper
  external:
    - ffmpeg
    - ffprobe
---

# faster-whisper-stt

本地离线批量语音转文字（STT）技能。基于 faster-whisper（CTranslate2 CPU int8），
无需上传云端，无 API 费用。支持长音频自动分片、断点续跑、双层片尾/广告字幕过滤、
SRT + TXT 双格式输出。

## 何时使用

- 用户要求**本地/离线**转写音频或视频（明确拒绝云端上传时尤其适用）
- 长音频（数小时）需要分片 + 断点续跑
- 批量转写整个目录（递归扫描）
- 需要过滤字幕组/广告/片尾 volunteer 幻觉文本
- 与 `chatgpt-short-video-editor` 的关系：**本技能是该工作流的默认 STT 引擎**
  （本地、免上传、无费用）。产物为短语级时间戳，精度低于 ElevenLabs Scribe v2 的
  词级时间戳；使用时须按该技能规则在 `project.md` 标注 lower-confidence，
  切边吸附短语边界 + 静音 ≥400ms 目标，并在每个 EDL 边做回放检查。
  Scribe v2 降为备用方案：仅当用户明确要求词级精度、点名 Scribe，或本引擎失败时启用，
  且上传前须取得用户对文件、用途与费用的明确同意。

## 前置要求（本机已满足）

- `faster-whisper` ≥ 1.2（已装 1.2.1）
- `ffmpeg` / `ffprobe` 在 PATH
- 模型目录：`~/lavoro/translate/whisper/models/faster-whisper-large-v3-turbo-int8`
  （large-v3-turbo int8 量化，约 1.6GB；缺失时可用 `--model <HF模型名>` 从 HuggingFace 拉取）

## 快速用法

脚本位置：`{baseDir}/scripts/stt_fasterwhisper_batch.py`

```bash
# 单文件长音频（自动 15 分钟分片 + 断点续跑）
python3 {baseDir}/scripts/stt_fasterwhisper_batch.py \
  --file <音频或视频文件> \
  --language zh \
  --resume

# 目录批量（递归）
python3 {baseDir}/scripts/stt_fasterwhisper_batch.py \
  --dir <媒体目录> \
  -o ~/Downloads/stt_transcripts \
  --language zh \
  --resume

# 仅合并已有分片（转写中断后修复，不重跑）
python3 {baseDir}/scripts/stt_fasterwhisper_batch.py \
  --file <文件> --merge-only
```

## 常用参数

| 参数 | 默认 | 说明 |
|---|---|---|
| `--file` / `--dir` | 必选二选一 | 单文件或目录（`--no-recursive` 关闭递归） |
| `-o, --output` | `~/Downloads/stt_transcripts` | 输出根目录（自动建 `YYYYMMDD_HHMM` 批次目录） |
| `--batch-name` | `YYYYMMDD_HHMM` | 自定义批次目录名 |
| `--model` | 本机 int8 turbo 模型 | CTranslate2 模型目录或 HF 名（如 `deepdml/faster-whisper-large-v3-turbo-ct2`） |
| `--language` | `auto` | 语言代码（zh/en/ja…）；auto 自动识别 |
| `--chunk-duration` | 900 | 分片秒数（≥60）；15 分钟默认适配 16GB 内存 |
| `--resume` | 关 | 断点续跑：跳过已成功分片 |
| `--merge-only` | 关 | 只合并已有分片结果 |
| `--srt-only` | 关 | 只出 SRT 不出 TXT |
| `--credit-filter` / `--credit-tail-filter` | 开 | A 层全文关键词 / B 层尾部窗口过滤片尾广告文本 |
| `--cpu-threads` | 6 | CPU 线程数（本机 8 核，留 2 核给系统） |
| `--beam-size` | 5 | 解码 beam |
| `--vad` / `--no-vad` | 开 | VAD 过滤静音段 |
| `--overwrite` | 关 | 覆盖已有输出 |

## 输出结构

```
<output_root>/<batch_name>/
├── report.json                 # 批次总报告（成功/失败/各文件统计）
├── batch.log                   # 全程日志
└── <source_stem>/              # 每个源文件一个 job 目录
    ├── subtitle_merged.srt     # 原始合并字幕（分片偏移后）
    ├── subtitle_clean.srt      # 发布版：清理无效段/修正重叠/重排编号
    ├── transcript_merged.txt   # 纯文本
    ├── cleanup_report.json
    ├── job_result.json
    └── chunks/
        ├── chunk_0000.wav      # 16kHz mono 分片
        └── chunk_0000/
            ├── subtitle.srt
            ├── transcript.txt
            ├── chunk_result.json
            └── filter_report.json
```

## 运行规则（agent 执行时遵守）

1. **先 ffprobe 后转写**：确认源文件时长/格式；源文件永不修改，产物只进输出目录。
2. **长音频必带 `--resume`**：数小时任务中断后可续跑，失败只重跑对应分片。
3. **过滤层不要随意关闭**：A+B 双层过滤是防止 Whisper 在片尾/静音处幻觉出
   "字幕志愿者/制作"等文本的关键；确认误杀时用 `--credit-keywords` 精确调整。
4. **报告必须基于真实输出**：交付前核对 `report.json` 与 `subtitle_clean.srt`
   存在且非空；部分分片失败时如实说明，不得宣称完整。
5. **磁盘提示**：分片 WAV 每小时约 115MB；本机磁盘 <2GB 可用时先清理再跑长音频。
6. **与编辑工作流衔接**：产物 SRT/TXT 可复制进剪辑批次目录
   （`~/Downloads/short_videos/<batch>/edit/`）使用；但该工作流的词级时间戳要求
   仍以 Scribe 为主，本技能输出按 lower-confidence 对待。
