'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {
  main,
  parseArgs,
  sendWithRetry,
} = require('./send_report.cjs');

function temporaryReport() {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'china-flight-send-test-'));
  const html = path.join(directory, 'report.html');
  const text = path.join(directory, 'report.md');
  fs.writeFileSync(html, '<h1>test</h1>');
  fs.writeFileSync(text, '# test');
  return { directory, html, text };
}

test('parses bounded retry and status-file options', () => {
  const options = parseArgs([
    '--html', 'a.html', '--text', 'a.md', '--subject', '测试',
    '--retries', '3', '--retry-delay-ms', '0', '--status-file', 'status.json',
  ]);
  assert.equal(options.retries, 3);
  assert.equal(options.retryDelayMs, 0);
  assert.equal(options.statusFile, 'status.json');
  assert.throws(() => parseArgs([
    '--html', 'a.html', '--text', 'a.md', '--subject', '测试', '--retries', '5',
  ]));
});

test('retries a transient failure and records only delivery metadata', async () => {
  let calls = 0;
  const outcome = await sendWithRetry({
    retries: 2,
    retryDelayMs: 0,
    payload: { to: 'test@example.com', subject: 'test' },
    send: async () => {
      calls += 1;
      if (calls < 2) throw Object.assign(new Error('temporary SMTP failure'), { responseCode: 451 });
      return { messageId: '<message-id>' };
    },
  });
  assert.equal(calls, 2);
  assert.equal(outcome.success, true);
  assert.deepEqual(outcome.attempts.map((item) => item.status), ['failed', 'sent']);
  assert.equal(outcome.attempts[1].messageId, '<message-id>');
  assert.equal(outcome.attempts[0].error, 'EMAIL_ERROR SMTP 451');
});

test('CLI simulation writes a failed status record after finite retries', async () => {
  const files = temporaryReport();
  const statusFile = path.join(files.directory, 'send-status.json');
  const output = [];
  const originalLog = console.log;
  const originalError = console.error;
  console.log = (line) => output.push(line);
  console.error = () => {};
  try {
    const exitCode = await main([
      '--html', files.html, '--text', files.text, '--subject', '测试',
      '--to', 'test@example.com', '--retries', '1', '--retry-delay-ms', '0',
      '--status-file', statusFile,
    ], {
      send: async () => { throw Object.assign(new Error('SMTP_PASS=do-not-save'), { responseCode: 451 }); },
    });
    assert.equal(exitCode, 1);
  } finally {
    console.log = originalLog;
    console.error = originalError;
  }
  const record = JSON.parse(fs.readFileSync(statusFile, 'utf8'));
  assert.equal(record.status, 'failed');
  assert.equal(record.success, false);
  assert.equal(record.attempts.length, 2);
  assert.equal(record.attempts[0].error, 'EMAIL_ERROR SMTP 451');
  assert.doesNotMatch(fs.readFileSync(statusFile, 'utf8'), /do-not-save/);
  assert.equal(JSON.parse(output[0]).statusFile, statusFile);
});
