#!/usr/bin/env python3
"""
Telegram Chat List - 列出所有聊天ID和名称
"""

import argparse
import asyncio
import json
import os
import sys
from telethon import TelegramClient

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)
DEFAULT_CONFIG_PATH = os.path.join(SKILL_DIR, 'config.json')
DEFAULT_OUTPUT_DIR = os.path.expanduser('~/Downloads')

def load_config(config_path=DEFAULT_CONFIG_PATH):
    """加载配置文件"""
    if os.path.exists(config_path):
        with open(config_path, 'r') as f:
            return json.load(f)
    return {}

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='列出Telegram所有聊天ID')
    parser.add_argument('--api-id', help='Telegram API ID')
    parser.add_argument('--api-hash', help='Telegram API Hash')
    parser.add_argument('--phone', help='手机号')
    parser.add_argument('--session', default='telegram_session', help='Session名称')
    parser.add_argument('--config', default=DEFAULT_CONFIG_PATH, help='配置文件路径')
    parser.add_argument('--json', action='store_true', help='JSON格式输出')
    return parser.parse_args()

async def list_chats(client, json_output=False):
    """列出所有聊天"""
    dialogs = await client.get_dialogs()
    
    if json_output:
        chats = []
        for dialog in dialogs:
            chats.append({
                'id': dialog.id,
                'name': dialog.name,
                'type': dialog.entity.__class__.__name__
            })
        print(json.dumps(chats, ensure_ascii=False, indent=2))
    else:
        print(f"\n{'='*60}")
        print(f"您的所有对话 (共 {len(dialogs)} 个)")
        print(f"{'='*60}\n")
        
        for idx, dialog in enumerate(dialogs, 1):
            chat_type = dialog.entity.__class__.__name__
            print(f"{idx}. ID: {dialog.id}")
            print(f"   名称: {dialog.name}")
            print(f"   类型: {chat_type}")
            print(f"   {'-'*50}")
        
        # 保存聊天列表到文件
        chats = []
        for dialog in dialogs:
            chats.append({
                'id': dialog.id,
                'name': dialog.name,
                'type': chat_type
            })
        
        chats_json_file = os.path.join(DEFAULT_OUTPUT_DIR, 'telegram_chats.json')
        with open(chats_json_file, 'w', encoding='utf-8') as f:
            json.dump(chats, f, ensure_ascii=False, indent=2)
        print(f"聊天列表已保存到: {chats_json_file}")
        
        # 保存ID列表到文件
        ids = [dialog.id for dialog in dialogs]
        ids_file = os.path.join(DEFAULT_OUTPUT_DIR, 'telegram_chat_ids.txt')
        with open(ids_file, 'w') as f:
            for chat_id in ids:
                f.write(f"{chat_id}\n")
        print(f"ID列表已保存到: {ids_file}")

async def main():
    args = parse_args()
    
    # 加载配置
    config = {}
    if os.path.exists(args.config):
        config = load_config(args.config)
    
    # 命令行参数优先
    api_id = args.api_id or config.get('api_id')
    api_hash = args.api_hash or config.get('api_hash')
    phone = args.phone or config.get('phone')
    
    if not api_id or not api_hash:
        print("错误: 请提供 API ID 和 API Hash")
        print("方式一: 通过 --api-id 和 --api-hash 参数")
        print("方式二: 创建 config.json 配置文件")
        sys.exit(1)
    
    client = TelegramClient(args.session, int(api_id), api_hash)
    
    async with client:
        # 如果session已存在且已认证，直接使用
        if not client.is_connected():
            await client.connect()
        
        if phone:
            await client.start(phone)
        else:
            await client.start()
        
        await list_chats(client, json_output=args.json)

if __name__ == "__main__":
    asyncio.run(main())