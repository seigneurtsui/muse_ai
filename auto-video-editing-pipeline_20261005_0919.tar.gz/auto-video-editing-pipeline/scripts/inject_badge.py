#!/usr/bin/env python3
"""Inject one precisely-timed, independently styled badge into an ASS file."""
from __future__ import annotations

import argparse
import re
from pathlib import Path


POSITIONS = {
    "top-left": (7, "margin", "margin"),
    "top-center": (8, "center", "margin"),
    "top-right": (9, "right", "margin"),
    "center-left": (4, "margin", "center"),
    "center": (5, "center", "center"),
    "center-right": (6, "right", "center"),
    "bottom-left": (1, "margin", "bottom"),
    "bottom-center": (2, "center", "bottom"),
    "bottom-right": (3, "right", "bottom"),
}


def ass_color(value: str, default_alpha: str = "00") -> str:
    value = value.strip().lstrip("#")
    if re.fullmatch(r"[0-9A-Fa-f]{6}", value):
        alpha, rgb = default_alpha, value
    elif re.fullmatch(r"[0-9A-Fa-f]{8}", value):
        alpha, rgb = value[:2], value[2:]
    else:
        raise ValueError("colors must be RRGGBB or AARRGGBB")
    r, g, b = rgb[0:2], rgb[2:4], rgb[4:6]
    return f"&H{alpha.upper()}{b.upper()}{g.upper()}{r.upper()}"


def ass_time(value: float) -> str:
    value = max(0.0, value)
    hours = int(value // 3600)
    minutes = int((value % 3600) // 60)
    seconds = int(value % 60)
    centiseconds = int(round((value - int(value)) * 100))
    if centiseconds >= 100:
        seconds += 1
        centiseconds -= 100
    return f"{hours}:{minutes:02d}:{seconds:02d}.{centiseconds:02d}"


def escape_text(text: str) -> str:
    return text.replace("\\", r"\\").replace("{", r"\{").replace("}", r"\}").replace("\n", r"\N")


def play_res(text: str) -> tuple[int, int]:
    width = re.search(r"^PlayResX:\s*(\d+)", text, re.MULTILINE)
    height = re.search(r"^PlayResY:\s*(\d+)", text, re.MULTILINE)
    return int(width.group(1)) if width else 1920, int(height.group(1)) if height else 1080


def inject(
    source: Path,
    destination: Path,
    *,
    text: str,
    start: float,
    end: float,
    position: str,
    font: str,
    size: int,
    color: str,
    outline_color: str,
    back_color: str,
    outline: int,
    shadow: int,
    animation: str,
    fade_in_ms: int,
    fade_out_ms: int,
) -> dict:
    if not text.strip() or start < 0 or end <= start:
        raise ValueError("badge text/time range is invalid")
    if position not in POSITIONS:
        raise ValueError(f"unknown badge position: {position}")
    if size < 1 or outline < 0 or shadow < 0:
        raise ValueError("badge size/outline/shadow must be non-negative")
    raw = source.read_text(encoding="utf-8")
    width, height = play_res(raw)
    align, x_mode, y_mode = POSITIONS[position]
    x = 60 if x_mode == "margin" else width - 60 if x_mode == "right" else width // 2
    y = 60 if y_mode == "margin" else height - 60 if y_mode == "bottom" else height // 2
    primary = ass_color(color)
    outline_ass = ass_color(outline_color)
    back_ass = ass_color(back_color)
    style = (
        f"Style: Badge,{font},{size},{primary},{primary},{outline_ass},{back_ass},"
        f"-1,0,0,0,100,100,0,0,1,{outline},{shadow},{align},60,60,60,1"
    )
    if re.search(r"^Style:\s*Badge,", raw, re.MULTILINE) is None:
        marker = "[Events]"
        if marker not in raw:
            raise ValueError("ASS file has no [Events] section")
        raw = raw.replace(marker, f"{style}\n\n{marker}", 1)
    tags = f"\\an{align}\\pos({x},{y})"
    fade_in_ms = max(0, min(fade_in_ms, int((end - start) * 500)))
    fade_out_ms = max(0, min(fade_out_ms, int((end - start) * 500)))
    if animation in {"fade", "pop", "zoom", "fly"}:
        tags += f"\\fad({fade_in_ms},{fade_out_ms})"
    if animation == "pop":
        duration = max(1, fade_in_ms or 300)
        tags += f"\\fscx75\\fscy75\\t(0,{duration},\\fscx100\\fscy100)"
    elif animation == "zoom":
        tags += f"\\fscx85\\fscy85\\t(0,{max(1, int((end-start)*1000))},\\fscx100\\fscy100)"
    elif animation == "fly":
        tags = f"\\an{align}\\move({x+120},{y},{x},{y},0,{max(1, fade_in_ms)})\\fad({fade_in_ms},{fade_out_ms})"
    event = f"Dialogue: 20,{ass_time(start)},{ass_time(end)},Badge,,0,0,0,,{{{tags}}}{escape_text(text)}"
    raw = raw.rstrip() + "\n" + event + "\n"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(raw, encoding="utf-8")
    return {"text": text, "start": start, "end": end, "duration": end - start, "position": position, "animation": animation}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--text", required=True)
    parser.add_argument("--start", type=float, default=0.4)
    parser.add_argument("--end", type=float, default=2.0)
    parser.add_argument("--position", choices=sorted(POSITIONS), default="top-center")
    parser.add_argument("--font", default="Noto Sans CJK SC")
    parser.add_argument("--size", type=int, default=72)
    parser.add_argument("--color", default="FFFFFF")
    parser.add_argument("--outline-color", default="151515")
    parser.add_argument("--back-color", default="80000000")
    parser.add_argument("--outline", type=int, default=3)
    parser.add_argument("--shadow", type=int, default=1)
    parser.add_argument("--anim", choices=("none", "fade", "pop", "zoom", "fly"), default="none")
    parser.add_argument("--fade-in-ms", type=int, default=120)
    parser.add_argument("--fade-out-ms", type=int, default=250)
    args = parser.parse_args()
    report = inject(
        args.input, args.output, text=args.text, start=args.start, end=args.end,
        position=args.position, font=args.font, size=args.size, color=args.color,
        outline_color=args.outline_color, back_color=args.back_color,
        outline=args.outline, shadow=args.shadow, animation=args.anim,
        fade_in_ms=args.fade_in_ms, fade_out_ms=args.fade_out_ms,
    )
    print(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
