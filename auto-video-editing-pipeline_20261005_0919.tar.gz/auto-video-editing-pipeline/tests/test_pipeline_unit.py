import tempfile
import unittest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.inject_badge import inject
from scripts.srt_utils import read_cues, retime_srt


class PipelineUnitTests(unittest.TestCase):
    def test_retime_preserves_phrase_boundaries(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "source.srt"
            destination = root / "retimed.srt"
            source.write_text(
                "1\n00:00:01,000 --> 00:00:03,000\n襄阳古城\n\n"
                "2\n00:00:04,000 --> 00:00:06,000\n护城河\n",
                encoding="utf-8",
            )
            report = retime_srt(source, destination, speed=2.0, trim_start=1.0, trim_end=6.0)
            cues = read_cues(destination)
            self.assertEqual(report["output_cues"], 2)
            self.assertEqual(cues[0][0], 0.0)
            self.assertEqual(cues[0][1], 1.0)
            self.assertEqual(cues[1][0], 1.5)
            self.assertEqual(cues[1][1], 2.5)

    def test_badge_has_exact_time_position_and_duration(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "source.ass"
            destination = root / "badge.ass"
            source.write_text(
                "[Script Info]\nPlayResX: 1080\nPlayResY: 1920\n\n"
                "[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
                "Style: Default,Noto Sans CJK SC,42,&H00FFFFFF,&H00FFFFFF,&H00151515,&H80000000,0,0,0,0,100,100,0,0,1,2,0,2,60,60,109,1\n\n"
                "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
                "Dialogue: 1,0:00:00.00,0:00:01.00,Default,,0,0,0,,hello\n",
                encoding="utf-8",
            )
            report = inject(source, destination, text="高能时刻", start=0.4, end=2.8, position="top-right", font="Noto Sans CJK SC", size=72, color="FFFFFF", outline_color="151515", back_color="80000000", outline=3, shadow=1, animation="pop", fade_in_ms=120, fade_out_ms=250)
            content = destination.read_text(encoding="utf-8")
            self.assertEqual(report["duration"], 2.4)
            self.assertIn("Style: Badge", content)
            self.assertIn("Dialogue: 20,0:00:00.40,0:00:02.80,Badge", content)
            self.assertIn("\\an9\\pos(1020,60)", content)


if __name__ == "__main__":
    unittest.main()
