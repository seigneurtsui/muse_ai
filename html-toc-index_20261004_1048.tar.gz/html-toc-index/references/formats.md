# 格式与接口

## CLI

```text
build_toc_index.py [INPUT_DIR] [-o OUTPUT] [options]
```

| 选项 | 说明 |
|---|---|
| `INPUT_DIR` | 输入目录（默认 `~/Downloads/rainman-travel`），必须存在。 |
| `-o, --output OUTPUT` | 输出目录（默认 `~/Downloads/rainman-travel_toc`）。不得等于或位于输入目录内。 |
| `--title TITLE` | 索引页标题（默认 `文档索引`）。 |
| `-r, --recursive` | 递归扫描输入目录的子目录；否则只处理顶层。 |
| `--exclude-pattern REGEX` | 按正则排除文件名；可重复。值以 `-` 开头（如 `-email`）也可直接使用。 |
| `--places-file FILE` | 自定义地名词典文件（每行一个地名，`#` 开头为注释）；提供时**替换**内置词典。 |
| `--incremental` | 增量更新：跳过内容未变文档、删除过期 `doc-*` 目录。 |
| `--inject-doc-toc` | 为每篇文档注入 H1–H3 标题目录（稳定锚点 + 可折叠浮动目录）。 |
| `--export-json` / `--export-markdown` / `--export-txt` | 生成对应导出文件。 |
| `--jobs N` | 并行工作线程数（默认 `auto`，上限 8，且不超过文件数）。 |
| `--no-parallel` | 串行处理。 |
| `--dry-run` | 只扫描与规划，不写任何文件。 |
| `--json` | 把 JSON 报告打印到 stdout（日志走 stderr）。 |
| `--report FILE` | 另将 JSON 报告写入该文件。 |
| `--verbose` / `--log-file FILE` | 详细日志 / 追加日志文件。 |
| `-v, --version` | 打印版本。 |

## 索引页（`output/index.html`）

- 采用 `__TOKEN__` 占位符替换（`__PAGE_TITLE__`、`__TOTAL__`、`__GENERATED_AT__`、`__DATA_JSON__`），不使用 `str.format`，因此 CSS/JS 的花括号无需转义。
- 元数据以内联 `const DATA = [...]` 注入；每条记录字段：`doc_id, title, summary, filename, size, word_count, date, date_sort, date_source, tags`。
- 前端特性：实时搜索、多维排序 + 升降序、每页 10/20/50/100、标签筛选、关键词高亮、URL hash 路由（`search/sort/dir/tag/page/size`）、暗色模式、打印样式；键盘 `/`、`Esc`、`G`。
- 每张卡片链接到 `doc-<doc_id>/index.html`。

## 导出文件

- `data.json`：记录数组，字段与索引页 `DATA` 相同，另含 `toc_items` 与 `output`（相对路径）。不含正文。
- `INDEX.md`：Markdown 索引（按日期倒序），含标题链接、日期、字数与标签。
- `file_list.txt`：按标题排序的文件名列表。

## 报告字段（JSON）

```jsonc
{
  "version": "1.0.0",
  "generated_at": "ISO-8601",
  "input_dir": "/abs",
  "output_dir": "/abs",
  "recursive": false,
  "incremental": false,
  "inject_doc_toc": false,
  "dry_run": false,
  "status": "complete | partial_failure | dry_run",
  "summary": { "scanned": 0, "total": 0, "written": 0, "skipped": 0, "deleted": 0, "failed": 0 },
  "docs": [
    {
      "title": "…", "filename": "…", "doc_id": "abc123",
      "size": 1234, "word_count": 567,
      "date": "2024-01-01 12:00:00", "date_sort": "20240101120000",
      "date_source": "filename | content | mtime",
      "summary": "…", "tags": ["南京"],
      "toc_items": 3, "output": "doc-abc123/index.html"
    }
  ],
  "warnings": ["name.html:read_failed"],
  "elapsed_seconds": 1.23,
  "report_path": "…"        // 仅 --report
}
```

## 退出码

- `0`：批次完成（`complete`/`dry_run`）且无单文件失败。
- `2`：批次运行但至少一个文件失败（`partial_failure`）。
- `1`：无法启动（参数/目录边界错误、输入目录不存在）。

## 错误码

- 启动错误（退出 1，`--json` 时输出 `{"status":"error","reason":...}`）：
  `input_not_found`、`output_equals_input`、`output_within_input`、`invalid_jobs_value`、
  `unexpected_error`。
- 单文件失败（计入 `warnings`，使批次成为 `partial_failure`）：`read_failed`、`unexpected_error`。
