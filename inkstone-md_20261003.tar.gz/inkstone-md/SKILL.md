---
name: inkstone-md
description: "Batch upload Markdown files from a directory into the default Inkstone notes service (https://md.allez.cc.cd) via its MCP API. Use when the user wants to submit/push .md files to Inkstone."
version: 1.0.0
author: Muse
license: MIT
metadata:
  tags: [markdown, inkstone, notes, batch-upload, mcp]
  category: productivity
---

# Inkstone Markdown Batch Upload

把指定目录里的 Markdown 文档批量提交到默认的 Inkstone 笔记服务。

## 默认目标

- **服务 URL**: `https://md.allez.cc.cd/mcp`（MCP JSON-RPC，SSE 返回）
- **默认 folder**: `Notes`（`01m2mrk9wth9y55961cxxmfarm`），在脚本顶部 `DEFAULT_IMPORT_FOLDER_ID` 统一维护
- **鉴权**: Bearer API Key，脚本内嵌默认值；可用环境变量 `INKSTONE_API_KEY` 覆盖

## 运行环境

脚本只依赖标准库 + `curl`（系统自带），用 venv 的 Python 运行：

```bash
PY=~/lavoro/venv/bin/python
CLIENT=~/workspace/skills/inkstone-md/scripts/inkstone_client_optimized.py
```

## 核心用法：批量上传目录

```bash
# 上传目录下所有 .md/.markdown（默认进 Notes folder）
$PY $CLIENT create "/path/to/md_dir"

# 递归包含子目录
$PY $CLIENT create "/path/to/md_dir" --recursive

# 指定目标 folder
$PY $CLIENT create "/path/to/md_dir" --folder-id <folder_id>

# 上传单个文件
$PY $CLIENT create "/path/to/note.md"

# 忽略断点、强制重传；遇错即停
$PY $CLIENT create "/path/to/md_dir" --no-resume --stop-on-error
```

行为说明：
- 文件名（去扩展名）自动作为笔记标题。
- 断点续传：源目录下生成 `.inkstone-import.jsonl`，再次运行自动跳过已成功的；`--no-resume` 强制重传。
- 逐个上传并打印进度、成功/跳过/失败统计与耗时。

## 辅助命令

```bash
$PY $CLIENT folders                                  # 列出所有 folder（含 id）
$PY $CLIENT search "关键词" --folder Notes             # 搜索笔记
$PY $CLIENT download --folder-id <id> --output DIR   # 下载整个 folder
$PY $CLIENT download <note_id>                       # 下载单篇笔记
$PY $CLIENT create-folder "新文件夹" --icon "📚"       # 新建 folder
$PY $CLIENT update <note_id> ./new.md                # 用本地 md 更新笔记
```

## 本机适配说明（相对原版 tar 包的改动）

1. **传输层改用 curl**：本机 Python urllib 经出口代理访问该 MCP 端点时，
   SSE chunked 流会被截断（`http.client.IncompleteRead`），curl 可完整收下响应。
   业务逻辑（MCP 方法、参数、断点、进度）与原版完全一致。
2. **API Key 必须通过环境变量传入**：`export INKSTONE_API_KEY=<your-key>`，未设置则鉴权失败。
3. `download` 默认根目录仍是 `~/Downloads/inkstone_md`（`Path.home()` 跨平台）。

## 安全提示

- 脚本内嵌的 API Key 曾在聊天记录中出现过（原包 README 亦有提醒）。
  建议在 Inkstone 后台撤销并生成新 Key，然后 `export INKSTONE_API_KEY=新key` 或替换脚本默认值。
- 不要把 Key 输出到聊天记录、日志或提交到公开仓库。

## 触发时机

当用户说"把这些 md 传到 Inkstone / 提交到默认 URL / 上传笔记"之类，
且意图是批量上传 Markdown 到 Inkstone 时使用本 skill。
注意与 `md-upload` skill 的区别：那个是 md2mindmap 渲染 API，本 skill 是 Inkstone 笔记服务。
