#!/usr/bin/env python3
"""Live, no-API-key 12306 direct-train query.

This deliberately supports search only. It does not log in, book, or pay.
"""
from __future__ import annotations

import argparse
import gzip
import json
import re
import sys
import urllib.parse
import urllib.request
from datetime import datetime
from http.cookiejar import CookieJar
from zoneinfo import ZoneInfo

BASE = "https://kyfw.12306.cn"
STATION_JS = f"{BASE}/otn/resources/js/framework/station_name.js"
UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/131 Safari/537.36"
HEADERS = {
    "User-Agent": UA,
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Referer": f"{BASE}/otn/leftTicket/init",
    "X-Requested-With": "XMLHttpRequest",
}

# 12306's pipe-delimited response fields used by this script.
FIELD = {
    "train_no": 2,
    "train_code": 3,
    "from_code": 6,
    "to_code": 7,
    "start_time": 8,
    "arrive_time": 9,
    "duration": 10,
    "start_date": 13,
    "yz": 29,
    "ze": 30,
    "zy": 31,
    "swz": 32,
    "srrb": 33,
    "price_info": 39,
    "flags": 46,
    "seat_types": 35,
}
SEATS = {
    "9": ("商务座", "swz"), "P": ("特等座", "tz"), "M": ("一等座", "zy"),
    "D": ("优选一等座", "zy"), "O": ("二等座", "ze"), "S": ("二等包座", "ze"),
    "4": ("软卧", "rw"), "I": ("一等卧", "rw"), "F": ("动卧", "rw"),
    "3": ("硬卧", "yw"), "J": ("二等卧", "yw"), "2": ("软座", "rz"),
    "1": ("硬座", "yz"), "W": ("无座", "wz"), "H": ("其他", "qt"),
}
STATUS_FIELDS = {"swz": 32, "zy": 31, "ze": 30, "yz": 29, "yw": 28, "rw": 23, "wz": 26}


def fail(message: str) -> None:
    print(f"错误：{message}", file=sys.stderr)
    raise SystemExit(2)


def get_opener() -> urllib.request.OpenerDirector:
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(CookieJar()))


def request(opener: urllib.request.OpenerDirector, url: str, params: dict[str, str] | None = None) -> bytes:
    if params:
        url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        with opener.open(req, timeout=25) as response:
            body = response.read()
            if response.headers.get("Content-Encoding", "").lower() == "gzip":
                body = gzip.decompress(body)
            return body
    except Exception as exc:
        fail(f"访问 12306 失败（可能是网络、频率限制或站点临时不可用）：{exc}")


def text_request(opener: urllib.request.OpenerDirector, url: str, params: dict[str, str] | None = None) -> str:
    return request(opener, url, params).decode("utf-8-sig", errors="replace")


def load_stations(opener: urllib.request.OpenerDirector) -> tuple[dict[str, dict[str, str]], dict[str, list[dict[str, str]]]]:
    raw = text_request(opener, STATION_JS)
    match = re.search(r"station_names\s*=\s*'([^']+)'", raw)
    if not match:
        fail("无法解析 12306 车站数据")
    stations: dict[str, dict[str, str]] = {}
    cities: dict[str, list[dict[str, str]]] = {}
    parts = match.group(1).split("|")
    for i in range(0, len(parts) - 9, 10):
        if not parts[i].startswith("@"):
            continue
        item = {
            "name": re.sub(r"\s+", "", parts[i + 1]),
            "code": parts[i + 2],
            "pinyin": parts[i + 3],
            "short": parts[i + 4],
            "city": re.sub(r"\s+", "", parts[i + 7]),
        }
        if item["code"]:
            stations[item["code"]] = item
            if item["city"]:
                cities.setdefault(item["city"], []).append(item)
    if not stations:
        fail("12306 车站数据为空")
    return stations, cities


def resolve_station(value: str, stations: dict[str, dict[str, str]], cities: dict[str, list[dict[str, str]]]) -> dict[str, str]:
    value = value.strip()
    upper = value.upper()
    if upper in stations:
        return stations[upper]
    normalized = re.sub(r"\s+", "", value.removesuffix("站"))
    for item in stations.values():
        if item["name"] == normalized:
            return item
    candidates = cities.get(normalized, [])
    if candidates:
        # Prefer the station whose name equals the city; otherwise the first main station.
        return next((item for item in candidates if item["name"] == normalized), candidates[0])
    fail(f"找不到车站或城市：{value}")


def get_query_path(opener: urllib.request.OpenerDirector) -> str:
    html = text_request(opener, f"{BASE}/otn/leftTicket/init")
    match = re.search(r"CLeftTicketUrl\s*=\s*'([^']+)'", html)
    return "/otn/" + match.group(1).lstrip("/") if match else "/otn/leftTicket/queryG"


def status(value: str) -> str:
    value = (value or "").strip()
    if value.isdigit():
        return "无票" if value == "0" else f"余{value}张"
    if value in {"有", "充足"}:
        return "有票"
    if value in {"无", "--", ""}:
        return "无票"
    if value == "候补":
        return "候补"
    return value


def parse_prices(row: list[str]) -> list[dict[str, object]]:
    encoded = row[FIELD["price_info"]] if len(row) > FIELD["price_info"] else ""
    result: list[dict[str, object]] = []
    for i in range(0, len(encoded) - 9, 10):
        chunk = encoded[i : i + 10]
        try:
            code = chunk[0]
            price = int(chunk[1:6]) / 10
        except ValueError:
            continue
        if code not in SEATS:
            continue
        name, short = SEATS[code]
        seat_index = STATUS_FIELDS.get(short)
        result.append({"seat": name, "price": price, "availability": status(row[seat_index] if seat_index is not None and len(row) > seat_index else "")})
    return result


def parse_row(raw: str, name_map: dict[str, str]) -> dict[str, object] | None:
    row = raw.split("|")
    if len(row) < 40 or not row[FIELD["train_code"]]:
        return None
    from_code = row[FIELD["from_code"]]
    to_code = row[FIELD["to_code"]]
    return {
        "train": row[FIELD["train_code"]],
        "from": name_map.get(from_code, from_code),
        "to": name_map.get(to_code, to_code),
        "departure": row[FIELD["start_time"]],
        "arrival": row[FIELD["arrive_time"]],
        "duration": row[FIELD["duration"]],
        "date": row[FIELD["start_date"]],
        "prices": parse_prices(row),
        "tags": [tag for tag in ("复兴号" if len(row) > FIELD["flags"] and "1" in row[FIELD["flags"]].split("#")[:2] else "",) if tag],
    }


def search(args: argparse.Namespace) -> list[dict[str, object]]:
    opener = get_opener()
    stations, cities = load_stations(opener)
    origin = resolve_station(args.from_station, stations, cities)
    destination = resolve_station(args.to_station, stations, cities)
    path = get_query_path(opener)
    payload = json.loads(text_request(opener, f"{BASE}{path}", {
        "leftTicketDTO.train_date": args.date,
        "leftTicketDTO.from_station": origin["code"],
        "leftTicketDTO.to_station": destination["code"],
        "purpose_codes": "ADULT",
    }))
    data = payload.get("data") or {}
    rows = data.get("result") or []
    if not isinstance(rows, list):
        fail("12306 返回了无法识别的结果")
    name_map = data.get("map") or {code: item["name"] for code, item in stations.items()}
    results = [item for raw in rows if isinstance(raw, str) and (item := parse_row(raw, name_map))]
    if args.kind:
        kinds = tuple(args.kind.upper())
        results = [item for item in results if str(item["train"])[0].upper() in kinds or ("G" in kinds and str(item["train"])[0].upper() == "C")]
    results.sort(key=lambda item: str(item["departure"]))
    return results[: args.limit] if args.limit else results


def main() -> int:
    parser = argparse.ArgumentParser(description="无需 API Key 的 12306 直达车次查询")
    parser.add_argument("--date", required=True, help="出发日期 YYYY-MM-DD")
    parser.add_argument("--from", dest="from_station", required=True, help="出发城市或车站")
    parser.add_argument("--to", dest="to_station", required=True, help="到达城市或车站")
    parser.add_argument("--kind", default="", help="车次类型，例如 G、D、K；G 同时包含 C")
    parser.add_argument("--limit", type=int, default=10, help="最多返回数量，0 表示全部")
    parser.add_argument("--format", choices=("text", "json"), default="text")
    args = parser.parse_args()
    try:
        requested = datetime.strptime(args.date, "%Y-%m-%d").date()
        today = datetime.now(ZoneInfo("Asia/Shanghai")).date()
        if requested < today:
            fail("出发日期不能早于今天")
        results = search(args)
        if args.format == "json":
            print(json.dumps({"source": "12306", "queried_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(), "results": results}, ensure_ascii=False))
        elif results:
            for item in results:
                seats = "；".join(f"{seat['seat']} {seat['price']}元/{seat['availability']}" for seat in item["prices"])
                print(f"{item['train']}  {item['from']} → {item['to']}  {item['departure']} → {item['arrival']}  历时{item['duration']}")
                if seats:
                    print(f"  {seats}")
        else:
            print("没有查询到直达车次；可改查中转方案或放宽车次类型。")
        return 0
    except SystemExit:
        raise
    except Exception as exc:
        fail(str(exc))
    return 2


if __name__ == "__main__":
    main()
