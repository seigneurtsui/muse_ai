from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import Mock, patch

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import srt_ass as app
from subtitles import Cue, SubtitleError, parse_srt
from translation import Translator, validate_translation

SRT = "7\n00:00:00,505 --> 00:00:02,500\nFirst line\nSecond line\n\n9\n00:00:03,000 --> 00:00:04,001\n2026\n"


class FakeAI:
    model = "synthetic-model"
    provider = "omnirush"

    def __init__(self):
        self.calls = 0
        self.active = 0
        self.peak = 0
        self.lock = threading.Lock()

    def request(self, system, payload):
        with self.lock:
            self.calls += 1
            self.active += 1
            self.peak = max(self.active, self.peak)
        time.sleep(0.015)
        with self.lock:
            self.active -= 1
        if "text" in payload:
            return {"keywords": ["First"]}
        return {"items": [{"index": item["index"], "text": "Translated " + item["source"]} for item in payload["items"]]}


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.input = self.root / "inputs"
        self.input.mkdir()
        self.file = self.input / "demo.srt"
        self.file.write_text(SRT, encoding="utf-8")
        self.output = self.root / "output"

    def args(self, *options):
        return app.parser().parse_args([str(self.input), "--output-root", str(self.output), *options])

    def translator(self, client=None, **options):
        return Translator(client or FakeAI(), normalize="off", **options)

    def test_plain_conversion_no_ai_no_notifications_and_no_overwrite(self):
        original = self.file.read_bytes()
        with patch("omnirush_ai.OmniRushAI", side_effect=AssertionError("AI should not be initialized")), patch.object(app.subprocess, "run", side_effect=AssertionError("external process")):
            report = app.run(self.args())
        self.assertTrue(report["ok"])
        self.assertEqual(report["ai"]["requests"], 0)
        self.assertEqual(report["notification"]["status"], "disabled")
        batch = Path(report["batch_dir"])
        self.assertEqual(batch.stat().st_mode & 0o777, 0o700)
        generated = batch / next(p for p in report["files"][0]["outputs"] if p.endswith(".srt"))
        self.assertEqual(parse_srt(generated.read_text()), parse_srt(SRT))
        self.assertEqual(generated.stat().st_mode & 0o777, 0o600)
        self.assertEqual(self.file.read_bytes(), original)
        again = app.run(self.args())
        self.assertNotEqual(again["batch_dir"], report["batch_dir"])

    def test_dry_run_never_creates_output_or_calls_ai_notifier(self):
        with patch("omnirush_ai.OmniRushAI", side_effect=AssertionError("AI")), patch.object(app, "notify_summary", side_effect=AssertionError("notify")):
            report = app.run(self.args("--languages", "source,en", "--ai-highlight", "--notify-all", "--dry-run"))
        self.assertTrue(report["ok"])
        self.assertTrue(report["ai_may_be_required"])
        self.assertFalse(self.output.exists())

    def test_bad_file_isolated_and_report_persisted(self):
        (self.input / "bad.srt").write_text("invalid")
        report = app.run(self.args())
        self.assertEqual((report["succeeded"], report["failed"]), (1, 1))
        self.assertFalse(report["ok"])
        self.assertEqual(json.loads((Path(report["batch_dir"]) / "report.json").read_text())["failed"], 1)
        self.assertFalse(list(Path(report["batch_dir"]).glob(".staging-*")))

    def test_recursive_case_insensitive_inputs_dedup_and_output_exclusion(self):
        nested = self.input / "sub"
        nested.mkdir()
        other = nested / "demo.SRT"
        other.write_text(SRT)
        generated = self.input / "generated"
        generated.mkdir()
        (generated / "old.srt").write_text(SRT)
        found = app.collect_inputs([str(self.input), str(self.file)], True, generated)
        self.assertEqual(set(found), {self.file.resolve(), other.resolve()})
        self.assertNotEqual(app.file_key(self.file), app.file_key(other))
        self.assertEqual(app.collect_inputs([str(self.file)], False, self.output), [self.file.resolve()])

    def test_same_stem_different_folders_do_not_collide(self):
        nested = self.input / "sub"
        nested.mkdir()
        (nested / "demo.srt").write_text(SRT)
        report = app.run(self.args("--recursive"))
        self.assertEqual(report["succeeded"], 2)
        folders = {Path(file["outputs"][0]).parent for file in report["files"]}
        self.assertEqual(len(folders), 2)

    def test_merged_and_independent_reuse_one_translation(self):
        client = FakeAI()
        args = self.args("--languages", "source,en", "--separate-languages", "en", "--normalize-chinese", "off")
        with patch("omnirush_ai.OmniRushAI", return_value=client):
            report = app.run(args)
        self.assertTrue(report["ok"])
        self.assertEqual(client.calls, 1)
        outputs = report["files"][0]["outputs"]
        self.assertEqual(sum(name.endswith(".ass") for name in outputs), 2)
        merged = Path(report["batch_dir"]) / next(name for name in outputs if name.endswith("source.en.srt"))
        self.assertIn("First line\nSecond line\nTranslated First line\nSecond line", merged.read_text())

    def test_missing_translation_never_commits_partial_variant(self):
        args = self.args("--languages", "source,en", "--separate-languages", "source")
        client = FakeAI()
        client.request = Mock(return_value={"items": []})
        with patch("omnirush_ai.OmniRushAI", return_value=client):
            report = app.run(args)
        self.assertEqual(report["failed"], 1)
        batch = Path(report["batch_dir"])
        self.assertEqual([p.name for p in batch.iterdir()], ["report.json"])

    def test_translation_index_count_types_and_empty_after_cleanup(self):
        invalid = [{"items": []}, {"items": [{"index": True, "text": "text"}]},
                   {"items": [{"text": "text"}]}, {"items": [{"index": 1, "text": "text"}]},
                   {"items": [{"index": 0, "text": "..."}]}, {"items": [{"index": 0, "text": ""}]}]
        for value in invalid:
            with self.subTest(value=value), self.assertRaises(SubtitleError):
                validate_translation(value, ["source"], "en")
        reordered = {"items": [{"index": 1, "text": "two"}, {"index": 0, "text": "one..."}]}
        self.assertEqual(validate_translation(reordered, ["source", "another"], "en"), ["one", "two"])
        self.assertEqual(validate_translation({"items": [{"index": 0, "text": "one..."}]}, ["source..."], "en"), ["one..."])

    def test_translation_blank_lines_cannot_break_srt_blocks(self):
        translated = validate_translation({"items": [{"index": 0, "text": "first\n\nsecond"}]}, ["source"], "en")
        self.assertEqual(translated, ["first\nsecond"])

    def test_thread_local_clients_are_not_shared_between_ai_workers(self):
        clients = []
        def factory():
            client = FakeAI()
            clients.append(client)
            return client
        translator = self.translator(FakeAI(), ai_workers=2, client_factory=factory)
        with ThreadPoolExecutor(max_workers=4) as pool:
            list(pool.map(lambda i: translator.translate([Cue(str(i), 0, 1000, f"unique {i}")], ["en"]), range(8)))
        self.assertGreater(len(clients), 1)
        self.assertTrue(all(client.peak == 1 for client in clients))
        self.assertEqual(translator.served_models, {"synthetic-model"})

    def test_chunk_bounds_and_request_counts(self):
        client = FakeAI()
        translator = self.translator(client, batch_size=2, batch_chars=100)
        cues = [Cue(str(i), i * 1000, i * 1000 + 500, f"cue {i}") for i in range(5)]
        result, warnings = translator.translate(cues, ["en"])
        self.assertEqual(client.calls, 3)
        self.assertEqual(len(result["en"]), 5)
        with self.assertRaises(SubtitleError):
            list(translator.chunks(["x" * 101]))

    def test_inflight_dedup_and_disk_cache_readback(self):
        client = FakeAI()
        cache = self.root / "cache"
        translator = self.translator(client, cache_dir=cache)
        cues = parse_srt(SRT)
        with ThreadPoolExecutor(max_workers=4) as pool:
            values = list(pool.map(lambda _: translator.translate(cues, ["en"]), range(4)))
        self.assertEqual(client.calls, 1)
        self.assertEqual(translator.stats["memory_hits"], 3)
        self.assertTrue(all(value == values[0] for value in values))
        cached = next(cache.glob("*.json"))
        self.assertEqual(cached.stat().st_mode & 0o777, 0o600)
        second = self.translator(client, cache_dir=cache)
        second.translate(cues, ["en"])
        self.assertEqual(client.calls, 1)
        self.assertEqual(second.stats["disk_hits"], 1)
        cached.write_text("broken json")
        self.translator(client, cache_dir=cache).translate(cues, ["en"])
        self.assertEqual(client.calls, 2)

    def test_ai_parallelism_is_bounded(self):
        client = FakeAI()
        translator = self.translator(client, ai_workers=2)
        with ThreadPoolExecutor(max_workers=6) as pool:
            list(pool.map(lambda i: translator.translate([Cue(str(i), 0, 1000, f"unique {i}")], ["en"]), range(6)))
        self.assertGreater(client.peak, 1)
        self.assertLessEqual(client.peak, 2)

    def test_explicit_retries_not_silent_fallback(self):
        client = FakeAI()
        client.request = Mock(side_effect=[{"items": []}, {"items": [{"index": 0, "text": "translated"}]}])
        result, _ = self.translator(client, attempts=2).translate([Cue("1", 0, 1000, "source")], ["en"])
        self.assertEqual(result["en"], ["translated"])
        self.assertEqual(client.request.call_count, 2)

    def test_chinese_conversion_preserves_numeric_cues(self):
        class FakeConverter:
            def __init__(self, _): pass
            def convert(self, text): return text.replace("学", "學")
        client = FakeAI()
        translator = self.translator(client, source_language="zh-Hans")
        translator.converter_type = FakeConverter
        translator.normalize = "auto"
        translated, _ = translator.translate([Cue("1", 0, 1000, "学习"), Cue("2", 1000, 2000, "2026")], ["zh-Hant"])
        self.assertEqual(translated["zh-Hant"], ["學习", "2026"])
        self.assertEqual(client.calls, 0)

    def test_no_guessing_mixed_source_language_for_opencc(self):
        client = FakeAI()
        translator = self.translator(client)
        translator.converter_type = Mock(side_effect=AssertionError("must not use OpenCC as a translator without source hint"))
        translator.translate([Cue("1", 0, 1000, "中文"), Cue("2", 1000, 2000, "English")], ["zh-Hant"])
        self.assertEqual(client.calls, 1)

    def test_strict_opencc_missing_fails_before_ai(self):
        client = FakeAI()
        translator = self.translator(client)
        translator.normalize = "strict"
        translator.converter_type = None
        with self.assertRaises(SubtitleError):
            translator.translate(parse_srt(SRT), ["zh-Hant"])
        self.assertEqual(client.calls, 0)

    def test_keyword_extraction_explicit_and_grounded(self):
        client = FakeAI()
        client.request = Mock(return_value={"keywords": ["First", "invented"]})
        translator = self.translator(client)
        self.assertEqual(translator.keywords(["First line"], maximum=3), ["First"])
        self.assertEqual(client.request.call_count, 1)

    def test_safe_exception_does_not_copy_private_provider_errors(self):
        report = app.safe_error(RuntimeError("PRIVATE SUBTITLE SECRET TOKEN"))
        self.assertNotIn("PRIVATE", report)
        self.assertNotIn("TOKEN", report)

    def test_notify_disabled_dry_run_and_live_summary_only(self):
        report = {"total": 2, "succeeded": 2, "failed": 0, "files": [{"source": "PRIVATE_FILENAME", "text": "PRIVATE_TEXT"}]}
        script = self.root / "notify.py"
        script.write_text("# fixture")
        with patch.object(app.subprocess, "run") as run:
            self.assertEqual(app.notify_summary(report, self.args(), script)["status"], "disabled")
            run.assert_not_called()
        ready = subprocess.CompletedProcess([], 0, json.dumps({"status": "dry_run"}), "")
        accepted = subprocess.CompletedProcess([], 0, json.dumps({"status": "complete", "accepted": 2, "results": []}), "")
        with patch.object(app.subprocess, "run", return_value=ready) as run:
            result = app.notify_summary(report, self.args("--notify-channels", "bark,telegram", "--notify-dry-run"), script)
            self.assertEqual(result["status"], "dry_run")
            self.assertEqual(run.call_count, 1)
        with patch.object(app.subprocess, "run", side_effect=[ready, accepted]) as run:
            result = app.notify_summary(report, self.args("--notify-channels", "bark,telegram"), script)
            self.assertEqual(result["status"], "accepted")
            self.assertEqual(run.call_count, 2)
            self.assertNotIn("PRIVATE", str(run.call_args_list))
            self.assertIn("bark,telegram", run.call_args.args[0])

    def test_notifier_failure_keeps_conversion_results(self):
        with patch.object(app, "notify_summary", return_value={"status": "failed"}):
            report = app.run(self.args("--notify-all"))
        self.assertTrue(report["ok"])
        self.assertEqual(report["notification"]["status"], "failed")
        self.assertEqual(report["succeeded"], 1)

    def test_offset_and_cli_exit_codes(self):
        report = app.run(self.args("--offset-ms", "500"))
        path = Path(report["batch_dir"]) / next(v for v in report["files"][0]["outputs"] if v.endswith(".srt"))
        self.assertEqual(parse_srt(path.read_text())[0].start, 1005)
        report = app.run(self.args("--offset-ms", "-1000"))
        self.assertEqual(report["failed"], 1)
        proc = subprocess.run([sys.executable, str(SCRIPTS / "srt_ass.py"), str(self.input), "--output-root", str(self.output), "--workers", "0"], text=True, capture_output=True)
        self.assertEqual(proc.returncode, 2)
        self.assertEqual(json.loads(proc.stdout)["status"], "configuration_error")


if __name__ == "__main__":
    unittest.main()
