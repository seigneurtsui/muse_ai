---
name: auto-video-editing-pipeline
description: >-
  批量处理指定目录中的本地视频：ffprobe 检查、faster-whisper-stt 离线转写、
  erratum-correction 字幕勘误、s2t 简繁转换、srt-ass-studio ASS 样式化、
  可配置 badge、FFmpeg 渲染、预览与全片 QA，并可通过
  multiple-channel-notifier 发送批次摘要。适用于批量加字幕、短视频粗剪、
  横竖屏输出、变速、裁切、字幕样式和本地成片；不自动上传或发布视频。
version: 2.0.0
metadata:
  short-description: Local batch video editing with reusable STT, correction, subtitles, rendering, QA, and optional notifications
  dependencies:
    - faster-whisper-stt
    - erratum-correction
    - s2t
    - srt-ass-studio
    - multiple-channel-notifier
    - ffmpeg
    - ffprobe
---

# Auto Video Editing Pipeline

这是一个**批量、本地、可恢复**的视频编辑技能。它以 `/tmp/auto_video_pipeline/`
的成熟交付流程为基础，吸收 `/tmp/auto-video-editing-pipeline/` 的项目契约与 QA
规则，并移植 `chatgpt-short-video-editor` 的八步顺序、源文件保护、短视频预览门和
phrase-level STT 边界纪律。

## 硬性流程

```text
ffprobe intake
  → faster-whisper-stt（本地、断点、SRT/TXT）
  → erratum-correction（当前会话模型；白名单进入校对上下文）
  → s2t（仅在目标字形不同且明确时调用）
  → srt-ass-studio（SRT → ASS，样式/动效/高亮/双语可选）
  → badge 注入（精确时间、位置、时长）
  → FFmpeg 粗剪/变速/缩放/响度/烧录
  → preview / full-decode / frames / QA report
  → multiple-channel-notifier（仅明确指定渠道时）
```

所有源视频保持不变。所有中间文件、请求、响应、报告和成片写入独立批次目录。
默认关闭真实通知；`--notify-channels`、`--notify-all` 或 `--notify-dry-run` 才会
启用通知流程。不会读取、复制或硬编码外部 AI 密钥。

## 快速开始

入口脚本：

```bash
PIPE="$HOME/.config/omnirush/skills/auto-video-editing-pipeline/scripts/auto_video_pipeline.py"

# 先只探测并生成处理计划，不写出片文件
python3 "$PIPE" "/path/to/videos" --dry-run

# 批量处理目录：中文字幕 + cinematic ASS + H.264/AAC + QA
python3 "$PIPE" "/path/to/videos" --language zh --resume

# 竖屏短视频：保留语音，字幕最后烧录，生成预览和正式成片
python3 "$PIPE" "/path/to/videos" \
  --canvas vertical --preset cinematic --effect fade \
  --preview --resume

# 明确要求繁体字幕时，使用成熟 s2t 适配层
python3 "$PIPE" "/path/to/videos" \
  --subtitle-lang zh-Hant --source-script zh-Hans --resume

# 自定义 badge：从 0.4s 显示到 2.8s，右上角，精确 2.4s
python3 "$PIPE" "/path/to/videos" \
  --badge-text "高能时刻" --badge-start 0.4 --badge-end 2.8 \
  --badge-position top-right --badge-anim pop
```

### 当前会话 AI 勘误的接续

`erratum-correction` 遇到 AI 请求时会返回退出码 `10`，这表示“等待当前
OmniRush 会话写入 response”，不是失败。读取终端 JSON 中的 `pending_requests`，
完整读取每个 `request_path`，严格按其中的 schema 将结果写入 `response_path`，然后
用同一个批次继续：

```bash
python3 "$PIPE" --resume-batch "/实际的批次目录"
```

不要重新输入源目录创建新批次，也不要用外部 provider、HTTP API 或另一模型替代。

## 输入与输出

- 输入可以是一个视频、多个视频路径或目录；目录默认递归扫描。
- 支持 `.mp4 .mov .mkv .avi .webm .m4v .ts .flv .wmv`。
- 默认输出：`~/Downloads/auto_video_editing_pipeline/<YYYYMMDD_HHMM_slug>/`。
- 每个视频独立处理，不因一个文件失败而覆盖或丢弃其他文件。
- 断点时使用 `--resume-batch <batch_dir>`，或在首次命令中使用 `--resume` 让各阶段
  复用已经验证的产物。
- 中文主字幕默认字号为 `200`，默认字体文件为
  `~/Library/Fonts/字魂龙腾楷书.ttf`；字体文件会自动解析为 fontconfig/libass
  字体族名。可用 `--subtitle-font-file` 或 `--subtitle-font-name` 切换字体。

批次结构：

```text
batch/
├── batch.json                  # 输入哈希、参数、工具版本、阶段状态
├── state.json                  # 可恢复状态快照
├── project.md                  # 机器/人工决策与风险记录
├── stt/                        # faster-whisper-stt 适配层的共享模型批次
├── erratum/                    # 私有勘误批次、pending request、response、报告
├── videos/<video-id>/
│   ├── probe.json
│   ├── transcripts/subtitle_clean.srt
│   ├── transcripts/transcript_merged.txt
│   ├── corrections/<name>_corrected.srt
│   ├── subtitles/<name>.srt
│   ├── subtitles/<name>.ass
│   ├── preview.mp4              # 选择 --preview 或 --preview-first 时生成
│   ├── final.mp4
│   └── qa/QA报告.md + report.json + frames/
└── batch_report.json
```

## 关键边界

1. **STT**：只通过已安装的 `faster-whisper-stt`；输出按 phrase-level 处理并标记
   lower-confidence。裁切点必须落在字幕短语边缘；默认不自动在短语中间切断。
2. **字幕纠错**：只通过已安装的 `erratum-correction`。本技能的
   `ai_whitelist.txt` 会被适配层作为 `context.protected_terms` 传给当前会话模型，
   同时保留成熟技能的结构校验、请求接续、报告和原文不覆盖规则。
3. **简繁转换**：不自行导入 OpenCC。只有 `--source-script` 与
   `--subtitle-lang` 明确冲突时调用已安装的 `s2t` CLI。
4. **ASS**：不复制旧的 SRT→ASS 实现；直接调用 `srt-ass-studio`，包括预设、折行、
   高亮、双语、动效和样式校验。
5. **Badge**：在成熟 ASS 产物之后注入独立 `Badge` 样式，允许独立控制文本、开始时间、
   结束时间、位置、字体、字号、颜色、描边、淡入淡出和 pop 动画。
6. **通知**：通过 `multiple-channel-notifier`，先执行相同消息的 `--dry-run`，再在
   用户明确给出渠道时发送。通知正文只包含计数和状态，不含字幕正文、密钥或本地路径。
7. **QA**：没有 `final.mp4` 的完整解码、分辨率/帧率/音频检查、抽帧和字幕时间检查，
   不称为完成。预览和正式成片必须分开记录。

## 常用参数

| 参数 | 说明 |
|---|---|
| `--resume-batch PATH` | 继续同一批次，尤其用于 AI 勘误请求接续 |
| `--resume` | 复用同批次内已成功阶段；首次运行也建议开启 |
| `--language zh` | faster-whisper 语言；省略则自动识别 |
| `--model PATH_OR_HF` | 传给 faster-whisper-stt 的模型；默认本地 large-v3-turbo int8 |
| `--chunk-duration SEC` | STT 长音频分片，默认 900 |
| `--subtitle-lang zh-Hans/zh-Hant` | 输出字形目标 |
| `--source-script zh-Hans/zh-Hant/auto` | 输入字形；默认 `zh-Hans`，因此目标 `zh-Hant` 会走 s2t；不确定时用 `auto` 跳过转换 |
| `--preset` | 传给 srt-ass-studio，如 `cinematic`、`vertical`、`karaoke` |
| `--effect` | `static`、`fade`、`slide-*`、`karaoke`、`typewriter` 等 |
| `--highlight TERM` | 可重复，传给 srt-ass-studio 做字幕高亮 |
| `--canvas auto/vertical/landscape` | 输出画布；auto 使用源视频尺寸 |
| `--speed N` | 全片速度；字幕按输出时间轴重算 |
| `--trim-start/--trim-end` | 源时间轴裁切，须由用户确认且尽量贴合 phrase 边界 |
| `--loudnorm` | 用 FFmpeg loudnorm 统一音量 |
| `--preview` | 同时输出低分辨率预览 |
| `--force-render` | 复用 STT/勘误结果，重新生成字幕、成片和 QA |
| `--subtitle-font-size 200` | 中文主字幕字号，默认 200 |
| `--subtitle-font-file PATH` | 中文主字幕字体文件，默认字魂龙腾楷书 |
| `--subtitle-font-name NAME` | 直接指定 libass/fontconfig 字体族名 |
| `--highlight-font-file PATH` | highlight keyword 独立字体文件 |
| `--highlight-font-name NAME` | highlight keyword 独立字体族名 |
| `--highlight-size N` | highlight keyword 独立字号 |
| `--highlight-color RRGGBB` | highlight keyword 独立字色 |
| `--badge-font-file PATH` | badge 独立字体文件 |
| `--badge-font-name NAME` | badge 独立字体族名 |
| `--badge-size N` / `--badge-color RRGGBB` | badge 独立字号和字色 |
| `--badge-*` | badge 的文本、时间、位置、样式和动画 |
| `--notify-channels a,b` | 明确指定 notifier 实例；不指定则不发送 |
| `--notify-dry-run` | 只检查 notifier，不发送 |

完整参数：

```bash
python3 "$PIPE" --help
```

## 白名单文件

默认文件：`ai_whitelist.txt`。每行一个词条，支持注释和三段式备注：

```text
# 词 | 类别 | 备注
襄阳古城 | 地名
护城河 | 地物 | ASR 常误写为"城河"
```

白名单不会被写入公共技能之外的词典，也不会自动发布为正式纠错规则；它只在本批次
勘误请求中作为受保护专名使用。可用 `--whitelist-file` 指定另一份文件。

## 移植的短视频能力

本技能默认采用 `chatgpt-short-video-editor` 的适配规则：八步工作顺序、ffprobe
intake、源素材 immutable、Whisper lower-confidence 标注、短语边界与至少 400ms 静音
优先、预览先于正式输出、最多三次证据驱动修复、字幕作为最后视觉操作、完整 QA 后才
交付。它不默认添加 B-roll、音乐、CTA、上传或发布动作；这些必须由用户另行授权。

参考细节见：

- `references/pipeline.md`
- `references/short-video-rules.md`
- `references/badge.md`
