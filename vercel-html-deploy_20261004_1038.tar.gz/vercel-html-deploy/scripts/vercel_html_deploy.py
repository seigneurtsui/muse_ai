#!/usr/bin/env python3
"""Batch-deploy static HTML to Vercel.

Adapted from the supplied ``deploy_rainmain_2vercel.py`` (the rainman-travel
one-shot deploy script). It keeps that script's two useful ideas — publish a
newest document to the root domain, and archive many documents under stable
``<slug>/`` paths behind a generated, searchable ``/toc/`` index — but turns
them into a general, config-driven batch tool with:

* two modes: ``static`` (ship a directory/file as-is) and ``collection``
  (scan many HTML documents, generate slugs + a TOC index, then deploy);
* content-input fingerprint skip so unchanged sites are not re-deployed;
* bounded parallelism across projects, retry with backoff;
* ``--dry-run`` planning, atomic state, JSON reports;
* credentials read from ``~/.config/freebuff/.env`` (never hard-coded, never
  printed), and a *uniform* token/scope/project CLI for Vercel (v54+).

Examples:
    vercel_html_deploy.py deploy --config vercel.yaml
    vercel_html_deploy.py deploy --config vercel.yaml --only zhongnanshan
    vercel_html_deploy.py deploy --dir ./site --project-name my-site --prod
    vercel_html_deploy.py deploy --config vercel.yaml --dry-run --json
    vercel_html_deploy.py discover --root ~/Downloads/sites --output vercel.yaml
    vercel_html_deploy.py list
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import html
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None  # type: ignore[assignment]


VERSION = "1.0.0"

DEFAULT_ENV_FILE = Path.home() / ".config" / "freebuff" / ".env"
DEFAULT_STATE_NAME = ".vercel_html_deploy_state.json"
DEFAULT_TIMEOUT = 900
DEFAULT_RETRIES = 2
RETRY_BASE_SECONDS = 3.0
MAX_JOBS = 6
HASH_CHUNK_BYTES = 1 << 20
MAX_WARNING_CHARS = 600
HTML_SUFFIXES = (".html", ".htm")
PROJECT_NAME_RE = re.compile(r"^[a-z0-9](?:[a-z0-9._-]{0,98}[a-z0-9])?$")
URL_RE = re.compile(r"https?://[A-Za-z0-9._-]+(?:/[^\s\"'<>]*)?")
SKIP_DIR_NAMES = {".vercel", ".git", "__pycache__", "node_modules"}

log = logging.getLogger("vercel-html-deploy")


class DeployError(Exception):
    """Error carrying a short, log-safe reason code."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def reason(error: BaseException) -> str:
    code = getattr(error, "code", "")
    if isinstance(code, str) and re.fullmatch(r"[a-z][a-z0-9_]{0,79}", code):
        return code
    return "unexpected_error"


# --------------------------------------------------------------------------
# Environment / credentials
# --------------------------------------------------------------------------


def parse_env_file(path: Path) -> dict[str, str]:
    """Parse a minimal ``KEY=VALUE`` env file (spaces around '=' allowed)."""
    values: dict[str, str] = {}
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return values
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key.startswith("export "):
            key = key[len("export ") :].strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        if key:
            values[key] = value
    return values


def load_env_files(paths: list[Optional[str]]) -> list[str]:
    loaded: list[str] = []
    for raw in paths:
        if not raw:
            continue
        path = Path(raw).expanduser()
        if not path.is_file():
            continue
        loaded.append(str(path))
        for key, value in parse_env_file(path).items():
            os.environ.setdefault(key, value)
    return loaded


@dataclass
class Credentials:
    token: Optional[str]
    scope: Optional[str]
    project: Optional[str]
    prod_url: Optional[str]


def credentials() -> Credentials:
    return Credentials(
        token=os.environ.get("VERCEL_TOKEN") or os.environ.get("VERCEL_API_TOKEN"),
        scope=os.environ.get("VERCEL_SCOPE"),
        project=os.environ.get("VERCEL_PROJECT"),
        prod_url=os.environ.get("PROD_URL"),
    )


# --------------------------------------------------------------------------
# Specs and configuration
# --------------------------------------------------------------------------


@dataclass
class DeploymentSpec:
    name: str
    source: str
    mode: str = "static"  # static | collection
    scope: Optional[str] = None
    prod: bool = True
    create_if_missing: bool = True
    archive: Optional[str] = "tgz"
    # collection-only
    prod_url: Optional[str] = None
    title: str = "🗂️ 内容目录"
    subtitle: str = "自动生成的索引页"
    item_label: str = "条目"
    slug_prefix: str = "item"
    slug_algo: str = "md5"
    slug_len: int = 6
    min_bytes: int = 1000
    exclude_email: bool = True
    root_mode: str = "latest"  # latest | none

    def source_path(self) -> Path:
        return Path(self.source).expanduser()

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "source": self.source,
            "mode": self.mode,
            "prod": self.prod,
            "scope": self.scope,
        }


COLLECTION_FIELDS = (
    "prod_url",
    "title",
    "subtitle",
    "item_label",
    "slug_prefix",
    "slug_algo",
    "slug_len",
    "min_bytes",
    "exclude_email",
    "root_mode",
)


def validate_project_name(name: str) -> None:
    if not PROJECT_NAME_RE.match(name or ""):
        raise DeployError(f"invalid_project_name:{name}")


def _spec_from_entry(
    name: str, data: dict[str, Any], base: Path, defaults: dict[str, Any]
) -> DeploymentSpec:
    if not isinstance(data, dict) or "source_dir" not in data:
        raise DeployError(f"invalid_deployment_config:{name}")
    merged = {**defaults, **data}
    source = str(merged["source_dir"])
    candidate = Path(source).expanduser()
    if not candidate.is_absolute():
        candidate = (base / candidate).resolve()
    mode = str(merged.get("mode", "static")).lower()
    if mode not in ("static", "collection"):
        raise DeployError(f"invalid_mode:{name}")
    kwargs: dict[str, Any] = {
        "name": name,
        "source": str(candidate),
        "mode": mode,
        "scope": merged.get("scope"),
        "prod": bool(merged.get("prod", True)),
        "create_if_missing": bool(merged.get("create_if_missing", True)),
        "archive": merged.get("archive", "tgz"),
    }
    for key in COLLECTION_FIELDS:
        if key in merged:
            kwargs[key] = merged[key]
    if data.get("archive") is False or merged.get("archive") in ("", "none", False):
        kwargs["archive"] = None
    return DeploymentSpec(**kwargs)


def load_config(path: str) -> list[DeploymentSpec]:
    config_path = Path(path).expanduser().resolve()
    if not config_path.is_file():
        raise DeployError("config_not_found")
    if yaml is None:
        raise DeployError("yaml_dependency_missing")
    try:
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        raise DeployError("config_parse_failed") from None
    if not isinstance(raw, dict):
        raise DeployError("config_not_a_mapping")
    defaults = raw.get("defaults") or {}
    if not isinstance(defaults, dict):
        raise DeployError("config_defaults_not_a_mapping")
    deployments = raw.get("deployments") or raw.get("projects") or {}
    if not isinstance(deployments, dict) or not deployments:
        raise DeployError("config_has_no_deployments")
    specs: list[DeploymentSpec] = []
    for name, data in deployments.items():
        spec = _spec_from_entry(str(name), data, config_path.parent, defaults)
        validate_project_name(spec.name)
        specs.append(spec)
    return specs


def discover_specs(
    root: str, scope: Optional[str] = None, name_prefix: str = ""
) -> list[DeploymentSpec]:
    root_path = Path(root).expanduser().resolve()
    if not root_path.is_dir():
        raise DeployError("discover_root_not_directory")
    specs: list[DeploymentSpec] = []
    for child in sorted(root_path.iterdir(), key=lambda p: p.name.casefold()):
        if not child.is_dir() or child.name.startswith("."):
            continue
        if not (child / "index.html").is_file():
            continue
        name = re.sub(r"[^a-z0-9._-]+", "-", f"{name_prefix}{child.name}".lower())
        name = name.strip("-._")
        if not name:
            continue
        specs.append(DeploymentSpec(name=name, source=str(child), scope=scope))
    if not specs:
        raise DeployError("discover_found_no_sites")
    return specs


def specs_from_args(args: argparse.Namespace) -> list[DeploymentSpec]:
    creds = credentials()
    if args.config:
        specs = load_config(args.config)
    elif args.discover_root:
        specs = discover_specs(args.discover_root, args.scope, args.name_prefix or "")
    elif args.dir:
        name = args.project_name or creds.project
        if not name:
            raise DeployError("project_name_required")
        validate_project_name(name)
        specs = [
            DeploymentSpec(
                name=name,
                source=str(Path(args.dir).expanduser().resolve()),
                scope=args.scope or creds.scope,
                prod=args.prod if args.prod is not None else True,
                prod_url=creds.prod_url,
            )
        ]
    else:
        raise DeployError("no_input_specified")
    # An explicit --prod/--preview on the CLI overrides the per-entry prod value.
    if getattr(args, "prod", None) is not None:
        for spec in specs:
            spec.prod = bool(args.prod)
    if args.only:
        wanted = {item.strip() for item in args.only.split(",") if item.strip()}
        specs = [spec for spec in specs if spec.name in wanted]
        if not specs:
            raise DeployError("only_matched_nothing")
    return specs


def default_state_path(args: argparse.Namespace) -> Path:
    if args.state:
        return Path(args.state).expanduser()
    if args.config:
        return Path(args.config).expanduser().resolve().parent / DEFAULT_STATE_NAME
    return Path.cwd() / DEFAULT_STATE_NAME


# --------------------------------------------------------------------------
# Collection scanning
# --------------------------------------------------------------------------


@dataclass
class Item:
    identity: str
    source: Path
    slug: str
    title: str
    date: str
    tags: str = ""


def _read_prefix(path: Path, limit: int = 200_000) -> str:
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as handle:
            return handle.read(limit)
    except OSError:
        return ""


def extract_h1(text: str) -> str:
    match = re.search(r"<h1[^>]*>(.*?)</h1>", text, re.IGNORECASE | re.DOTALL)
    if not match:
        return ""
    inner = re.sub(r"<[^>]+>", "", match.group(1))
    return html.unescape(inner).strip()


def extract_date_from_filename(name: str) -> str:
    match = re.match(r"(\d{4})(\d{2})(\d{2})T", Path(name).name)
    if match:
        return f"{match.group(1)}-{match.group(2)}-{match.group(3)}"
    return ""


def slug_for(identity: str, spec: DeploymentSpec) -> str:
    algo = spec.slug_algo.lower()
    if algo == "sha256":
        digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()
    elif algo in ("md5", "sha1"):
        digest = hashlib.new(algo, identity.encode("utf-8")).hexdigest()
    else:
        raise DeployError(f"invalid_slug_algo:{algo}")
    length = max(4, min(40, int(spec.slug_len)))
    prefix = re.sub(r"[^a-zA-Z0-9-]+", "-", spec.slug_prefix).strip("-") or "item"
    return f"{prefix}-{digest[:length]}"


def scan_items(spec: DeploymentSpec) -> list[Item]:
    """Find documents in a collection source (sub-dir index.html + flat HTML)."""
    base = spec.source_path()
    if not base.is_dir():
        raise DeployError("collection_source_not_directory")
    items: list[Item] = []
    seen_titles: set[str] = set()

    for entry in sorted(base.iterdir(), key=lambda p: p.name.casefold()):
        if (
            not entry.is_dir()
            or entry.name in SKIP_DIR_NAMES
            or entry.name.startswith(".")
        ):
            continue
        index_file = entry / "index.html"
        if not index_file.is_file():
            continue
        if index_file.stat().st_size < spec.min_bytes:
            continue
        title = extract_h1(_read_prefix(index_file)) or entry.name
        if title in seen_titles:
            continue
        seen_titles.add(title)
        items.append(
            Item(
                identity=entry.name,
                source=index_file,
                slug=slug_for(entry.name, spec),
                title=title,
                date=extract_date_from_filename(index_file.name),
            )
        )

    for file_path in sorted(base.iterdir(), key=lambda p: p.name.casefold()):
        if not file_path.is_file() or file_path.suffix.lower() not in HTML_SUFFIXES:
            continue
        if file_path.name == "index.html":
            continue
        if spec.exclude_email and "-email" in file_path.name:
            continue
        if file_path.stat().st_size < spec.min_bytes:
            continue
        match = re.match(r"\d{8}T\d{6}==z--(.+)", file_path.name)
        stem = match.group(1) if match else file_path.stem
        title = extract_h1(_read_prefix(file_path)) or stem
        identity = file_path.name
        if any(item.slug == slug_for(identity, spec) for item in items):
            continue
        if title in seen_titles:
            continue
        seen_titles.add(title)
        items.append(
            Item(
                identity=identity,
                source=file_path,
                slug=slug_for(identity, spec),
                title=title,
                date=extract_date_from_filename(file_path.name),
            )
        )
    return items


# --------------------------------------------------------------------------
# TOC page generation
# --------------------------------------------------------------------------

TOC_TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>__TITLE__</title>
<style>
*{box-sizing:border-box}
body{margin:0;padding:40px 20px;min-height:100vh;display:flex;flex-direction:column;
 align-items:center;background:#0a1929;color:#e0e0e0;line-height:1.6;
 font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','PingFang SC',sans-serif}
.header{text-align:center;margin-bottom:28px}
.header h1{font-size:28px;margin:0 0 8px;background:linear-gradient(135deg,#667eea,#764ba2);
 -webkit-background-clip:text;-webkit-text-fill-color:transparent}
.header p{color:#90a4ae;font-size:14px;margin:0}
.toolbar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;max-width:960px;width:100%;margin-bottom:16px}
.search-wrapper{flex:1;min-width:200px;position:relative;display:flex;align-items:center}
.search-box{width:100%;padding:10px 36px 10px 14px;border-radius:8px;border:1px solid rgba(255,255,255,.12);
 background:rgba(255,255,255,.05);color:#e0e0e0;font-size:14px;outline:none}
.search-box:focus{border-color:#667eea}
.clear-btn{position:absolute;right:8px;width:22px;height:22px;border-radius:50%;border:none;
 background:rgba(255,255,255,.1);color:#90a4ae;font-size:12px;cursor:pointer;display:none;
 align-items:center;justify-content:center;padding:0}
.clear-btn.visible{display:flex}
.btn{padding:8px 14px;border-radius:8px;border:1px solid rgba(255,255,255,.12);
 background:rgba(255,255,255,.05);color:#b0bec5;font-size:13px;cursor:pointer;white-space:nowrap}
.btn:hover{background:rgba(255,255,255,.09);color:#e0e0e0}
.btn.active{background:rgba(102,126,234,.15);color:#a5b4fc;border-color:rgba(102,126,234,.3)}
.btn.export{border-color:rgba(245,158,11,.25);background:rgba(245,158,11,.08);color:#fbbf24;font-weight:600}
.result-info{color:#546e7a;font-size:12px;margin-bottom:8px;max-width:960px;width:100%}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px;max-width:960px;width:100%}
.card{display:block;padding:20px;border-radius:12px;text-decoration:none;color:inherit;
 background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);transition:all .2s}
.card:hover{background:rgba(102,126,234,.08);border-color:rgba(102,126,234,.3);transform:translateY(-2px)}
.card.hidden{display:none}
.card-title{font-size:16px;font-weight:600;color:#c7d2fe;margin-bottom:6px}
.card-meta{font-size:12px;color:#546e7a}
.empty{display:none;grid-column:1/-1;text-align:center;color:#546e7a;padding:40px}
.empty.show{display:block}
.pagination{display:flex;justify-content:center;align-items:center;gap:6px;margin-top:24px;
 max-width:960px;width:100%;flex-wrap:wrap}
.page-btn{padding:8px 12px;min-width:36px;text-align:center;border-radius:8px;
 border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.05);color:#b0bec5;
 font-size:13px;cursor:pointer}
.page-btn:hover{background:rgba(255,255,255,.09);color:#e0e0e0}
.page-btn.active{background:rgba(102,126,234,.15);color:#a5b4fc;border-color:rgba(102,126,234,.3)}
.page-btn:disabled{opacity:.3;cursor:not-allowed}
.page-info{color:#546e7a;padding:0 2px;letter-spacing:2px}
.footer{margin-top:44px;text-align:center;color:#455a64;font-size:12px}
@media(max-width:640px){body{padding:20px 12px}.header h1{font-size:22px}.grid{grid-template-columns:1fr;gap:12px}
 .search-wrapper{min-width:100%}.search-box{font-size:16px}}
</style>
</head>
<body>
<div class="header"><h1>__TITLE__</h1><p>__SUBTITLE__</p></div>
<div class="toolbar">
 <div class="search-wrapper">
  <input type="text" class="search-box" id="searchBox" placeholder="🔍 搜索…">
  <button class="clear-btn" id="clearBtn">✕</button>
 </div>
 <button class="btn active" data-sort="date-desc">最新优先</button>
 <button class="btn" data-sort="date-asc">最早优先</button>
 <button class="btn" data-sort="name-asc">名称 A→Z</button>
 <button class="btn export" id="exportBtn">📊 导出CSV</button>
</div>
<div class="result-info" id="resultInfo"></div>
<div class="grid" id="grid">
__CARDS__
<div class="empty" id="emptyMsg">未找到匹配项</div>
</div>
<div class="pagination" id="pagination"></div>
<div class="footer"><p>__SUBTITLE__</p></div>
<script>
const PAGE_SIZE=12,PROD_URL=__PROD_URL__,CSV_NAME=__CSV_NAME__,LABEL=__LABEL__;
let currentSort='date-desc',currentPage=1,filtered=[];
const grid=document.getElementById('grid'),searchBox=document.getElementById('searchBox');
const clearBtn=document.getElementById('clearBtn'),pagination=document.getElementById('pagination');
const resultInfo=document.getElementById('resultInfo'),emptyMsg=document.getElementById('emptyMsg');
const allCards=Array.from(grid.querySelectorAll('.card'));
function getCards(){
 const q=searchBox.value.trim().toLowerCase();
 let cards=allCards.slice();
 if(q){cards=cards.filter(c=>((c.dataset.title||'')+(c.dataset.slug||'')+(c.dataset.tags||'')).toLowerCase().includes(q));}
 cards.sort((a,b)=>{switch(currentSort){
   case 'date-asc':return (a.dataset.date||'').localeCompare(b.dataset.date||'');
   case 'name-asc':return (a.dataset.title||'').localeCompare(b.dataset.title||'');
   default:return (b.dataset.date||'').localeCompare(a.dataset.date||'');}});
 return cards;
}
function render(){
 filtered=getCards();const total=filtered.length;
 const totalPages=Math.max(1,Math.ceil(total/PAGE_SIZE));
 if(currentPage>totalPages)currentPage=totalPages;
 const start=(currentPage-1)*PAGE_SIZE,end=start+PAGE_SIZE;
 allCards.forEach(c=>{c.style.display='none';});
 filtered.slice(start,end).forEach(c=>{c.style.display='';grid.appendChild(c);});
 grid.appendChild(emptyMsg);emptyMsg.classList.toggle('show',total===0);
 resultInfo.textContent=total?`显示 ${start+1}-${Math.min(end,total)} / 共 ${total} 个${LABEL}`:'';
 renderPagination(totalPages);
}
function renderPagination(totalPages){
 if(totalPages<=1){pagination.innerHTML='';return;}
 const p=currentPage;let h=`<button class="page-btn" data-page="prev" ${p===1?'disabled':''}>‹</button>`;
 for(let i=1;i<=totalPages;i++){
  if(i===1||i===totalPages||Math.abs(i-p)<=1){h+=`<button class="page-btn${i===p?' active':''}" data-page="${i}">${i}</button>`;}
  else if(i<p&&i+1<p===false){h+='<span class="page-info">…</span>';}
 }
 h+=`<button class="page-btn" data-page="next" ${p===totalPages?'disabled':''}>›</button>`;
 pagination.innerHTML=h;
}
function exportCSV(){
 const rows=[['#','标题','日期','链接']];
 allCards.forEach((c,i)=>rows.push([i+1,c.dataset.title||'',c.dataset.date||'',`https://${PROD_URL}/${c.dataset.slug||''}/`]));
 const csv=rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\n');
 const blob=new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8;'});
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=CSV_NAME;
 document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(a.href);
}
let t;function toggleClear(){clearBtn.classList.toggle('visible',searchBox.value.length>0);}
searchBox.addEventListener('input',()=>{toggleClear();clearTimeout(t);t=setTimeout(()=>{currentPage=1;render();},200);});
clearBtn.addEventListener('click',()=>{searchBox.value='';toggleClear();currentPage=1;render();searchBox.focus();});
document.querySelectorAll('.btn[data-sort]').forEach(b=>b.addEventListener('click',()=>{
 document.querySelectorAll('.btn[data-sort]').forEach(x=>x.classList.remove('active'));
 b.classList.add('active');currentSort=b.dataset.sort;currentPage=1;render();}));
document.getElementById('exportBtn').addEventListener('click',exportCSV);
pagination.addEventListener('click',e=>{const b=e.target.closest('.page-btn');if(!b||b.disabled)return;
 if(b.dataset.page==='prev')currentPage--;else if(b.dataset.page==='next')currentPage++;else currentPage=parseInt(b.dataset.page);
 render();window.scrollTo({top:0,behavior:'smooth'});});
render();
</script>
</body>
</html>"""


def build_toc_html(items: list[Item], spec: DeploymentSpec) -> str:
    cards = []
    for item in items:
        title = html.escape(item.title)
        date = item.date or datetime.now().strftime("%Y-%m-%d")
        slug = html.escape(item.slug, quote=True)
        cards.append(
            f'<a class="card" href="/{slug}/" data-title="{title}" '
            f'data-date="{date}" data-slug="{slug}" data-tags="{html.escape(item.tags)}">'
            f'<div class="card-title">{title}</div>'
            f'<div class="card-meta">📅 {date} · 🔗 /{slug}/</div></a>'
        )
    prod_url = (spec.prod_url or "").strip() or "example.com"
    return (
        TOC_TEMPLATE.replace("__CARDS__", "\n".join(cards))
        .replace("__TITLE__", html.escape(spec.title))
        .replace("__SUBTITLE__", html.escape(spec.subtitle))
        .replace("__PROD_URL__", json.dumps(prod_url, ensure_ascii=False))
        .replace(
            "__CSV_NAME__", json.dumps(f"{spec.item_label}.csv", ensure_ascii=False)
        )
        .replace("__LABEL__", json.dumps(spec.item_label, ensure_ascii=False))
    )


# --------------------------------------------------------------------------
# Staging
# --------------------------------------------------------------------------


def stage_static(spec: DeploymentSpec, staging: Path) -> dict[str, Any]:
    source = spec.source_path()
    if not source.exists():
        raise DeployError("source_not_found")
    if source.is_file():
        if source.suffix.lower() not in HTML_SUFFIXES:
            raise DeployError("source_not_html_file")
        shutil.copy2(source, staging / "index.html")
        return {"mode": "file", "files": 1}
    shutil.copytree(
        source,
        staging,
        dirs_exist_ok=True,
        ignore=shutil.ignore_patterns(*SKIP_DIR_NAMES),
    )
    if not list(staging.rglob("*.html")):
        log.warning("[%s] no .html files found under %s", spec.name, source)
    return {"mode": "dir", "files": sum(1 for _ in staging.rglob("*") if _.is_file())}


def stage_collection(spec: DeploymentSpec, staging: Path) -> dict[str, Any]:
    items = scan_items(spec)
    if not items:
        raise DeployError("collection_found_no_items")
    for item in items:
        dest = staging / item.slug
        dest.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item.source, dest / "index.html")
    toc_dir = staging / "toc"
    toc_dir.mkdir(parents=True, exist_ok=True)
    (toc_dir / "index.html").write_text(build_toc_html(items, spec), encoding="utf-8")
    if root := _select_root_item(items, spec):
        shutil.copy2(root.source, staging / "index.html")
    return {"mode": "collection", "items": len(items)}


def _select_root_item(items: list[Item], spec: DeploymentSpec) -> Optional[Item]:
    if spec.root_mode == "none":
        return None
    return max(items, key=lambda item: (item.date or "", item.title))


# --------------------------------------------------------------------------
# Fingerprints and digests
# --------------------------------------------------------------------------


def content_digest(path: Path) -> dict[str, Any]:
    if path.is_file():
        digest = hashlib.sha256()
        size = 0
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(HASH_CHUNK_BYTES), b""):
                size += len(chunk)
                digest.update(chunk)
        return {"sha256": digest.hexdigest(), "files": 1, "bytes": size}
    if path.is_dir():
        digest = hashlib.sha256()
        files = size = 0
        for file_path in sorted(
            (p for p in path.rglob("*") if p.is_file() and not p.is_symlink()),
            key=lambda p: p.relative_to(path).as_posix(),
        ):
            digest.update(file_path.relative_to(path).as_posix().encode("utf-8"))
            digest.update(b"\0")
            with file_path.open("rb") as handle:
                for chunk in iter(lambda: handle.read(HASH_CHUNK_BYTES), b""):
                    size += len(chunk)
                    digest.update(chunk)
            digest.update(b"\0")
            files += 1
        return {"sha256": digest.hexdigest(), "files": files, "bytes": size}
    raise DeployError("source_not_found")


def input_fingerprint(spec: DeploymentSpec) -> str:
    """A cheap, stable fingerprint of the deployment inputs (for skip)."""
    digest = hashlib.sha256()
    if spec.mode == "collection":
        for key in COLLECTION_FIELDS:
            digest.update(f"{key}={getattr(spec, key)!r}\0".encode("utf-8"))
        base = spec.source_path()
        if not base.is_dir():
            raise DeployError("collection_source_not_directory")
        candidates = sorted(
            p for p in base.rglob("*") if p.is_file() and not p.is_symlink()
        )
        for path in candidates:
            stat = path.stat()
            digest.update(path.relative_to(base).as_posix().encode("utf-8"))
            digest.update(f":{stat.st_size}:{stat.st_mtime_ns}\0".encode("utf-8"))
    else:
        digest.update(b"static\0")
        digest.update(content_digest(spec.source_path())["sha256"].encode("ascii"))
    digest.update(f"prod={spec.prod}".encode("ascii"))
    return digest.hexdigest()


# --------------------------------------------------------------------------
# State
# --------------------------------------------------------------------------


def load_state(path: Path) -> dict[str, Any]:
    if path.is_file():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                data.setdefault("deployments", {})
                return data
        except (OSError, json.JSONDecodeError):
            log.warning("state file unreadable, starting fresh: %s", path)
    return {"version": VERSION, "deployments": {}}


def save_state(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True)
    fd, temp_name = tempfile.mkstemp(prefix=".vercel-", suffix=".tmp", dir=path.parent)
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def merge_state(state: dict[str, Any], result: dict[str, Any]) -> None:
    if result.get("status") == "skipped":
        return
    entry = state.setdefault("deployments", {}).setdefault(result["name"], {})
    entry["status"] = result["status"]
    entry["updated_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    for key in ("fingerprint", "url", "reason", "source", "mode", "production"):
        if key in result and result[key] is not None:
            entry[key] = result[key]


# --------------------------------------------------------------------------
# Vercel CLI
# --------------------------------------------------------------------------


def find_vercel() -> list[str]:
    executable = shutil.which("vercel") or shutil.which("vc")
    if executable:
        return [executable]
    npx = shutil.which("npx")
    if npx:
        return [npx, "--yes", "vercel"]
    raise DeployError("vercel_not_found")


@dataclass
class CommandResult:
    returncode: int
    stdout: str
    stderr: str


def _global_flags(token: str, scope: Optional[str]) -> list[str]:
    flags = ["--token", token]
    if scope:
        flags += ["--scope", scope]
    return flags


def build_deploy_command(
    prefix: list[str], path: Path, spec: DeploymentSpec, token: str
) -> list[str]:
    command = [*prefix, "deploy", str(path), *_global_flags(token, spec.scope), "-y"]
    if spec.prod:
        command.append("--prod")
    command += ["--project", spec.name]
    if spec.archive:
        command += ["--archive", spec.archive]
    return command


def masked_command(command: list[str]) -> str:
    masked = list(command)
    for index, token in enumerate(masked):
        if token in ("--token", "-t") and index + 1 < len(masked):
            masked[index + 1] = "***"
    return " ".join(masked)


def run_process(
    command: list[str], timeout: int, cwd: Optional[Path] = None
) -> CommandResult:
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(cwd) if cwd else None,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return CommandResult(1, "", f"command timed out after {timeout}s")
    except OSError as error:
        return CommandResult(1, "", f"failed to run {command[0]}: {error}")
    return CommandResult(completed.returncode, completed.stdout, completed.stderr)


def find_deployment_url(text: str) -> Optional[str]:
    """Best-effort extraction of the deployment URL from CLI output."""
    text = text or ""
    try:
        data = json.loads(text[text.index("{") : text.rindex("}") + 1])
    except (ValueError, json.JSONDecodeError):
        data = None
    if data is not None:
        found: list[str] = []

        def walk(node: Any) -> None:
            if isinstance(node, str):
                if node.startswith("http") and (
                    ".vercel.app" in node or "/" in node[8:]
                ):
                    found.append(node)
            elif isinstance(node, dict):
                for value in node.values():
                    walk(value)
            elif isinstance(node, list):
                for value in node:
                    walk(value)

        walk(data)
        if found:
            return found[0]
    matches = [u for u in URL_RE.findall(text) if ".vercel.app" in u]
    return matches[-1] if matches else None


def _tail(text: str, limit: int = MAX_WARNING_CHARS) -> str:
    text = (text or "").strip()
    return text if len(text) <= limit else "..." + text[-limit:]


# --------------------------------------------------------------------------
# Options / per-project deploy
# --------------------------------------------------------------------------


@dataclass
class Options:
    force: bool = False
    retry_failed: bool = False
    dry_run: bool = False
    keep: bool = False
    retries: int = DEFAULT_RETRIES
    timeout: int = DEFAULT_TIMEOUT


def decide_skip(
    spec: DeploymentSpec, prior: Optional[dict], fingerprint: str, opts: Options
) -> Optional[str]:
    if opts.force or not prior or prior.get("status") != "success":
        return None
    if opts.retry_failed:
        return "retry_failed_skip"
    if prior.get("fingerprint") == fingerprint:
        return "unchanged"
    return None


def plan_one(
    spec: DeploymentSpec, prior: Optional[dict], opts: Options
) -> dict[str, Any]:
    started = time.perf_counter()
    fingerprint = input_fingerprint(spec)
    skip = decide_skip(spec, prior, fingerprint, opts)
    result: dict[str, Any] = {
        "name": spec.name,
        "source": spec.source,
        "mode": spec.mode,
        "production": spec.prod,
        "fingerprint": fingerprint,
        "elapsed_seconds": round(time.perf_counter() - started, 3),
    }
    if spec.mode == "collection":
        try:
            result["items"] = len(scan_items(spec))
        except DeployError as error:
            result["status"] = "failed"
            result["reason"] = error.code
            return result
    result["status"] = "skipped" if skip else "planned"
    if skip:
        result["reason"] = skip
    return result


def deploy_one(
    spec: DeploymentSpec,
    prior: Optional[dict],
    opts: Options,
    token: str,
    scope: Optional[str],
    prefix: list[str],
) -> dict[str, Any]:
    started = time.perf_counter()
    fingerprint = input_fingerprint(spec)
    skip = decide_skip(spec, prior, fingerprint, opts)
    if skip:
        return {
            "name": spec.name,
            "source": spec.source,
            "status": "skipped",
            "reason": skip,
            "fingerprint": fingerprint,
            "elapsed_seconds": round(time.perf_counter() - started, 3),
        }

    scope = spec.scope or scope
    if spec.create_if_missing and not project_exists(prefix, spec.name, token, scope):
        created = run_process(
            [*prefix, "project", "add", spec.name, *_global_flags(token, scope)],
            opts.timeout,
        )
        if created.returncode != 0:
            return _failure(
                spec,
                started,
                fingerprint,
                "project_create_failed",
                _tail(created.stderr),
            )
    elif not spec.create_if_missing and not project_exists(
        prefix, spec.name, token, scope
    ):
        return _failure(spec, started, fingerprint, "project_missing")

    staging = Path(tempfile.mkdtemp(prefix=f"vercel-{spec.name}-"))
    try:
        if spec.mode == "collection":
            details = stage_collection(spec, staging)
        else:
            details = stage_static(spec, staging)

        command = build_deploy_command(prefix, staging, spec, token)
        log.debug("[%s] %s", spec.name, masked_command(command))
        result = CommandResult(1, "", "not run")
        for attempt in range(1, opts.retries + 1):
            result = run_process(command, opts.timeout)
            if result.returncode == 0:
                break
            if attempt < opts.retries:
                wait = RETRY_BASE_SECONDS * attempt
                log.warning(
                    "[%s] deploy failed (attempt %d/%d), retry in %.0fs",
                    spec.name,
                    attempt,
                    opts.retries,
                    wait,
                )
                time.sleep(wait)
        if result.returncode != 0:
            return _failure(
                spec,
                started,
                fingerprint,
                "deploy_failed",
                _tail(result.stderr or result.stdout),
            )
        url = find_deployment_url(result.stdout) or find_deployment_url(result.stderr)
        output = {
            "name": spec.name,
            "source": spec.source,
            "status": "success",
            "url": url,
            "production": spec.prod,
            "mode": spec.mode,
            "fingerprint": fingerprint,
            "created_project": spec.create_if_missing,
            "elapsed_seconds": round(time.perf_counter() - started, 3),
        }
        output.update({k: v for k, v in details.items() if k in ("files", "items")})
        return output
    finally:
        if not opts.keep:
            shutil.rmtree(staging, ignore_errors=True)
        else:
            log.info("[%s] staging kept at %s", spec.name, staging)


def _failure(
    spec: DeploymentSpec,
    started: float,
    fingerprint: str,
    code: str,
    detail: str = "",
) -> dict[str, Any]:
    result: dict[str, Any] = {
        "name": spec.name,
        "source": spec.source,
        "status": "failed",
        "reason": code,
        "fingerprint": fingerprint,
        "elapsed_seconds": round(time.perf_counter() - started, 3),
    }
    if detail:
        result["detail"] = detail
    return result


def project_exists(
    prefix: list[str], name: str, token: str, scope: Optional[str]
) -> bool:
    result = run_process(
        [
            *prefix,
            "project",
            "ls",
            "--filter",
            name,
            *_global_flags(token, scope),
            "-F",
            "json",
        ],
        120,
    )
    if result.returncode != 0:
        return False
    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError:
        return False
    projects = data.get("projects") if isinstance(data, dict) else data
    if not isinstance(projects, list):
        return False
    return any(p.get("name") == name for p in projects if isinstance(p, dict))


def list_projects(prefix: list[str], token: str, scope: Optional[str]) -> list[dict]:
    result = run_process(
        [*prefix, "project", "ls", *_global_flags(token, scope), "-F", "json"],
        120,
    )
    if result.returncode != 0:
        raise DeployError(f"project_list_failed:{_tail(result.stderr, 120)}")
    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError:
        raise DeployError("project_list_invalid_json") from None
    projects = data.get("projects") if isinstance(data, dict) else data
    return projects if isinstance(projects, list) else []


# --------------------------------------------------------------------------
# Batch orchestration
# --------------------------------------------------------------------------


def resolve_jobs(requested: Optional[str], count: int) -> int:
    if count <= 0:
        return 1
    if requested in (None, "", "auto"):
        return max(1, min(4, count))
    try:
        value = int(requested)
    except (TypeError, ValueError):
        raise DeployError("invalid_jobs_value") from None
    return max(1, min(MAX_JOBS, value, count))


def batch(args: argparse.Namespace) -> dict[str, Any]:
    specs = specs_from_args(args)
    state_path = default_state_path(args)
    state = load_state(state_path)
    opts = Options(
        force=args.force,
        retry_failed=args.retry_failed,
        dry_run=args.dry_run,
        keep=args.keep,
        retries=args.retries,
        timeout=args.timeout,
    )
    started = time.perf_counter()

    if args.dry_run:
        results = []
        for spec in specs:
            try:
                results.append(
                    plan_one(spec, state["deployments"].get(spec.name), opts)
                )
            except Exception as error:  # noqa: BLE001
                results.append(
                    {"name": spec.name, "status": "failed", "reason": reason(error)}
                )
        return _finalize(results, state_path, args, started, write=False)

    creds = credentials()
    if not creds.token:
        raise DeployError("credentials_missing")
    prefix = find_vercel()
    jobs = resolve_jobs(args.jobs, len(specs))
    log.info("deploying %d project(s) with %d worker(s)", len(specs), jobs)

    results: dict[str, dict[str, Any]] = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=jobs) as pool:
        futures = {
            pool.submit(
                deploy_one,
                spec,
                state["deployments"].get(spec.name),
                opts,
                creds.token,
                creds.scope,
                prefix,
            ): spec
            for spec in specs
        }
        for future in concurrent.futures.as_completed(futures):
            spec = futures[future]
            try:
                result = future.result()
            except Exception as error:  # noqa: BLE001
                result = {
                    "name": spec.name,
                    "status": "failed",
                    "reason": reason(error),
                }
            results[spec.name] = result
            merge_state(state, result)
            save_state(state_path, state)
            _log_result(result)

    ordered = [results[spec.name] for spec in specs]
    return _finalize(ordered, state_path, args, started, write=True)


def _finalize(
    results: list[dict[str, Any]],
    state_path: Path,
    args: argparse.Namespace,
    started: float,
    *,
    write: bool,
) -> dict[str, Any]:
    summary = {
        "total": len(results),
        "success": sum(i["status"] == "success" for i in results),
        "planned": sum(i["status"] == "planned" for i in results),
        "skipped": sum(i["status"] == "skipped" for i in results),
        "failed": sum(i["status"] == "failed" for i in results),
    }
    report = {
        "version": VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "status": (
            "partial_failure"
            if summary["failed"]
            else ("dry_run" if args.dry_run else "complete")
        ),
        "dry_run": args.dry_run,
        "summary": summary,
        "results": results,
        "elapsed_seconds": round(time.perf_counter() - started, 3),
    }
    if write:
        report["state_path"] = str(state_path)
        if args.report:
            report_path = Path(args.report).expanduser()
            report_path.parent.mkdir(parents=True, exist_ok=True)
            report_path.write_text(
                json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            report["report_path"] = str(report_path)
    return report


def _log_result(result: dict[str, Any]) -> None:
    status = result["status"]
    text = f"[{result['name']}] {status}"
    if status == "success" and result.get("url"):
        text += f" {result['url']}"
    elif status in ("skipped", "failed"):
        text += f" ({result.get('reason')})"
    (log.error if status == "failed" else log.info)(text)


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vercel_html_deploy.py",
        description="Batch-deploy static HTML to Vercel.",
    )
    parser.add_argument(
        "-v", "--version", action="version", version=f"%(prog)s {VERSION}"
    )
    parser.add_argument(
        "--env-file",
        action="append",
        default=None,
        help=f"extra env file (default also reads {DEFAULT_ENV_FILE})",
    )
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--log-file")

    sub = parser.add_subparsers(dest="command", required=True)

    deploy = sub.add_parser("deploy", help="deploy one or many projects")
    group = deploy.add_argument_group("source (choose one)")
    group.add_argument("--config", help="YAML config with a deployments: section")
    group.add_argument("--dir", help="single directory or .html file")
    group.add_argument(
        "--discover-root", dest="discover_root", help="parent of site dirs"
    )
    group.add_argument("--project-name", help="Vercel project name for --dir mode")
    group.add_argument("--scope", help="Vercel scope/team")
    group.add_argument("--name-prefix", default="")
    deploy.add_argument(
        "--prod",
        dest="prod",
        action="store_true",
        default=None,
        help="force production deploys (overrides config prod: true/false)",
    )
    deploy.add_argument(
        "--preview",
        dest="prod",
        action="store_false",
        help="deploy to preview instead of production (overrides config)",
    )
    deploy.add_argument("--only", help="comma-separated project names")
    deploy.add_argument("--force", action="store_true", help="ignore fingerprint skip")
    deploy.add_argument("--retry-failed", action="store_true")
    deploy.add_argument("--dry-run", action="store_true")
    deploy.add_argument("--jobs", default="auto")
    deploy.add_argument("--retries", type=int, default=DEFAULT_RETRIES)
    deploy.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT)
    deploy.add_argument("--state")
    deploy.add_argument("--report")
    deploy.add_argument("--keep", action="store_true", help="keep staging dirs")
    deploy.add_argument("--json", action="store_true")

    discover = sub.add_parser("discover", help="find site dirs and emit a config")
    discover.add_argument("--root", required=True)
    discover.add_argument("--scope")
    discover.add_argument("--name-prefix", default="")
    discover.add_argument("--output")

    listing = sub.add_parser("list", help="list Vercel projects in the scope")
    listing.add_argument("--json", action="store_true")

    return parser


def _setup_logging(verbose: bool, log_file: Optional[str]) -> None:
    log.setLevel(logging.DEBUG if verbose else logging.INFO)
    log.handlers.clear()
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(message)s", datefmt="%H:%M:%S"
    )
    console = logging.StreamHandler(sys.stderr)
    console.setLevel(logging.DEBUG if verbose else logging.INFO)
    console.setFormatter(formatter)
    log.addHandler(console)
    if log_file:
        path = Path(log_file).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        handler = logging.FileHandler(path, encoding="utf-8")
        handler.setLevel(logging.DEBUG)
        handler.setFormatter(formatter)
        log.addHandler(handler)


def _dump_yaml(document: dict) -> str:
    if yaml is None:
        raise DeployError("yaml_dependency_missing")

    class _Dumper(yaml.SafeDumper):
        pass

    def _represent_str(dumper, data):
        style = '"' if any(ch in data for ch in " \t#") else None
        return dumper.represent_scalar("tag:yaml.org,2002:str", data, style=style)

    _Dumper.add_representer(str, _represent_str)
    return yaml.dump(
        document, Dumper=_Dumper, allow_unicode=True, sort_keys=False, width=10**6
    )


def _discover_command(args: argparse.Namespace) -> int:
    specs = discover_specs(args.root, args.scope, args.name_prefix)
    document = {
        "deployments": {
            spec.name: {
                "source_dir": spec.source,
                "mode": "static",
                "scope": spec.scope,
                "prod": True,
                "create_if_missing": True,
            }
            for spec in specs
        }
    }
    text = _dump_yaml(document)
    if args.output:
        output = Path(args.output).expanduser()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(text, encoding="utf-8")
        log.info("wrote %d site(s) to %s", len(specs), output)
    else:
        sys.stdout.write(text)
    return 0


def _list_command(args: argparse.Namespace) -> int:
    creds = credentials()
    if not creds.token:
        raise DeployError("credentials_missing")
    projects = list_projects(find_vercel(), creds.token, creds.scope)
    if args.json:
        print(json.dumps(projects, ensure_ascii=False, indent=2))
        return 0
    log.info("%d Vercel project(s) in scope %s:", len(projects), creds.scope)
    for project in projects:
        log.info(
            "  - %s  (%s)",
            project.get("name"),
            project.get("latestProductionUrl") or "-",
        )
    return 0


def _print_summary(report: dict[str, Any]) -> None:
    summary = report["summary"]
    log.info(
        "done: total=%d success=%d skipped=%d failed=%d (%.2fs)",
        summary["total"],
        summary["success"],
        summary["skipped"],
        summary["failed"],
        report["elapsed_seconds"],
    )
    failed = [item["name"] for item in report["results"] if item["status"] == "failed"]
    if failed:
        log.warning("failed projects: %s", ", ".join(failed))
        log.warning("re-run with --retry-failed to retry only those")


def main(argv: Optional[list[str]] = None) -> int:
    args = build_parser().parse_args(argv)

    env_files = list(args.env_file or [])
    env_files.append(str(DEFAULT_ENV_FILE))
    _setup_logging(getattr(args, "verbose", False), getattr(args, "log_file", None))
    loaded = load_env_files(env_files)
    if loaded:
        log.debug("loaded env files: %s", ", ".join(loaded))

    try:
        if args.command == "deploy":
            report = batch(args)
            if getattr(args, "json", False):
                print(json.dumps(report, ensure_ascii=False, indent=2))
            else:
                _print_summary(report)
            return 0 if report["summary"]["failed"] == 0 else 2
        if args.command == "discover":
            return _discover_command(args)
        if args.command == "list":
            return _list_command(args)
    except DeployError as error:
        _emit_error(args, error.code)
        return 1
    except Exception as error:  # noqa: BLE001
        _emit_error(args, reason(error))
        return 1
    return 1


def _emit_error(args: argparse.Namespace, code: str) -> None:
    if getattr(args, "json", False):
        print(json.dumps({"status": "error", "reason": code}))
    else:
        log.error("error: %s", code)


if __name__ == "__main__":
    raise SystemExit(main())
