#!/usr/bin/env python3
"""Reuse the installed faster-whisper-stt engine with a stable resumable job root.

The installed skill's engine is imported rather than reimplemented. Keeping a
stable job directory fixes the orchestration-level resume problem while
retaining its chunking, filtering, SRT/TXT merge, and model reuse behavior.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from dataclasses import asdict
from pathlib import Path


STT_ROOT = Path.home() / ".config/omnirush/skills/faster-whisper-stt/scripts"
sys.path.insert(0, str(STT_ROOT))
import stt_fasterwhisper_batch as stt  # noqa: E402


def stable_name(path: Path) -> str:
    safe = re.sub(r"[^\w.-]+", "_", path.stem, flags=re.UNICODE).strip("._") or "video"
    import hashlib
    return f"{safe}_{hashlib.sha256(str(path.resolve()).encode()).hexdigest()[:10]}"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", action="append", required=True, type=Path)
    parser.add_argument("--job-root", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument("--model", default=stt.DEFAULT_MODEL)
    parser.add_argument("--language", default="auto")
    parser.add_argument("--chunk-duration", type=int, default=900)
    parser.add_argument("--cpu-threads", type=int, default=6)
    parser.add_argument("--beam-size", type=int, default=5)
    parser.add_argument("--retries", type=int, default=1)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--merge-only", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    if args.chunk_duration < 60:
        parser.error("--chunk-duration must be >= 60")
    sources = [path.expanduser().resolve() for path in args.source]
    if any(not path.is_file() for path in sources):
        parser.error("every --source must be an existing file")
    root = args.job_root.expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    stt.setup_logging(root, "INFO")
    config = stt.Config(
        model=os.path.expanduser(args.model),
        language=None if args.language.lower() == "auto" else args.language,
        cpu_threads=args.cpu_threads,
        compute_type="int8",
        beam_size=args.beam_size,
        use_vad=True,
        condition_on_previous_text=False,
        write_srt=True,
        write_txt=True,
        retries=args.retries,
        overwrite=args.overwrite,
        credit_filter=True,
        credit_tail_filter=True,
        credit_tail_window=stt.DEFAULT_CREDIT_TAIL_WINDOW,
        credit_keywords=stt.DEFAULT_CREDIT_KEYWORDS,
        chunk_duration=args.chunk_duration,
        resume=args.resume,
        merge_only=args.merge_only,
    )
    engine = stt.FasterWhisperEngine(config)
    results = []
    for source in sources:
        job_dir = root / stable_name(source)
        job_dir.mkdir(parents=True, exist_ok=True)
        try:
            result = engine.transcribe_with_chunks(source, job_dir)
        except Exception as exc:  # keep other videos moving and report safely
            result = stt.JobResult(source=str(source), job_dir=str(job_dir), success=False, error=str(exc))
        result_json = job_dir / "job_result.json"
        result_json.write_text(json.dumps(asdict(result), ensure_ascii=False, indent=2), encoding="utf-8")
        results.append(asdict(result))
    report = {"sources": len(sources), "succeeded": sum(bool(row.get("success")) for row in results), "failed": sum(not row.get("success") for row in results), "results": results}
    args.report.expanduser().parent.mkdir(parents=True, exist_ok=True)
    args.report.expanduser().write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"report": str(args.report.expanduser()), "succeeded": report["succeeded"], "failed": report["failed"]}, ensure_ascii=False))
    return 0 if report["failed"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
