# Conversion engines

## Interface for the CLI

`scripts/conversion_engines.py` uses Python 3.10+ and standard-library facilities,
plus an optional separately installed Python OpenCC package. It does not read
input files, credentials, or `.env` files and does not install dependencies.

```python
from conversion_engines import EngineError, doctor, get_engine

engine = get_engine("s2t", "auto")  # only s2t / t2s; auto / native / opencc
try:
    converted = engine.convert("  汉语😀\r\n")
    details = engine.metadata()  # inspect AFTER conversion for runtime fallback
finally:
    engine.close()
```

- `EngineError.code` is the fixed string **`"engine_error"`**. Engine selection,
  initialization, conversion, and reported native cleanup failures raise this
  exception. Error messages never include submitted text or raw backend errors.
- `.name` is the **currently selected** backend: `native` or `opencc`. It can
  change after a native failure in automatic mode. `.mode` is `s2t` or `t2s`.
- `.convert(text: str) -> str` submits the complete string, including an empty
  string, to its converter. No stripping, newline normalization, Unicode
  normalization, or length-based chunking occurs.
- `.close()` releases ownership and is idempotent. Conversion after close is an
  error. Use one engine per independent job and close it in `finally`. Operations
  on one returned engine are serialized; no converter is cached globally.
- `.metadata()` is a fresh JSON-safe dictionary with `backend`,
  `selected_backend`, `requested_backend`, `mode`, `fallback_reason`, `version`,
  `available`, and `closed`, plus backend-specific library/config paths or
  installed Python distribution versions. It contains no input or output text.
  `available` here means this engine is still open, not a guarantee of future
  conversion success. Caller mutation of the returned dictionary does not
  mutate engine metadata.
- `doctor()` returns JSON-safe `platform`, `engines`, and `auto_backend` data.
  It probes **both directions separately** with tiny built-in synthetic strings
  containing Chinese, whitespace, CRLF, and an emoji. A backend is available in
  this report only if both conversions and cleanup succeed. Its probes never
  read user documents. Unlike normal selection, doctor explicitly checks both
  backends on macOS so it can show whether fallback is also usable.

## Source-preserving reuse rationale

The supplied `/tmp/s2t/scripts/chinese_converter_cli.py` `convert_text` called
`[binary, mode, text]` with a 30-second subprocess timeout and returned
`stdout.strip()`. The supplied `chinese_converter` artifact is an x86_64 Mach-O
linked to `/usr/local/opt/opencc/lib/libopencc.1.2.dylib`, not a self-contained
portable Swift conversion engine. Its identified imports include `opencc_open`,
`opencc_convert_utf8`, `opencc_convert_utf8_free`, `opencc_close`, and
`opencc_error`.

This implementation retains the source's **OpenCC conversion semantics and
standard modes**, but replaces only its engine boundary. It neither executes
nor copies the opaque binary; no source files under `/tmp/s2t` are modified.
Native calls use the documented C ABI verified against the locally installed
`include/opencc/opencc.h`, with matching `s2t.json` / `t2s.json` configurations.
Text stays in process memory, not command-line arguments or subprocess output.
The previous `.strip()` behavior is deliberately removed to preserve whitespace.
This is a compatibility-preserving engine replacement, not a claim to have
recovered or reproduced the artifact's unavailable source.

## Selection and fallback precedence

| Requested backend | macOS (Darwin) | Linux / Windows |
| --- | --- | --- |
| `auto` | Known Homebrew native libraries first; Python OpenCC if native initialization or a conversion fails | Python OpenCC only; no native discovery/loading |
| `native` | Native C API only; failures are errors | Clear unsupported-platform error; no loading |
| `opencc` | Python OpenCC only; failures are errors | Python OpenCC only; failures are errors |

The `native` backend tries these known libraries, always pairing a library with
`share/opencc/{mode}.json` under the **same installation prefix**:

- `/usr/local/opt/opencc/lib/libopencc.1.2.dylib`
- `/usr/local/opt/opencc/lib/libopencc.dylib`
- `/opt/homebrew/opt/opencc/lib/libopencc.1.2.dylib`
- `/opt/homebrew/opt/opencc/lib/libopencc.dylib`

On an `arm64`/`aarch64` Python process, `/opt/homebrew` takes precedence; otherwise
`/usr/local` does. The unversioned Homebrew symlink permits compatible OpenCC
versions with other dylib version suffixes. No recursive filesystem search,
`PATH` executable discovery, arbitrary library environment override, or native
library load on non-Darwin platforms occurs. Configurations reference the
OpenCC dictionaries shipped by that installation.

In `auto`, a catchable native conversion failure discards its result, closes the
native converter, initializes Python OpenCC, and retries the **entire original
`convert()` argument once**. There is never a concatenation of partial results
from different engines. The engine remains on Python for subsequent calls.
`metadata()["fallback_reason"]` records the sanitized native error; the CLI must
report that metadata to its user if it wants to surface fallback. If Python is
also unavailable or fails, conversion raises an error, never returns unchanged
input as a substitute for conversion. Native cleanup failure during this switch
is recorded too. Explicit backends never switch to another backend.

## Optional packages (instructions, not automatic actions)

For the portable Python implementation, users may install into their chosen
virtual environment:

```sh
python3 -m pip install opencc-python-reimplemented
```

This package exports `from opencc import OpenCC`; the engine uses `OpenCC("s2t")`
or `OpenCC("t2s")`. A compatible already installed package exporting the same
API is accepted as well. The local verification environment has distribution
**`OpenCC` 1.4.1**, which includes Python bindings to its own native implementation;
`opencc` as a backend name means the Python API, not necessarily pure Python.
Both distribution families occupy the same `opencc` import namespace, so use
one chosen provider per environment instead of installing them over one another.
No installation was performed for this change.

For macOS users who specifically want the Homebrew backend, a separate manual
`brew install opencc` supplies its library, configurations, and dictionaries.
Use the Homebrew architecture compatible with the Python process. Nothing in
this module invokes Homebrew, pip, a shell, or the original executable.

## C memory safety and boundaries

The ctypes declarations use `c_void_p` for converter handles **and allocated
output pointers**. Declaring the output as `c_char_p` would lose the allocation
address and leak it. Initialization rejects NULL and `(opencc_t)-1`. Conversion
uses the explicit UTF-8 byte length, checks the output pointer, copies/decodes
it, and frees the original pointer in `finally`, including on decoding failure.
Closing relinquishes the handle once; a reported close failure is not retried,
because C ownership is then ambiguous and a retry might double-free memory.
The global, non-thread-safe `opencc_error()` text is not used in diagnostics.

The allocating C API returns a NUL-terminated string without a result length.
To avoid silent truncation, `native` explicitly rejects embedded U+0000; `auto`
then retries the whole string through Python. The installed Python API was
verified to preserve embedded NULs. This is a documented native limitation,
not permission to split strings and alter phrase context. Unpaired surrogate
code points cannot be UTF-8 encoded by the native API and produce a clean
conversion error.

Direct in-process conversion does not reproduce the old subprocess's 30-second
timeout or provide process crash isolation. Catchable API/load errors can
trigger fallback; a library segmentation fault or hung C call cannot. Libraries
are therefore restricted to known user-managed Homebrew installations.

## Verification and limits

Run from the skill directory:

```sh
python3 -m unittest discover -s tests -p test_engines.py -v
```

The suite covers macOS/Linux/Windows selection using mocks, forced-backend
failures, unavailable/broken Python packages, native loading/configuration
failures, whole-input runtime fallback, pointer signatures, invalid pointers,
output freeing on decode/copy errors, cleanup failures and idempotence, text-free
diagnostics, JSON-safe doctor data, whitespace/CR/LF/CRLF, phrase context,
non-BMP Unicode, and independent engine instances. Real tests exercise both
conversion directions through the installed Python provider and native library.
Real native tests are explicitly skipped on non-macOS hosts or when the expected
Homebrew library/config files are absent; real Python tests explicitly skip
when the optional import is absent.

Verified locally on **macOS x86_64, Python 3.12.10**, with **Homebrew OpenCC 1.2.0**
and **Python `OpenCC` 1.4.1**: 47 tests passed with no skips. Doctor reported both
backends available in both directions. Linux/Windows selection and Apple
Silicon path precedence are mock-verified, **not** real-host verification.
Python 3.10, Apple Silicon native loading, and the separately packaged
`opencc-python-reimplemented` implementation were not run in this environment.
Dictionary versions can differ between native and Python providers, so these
checks demonstrate standard-mode behavior on the synthetic samples, not
exhaustive phrase-by-phrase equality across OpenCC releases. CLI/file/SRT
handling and source-byte/encoding preservation are outside this engine module.
