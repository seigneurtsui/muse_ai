# 验证

## 自动测试

```bash
cd "$HOME/.config/freebuff/skills/html-toc-embed"
python3 -m py_compile scripts/batch_add_toc.py
python3 -m black --config /dev/null --check scripts/batch_add_toc.py tests/test_batch_add_toc.py
python3 -m unittest discover -s tests
```

结果（Python 3.12.10）：

- `py_compile` 通过。
- `black --check` 通过（exit 0，两文件均未改动）。
- `unittest` **Ran 36 tests … OK**（exit 0）。

脚本仅依赖标准库；未安装任何第三方包。

覆盖范围（`tests/test_batch_add_toc.py`）：

- **StripTests**：移除本工具的目录块 + CSS 层；移除旧形式（源工具）注入；解包旧表格包裹（`test_strip_removes_our_block_and_css` / `test_strip_removes_legacy_injections` / `test_strip_removes_legacy_css_layer`）。
- **ProcessTests**：`process_html` 幂等（含「无 `<style>`、无 `<head>`」分支）；补齐 viewport 且不重复；标题 ID 与目录锚点；保留已有 ID 并去重；`--levels` 过滤；`--min-headings` 跳过目录但保留 CSS；表格包裹与 `--no-wrap-tables`；标题文本与 `--toc-title` 转义；缺失 `<body>` 时追加到文档末尾；无标题文档仍完成基础转换。
- **HelperTests**：`normalize_heading_levels`（合法/非法）；`resolve_jobs`（auto/整数/上限）；`_normalize_argv` 保留以 `-` 开头的值；`write_atomic`。
- **BatchTests**：输出转换后的文件；递归 vs 扁平结构；`--exclude-pattern`；dry-run 不写任何文件；`--incremental` 跳过未变；`--force` 强制重写；`--in-place` 改写源文件；`output_within_input` / `output_equals_input` / `input_not_found` 被拒；单文件读取失败（mock）→ `partial_failure` 且退出码 2；`--report` 写入。
- **CliTests**：`--help`/`--version` 退出 0；真实子进程 dry-run 与正式运行退出 0；坏输入以 `--json` 返回 `{"status":"error",...}` 且退出 1。

## 端到端 smoke test（真实文件系统）

构造含子目录、无 `<head>`、无标题与多行格式的目录，执行：

```bash
python3 scripts/batch_add_toc.py "$IN" "$OUT" -r --levels 2,3,4 --json
```

实测（示例目录：`a.html`(H2+H3+表格)、`sub/b.html`(无 head，H2/H4/H3)、`c.html`(无标题)）：

- `status=complete`，`summary={total:3, success:3, skipped:0, failed:0, toc_documents:2, headings:5}`。
- 输出树：`out/a.html`、`out/c.html`、`out/sub/b.html`（递归保持结构；`c.html` 无标题仍被基础转换）。
- 逐文件记录含 `source/output/status/headings/toc_items/tables/bytes/elapsed_seconds`；例：`a.html → success, headings=2, toc_items=2, tables=1`。
- `--incremental` 第二次运行：`{total:3, success:0, skipped:3, failed:0, toc_documents:2, headings:5}`（全部命中未变而跳过）。
- `--dry-run`：`status=dry_run`，输出目录**未创建**。
- `output_within_input`：输出 `{"status":"error","reason":"output_within_input"}`，**退出码 1**（`in/out` 位于输入内）。
- `--in-place`：`status=complete`，源文件被原子改写并含注入标记（`grep -c 'rainman-toc' in/z.html` = 40）。

### 注入标记（实测）

处理后文档同时含：`<!--rainman-toc-embed:start/end-->`、`/* rainman-toc-embed:start/end */`、`data-rainman-toc-script="1"`、`data-rainman-toc-style="1"`、`data-rainman-toc="1"`（面板 + 进度条）、`data-rainman-table="1"`、`rainman-section-N` 锚点、`rainman-toc-progress-bar` 等。

### 多轮幂等（真实往返）

对 5 类文档（有 `<style>` / 无 head 无 style / 无标题 / 有 head 无 style / 多行缩进）执行**往返三轮**：`in → out1 → out2 → out3`，逐目录 `diff -r`：

- `out1 == out2` **PASS**；`out2 == out3` **PASS**（全部字节一致）。

### 内嵌 JS 语法检查（node v22.20.0）

从生成的文档中抽取 `data-rainman-toc-script="1"` 的 `<script>`，用 `node --check` 校验：**JS_OK**。

## 未执行 / 限制

- 未在真实浏览器中做视觉回归；目录面板、进度条与当前章节高亮通过内嵌脚本的 `node --check` 语法检查与 DOM 标记结构验证，未做浏览器级自动化交互测试。
- 未处理超大目录（数万文件）的磁盘/内存上限；并行上限固定为 8。
