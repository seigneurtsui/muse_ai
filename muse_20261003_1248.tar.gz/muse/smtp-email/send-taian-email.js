const { sendSmtpEmail } = require('./index.js');

sendSmtpEmail({
  to: process.env.SMTP_TO || 'gc40800@gmail.com',
  subject: '泰安城市画像研究报告 - 五岳独尊·封禅圣地',
  text: `泰安城市画像研究报告

六维深度研究：
1. 历史分层·封禅文化 - 秦始皇至宋真宗12位帝王
2. 古建遗存·岱庙 - 中国四大古建群，天贶殿为三大宫殿之一
3. 宗教与信仰 - 碧霞元君（泰山老奶奶）民间信仰辐射华北
4. 自然地理 - 28亿年地质演化，四大自然奇观
5. 考古发现 - 大汶口文化6500-4500年前，中华文明五千年实证
6. 人文脉络 - 孔子登泰山、杜甫李白诗篇、挑山工精神

在线阅读: https://plan.allez.cc.cd/
存档: https://plan.allez.cc.cd/trip-9441d0/
目录: https://plan.allez.cc.cd/toc/`,
  html: '<h2>泰安城市画像研究报告</h2><p>六维深度研究完成:</p><ul><li><b>历史分层·封禅文化</b> - 秦始皇至宋真宗12位帝王</li><li><b>古建遗存·岱庙</b> - 中国四大古建群，天贶殿为三大宫殿之一</li><li><b>宗教与信仰</b> - 碧霞元君（泰山老奶奶）民间信仰辐射华北</li><li><b>自然地理</b> - 28亿年地质演化，四大自然奇观</li><li><b>考古发现</b> - 大汶口文化6500-4500年前，中华文明五千年实证</li><li><b>人文脉络</b> - 孔子登泰山、杜甫李白诗篇、挑山工精神</li></ul><p><a href="https://plan.allez.cc.cd/">在线阅读完整报告</a></p><p><a href="https://plan.allez.cc.cd/trip-9441d0/">存档链接</a> | <a href="https://plan.allez.cc.cd/toc/">目录页</a></p>'
}).then(info => {
  console.log('Email sent:', info.messageId);
  process.exit(0);
}).catch(err => {
  console.error('Failed:', err.message);
  process.exit(1);
});
