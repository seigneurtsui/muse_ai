#!/usr/bin/env python3
"""
本地 STT 批量处理器：faster-whisper + A/B 双层广告/片尾字幕过滤 + 长音频分片与断点续跑

A：内容层过滤——识别“字幕志愿者、制作、翻译”等疑似片尾/广告文本。
B：尾部过滤——仅检查最后若干字幕段，防止模型在无语音尾部幻觉出制作信息。

新增特性（针对数小时长音频）：
- 按固定时长自动分片（--chunk-duration），默认 15 分钟
- 每个分片独立 job 目录，独立 SRT/TXT 与状态
- 分片级断点续跑：已完成的分片可跳过（--resume）
- 分片级重试：失败只重跑对应分片
- 最终自动合并所有分片字幕为一个完整 SRT/TXT（--merge-only 可只合并）
- 合并时自动进行时间戳偏移

适用于 Linux CPU + int8（8 核 / 16G RAM；原版为 Intel Mac i9 + 64G，线程数已按本机下调）。

依赖：
sudo apt-get install -y ffmpeg   # 或 brew install ffmpeg (macOS)
python3 -m pip install -U faster-whisper

示例：
# 单文件长音频（启用分片 + 断点）
python3 stt_fasterwhisper_batch.py \
  --file ~/Desktop/long_audio.mp3 \
  --language zh \
  --chunk-duration 900 \
  --resume

# 目录批量（递归）
python3 stt_fasterwhisper_batch.py \
  --dir ~/Desktop/audioRepo \
  -o ~/Downloads/stt_transcripts \
  --language zh \
  --chunk-duration 900 \
  --resume

# 仅合并已有分片结果（不重新转写）
python3 stt_fasterwhisper_batch.py \
  --file ~/Desktop/long_audio.mp3 \
  --merge-only \
  --language zh
"""

from __future__ import annotations

import argparse
import gc
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Iterable, List, Optional, Sequence, Tuple

# 必须在 faster_whisper 导入之前设置。
# PyTorch/CTranslate2/OpenMP 可能发生重复运行时冲突（Linux/Intel Mac 皆然）。
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

from faster_whisper import WhisperModel

DEFAULT_OUTPUT_ROOT = Path.home() / "Downloads" / "stt_transcripts"
DEFAULT_MODEL = os.path.expanduser(
    "~/lavoro/translate/whisper/models/faster-whisper-large-v3-turbo-int8"
)

# 针对 i9 + 64G：给单任务留足内存，同时避免过多线程导致上下文切换
DEFAULT_CPU_THREADS = 12  
#DEFAULT_CPU_THREADS = 6  # 本机 elitebook 830 G8 8 核：留 2 核给系统；内存 16G 与 15 分钟分片匹配
DEFAULT_BEAM_SIZE = 5
DEFAULT_RETRIES = 1
DEFAULT_CREDIT_TAIL_WINDOW = 3
DEFAULT_CHUNK_DURATION = 15 * 60  # 15 分钟

SUPPORTED_EXTENSIONS = {
    ".wav", ".mp3", ".m4a", ".flac", ".aac", ".ogg", ".opus", ".wma",
    ".aiff", ".aif", ".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v",
    ".mpeg", ".mpg", ".ts",
}

logger = logging.getLogger("stt_fw")


@dataclass
class Config:
    model: str
    language: Optional[str]
    cpu_threads: int
    compute_type: str
    beam_size: int
    use_vad: bool
    condition_on_previous_text: bool
    write_srt: bool
    write_txt: bool
    retries: int
    overwrite: bool
    credit_filter: bool
    credit_tail_filter: bool
    credit_tail_window: int
    credit_keywords: Tuple[str, ...]
    chunk_duration: int
    resume: bool
    merge_only: bool


@dataclass
class SegmentData:
    start: float
    end: float
    text: str


@dataclass
class ChunkResult:
    chunk_index: int
    chunk_start: float
    chunk_end: float
    success: bool
    segment_count_before_filter: int = 0
    segment_count_after_filter: int = 0
    filtered_segments: int = 0
    filtered_texts: List[str] = field(default_factory=list)
    srt_path: Optional[str] = None
    txt_path: Optional[str] = None
    elapsed_seconds: Optional[float] = None
    error: Optional[str] = None


@dataclass
class JobResult:
    source: str
    job_dir: str
    success: bool
    language: Optional[str] = None
    duration_seconds: Optional[float] = None
    total_segment_count_before_filter: int = 0
    total_segment_count_after_filter: int = 0
    total_filtered_segments: int = 0
    chunk_results: List[ChunkResult] = field(default_factory=list)
    merged_srt_path: Optional[str] = None
    merged_txt_path: Optional[str] = None
    cleaned_srt_path: Optional[str] = None
    cleanup_input_segment_count: int = 0
    cleanup_output_segment_count: int = 0
    cleanup_removed_segments: int = 0
    cleanup_overlap_adjustments: int = 0
    elapsed_seconds: Optional[float] = None
    error: Optional[str] = None
    
    

DEFAULT_CREDIT_KEYWORDS = (
    "字幕志愿者",
    "字幕組",
    "字幕组",
    "志愿者",
    "制作人员",
    "制作团队",
    "字幕制作",
    "字幕制作人",
    "翻译制作",
    "翻譯製作",
    "字幕翻译",
    "字幕翻譯",
    "校对",
    "校對",
    "后期制作",
    "後期製作",
    "特别感谢",
    "特別感謝",
    "技术支持",
    "技術支援",
    "片尾制作",
    "本字幕由",
    "字幕由",
)


def setup_logging(batch_dir: Path, level_name: str) -> None:
    level = getattr(logging, level_name.upper(), logging.INFO)
    logger.setLevel(level)
    logger.handlers.clear()

    formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    console = logging.StreamHandler(sys.stdout)
    console.setLevel(level)
    console.setFormatter(formatter)
    logger.addHandler(console)

    handler = logging.FileHandler(batch_dir / "batch.log", encoding="utf-8")
    handler.setLevel(level)
    handler.setFormatter(formatter)
    logger.addHandler(handler)


def safe_name(name: str) -> str:
    name = re.sub(r"[/:\\\x00]", "_", name).strip()
    return name or "unnamed"


def unique_job_dir(batch_dir: Path, source: Path) -> Path:
    base = safe_name(source.stem)
    candidate = batch_dir / base
    index = 2
    while candidate.exists():
        candidate = batch_dir / f"{base}_{index}"
        index += 1
    candidate.mkdir(parents=True, exist_ok=False)
    return candidate


def ensure_ffmpeg() -> None:
    if shutil.which("ffmpeg") is None:
        raise RuntimeError(
            "未找到 ffmpeg。Linux: sudo apt-get install -y ffmpeg；macOS: brew install ffmpeg，"
            "并确认 ffmpeg 位于 PATH 中。"
        )


def scan_media(directory: Path, recursive: bool) -> List[Path]:
    walker: Iterable[Path] = (
        directory.rglob("*") if recursive else directory.glob("*")
    )

    files = [
        path for path in walker
        if path.is_file()
        and not path.name.startswith(".")
        and not path.name.startswith("~")
        and path.suffix.lower() in SUPPORTED_EXTENSIONS
    ]

    return sorted(files, key=lambda p: str(p).lower())


def get_audio_duration_seconds(media_path: Path) -> Optional[float]:
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        return None

    command = [
        ffprobe,
        "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        str(media_path),
    ]

    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        )

        if completed.returncode == 0:
            return round(float(completed.stdout.strip()), 3)
    except Exception:
        pass
    return None


def normalize_text(text: str) -> str:
    text = re.sub(r"<[^>]+>", "", text)
    text = text.replace("\\N", " ")
    return re.sub(r"\s+", " ", text).strip()


def contains_credit_keyword(text: str, keywords: Sequence[str]) -> bool:
    compact = re.sub(r"\s+", "", text).lower()
    return any(keyword.lower() in compact for keyword in keywords)


def is_likely_credit_line(
    text: str,
    keywords: Sequence[str],
    max_length: int = 40,
) -> bool:
    """A 层：按文本内容过滤疑似广告/制作/志愿者字幕。"""
    text = normalize_text(text)
    if not text:
        return True

    if not contains_credit_keyword(text, keywords):
        return False

    return len(text) <= max_length


def is_likely_credit_tail_line(
    text: str,
    keywords: Sequence[str],
) -> bool:
    """B 层候选：尾部只要包含制作/字幕/志愿者关键词，就认为可疑。"""
    text = normalize_text(text)
    if not text:
        return True
    return contains_credit_keyword(text, keywords) and len(text) <= 80


def filter_segments(
    segments: Sequence[SegmentData],
    cfg: Config,
) -> Tuple[List[SegmentData], List[str]]:
    """
    同时使用 A+B：
    - A 遍历所有段，删除短的疑似制作/广告文本。
    - B 仅检查过滤后最后 N 段，删除尾部疑似片尾文本。
    """
    kept: List[SegmentData] = []
    removed: List[str] = []

    if cfg.credit_filter:
        for segment in segments:
            if is_likely_credit_line(segment.text, cfg.credit_keywords):
                removed.append(f"A | {segment.start:.3f}-{segment.end:.3f} | {segment.text}")
            else:
                kept.append(segment)
    else:
        kept = list(segments)

    if cfg.credit_tail_filter and kept:
        window = max(1, cfg.credit_tail_window)
        start_index = max(0, len(kept) - window)
        tail_kept: List[SegmentData] = []

        for index, segment in enumerate(kept):
            if index >= start_index and is_likely_credit_tail_line(
                segment.text,
                cfg.credit_keywords,
            ):
                removed.append(f"B | {segment.start:.3f}-{segment.end:.3f} | {segment.text}")
            else:
                tail_kept.append(segment)
        kept = tail_kept

    return kept, removed


def format_timestamp(seconds: float) -> str:
    milliseconds = max(0, int(round(seconds * 1000)))
    hour, milliseconds = divmod(milliseconds, 3_600_000)
    minute, milliseconds = divmod(milliseconds, 60_000)
    second, milliseconds = divmod(milliseconds, 1_000)
    return f"{hour:02}:{minute:02}:{second:02},{milliseconds:03}"


def segments_to_srt(
    segments: Sequence[SegmentData],
    output_path: Path,
    start_offset: float = 0.0,
) -> None:
    """
    将 segment 列表写入 SRT。
    start_offset 用于合并时整体偏移时间戳。
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)
    blocks: List[str] = []
    last_end = 0.0

    for index, segment in enumerate(segments, start=1):
        text = normalize_text(segment.text)
        if not text:
            continue

        start = max(last_end, float(segment.start) + start_offset)
        end = max(start + 0.05, float(segment.end) + start_offset)
        blocks.append(
            f"{index}\n"
            f"{format_timestamp(start)} --> {format_timestamp(end)}\n"
            f"{text}"
        )
        last_end = end

    if not blocks:
        raise RuntimeError("过滤后没有可写入 SRT 的字幕段。")

    temp_path = output_path.with_name(output_path.name + ".tmp")
    temp_path.write_text("\n\n".join(blocks) + "\n", encoding="utf-8")
    temp_path.replace(output_path)


def parse_srt_to_text(srt_content: str) -> str:
    lines: List[str] = []
    for line in srt_content.splitlines():
        stripped = line.strip()
        if not stripped or stripped.isdigit() or "-->" in stripped:
            continue
        lines.append(stripped)
    return "\n".join(lines)


def srt_to_txt(srt_path: Path, txt_path: Path) -> None:
    content = srt_path.read_text(encoding="utf-8-sig")
    text = parse_srt_to_text(content).strip()
    if not text:
        raise RuntimeError("SRT 中没有可用文本，无法生成 TXT。")
    txt_path.write_text(text + "\n", encoding="utf-8")

def split_audio_into_chunks(
    source: Path,
    chunk_duration: float,
    work_dir: Path,
) -> List[Tuple[int, float, float, Path]]:
    """
    使用 ffmpeg 将音频切分为多个固定时长片段。
    返回：[(chunk_index, start_sec, end_sec, chunk_path), ...]

    片段命名：chunk_0000.wav, chunk_0001.wav, ...
    """
    duration = get_audio_duration_seconds(source)
    if duration is None:
        raise RuntimeError(f"无法获取音频时长：{source}")

    work_dir.mkdir(parents=True, exist_ok=True)

    pattern = work_dir / "chunk_%04d.wav"

    command = [
        "ffmpeg",
        "-y",
        "-i", str(source),
        "-f", "wav",
        "-acodec", "pcm_s16le",
        "-ar", "16000",
        "-ac", "1",
        "-map", "0:a:0",
        "-segment_time", str(chunk_duration),
        "-segment_format", "wav",
        "-reset_timestamps", "1",
        str(pattern),
    ]

    logger.info("执行 ffmpeg 切分命令：%s", " ".join(command))

    proc = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=300,
        check=False,
    )

    if proc.returncode != 0:
        logger.error("ffmpeg 切分失败，stderr:\n%s", proc.stderr)
        raise RuntimeError(f"ffmpeg 切分失败（returncode={proc.returncode}）:\n{proc.stderr}")

    # 列出实际生成的文件
    chunk_files = sorted(work_dir.glob("chunk_*.wav"))
    if not chunk_files:
        logger.error("ffmpeg 执行成功但未生成任何 chunk_*.wav 文件，work_dir=%s", work_dir)
        logger.error("ffmpeg stdout:\n%s", proc.stdout)
        logger.error("ffmpeg stderr:\n%s", proc.stderr)
        raise RuntimeError("未能生成任何音频分片。")

    chunks = []
    index = 0
    current_start = 0.0

    for chunk_path in chunk_files:
        chunk_dur = get_audio_duration_seconds(chunk_path)
        if chunk_dur is None:
            logger.warning("无法获取分片时长：%s，跳过", chunk_path)
            index += 1
            current_start += chunk_duration
            continue

        chunk_end = current_start + chunk_dur
        chunks.append((index, current_start, chunk_end, chunk_path))

        index += 1
        current_start += chunk_duration

    if not chunks:
        raise RuntimeError("未能生成任何有效的音频分片（所有分片都无法读取时长）。")

    return chunks

class FasterWhisperEngine:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.model: Optional[WhisperModel] = None

    def load(self) -> WhisperModel:
        if self.model is not None:
            return self.model

        logger.info(
            "加载模型：%s | device=cpu | compute_type=%s | cpu_threads=%s",
            self.cfg.model,
            self.cfg.compute_type,
            self.cfg.cpu_threads,
        )

        self.model = WhisperModel(
            self.cfg.model,
            device="cpu",
            compute_type=self.cfg.compute_type,
            cpu_threads=self.cfg.cpu_threads,
        )

        return self.model

    def transcribe_chunk(
        self,
        chunk_path: Path,
        chunk_index: int,
        chunk_start: float,
        chunk_end: float,
        chunk_dir: Path,
    ) -> ChunkResult:
        """
        对单个分片进行转写、过滤、写 SRT/TXT。
        返回 ChunkResult。
        """
        started = time.monotonic()
        srt_path = chunk_dir / "subtitle.srt"
        txt_path = chunk_dir / "transcript.txt"
        chunk_json = chunk_dir / "chunk_result.json"

        last_error: Optional[str] = None
        for attempt in range(1, self.cfg.retries + 2):
            try:
                logger.info(
                    "[分片 %04d] 开始 | 范围 %.1f–%.1f 秒 | 第 %d/%d 次",
                    chunk_index,
                    chunk_start,
                    chunk_end,
                    attempt,
                    self.cfg.retries + 1,
                )

                model = self.load()
                segments_iter, info = model.transcribe(
                    str(chunk_path),
                    language=self.cfg.language,
                    beam_size=self.cfg.beam_size,
                    vad_filter=self.cfg.use_vad,
                    word_timestamps=False,
                    condition_on_previous_text=self.cfg.condition_on_previous_text,
                )

                raw_segments = [
                    SegmentData(
                        start=float(segment.start),
                        end=float(segment.end),
                        text=normalize_text(segment.text),
                    )
                    for segment in list(segments_iter)
                    if normalize_text(segment.text)
                ]

                filtered_segments, removed = filter_segments(raw_segments, self.cfg)
                chunk_report = {
                    "chunk_index": chunk_index,
                    "chunk_start": chunk_start,
                    "chunk_end": chunk_end,
                    "before": len(raw_segments),
                    "after": len(filtered_segments),
                    "removed": removed,
                    "keywords": list(self.cfg.credit_keywords),
                }
                (chunk_dir / "filter_report.json").write_text(
                    json.dumps(chunk_report, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )

                if not filtered_segments:
                    raise RuntimeError("所有字幕段都被过滤，拒绝生成空结果。")

                if self.cfg.write_srt:
                    # 写入分片 SRT（时间戳相对于分片起点）
                    segments_to_srt(filtered_segments, srt_path, start_offset=0.0)

                if self.cfg.write_txt:
                    if not self.cfg.write_srt:
                        raise RuntimeError("生成 TXT 时必须同时生成 SRT。")
                    srt_to_txt(srt_path, txt_path)

                detected_language = getattr(info, "language", None)
                elapsed = round(time.monotonic() - started, 3)
                logger.info(
                    "[分片 %04d] 完成 | 耗时 %.1f 秒 | 语言=%s | 过滤 %d 段",
                    chunk_index,
                    elapsed,
                    detected_language or "auto",
                    len(removed),
                )

                result = ChunkResult(
                    chunk_index=chunk_index,
                    chunk_start=chunk_start,
                    chunk_end=chunk_end,
                    success=True,
                    segment_count_before_filter=len(raw_segments),
                    segment_count_after_filter=len(filtered_segments),
                    filtered_segments=len(removed),
                    filtered_texts=removed,
                    srt_path=str(srt_path) if self.cfg.write_srt else None,
                    txt_path=str(txt_path) if self.cfg.write_txt else None,
                    elapsed_seconds=elapsed,
                )
                chunk_json.write_text(
                    json.dumps(asdict(result), ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                return result

            except Exception as exc:
                last_error = "".join(
                    traceback.format_exception_only(type(exc), exc)
                ).strip()
                logger.warning("[分片 %04d] 失败 | %s", chunk_index, last_error)
                if attempt <= self.cfg.retries:
                    time.sleep(min(10, attempt * 2))

        elapsed = round(time.monotonic() - started, 3)
        result = ChunkResult(
            chunk_index=chunk_index,
            chunk_start=chunk_start,
            chunk_end=chunk_end,
            success=False,
            elapsed_seconds=elapsed,
            error=last_error,
        )
        chunk_json.write_text(
            json.dumps(asdict(result), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return result

    def transcribe_with_chunks(
        self,
        source: Path,
        job_dir: Path,
    ) -> JobResult:
        """
        长音频分片转写主流程：
        1. 切分音频为多个 chunk
        2. 对每个 chunk 调用 transcribe_chunk
        3. 支持 resume：跳过已有 chunk_result.json 且 success=true 的分片
        4. 全部完成后合并所有分片 SRT/TXT 为完整字幕
        """
        started = time.monotonic()
        work_dir = job_dir / "chunks"
        merged_srt_path = job_dir / "subtitle_merged.srt"
        merged_txt_path = job_dir / "transcript_merged.txt"
        source_json = job_dir / "source.json"
        job_json = job_dir / "job_result.json"

        duration = get_audio_duration_seconds(source)
        source_json.write_text(
            json.dumps(
                {
                    "source": str(source),
                    "source_name": source.name,
                    "processed_at": datetime.now().isoformat(timespec="seconds"),
                    "config": asdict(self.cfg),
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

        # 切分音频
        logger.info("开始切分音频：%s | 每片 %.1f 秒", source, self.cfg.chunk_duration)
        try:
            chunks = split_audio_into_chunks(
                source,
                chunk_duration=self.cfg.chunk_duration,
                work_dir=work_dir,
            )
        except Exception as exc:
            error_msg = "".join(
                traceback.format_exception_only(type(exc), exc)
            ).strip()
            logger.error("切分音频失败：%s", error_msg)
            return JobResult(
                source=str(source),
                job_dir=str(job_dir),
                success=False,
                duration_seconds=duration,
                error=f"切分音频失败：{error_msg}",
            )

        logger.info("共切分为 %d 个分片", len(chunks))

        # 如果 merge-only，则不再重新转写，直接尝试合并已有结果
        if self.cfg.merge_only:
            logger.info("merge-only 模式：跳过转写，直接合并已有分片结果")
            chunk_results = []
            for index, chunk_start, chunk_end, chunk_path in chunks:
                chunk_dir = work_dir / f"chunk_{index:04d}"
                chunk_json = chunk_dir / "chunk_result.json"
                if not chunk_json.exists():
                    logger.warning("分片 %04d 没有 chunk_result.json，跳过", index)
                    continue
                data = json.loads(chunk_json.read_text(encoding="utf-8"))
                chunk_results.append(ChunkResult(**data))
            return self._merge_chunks(
                job_dir,
                work_dir,
                chunks,
                chunk_results,
                started,
                duration,
            )

        # 正常转写模式：逐分片处理
        chunk_results: List[ChunkResult] = []

        for index, chunk_start, chunk_end, chunk_path in chunks:
            chunk_dir = work_dir / f"chunk_{index:04d}"
            chunk_dir.mkdir(parents=True, exist_ok=True)
            chunk_json = chunk_dir / "chunk_result.json"

            # resume 逻辑：如果已有成功结果且未要求 overwrite，则跳过
            if self.cfg.resume and chunk_json.exists() and not self.cfg.overwrite:
                try:
                    data = json.loads(chunk_json.read_text(encoding="utf-8"))
                    if data.get("success"):
                        logger.info(
                            "[分片 %04d] 已有成功结果，跳过（resume 模式）",
                            index,
                        )
                        chunk_results.append(ChunkResult(**data))
                        continue
                except Exception:
                    logger.warning(
                        "[分片 %04d] 读取已有结果失败，将重新转写",
                        index,
                    )

            result = self.transcribe_chunk(
                chunk_path,
                index,
                chunk_start,
                chunk_end,
                chunk_dir,
            )
            chunk_results.append(result)

            if not result.success:
                logger.error(
                    "[分片 %04d] 失败，且未完全成功；继续处理后续分片",
                    index,
                )

            gc.collect()

        return self._merge_chunks(
            job_dir,
            work_dir,
            chunks,
            chunk_results,
            started,
            duration,
        )

    def _merge_chunks(
        self,
        job_dir: Path,
        work_dir: Path,
        chunks: List[Tuple[int, float, float, Path]],
        chunk_results: List[ChunkResult],
        started: float,
        duration: Optional[float],
    ) -> JobResult:
        """
        合并所有成功分片的 SRT/TXT 为完整字幕。
        - SRT：按分片顺序拼接，并对每个分片应用 start_offset = chunk_start
        - TXT：按顺序拼接所有分片文本
        """
        merged_srt_path = job_dir / "subtitle_merged.srt"
        merged_txt_path = job_dir / "transcript_merged.txt"
        cleaned_srt_path = job_dir / "subtitle_clean.srt"
        cleanup_stats = {
            "input": 0,
            "output": 0,
            "removed": 0,
            "overlap_adjustments": 0,
        }


        # 只保留成功的分片
        success_chunks = [
            (info, result)
            for info, result in zip(chunks, chunk_results)
            if result.success
        ]

        if not success_chunks:
            elapsed = round(time.monotonic() - started, 3)
            return JobResult(
                source=str(job_dir / "source"),
                job_dir=str(job_dir),
                success=False,
                duration_seconds=duration,
                error="没有任何成功的分片，无法合并。",
                elapsed_seconds=elapsed,
            )

        # 合并 SRT
        if self.cfg.write_srt:
            all_segments: List[SegmentData] = []
            for (index, chunk_start, chunk_end, chunk_path), result in success_chunks:
                srt_path = Path(result.srt_path) if result.srt_path else None
                if not srt_path or not srt_path.exists():
                    logger.warning(
                        "[分片 %04d] 没有 SRT 文件，跳过该分片合并",
                        index,
                    )
                    continue

                content = srt_path.read_text(encoding="utf-8-sig")
                segments = self._parse_srt_to_segments(content)
                # 将分片内时间戳整体偏移 chunk_start
                for seg in segments:
                    seg.start += chunk_start
                    seg.end += chunk_start
                all_segments.extend(segments)

            # ~ if all_segments:
                # ~ # 按 start 排序，保证整体时间顺序
                # ~ all_segments.sort(key=lambda s: s.start)
                # ~ segments_to_srt(all_segments, merged_srt_path, start_offset=0.0)
            # ~ else:
                # ~ logger.warning("合并后没有可用字幕段，跳过 SRT 合并。")

            cleaned_srt_path = job_dir / "subtitle_clean.srt"
            cleanup_stats = {
                "input": 0,
                "output": 0,
                "removed": 0,
                "overlap_adjustments": 0,
            }
            
            if all_segments:
                # 原有逻辑：按 start 排序并写入原始合并文件。
                all_segments.sort(key=lambda s: s.start)
                segments_to_srt(all_segments, merged_srt_path, start_offset=0.0)
            
                # 新增逻辑：不改动原始合并结果，额外生成清理、重排编号后的版本。
                try:
                    cleanup_stats = self.cleanup_merged_srt(
                        merged_srt_path,
                        cleaned_srt_path,
                    )
                except Exception as exc:
                    logger.warning(
                        "SRT 二次清理失败，保留原始合并文件：%s",
                        "".join(traceback.format_exception_only(type(exc), exc)).strip(),
                    )
            else:
                logger.warning("合并后没有可用字幕段，跳过 SRT 合并。")
                
    
    
        # 合并 TXT
        if self.cfg.write_txt:
            texts: List[str] = []
            for (index, chunk_start, chunk_end, chunk_path), result in success_chunks:
                txt_path = Path(result.txt_path) if result.txt_path else None
                if not txt_path or not txt_path.exists():
                    continue
                content = txt_path.read_text(encoding="utf-8-sig").strip()
                if content:
                    texts.append(content)
            if texts:
                merged_txt_path.write_text("\n".join(texts) + "\n", encoding="utf-8")
            else:
                logger.warning("合并后没有可用文本，跳过 TXT 合并。")

        elapsed = round(time.monotonic() - started, 3)

        total_before = sum(r.segment_count_before_filter for r in chunk_results)
        total_after = sum(r.segment_count_after_filter for r in chunk_results)
        total_filtered = sum(r.filtered_segments for r in chunk_results)

        any_failed = any(not r.success for r in chunk_results)

        # ~ return JobResult(
            # ~ source=str(job_dir / "source"),
            # ~ job_dir=str(job_dir),
            # ~ success=not any_failed,
            # ~ language=None,  # 多分片不单独记录语言
            # ~ duration_seconds=duration,
            # ~ total_segment_count_before_filter=total_before,
            # ~ total_segment_count_after_filter=total_after,
            # ~ total_filtered_segments=total_filtered,
            # ~ chunk_results=chunk_results,
            # ~ merged_srt_path=str(merged_srt_path) if self.cfg.write_srt and merged_srt_path.exists() else None,
            # ~ merged_txt_path=str(merged_txt_path) if self.cfg.write_txt and merged_txt_path.exists() else None,
            # ~ elapsed_seconds=elapsed,
            # ~ error="部分分片失败" if any_failed else None,
        # ~ )

        # ~ any_failed = any(not r.success for r in chunk_results)

        return JobResult(
            source=str(job_dir / "source"),
            job_dir=str(job_dir),
            success=not any_failed,
            language=None,  # 多分片不单独记录语言
            duration_seconds=duration,
            total_segment_count_before_filter=total_before,
            total_segment_count_after_filter=total_after,
            total_filtered_segments=total_filtered,
            cleanup_input_segment_count=cleanup_stats["input"],
            cleanup_output_segment_count=cleanup_stats["output"],
            cleanup_removed_segments=cleanup_stats["removed"],
            cleanup_overlap_adjustments=cleanup_stats["overlap_adjustments"],
            chunk_results=chunk_results,
            merged_srt_path=(
                str(merged_srt_path)
                if self.cfg.write_srt and merged_srt_path.exists()
                else None
            ),
            cleaned_srt_path=(
                str(cleaned_srt_path)
                if self.cfg.write_srt and cleaned_srt_path.exists()
                else None
            ),
            merged_txt_path=(
                str(merged_txt_path)
                if self.cfg.write_txt and merged_txt_path.exists()
                else None
            ),
            elapsed_seconds=elapsed,
            error="部分分片失败" if any_failed else None,
        )
        
        
    def _parse_srt_to_segments(self, srt_content: str) -> List[SegmentData]:
        """
        将 SRT 内容解析回 SegmentData 列表，用于合并。
        """
        segments: List[SegmentData] = []
        blocks = re.split(r"\n\s*\n", srt_content.strip())

        for block in blocks:
            lines = block.splitlines()
            if len(lines) < 3:
                continue
            if not lines[0].strip().isdigit():
                continue
            time_line = lines[1].strip()
            if "-->" not in time_line:
                continue
            start_str, end_str = time_line.split("-->", 1)
            start = self._parse_timestamp(start_str.strip())
            end = self._parse_timestamp(end_str.strip())
            text = "\n".join(lines[2:]).strip()
            if text:
                segments.append(SegmentData(start=start, end=end, text=text))

        return segments

    def _parse_timestamp(self, ts: str) -> float:
        """
        解析 SRT 时间戳：HH:MM:SS,mmm 或 HH:MM:SS.mmm
        """
        ts = ts.replace(",", ".")
        h, m, rest = ts.split(":", 2)
        s, ms = rest.split(".", 1)
        h = int(h)
        m = int(m)
        s = int(s)
        ms = int(ms.ljust(3, "0")[:3])
        return h * 3600 + m * 60 + s + ms / 1000.0

    
    def cleanup_merged_srt(
        self,
        input_path: Path,
        output_path: Path,
    ) -> dict:
        """
        对已合并 SRT 做发布前二次整理：
        - 删除空白、纯标点、start >= end 的无效段；
        - 按起始时间排序；
        - 修正与上一段重叠的开始时间；
        - 调用既有 segments_to_srt() 重新连续编号。
        原始 subtitle_merged.srt 不修改。
        """
        source_segments = self._parse_srt_to_segments(
            input_path.read_text(encoding="utf-8-sig")
        )
        input_count = len(source_segments)
    
        cleaned: List[SegmentData] = []
    
        for segment in source_segments:
            text = normalize_text(segment.text)
    
            if not text:
                continue
    
            if segment.start >= segment.end:
                continue
    
            # 删除只有标点、符号或空白的孤立段。
            if len(text) <= 1 and re.match(r"^[^\w]+$", text, re.UNICODE):
                continue
    
            cleaned.append(
                SegmentData(
                    start=float(segment.start),
                    end=float(segment.end),
                    text=text,
                )
            )
    
        cleaned.sort(key=lambda item: (item.start, item.end))
    
        overlap_adjustments = 0
        fixed: List[SegmentData] = []
    
        for segment in cleaned:
            if not fixed:
                fixed.append(segment)
                continue
    
            previous = fixed[-1]
    
            if segment.start < previous.end:
                overlap_adjustments += 1
                adjusted_start = previous.end
                adjusted_end = max(adjusted_start + 0.05, segment.end)
    
                fixed.append(
                    SegmentData(
                        start=adjusted_start,
                        end=adjusted_end,
                        text=segment.text,
                    )
                )
            else:
                fixed.append(segment)
    
        if not fixed:
            raise RuntimeError("SRT 二次清理后没有剩余有效字幕段。")
    
        # 复用原有写入函数：会重新从 1 开始连续编号。
        segments_to_srt(fixed, output_path, start_offset=0.0)
    
        stats = {
            "input": input_count,
            "output": len(fixed),
            "removed": input_count - len(fixed),
            "overlap_adjustments": overlap_adjustments,
        }
    
        cleanup_report_path = output_path.parent / "cleanup_report.json"
        cleanup_report_path.write_text(
            json.dumps(
                {
                    "input_srt": str(input_path),
                    "output_srt": str(output_path),
                    **stats,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
    
        logger.info(
            "SRT 二次清理完成：%d -> %d 段，删除 %d 段，修正重叠 %d 处 | %s",
            stats["input"],
            stats["output"],
            stats["removed"],
            stats["overlap_adjustments"],
            output_path,
        )
    
        return stats
        
        

def write_batch_report(
    batch_dir: Path,
    cfg: Config,
    results: List[JobResult],
) -> None:
    report = {
        "batch_dir": str(batch_dir),
        "finished_at": datetime.now().isoformat(timespec="seconds"),
        "config": asdict(cfg),
        "total": len(results),
        "success": sum(item.success for item in results),
        "failed": sum(not item.success for item in results),
        "items": [asdict(item) for item in results],
    }

    (batch_dir / "report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="faster-whisper SRT 批量处理器（A+B 双层片尾/广告过滤 + 长音频分片断点）",
        formatter_class=argparse.RawTextHelpFormatter,
    )

    source_group = parser.add_mutually_exclusive_group(required=True)
    source_group.add_argument("--file", type=Path, help="单个音频或视频文件")
    source_group.add_argument("--dir", type=Path, help="批量扫描媒体文件的目录")

    parser.add_argument(
        "-o", "--output", type=Path, default=DEFAULT_OUTPUT_ROOT,
        help=f"输出根目录（默认：{DEFAULT_OUTPUT_ROOT}）",
    )

    parser.add_argument(
        "--batch-name", default=None,
        help="批次目录名；默认 YYYYMMDD_HHMM，例如 20260818_1828",
    )

    parser.add_argument(
        "--model", default=DEFAULT_MODEL,
        help="faster-whisper CTranslate2 模型目录或 HF 模型名",
    )

    parser.add_argument(
        "--language", default="auto",
        help="语言代码，例如 zh、en；默认 auto 自动识别主语言",
    )

    parser.add_argument(
        "--compute-type", choices=["int8", "float32"], default="int8",
        help="CPU 计算精度（默认 int8）",
    )

    parser.add_argument(
        "--cpu-threads", type=int, default=DEFAULT_CPU_THREADS,
        help=f"CPU 线程数（默认 {DEFAULT_CPU_THREADS}）",
    )

    parser.add_argument(
        "--beam-size", type=int, default=DEFAULT_BEAM_SIZE,
        help=f"beam size（默认 {DEFAULT_BEAM_SIZE}）",
    )

    parser.add_argument(
        "--vad", action=argparse.BooleanOptionalAction, default=True,
        help="启用/关闭 VAD（默认启用；使用 --no-vad 关闭）",
    )

    parser.add_argument(
        "--condition-on-previous-text",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="启用/关闭前文上下文（默认关闭，减少幻觉）",
    )

    parser.add_argument(
        "--srt-only", action="store_true",
        help="只生成 SRT，不生成 transcript.txt",
    )

    parser.add_argument(
        "--no-srt", action="store_true",
        help="不生成 SRT，仅生成 TXT；不能与 --srt-only 同时使用",
    )

    parser.add_argument(
        "--retries", type=int, default=DEFAULT_RETRIES,
        help=f"失败重试次数（默认 {DEFAULT_RETRIES}）",
    )

    parser.add_argument(
        "--overwrite", action="store_true",
        help="覆盖已有输出文件（包括分片结果）",
    )

    parser.add_argument(
        "--credit-filter", action=argparse.BooleanOptionalAction, default=True,
        help="启用/关闭 A 层全文关键词过滤（默认启用）",
    )

    parser.add_argument(
        "--credit-tail-filter", action=argparse.BooleanOptionalAction, default=True,
        help="启用/关闭 B 层尾部过滤（默认启用）",
    )

    parser.add_argument(
        "--credit-tail-window", type=int, default=DEFAULT_CREDIT_TAIL_WINDOW,
        help=f"B 层检查最后几段（默认 {DEFAULT_CREDIT_TAIL_WINDOW}）",
    )

    parser.add_argument(
        "--credit-keywords", nargs="*", default=None,
        help="覆盖默认过滤关键词，例如：--credit-keywords 字幕 志愿者 制作",
    )

    parser.add_argument(
        "--no-recursive", action="store_true",
        help="目录模式不递归子目录",
    )

    parser.add_argument(
        "--log-level", choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="日志级别（默认 INFO）",
    )

    # 长音频相关参数
    parser.add_argument(
        "--chunk-duration", type=int, default=DEFAULT_CHUNK_DURATION,
        help=f"长音频分片时长（秒），默认 {DEFAULT_CHUNK_DURATION} 秒（15 分钟）",
    )

    parser.add_argument(
        "--resume", action="store_true",
        help="启用断点续跑：跳过已有成功分片结果",
    )

    parser.add_argument(
        "--merge-only", action="store_true",
        help="仅合并已有分片结果，不重新转写（用于调试或手动修复后）",
    )

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.srt_only and args.no_srt:
        parser.error("--srt-only 与 --no-srt 不能同时使用")
    if args.no_srt and not args.srt_only:
        parser.error("当前版本要求生成 TXT 时同时生成 SRT；请删除 --no-srt")
    if args.cpu_threads < 1:
        parser.error("--cpu-threads 必须大于 0")
    if args.beam_size < 1:
        parser.error("--beam-size 必须大于 0")
    if args.retries < 0:
        parser.error("--retries 不能小于 0")
    if args.credit_tail_window < 1:
        parser.error("--credit-tail-window 必须大于 0")
    if args.chunk_duration < 60:
        parser.error("--chunk-duration 必须 >= 60 秒")

    try:
        ensure_ffmpeg()
    except RuntimeError as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 2

    output_root = args.output.expanduser().resolve()
    batch_name = safe_name(args.batch_name) if args.batch_name else datetime.now().strftime("%Y%m%d_%H%M")
    batch_dir = output_root / batch_name
    batch_dir.mkdir(parents=True, exist_ok=True)
    setup_logging(batch_dir, args.log_level)

    keywords = tuple(args.credit_keywords) if args.credit_keywords is not None else DEFAULT_CREDIT_KEYWORDS
    cfg = Config(
        model=os.path.expanduser(args.model),
        language=None if args.language.lower() == "auto" else args.language,
        cpu_threads=args.cpu_threads,
        compute_type=args.compute_type,
        beam_size=args.beam_size,
        use_vad=args.vad,
        condition_on_previous_text=args.condition_on_previous_text,
        write_srt=not args.no_srt,
        write_txt=not args.srt_only,
        retries=args.retries,
        overwrite=args.overwrite,
        credit_filter=args.credit_filter,
        credit_tail_filter=args.credit_tail_filter,
        credit_tail_window=args.credit_tail_window,
        credit_keywords=keywords,
        chunk_duration=args.chunk_duration,
        resume=args.resume,
        merge_only=args.merge_only,
    )

    if args.file:
        source = args.file.expanduser().resolve()
        if not source.is_file():
            logger.error("文件不存在：%s", source)
            return 2
        sources = [source]
    else:
        source_dir = args.dir.expanduser().resolve()
        if not source_dir.is_dir():
            logger.error("目录不存在：%s", source_dir)
            return 2
        sources = scan_media(source_dir, recursive=not args.no_recursive)
        if not sources:
            logger.warning("目录中没有找到支持的媒体文件：%s", source_dir)
            return 0

    logger.info("批次目录：%s", batch_dir)
    logger.info("待处理文件数：%d", len(sources))
    logger.info(
        "语言：%s | CPU threads=%d | compute_type=%s | A=%s | B=%s | chunk=%ds | resume=%s | merge_only=%s",
        cfg.language or "auto",
        cfg.cpu_threads,
        cfg.compute_type,
        cfg.credit_filter,
        cfg.credit_tail_filter,
        cfg.chunk_duration,
        cfg.resume,
        cfg.merge_only,
    )

    engine = FasterWhisperEngine(cfg)
    results: List[JobResult] = []

    for index, source in enumerate(sources, start=1):
        logger.info("========== [%d/%d] ==========", index, len(sources))
        job_dir = unique_job_dir(batch_dir, source)
        result = engine.transcribe_with_chunks(source, job_dir)
        results.append(result)
        (job_dir / "job_result.json").write_text(
            json.dumps(asdict(result), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        gc.collect()

    write_batch_report(batch_dir, cfg, results)
    success_count = sum(item.success for item in results)
    failed_count = len(results) - success_count
    logger.info(
        "批次完成：总数=%d，成功=%d，失败=%d",
        len(results), success_count, failed_count,
    )

    logger.info("报告：%s", batch_dir / "report.json")
    return 1 if failed_count else 0


if __name__ == "__main__":
    raise SystemExit(main())
