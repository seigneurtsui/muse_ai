#!/usr/bin/env python3
"""Batch SRT -> styled ASS, optionally translated by the current OmniRush model."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, replace
from datetime import datetime
import glob
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time

from subtitles import EFFECTS, EFFECT_ALIASES, Highlighter, Style, SubtitleError, parse_srt, read_text, render_ass, srt_text
from translation import Translator, atomic_json, parse_languages

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_OUTPUT = Path.home() / "Downloads/srt_ass_studio"
NOTIFIER = ROOT.parent / "multiple-channel-notifier/scripts/notify.py"


def presets():
    return json.loads((ROOT / "assets/presets.json").read_text(encoding="utf-8"))


def parser():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument("inputs", nargs="*", help="SRT files, folders or quoted glob patterns")
    p.add_argument("--recursive", action="store_true")
    p.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    p.add_argument("--dry-run", action="store_true", help="parse and plan only; no AI, output writes or notifications")
    p.add_argument("--workers", type=int, default=4, help="independent file workers, 1-16")
    p.add_argument("--offset-ms", type=int, default=0)
    p.add_argument("--preset", default="cinematic", choices=sorted(presets()))
    p.add_argument("--list-presets", action="store_true")
    p.add_argument("--style-json", type=Path, help="style overrides; unknown fields are rejected")
    p.add_argument("--languages", help="one/two merged languages, e.g. source,en or zh-Hant,fr; default source")
    p.add_argument("--separate-languages", help="additional independent language files, comma-separated")
    p.add_argument("--source-language", help="explicit source language hint; enables safe local Chinese conversion")
    p.add_argument("--normalize-chinese", choices=("off", "auto", "strict"), default="auto")
    p.add_argument("--ai-model", help="explicit override; normally inherits current OMNIRUSH_MODEL")
    p.add_argument("--omnirush-bin", default="omnirush")
    p.add_argument("--ai-timeout", type=float, default=180)
    p.add_argument("--ai-workers", type=int, default=1, help="maximum simultaneous model calls, 1-4")
    p.add_argument("--ai-attempts", type=int, default=1, help="attempts per AI request, 1-3; no provider fallback")
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--batch-chars", type=int, default=6000)
    p.add_argument("--cache-dir", type=Path, help="opt-in private persistent AI response cache")
    p.add_argument("--highlight", action="append", default=[], help="literal keyword; repeat this option for more")
    p.add_argument("--highlight-keyword-file", type=Path)
    p.add_argument("--highlight-ignore-case", action="store_true")
    p.add_argument("--ai-highlight", action="store_true", help="explicitly ask OmniRush to extract visible keywords")
    p.add_argument("--max-keywords", type=int, default=40)
    p.add_argument("--effect", choices=(*EFFECTS, *EFFECT_ALIASES))
    p.add_argument("--position", choices=("bottom", "top", "center"))
    for option in ("font-name", "secondary-font", "primary-color", "secondary-color", "karaoke-color", "outline-color", "back-color", "highlight-color", "highlight-font", "overlay-text"):
        p.add_argument("--" + option, default=None)
    for option in ("font-size", "secondary-size", "width", "height", "margin-x", "margin-y", "wrap", "min-font-size", "animation-ms", "fade-in-ms", "fade-out-ms", "overlay-interval", "overlay-duration"):
        p.add_argument("--" + option, type=int, default=None)
    for option in ("outline", "shadow", "glow", "highlight-scale"):
        p.add_argument("--" + option, type=float, default=None)
    p.add_argument("--bold", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--subscribe-overlay", action=argparse.BooleanOptionalAction, default=None, help="legacy-compatible opt-in overlay; off by default")
    notify = p.add_mutually_exclusive_group()
    notify.add_argument("--notify-channels", help="explicit existing notifier instances, e.g. bark,telegram")
    notify.add_argument("--notify-all", action="store_true", help="explicitly notify all enabled channels")
    p.add_argument("--notify-when", choices=("always", "success", "failure"), default="always")
    p.add_argument("--notify-dry-run", action="store_true", help="check notifier only, do not send")
    return p


def resolve_style(args):
    values = dict(presets()[args.preset])
    if args.style_json:
        try:
            overrides = json.loads(args.style_json.expanduser().read_text(encoding="utf-8"))
        except (OSError, ValueError):
            raise SubtitleError("cannot read style JSON") from None
        if not isinstance(overrides, dict):
            raise SubtitleError("style JSON must be an object")
        values.update(overrides)
    for field in asdict(Style()):
        value = getattr(args, field, None)
        if value is not None:
            values[field] = value
    if args.subscribe_overlay is True:
        values["overlay_text"] = values.get("overlay_text") or "欢迎订阅"
    elif args.subscribe_overlay is False:
        values["overlay_text"] = ""
    return Style.from_mapping(values)


def collect_inputs(values, recursive, output_root):
    selected = {}
    output_root = output_root.resolve()
    for value in values:
        value = os.path.expanduser(value)
        matches = [Path(x) for x in glob.glob(value, recursive=recursive)] if glob.has_magic(value) else [Path(value)]
        if not matches:
            raise SubtitleError("an input pattern matched no files")
        for path in matches:
            if not path.exists():
                raise SubtitleError("an input path does not exist")
            if path.is_dir():
                if path.resolve() == output_root:
                    raise SubtitleError("output-root cannot be the same directory as an input folder")
                candidates = path.rglob("*") if recursive else path.iterdir()
            else:
                if path.suffix.lower() != ".srt":
                    raise SubtitleError("explicit input files must have an .srt extension")
                candidates = [path]
            for candidate in candidates:
                if candidate.is_file() and candidate.suffix.lower() == ".srt":
                    resolved = candidate.resolve()
                    if resolved.is_relative_to(output_root):
                        continue
                    selected.setdefault(str(resolved), resolved)
    if not selected:
        raise SubtitleError("no SRT files found (generated output folders are excluded)")
    return sorted(selected.values(), key=lambda path: str(path).casefold())


def variants(args):
    separate = parse_languages(args.separate_languages) if args.separate_languages is not None else []
    merged = parse_languages(args.languages, maximum=2) if args.languages is not None else ([] if separate else ["source"])
    result = [tuple(merged)] if merged else []
    for language in separate:
        if (language,) not in result:
            result.append((language,))
    if args.source_language is not None:
        source = parse_languages(args.source_language, maximum=1)
        if source == ["source"]:
            raise SubtitleError("source-language must be an actual language code, not source")
    return result


def keywords_from_args(args):
    values = args.highlight[:]
    if args.highlight_keyword_file:
        text, encoding = read_text(args.highlight_keyword_file.expanduser())
        values.extend(line.strip() for line in text.splitlines() if line.strip() and not line.lstrip().startswith("#"))
    return Highlighter(values, args.highlight_ignore_case).keywords


def shifted_cues(path, offset):
    text, encoding = read_text(path)
    cues = parse_srt(text)
    if offset:
        cues = [replace(cue, start=cue.start + offset, end=cue.end + offset) for cue in cues]
        if any(cue.start < 0 for cue in cues):
            raise SubtitleError("offset creates negative timestamps")
    return cues, encoding


def file_key(path):
    name = re.sub(r"[^\w.-]+", "_", path.stem, flags=re.UNICODE).strip("._")
    name = name.encode("utf-8")[:180].decode("utf-8", errors="ignore") or "subtitles"
    return name + "_" + hashlib.sha256(str(path).encode()).hexdigest()[:10]


def safe_error(exc):
    if isinstance(exc, SubtitleError):
        return str(exc)
    # The adapter's exceptions may include provider detail; never put raw text into reports.
    if exc.__class__.__name__ == "AIError":
        return "OmniRush AI request failed; check login, current model availability, timeout and JSON response contract"
    if isinstance(exc, OSError):
        return "local file read/write failed; check paths, permissions and disk space"
    return "processing failed; raw exception withheld to avoid exposing subtitle text or credentials"


def process_file(path, batch_dir, wanted, style, keywords, args, translator):
    start = time.monotonic()
    staging = None
    result = {"source": str(path), "status": "failed", "outputs": []}
    try:
        cues, encoding = shifted_cues(path, args.offset_ms)
        languages = list(dict.fromkeys(language for group in wanted for language in group))
        per_language, warnings = translator.translate(cues, languages)
        active_keywords = keywords[:]
        if args.ai_highlight:
            visible = [text for language in languages for text in per_language[language]]
            active_keywords.extend(translator.keywords(visible, args.max_keywords))
            active_keywords = Highlighter(active_keywords, args.highlight_ignore_case).keywords
        # Render every variant in memory before creating any final outputs for this source.
        artifacts = {}
        render_reports = []
        for group in wanted:
            segments = [[per_language[language][i] for language in group] for i in range(len(cues))]
            stem = ".".join(group)
            ass, stats = render_ass(cues, segments, style, active_keywords, args.highlight_ignore_case)
            artifacts[stem + ".srt"] = srt_text(cues, segments)
            artifacts[stem + ".ass"] = ass
            render_reports.append({"languages": list(group), **stats})
        if active_keywords:
            artifacts["highlight_keywords.txt"] = "\n".join(active_keywords) + "\n"
        staging = Path(tempfile.mkdtemp(prefix=".staging-", dir=batch_dir))
        for name, content in artifacts.items():
            file = staging / name
            fd = os.open(file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                stream.write(content)
        destination = batch_dir / file_key(path)
        staging.rename(destination)
        staging = None
        result.update(status="ok", encoding=encoding, cues=len(cues), warnings=warnings,
                      outputs=[str(destination.relative_to(batch_dir) / name) for name in artifacts], variants=render_reports)
    except Exception as exc:
        result["error"] = safe_error(exc)
    finally:
        if staging is not None:
            shutil.rmtree(staging, ignore_errors=True)
    result["elapsed_ms"] = round((time.monotonic() - start) * 1000)
    return result


def notify_summary(report, args, script=None):
    script = NOTIFIER if script is None else script
    if not (args.notify_channels or args.notify_all):
        return {"status": "disabled"}
    success = report["failed"] == 0
    if (args.notify_when == "success" and not success) or (args.notify_when == "failure" and success):
        return {"status": "skipped"}
    if not script.is_file():
        return {"status": "failed", "message": "multiple-channel-notifier is not installed"}
    # No filenames, paths, subtitle text, translations or private configuration in the message.
    message = f"字幕批处理结束：共 {report['total']} 个文件，成功 {report['succeeded']} 个，失败 {report['failed']} 个。"
    command = [sys.executable, str(script), "send", "--title", "SRT→ASS 批处理结果", "--content", message]
    if args.notify_channels:
        command.extend(["--channels", args.notify_channels])
    try:
        check = subprocess.run(command + ["--dry-run"], capture_output=True, text=True, timeout=180)
        checked = json.loads(check.stdout)
        if check.returncode or checked.get("status") != "dry_run":
            return {"status": "disabled" if checked.get("status") == "disabled" else "failed", "message": "notifier did not pass offline preflight; nothing sent"}
        if args.notify_dry_run:
            return {"status": "dry_run", "message": "notifier configuration validated; nothing sent"}
        sent = subprocess.run(command, capture_output=True, text=True, timeout=180)
        data = json.loads(sent.stdout)
        return {"status": "accepted" if sent.returncode == 0 and data.get("accepted", 0) > 0 else "failed",
                "accepted": data.get("accepted", 0), "results": data.get("results", [])}
    except (OSError, ValueError, subprocess.TimeoutExpired):
        return {"status": "failed", "message": "notifier failed or timed out; delivery unknown; no automatic resend"}


def validate_args(args):
    limits = {"workers": (1, 16), "ai_workers": (1, 4), "ai_attempts": (1, 3), "batch_size": (1, 200),
              "batch_chars": (100, 30000), "max_keywords": (1, 200)}
    for key, (low, high) in limits.items():
        if not low <= getattr(args, key) <= high:
            raise SubtitleError(f"{key} must be in [{low}, {high}]")
    if not 1 <= args.ai_timeout <= 3600:
        raise SubtitleError("ai-timeout must be in [1, 3600] seconds")
    if args.notify_channels is not None and not re.fullmatch(r"[A-Za-z0-9_-]+(?:,[A-Za-z0-9_-]+)*", args.notify_channels):
        raise SubtitleError("notify-channels must be a nonempty comma-separated instance list")
    if args.notify_dry_run and not (args.notify_channels or args.notify_all):
        raise SubtitleError("notify-dry-run needs notify-channels or notify-all")
    if not args.inputs:
        raise SubtitleError("provide at least one input file, folder or pattern")


def run(args):
    validate_args(args)
    style = resolve_style(args)
    wanted = variants(args)
    keywords = keywords_from_args(args)
    output_root = args.output_root.expanduser().resolve()
    inputs = collect_inputs(args.inputs, args.recursive, output_root)
    requested = list(dict.fromkeys(language for group in wanted for language in group))
    ai_possible = args.ai_highlight or any(language != "source" and language != args.source_language for language in requested)
    if args.dry_run:
        plans = []
        for path in inputs:
            try:
                cues, encoding = shifted_cues(path, args.offset_ms)
                plans.append({"source": str(path), "status": "ready", "cues": len(cues), "encoding": encoding})
            except Exception as exc:
                plans.append({"source": str(path), "status": "failed", "error": safe_error(exc)})
        return {"ok": all(item["status"] == "ready" for item in plans), "status": "dry_run", "ai_may_be_required": ai_possible,
                "variants": [list(group) for group in wanted], "style": asdict(style), "files": plans, "notification": {"status": "disabled"}}
    client = None
    client_factory = None
    if ai_possible:
        from omnirush_ai import OmniRushAI
        client_factory = lambda: OmniRushAI(model=args.ai_model, timeout=args.ai_timeout, executable=args.omnirush_bin)
        client = client_factory()
    translator = Translator(client, batch_size=args.batch_size, batch_chars=args.batch_chars, attempts=args.ai_attempts,
                            ai_workers=args.ai_workers, cache_dir=args.cache_dir.expanduser() if args.cache_dir else None,
                            source_language=args.source_language, normalize=args.normalize_chinese,
                            client_factory=client_factory if args.ai_workers > 1 else None)
    output_root.mkdir(parents=True, exist_ok=True)
    batch_dir = Path(tempfile.mkdtemp(prefix=datetime.now().strftime("%Y%m%d_%H%M%S_") , dir=output_root))
    start = time.monotonic()
    with ThreadPoolExecutor(max_workers=min(args.workers, len(inputs))) as pool:
        results = list(pool.map(lambda path: process_file(path, batch_dir, wanted, style, keywords, args, translator), inputs))
    succeeded = sum(result["status"] == "ok" for result in results)
    report = {"ok": succeeded == len(inputs), "status": "complete", "batch_dir": str(batch_dir), "total": len(inputs),
              "succeeded": succeeded, "failed": len(inputs) - succeeded, "preset": args.preset, "effect": style.effect,
              "ai": {"provider": "omnirush" if client else None, "model": getattr(client, "model", None),
                     "served_models": sorted(translator.served_models), **translator.stats},
              "elapsed_ms": round((time.monotonic() - start) * 1000), "files": results}
    # Save conversion results first so a notification issue never loses completed work.
    atomic_json(batch_dir / "report.json", report)
    report["notification"] = notify_summary(report, args)
    atomic_json(batch_dir / "report.json", report)
    return report


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        if args.list_presets:
            print(json.dumps({"presets": presets(), "effects": EFFECTS}, ensure_ascii=False, indent=2))
            return 0
        report = run(args)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        if not report["ok"]:
            return 1
        return 3 if report.get("notification", {}).get("status") == "failed" else 0
    except (SubtitleError, OSError, ValueError, ImportError) as exc:
        print(json.dumps({"ok": False, "status": "configuration_error", "message": safe_error(exc)}, ensure_ascii=False))
        return 2
    except Exception as exc:
        print(json.dumps({"ok": False, "status": "configuration_error", "message": safe_error(exc)}, ensure_ascii=False))
        return 2
    except KeyboardInterrupt:
        print(json.dumps({"ok": False, "status": "interrupted", "message": "interrupted; check the private output batch before rerunning"}))
        return 130


if __name__ == "__main__":
    sys.exit(main())
