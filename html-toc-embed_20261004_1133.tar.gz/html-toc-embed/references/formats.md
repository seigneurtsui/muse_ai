# 格式与接口

## CLI

```text
batch_add_toc.py INPUT_DIR [OUTPUT_DIR] [options]
```

| 选项 | 说明 |
|---|---|
| `INPUT_DIR` | 输入目录（必须存在）。 |
| `OUTPUT_DIR` | 位置参数形式的输出目录（可选）。 |
| `-o, --output OUTPUT` | 输出目录（覆盖位置参数；默认 `~/Downloads/html_toc_silo`）。 |
| `-r, --recursive` | 下钻子目录并保持目录结构；否则只处理顶层。 |
| `--in-place` | 原子改写源文件本身（输出目录 = 输入目录）。 |
| `--levels LEVELS` | 纳入目录的标题级别，逗号或空格分隔（默认 `2,3`；取值 1–6）。 |
| `--min-headings N` | 标题数少于 N 时跳过目录面板（默认 `1`；仍执行清理/基础注入）。 |
| `--no-wrap-tables` | 不包裹 `<table>`。 |
| `--toc-title TITLE` | 目录面板标题（默认 `目录导航`；会被 HTML 转义）。 |
| `--exclude-pattern REGEX` | 按文件名正则排除；可重复。值以 `-` 开头（如 `'-draft'`）也可直接使用。 |
| `--jobs N` | 并行工作线程数（默认 `auto`，上限 8，且不超过文件数）。 |
| `--incremental` | 目标内容未变则跳过。 |
| `--force` | 即使未变也重写。 |
| `--dry-run` | 只规划，不写任何文件。 |
| `--json` | 把 JSON 报告打印到 stdout（日志走 stderr）。 |
| `--report FILE` | 另将 JSON 报告写入该文件。 |
| `--verbose` / `--log-file FILE` | 详细日志 / 追加日志文件。 |
| `-v, --version` | 打印版本（`batch_add_toc.py 1.0.0`）。 |

> `_normalize_argv` 会把 `--output/--levels/--min-headings/--toc-title/--jobs/--exclude-pattern/--report/--log-file` 的「空格 + 值」改写为 `opt=value`，因此以 `-` 开头的值不会被 argparse 误判为选项。

## 报告字段（JSON）

```jsonc
{
  "version": "1.0.0",
  "generated_at": "ISO-8601",
  "input_dir": "/abs",
  "output_dir": "/abs",
  "recursive": false,
  "in_place": false,
  "dry_run": false,
  "status": "complete | partial_failure | dry_run",   // 错误时为 "error"
  "summary": {
    "total": 0,           // 处理的文件数
    "success": 0,         // status 为 success/planned 的数量
    "skipped": 0,         // --incremental 跳过的数量
    "failed": 0,          // 单文件失败数量
    "toc_documents": 0,   // 实际注入了目录面板的文档数
    "headings": 0         // 纳入目录的标题总数
  },
  "files": [
    {
      "source": "/abs/in/a.html",
      "output": "/abs/out/a.html",
      "status": "success | planned | skipped | failed",
      "headings": 2,          // 纳入目录级别的标题数
      "toc_items": 2,         // 目录条目数（未注入目录时为 0）
      "tables": 1,            // 包裹的表格数
      "bytes": 1234,          // 处理后 UTF-8 字节数
      "elapsed_seconds": 0.001,
      "reason": "unchanged | read_failed | write_failed"  // 视情况出现
    }
  ],
  "elapsed_seconds": 1.23,
  "report_path": "/abs/report.json"   // 仅 --report
}
```

## 退出码

- `0`：批次完成（`complete`/`dry_run`）且无单文件失败。
- `2`：批次运行但至少一个文件失败（`partial_failure`）。
- `1`：无法启动（参数/路径边界错误、输入目录不存在）。

## 错误码

启动/参数错误（退出 1；`--json` 时输出 `{"status":"error","reason":...}`）：

- `input_not_found`：输入目录不存在。
- `output_equals_input`：输出目录等于输入目录（非 `--in-place`）。
- `output_within_input`：输出目录位于输入目录内部。
- `invalid_levels`：`--levels` 非 1–6 的整数集合。
- `invalid_min_headings`：`--min-headings` 为负。
- `invalid_jobs_value`：`--jobs` 既非整数、也非 `auto`。
- `unexpected_error`：其它异常。

单文件失败（计入 `failed`，使批次成为 `partial_failure`，退出码 2）：

- `read_failed`：读取源文件失败。
- `write_failed`：写入目标文件失败。
