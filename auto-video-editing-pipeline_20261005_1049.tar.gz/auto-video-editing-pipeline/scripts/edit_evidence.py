#!/usr/bin/env python3
"""Phrase-safe cut handles and a source-to-output edit decision list."""
from __future__ import annotations

import copy
import math
from pathlib import Path

try:
    from .edit_mode import validate_plan
    from .srt_utils import read_cues
except ImportError:
    from edit_mode import validate_plan
    from srt_utils import read_cues


def padded_ranges(ranges: list[dict], source_srt: Path, duration: float, padding_ms: float) -> list[dict]:
    """Expand only into subtitle gaps; never repeat padding at contiguous joins."""
    if not math.isfinite(padding_ms) or not 0 <= padding_ms <= 200:
        raise ValueError("cut padding must be between 0 and 200 ms (0 disables)")
    result = copy.deepcopy(ranges)
    validate_plan({"ranges": result}, source_srt, duration)
    cues = read_cues(source_srt)
    padding = padding_ms / 1000
    for index, item in enumerate(result):
        start, end = item["start"], item["end"]
        previous = ranges[index - 1] if index else None
        following = ranges[index + 1] if index + 1 < len(ranges) else None
        left = max([0.0] + [b for a, b, _ in cues if b <= start + 0.001])
        right = min([duration] + [a for a, b, _ in cues if a >= end - 0.001])
        new_start = start if previous and abs(float(previous["end"]) - start) < 0.001 else max(left, start - padding)
        new_end = end if following and abs(float(following["start"]) - end) < 0.001 else min(right, end + padding)
        # Timelapses cannot gain spoken handles even when transcript gaps are tiny.
        item.update(requested_start=start, requested_end=end, start=round(new_start, 6), end=round(new_end, 6),
                    padding_before_ms=round((start - new_start) * 1000, 3),
                    padding_after_ms=round((new_end - end) * 1000, 3))
    validate_plan({"ranges": result}, source_srt, duration)
    return result


def build_edl(source: str, source_sha256: str, source_srt: Path, ranges: list[dict], durations: list[float], audio_fade_ms: float) -> dict:
    if len(ranges) != len(durations) or any(not math.isfinite(value) or value <= 0 for value in durations):
        raise ValueError("EDL requires one positive duration per range")
    cues = read_cues(source_srt)
    entries = []
    offset = 0.0
    for index, (item, actual) in enumerate(zip(ranges, durations), 1):
        quote = " ".join(" ".join(body) for a, b, body in cues if a < item["end"] and b > item["start"])
        entries.append({
            "id": index, "source": source, "source_sha256": source_sha256,
            "start": item["start"], "end": item["end"], "speed": item["speed"],
            "requested_start": item.get("requested_start", item["start"]),
            "requested_end": item.get("requested_end", item["end"]),
            "padding_before_ms": item.get("padding_before_ms", 0), "padding_after_ms": item.get("padding_after_ms", 0),
            "beat": item.get("kind", "body"), "quote": quote,
            "reason": item.get("reason", "explicit trim/speed"),
            "transcript_engine": "faster-whisper-stt", "confidence": "lower-confidence phrase-level",
            "output_start": round(offset, 6), "output_end": round(offset + actual, 6),
            "output_duration": actual, "audio_fade_ms": min(audio_fade_ms, actual * 500),
        })
        offset += actual
    return {"version": 1, "time_unit": "seconds", "transcript_engine": "faster-whisper-stt",
            "confidence": "lower-confidence phrase-level", "duration_basis": "video timeline (measured for edit segments)",
            "duration": round(offset, 6), "entries": entries,
            "boundaries": [entry["output_start"] for entry in entries] + [round(offset, 6)]}
