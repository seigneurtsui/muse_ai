# 项目说明

请阅读[使用指南](https://example.com/guide)，并保留变量 {name}。

```python
print("不要翻译代码")
```
