# 可选批次完成通知

## 行为与边界

电子书核心命令仍是 `batch_sumup_ebook.py /path/to/ebook/docs`，无新增自动联网行为。
通知由加载本技能的 OmniRush 会话在批次真正结束后按用户要求执行，默认关闭。
“完成”包括转换、分块摘要、全文摘要、现代启示、播报稿和最终校验，不是在 EPUB 刚转成 TXT 时就发送。

仅要求创建、配置或测试通知功能，不代表授权向真实渠道发消息。
未明确目标时先询问；不能因为通知配置已有启用渠道就默认全部发送。
如果需要把书籍摘要片段或正文也放入通知，须另行确认内容及收件范围，本版本不自动附加。

## 复用已有通知技能

入口：`../scripts/notify_result.py`，Python 标准库。
它只整理已完成的报告、生成消息、保存尝试记录，再通过独立子进程调用兄弟技能的 `scripts/notify.py`。
不复制任何 HTTP/SMTP 客户端，不导入旧通知代码，不修改通知技能、配置或 `.env`。

通知技能说明位于：

```text
~/.config/omnirush/skills/multiple-channel-notifier/SKILL.md
~/.config/omnirush/skills/multiple-channel-notifier/references/configuration.md
```

真实通知支持的渠道及其配置约束，以该技能为准；本适配器不声称所有渠道都已实发验证。
只需处理电子书而不通知时，无须安装或配置通知技能。

## 用法

```bash
HELPER="$HOME/.config/omnirush/skills/batch-sumup-ebook/scripts/notify_result.py"
REPORT="$HOME/Downloads/summary_voice/batch_result.json"

# 默认只生成本地预览，不读取任何渠道或密钥配置
python3 "$HELPER" "$REPORT"

# 指定实例进行离线演练，不向外发送
python3 "$HELPER" "$REPORT" --channels bark,telegram --dry-run

# 用户授权后的实际发送
python3 "$HELPER" "$REPORT" --channels bark,telegram --send

# 使用已存在的分组（仅示例，不自动创建或启用 personal）
python3 "$HELPER" "$REPORT" --profile personal --dry-run
python3 "$HELPER" "$REPORT" --profile personal --send

# 仅在用户明确要求所有已启用渠道时
python3 "$HELPER" "$REPORT" --all-enabled --send
```

- `--channels`、`--profile`、`--all-enabled` 互斥；演练或发送时必须指定一个。
- `--dry-run`、`--send` 互斥；都不指定时是本地预览。
- `--config /path/config.json`、`--env-file /path/.env` 原样传给通知技能，不修改文件。
- 省略配置参数时沿用通知技能默认值及其 `OMNIRUSH_NOTIFY_CONFIG`、`OMNIRUSH_NOTIFY_ENV_FILE` 环境覆盖。
- `--send` 内部仍先执行同一消息的 `send --dry-run`；未通过校验不会开始发送。
- 通知子进程总等待时间最多 600 秒。超时被标记为投递未知，不自动重发。

## 消息示例

下列为格式示例，实际内容从完整批次报告读取：

```text
电子书处理结束｜完成

OmniRush 电子书批次报告
总计 1 本｜成功 1｜跳过 0｜待更新 0｜失败 0
范围：转换、摘要、现代启示、播报稿与最终校验已结束；失败项见下文。
输入：/path/to/ebook/docs
输出：~/Downloads/summary_voice

1. [成功] 谈判技巧
文稿：6184 字符；预估 19.6 分钟
中文：5654 字；段落：50；高相似段落对：0
校验：通过
文稿：~/Downloads/summary_voice/谈判技巧/summary_voice.txt

成功书籍产物：summary.txt、summary.md、modern_insights.md、summary_voice.txt、validation.json。
时长按每秒 5.27 字估算；未合成音频。
未包含书籍正文、摘要全文、原始日志或密钥。
完整报告（本机路径）：~/Downloads/summary_voice/batch_result.json
```

报告包括全部计数，优先展示失败与待更新项。正文加标题限制为 3600 个 UTF-16 单元，
为 Telegram 的 4096 上限保留余量；书名和路径可缩略。超过长度时明确列出未展开书籍数量，
不静默丢失失败统计，也不自动拆分成多条通知。其他服务仍可能有自己的限制，以演练/发送结果为准。
路径只是本机位置，不是可供远端下载的链接；不会上传电子书或附件。
失败原因采用固定分类，原始转换错误只保留在本地，避免把日志中的私人内容外发。

## 本地文件与重复发送保护

消息保存在**输入报告所在目录**的：

```text
.ebook-notifications/<报告内容哈希>/
├── message.txt
├── message.json
├── lock
└── <通知配置路径哈希>.delivery.json
```

预览和演练不会产生发送尝试记录。消息及 JSON 文件使用 `600` 权限，事件目录使用 `700`。
适配器不更改 `batch_result.json`、书籍文件、摘要或校验结果。

发送前先落盘记录具体渠道的尝试，再调用通知技能；调用结束后保存其逐渠道结果。
同一报告、同一配置路径、同一渠道即使再次调用也不会自动重发，包括先前失败、超时或中断的情况。
选择更多渠道时，仅向尚未尝试的新渠道发送；已接受的渠道不会随整个批次重新发送。
跨进程文件锁防止同一报告同时发送。

这不是 exactly-once 投递保证：通知服务本身的重试设置、服务端行为及发送后断连都可能造成不确定结果。
配置文件在同一路径更换了收件人时，既有同名渠道仍视作已尝试；不会以更改配置为理由自动重发。
不同报告内容会产生新事件，不能把本地保护理解为对相似通知的永久去重。

确实需要重新发送时，先检查尝试记录和服务端状态，取得用户明确授权，再使用通知技能的原生 CLI
针对限定渠道发送 `message.txt`，不要删除记录来绕过去重，也不要自动重试完整渠道集合。
本地报告内保留真实错误，通知文案使用的是分类摘要，两者用途不同。

## 状态解释

| 状态 | 含义 |
| --- | --- |
| `preview` | 已生成本地消息，没有读取通知配置或发送 |
| `dry_run` / `ready` | 离线校验通过，不代表网络或凭据有效 |
| `complete` / `accepted` | 服务端已接受相应请求，未验证最终送达 |
| `disabled` | 通知技能总开关关闭，未发送 |
| `already_attempted` | 选中的渠道已尝试过，本次未重新发送；看保存的逐渠道结果 |
| `configuration_error` / `unavailable` | 配置有问题或通知技能缺失，没有开始本次发送 |
| `unknown` | 超时、进程异常或无法读取结果；可能已经发送，不自动重发 |
| `notification_error` | 输入报告、目标选择或本地状态异常，不修改电子书结果 |

通知脚本的退出码 `1` 表示通知步骤有问题，不表示电子书处理失败。
主流程是否成功，仍以其 `batch_result.json` 为准。

## 本地验证

```bash
python3 -m unittest discover \
  -s "$HOME/.config/omnirush/skills/batch-sumup-ebook/tests" -v
```

当前通知回归覆盖：默认不发送、只接受完整批次、详细文案、长度控制、原始错误不外发、
真实通知 CLI 的离线演练、本机回环 Webhook 发送、分组选择、禁用状态、部分失败隔离、
发送前失败阻止联网、超时/中断记录、跨调用重复保护及追加渠道。
所有发送测试使用合成数据和本机回环地址，没有向用户的真实渠道发送测试消息。
