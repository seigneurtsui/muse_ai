# R2 Explorer Share API 参考

基于 [r2explorer.com](https://r2explorer.com) 文档与上游源码（cybersoulja/r2-explorer）整理的完整路由表。
API 根地址：`https://disk.allez.cc.cd`。除 `/share/:shareId` 外全部需要 Basic Auth。

## 分享链接（核心功能）

> ⚠️ **实测状态（2026-10-09）**：`disk.allez.cc.cd` 跑的是 R2 Explorer **v1.1.10**，
> 其分享子系统服务端故障——创建/列表/撤销分享链接全部返回 `500`（空响应）。
> `r2x.py share/shares/revoke` 命令已按该版本的接口形状写好，待服务端修复或升级后即可用。
> 该版本管理台 UI 的 "Get sharable link" 只是复制**带鉴权的**文件 URL，并非免登录公开链接。

| 方法 | 路径 | 说明 |
|---|---|---|
| `POST` | `/api/buckets/:bucket/share` | 创建分享链接（v1.1.10：key 在 JSON body，非 path） |
| `GET` | `/api/buckets/:bucket/shares` | 列出全部分享链接 |
| `DELETE` | `/api/buckets/:bucket/share/:shareId` | 撤销分享链接 |
| `GET` | `/share/:shareId` | 公开访问（免鉴权） |

创建请求体（v1.1.10 实测）：

```json
{
  "key": "docs/report.pdf",  // 必填：对象 key（明文，非 base64）
  "customMetadata": {},      // 必填：可为空对象
  "httpMetadata": {},        // 必填：可为空对象
  "expiresIn": 3600,         // 可选：有效期（秒）
  "password": "secret",      // 可选：访问密码
  "maxDownloads": 10         // 可选：下载次数上限
}
```

> 最新版文档（r2explorer.com）写的是 `POST /api/buckets/:bucket/:base64Key/share`，
> 那是新版路由；**v1.1.10 用上面这个 body 形式**，不要混用。

```json
{
  "expiresIn": 3600,     // 有效期（秒），不填则永久
  "password": "secret",  // 访问密码，SHA-256 存储；访问时 URL 追加 ?password=secret
  "maxDownloads": 10     // 下载次数上限，超限返回 403
}
```

响应：`{"shareId": "abc123xyz9", "shareUrl": "https://disk.allez.cc.cd/share/abc123xyz9", "expiresAt": 1735574400000}`

错误码：`401` 密码缺失/错误，`403` 下载次数超限，`404` 链接不存在/已撤销，`410` 已过期。

## 文件操作

| 方法 | 路径 | 说明 |
|---|---|---|
| `POST` | `/api/buckets/:bucket/upload?key=<base64key>` | 上传单个文件，body 为原始字节，`Content-Type: application/octet-stream`；可选 `customMetadata`/`httpMetadata`（base64 JSON）查询参数 |
| `GET` | `/api/buckets/:bucket/:base64Key` | 下载文件 |
| `GET` | `/api/buckets/:bucket` | 列出对象（游标分页，`?limit=&cursor=&prefix=`） |
| `HEAD` | `/api/buckets/:bucket/:base64Key` | 对象元数据 |
| `POST` | `/api/buckets/:bucket/delete` | 删除对象 |
| `POST` | `/api/buckets/:bucket/move` | 移动/重命名 |
| `POST` | `/api/buckets/:bucket/copy` | 复制 |
| `POST` | `/api/buckets/:bucket/folder` | 创建文件夹 |
| `POST` | `/api/buckets/:bucket/multipart/{create,upload,complete}` | 大文件分片上传 |

## Key 编码

`:key` 路径段与 `?key=` 查询参数都要求 **base64 编码的对象 key**（UTF-8 → base64 → URL 转义）。

```python
import base64, urllib.parse
b64 = urllib.parse.quote(base64.b64encode(key.encode("utf-8")).decode(), safe="")
```

## 鉴权

- 管理接口：`Authorization: Basic base64(username:password)`（见 security 文档）。
- 分享访问链接 `/share/:shareId` 故意绕过鉴权；敏感文件务必加密码 + 有效期。
- 服务端 `readonly: true`（默认）会拦截所有写操作（上传/分享创建等）；若写操作报 403，先确认服务端已关只读模式。
- 分享元数据存在 bucket 内 `.r2-explorer/sharable-links/{shareId}.json`，撤销即删除该对象。
