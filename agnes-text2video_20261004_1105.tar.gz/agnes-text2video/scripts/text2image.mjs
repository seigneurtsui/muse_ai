#!/usr/bin/env node
/**
 * text2image.mjs — Generate an image from a text prompt via Agnes AI
 *
 * Usage:
 *   node text2image.mjs --prompt "a cat on a beach"
 *
 * Options:
 *   --prompt     Text description (required)
 *   --model      Model name (default: agnes-image-2.1-flash)
 *   --size       Image dimensions, e.g. 2048x2048 (default: 2048x2048)
 *   --output     Output filename (auto-generated if omitted)
 *   --dir        Output directory (default: ~/Downloads/text2video)
 *   --no-save    Print the URL but don't download
 */

import { generateImage } from './agnes.mjs';
import { mkdirSync, writeFileSync, statSync } from 'fs';
import { resolve } from 'path';
import { homedir } from 'os';

const DEFAULT_DIR = resolve(homedir(), 'Downloads', 'text2video');

function parseArgs() {
  const args = {};
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i++) {
    if (argv[i].startsWith('--')) {
      const key = argv[i].slice(2);
      if (i + 1 < argv.length && !argv[i + 1].startsWith('--')) {
        args[key] = argv[i + 1];
        i++;
      } else {
        args[key] = true;
      }
    }
  }
  return args;
}

function slugify(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 60);
}

async function download(url, dest) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Download failed: ${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  writeFileSync(dest, buf);
  return dest;
}

async function main() {
  const opts = parseArgs();

  if (!opts.prompt) {
    console.error('Usage: node text2image.mjs --prompt "your description" [--size 3840x2160] [--dir path]');
    process.exit(1);
  }

  const prompt = opts.prompt;
  const model = opts.model || 'agnes-image-2.1-flash';
  const size = opts.size || '3840x2160';
  const outDir = resolve(opts.dir || DEFAULT_DIR);
  const noSave = opts['no-save'] === true;

  console.log(`Generating image...`);
  console.log(`  Model: ${model}`);
  console.log(`  Prompt: ${prompt}`);
  console.log(`  Size: ${size}`);

  const result = await generateImage({
    prompt,
    model,
    size,
  });

  const url = result.data?.[0]?.url;
  if (!url) {
    console.error('No image URL in response:', JSON.stringify(result, null, 2));
    process.exit(1);
  }

  if (noSave) {
    console.log(`\nImage URL: ${url}`);
    return;
  }

  mkdirSync(outDir, { recursive: true });

  const ext = url.includes('.png') ? 'png' : 'jpg';
  const filename = opts.output
    ? (opts.output.endsWith(`.${ext}`) ? opts.output : `${opts.output}.${ext}`)
    : `${slugify(prompt)}-${Date.now()}.${ext}`;

  const dest = resolve(outDir, filename);
  await download(url, dest);

  const kb = statSync(dest).size / 1024;
  console.log(`\n✓ Saved: ${dest} (${kb.toFixed(0)} KB)`);
  console.log(`  URL: ${url}`);
}

main().catch(err => {
  console.error(err.message);
  process.exit(1);
});
