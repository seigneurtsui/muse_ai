"""Synthetic format/attack fixtures only; no network, provider or private files."""

import copy
import json
from pathlib import Path
import random
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import translation_documents as documents  # noqa: E402
from translation_documents import (  # noqa: E402
    DocumentError,
    MAX_JSON_DEPTH,
    MAX_UNIT_CHARS,
    prepare_document,
    render_document,
    validate_translation,
)


class DocumentTests(unittest.TestCase):
    def identity(self, source, extension, max_chars=1500):
        plan = prepare_document(source, extension, max_chars)
        # Persistence must not require dataclasses, tuples or integer object keys.
        restored = json.loads(json.dumps(plan, ensure_ascii=False))
        self.assertEqual(restored, plan)
        self.assertEqual(
            render_document(restored, {u["id"]: u["text"] for u in plan["units"]}),
            source,
        )
        self.assertEqual(
            [u["id"] for u in plan["units"]], list(range(len(plan["units"])))
        )
        self.assertTrue(all(0 < len(u["text"]) <= max_chars for u in plan["units"]))
        return plan

    def translated(self, source, extension, mapping, max_chars=1500):
        plan = self.identity(source, extension, max_chars)
        replacements = {
            u["id"]: mapping.get(u["text"], u["text"]) for u in plan["units"]
        }
        return render_document(plan, replacements)

    def reject_output(self, source, extension, replacement):
        plan = prepare_document(source, extension)
        self.assertTrue(plan["units"])
        translations = {u["id"]: u["text"] for u in plan["units"]}
        translations[0] = replacement
        with self.assertRaises(DocumentError):
            render_document(plan, translations)

    def test_all_extensions_and_unchanged_names(self):
        samples = {
            ".txt": "Paris\r\n東京\rAlice\n",
            ".md": "# Paris\n\nHello **Alice**!\n",
            ".markdown": "[Paris](https://example.invalid/city)\n",
            ".srt": "1\r\n00:00:01,000 --> 00:00:02,000\r\nParis\r\n",
            ".vtt": "WEBVTT\n\nid\n00:01.000 --> 00:02.000\nParis\n",
            ".csv": 'city,person\r\n"Paris",Alice\r\n',
            ".json": '{ "city": "Paris", "n": 1e+02, "ok": true, "nil": null }\n',
        }
        for extension, source in samples.items():
            with self.subTest(extension=extension):
                self.assertTrue(self.identity(source, extension)["units"])

    def test_empty_and_numeric_text_need_no_translation(self):
        for source in ("", " \t\r\n", "123\n-5.25\r\n1e3\n١٢٣\n", "😺!!!"):
            with self.subTest(source=source):
                plan = self.identity(source, ".txt")
                self.assertEqual(plan["units"], [])

    def test_any_script_is_eligible(self):
        source = "Hello\nBonjour\nمرحبا\nこんにちは\nЗдравствуйте\n你好\n"
        plan = self.identity(source, ".txt")
        self.assertEqual(len(plan["units"]), 6)
        result = render_document(plan, {u["id"]: "Salut !" for u in plan["units"]})
        self.assertEqual(result, "Salut !\n" * 6)

    def test_preserve_source_whitespace_and_punctuation_changes(self):
        source = "  Hello,  world! \t\r\n\tGood morning.  \rFinal\n"
        output = self.translated(
            source,
            ".txt",
            {
                "Hello,  world!": "Bonjour le monde !",
                "Good morning.": "おはよう。",
                "Final": "Fin",
            },
        )
        self.assertEqual(output, "  Bonjour le monde ! \t\r\n\tおはよう。  \rFin\n")
        validate_translation("  Good  morning! ", "  Bonjour ! ")

    def test_all_physical_newline_forms_remain_exact(self):
        source = "A\r\nB\rC\nD\vE\fF\x85G\u2028H\u2029I"
        plan = self.identity(source, ".txt", 1)
        self.assertEqual(len(plan["units"]), 9)
        output = render_document(plan, {u["id"]: "Z" for u in plan["units"]})
        self.assertEqual(output, "Z\r\nZ\rZ\nZ\vZ\fZ\x85Z\u2028Z\u2029Z")

    def test_generic_tokens_are_not_sent_for_translation(self):
        source = 'Hello {name} {{other}} %(person)s %s ${home} 12.50 -3e+2 ١٢٣ https://example.invalid/a?q=1 <b title="key">world</b> `code(42)` &amp; --> done'
        plan = self.identity(source, ".txt")
        self.assertEqual([u["text"] for u in plan["units"]], ["Hello", "world", "done"])
        output = render_document(plan, {u["id"]: "Bonjour" for u in plan["units"]})
        self.assertIn("{name} {{other}} %(person)s %s ${home} 12.50 -3e+2 ١٢٣", output)
        self.assertIn(
            'https://example.invalid/a?q=1 <b title="key">Bonjour</b> `code(42)` &amp; -->',
            output,
        )

    def test_nested_placeholders_comments_and_raw_code(self):
        source = "Hello {count, plural, one {item} other {items}} <!-- private grammar --> <code>code\n42</code> <script>call('x')</script> world"
        plan = self.identity(source, ".txt")
        self.assertEqual([u["text"] for u in plan["units"]], ["Hello", "world"])

    def test_xml_processing_and_cdata_are_untouched(self):
        source = '<?xml version="1.0"?> <p>Hello</p> <![CDATA[Code<42]]>'
        plan = self.identity(source, ".txt")
        self.assertEqual([u["text"] for u in plan["units"]], ["Hello"])

    def test_translation_guards_reject_tokens_and_whitespace_attacks(self):
        for after in (
            "",
            "...",
            "Hello\nthere",
            " Hello",
            "Hello ",
            "Hello\tthere",
            "<b>Hello</b>",
            "Hello {x}",
            "Hello 12",
            "https://example.invalid/",
            "`hello`",
            "Hello\x00",
            "Hello\u202e",
            "Hello\ufeff",
            "Hello **there**",
        ):
            with self.subTest(after=after):
                self.reject_output("Hello", ".txt", after)
        for before, after in (
            ("Hello 12", "Hola 13"),
            ("Hello {x}", "Hola {y}"),
            ("Hello %s", "Hola %d"),
            ("Hi https://example.invalid/a", "Hola https://example.invalid/b"),
            ("Hi --> there", "Hola -> allí"),
            ("<b>Hello</b>", "<i>Hola</i>"),
        ):
            with self.subTest(before=before):
                with self.assertRaises(DocumentError):
                    validate_translation(before, after)

    def test_internal_number_and_placeholder_joins_allow_natural_word_spacing(self):
        source = "  支持3种语言。\r\n欢迎{name}参加。\n"
        plan = prepare_document(source, ".txt")
        choices = {
            "支持": "Supports ",
            "种语言。": " languages.",
            "欢迎": "Welcome ",
            "参加。": " to join.",
        }
        output = render_document(
            plan, {u["id"]: choices[u["text"]] for u in plan["units"]}
        )
        self.assertEqual(output, "  Supports 3 languages.\r\nWelcome {name} to join.\n")
        for unit in plan["units"]:
            self.assertLessEqual(len(unit["context"]["before"]), 120)
            self.assertLessEqual(len(unit["context"]["after"]), 120)
        choices["支持"] = "Supports  "
        with self.assertRaises(DocumentError):
            render_document(plan, {u["id"]: choices[u["text"]] for u in plan["units"]})

    def test_internal_padding_does_not_loosen_markdown_delimiters_or_line_edges(self):
        for source in ("*你好*", "[你好](https://example.test)", "你好\n"):
            plan = prepare_document(source, ".md")
            for replacement in (" Hello", "Hello "):
                with self.subTest(
                    source=source, replacement=replacement
                ), self.assertRaises(DocumentError):
                    render_document(plan, {u["id"]: replacement for u in plan["units"]})

    def test_unchanged_and_inner_spaces_permitted(self):
        for before, after in (
            ("Paris", "Paris"),
            ("你好", "Hello, world!"),
            ("Hello {name} 12", "Bonjour {name} 12"),
            ("Good    morning!", "Bonjour !"),
        ):
            validate_translation(before, after)

    def test_cross_fragment_structure_creation_is_rejected(self):
        # Neither fragment individually contains an URL; their concatenation does.
        plan = prepare_document("abcdefghijk", ".txt", 5)
        with self.assertRaises(DocumentError):
            render_document(plan, {0: "https", 1: "://abc", 2: "z"})

    def test_missing_extra_and_noninteger_ids(self):
        plan = prepare_document("Hello\nWorld", ".txt")
        for replacements in (
            {},
            {0: "Hola"},
            {0: "Hola", 1: "Mundo", 2: "Extra"},
            {"0": "Hola", "1": "Mundo"},
            {False: "Hola", 1: "Mundo"},
            [],
        ):
            with self.subTest(replacements=replacements):
                with self.assertRaises(DocumentError):
                    render_document(plan, replacements)

    def test_immutable_plan_offsets_units_and_version(self):
        original = prepare_document("Hello", ".txt")
        for mutation in (
            lambda p: p.update(version=99),
            lambda p: p["units"][0].update(text="Fake"),
            lambda p: p["_containers"][0].update(start=1),
            lambda p: p.update(extra="field"),
        ):
            plan = copy.deepcopy(original)
            mutation(plan)
            with self.assertRaises(DocumentError):
                render_document(plan, {0: "Bonjour"})

    def test_errors_do_not_echo_data(self):
        error = DocumentError("Private Source /home/name")
        self.assertEqual(error.code, "document_error")
        self.assertEqual(str(error), "document_error")
        with self.assertRaises(DocumentError) as caught:
            prepare_document('{"SECRET_NAME": 1, "SECRET_NAME": 2}', ".json")
        self.assertEqual(str(caught.exception), "json_duplicate_key")

    def test_bad_argument_and_unsupported_formats(self):
        for ext in (".pdf", ".docx", ".html", ".ass", None):
            with self.assertRaises(DocumentError):
                prepare_document("Hello", ext)
        for max_chars in (0, -1, True, 1.5, MAX_UNIT_CHARS + 1):
            with self.assertRaises(DocumentError):
                prepare_document("Hello", ".txt", max_chars)
        for text in (None, "bad\x00text", "bad\ud800text"):
            with self.assertRaises(DocumentError):
                prepare_document(text, ".txt")
        self.assertEqual(prepare_document("Hi", "TXT")["extension"], ".txt")

    def test_oversized_translation(self):
        self.reject_output("Hello", ".txt", "x" * 257)
        self.reject_output("x" * 100, ".txt", "y" * 801)

    def test_document_and_complexity_limits_fail_closed(self):
        with self.assertRaises(DocumentError):
            prepare_document("x" * (documents.MAX_DOCUMENT_CHARS + 1), ".txt")
        with patch.object(documents, "MAX_UNITS", 2):
            with self.assertRaises(DocumentError):
                prepare_document("Hello\nWorld\nAgain", ".txt")
        with patch.object(documents, "MAX_TOKENS", 2):
            with self.assertRaises(DocumentError):
                prepare_document("1 2 3", ".txt")
        with patch.object(documents, "MAX_CONTAINERS", 2):
            with self.assertRaises(DocumentError):
                prepare_document('["Hello", "World"]', ".json")

    def test_total_output_bound_and_nonstring_replacements(self):
        plan = prepare_document("Hello\nWorld", ".txt")
        with patch.object(documents, "MAX_OUTPUT_CHARS", 100):
            with self.assertRaises(DocumentError) as caught:
                render_document(plan, {0: "A" * 60, 1: "B" * 60})
            self.assertEqual(caught.exception.code, "translation_size")
        for value in (None, 123, True, [], {}):
            with self.subTest(value=value):
                with self.assertRaises(DocumentError):
                    render_document(plan, {0: value, 1: "World"})

    def test_long_fragments_keep_sentence_and_space_boundaries(self):
        source = (
            "  First sentence. Second sentence!\n"
            + "word " * 400
            + "字" * 201
            + " \r\n"
        )
        plan = self.identity(source, ".txt", 20)
        self.assertEqual(plan["units"][0]["text"], "First sentence.")
        self.assertTrue(
            all(not any(c in u["text"] for c in "\r\n") for u in plan["units"])
        )
        self.assertTrue(all(u["text"] == u["text"].strip() for u in plan["units"]))
        self.assertGreater(len(plan["units"]), 100)

    def test_long_protected_token_not_split_or_sent(self):
        source = "Hello {" + "name" * 2000 + "} World"
        plan = self.identity(source, ".txt", 5)
        self.assertEqual([u["text"] for u in plan["units"]], ["Hello", "World"])

    def test_markdown_framing_code_links_and_metadata(self):
        source = '---\r\ntitle: Metadata\r\n---\r\n# Hello **world**  \r\n\r\n- [x] Read [guide](https://example.invalid/a_(b) "A title")!\r\n![image](asset.png) [label][ref] [ref] [ref][]\r\n\r\n[ref]: https://example.invalid "Title"\r\n\r\n```python\r\nprint("Never translate")\r\n```\r\n    indented code\r\n\r\nText `code` and <b>bold</b>.\r\n'
        plan = self.identity(source, ".md")
        values = [u["text"] for u in plan["units"]]
        for expected in (
            "Hello",
            "world",
            "Read",
            "guide",
            "image",
            "label",
            "Text",
            "and",
            "bold",
        ):
            self.assertIn(expected, values)
        for forbidden in (
            "Metadata",
            "ref",
            "A title",
            "Title",
            "Never translate",
            "indented code",
            "code",
            "asset.png",
        ):
            self.assertNotIn(forbidden, values)
        output = render_document(
            plan,
            {
                u["id"]: {
                    "Hello": "Bonjour",
                    "guide": "manuel",
                    "image": "illustration",
                }.get(u["text"], u["text"])
                for u in plan["units"]
            },
        )
        self.assertEqual(
            output,
            source.replace("# Hello", "# Bonjour")
            .replace("[guide]", "[manuel]")
            .replace("![image]", "![illustration]"),
        )

    def test_markdown_tables_quotes_setext_and_tilde_fence(self):
        source = "Title\n=====\n\n> Quoted\n\n| Name | Value |\n| --- | --- |\n| Hello | World |\n\n~~~text\nUntouched\n~~~\n"
        plan = self.identity(source, ".markdown")
        self.assertNotIn("Untouched", [u["text"] for u in plan["units"]])
        output = render_document(plan, {u["id"]: "Texte" for u in plan["units"]})
        self.assertIn("| Texte | Texte |\n| --- | --- |", output)
        self.assertIn("~~~text\nUntouched\n~~~", output)

    def test_markdown_cannot_add_structure(self):
        for replacement in (
            "# Heading",
            "- List item",
            "+ List item",
            "[link](target)",
            "Text | cell",
            "Text\n```",
            "Text *new*",
            "Text  ",
        ):
            with self.subTest(replacement=replacement):
                self.reject_output("Hello", ".md", replacement)

    def test_markdown_fail_closed_unsupported_or_unclosed(self):
        for source in (
            "```\ncode\n",
            "---\nkey: value",
            "[nested [label]](url)",
            "[label](broken",
            "[label](multi\nline)",
            "[unclosed",
            "<script>missing close",
            "<!-- missing close",
            "`unclosed",
            "Hello {unclosed",
            "- - Nested",
            "<!DOCTYPE html>",
        ):
            with self.subTest(source=source):
                with self.assertRaises(DocumentError):
                    prepare_document(source, ".md")

    def test_markdown_reference_continuations_stay_immutable(self):
        source = '[ref]:\n  relative/path.md\n  "Link title"\n\nHello [ref]\n'
        plan = self.identity(source, ".md")
        self.assertEqual([u["text"] for u in plan["units"]], ["Hello"])

    def test_autolinks_and_unicode_xml_tag_names(self):
        source = "Visit <https://example.invalid/path> <hello@example.invalid> <項目>東京</項目>"
        plan = self.identity(source, ".md")
        self.assertEqual([u["text"] for u in plan["units"]], ["Visit", "東京"])

    def test_markdown_image_marker_cannot_change_via_adjacent_unit(self):
        source = "Hello[label](image.png)"
        plan = prepare_document(source, ".md")
        with self.assertRaises(DocumentError):
            render_document(plan, {0: "Bonjour!", 1: "texte"})
        source = "Hello![label](image.png)"
        plan = self.identity(source, ".md")
        self.assertEqual([u["text"] for u in plan["units"]], ["Hello", "label"])
        self.reject_output("- Hello", ".md", "- Bonjour")

    def test_long_malformed_markup_and_printf_input_are_bounded(self):
        with self.assertRaises(DocumentError):
            prepare_document("<p " + " " * 50_000, ".txt")
        self.identity("%" + "0" * 50_000, ".txt")

    def test_currency_symbols_and_numeric_values_stay_exact(self):
        source = "Price $12.50 or €10!"
        plan = self.identity(source, ".txt")
        self.assertEqual([u["text"] for u in plan["units"]], ["Price", "or"])
        with self.assertRaises(DocumentError):
            validate_translation("Price $12.50", "Prix €12.50")

    def test_markdown_multiline_inline_code_preserved(self):
        source = "Before `code\nmore code` after\n"
        plan = self.identity(source, ".md")
        self.assertEqual([u["text"] for u in plan["units"]], ["Before", "after"])

    def test_srt_numeric_dialogue_arrow_and_tags(self):
        source = "1\r\n00:00:01,000 --> 00:00:05,000\r\n<b>Hello 42 --> world</b>\r\n123\r\n\r\n2\r\n00:00:06,000 --> 00:00:07,000\r\nBye\r\n"
        plan = self.identity(source, ".srt")
        self.assertEqual([u["text"] for u in plan["units"]], ["Hello", "world", "Bye"])
        output = render_document(
            plan,
            {
                u["id"]: {"Hello": "Bonjour", "world": "monde", "Bye": "Salut"}[
                    u["text"]
                ]
                for u in plan["units"]
            },
        )
        self.assertEqual(
            output,
            source.replace("Hello", "Bonjour")
            .replace("world", "monde")
            .replace("Bye", "Salut"),
        )

    def test_vtt_header_note_settings_region_and_identifiers(self):
        source = "WEBVTT Title\nKind: captions\nLanguage: en\n\nSTYLE\n::cue { color: red; }\n\nREGION\nid:main\n\nNOTE Do not translate\nImportant 42\n\ncue-identifier\n00:01.000 --> 00:03.000 align:start position:20% line:0 region:main\n<v Speaker>Hello 12 --> world</v>\n\nNOTE End\n"
        plan = self.identity(source, ".vtt")
        self.assertEqual([u["text"] for u in plan["units"]], ["Hello", "world"])
        output = render_document(plan, {u["id"]: "Bonjour" for u in plan["units"]})
        self.assertIn("NOTE Do not translate\nImportant 42", output)
        self.assertIn("align:start position:20% line:0 region:main", output)
        self.assertIn("<v Speaker>Bonjour 12 --> Bonjour</v>", output)

    def test_bad_subtitle_grammar(self):
        samples = [
            (".srt", "1\n00:00:05,000 --> 00:00:01,000\nHello\n"),
            (".srt", "1\n00:00:01,000 --> 00:00:05,000\n"),
            (".srt", "index\n00:00:01,000 --> 00:00:05,000\nHello\n"),
            (
                ".srt",
                "1\n00:00:01,000 --> 00:00:05,000\nHello\n2\n00:00:06,000 --> 00:00:07,000\nBye\n",
            ),
            (".vtt", "WEBVTT\n00:01.000 --> 00:02.000\nHello\n"),
            (".vtt", "WEBVTT\n\n00:01.000 --> 00:02.000 size:101%\nHello\n"),
            (
                ".vtt",
                "WEBVTT\n\n00:01.000 --> 00:02.000 align:start align:end\nHello\n",
            ),
            (".vtt", "WEBVTT\n\n00:01.000 --> 00:02.000 surprise:x\nHello\n"),
            (".vtt", "WEBVTT\n\n00:01.000 --> 00:02.000\nHello\n\nSTYLE\nBad order\n"),
        ]
        for extension, source in samples:
            with self.subTest(source=source):
                with self.assertRaises(DocumentError):
                    prepare_document(source, extension)

    def test_subtitle_replacement_cannot_add_cues(self):
        for ext, source in (
            (".srt", "1\n00:00:01,000 --> 00:00:02,000\nHello\n"),
            (".vtt", "WEBVTT\n\n00:01.000 --> 00:02.000\nHello\n"),
        ):
            self.reject_output(
                source, ext, "Bonjour\n\n2\n00:03.000 --> 00:04.000\nInjected"
            )

    def test_csv_header_policy_quoted_fields_and_embedded_newlines(self):
        source = 'Name,Note,Count\r\n"Alice","Hello, world\r\nSecond ""line""",42\r\n'
        plan = self.identity(source, ".csv")
        self.assertTrue(all(u["context"]["header"] for u in plan["units"][:3]))
        self.assertEqual(
            [u["text"] for u in plan["units"]],
            ["Name", "Note", "Count", "Alice", "Hello, world", 'Second "line"'],
        )
        output = render_document(
            plan,
            {
                u["id"]: {
                    "Name": "Nom",
                    "Hello, world": "Bonjour, monde",
                    'Second "line"': 'Autre "ligne"',
                }.get(u["text"], u["text"])
                for u in plan["units"]
            },
        )
        self.assertEqual(
            output,
            'Nom,Note,Count\r\n"Alice","Bonjour, monde\r\nAutre ""ligne""",42\r\n',
        )

    def test_csv_delimiters_and_empty_cells(self):
        for delimiter in (",", ";", "\t", "|"):
            source = f"Name{delimiter}Note{delimiter}Count\nAlice{delimiter}{delimiter}42\nBob{delimiter}Hello{delimiter}\n"
            with self.subTest(delimiter=delimiter):
                plan = self.identity(source, ".csv")
                self.assertEqual(plan["_metadata"]["delimiter"], delimiter)
                self.assertEqual(plan["_metadata"]["rows"], 3)
                self.assertEqual(plan["_metadata"]["columns"], 3)
        for source in ("", "Hello\nWorld\n", '"Hello"\n"World"\n', "a,b,", "\n", ",\n"):
            self.identity(source, ".csv")

    def test_csv_new_delimiter_and_quotes_are_safely_quoted(self):
        self.assertEqual(
            self.translated(
                "Name,Note\nAlice,Hello\n", ".csv", {"Hello": 'Bonjour, "monde"'}
            ),
            'Name,Note\nAlice,"Bonjour, ""monde"""\n',
        )

    def test_csv_dangerous_new_formula_prefixes(self):
        for replacement in (
            "=SUM(A)",
            "+Danger",
            "-Danger",
            "@Danger",
            "\tDanger",
            " =Danger",
            "\ufeff=Danger",
        ):
            with self.subTest(replacement=replacement):
                self.reject_output("Hello,World\n", ".csv", replacement)

    def test_csv_new_formulas_after_existing_unicode_whitespace(self):
        for whitespace in (" ", "\u00a0", "\u2003"):
            self.reject_output(whitespace + "Hello,World\n", ".csv", "=Danger")

    def test_csv_existing_formulas_are_immutable(self):
        source = 'Name,Formula\nAlice,"=SUM(A1:A2)"\nBob,+Existing\nCarol,-Existing\nDavid,@Existing\nEve,"\tExisting"\n'
        plan = self.identity(source, ".csv")
        self.assertNotIn("Existing", [u["text"] for u in plan["units"]])
        self.assertFalse(any("SUM" in u["text"] for u in plan["units"]))

    def test_csv_malformed_and_ambiguous_records(self):
        for source in (
            "a,b\nc\n",
            "a;b\nc\n",
            "a\tb\nc\n",
            "a|b\nc\n",
            'a,"unclosed\n',
            'a,"quoted"junk\n',
            'a,b"quote\n',
            "a,b;c\nx,y;z\n",
            "a,b\n\n",
        ):
            with self.subTest(source=source):
                with self.assertRaises(DocumentError):
                    prepare_document(source, ".csv")

    def test_csv_embedded_newlines_cannot_be_added_or_removed(self):
        self.reject_output('"Hello\nWorld",note\n', ".csv", "Bonjour\nInjected")

    def test_json_values_not_keys_and_exact_unmodified_spelling(self):
        source = '{\r\n  "Hello" : "Hello", "number" : -0.2500e+02, "flag":true, "empty": null,\r\n  "nested" : ["World", 123, false, {"key":"\\u0041lice"}], "raw":"a\\/b"\r\n}\r\n'
        plan = self.identity(source, ".json")
        output = render_document(
            plan,
            {
                u["id"]: {"Hello": "Bonjour", "World": "Monde"}.get(
                    u["text"], u["text"]
                )
                for u in plan["units"]
            },
        )
        self.assertEqual(
            output,
            source.replace('"Hello", "number"', '"Bonjour", "number"').replace(
                '["World",', '["Monde",'
            ),
        )
        self.assertIn('"key":"\\u0041lice"', output)
        self.assertIn('"raw":"a\\/b"', output)
        self.assertEqual(plan["units"][0]["context"]["path"], ["Hello"])

    def test_json_changed_string_encoding_cannot_inject_keys(self):
        source = '{"key":"Hello", "safe":true}'
        output = self.translated(
            source, ".json", {"Hello": 'Bonjour ", evil: false, "'}
        )
        value = json.loads(output)
        self.assertEqual(list(value), ["key", "safe"])
        self.assertTrue(value["safe"])
        self.assertEqual(value["key"], 'Bonjour ", evil: false, "')

    def test_json_escaped_newlines_and_unicode_surrogate_pair(self):
        source = '{"value":"Hello\\r\\nWorld", "emoji":"\\ud83d\\ude3a", "name":"\\u4f60\\u597d"}'
        output = self.translated(
            source, ".json", {"Hello": "Bonjour", "World": "Monde", "你好": "Salut"}
        )
        self.assertEqual(json.loads(output)["value"], "Bonjour\r\nMonde")
        self.assertIn('"emoji":"\\ud83d\\ude3a"', output)
        self.assertEqual(json.loads(output)["name"], "Salut")

    def test_json_root_scalar_array_and_numeric_only_values(self):
        for source in (
            '"Hello"',
            '["Hello", "123", 123, null, true, false]',
            "-1.0e+02",
            "{}",
            "[]",
            "true",
        ):
            self.identity(source, ".json")
        self.assertEqual(prepare_document('{"x":"123"}', ".json")["units"], [])

    def test_json_duplicate_keys_include_escaped_equivalents(self):
        for source in (
            '{"a":1,"a":2}',
            '{"a":1,"\\u0061":2}',
            '{"outer":{"x":true,"x":false}}',
        ):
            with self.subTest(source=source):
                with self.assertRaises(DocumentError) as caught:
                    prepare_document(source, ".json")
                self.assertEqual(caught.exception.code, "json_duplicate_key")

    def test_json_malformed_nonfinite_deep_and_invalid_strings(self):
        for source in (
            "",
            "{",
            "[1,]",
            '{"a":1,}',
            '{"a" 1}',
            "{a:1}",
            "01",
            "-01",
            "NaN",
            "Infinity",
            "-Infinity",
            "1e999",
            '{"a": NaN}',
            '"bad\\q"',
            '"bad\nline"',
            '"\\ud800"',
            '"\\u0000"',
            "null true",
            "[" * (MAX_JSON_DEPTH + 2) + "0" + "]" * (MAX_JSON_DEPTH + 2),
        ):
            with self.subTest(source=source[:80]):
                with self.assertRaises(DocumentError):
                    prepare_document(source, ".json")

    def test_random_identity_json_and_csv(self):
        randomizer = random.Random(41)
        alphabet = "abc é你好مرحبا123,.;!? "
        for _ in range(30):
            values = [
                "".join(randomizer.choice(alphabet) for _ in range(70))
                for _ in range(4)
            ]
            self.identity(
                json.dumps(
                    {"items": values},
                    ensure_ascii=bool(randomizer.randrange(2)),
                    indent=2,
                ),
                ".json",
                13,
            )
            source = '"' + '","'.join(v.replace('"', '""') for v in values) + '"\r\n'
            self.identity(source, ".csv", 13)


if __name__ == "__main__":
    unittest.main()
