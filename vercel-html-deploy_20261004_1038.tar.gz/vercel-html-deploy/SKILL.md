---
name: vercel-html-deploy
description: 批量将指定目录中的静态 HTML（单文件或整个目录）部署到 Vercel。支持两种模式——static（整目录/单文件原样发布）与 collection（扫描多个文档、生成稳定 slug + 可搜索/排序/分页的 /toc/ 索引页、并把最新一篇发布到站点根路径）。配置驱动、状态持久化、内容指纹跳过未变更站点、可断点重试、有界并行与 dry-run 预检，凭证读取 ~/.config/omnirush/.env 的 VERCEL_TOKEN / VERCEL_SCOPE / VERCEL_PROJECT / PROD_URL。
compatibility: Python 3.10+；需要当前环境已有 PyYAML；部署需要 Vercel CLI（`npm i -g vercel`，v54+）或 `npx vercel`。不会自动安装依赖或访问除 Vercel CLI 上传端点之外的网络。
allowed-tools: read write edit bash
permissions:
  - file_write
---

# 批量部署 HTML 到 Vercel

安装目录：`~/.config/omnirush/skills/vercel-html-deploy/`。

基于用户提供的 `/tmp/deploy_rainmain_2vercel.py` 改造，保留原脚本两个核心思路——「把最新一篇文档发布到根域名」和「把大量文档归档到稳定 `/<slug>/` 子路径、并生成可搜索的 `/toc/` 索引页」，同时把它扩展为通用的、配置驱动的批量部署工具；原脚本只读未改，SHA-256 见 `references/source-hashes.json`。

## 依赖与凭证

- 运行环境：Python 3.10+、`PyYAML`、`vercel` CLI（v54+，或 `npx vercel`）。
- 凭证默认从 `~/.config/omnirush/.env` 读取：

  ```ini
  ## vercel deployment
  PROD_URL = "city.allez.cc.cd"
  VERCEL_PROJECT = "zhongnanshan"
  VERCEL_SCOPE = "seigneurtsuis-projects"
  VERCEL_TOKEN = "xxxx"
  ```

  也接受 `VERCEL_API_TOKEN` 作为 token 别名。真实环境变量优先于文件；`--env-file` 可追加额外文件。Token 只写入 Vercel 子进程命令行并在日志中掩码显示，从不落入报告/状态文件。配置文件里的 `scope` 优先于环境变量。

## 快速开始

```bash
VHD="$HOME/.config/omnirush/skills/vercel-html-deploy/scripts/vercel_html_deploy.py"

# 1) 从一个「每个子目录一个站点」的父目录自动生成配置
python3 "$VHD" discover --root ~/Downloads/sites --output vercel.yaml

# 2) 预检（不联网、不建项目、不写状态）
python3 "$VHD" deploy --config vercel.yaml --dry-run

# 3) 批量部署
python3 "$VHD" deploy --config vercel.yaml

# 4) 只部署某个项目 / 重跑失败项
python3 "$VHD" deploy --config vercel.yaml --only zhongnanshan
python3 "$VHD" deploy --config vercel.yaml --retry-failed

# 单目录/单文件临时部署，不用配置文件
python3 "$VHD" deploy --dir ./site --project-name my-site --prod

# 列出 scope 下的 Vercel 项目
python3 "$VHD" list
```

## 三种输入方式（选其一）

| 方式 | 参数 | 说明 |
|---|---|---|
| 配置文件 | `--config vercel.yaml` | 一次部署多个命名项目（推荐、可断点续传、支持 collection 模式） |
| 父目录发现 | `--discover-root DIR` | 把 DIR 下含 `index.html` 的一级子目录各部署为一个项目（项目名=目录名小写化） |
| 单目标 | `--dir PATH --project-name NAME` | 部署一个目录或单个 `.html` 文件 |

配置文件中的 `source_dir` 相对配置文件所在目录解析；`--discover-root` / `--dir` 相对当前工作目录。

## 两种部署模式

- **`static`**：整目录（HTML + CSS/JS/图片）或单个 `.html` 文件原样上传；单文件会被复制为 `index.html`。适合一个独立的站点目录。
- **`collection`**：扫描一个目录中的多个文档，为每个文档计算稳定 slug 并发布到 `/<slug>/`，生成可搜索/排序/分页/导出 CSV 的 `/toc/` 索引页，并按 `root_mode`（默认 `latest`）把最新一篇同时发布为站点根 `index.html`。这是原 rainman-travel 脚本的核心行为。

## 配置格式

```yaml
defaults:                          # 可选，合并进每个 deployment；部署项自身的键优先
  scope: "seigneurtsuis-projects"
  prod: true
  create_if_missing: true
  archive: "tgz"                   # 上传压缩格式；"none"/false 关闭

deployments:                       # 也可写作 projects:
  my-site:
    source_dir: "./site"           # 目录，或单个 .html 文件
    mode: static                   # static（默认）| collection
  zhongnanshan:
    source_dir: "../rainman/城市"
    mode: collection
    prod_url: "city.allez.cc.cd"   # TOC 页用于绝对链接/CSV
    title: "🗂️ 城市内容目录"
    slug_prefix: "city"
    root_mode: latest              # latest | none
```

完整示例见 `examples/vercel.example.yaml`。collection 专属字段：`prod_url`、`title`、`subtitle`、`item_label`、`slug_prefix`、`slug_algo`（md5/sha1/sha256）、`slug_len`、`min_bytes`、`exclude_email`、`root_mode`。

## 行为

- **内容指纹跳过**：记录每个项目最近一次成功部署的输入指纹（static=源内容 SHA-256；collection=文件路径+大小+mtime 与 collection 配置）。指纹未变时标记 `skipped(unchanged)`，不再上传。`--force` 忽略此跳过。
- **断点续传**：`--retry-failed` 只处理状态不是成功的项目（成功项标记 `skipped(retry_failed_skip)`）。
- **并行**：`--jobs` 控制并发项目数（默认 `auto` = min(4, 项目数)，上限 6）。
- **重试**：Vercel 调用按线性回退重试（`--retries`，默认 2），单个项目失败不影响整批。
- **项目确保**：部署前用 `vercel project ls --filter NAME -F json` 判断项目是否存在，缺失且 `create_if_missing` 时 `vercel project add NAME` 创建。
- **生产/预览**：`prod` 默认取自配置项（缺省 true）。命令行 `--prod` / `--preview` 会覆盖所有项目的 `prod`，便于对同一份配置先预览再生产。
- **dry-run**：只做文件系统校验与计划，不联网、不建项目、不写状态或报告。
- **原子状态**：状态文件（默认与配置文件同目录的 `.vercel_html_deploy_state.json`，可用 `--state` 指定）原子写入；`skipped` 不会把已有的成功记录降级。
- **报告**：`--json` 输出机器可读报告；`--report FILE` 另存 JSON。退出码：0=全部成功/计划完成，2=有失败，1=无法启动（配置/凭证/参数错误）。

## 安全与边界

- 只从用户明确指定的目录/配置读取内容，不扫描 Downloads 或家目录。
- 不打印、不落盘 Vercel Token；命令行中的 `--token` 值在日志里显示为 `***`。
- 不访问除 Vercel CLI 上传端点与 `vercel project ls/add` 之外的网络。
- 不自动安装依赖、不执行 `vercel login`、不删除项目或域名。
- 部署/创建项目是外部动作：`--dry-run` 可先预检；生产（`--prod`）谨慎操作，需要预览时可 `--preview`。

## 输出结构

```text
vercel.yaml
.vercel_html_deploy_state.json      # 状态（可 --state 改路径）
logs/…                              # 仅在使用 --log-file 时
```

参考文档：

- `references/formats.md`：CLI、配置、状态与报告字段、退出码。
- `references/implementation.md`：架构、指纹、跳过策略、并行与安全边界。
- `references/verification.md`：测试与验证结果。
