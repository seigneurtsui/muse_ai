---
name: himalaya
description: CLI to manage emails via IMAP/SMTP. Use himalaya to list, read, write, reply, forward, search, and organize emails from the terminal. Supports multiple accounts and message composition with MML (MIME Meta Language).
version: 1.0.0
author: community
license: MIT
metadata:
  hermes:
    tags: [Email, IMAP, SMTP, CLI, Communication]
    homepage: https://github.com/pimalaya/himalaya
prerequisites:
  commands: [himalaya]
---

# Himalaya Email CLI

Himalaya is a CLI email client that lets you manage emails from the terminal using IMAP, SMTP, Notmuch, or Sendmail backends.

## References

- `references/configuration.md` (config file setup + IMAP/SMTP authentication)
- `references/message-composition.md` (MML syntax for composing emails)

## Prerequisites

1. Himalaya CLI installed (`himalaya --version` to verify)
2. A configuration file at `~/.config/himalaya/config.toml`
3. IMAP/SMTP credentials configured (password stored securely)

### Installation

```bash
# Pre-built binary (Linux/macOS — recommended)
curl -sSL https://raw.githubusercontent.com/pimalaya/himalaya/master/install.sh | PREFIX=~/.local sh

# macOS via Homebrew
brew install himalaya

# Or via cargo (any platform with Rust)
cargo install himalaya --locked
```

## Configuration Setup

Run the interactive wizard to set up an account:

```bash
himalaya account configure
```

Or create `~/.config/himalaya/config.toml` manually:

```toml
[accounts.personal]
email = "you@example.com"
display-name = "Your Name"
default = true

backend.type = "imap"
backend.host = "imap.example.com"
backend.port = 993
backend.encryption.type = "tls"
backend.login = "you@example.com"
backend.auth.type = "password"
backend.auth.cmd = "pass show email/imap"  # or use keyring

message.send.backend.type = "smtp"
message.send.backend.host = "smtp.example.com"
message.send.backend.port = 587
message.send.backend.encryption.type = "start-tls"
message.send.backend.login = "you@example.com"
message.send.backend.auth.type = "password"
message.send.backend.auth.cmd = "pass show email/smtp"
```

## Hermes Integration Notes

- **发邮件 (默认)** → 使用 `scripts/send-html.js`，自动发送 HTML 卡片式邮件 + 纯文本双版本
- **Reading, listing, searching, moving, deleting** all work directly through the terminal tool
- **Composing/replying/forwarding** — piped input (`cat << EOF | himalaya template send`) is recommended for reliability. Interactive `$EDITOR` mode works with `pty=true` + background + process tool, but requires knowing the editor and its commands
- Use `--output json` for structured output that's easier to parse programmatically
- The `himalaya account configure` wizard requires interactive input — use PTY mode: `terminal(command="himalaya account configure", pty=true)`
- **⚠️ MML 必须用 `template send`**，不能用 `message send` — 否则 MML 标签会原样出现在邮件正文

## Quick Reference

See `QUICK_REFERENCE.md` for a condensed command reference, including the correct `himalaya message send` syntax with heredoc format.

## Common Operations

### List Folders

```bash
himalaya folder list
```

### List Emails

List emails in INBOX (default):

```bash
himalaya envelope list
```

List emails in a specific folder:

```bash
himalaya envelope list --folder "Sent"
```

List with pagination:

```bash
himalaya envelope list --page 1 --page-size 20
```

### Search Emails

```bash
himalaya envelope list from john@example.com subject meeting
```

### Read an Email

Read email by ID (shows plain text):

```bash
himalaya message read 42
```

Export raw MIME:

```bash
himalaya message export 42 --full
```

### Reply to an Email

To reply non-interactively from Hermes, read the original message, compose a reply, and pipe it:

```bash
# Get the reply template, edit it, and send
himalaya template reply 42 | sed 's/^$/\nYour reply text here\n/' | himalaya template send
```

Or build the reply manually:

```bash
cat << 'EOF' | himalaya template send
From: you@example.com
To: sender@example.com
Subject: Re: Original Subject
In-Reply-To: <original-message-id>

Your reply here.
EOF
```

Reply-all (interactive — needs $EDITOR, use template approach above instead):

```bash
himalaya message reply 42 --all
```

### Forward an Email

```bash
# Get forward template and pipe with modifications
himalaya template forward 42 | sed 's/^To:.*/To: newrecipient@example.com/' | himalaya template send
```

### Write a New Email

> **默认方式: HTML 富文本邮件** — 使用 `scripts/send-html.js` 便捷脚本，自动构建美观的 HTML 邮件（渐变色头部 + 圆角卡片设计），同时附带纯文本版本。

**⭐ 方法 1: 使用 send-html.js 脚本 (默认推荐)**
```bash
# 基础用法
node scripts/send-html.js --to "recipient@example.com" --subject "邮件主题" --body "邮件内容"

# 从文件读取内容
node scripts/send-html.js --to "recipient@example.com" --subject "报告" --body-file /path/to/content.txt

# 从管道读取
echo "邮件内容" | node scripts/send-html.js --to "recipient@example.com" --subject "通知"
```

**颜色主题** (通过 `HIMALAYA_STYLE` 环境变量):
```bash
HIMALAYA_STYLE=red    node scripts/send-html.js ...   # 红色渐变 (默认)
HIMALAYA_STYLE=blue   node scripts/send-html.js ...   # 蓝色渐变
HIMALAYA_STYLE=green  node scripts/send-html.js ...   # 绿色渐变
HIMALAYA_STYLE=purple node scripts/send-html.js ...   # 紫色渐变
```

**默认配置**:
- 发件人: `Seigneur Tsui <2826824650@qq.com>` (可通过 `HIMALAYA_FROM` 覆盖)
- 收件人: `gc40800@gmail.com` (可通过 `--to` 或 `HIMALAYA_TO` 覆盖)
- 格式: HTML 富文本 + 纯文本双版本 (MML multipart/alternative)

**从 Node.js 程序调用**:
```javascript
const { execFileSync } = require('child_process');
execFileSync('node', [
  '/Users/seigneur/.hermes/skills/email/himalaya/scripts/send-html.js',
  '--to', 'gc40800@gmail.com',
  '--subject', '自动通知',
  '--body', '邮件正文内容'
], { timeout: 15000 });
```

---

**方法 2: 使用 heredoc 纯文本 (简单场景)**
```bash
himalaya message send <<EOF
From: Seigneur Tsui <2826824650@qq.com>
To: gc40800@gmail.com
Subject: 邮件主题

邮件正文内容
EOF
```

**方法 3: 使用 MML 手写 HTML (完全自定义)**
```bash
himalaya message send <<'EOF'
From: Seigneur Tsui <2826824650@qq.com>
To: gc40800@gmail.com
Subject: 自定义 HTML 邮件

<#multipart type=alternative>
<#part type=text/plain>
纯文本版本
<#part type=text/html>
<!DOCTYPE html>
<html><body><h1>自定义 HTML</h1></body></html>
<#/multipart>
EOF
```

**方法 4: 使用 headers 标志 (快速)**
```bash
himalaya message write -H "To:recipient@example.com" -H "Subject:Test" "Message body here"
```

**MML 关键语法**:
- `<#multipart type=alternative>` — 包裹多个版本，客户端自动选择
- `<#part type=text/plain>` — 纯文本部分（兜底兼容）
- `<#part type=text/html>` — HTML 富文本部分
- `<#/multipart>` — 结束标记
- 也可用 `<#part type=text/html filename=/path/to/template.html>` 从文件加载 HTML

**⚠️ MML 发送必须用 `template send`，不能用 `message send`**:
```bash
# ✅ 正确 — MML 通过 template send 管道传入，才会被编译为 MIME
echo '<#multipart ...>' | himalaya template send
# 或
himalaya template send < mml_content.txt
# 或 Node.js
spawnSync('himalaya', ['template', 'send'], { input: mml })

# ❌ 错误 — message send 把 MML 当作纯文本原样发送
himalaya message send <<< '<#multipart ...>'
```

**原理**: `message send` 将输入视为已完成的消息体直接发送；`template send` 才会将 MML 标签解析、编译为正确的 MIME multipart 结构。

**重要说明:**
- 邮件头和正文之间必须有一个空行
- From 头可以包含显示名称：`From: 显示名称 <email@example.com>`
- 使用 `himalaya message send` 而不是 `himalaya template send`
- 如果遇到 "index out of bounds" 错误，检查邮件格式是否正确
- `references/message-composition.md` 有更完整的 MML 语法参考（附件、内联图片等）

### Move/Copy Emails

Move to folder:

```bash
himalaya message move 42 "Archive"
```

Copy to folder:

```bash
himalaya message copy 42 "Important"
```

### Delete an Email

```bash
himalaya message delete 42
```

### Manage Flags

Add flag:

```bash
himalaya flag add 42 --flag seen
```

Remove flag:

```bash
himalaya flag remove 42 --flag seen
```

## Multiple Accounts

List accounts:

```bash
himalaya account list
```

Use a specific account:

```bash
himalaya --account work envelope list
```

## Attachments

Save attachments from a message:

```bash
himalaya attachment download 42
```

Save to specific directory:

```bash
himalaya attachment download 42 --dir ~/Downloads
```

## Output Formats

Most commands support `--output` for structured output:

```bash
himalaya envelope list --output json
himalaya envelope list --output plain
```

## Debugging

Enable debug logging:

```bash
RUST_LOG=debug himalaya envelope list
```

Full trace with backtrace:

```bash
RUST_LOG=trace RUST_BACKTRACE=1 himalaya envelope list
```

## Tips

- Use `himalaya --help` or `himalaya <command> --help` for detailed usage.
- Message IDs are relative to the current folder; re-list after folder changes.
- For composing rich emails with attachments, use MML syntax (see `references/message-composition.md`).
- Store passwords securely using `pass`, system keyring, or a command that outputs the password.
