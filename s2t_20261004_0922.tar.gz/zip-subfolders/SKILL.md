---
name: zip-subfolders
description: 批量压缩用户明确指定目录中的子文件夹，保留子目录结构，支持 ZIP、TAR.GZ 和可选 7z，具备预览、排除、并行压缩、原子写入、归档校验、断点状态和 JSON/文本报告；不跟随链接、不默认覆盖已有压缩包。
compatibility: Python 3.10+；ZIP/TAR.GZ 只需标准库。7z 为可选的本机外部命令，不自动安装；不提供 cpgz 或密码压缩。
allowed-tools: read write edit bash
permissions:
  - file_write
---

# 批量子文件夹压缩

安装目录：`~/.config/omnirush/skills/zip-subfolders/`。

本技能基于用户提供的 `/tmp/zip_subfolders_cli.py` 的成熟目录扫描、深度选择、排除、并行处理、checkpoint、报告和 CLI 思路重写为无 GUI、跨平台的安全 CLI。原脚本未执行、未修改；原始 SHA-256 记录在 `references/source-hashes.json`。

## 用法

必须明确指定源目录和独立目标目录：

```bash
ZIPPER="$HOME/.config/omnirush/skills/zip-subfolders/scripts/zip_subfolders.py"

# 预览：不创建目标目录、锁、压缩包或报告
python3 "$ZIPPER" \
  --source "/path/to/source" \
  --target "/path/to/archives" \
  --format zip \
  --dry-run

# 压缩深度内的所有子文件夹
python3 "$ZIPPER" \
  --source "/path/to/source" \
  --target "/path/to/archives" \
  --format zip \
  --depth 2 \
  --workers 3

# 只处理明确选择的目录
python3 "$ZIPPER" \
  --source "/path/to/source" \
  --target "/path/to/archives" \
  --folder project-a \
  --folder "/path/to/source/project-b" \
  --format tar.gz
```

支持：

```text
zip       Python 标准库 ZIP_DEFLATED，跨平台默认格式
 tar.gz   Python 标准库 tarfile + gzip
7z        可选本机 7z/7zz 命令；不自动安装，未找到时明确失败
```

源代码中的 `cpgz`、Gradio 界面和 `py7zr` 注册没有复制：cpgz/ditto 是平台特定行为，py7zr 不是默认依赖；不把未验证的格式冒充成跨平台支持。7z 仅使用无密码、固定参数列表的外部命令。**本版本不接受密码压缩**，不会把密码放进 argv、日志、报告或临时文件；需要加密时使用经过单独审核的加密工具和明确授权。

常用选项：

- `--depth 1..5`：默认 1；会发现每层目录，不跟随隐藏目录或链接。
- `--exclude NAME`：按目录名排除，可重复；默认排除 `.git`、`node_modules`、`__pycache__`、`.DS_Store`。
- `--workers 1..8`：独立子文件夹并行压缩，默认 2。并行只影响不同归档，不共享写入一个压缩包。
- `--compression-level 0..9`：ZIP/TAR.GZ 压缩级别，默认 6。
- `--overwrite`：明确允许替换已有同名压缩包；默认只校验并跳过已有归档。
- `--json`：单个 JSON 输出，适合自动化读取。

## 输出命名与状态

输出保留相对于源目录的父层次，避免原脚本只使用文件夹 basename 导致不同位置的同名目录相互覆盖：

```text
source/
  one/same/
  two/same/

archives/
  one/same_YYYYMMDD.zip
  two/same_YYYYMMDD.zip
```

目标目录包含：

```text
.zip-subfolders-state.json   # 哈希绑定的目录指纹和完成状态
report.json                  # 机器可读统计
report.txt                   # 简明文本统计
<relative-parent>/<name>_YYYYMMDD.<format>
```

每个归档写入目标目录同级临时文件，成功后原子替换，并进行 ZIP CRC 或 TAR.GZ 读取校验。源目录在归档前后各做一次有界指纹检查；归档期间源文件变化会删除临时文件并标记失败。

状态：

- `dry_run`：只有预览，不发生写入。
- `created`：新建并校验成功。
- `skipped_existing`：已有归档通过校验且源目录指纹未变化，未重写。
- `failed`：单个子文件夹失败；其他独立任务仍可完成。
- 总状态 `complete` 或 `partial_failure`。

首次看到未知的同名归档时，默认只校验并跳过；带有本技能状态且源指纹已变化时，默认报 `archive_exists_source_changed_use_overwrite`，不隐式替换。确认需要更新后再使用 `--overwrite`。

如果上次运行中断，状态文件保留已完成条目。下一次相同源/目标/格式会重用可验证的已有归档；残留 `.zip-subfolders.lock` 不自动删除。确认没有其他压缩进程后，检查目标目录再人工处理残留锁。

## 安全边界

- 不扫描 Downloads、家目录或历史目录；只有用户明确的 `--source` 被读取。
- 目标目录必须和源目录分离：不能是源目录、源目录子目录或源目录祖先，避免把正在生成的归档再次打包或写入源文件。
- 不跟随符号链接、Windows reparse point、FIFO、设备文件或其他特殊文件；这些项目在结果中作为跳过项记录，不执行、不读取目标内容。
- 只写目标目录，输入以只读方式访问；已有普通归档不默认覆盖，链接/硬链接输出目标拒绝操作。
- 归档成员使用安全相对路径，不产生绝对路径或 `..` 路径；每个归档完成后校验成员名和数据完整性。
- 不调用 shell，不执行文档中的命令；7z 使用 `shell=False`、固定参数数组和超时。7z 输出不会写入报告，避免回显文档内容。
- 报告和状态只记录路径、哈希、大小、计数、耗时和安全原因，不嵌入文件正文。

## 资源边界

- 最多 10,000 个待压缩子文件夹。
- 每个子文件夹最多 100,000 个常规文件、8 GiB 逻辑输入大小。
- 目录扫描深度最多 5，目录状态/报告单文件最多 16 MiB。
- `--workers` 最大 8；7z 单任务默认超时 300 秒。
- ZIP 使用 ZIP64；压缩包数据仍受底层磁盘空间和标准库限制约束。

## 限制与恢复

压缩过程保证归档结构、路径和数据读取完整性，不保证输入在不合作进程同时修改时的一致快照；前后指纹检查只能发现大部分修改，检查之后仍存在普通文件系统竞态。权限、时间戳和平台特定扩展不承诺完全跨平台还原。符号链接不保存为链接条目，而是明确跳过。

本技能不是备份快照、加密工具、云同步工具或文件删除工具。它不删除源文件、不上传归档、不发送通知、不修改 `.env`、不安装 `7z`、不启动后台任务。

完整实现、状态字段和验证记录见：

- `references/implementation.md`
- `references/verification.md`
