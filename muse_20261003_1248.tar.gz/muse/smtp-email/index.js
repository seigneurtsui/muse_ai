const nodemailer = require('nodemailer');
const fs = require('fs');
const os = require('os');
const path = require('path');
const marked = require('marked');

const SKILL_DIR = path.join(__dirname);

function loadConfig() {
  // 兼容通过 `node index.js setup` 生成的本地配置；默认使用 ~/.config/omnirush/.env。
  const configPath = path.join(SKILL_DIR, 'config.json');
  if (fs.existsSync(configPath)) {
    return JSON.parse(fs.readFileSync(configPath, 'utf8'));
  }

  return null;
}

function loadEnvConfig() {
  // 从 Omnirush 的用户级 .env 文件加载配置
  const envPath = path.join(os.homedir(), '.config', 'omnirush', '.env');
  if (!fs.existsSync(envPath)) {
    return {};
  }

  const content = fs.readFileSync(envPath, 'utf8');
  const lines = content.split('\n');
  const config = {};

  lines.forEach(line => {
    const trimmed = line.trim();
    if (trimmed && !trimmed.startsWith('#') && trimmed.includes('=')) {
      const separator = trimmed.indexOf('=');
      const key = trimmed.slice(0, separator).trim();
      const value = trimmed.slice(separator + 1).trim().replace(/^['"]|['"]$/g, '');
      if (value) {
        config[key] = value;
      }
    }
  });

  return config;
}

// ── HTML Beautification ─────────────────────────────────────
function buildHtmlEmail(subject, body, style = 'red') {
  function escapeHtml(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  const themes = {
    red:    { accent: '#e74c3c', heading: '#2c3e50', bg: '#fef5f5', code_bg: '#f8f9fa' },
    blue:   { accent: '#2980b9', heading: '#2c3e50', bg: '#f0f7ff', code_bg: '#f0f4f8' },
    green:  { accent: '#27ae60', heading: '#1a5e2a', bg: '#f0faf4', code_bg: '#f4f9f6' },
    purple: { accent: '#8e44ad', heading: '#4a235a', bg: '#faf5ff', code_bg: '#f8f4fb' },
  };
  const c = themes[style] || themes.red;
  
  const bodyHtml = escapeHtml(body).replace(/\n/g, '<br>\n');
  const dateStr = new Date().toISOString().slice(0, 10);
  
  return `<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    background: #f5f5f5; padding: 24px; color: #333; line-height: 1.7;
  }
  .wrapper {
    max-width: 640px; margin: 0 auto; background: #fff;
    border-radius: 12px; overflow: hidden;
    box-shadow: 0 2px 12px rgba(0,0,0,0.08);
  }
  .header {
    background: linear-gradient(135deg, ${c.accent}, ${c.heading});
    color: #fff; padding: 28px 32px;
  }
  .header h1 { font-size: 20px; font-weight: 600; letter-spacing: 0.3px; }
  .header .meta { font-size: 13px; opacity: 0.85; margin-top: 6px; }
  .body {
    padding: 28px 32px; background: ${c.bg};
    font-size: 15px; color: #444;
  }
  .body pre, .body code {
    background: ${c.code_bg}; border-radius: 6px; padding: 2px 6px;
    font-family: 'SF Mono', Menlo, monospace; font-size: 13px;
  }
  .body pre { padding: 16px; overflow-x: auto; margin: 12px 0; }
  .footer {
    padding: 16px 32px; border-top: 1px solid #eee;
    font-size: 12px; color: #999; text-align: center;
  }
  .footer a { color: ${c.accent}; text-decoration: none; }
</style></head><body>
<div class="wrapper">
  <div class="header">
    <h1>📬 ${escapeHtml(subject)}</h1>
    <div class="meta">${dateStr} · via OpenCode</div>
  </div>
  <div class="body">${bodyHtml}</div>
  <div class="footer">
    此邮件通过 OpenCode smtp-email skill 发送 · ${dateStr}
  </div>
</div>
</body></html>`;
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function buildMdEmail(subject, mdContent, style = 'blue') {
  const themes = {
    red:    { accent: '#e74c3c', heading: '#2c3e50' },
    blue:   { accent: '#2980b9', heading: '#1a3a5c' },
    green:  { accent: '#27ae60', heading: '#1a5e2a' },
    purple: { accent: '#8e44ad', heading: '#4a235a' },
  };
  const c = themes[style] || themes.blue;
  const dateStr = new Date().toISOString().slice(0, 10);

  const bodyHtml = marked.parse(mdContent, { breaks: true, gfm: true });

  return `<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    background: #f0f4f8; padding: 24px; color: #333; line-height: 1.7;
  }
  .wrapper {
    max-width: 700px; margin: 0 auto; background: #fff;
    border-radius: 12px; overflow: hidden;
    box-shadow: 0 2px 16px rgba(0,0,0,0.08);
  }
  .header {
    background: linear-gradient(135deg, ${c.accent}, ${c.heading});
    color: #fff; padding: 28px 32px;
  }
  .header h1 { font-size: 20px; font-weight: 600; letter-spacing: 0.3px; }
  .header .meta { font-size: 13px; opacity: 0.85; margin-top: 6px; }
  .body {
    padding: 24px 32px; font-size: 15px; color: #444;
  }
  .body h1, .body h2, .body h3, .body h4 {
    color: ${c.heading}; margin-top: 24px; margin-bottom: 12px;
    line-height: 1.3;
  }
  .body h1 { font-size: 22px; border-bottom: 2px solid #eef2f7; padding-bottom: 8px; }
  .body h2 { font-size: 18px; border-bottom: 1px solid #eef2f7; padding-bottom: 6px; }
  .body h3 { font-size: 16px; }
  .body p { margin: 10px 0; }
  .body a { color: ${c.accent}; text-decoration: none; }
  .body a:hover { text-decoration: underline; }
  .body blockquote {
    margin: 12px 0; padding: 12px 16px; border-left: 4px solid ${c.accent};
    background: #f8fafc; border-radius: 0 6px 6px 0; color: #555;
    font-style: italic;
  }
  .body pre {
    background: #1e293b; color: #e2e8f0; padding: 16px; border-radius: 8px;
    overflow-x: auto; margin: 12px 0; font-size: 13px; line-height: 1.5;
  }
  .body code {
    background: #f1f5f9; border-radius: 4px; padding: 2px 6px;
    font-family: 'SF Mono', Menlo, monospace; font-size: 13px; color: #c7254e;
  }
  .body pre code { background: none; color: inherit; padding: 0; }
  .body ul, .body ol { margin: 8px 0; padding-left: 24px; }
  .body li { margin: 4px 0; }
  .body table {
    width: 100%; border-collapse: collapse; margin: 12px 0;
    font-size: 14px;
  }
  .body th, .body td {
    border: 1px solid #e2e8f0; padding: 8px 12px; text-align: left;
  }
  .body th { background: #f8fafc; font-weight: 600; color: ${c.heading}; }
  .body tr:nth-child(even) { background: #fafbfc; }
  .body hr { border: none; border-top: 1px solid #e2e8f0; margin: 24px 0; }
  .body img { max-width: 100%; border-radius: 6px; margin: 12px 0; }
  .body input[type="checkbox"] { margin-right: 6px; }
  .footer {
    padding: 16px 32px; border-top: 1px solid #eef2f7;
    font-size: 12px; color: #999; text-align: center;
  }
  .footer a { color: ${c.accent}; text-decoration: none; }
</style></head><body>
<div class="wrapper">
  <div class="header">
    <h1>🗺️ ${escapeHtml(subject)}</h1>
    <div class="meta">${dateStr} · via OpenCode smtp-email</div>
  </div>
  <div class="body">${bodyHtml}</div>
  <div class="footer">
    此邮件通过 OpenCode smtp-email skill 自动发送 · ${dateStr}
  </div>
</div>
</body></html>`;
}

async function sendSmtpEmail({ to, subject, html, text, from, style = 'red' }) {
  const config = loadConfig();
  const envConfig = loadEnvConfig();
  
  // 优先使用环境变量，其次使用配置
  const smtpHost = process.env.SMTP_HOST || envConfig.SMTP_HOST || config?.host;
  const smtpPort = process.env.SMTP_PORT || envConfig.SMTP_PORT || config?.port;
  const smtpUser = process.env.SMTP_USER || envConfig.SMTP_USER || config?.user;
  const smtpPass = process.env.SMTP_PASS || envConfig.SMTP_PASS || config?.pass;
  const smtpFrom = process.env.SMTP_FROM || envConfig.SMTP_FROM || config?.from || smtpUser;
  
  if (!smtpHost || !smtpPort || !smtpUser || !smtpPass) {
    throw new Error('Missing SMTP configuration. Set SMTP_* in ~/.config/omnirush/.env or the process environment.');
  }

  const isSecure = smtpPort == 465;
  
  const transporter = nodemailer.createTransport({
    host: smtpHost,
    port: parseInt(smtpPort),
    secure: isSecure,
    auth: {
      user: smtpUser,
      pass: smtpPass
    }
  });

  try {
    await transporter.verify();
  } catch (error) {
    throw new Error(`SMTP connection failed: ${error.message}`);
  }

  const mailOptions = {
    from: from || smtpFrom,
    to: to,
    subject: subject,
    html: html,
  };
  
  if (text) {
    mailOptions.text = text;
  }
  
  try {
    const info = await transporter.sendMail(mailOptions);
    
    return {
      success: true,
      messageId: info.messageId,
      message: 'Email sent successfully'
    };
  } catch (error) {
    throw new Error(`Failed to send email: ${error.message}`);
  }
}

async function verifyConnection() {
  const config = loadConfig();
  const envConfig = loadEnvConfig();
  
  // 优先使用环境变量，其次使用配置
  const smtpHost = process.env.SMTP_HOST || envConfig.SMTP_HOST || config?.host;
  const smtpPort = process.env.SMTP_PORT || envConfig.SMTP_PORT || config?.port;
  const smtpUser = process.env.SMTP_USER || envConfig.SMTP_USER || config?.user;
  const smtpPass = process.env.SMTP_PASS || envConfig.SMTP_PASS || config?.pass;
  
  if (!smtpHost || !smtpPort || !smtpUser || !smtpPass) {
    throw new Error('Missing SMTP configuration. Set SMTP_* in ~/.config/omnirush/.env or the process environment.');
  }

  const isSecure = smtpPort == 465;
  
  const transporter = nodemailer.createTransport({
    host: smtpHost,
    port: parseInt(smtpPort),
    secure: isSecure,
    auth: {
      user: smtpUser,
      pass: smtpPass
    }
  });

  try {
    await transporter.verify();
    console.log('✓ SMTP connection successful');
    return { success: true, message: 'Connection verified' };
  } catch (error) {
    throw new Error(`SMTP connection failed: ${error.message}`);
  }
}

function showConfig() {
  const config = loadConfig();
  const envConfig = loadEnvConfig();
  const hasEnv = !!(process.env.SMTP_HOST || envConfig.SMTP_HOST);
  const hasFile = !!config;
  
  console.log(`SMTP Config Status:`);
  console.log(`  config.json: ${hasFile ? '✓' : '✗'}`);
  console.log(`  Environment: ${hasEnv ? '✓' : '✗'}`);
  
  if (hasFile) {
    console.log('\nCurrent config:');
    console.log(`  Host: ${config.host}`);
    console.log(`  Port: ${config.port}`);
    console.log(`  User: ${config.user}`);
    console.log(`  From: ${config.from}`);
  }
}

// CLI
if (require.main === module) {
  const args = process.argv.slice(2);

  if (args.length === 0) {
    console.log('SMTP Email CLI - 发送邮件');
    console.log('\n用法:');
    console.log('  node index.js send --to <email> --subject "<subject>" --html "<html>"');
    console.log('  node index.js verify');
    console.log('  node index.js config');
    console.log('  node index.js setup <host> <port> <user> <pass> <from>');
    process.exit(1);
  }

  const action = args[0];

  const run = async () => {
    try {
      switch (action) {
        case 'send':
          const opts = {};
          for (let i = 1; i < args.length; i++) {
            if (args[i] === '--to' && args[i + 1]) opts.to = args[++i];
            else if (args[i] === '--subject' && args[i + 1]) opts.subject = args[++i];
            else if (args[i] === '--html' && args[i + 1]) opts.html = args[++i];
            else if (args[i] === '--text' && args[i + 1]) opts.text = args[++i];
            else if (args[i] === '--from' && args[i + 1]) opts.from = args[++i];
            else if (args[i] === '--style' && args[i + 1]) opts.style = args[++i];
            else if (args[i] === '--file' && args[i + 1]) {
              const filePath = args[++i];
              if (fs.existsSync(filePath)) {
                opts.mdContent = fs.readFileSync(filePath, 'utf8');
              } else {
                console.error('错误: 文件不存在:', filePath);
                process.exit(1);
              }
            }
          }
          
          if (!opts.to || !opts.subject || (!opts.html && !opts.text && !opts.mdContent)) {
            console.error('错误: 需要 --to, --subject, --html, --text 或 --file 参数');
            process.exit(1);
          }
          
          // Render markdown to HTML if file was provided
          if (!opts.html && opts.mdContent) {
            opts.html = buildMdEmail(opts.subject, opts.mdContent, opts.style || 'blue');
            delete opts.mdContent;
          }
          
          // Auto-wrap plain text into beautiful HTML
          if (!opts.html && opts.text) {
            opts.html = buildHtmlEmail(opts.subject, opts.text, opts.style || 'red');
            delete opts.text;
          }
          
          const result = await sendSmtpEmail(opts);
          console.log('✓ ' + result.message);
          break;

        case 'verify':
          await verifyConnection();
          break;

        case 'config':
          showConfig();
          break;

        case 'setup':
          if (args.length < 6) {
            console.error('错误: 需要 <host> <port> <user> <pass> <from>');
            process.exit(1);
          }
          
          const configData = {
            host: args[1],
            port: args[2],
            user: args[3],
            pass: args[4],
            from: args[5]
          };
          
          fs.writeFileSync(path.join(SKILL_DIR, 'config.json'), JSON.stringify(configData, null, 2));
          console.log('✓ Configuration saved to config.json');
          break;

        default:
          console.error('未知操作:', action);
          process.exit(1);
      }
    } catch (error) {
      console.error('错误:', error.message);
      process.exit(1);
    }
  };

  run();
}

module.exports = {
  sendSmtpEmail,
  verifyConnection,
  showConfig
};
