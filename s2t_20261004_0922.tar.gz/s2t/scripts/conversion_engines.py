"""OpenCC conversion backends; no subprocesses, downloads, or text diagnostics.

Public interface: EngineError, get_engine(mode, backend='auto'), doctor().
Each returned engine owns its converter. Call close() when finished.
"""
from __future__ import annotations

import ctypes
import importlib.metadata
import platform
import re
import sys
import threading
from pathlib import Path
from typing import Any


class EngineError(Exception):
    """A converter selection, conversion, or lifecycle failure.

    ``code`` is deliberately stable across backends; messages are text-free.
    """

    code = "engine_error"


_MODES = ("s2t", "t2s")
_BACKENDS = ("auto", "native", "opencc")
_INVALID_POINTER = ctypes.c_void_p(-1).value
_INSTALL_HELP = (
    "Install a compatible OpenCC Python package separately, for example "
    "`python3 -m pip install opencc-python-reimplemented` in your chosen "
    "environment. Nothing is installed automatically."
)


def _native_candidates() -> list[tuple[Path, Path]]:
    """Known Homebrew libraries and the config directory in that installation."""
    prefixes = [Path("/usr/local/opt/opencc"), Path("/opt/homebrew/opt/opencc")]
    if platform.machine().lower() in ("arm64", "aarch64"):
        prefixes.reverse()
    return [
        (prefix / "lib" / library, prefix / "share" / "opencc")
        for prefix in prefixes
        for library in ("libopencc.1.2.dylib", "libopencc.dylib")
    ]


def _native_version(library: Path) -> str | None:
    try:
        match = re.fullmatch(r"libopencc\.(\d+(?:\.\d+)*)\.dylib", library.resolve().name)
    except OSError:
        return None
    return match.group(1) if match else None


def _python_package_info() -> dict[str, Any]:
    distributions: dict[str, str] = {}
    for name in ("opencc-python-reimplemented", "OpenCC"):
        try:
            distributions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            pass
    module_version = getattr(sys.modules.get("opencc"), "__version__", None)
    version = module_version if isinstance(module_version, str) else None
    if version is None and len(distributions) == 1:
        version = next(iter(distributions.values()))
    return {"version": version, "distributions": distributions}


def _bind_native(library: Any) -> None:
    # char* output must remain a raw pointer until explicitly freed. c_char_p
    # restype would copy it to bytes, losing ownership of the allocated buffer.
    signatures = {
        "opencc_open": ([ctypes.c_char_p], ctypes.c_void_p),
        "opencc_convert_utf8": (
            [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t], ctypes.c_void_p
        ),
        "opencc_convert_utf8_free": ([ctypes.c_void_p], None),
        "opencc_close": ([ctypes.c_void_p], ctypes.c_int),
        "opencc_error": ([], ctypes.c_char_p),
    }
    for name, (arguments, result) in signatures.items():
        function = getattr(library, name)
        function.argtypes = arguments
        function.restype = result


class _NativeEngine:
    name = "native"

    def __init__(self, mode: str, library: Any, library_path: Path, config: Path):
        self.mode = mode
        self._library = library
        self._handle: int | None = None
        self._details = {
            "library": str(library_path),
            "config": str(config),
            "version": _native_version(library_path),
        }
        try:
            handle = library.opencc_open(str(config).encode("utf-8"))
        except Exception:
            raise EngineError("Native OpenCC could not open its configuration.") from None
        if handle in (None, 0, -1, _INVALID_POINTER):
            raise EngineError("Native OpenCC rejected its configuration or dictionaries.")
        self._handle = handle

    def convert(self, text: str) -> str:
        if self._handle is None:
            raise EngineError("Native OpenCC engine is closed.")
        # The allocating C API returns a NUL-terminated string with no length.
        # Reject rather than silently truncate. Auto mode retries all text with
        # Python; do not split text and change phrase boundaries.
        if "\0" in text:
            raise EngineError("Native OpenCC cannot safely return embedded NUL characters.")
        try:
            encoded = text.encode("utf-8")
            pointer = self._library.opencc_convert_utf8(self._handle, encoded, len(encoded))
        except Exception:
            raise EngineError("Native OpenCC conversion failed.") from None
        if pointer in (None, 0, -1, _INVALID_POINTER):
            raise EngineError("Native OpenCC conversion returned no valid output buffer.")
        try:
            try:
                return ctypes.string_at(pointer).decode("utf-8")
            finally:
                self._library.opencc_convert_utf8_free(pointer)
        except Exception:
            raise EngineError("Native OpenCC could not decode or release its output buffer.") from None

    def close(self) -> None:
        handle, self._handle = self._handle, None
        if handle is None:
            return
        # A failed close has ambiguous ownership. Never retry the pointer and
        # risk a double free, including from __del__.
        try:
            result = self._library.opencc_close(handle)
        except Exception:
            raise EngineError("Native OpenCC could not release its converter.") from None
        if result != 0:
            raise EngineError("Native OpenCC reported a converter cleanup failure.")

    def metadata(self) -> dict[str, Any]:
        return dict(self._details)

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass


def _make_native(mode: str) -> _NativeEngine:
    if platform.system() != "Darwin":
        raise EngineError("The native backend is supported only on macOS (Darwin).")
    failures: list[str] = []
    for library_path, config_dir in _native_candidates():
        config = config_dir / f"{mode}.json"
        if not library_path.is_file() or not config.is_file():
            continue
        try:
            library = ctypes.CDLL(str(library_path))
            _bind_native(library)
            return _NativeEngine(mode, library, library_path, config)
        except EngineError as error:
            failures.append(str(error))
        except Exception:
            # Loader exception messages can be noisy; known paths are exposed
            # by doctor() instead. Never use the global, non-thread-safe C error
            # string as diagnostics: it can include application input.
            failures.append("Native OpenCC library could not be loaded or lacks the required C API.")
    detail = failures[-1] if failures else "No matching Homebrew library and configuration were found."
    raise EngineError(
        "Native OpenCC unavailable. " + detail
        + " Check the OpenCC Homebrew installation and its Python-compatible CPU architecture."
    )


class _PythonEngine:
    name = "opencc"

    def __init__(self, mode: str):
        self.mode = mode
        self._converter: Any = None
        try:
            from opencc import OpenCC
        except Exception:
            raise EngineError("Python OpenCC is unavailable or could not be imported. " + _INSTALL_HELP) from None
        try:
            self._converter = OpenCC(mode)
        except Exception:
            raise EngineError("Python OpenCC could not initialize the requested configuration. " + _INSTALL_HELP) from None
        self._details = _python_package_info()

    def convert(self, text: str) -> str:
        if self._converter is None:
            raise EngineError("Python OpenCC engine is closed.")
        try:
            result = self._converter.convert(text)
        except Exception:
            raise EngineError("Python OpenCC conversion failed.") from None
        if not isinstance(result, str):
            raise EngineError("Python OpenCC returned a non-text result.")
        # No strip(), line normalization, or fixed-size chunks.
        return result

    def close(self) -> None:
        # Both supported Python APIs manage their own converter lifetime.
        self._converter = None

    def metadata(self) -> dict[str, Any]:
        return {**self._details, "distributions": dict(self._details["distributions"])}


class _Engine:
    """Per-request owner; serializes conversion and close on its own instance."""

    def __init__(self, mode: str, requested: str, converter: Any, fallback: str | None = None):
        self.mode = mode
        self._requested = requested
        self._converter = converter
        self._fallback = fallback
        self._closed = False
        self._lock = threading.RLock()

    @property
    def name(self) -> str:
        return self._converter.name

    def convert(self, text: str) -> str:
        with self._lock:
            if self._closed:
                raise EngineError("Conversion engine is closed.")
            if not isinstance(text, str):
                raise EngineError("Conversion input must be a string.")
            try:
                return self._converter.convert(text)
            except EngineError as error:
                if self._requested != "auto" or self.name != "native":
                    raise
                # Save only our sanitized error, never the input or partial output.
                self._fallback = str(error)
                try:
                    self._converter.close()
                except EngineError:
                    self._fallback += " Native converter cleanup also failed."
                try:
                    replacement = _PythonEngine(self.mode)
                except EngineError as fallback_error:
                    self._closed = True
                    raise EngineError(
                        "Native OpenCC failed and Python fallback is unavailable. " + str(fallback_error)
                    ) from None
                self._converter = replacement
                # Retry the entire original argument once. Further calls use the
                # Python engine; never combine outputs from different backends.
                return replacement.convert(text)

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
            self._converter.close()

    def metadata(self) -> dict[str, Any]:
        with self._lock:
            return {
                **self._converter.metadata(),
                "backend": self.name,
                "selected_backend": self.name,
                "requested_backend": self._requested,
                "mode": self.mode,
                "fallback_reason": self._fallback,
                "available": not self._closed,
                "closed": self._closed,
            }


def get_engine(mode: str, backend: str = "auto") -> _Engine:
    """Select an independent converter; explicit choices never fall back.

    macOS auto: native Homebrew C API, then Python OpenCC. Other platforms:
    Python OpenCC only. A runtime native failure in auto retries the complete
    convert() argument through Python and records its reason in metadata().
    """
    if mode not in _MODES:
        raise EngineError("Unsupported conversion mode; choose s2t or t2s.")
    if backend not in _BACKENDS:
        raise EngineError("Unsupported engine; choose auto, native, or opencc.")
    if backend == "native":
        return _Engine(mode, backend, _make_native(mode))
    if backend == "opencc" or platform.system() != "Darwin":
        return _Engine(mode, backend, _PythonEngine(mode))
    try:
        return _Engine(mode, backend, _make_native(mode))
    except EngineError as error:
        fallback = str(error)
    try:
        return _Engine(mode, backend, _PythonEngine(mode), fallback)
    except EngineError as error:
        raise EngineError("No usable OpenCC converter. " + fallback + " " + str(error)) from None


def doctor() -> dict[str, Any]:
    """JSON-safe platform/package data and tiny synthetic s2t/t2s probes.

    Does not inspect documents, run executables, or install dependencies.
    Native libraries are never searched or loaded outside Darwin.
    """
    system = platform.system()
    report: dict[str, Any] = {
        "platform": {"system": system, "machine": platform.machine(), "python": platform.python_version()},
        "engines": {},
    }
    samples = {
        "s2t": (" \t汉语龙😀\r\n", " \t漢語龍😀\r\n"),
        "t2s": (" \t漢語龍😀\r\n", " \t汉语龙😀\r\n"),
    }
    for backend in ("native", "opencc"):
        entry: dict[str, Any] = {"available": False, "version": None, "probes": {}}
        if backend == "native":
            entry["supported"] = system == "Darwin"
            if system != "Darwin":
                entry["reason"] = "Native backend is macOS-only; no native library was loaded."
                report["engines"][backend] = entry
                continue
            entry["candidates"] = [
                {"library": str(library), "exists": library.is_file(),
                 "configs": {mode: (configs / f"{mode}.json").is_file() for mode in _MODES}}
                for library, configs in _native_candidates()
            ]
        for mode, (source, expected) in samples.items():
            engine: _Engine | None = None
            probe: dict[str, Any] = {"ok": False}
            try:
                engine = get_engine(mode, backend)
                details = engine.metadata()
                entry["version"] = details.get("version")
                if "distributions" in details:
                    entry["distributions"] = details["distributions"]
                if "library" in details:
                    entry["library"] = details["library"]
                if engine.convert(source) != expected:
                    raise EngineError("Synthetic conversion did not match the expected glyphs and whitespace.")
                probe["ok"] = True
            except EngineError as error:
                probe.update(error=str(error), code=error.code)
            finally:
                if engine is not None:
                    try:
                        engine.close()
                    except EngineError as error:
                        probe.update(ok=False, error=str(error), code=error.code)
            entry["probes"][mode] = probe
        entry["available"] = all(probe["ok"] for probe in entry["probes"].values())
        report["engines"][backend] = entry
    report["auto_backend"] = next(
        (name for name in ("native", "opencc") if report["engines"][name]["available"]), None
    )
    return report
