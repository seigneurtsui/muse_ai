#!/usr/bin/env bash
# usage.sh — example invocations of the html-toc-embed skill.
set -euo pipefail

B="$HOME/.config/freebuff/skills/html-toc-embed/scripts/batch_add_toc.py"

# 1) Preview: scan and plan, write nothing.
python3 "$B" ./docs ./site --dry-run

# 2) Flat conversion: docs/*.html -> site/*.html
python3 "$B" ./docs ./site

# 3) Recursive (keep structure), include H2/H3/H4, skip TOC below 3 headings.
python3 "$B" ./docs ./site -r --levels 2,3,4 --min-headings 3

# 4) Rewrite the source files in place (atomic), no output copy.
python3 "$B" ./docs --in-place

# 5) Incremental: only rewrite changed docs; skip filenames matching a regex.
python3 "$B" ./docs ./site -r --incremental --exclude-pattern '-draft'

# 6) Machine-readable report to stdout (logs go to stderr).
python3 "$B" ./docs ./site -r --json | python3 -m json.tool

# 7) Write the report to a file and use a custom TOC panel title.
python3 "$B" ./docs ./site -r --toc-title 'Contents' --report ./toc-report.json
