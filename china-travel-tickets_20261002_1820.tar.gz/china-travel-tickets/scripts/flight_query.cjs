#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const PACKAGE_VERSION = '1.0.16';
const SOURCE = `FlyAI official CLI (@fly-ai/flyai-cli@${PACKAGE_VERSION})`;
const DEFAULT_LIMIT = 10;
const DEFAULT_TIMEOUT_MS = 60_000;
const DEFAULT_SORT_TYPE = 3;
const SHANGHAI_TIME_ZONE = 'Asia/Shanghai';
const CLI_PATH = path.join(
  __dirname,
  '..',
  'node_modules',
  '@fly-ai',
  'flyai-cli',
  'dist',
  'flyai-bundle.cjs',
);

class AdapterError extends Error {
  constructor(code, message, hint) {
    super(message);
    this.name = 'AdapterError';
    this.code = code;
    this.hint = hint;
  }
}

function usage() {
  return `Usage: node china-flight-adapter.cjs --from <city|airport> --to <city|airport> [options]

Query official FlyAI flight inventory without requiring a user API key.

Options:
  --from, --origin <value>       Departure Chinese city or airport code (required)
  --to, --destination <value>   Arrival Chinese city or airport code (required)
  --date, --dep-date <date>     Departure date, YYYY-MM-DD (default: Shanghai date + 7 days)
  --limit <n>                   Number of returned records, 1-50 (default: 10)
  --sort-type <1-8>             FlyAI sort order (default: 3, price ascending)
  --timeout-ms <n>              Upstream timeout (default: 60000)
  --json                        Accepted for scripting; JSON is always printed on success
  --help                        Show this help

Examples:
  node china-flight-adapter.cjs --from 北京 --to 上海 --date 2026-10-09 --limit 5
  node china-flight-adapter.cjs --origin PEK --destination SHA --date 2026-10-09
`;
}

function optionValue(argv, index, option) {
  const value = argv[index + 1];
  if (!value || value.startsWith('--')) {
    throw new AdapterError('INVALID_ARGUMENT', `${option} requires a value`, usage());
  }
  return value;
}

function parseArgs(argv) {
  const options = {
    from: undefined,
    to: undefined,
    date: undefined,
    limit: DEFAULT_LIMIT,
    sortType: DEFAULT_SORT_TYPE,
    timeoutMs: DEFAULT_TIMEOUT_MS,
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    switch (arg) {
      case '--from':
      case '--origin':
        options.from = optionValue(argv, i, arg);
        i += 1;
        break;
      case '--to':
      case '--destination':
        options.to = optionValue(argv, i, arg);
        i += 1;
        break;
      case '--date':
      case '--dep-date':
        options.date = optionValue(argv, i, arg);
        i += 1;
        break;
      case '--limit':
        options.limit = parsePositiveInteger(optionValue(argv, i, arg), '--limit');
        i += 1;
        if (options.limit > 50) {
          throw new AdapterError('INVALID_ARGUMENT', '--limit must be between 1 and 50', usage());
        }
        break;
      case '--sort-type':
        options.sortType = parsePositiveInteger(optionValue(argv, i, arg), '--sort-type');
        i += 1;
        if (options.sortType < 1 || options.sortType > 8) {
          throw new AdapterError('INVALID_ARGUMENT', '--sort-type must be between 1 and 8', usage());
        }
        break;
      case '--timeout-ms':
        options.timeoutMs = parsePositiveInteger(optionValue(argv, i, arg), '--timeout-ms');
        i += 1;
        break;
      case '--json':
        break;
      case '--help':
      case '-h':
        options.help = true;
        break;
      default:
        throw new AdapterError('INVALID_ARGUMENT', `Unknown argument: ${arg}`, usage());
    }
  }

  if (options.help) return options;
  if (!options.from || !options.from.trim()) {
    throw new AdapterError('INVALID_ARGUMENT', '--from is required', usage());
  }
  if (!options.to || !options.to.trim()) {
    throw new AdapterError('INVALID_ARGUMENT', '--to is required', usage());
  }

  options.from = options.from.trim();
  options.to = options.to.trim();
  options.date = options.date || shanghaiDatePlusDays(7);
  validateDate(options.date);
  if (options.date < shanghaiDateString()) {
    throw new AdapterError(
      'INVALID_ARGUMENT',
      `--date must not be before today's Shanghai date (${shanghaiDateString()})`,
      'Use TZ=Asia/Shanghai date context or pass a future YYYY-MM-DD.',
    );
  }
  return options;
}

function parsePositiveInteger(value, name) {
  if (!/^\d+$/.test(value)) {
    throw new AdapterError('INVALID_ARGUMENT', `${name} must be a positive integer`, usage());
  }
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed < 1) {
    throw new AdapterError('INVALID_ARGUMENT', `${name} must be a positive integer`, usage());
  }
  return parsed;
}

function validateDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    throw new AdapterError('INVALID_ARGUMENT', '--date must use YYYY-MM-DD', usage());
  }
  const [year, month, day] = value.split('-').map(Number);
  const check = new Date(Date.UTC(year, month - 1, day));
  if (
    check.getUTCFullYear() !== year ||
    check.getUTCMonth() !== month - 1 ||
    check.getUTCDate() !== day
  ) {
    throw new AdapterError('INVALID_ARGUMENT', `Invalid calendar date: ${value}`, usage());
  }
}

function shanghaiDateString(now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: SHANGHAI_TIME_ZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(now);
  const values = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function shanghaiDatePlusDays(days, now = new Date()) {
  const date = new Date(`${shanghaiDateString(now)}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

function buildCliArgs(options) {
  return [
    'search-flight',
    '--origin',
    options.from,
    '--destination',
    options.to,
    '--dep-date',
    options.date,
    '--sort-type',
    String(options.sortType),
  ];
}

function keylessEnvironment() {
  const env = { ...process.env };
  // Never read or forward a user's FlyAI/API credential. The official bundle's
  // built-in trial authorization is used when these variables are absent.
  for (const key of [
    'FLYAI_API_KEY',
    'DEBUG_FLYAI_API_KEY',
    'FLYAI_SIGN_SECRET',
    'DEBUG_FLYAI_MCP_URL',
    'FLYAI_MCP_URL',
    'FLYAI_PROFILE',
  ]) {
    delete env[key];
  }

  // Keep the CLI away from a user's home-directory FlyAI config. This also
  // makes the adapter genuinely no-setup for a clean skill subprocess.
  const isolatedHome = fs.mkdtempSync(path.join(os.tmpdir(), 'china-flight-home-'));
  env.HOME = isolatedHome;
  env.USERPROFILE = isolatedHome;
  env.XDG_CONFIG_HOME = path.join(isolatedHome, '.config');
  return { env, isolatedHome };
}

function runOfficialCli(options, cliPath = CLI_PATH) {
  if (!fs.existsSync(cliPath)) {
    throw new AdapterError(
      'DEPENDENCY_MISSING',
      `Official FlyAI CLI bundle not found: ${cliPath}`,
      'Run npm install --ignore-scripts in the china-travel-tickets skill directory.',
    );
  }

  const isolated = keylessEnvironment();
  let result;
  try {
    result = spawnSync(
      process.execPath,
      [cliPath, ...buildCliArgs(options)],
      {
        cwd: __dirname,
        env: isolated.env,
        encoding: 'utf8',
        timeout: options.timeoutMs,
        maxBuffer: 20 * 1024 * 1024,
      },
    );
  } finally {
    fs.rmSync(isolated.isolatedHome, { recursive: true, force: true });
  }

  return {
    exitCode: result.status,
    stdout: result.stdout || '',
    stderr: [result.stderr || '', result.error?.message || ''].filter(Boolean).join('\n'),
    signal: result.signal || undefined,
  };
}

function parsePayload(stdout) {
  const text = String(stdout || '').trim();
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function classifyError(text, exitCode, signal) {
  const lower = String(text || '').toLowerCase();
  if (signal || lower.includes('timed out') || lower.includes('timeout')) {
    return {
      code: 'UPSTREAM_TIMEOUT',
      message: 'FlyAI did not answer before the timeout.',
      hint: 'Retry later; no fare is reported when the official query is incomplete.',
    };
  }
  if (
    lower.includes('quota') ||
    lower.includes('rate limit') ||
    lower.includes('too many') ||
    lower.includes('429') ||
    lower.includes('次数') ||
    lower.includes('额度')
  ) {
    return {
      code: 'TRIAL_QUOTA_EXCEEDED',
      message: 'The FlyAI no-key trial quota appears exhausted or rate-limited.',
      hint: 'Wait and retry, or configure an official key in the upstream FlyAI CLI if permitted.',
    };
  }
  if (
    lower.includes('unauthorized') ||
    lower.includes('forbidden') ||
    lower.includes('authentication') ||
    lower.includes('api key') ||
    lower.includes('token') ||
    lower.includes('401') ||
    lower.includes('403') ||
    lower.includes('鉴权') ||
    lower.includes('认证') ||
    lower.includes('密钥')
  ) {
    return {
      code: 'TRIAL_AUTH_REQUIRED',
      message: 'FlyAI rejected the no-key trial request; registration or an official API key may now be required.',
      hint: 'See https://flyai.open.fliggy.com/docs/quickstart and https://flyai.open.fliggy.com/console.',
    };
  }
  return {
    code: exitCode === null ? 'UPSTREAM_PROCESS_ERROR' : 'FLYAI_QUERY_FAILED',
    message: 'The official FlyAI flight query failed.',
    hint: 'No fare has been fabricated; inspect the upstream status and retry later.',
  };
}

function redactDiagnostics(text) {
  return String(text || '')
    .replace(/Bearer\s+[A-Za-z0-9._+/=-]+/gi, 'Bearer [redacted]')
    .replace(/(?:api[_ -]?key|token|secret|authorization)["'=: ]+[A-Za-z0-9._+/=-]{8,}/gi, '$1 [redacted]')
    .slice(0, 800);
}

function query(options, dependencies = {}) {
  const runner = dependencies.runner || runOfficialCli;
  const now = dependencies.now || new Date();
  const result = runner(options);
  const payload = parsePayload(result.stdout);
  const itemList = payload?.data?.itemList;

  if (payload && payload.status === 0 && Array.isArray(itemList)) {
    const output = {
      source: SOURCE,
      timestamp: now.toISOString(),
      query: {
        from: options.from,
        to: options.to,
        date: options.date,
        limit: options.limit,
      },
      status: payload.status,
      message: payload.message,
      availableCount: itemList.length,
      resultCount: Math.min(itemList.length, options.limit),
      results: itemList.slice(0, options.limit),
    };
    if (typeof payload.systemMessage === 'string' && payload.systemMessage) {
      output.systemMessage = payload.systemMessage;
    }
    return output;
  }

  const upstreamText = [payload?.message, result.stderr, result.stdout]
    .filter(Boolean)
    .join('\n');
  const classified = classifyError(upstreamText, result.exitCode, result.signal);
  throw new AdapterError(
    classified.code,
    `${classified.message}${payload?.message ? ` Upstream: ${payload.message}` : ''}`,
    `${classified.hint}${result.stderr ? ` Diagnostic: ${redactDiagnostics(result.stderr)}` : ''}`,
  );
}

function main() {
  try {
    const options = parseArgs(process.argv.slice(2));
    if (options.help) {
      process.stdout.write(usage());
      return 0;
    }
    process.stdout.write(`${JSON.stringify(query(options))}\n`);
    return 0;
  } catch (error) {
    const adapterError = error instanceof AdapterError
      ? error
      : new AdapterError('UNEXPECTED_ERROR', error.message || String(error), 'No fare was reported.');
    process.stderr.write(`china-flight-adapter: ${adapterError.code}: ${adapterError.message}\n`);
    if (adapterError.hint) process.stderr.write(`${adapterError.hint}\n`);
    return 1;
  }
}

if (require.main === module) {
  process.exitCode = main();
}

module.exports = {
  SOURCE,
  AdapterError,
  buildCliArgs,
  classifyError,
  parseArgs,
  parsePayload,
  query,
  redactDiagnostics,
  shanghaiDatePlusDays,
  shanghaiDateString,
  validateDate,
};
