# AGENTS.md for agnes-text2video

## Environment Variables

AGNES_API_KEY is defined in `/Users/seigneur/.config/opencode/.env`

Load with:
```bash
set -a; source /Users/seigneur/.config/opencode/.env; set +a
```
Or pass inline:
```bash
export AGNES_API_KEY=sk-40tGLaeHdZkWPHjbpR4K5xY1aURbC8mPrTcye714ovu3s03q
```

## Scripts

- `scripts/text2image.mjs` — text-to-image generation
- `scripts/text2video.mjs` — text-to-video generation
- `scripts/agnes.mjs` — shared API client
- `scripts/chat.mjs` — prompt expansion via chat

## Default Output

`~/Downloads/text2video/`
