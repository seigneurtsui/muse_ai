import json
import math
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts import auto_video_pipeline as pipeline
from scripts.edit_evidence import padded_ranges, build_edl
from scripts.render_video import preview_dimensions, duck_expression
from scripts.srt_utils import write_cues
import test_batch_features as batch_tests


class EvidenceUnitTests(unittest.TestCase):
    def test_padding_never_enters_neighbor_phrase_or_overlaps_contiguous_ranges(self):
        with tempfile.TemporaryDirectory() as temp:
            srt = Path(temp) / 'source.srt'
            write_cues(srt, [(0.1, 0.9, ['one']), (1.0, 1.9, ['two']), (2.2, 2.9, ['three'])])
            ranges = padded_ranges([{'start': 1, 'end': 1.9, 'speed': 1}], srt, 3, 120)
            self.assertAlmostEqual(ranges[0]['start'], 0.9)
            self.assertAlmostEqual(ranges[0]['end'], 2.02)
            joined = padded_ranges([{'start': 0, 'end': 1, 'speed': 1}, {'start': 1, 'end': 3, 'speed': 2}], srt, 3, 120)
            self.assertEqual(joined[0]['end'], joined[1]['start'])
            edl = build_edl('/source.mp4', 'hash', srt, joined, [1, 1.03], 30)
            self.assertEqual(edl['entries'][1]['output_start'], 1)
            self.assertAlmostEqual(edl['entries'][1]['output_end'], 2.03)
            self.assertIn('two', edl['entries'][1]['quote'])
            self.assertEqual(edl['entries'][0]['transcript_engine'], 'faster-whisper-stt')
            for bad in (-1, 201, float('nan')):
                with self.assertRaises(ValueError):
                    padded_ranges([{'start': 0, 'end': 3, 'speed': 1}], srt, 3, bad)
            with self.assertRaisesRegex(ValueError, 'cuts a subtitle phrase'):
                padded_ranges([{'start': 0.5, 'end': 3, 'speed': 1}], srt, 3, 120)

    def test_preview_is_real_720p_and_does_not_upscale(self):
        self.assertEqual(preview_dimensions(1080, 1920), (720, 1280))
        self.assertEqual(preview_dimensions(1920, 1080), (1280, 720))
        self.assertEqual(preview_dimensions(640, 360), (640, 360))

    def test_final_resume_checks_media_and_edl_hashes(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            final, edl, report = [root / name for name in ('final.mp4', 'edl.json', 'report.json')]
            final.write_bytes(b'QA verified bytes')
            edl.write_text('{"entries": []}')
            pipeline.write_json(report, {'ok': True, 'sha256': pipeline.sha256(final)})
            item = {'paths': {'final': str(final), 'edl': str(edl)}, 'edl_sha256': pipeline.sha256(edl),
                    'stages': {'final_qa': {'report': {'report': str(report)}}}}
            self.assertTrue(pipeline.cached_final_is_verified(item))
            final.write_bytes(b'changed bytes')
            self.assertFalse(pipeline.cached_final_is_verified(item))
            final.write_bytes(b'QA verified bytes')
            edl.write_text('{"entries": ["tampered"]}')
            self.assertFalse(pipeline.cached_final_is_verified(item))

    def test_approval_is_transient_but_gate_restored(self):
        with tempfile.TemporaryDirectory() as temp:
            pipeline.write_json(Path(temp) / 'state.json', {'options': {'stop_for_preview': True, 'approve_preview': True, 'cut_padding_ms': 150}})
            args = pipeline.parse_args(['--resume-batch', temp])
            self.assertTrue(args.stop_for_preview)
            self.assertFalse(args.approve_preview)
            self.assertEqual(args.cut_padding_ms, 150)
            self.assertFalse(pipeline.parse_args(['--resume-batch', temp, '--no-stop-for-preview']).stop_for_preview)


@unittest.skipUnless(shutil.which('ffmpeg') and pipeline.ASS_SCRIPT.is_file(), 'requires FFmpeg/ASS skill')
class PreviewIntegrationTests(batch_tests.BatchIntegrationTests):
    # Reuse fixture helpers, not the base test cases.
    test_merge_release_and_resume = None
    test_edit_review_then_resume_uses_modified_ranges = None

    def test_preview_gate_changed_content_and_hash_cannot_be_approved(self):
        self.assertEqual(self.run_pipeline('--stop-for-preview', '--release-pack'), 11)
        state = self.state()
        self.assertEqual(state['status'], 'awaiting_preview')
        self.assertEqual(state['summary']['awaiting_preview'], 2)
        self.assertEqual(state['merge']['status'], 'blocked')
        self.assertEqual(state['release_pack']['status'], 'blocked')
        for item in state['videos']:
            directory = self.batch / 'videos' / item['id']
            self.assertFalse((directory / 'final.mp4').exists())
            preview = Path(item['paths']['preview'])
            report = json.loads((directory / 'qa/preview/report.json').read_text())
            self.assertTrue(report['ok'])
            evidence = json.loads(Path(report['boundary_evidence']).read_text())
            self.assertEqual(evidence['human_review'], 'pending')
            self.assertTrue(all(Path(e['video']).is_file() for e in evidence['entries']))
            self.assertEqual(evidence['video_sha256'], pipeline.sha256(preview))
        # Approval for a prior subtitle style may never approve the new preview.
        self.assertEqual(self.run_pipeline('--approve-preview', '--subtitle-font-size', '20'), 11)
        item = self.state()['videos'][0]
        Path(item['paths']['preview']).write_bytes(b'corrupt preview')
        self.assertEqual(self.run_pipeline('--approve-preview'), 11)
        # Now both current previews exist and are unchanged.
        self.assertEqual(self.run_pipeline('--approve-preview', '--no-release-pack'), 0)
        self.assertTrue((self.batch / 'final.mp4').exists())
        self.assertTrue((self.batch / 'edl.json').exists())
        for item in self.state()['videos']:
            self.assertEqual(item['stages']['preview_gate']['status'], 'approved')
            self.assertTrue(Path(item['paths']['final']).is_file())
        # Approval isn't replayed from state, but completed outputs remain cached.
        mtime = (self.batch / 'final.mp4').stat().st_mtime_ns
        self.assertEqual(self.run_pipeline(), 0)
        self.assertEqual((self.batch / 'final.mp4').stat().st_mtime_ns, mtime)
        self.assertEqual(self.run_pipeline('--force-render', '--approve-preview'), 11)

    def test_dry_run_discloses_cloud_voiceover_without_synthesis(self):
        import contextlib
        import io
        from unittest import mock
        from scripts import voiceover
        script = self.root / 'voiceover.json'
        pipeline.write_json(script, {'lines': [{'text': 'Narration', 'start': 0.5, 'end': 2.5}]})
        state_mtime = (self.batch / 'state.json').stat().st_mtime_ns
        output = io.StringIO()
        with mock.patch.object(voiceover, 'prepare_voiceover', side_effect=AssertionError('dry-run synthesis')), contextlib.redirect_stdout(output):
            self.assertEqual(pipeline.main(['--resume-batch', str(self.batch), '--dry-run', '--stop-for-preview', '--voiceover-script', str(script)]), 0)
        data = json.loads(output.getvalue())
        self.assertTrue(data['preview_approval'])
        self.assertTrue(data['voiceover']['enabled'])
        self.assertFalse(data['voiceover']['synthesis_performed'])
        self.assertIn('Microsoft Edge cloud', data['voiceover']['privacy'])
        self.assertEqual((self.batch / 'state.json').stat().st_mtime_ns, state_mtime)

    def test_voiceover_is_opt_in_and_cache_survives_preview_approval(self):
        from unittest import mock
        from scripts import voiceover
        script = self.root / 'voiceover.json'
        pipeline.write_json(script, {'videos': {item['id']: {'lines': [{'text': 'Narration', 'start': 0.5, 'end': 2.5}]} for item in self.state()['videos']}})
        def synthesize(text, output, **config):
            subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'sine=frequency=880:sample_rate=48000:duration=0.4', '-c:a', 'libmp3lame', str(output)], check=True, capture_output=True)
        with mock.patch.object(voiceover, '_synthesize', side_effect=synthesize) as synth:
            self.assertEqual(self.run_pipeline('--stop-for-preview', '--voiceover-script', str(script), '--voiceover-captions', 'voiceover'), 11)
            self.assertEqual(synth.call_count, 2)
            self.assertEqual(self.run_pipeline('--approve-preview'), 0)
            self.assertEqual(synth.call_count, 2, 'unchanged lines must not be synthesized on resume')
        for item in self.state()['videos']:
            self.assertEqual(item['stages']['voiceover']['status'], 'complete')
            self.assertEqual(item['stages']['preview_gate']['status'], 'approved')
            self.assertEqual(pipeline.read_cues(Path(item['paths']['timeline_srt']))[0][2], ['Narration'])
            media = pipeline.media_signature(Path(item['paths']['final']))
            self.assertEqual((media['audio_codec'], media['sample_rate'], media['channels']), ('aac', '48000', 2))
        # Unconfigured batches must never call or even import the adapter path.
        args = pipeline.build_parser().parse_args([])
        item = {'id': 'disabled', 'stages': {}}
        with mock.patch.object(voiceover, 'prepare_voiceover', side_effect=AssertionError('unrequested TTS')):
            self.assertEqual(pipeline.voiceover_for(item, self.root, args, script, 3), script)

    def test_edit_review_and_preview_are_separate_gates(self):
        self.assertEqual(self.run_pipeline('--edit-mode', '--stop-for-review', '--stop-for-preview', '--no-merge'), 11)
        self.assertEqual(self.state()['summary']['awaiting_review'], 2)
        self.assertEqual(self.run_pipeline('--approve-review'), 11)
        self.assertEqual(self.state()['summary']['awaiting_preview'], 2)
        for item in self.state()['videos']:
            edl = json.loads(Path(item['paths']['edl']).read_text())
            self.assertEqual(len(edl['entries']), 2)
            self.assertEqual(edl['entries'][1]['output_start'], edl['entries'][0]['output_end'])
        self.assertEqual(self.run_pipeline('--approve-preview'), 0)


@unittest.skipUnless(shutil.which('ffmpeg'), 'requires FFmpeg')
class AudioRenderTests(unittest.TestCase):
    def test_real_source_ducking_recovers_outside_voiceover(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source, narration, output = [root / name for name in ('source.mp4', 'voice.wav', 'output.mp4')]
            subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=red:s=160x90:r=24:d=3', '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000:duration=3', '-c:v', 'libx264', '-threads', '1', '-c:a', 'aac', '-ac', '2', str(source)], check=True, capture_output=True)
            # Silent narration isolates the measured attenuation of the source track.
            subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo', '-t', '3', str(narration)], check=True, capture_output=True)
            manifest = root / 'manifest.json'
            pipeline.write_json(manifest, {'intervals': [{'start': 1, 'end': 2}], 'duck_db': -12})
            subprocess.run([sys.executable, str(pipeline.RENDER_SCRIPT), '--source', str(source), '--output', str(output), '--voiceover-audio', str(narration), '--voiceover-manifest', str(manifest), '--audio-fade-ms', '30', '--fps', '24', '--preset', 'ultrafast'], check=True, capture_output=True)
            import array
            def rms(at, length=0.2):
                data = subprocess.run(['ffmpeg', '-v', 'error', '-ss', str(at), '-i', str(output), '-t', str(length), '-vn', '-f', 'f32le', '-ac', '1', '-'], check=True, capture_output=True).stdout
                samples = array.array('f', data)
                return math.sqrt(sum(x*x for x in samples) / len(samples))
            normal, ducked, recovered = rms(0.5), rms(1.4), rms(2.4)
            self.assertAlmostEqual(20 * math.log10(ducked / normal), -12, delta=1)
            self.assertAlmostEqual(recovered / normal, 1, delta=0.1)
            self.assertLess(rms(0, 0.01), normal * 0.6)


if __name__ == '__main__':
    unittest.main()
