#!/usr/bin/env bash
# usage.sh — example invocations of the html-toc-index skill.
set -euo pipefail

B="$HOME/.config/freebuff/skills/html-toc-index/scripts/build_toc_index.py"

# 1) Preview: scan and plan, write nothing.
python3 "$B" ~/docs -o ~/site --dry-run

# 2) Rebuild the index for a flat directory of documents.
python3 "$B" ~/docs -o ~/site

# 3) Recursive scan, skip files matching a regex, and inject a per-document TOC.
python3 "$B" ~/docs -o ~/site --recursive --exclude-pattern '-email' --inject-doc-toc

# 4) Incremental rebuild (skip unchanged, prune stale), plus JSON/Markdown/TXT exports.
python3 "$B" ~/docs -o ~/site --incremental --export-json --export-markdown --export-txt

# 5) Machine-readable report to stdout.
python3 "$B" ~/docs -o ~/site --json | python3 -m json.tool

# 6) Custom place dictionary for tag generation.
python3 "$B" ~/docs -o ~/site --places-file examples/places.example.txt
