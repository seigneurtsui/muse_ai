from __future__ import annotations
import json
from pathlib import Path
import os
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import md2html_toc as app


class MarkdownTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        self.input = self.root / "docs"
        self.input.mkdir()
        self.output = self.root / "site"

    def write(self, name, text):
        path = self.input / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        return path

    def args(self, *extra):
        return app.parser().parse_args([str(self.input), str(self.output), *extra])

    def test_default_sanitization_removes_script_javascript_and_event_attributes(self):
        self.write(
            "unsafe.md",
            '# Hello\n\n<script>alert(1)</script><div onclick="evil()">safe</div>\n\n[bad](javascript:alert(1))\n',
        )
        result = app.batch(self.args())
        self.assertEqual(
            result["summary"], {"total": 1, "success": 1, "skipped": 0, "failed": 0}
        )
        html = (self.output / "unsafe.html").read_text()
        self.assertNotIn("<script", html.lower())
        self.assertNotIn("onclick", html.lower())
        self.assertNotIn("javascript:", html.lower())
        self.assertIn("Hello", html)

    def test_explicit_unsafe_mode_preserves_raw_html_but_is_documented_behavior(self):
        self.write("trusted.md", '<span data-x="1">Trusted</span>')
        result = app.batch(self.args("--unsafe-raw-html"))
        self.assertEqual(result["summary"]["success"], 1)
        html = (self.output / "trusted.html").read_text()
        self.assertIn('<span data-x="1">Trusted</span>', html)

    def test_toc_ids_are_unique_escaped_and_include_heading_levels(self):
        self.write("toc.md", "# Title <x>\n\n## Same\n\n### Same\n\n## Same\n")
        app.batch(self.args())
        html = (self.output / "toc.html").read_text()
        self.assertIn('data-md-toc="1"', html)
        self.assertIn('href="#title-x"', html)
        self.assertIn('href="#same"', html)
        self.assertIn('href="#same-2"', html)
        self.assertIn('href="#same-3"', html)
        self.assertEqual(html.count('id="same"'), 1)

    def test_markdown_table_code_fence_and_internal_markdown_link(self):
        self.write(
            "guide.md",
            '# Guide\n\n## Table\n\n| A | B |\n|---|---|\n| 1 | 2 |\n\n```python\nprint("<x>")\n```\n\n[Next](next.md#part)',
        )
        app.batch(self.args())
        html = (self.output / "guide.html").read_text()
        self.assertIn('class="table-wrap"', html)
        self.assertIn('<pre><code class="language-python">', html)
        self.assertIn("print(&quot;&lt;x&gt;&quot;)", html)
        self.assertIn('href="next.html#part"', html)

    def test_external_links_get_safe_target_and_rel(self):
        self.write(
            "links.md", "[site](https://example.com/a) [mail](mailto:a@example.com)"
        )
        app.batch(self.args())
        html = (self.output / "links.html").read_text()
        self.assertIn('target="_blank"', html)
        self.assertIn('rel="noopener noreferrer"', html)
        self.assertIn("mailto:a@example.com", html)

    def test_front_matter_title_is_used_and_not_rendered(self):
        self.write(
            "meta.md", "---\ntitle: Custom & Title\nauthor: Test\n---\n\n## Body\n"
        )
        app.batch(self.args())
        html = (self.output / "meta.html").read_text()
        self.assertIn("<title>Custom &amp; Title</title>", html)
        self.assertNotIn("<p>title:", html)

    def test_recursive_layout_and_hidden_links_are_skipped(self):
        self.write("nested/a.md", "# A")
        self.write("nested/b.markdown", "# B")
        self.write(".hidden.md", "# Hidden")
        (self.input / "link.md").symlink_to(self.input / "nested/a.md")
        result = app.batch(self.args("-r"))
        self.assertEqual(result["summary"]["total"], 2)
        self.assertTrue((self.output / "nested/a.html").is_file())
        self.assertTrue((self.output / "nested/b.html").is_file())
        self.assertFalse((self.output / ".hidden.html").exists())

    def test_dry_run_has_no_output_or_report(self):
        self.write("a.md", "# A")
        result = app.batch(self.args("--dry-run"))
        self.assertEqual(result["status"], "dry_run")
        self.assertFalse(self.output.exists())
        self.assertFalse(list(self.root.rglob("conversion_report.json")))

    def test_same_stem_collision_is_rejected_before_writes(self):
        self.write("same.md", "# one")
        self.write("same.markdown", "# two")
        with self.assertRaisesRegex(app.ConversionError, "output_collision"):
            app.batch(self.args())
        self.assertFalse(self.output.exists())

    def test_existing_output_skips_without_rewrite_then_overwrite(self):
        source = self.write("a.md", "# First")
        first = app.batch(self.args())
        output = self.output / "a.html"
        mtime = output.stat().st_mtime_ns
        source.write_text("# Second")
        second = app.batch(self.args())
        self.assertEqual(second["summary"]["skipped"], 1)
        self.assertEqual(output.stat().st_mtime_ns, mtime)
        self.assertIn("First", output.read_text())
        third = app.batch(self.args("--overwrite"))
        self.assertEqual(third["summary"]["success"], 1)
        self.assertIn("Second", output.read_text())

    def test_copy_assets_hashes_and_confines_to_input_tree(self):
        self.write("chapter/a.md", "![inside](pic.png) ![outside](../../outside.png)")
        (self.input / "chapter" / "pic.png").write_bytes(b"inside")
        (self.root / "outside.png").write_bytes(b"outside")
        result = app.batch(self.args("-r", "--copy-assets"))
        self.assertEqual(result["summary"]["success"], 1)
        html = (self.output / "chapter/a.html").read_text()
        self.assertIn("assets/pic-", html)
        self.assertNotIn("assets/outside-", html)
        self.assertEqual(
            len(list((self.output / "chapter" / "assets").glob("pic-*"))), 1
        )

    def test_input_output_overlap_and_link_output_fail_closed(self):
        self.write("a.md", "# A")
        with self.assertRaisesRegex(app.ConversionError, "input_output_overlap"):
            app.batch(
                app.parser().parse_args([str(self.input), str(self.input / "site")])
            )
        self.output.symlink_to(self.root)
        with self.assertRaisesRegex(app.ConversionError, "directory_is_link"):
            app.batch(self.args())

    def test_invalid_encoding_and_report_contains_no_body(self):
        path = self.input / "bad.md"
        path.write_bytes(b"\xff\xfe\x00")
        result = app.batch(self.args())
        self.assertEqual(result["summary"]["failed"], 1)
        report = (self.output / "conversion_report.json").read_text()
        self.assertNotIn("\\xff", report)
        self.assertIn("text_decode_failed", report)
        self.assertNotIn("bad", "")

    def test_asset_and_output_are_atomic_targets(self):
        self.write("a.md", "# A")
        original = app.atomic_write

        def fail(path, raw):
            if Path(path).name == "a.html":
                raise OSError("fixture output failure")
            return original(path, raw)

        with patch.object(app, "atomic_write", side_effect=fail):
            result = app.batch(self.args())
        self.assertEqual(result["summary"]["failed"], 1)
        self.assertFalse((self.output / "a.html").exists())

    def test_cli_help_and_real_synthetic_subprocess(self):
        script = Path(app.__file__)
        help_result = subprocess.run(
            [sys.executable, "-B", str(script), "--help"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("--copy-assets", help_result.stdout)
        self.write("cli.md", "# CLI")
        result = subprocess.run(
            [
                sys.executable,
                "-B",
                str(script),
                str(self.input),
                str(self.output),
                "--json",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["summary"]["success"], 1)

    def test_limits_and_dependency_failure_codes(self):
        self.write("a.md", "# A")
        with patch.object(app, "MAX_FILES", 0), self.assertRaisesRegex(
            app.ConversionError, "directory_entry_limit"
        ):
            app.batch(self.args())
        with patch.dict(sys.modules, {"markdown": None}):
            result = app.batch(self.args("--overwrite"))
        self.assertEqual(result["summary"]["failed"], 1)
        self.assertEqual(result["files"][0]["reason"], "markdown_dependency_missing")


if __name__ == "__main__":
    unittest.main()
