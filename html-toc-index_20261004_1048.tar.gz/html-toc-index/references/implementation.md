# 实现与安全边界

## 架构

1. **路径校验** `_validate_paths`：输入必须存在；输出不得等于输入或位于输入内部
   （`output_equals_input` / `output_within_input`），避免把生成的 HTML 再次当作源扫描。
2. **扫描** `scan_files`：`*.html`（可 `--recursive` 递归），排除 `index.html`、符号链接、
   非普通文件与命中 `--exclude-pattern` 的文件名；结果按文件名稳定排序。
3. **处理** `process_file`：提取标题、摘要、字数、日期（文件名时间戳 → 正文日期 → mtime）、
   标签与 `doc_id`；`--inject-doc-toc` 时调用 `inject_doc_toc` 生成带目录的正文。
   `build_records` 在有界线程池（`--jobs`）中并行处理，结果按 `(date_sort, title)` 稳定排序。
4. **写入**：
   - `full_update`：对每篇文档写 `doc-<id>/index.html`；
   - `incremental_update`：内容未变则跳过、不在集合中的 `doc-*` 目录删除、变更的原子重写；
   - `clean_output`：非增量模式下只删除本工具拥有的产物（`doc-*` 与 `index.html`/`data.json`/
     `INDEX.md`/`file_list.txt`），保留目录内其他文件。
   全部使用 `write_atomic`（临时文件 + `fsync` + `os.replace`）。
5. **索引页** `render_index`：以内联 `DATA` 与 `__TOKEN__` 替换生成单文件 `index.html`。
6. **导出/报告**：`export_json`/`export_markdown`/`export_txt` 与 `run()` 汇总的 JSON 报告。

## 关键策略

- **doc_id**：`sha256(文件名 + 原始内容)[:6]`，与源脚本一致。内容变化 → 新 id → 新目录，
  旧目录由增量模式清理。这是一个有意的取舍（稳定性 vs 内容寻址）；文档中已说明。
- **日期来源**：文件名时间戳优先，其次正文日期正则，最后文件 mtime；报告记录 `date_source`。
- **标签**：内置城市词典 → `email 版` → 2–4 字候选词回退 → `未分类`。`--places-file` 提供时
  替换内置词典（不是叠加）。
- **文档内目录注入**：`inject_doc_toc` 用一次 `re.sub` 遍历 H1–H6，为缺 id 的标题生成唯一
  锚点（重复标题自动加 `-1`/`-2`），收集 H1–H3 条目；少于 `min_headings`(2) 时**返回原文**。
  以 `data-doc-toc="1"` 标记幂等；目录块插入 `<body>` 开标签之后（无 `<body>` 时前置）。
- **argv 规范化**：`_normalize_argv` 把 `--exclude-pattern '-email'` 这类「值以 `-` 开头」的
  长选项改写为 `--exclude-pattern=-email`，绕开 argparse 把值误判为选项的问题。

## 性能设计

- **有界并行**：`--jobs`（默认 auto，上限 8；文件数 > 5 时启用）让多文档解析重叠进行。
  解析是 CPU/IO 混合且以读取小文件为主，线程池足够。
- **增量**：`--incremental` 只重写内容变化的文档，并清理过期目录。
- **原子写**：避免半成品；崩溃后重跑可恢复。
- **单文件索引**：内联 CSS/JS 与数据，无外部请求，索引页加载零依赖。

## 安全边界

- 只读取用户明确指定的输入目录；不扫描家目录/Downloads。
- 输出目录不得等于或位于输入目录内部，防止自反馈扫描。
- 不联网、不上传、不发送通知、不访问密钥/账户、不创建后台任务。
- 输入内容按数据处理，不执行其中的脚本或指令。
- `--inject-doc-toc` 会向文档注入一段本地目录脚本；这是明确选择的行为，文档中已提示对
  不可信文档需谨慎。

## 与源脚本的差异

| 方面 | `/tmp/build_toc_index.py` | 本技能 |
|---|---|---|
| 依赖 | 标准库 | 标准库（保持一致） |
| 索引装配 | `str.format` + `{{`/`}}` 转义 | `__TOKEN__` 替换，无花括号转义风险 |
| 写入 | 直接 `write_text` | 原子写（临时文件 + `os.replace`） |
| 非增量清理 | `shutil.rmtree(输出目录)`（会删除目录内一切） | 只删除本工具拥有的产物 |
| 并行 | `--workers`（默认 8） | `--jobs auto`（上限 8） + `--no-parallel` |
| 报告 | 仅日志 | `--json` / `--report`（结构化） |
| 输出边界 | 无校验 | 拒绝 output==input / output 在 input 内 |
| 文档级目录 | 无 | `--inject-doc-toc`（稳定锚点 + 浮动目录，幂等） |
| 参数健壮性 | `--exclude-pattern '-email'` 会被 argparse 误判 | `_normalize_argv` 修正 |
| 退出码 | 0/1 | 0 / 2（partial_failure）/ 1 |

## 尚未实现

- 稳定的文档 URL（可选按文件名而非内容哈希，以在内容更新时保持链接不变）。
- 索引页的服务端预渲染/分页（当前为纯前端）。
- 多输入目录/多语言词典合并（当前单输入目录、单词典）。
