#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Batch-embed a self-contained table of contents into HTML documents.

Adapted from the supplied ``/tmp/batch_add_toc.py`` (the rainman-travel
"fix batch TOC / mobile" tool). It keeps that script's proven behaviour — strip
any previous injection, ensure a viewport meta, wrap tables for horizontal
scrolling, inject a stable desktop/mobile CSS layer, give every H2/H3 heading a
unique id, insert a fixed, collapsible TOC aside with a reading-progress bar,
and add an interaction script (collapse persistence + active-heading
highlight) — but hardens and generalises it:

* every injected artefact carries an explicit marker, so removal is exact and
  re-running over already-processed HTML is idempotent (no duplicated
  CSS / TOC / script, no nested table wrappers);
* atomic writes use a unique temp file + ``fsync`` + ``os.replace``;
* bounded parallelism (``--jobs``) and a deterministic file order;
* ``--incremental`` skips documents whose output would be unchanged;
* ``--in-place`` (opt-in) rewrites the source files; by default output goes to a
  separate directory, and output may not equal or live inside the input;
* configurable heading levels (``--levels``), minimum heading count, and an
  opt-out for table wrapping;
* JSON report (``--json`` / ``--report``), ``--dry-run`` and exit codes;
* dependency-free (standard library only).

Examples:
    batch_add_toc.py ./docs ./site
    batch_add_toc.py ./docs -o ./site --recursive
    batch_add_toc.py ./docs ./site --levels 2,3,4 --min-headings 3
    batch_add_toc.py ./docs --in-place
    batch_add_toc.py ./docs ./site --dry-run --json
"""

from __future__ import annotations

import argparse
import concurrent.futures
import html as html_module
import json
import logging
import os
import re
import sys
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

VERSION = "1.0.0"
DEFAULT_OUTPUT_DIR = Path.home() / "Downloads" / "html_toc_silo"
DEFAULT_JOBS_CAP = 8
PARALLEL_THRESHOLD = 4
DEFAULT_LEVELS = (2, 3)
MAX_WARNING_CHARS = 400

# Injection markers. ``TOC_MARKER`` matches the source tool's output so its
# previous injections are still cleaned up.
TOC_MARKER = 'data-rainman-toc="1"'
SCRIPT_MARKER = 'data-rainman-toc-script="1"'
STYLE_START = "/* rainman-toc-embed:start */"
STYLE_END = "/* rainman-toc-embed:end */"
# HTML comment markers delimit the injected TOC + script tail so removal is
# exact and re-running on already-processed HTML is byte-for-byte idempotent.
TOC_BLOCK_START = "<!--rainman-toc-embed:start-->"
TOC_BLOCK_END = "<!--rainman-toc-embed:end-->"

log = logging.getLogger("html-toc-embed")


class TocError(Exception):
    """Error carrying a short, log-safe reason code."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def reason(error: BaseException) -> str:
    code = getattr(error, "code", "")
    if isinstance(code, str) and re.fullmatch(r"[a-z][a-z0-9_]{0,79}", code):
        return code
    return "unexpected_error"


# --------------------------------------------------------------------------
# Injected CSS (kept from the source; wrapped in removal markers)
# --------------------------------------------------------------------------

BASE_CSS = r"""
/* Rainman TOC fixed layer */
:root {
  --rainman-text: #1e293b;
  --rainman-muted: #64748b;
  --rainman-surface: #ffffff;
  --rainman-border: #cbd5e1;
  --rainman-accent: #2563eb;
  --rainman-accent-light: #dbeafe;
}

html {
  scroll-behavior: smooth;
  -webkit-text-size-adjust: 100%;
  text-size-adjust: 100%;
}

body { overflow-x: hidden; }
img, video, iframe, svg { max-width: 100%; height: auto; }

.rainman-toc {
  position: fixed;
  z-index: 9998;
  top: 96px;
  left: max(20px, calc(50% - 700px));
  width: 250px;
  max-height: calc(100vh - 126px);
  overflow: hidden;
  color: #fff;
  background: linear-gradient(145deg, #172554, #1e1b4b 52%, #312e81);
  border: 1px solid rgba(255,255,255,.22);
  border-radius: 16px;
  box-shadow: 0 12px 34px rgba(15,23,42,.35);
  transform: translateX(-100px);
}

.rainman-toc-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 54px;
  padding: 0 14px;
  color: #fff;
  background: rgba(255,255,255,.09);
  border-bottom: 1px solid rgba(255,255,255,.18);
}

.rainman-toc-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 15px;
  font-weight: 700;
}

.rainman-toc-toggle {
  width: 32px;
  height: 32px;
  padding: 0;
  color: #fff;
  font-size: 20px;
  line-height: 1;
  background: rgba(255,255,255,.1);
  border: 1px solid rgba(255,255,255,.35);
  border-radius: 8px;
  cursor: pointer;
}

.rainman-toc-progress { padding: 12px 14px; border-bottom: 1px solid rgba(255,255,255,.18); }
.rainman-toc-progress-row { display: flex; justify-content: space-between; margin-bottom: 7px; color: rgba(255,255,255,.85); font-size: 11px; }
.rainman-toc-progress-track { height: 5px; overflow: hidden; background: rgba(255,255,255,.2); border-radius: 999px; }
.rainman-toc-progress-bar { width: 0; height: 100%; background: linear-gradient(90deg,#93c5fd,#c4b5fd); border-radius: inherit; }

.rainman-toc-nav {
  max-height: calc(100vh - 250px);
  padding: 10px 9px 14px;
  overflow-y: auto;
  scrollbar-width: thin;
  scrollbar-color: rgba(255,255,255,.4) transparent;
}
.rainman-toc-nav a {
  position: relative;
  display: block;
  margin: 2px 0;
  padding: 7px 8px 7px 14px;
  color: rgba(255,255,255,.84);
  font-size: 13px;
  line-height: 1.5;
  text-decoration: none;
  border-radius: 8px;
}
.rainman-toc-nav a::before { position: absolute; top: 8px; bottom: 8px; left: 3px; width: 3px; content: ""; border-radius: 999px; }
.rainman-toc-nav a:hover, .rainman-toc-nav a.active { color: #fff; background: rgba(147,197,253,.25); }
.rainman-toc-nav a.active { font-weight: 700; }
.rainman-toc-nav a.active::before { background: #bfdbfe; }
.rainman-toc-nav .rainman-toc-h3 { padding-left: 26px; font-size: 12px; color: rgba(255,255,255,.74); }
.rainman-toc-nav .rainman-toc-h4 { padding-left: 38px; font-size: 12px; color: rgba(255,255,255,.66); }

.rainman-toc.is-collapsed { width: 190px; max-height: 54px; }
.rainman-toc.is-collapsed .rainman-toc-progress,
.rainman-toc.is-collapsed .rainman-toc-nav { display: none; }

.rainman-table-wrapper {
  width: 100%;
  overflow-x: auto;
  margin: 1.5rem 0;
  border: 1px solid #cbd5e1;
  border-radius: 10px;
  -webkit-overflow-scrolling: touch;
  overscroll-behavior-x: contain;
}
.rainman-table-wrapper table { width: max-content; min-width: 100%; border-collapse: collapse !important; border-spacing: 0 !important; }
.rainman-table-wrapper th, .rainman-table-wrapper td { border: 1px solid #64748b !important; }

@media (min-width: 1100px) {
  .container.content { margin-left: calc(50% - 180px) !important; }
}

@media (max-width: 1099px) {
  .rainman-toc {
    position: relative;
    top: auto;
    left: auto;
    width: 100%;
    max-width: 100%;
    max-height: none;
    margin: 0 auto 1.25rem;
    border-radius: 12px;
    transform: none !important;
  }
  .rainman-toc-nav { max-height: 280px; -webkit-overflow-scrolling: touch; }
  .container.content { width: 100% !important; max-width: 100% !important; margin: 0 auto !important; }
}

@media (max-width: 700px) {
  body { padding: .65rem .4rem !important; }
  .container, .container.content { width: 100% !important; padding: 1.15rem .85rem 3rem !important; border-radius: 10px !important; }
  h1 { font-size: 1.65rem !important; line-height: 1.3 !important; overflow-wrap: anywhere; }
  h2 { font-size: 1.35rem !important; line-height: 1.4 !important; }
  h3 { font-size: 1.12rem !important; }
  p, li { font-size: .96rem; line-height: 1.72; }
  pre { max-width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch; font-size: .8rem; }
  img { max-width: 100% !important; height: auto !important; }
  .rainman-toc-header { min-height: 48px; }
  .rainman-toc-toggle { width: 34px; height: 34px; }
  .rainman-toc-nav a { padding: .55rem .5rem .55rem .75rem; font-size: .82rem; }
  .rainman-toc-nav .rainman-toc-h3 { padding-left: 1.35rem; }
  .rainman-table-wrapper { margin: 1rem 0; }
  .rainman-table-wrapper table { min-width: 460px; font-size: .8rem; }
  .rainman-table-wrapper th, .rainman-table-wrapper td { padding: .55rem .65rem; }
}

@media (max-width: 380px) {
  .container, .container.content { padding-left: .7rem !important; padding-right: .7rem !important; }
  h1 { font-size: 1.45rem !important; }
  p, li { font-size: .92rem; }
}

@media (prefers-reduced-motion: reduce) {
  html { scroll-behavior: auto; }
  *, *::before, *::after { transition: none !important; animation: none !important; }
}
"""


# --------------------------------------------------------------------------
# Injected interaction script (kept from the source; tagged for exact removal)
# --------------------------------------------------------------------------

SCRIPT = r"""<script data-rainman-toc-script="1">
(function () {
  const toc = document.querySelector('[data-rainman-toc="1"]');
  if (!toc) return;

  const toggle = toc.querySelector('.rainman-toc-toggle');
  const bar = toc.querySelector('.rainman-toc-progress-bar');
  const text = toc.querySelector('.rainman-toc-progress-text');
  const links = Array.from(toc.querySelectorAll('a[data-target]'));
  const key = 'rainman-toc-collapsed';

  function setCollapsed(value) {
    toc.classList.toggle('is-collapsed', value);
    if (toggle) {
      toggle.textContent = value ? '+' : '−';
      toggle.setAttribute('aria-expanded', String(!value));
      toggle.setAttribute('aria-label', value ? '展开目录' : '折叠目录');
    }
    try { localStorage.setItem(key, value ? '1' : '0'); } catch (_) {}
  }

  if (toggle) toggle.addEventListener('click', function () {
    setCollapsed(!toc.classList.contains('is-collapsed'));
  });

  try { if (localStorage.getItem(key) === '1') setCollapsed(true); } catch (_) {}

  function updateProgress() {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    const value = max > 0 ? Math.round((window.scrollY / max) * 100) : 0;
    const percent = Math.max(0, Math.min(100, value));
    if (bar) bar.style.width = percent + '%';
    if (text) text.textContent = percent + '%';
  }
  window.addEventListener('scroll', updateProgress, { passive: true });
  window.addEventListener('resize', updateProgress);
  updateProgress();

  const map = new Map();
  links.forEach(function (link) {
    const target = document.getElementById(link.dataset.target);
    if (target) map.set(target, link);
    link.addEventListener('click', function () {
      links.forEach(function (item) { item.classList.remove('active'); });
      link.classList.add('active');
    });
  });

  if ('IntersectionObserver' in window && map.size) {
    const observer = new IntersectionObserver(function (entries) {
      const visible = entries.filter(function (entry) { return entry.isIntersecting; })
        .sort(function (a, b) { return a.boundingClientRect.top - b.boundingClientRect.top; })[0];
      if (!visible) return;
      const link = map.get(visible.target);
      if (!link) return;
      links.forEach(function (item) { item.classList.remove('active'); });
      link.classList.add('active');
      if (!toc.classList.contains('is-collapsed')) link.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }, { rootMargin: '-80px 0px -65% 0px', threshold: [0, 1] });
    map.forEach(function (_, heading) { observer.observe(heading); });
  }
})();
</script>"""


# --------------------------------------------------------------------------
# HTML transforms
# --------------------------------------------------------------------------


def strip_injections(source: str) -> str:
    """Remove every artefact this tool (or the source tool) may have injected."""  # Remove our marked TOC + script tail (and the single newline we add after
    # it); nothing before the marker is touched, so re-runs stay idempotent.
    source = re.sub(
        re.escape(TOC_BLOCK_START) + r".*?" + re.escape(TOC_BLOCK_END) + r"\n?",
        "",
        source,
        flags=re.DOTALL,
    )
    # Remove any <style> element we created when the document had none.
    source = re.sub(
        r'<style\b[^>]*data-rainman-toc-style="1"[^>]*>.*?</style>\n?',
        "",
        source,
        flags=re.IGNORECASE | re.DOTALL,
    )
    source = re.sub(
        r'<aside\b[^>]*data-rainman-toc="1"[^>]*>.*?</aside>',
        "",
        source,
        flags=re.IGNORECASE | re.DOTALL,
    )
    source = re.sub(
        r'<script\b[^>]*data-rainman-toc-script="1"[^>]*>.*?</script>',
        "",
        source,
        flags=re.IGNORECASE | re.DOTALL,
    )
    # Legacy script forms emitted by the source tool (no marker attribute).
    source = re.sub(
        r"<script>\s*\(function\(\)\{\s*const toc=document\.querySelector\('\[data-rainman-toc=\"1\"\]'\).*?</script>",
        "",
        source,
        flags=re.IGNORECASE | re.DOTALL,
    )
    source = re.sub(
        r"<script>\s*\(\(\) => \{\s*const toc = document\.querySelector\('\[data-rainman-toc=\"1\"\]'\).*?</script>",
        "",
        source,
        flags=re.IGNORECASE | re.DOTALL,
    )
    # Our CSS between markers (including the whitespace it added).
    source = re.sub(
        r"\n?" + re.escape(STYLE_START) + r".*?" + re.escape(STYLE_END) + r"\n?",
        "",
        source,
        flags=re.DOTALL,
    )
    source = re.sub(
        r"/\* Rainman TOC fixed layer \*/.*?(?=</style>)",
        "",
        source,
        flags=re.IGNORECASE | re.DOTALL,
    )
    source = re.sub(
        r"/\* Rainman mobile adaptation layer \*/.*?(?=</style>)",
        "",
        source,
        flags=re.IGNORECASE | re.DOTALL,
    )
    # Unwrap previously wrapped tables so re-running does not nest wrappers.
    source = re.sub(
        r'<div\b[^>]*class="rainman-table-wrapper"[^>]*>\s*(<table\b.*?</table>)\s*</div>',
        r"\1",
        source,
        flags=re.IGNORECASE | re.DOTALL,
    )
    return source


def add_viewport(source: str) -> str:
    if re.search(r'<meta\s+name=["\']viewport["\']', source, re.IGNORECASE):
        return source
    meta = '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">'
    if re.search(r"</head>", source, re.IGNORECASE):
        return re.sub(
            r"</head>", f"  {meta}\n</head>", source, count=1, flags=re.IGNORECASE
        )
    return meta + source


def add_table_wrappers(source: str) -> tuple[str, int]:
    count = 0

    def replace(match: "re.Match[str]") -> str:
        nonlocal count
        full = match.group(0)
        attrs = match.group("attrs") or ""
        body = match.group("body")
        if not re.search(r"\bclass=", attrs, re.IGNORECASE):
            attrs += ' class="rainman-table"'
        elif "rainman-table" not in attrs:
            attrs = re.sub(
                r'(\bclass=["\'])([^"\']*)',
                r"\1\2 rainman-table",
                attrs,
                count=1,
                flags=re.IGNORECASE,
            )
        count += 1
        return f'<div class="rainman-table-wrapper" data-rainman-table="1"><table{attrs}>{body}</table></div>'

    source = re.sub(
        r'<div\s+class="table-wrapper"[^>]*>\s*',
        '<div class="rainman-table-wrapper" data-rainman-table="1">',
        source,
        flags=re.IGNORECASE,
    )
    pattern = re.compile(
        r"<table(?P<attrs>[^>]*)>(?P<body>.*?)</table>", re.IGNORECASE | re.DOTALL
    )
    source = pattern.sub(replace, source)
    return source, count


def inject_css(source: str) -> str:
    block = f"{STYLE_START}\n{BASE_CSS}\n{STYLE_END}"
    if re.search(r"</style>", source, re.IGNORECASE):
        return re.sub(
            r"</style>", f"\n{block}\n</style>", source, count=1, flags=re.IGNORECASE
        )
    tag = f'<style data-rainman-toc-style="1">\n{block}\n</style>'
    if re.search(r"</head>", source, re.IGNORECASE):
        return re.sub(
            r"</head>", tag + "\n</head>", source, count=1, flags=re.IGNORECASE
        )
    return tag + "\n" + source


def normalize_heading_levels(levels: Any) -> tuple[int, ...]:
    if levels is None:
        return DEFAULT_LEVELS
    if isinstance(levels, str):
        parts = [p for p in re.split(r"[,\s]+", levels) if p]
    else:
        parts = list(levels)
    parsed = set()
    for part in parts:
        try:
            value = int(part)
        except (TypeError, ValueError):
            raise TocError("invalid_levels") from None
        if value < 1 or value > 6:
            raise TocError("invalid_levels")
        parsed.add(value)
    if not parsed:
        raise TocError("invalid_levels")
    return tuple(sorted(parsed))


def _toc_aside(items: list[dict[str, Any]], toc_title: str) -> str:
    links = []
    for item in items:
        cls = f"rainman-toc-h{item['level']}"
        anchor = html_module.escape(item["id"], quote=True)
        title = html_module.escape(item["title"])
        links.append(
            f'<a class="{cls}" href="#{anchor}" data-target="{anchor}">{title}</a>'
        )
    title_html = html_module.escape(toc_title)
    return (
        f'<aside class="rainman-toc" data-rainman-toc="1">\n'
        f'  <div class="rainman-toc-header"><div class="rainman-toc-title">'
        f"<span>📑</span><span>{title_html}</span></div>"
        f'<button class="rainman-toc-toggle" type="button" aria-label="折叠目录" '
        f'aria-expanded="true">−</button></div>\n'
        f'  <div class="rainman-toc-progress"><div class="rainman-toc-progress-row">'
        f'<span>阅读进度</span><span class="rainman-toc-progress-text">0%</span></div>'
        f'<div class="rainman-toc-progress-track"><div class="rainman-toc-progress-bar"></div></div></div>\n'
        f'  <nav class="rainman-toc-nav" aria-label="文档目录">{"".join(links)}</nav>\n'
        f"</aside>"
    )


def process_html(
    source: str,
    *,
    levels: tuple[int, ...] = DEFAULT_LEVELS,
    min_headings: int = 1,
    wrap_tables: bool = True,
    toc_title: str = "目录导航",
) -> tuple[str, dict[str, Any]]:
    result = add_viewport(strip_injections(source))
    tables = 0
    if wrap_tables:
        result, tables = add_table_wrappers(result)
    result = inject_css(result)

    items: list[dict[str, Any]] = []
    used_ids = set(re.findall(r'\bid=["\']([^"\']+)["\']', result, re.IGNORECASE))
    index = 0
    level_chars = "".join(str(level) for level in levels)
    heading_pattern = re.compile(
        rf"<h([{level_chars}])(?P<attrs>[^>]*)>(?P<body>.*?)</h\1>",
        re.IGNORECASE | re.DOTALL,
    )

    def heading_replace(match: "re.Match[str]") -> str:
        nonlocal index
        level = int(match.group(1))
        attrs = match.group("attrs") or ""
        body = match.group("body")
        existing = re.search(r'\bid=["\']([^"\']+)["\']', attrs, re.IGNORECASE)
        if existing:
            heading_id = existing.group(1)
        else:
            index += 1
            heading_id = f"rainman-section-{index}"
            while heading_id in used_ids:
                index += 1
                heading_id = f"rainman-section-{index}"
            used_ids.add(heading_id)
            attrs += f' id="{heading_id}"'
        title = re.sub(r"<[^>]+>", "", body)
        title = re.sub(r"\s+", " ", title).strip()
        if title:
            items.append({"level": level, "id": heading_id, "title": title})
        return f"<h{level}{attrs}>{body}</h{level}>"

    result = heading_pattern.sub(heading_replace, result)

    meta = {"headings": len(items), "toc_items": 0, "tables": tables}
    if len(items) < max(1, min_headings):
        return result, meta

    toc = _toc_aside(items, toc_title)
    tail = f"{TOC_BLOCK_START}\n{toc}\n{SCRIPT}\n{TOC_BLOCK_END}"
    if re.search(r"</body>", result, re.IGNORECASE):
        result = re.sub(
            r"</body>", tail + "\n</body>", result, count=1, flags=re.IGNORECASE
        )
    else:
        result += tail + "\n"
    meta["toc_items"] = len(items)
    return result, meta


# --------------------------------------------------------------------------
# File IO and batch
# --------------------------------------------------------------------------


def write_atomic(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle_fd, temp_name = tempfile.mkstemp(
        prefix=".toc-", suffix=".tmp", dir=path.parent
    )
    temp_path = Path(temp_name)
    try:
        with os.fdopen(handle_fd, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
    finally:
        temp_path.unlink(missing_ok=True)


@dataclass
class Options:
    levels: tuple[int, ...] = DEFAULT_LEVELS
    min_headings: int = 1
    wrap_tables: bool = True
    toc_title: str = "目录导航"
    jobs: int = 1
    incremental: bool = False
    force: bool = False
    dry_run: bool = False


def scan_files(
    input_dir: Path, recursive: bool, exclude_patterns: list[str], output_dir: Path
) -> list[Path]:
    pattern = "**/*.html" if recursive else "*.html"
    files = [
        f
        for f in input_dir.glob(pattern)
        if f.is_file() and not f.is_symlink() and f.suffix.lower() == ".html"
    ]
    if exclude_patterns:
        compiled = [re.compile(p) for p in exclude_patterns]
        files = [f for f in files if not any(r.search(f.name) for r in compiled)]
    # Never re-process files that live inside the output directory (skipped in
    # in-place mode, where the output directory *is* the input directory).
    output_resolved = output_dir.resolve()
    if output_resolved != input_dir.resolve():
        files = [f for f in files if output_resolved not in f.resolve().parents]
    return sorted(files, key=lambda p: str(p).casefold())


def _target_for(
    source_file: Path,
    input_dir: Path,
    output_dir: Path,
    recursive: bool,
    in_place: bool,
) -> Path:
    if in_place:
        return source_file
    if recursive:
        return output_dir / source_file.relative_to(input_dir)
    return output_dir / source_file.name


def process_one(
    source_file: Path,
    input_dir: Path,
    output_dir: Path,
    recursive: bool,
    in_place: bool,
    opts: Options,
) -> dict[str, Any]:
    started = time.perf_counter()
    target = _target_for(source_file, input_dir, output_dir, recursive, in_place)
    record: dict[str, Any] = {
        "source": str(source_file),
        "output": str(target),
        "status": "success",
    }
    try:
        raw = source_file.read_text(encoding="utf-8", errors="replace")
    except OSError:
        record.update(status="failed", reason="read_failed")
        return record

    processed, meta = process_html(
        raw,
        levels=opts.levels,
        min_headings=opts.min_headings,
        wrap_tables=opts.wrap_tables,
        toc_title=opts.toc_title,
    )
    record.update(meta)
    record["bytes"] = len(processed.encode("utf-8"))
    record["elapsed_seconds"] = round(time.perf_counter() - started, 3)

    if opts.dry_run:
        record["status"] = "planned"
        return record

    changed = True
    if target.is_file() and not opts.force:
        try:
            changed = target.read_text(encoding="utf-8", errors="replace") != processed
        except OSError:
            changed = True
    if opts.incremental and not changed:
        record["status"] = "skipped"
        record["reason"] = "unchanged"
        return record

    try:
        write_atomic(target, processed)
    except OSError:
        record.update(status="failed", reason="write_failed")
    return record


def resolve_jobs(requested: Optional[str], count: int) -> int:
    if count <= 0:
        return 1
    if requested in (None, "", "auto"):
        return max(1, min(DEFAULT_JOBS_CAP, count))
    try:
        value = int(requested)
    except (TypeError, ValueError):
        raise TocError("invalid_jobs_value") from None
    return max(1, min(DEFAULT_JOBS_CAP, value, count))


def batch(
    input_dir: Path,
    output_dir: Path,
    recursive: bool,
    in_place: bool,
    exclude_patterns: list[str],
    opts: Options,
) -> dict[str, Any]:
    started = time.perf_counter()
    files = scan_files(input_dir, recursive, exclude_patterns, output_dir)
    if not opts.dry_run:
        output_dir.mkdir(parents=True, exist_ok=True)
    opts.jobs = 1 if opts.jobs <= 0 else min(opts.jobs, max(1, len(files)))

    results: list[dict[str, Any]] = []
    if opts.jobs > 1 and len(files) > PARALLEL_THRESHOLD:
        with concurrent.futures.ThreadPoolExecutor(max_workers=opts.jobs) as pool:
            futures = [
                pool.submit(
                    process_one, f, input_dir, output_dir, recursive, in_place, opts
                )
                for f in files
            ]
            for future in concurrent.futures.as_completed(futures):
                results.append(future.result())
        order = {str(f): i for i, f in enumerate(files)}
        results.sort(key=lambda r: order.get(r["source"], 0))
    else:
        for source_file in files:
            results.append(
                process_one(
                    source_file, input_dir, output_dir, recursive, in_place, opts
                )
            )

    summary = {
        "total": len(results),
        "success": sum(r["status"] in ("success", "planned") for r in results),
        "skipped": sum(r["status"] == "skipped" for r in results),
        "failed": sum(r["status"] == "failed" for r in results),
        "toc_documents": sum(1 for r in results if r.get("toc_items")),
        "headings": sum(r.get("headings", 0) for r in results),
    }
    return {
        "version": VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "input_dir": str(input_dir),
        "output_dir": str(output_dir),
        "recursive": recursive,
        "in_place": in_place,
        "dry_run": opts.dry_run,
        "summary": summary,
        "files": results,
        "elapsed_seconds": round(time.perf_counter() - started, 3),
    }


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

_VALUE_OPTIONS = frozenset(
    {
        "--output",
        "--levels",
        "--min-headings",
        "--toc-title",
        "--jobs",
        "--exclude-pattern",
        "--report",
        "--log-file",
    }
)


def _normalize_argv(argv: Optional[list[str]]) -> list[str]:
    if argv is None:
        argv = sys.argv[1:]
    normalized: list[str] = []
    index = 0
    while index < len(argv):
        token = argv[index]
        if token in _VALUE_OPTIONS and index + 1 < len(argv):
            normalized.append(f"{token}={argv[index + 1]}")
            index += 2
            continue
        normalized.append(token)
        index += 1
    return normalized


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="batch_add_toc.py",
        description="Batch-embed a self-contained TOC (with reading progress) into HTML documents.",
    )
    parser.add_argument("input_dir", help="directory of HTML files")
    parser.add_argument(
        "output_dir",
        nargs="?",
        default=None,
        metavar="OUTPUT_DIR",
        help=f"output directory (default {DEFAULT_OUTPUT_DIR})",
    )
    parser.add_argument(
        "-o",
        "--output",
        default=None,
        help=f"output directory (overrides the positional; default {DEFAULT_OUTPUT_DIR})",
    )
    parser.add_argument(
        "-r", "--recursive", action="store_true", help="recurse and keep structure"
    )
    parser.add_argument(
        "--in-place", action="store_true", help="rewrite source files atomically"
    )
    parser.add_argument(
        "--levels", default="2,3", help="heading levels included (default 2,3)"
    )
    parser.add_argument(
        "--min-headings", type=int, default=1, help="skip TOC below this many headings"
    )
    parser.add_argument(
        "--no-wrap-tables", action="store_true", help="do not wrap tables"
    )
    parser.add_argument("--toc-title", default="目录导航", help="TOC panel title")
    parser.add_argument(
        "--exclude-pattern",
        action="append",
        default=[],
        help="regex on filename to skip",
    )
    parser.add_argument(
        "--jobs", default="auto", help="parallel workers (default auto, cap 8)"
    )
    parser.add_argument(
        "--incremental",
        action="store_true",
        help="skip documents whose output is unchanged",
    )
    parser.add_argument(
        "--force", action="store_true", help="rewrite even when unchanged"
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="plan only, write nothing"
    )
    parser.add_argument(
        "--json", action="store_true", help="print a JSON report to stdout"
    )
    parser.add_argument("--report", help="also write the JSON report to this file")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--log-file")
    parser.add_argument(
        "-v", "--version", action="version", version=f"%(prog)s {VERSION}"
    )
    return parser


def _validate_paths(input_dir: Path, output_dir: Path, in_place: bool) -> None:
    if not input_dir.is_dir():
        raise TocError("input_not_found")
    if in_place:
        return
    resolved_in = input_dir.resolve()
    resolved_out = output_dir.resolve()
    if resolved_out == resolved_in:
        raise TocError("output_equals_input")
    if resolved_in in resolved_out.parents:
        raise TocError("output_within_input")


def _setup_logging(verbose: bool, log_file: Optional[str]) -> None:
    log.setLevel(logging.DEBUG if verbose else logging.INFO)
    log.handlers.clear()
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(message)s", "%H:%M:%S"
    )
    console = logging.StreamHandler(sys.stderr)
    console.setLevel(logging.DEBUG if verbose else logging.INFO)
    console.setFormatter(formatter)
    log.addHandler(console)
    if log_file:
        path = Path(log_file).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        handler = logging.FileHandler(path, encoding="utf-8")
        handler.setLevel(logging.DEBUG)
        handler.setFormatter(formatter)
        log.addHandler(handler)


def run(args: argparse.Namespace) -> tuple[dict[str, Any], int]:
    input_dir = Path(args.input_dir).expanduser()
    in_place = bool(args.in_place)
    if in_place:
        output_dir = input_dir
    elif args.output:
        output_dir = Path(args.output).expanduser()
    elif args.output_dir:
        output_dir = Path(args.output_dir).expanduser()
    else:
        output_dir = DEFAULT_OUTPUT_DIR
    _validate_paths(input_dir, output_dir, in_place)
    input_dir = input_dir.resolve()
    output_dir = output_dir.resolve()

    levels = normalize_heading_levels(args.levels)
    if args.min_headings < 0:
        raise TocError("invalid_min_headings")
    files_count = len(
        scan_files(
            input_dir, args.recursive, list(args.exclude_pattern or []), output_dir
        )
    )
    jobs = resolve_jobs(args.jobs, files_count)
    opts = Options(
        levels=levels,
        min_headings=args.min_headings,
        wrap_tables=not args.no_wrap_tables,
        toc_title=args.toc_title,
        jobs=jobs,
        incremental=bool(args.incremental),
        force=bool(args.force),
        dry_run=bool(args.dry_run),
    )
    report = batch(
        input_dir,
        output_dir,
        bool(args.recursive),
        in_place,
        list(args.exclude_pattern or []),
        opts,
    )
    failed = report["summary"]["failed"]
    report["status"] = (
        "dry_run" if args.dry_run else ("partial_failure" if failed else "complete")
    )
    code = 0 if args.dry_run else (2 if failed else 0)
    return report, code


def _emit(args: argparse.Namespace, report: dict[str, Any]) -> None:
    if args.report:
        path = Path(args.report).expanduser()
        write_atomic(path, json.dumps(report, ensure_ascii=False, indent=2))
        report["report_path"] = str(path)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))


def _print_summary(report: dict[str, Any]) -> None:
    summary = report["summary"]
    log.info(
        "done: status=%s total=%d success=%d skipped=%d failed=%d toc_docs=%d (%.2fs)",
        report["status"],
        summary["total"],
        summary["success"],
        summary["skipped"],
        summary["failed"],
        summary["toc_documents"],
        report["elapsed_seconds"],
    )
    if not summary["total"]:
        log.warning("no HTML files found under %s", report["input_dir"])


def main(argv: Optional[list[str]] = None) -> int:
    args = build_parser().parse_args(_normalize_argv(argv))
    _setup_logging(args.verbose, args.log_file)
    try:
        report, code = run(args)
    except TocError as error:
        if args.json:
            print(json.dumps({"status": "error", "reason": error.code}))
        else:
            log.error("error: %s", error.code)
        return 1
    except Exception as error:  # noqa: BLE001
        code = reason(error)
        if args.json:
            print(json.dumps({"status": "error", "reason": code}))
        else:
            log.error("error: %s", code)
        return 1
    _emit(args, report)
    if not args.json:
        _print_summary(report)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
