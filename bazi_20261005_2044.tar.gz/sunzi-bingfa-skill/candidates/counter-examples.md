# Stage 1 候选池：反例与失败模式

## C01 无算而动

- 原型：始计“多算胜，少算不胜”。
- 失败：目标、代价、对手、环境、组织都没算清就行动。
- 对应 skill：`temple-calculation`。

## C02 以硬攻为第一选择

- 原型：谋攻“其下攻城”。
- 失败：能通过谋、交、势解决的问题，直接升级为硬碰硬。
- 对应 skill：`win-without-fighting`。

## C03 久战拖垮自己

- 原型：作战“久则钝兵挫锐”。
- 失败：不断追加投入，胜利越来越贵。
- 对应 skill：`short-war-resource-control`。

## C04 以勇代势

- 原型：兵势“求之于势，不责于人”。
- 失败：靠个人拼命弥补系统设计缺陷。
- 对应 skill：`deception-and-shaping`、`command-discipline-control`。

## C05 正面撞强点

- 原型：虚实“避实而击虚”。
- 失败：在对手最强处证明自己，消耗巨大。
- 对应 skill：`void-solid-flexibility`。

## C06 无情报下注

- 原型：用间“先知者，不可取于鬼神”。
- 失败：靠直觉和传闻做重大决策。
- 对应 skill：`know-self-know-enemy`。

## C07 忽略地形

- 原型：地形、九地。
- 失败：同一策略不分市场、组织、渠道、资源环境照搬。
- 对应 skill：`terrain-context-diagnosis`。

## C08 命令不明还怪执行

- 原型：五事中的“法”，以及行军中赏罚和令行问题。
- 失败：战略含糊、角色混乱、赏罚不信，却要求团队高执行。
- 对应 skill：`command-discipline-control`。
