#!/bin/bash
# ============================================================
# backup-travel.sh — 旅行研究备份脚本
#
# 用法:
#   bash backup-travel.sh                    # 从 Vercel 在线下载备份（默认）
#   bash backup-travel.sh ~/my/backups       # 备份到指定目录
#   bash backup-travel.sh --local            # 从本地直接拷贝
#   bash backup-travel.sh --local ~/backups  # 本地模式 + 指定目录
#
# 流程:
#   默认模式：从 https://city.allez.cc.cd/toc/ 下载所有城市研究页面
#   本地模式：从 ~/Downloads/rainman-travel/ 拷贝历史备份
# ============================================================

set -uo pipefail
export LANG=${LANG:-en_US.UTF-8}
export LC_ALL=${LC_ALL:-en_US.UTF-8}

# —— 配置 ——
BASE_DIR="$HOME/Downloads/rainman-travel"
DEFAULT_BACKUP_DIR="$HOME/Downloads/rainman-travel-backups"
PROD_URL="https://city.allez.cc.cd"

# —— 解析参数 ——
MODE="online"
CUSTOM_DIR=""

for arg in "$@"; do
  case "$arg" in
    --local) MODE="local" ;;
    -*) echo "❌ 未知参数: $arg" >&2; exit 1 ;;
    *) CUSTOM_DIR="$arg" ;;
  esac
done

# —— 确定备份目录 ——
if [ -n "$CUSTOM_DIR" ]; then
  BACKUP_DIR="$CUSTOM_DIR"
else
  BACKUP_DIR="$DEFAULT_BACKUP_DIR"
fi

mkdir -p "$BACKUP_DIR"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ "$MODE" = "local" ]; then
  echo "  📁 模式: 本地备份"
  echo "  📂 源目录: $BASE_DIR"
else
  echo "  🌐 模式: Vercel 在线备份"
  echo "  📡 源地址: $PROD_URL/toc/"
fi
echo "  📦 备份目录: $BACKUP_DIR"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# —— 生成时间戳 ——
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
STAGING_DIR="/tmp/rainman-travel-backup-$TIMESTAMP"
mkdir -p "$STAGING_DIR"

# ============================================================
# 本地模式
# ============================================================
if [ "$MODE" = "local" ]; then
  echo ""
  echo "📋 扫描本地文件..."

  # 拷贝 index-*.html 历史备份
  COUNT=0
  for f in "$BASE_DIR"/index-*.html; do
    [ -f "$f" ] || continue
    BASENAME=$(basename "$f")
    [[ "$BASENAME" == *"toc"* ]] && continue
    cp "$f" "$STAGING_DIR/"
    COUNT=$((COUNT + 1))
    echo "  📄 $BASENAME"
  done

  # 拷贝最新的 index.html（如果有）
  if [ -f "$BASE_DIR/index.html" ]; then
    cp "$BASE_DIR/index.html" "$STAGING_DIR/"
    COUNT=$((COUNT + 1))
    echo "  📄 index.html"
  fi

  # 拷贝所有 .md 文件
  for f in "$BASE_DIR"/*.md; do
    [ -f "$f" ] || continue
    cp "$f" "$STAGING_DIR/"
    COUNT=$((COUNT + 1))
    echo "  📝 $(basename "$f")"
  done

  echo ""
  echo "📊 本地备份: $COUNT 个文件"

# ============================================================
# 在线模式（从 Vercel 下载）
# ============================================================
else
  echo ""
  echo "📥 从 Vercel 下载..."

  # 下载目录页
  echo "  📄 下载 /toc/ 目录页..."
  curl -sL "$PROD_URL/toc/" -o "$STAGING_DIR/toc.html" 2>/dev/null

  if [ ! -f "$STAGING_DIR/toc.html" ]; then
    echo "❌ 错误: 无法下载目录页" >&2
    rm -rf "$STAGING_DIR"
    exit 1
  fi

  # 解析目录页，提取所有城市链接
  echo "  🔍 解析城市列表..."
  CITY_URLS=$(grep -oE 'href="/[a-z0-9-]+/"' "$STAGING_DIR/toc.html" | sed 's/href="//' | sed 's/"//' | sort -u)

  COUNT=0
  for CITY_PATH in $CITY_URLS; do
    SLUG=$(echo "$CITY_PATH" | sed 's|^/||' | sed 's|/$||')
    [ -z "$SLUG" ] && continue
    [[ "$SLUG" == "toc" ]] && continue

    echo "  📥 下载 /$SLUG/ ..."
    curl -sL "$PROD_URL/$SLUG/" -o "$STAGING_DIR/$SLUG.html" 2>/dev/null
    if [ -f "$STAGING_DIR/$SLUG.html" ]; then
      SIZE=$(wc -c < "$STAGING_DIR/$SLUG.html")
      if [ "$SIZE" -gt 1000 ]; then
        COUNT=$((COUNT + 1))
        echo "    ✅ $SLUG.html ($SIZE bytes)"
      else
        rm -f "$STAGING_DIR/$SLUG.html"
        echo "    ⚠️  $SLUG.html 太小，跳过"
      fi
    else
      echo "    ❌ 下载失败: $SLUG"
    fi
  done

  echo ""
  echo "📊 在线备份: $COUNT 个城市页面"
fi

# ============================================================
# 生成备份清单
# ============================================================
echo ""
echo "📋 生成备份清单..."

MANIFEST="$STAGING_DIR/MANIFEST.md"
cat > "$MANIFEST" << EOF
# 拉萨旅行研究备份清单

- **备份时间**: $(date '+%Y-%m-%d %H:%M:%S')
- **备份模式**: $([ "$MODE" = "local" ] && echo "本地" || echo "Vercel 在线")
- **文件数量**: $COUNT

## 文件列表

EOF

for f in "$STAGING_DIR"/*; do
  [ -f "$f" ] || continue
  BASENAME=$(basename "$f")
  [ "$BASENAME" = "MANIFEST.md" ] && continue
  SIZE=$(wc -c < "$f")
  MTIME=$(stat -f "%Sm" -t "%Y-%m-%d %H:%M" "$f" 2>/dev/null || echo "unknown")
  echo "- \`$BASENAME\` — $SIZE bytes — $MTIME" >> "$MANIFEST"
done

echo "  ✅ MANIFEST.md 已生成"

# ============================================================
# 压缩打包
# ============================================================
echo ""
echo "📦 压缩打包..."

ARCHIVE_NAME="travel_${TIMESTAMP}.tar.gz"
ARCHIVE_PATH="$BACKUP_DIR/$ARCHIVE_NAME"

cd "$STAGING_DIR"
tar -czf "$ARCHIVE_PATH" . 2>/dev/null
cd - > /dev/null

ARCHIVE_SIZE=$(du -h "$ARCHIVE_PATH" | cut -f1)
echo "  ✅ 已保存: $ARCHIVE_PATH ($ARCHIVE_SIZE)"

# ============================================================
# 清理
# ============================================================
rm -rf "$STAGING_DIR"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🎉 备份完成！"
echo "  📦 文件: $ARCHIVE_PATH"
echo "  📊 大小: $ARCHIVE_SIZE"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
