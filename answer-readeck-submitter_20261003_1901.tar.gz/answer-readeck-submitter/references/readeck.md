# Readeck: temporary HTML capture

## Flow and result meanings

The adapter reuses the supplied `server.js` Markdown renderer and its create payload:
`POST <instance-base>/api/bookmarks` with JSON `{url, title, labels}` and bearer authentication.
It posts **once**. The URL identifies only the selected document's in-memory HTML.
It does not upload files, fetch Markdown images/links, follow API redirects, or log credentials/content.

After a valid create acknowledgment, `await onAccepted({remoteId})` runs **before any polling**.
The caller must durably persist this ID and must not create again on resume, including after capture
failure, poll/auth failure, or interrupted capture. If acknowledgment is missing/invalid or a create
request times out/fails ambiguously, reconcile the remote instance before considering another create.
There is no automatic retry, recapture, deletion, or resume-create operation in this adapter.

- **`submitted`**: an exact-path GET of our HTML completed its server-side response, and a subsequent
  bookmark details response matched the acknowledged ID with `state: 0`, `loaded: true`, and
  `has_article: true`. HEAD alone does not count. This confirms capture signals, not byte-for-byte
  preservation or attribution of the GET to a particular client.
- **`pending_capture`**: the bookmark was accepted, but the required capture signals were not both
  observed before the deadline/poll limit/close, or polling could not establish the result.
  `callbackReceived`, `callbackHeadReceived`, `captureComplete`, and `pollFailed` explain the observed
  signals without exposing the source URL or response body. The temporary listener is already closed;
  a later fetch cannot succeed. Inspect the existing bookmark; do not create a duplicate.
- **Capture failure**: `READECK_CAPTURE_FAILED` for `state: 1`, or `READECK_CAPTURE_NO_ARTICLE` for a
  completed bookmark explicitly lacking an article. These errors include the accepted `remoteId`.
  `loaded: true` is **not** sufficient: Readeck uses it for both successful and failed captures.
- **Create rejection**: explicit HTTP 4xx yields `READECK_CREATE_REJECTED` (`auth: true` for 401/403).
  Network/timeouts, 5xx, redirects/unexpected status, and missing/inconsistent/invalid IDs are uncertain.
  Errors contain fixed codes/messages and safe flags, never raw response bodies, URLs, tokens, or causes.

An ID may come from `Bookmark-Id`, JSON `id`, or a same-origin `Location` whose path is exactly the
configured bookmarks endpoint plus one ID segment. All supplied IDs must agree. IDs allow only
ASCII letters, digits, `_`, and `-`, up to 128 characters. Poll URLs are constructed locally;
returned links are never followed with credentials.

## Callback networking and permission

`callbackUrl` is an explicit, externally reachable **origin** such as `https://capture.example.invalid`
(or its trailing-slash form). Prefix paths, userinfo, queries, fragments, wildcard hosts, port zero,
encoded/dot-segment paths, and non-HTTP(S) schemes are rejected. The advertised URL is never silently
rewritten or replaced with a guessed LAN address.

The local listener is plain HTTP. An HTTPS callback therefore requires an **already configured** TLS
reverse proxy that forwards `/temp/<opaque-id>` unchanged to the configured local `bind`/`port`.
A direct HTTP callback must advertise the reachable listener port (or an intentional NAT mapping).
No tunnels, firewall rules, TLS certificates, or Readeck security settings are created/changed.

`bind` defaults to `127.0.0.1`; `localhost` maps to that address. Otherwise it must be an explicit IPv4
or IPv6 literal (no interface zone). `port` must be an integer 1–65535. A container/server's loopback
is not the submitting computer's loopback. Remote Readeck needs a permitted LAN/public route, and
Readeck's own outbound private-address restrictions may prevent local-network captures. Have the
operator approve/setup appropriate reachability rather than automatically bypassing those restrictions.
The API token needs bookmark creation **and read access** for polling (current OAuth scopes:
`bookmarks:write` and `bookmarks:read`).

Anyone who learns the temporary 192-bit random URL can read the selected HTML while its listener is
active; it is an opaque capability, not client authentication. Approve that temporary exposure before
publishing sensitive content. Prefer loopback behind an existing trusted HTTPS proxy; protect proxy
access logs. The adapter has no directory listing, filesystem routes, credential endpoint, or access log.
Only the exact random `/temp/<id>` accepts GET/HEAD; query/traversal variants are not routes.
Responses use no-store, no-referrer, noindex and a restrictive CSP.

**Temporary source URL limitation:** Readeck keeps this ephemeral URL as the bookmark's original URL.
It stops working when publication finishes, even on success. Captured article content lives in Readeck,
but “visit source” and later refetch will not work. This is not permanent web hosting.

## Interface and bounds

CommonJS export: `createReadeckSession(config) -> Promise<{publish, close}>`.
`publish({title, content, tags}, {onAccepted}?)` returns the status/ID/booleans above.
`close()` is idempotent and permanently closes the session. Sessions support sequential publications;
concurrent `publish` calls are rejected. No listener opens until `publish`, and each publication closes
its listener, destroys callback sockets, clears its timers and discards its page in `finally`.
The optional injected `requestFn` must follow the shared transport contract and honor `timeoutMs`;
an already-started transport request remains subject to its own bounded timeout after `close()`.

Defaults: API request timeout 30 s, capture/persistence deadline 60 s, poll interval 500 ms.
Maximums: request timeout 120 s, capture timeout 300 s, interval 10 s; minimum interval 10 ms.
At most 1,000 read-only polls. The listener additionally has an absolute lifetime of request timeout
plus capture timeout after startup, so a hanging acceptance hook cannot leave it running.
One document at a time: Markdown ≤1 MiB, rendered HTML/API response ≤2 MiB, title ≤1,024 characters,
≤100 labels of ≤128 characters. The listener permits 16 simultaneous connections, 8 KiB headers,
5 s header/request/idle socket timeouts, and at most 256 handled requests per publication.

The handcrafted renderer retains the original headings, paragraphs, flat lists, simple pipe tables,
quotes, fenced/inline code, emphasis and stylesheet. It is **not CommonMark/GFM**: nested constructs,
escapes, reference links, balanced-parenthesis URLs, language identifiers and table edge cases may
render differently. Raw HTML/entities are escaped. Only absolute HTTP(S) links without credentials
become anchors; unsafe/malformed links remain text. Markdown images become alt text, never `<img>`.
Collision-free code placeholders prevent user-supplied marker text from becoming generated markup.
Readeck's own readability extraction can change formatting or omit content; inspect important results.

## Official API evidence

Checked the official `readeck/readeck` repository at commit
`4e1bf51973bcf3832a8dfa36311444eada77f856` (source evidence, not a live instance test):

1. [Bookmark API schemas](https://codeberg.org/readeck/readeck/src/commit/4e1bf51973bcf3832a8dfa36311444eada77f856/docs/api/bookmarks/types.yaml):
   `bookmarkSummary.state` enumerates **0 loaded / 1 error / 2 loading**; `loaded` becomes true
   “regardless of its error state”; `has_article` indicates a stored article. `bookmarkCreate`
   lists `url`, `title`, and `labels`.
2. [Bookmark API routes](https://codeberg.org/readeck/readeck/src/commit/4e1bf51973bcf3832a8dfa36311444eada77f856/docs/api/bookmarks/routes-bookmarks.yaml):
   POST `/bookmarks` returns deferred **202** with `Bookmark-Id`; GET `/bookmarks/{id}` returns
   `bookmarkInfo`. Create requires write scope; details requires read scope.
3. [API traits](https://codeberg.org/readeck/readeck/src/commit/4e1bf51973bcf3832a8dfa36311444eada77f856/docs/api/traits.yaml):
   deferred 202 includes the created resource's `Location`. 401 means invalid authorization;
   403 means insufficient permission.
4. [Bookmark serializer](https://codeberg.org/readeck/readeck/src/commit/4e1bf51973bcf3832a8dfa36311444eada77f856/internal/bookmarks/dataset/bookmarks.go):
   `NewBookmark` assigns `Loaded: b.State != bookmarks.StateLoading`; `HasArticle` is true only
   when `b.Files["article"]` exists. This corroborates why neither HTTP 202 nor `loaded` alone proves success.

Current [creation documentation](https://codeberg.org/readeck/readeck/src/commit/4e1bf51973bcf3832a8dfa36311444eada77f856/docs/api/bookmarks/doc-create.md)
also documents an optional direct `html` payload. That alternative is deliberately **not used** here:
this track preserves the requested original `{url,title,labels}` callback flow.
