---
name: "youtube-sumup-gemini"
description: "用 Gemini agentic video 模型总结 YouTube 视频：链接直发 Google，Google 侧直接从 YouTube 拉片观看，不经过本机下载。当 yt-dlp 被 429/403 全拦（元数据/字幕都拿不到）或视频无字幕且下载限流时使用。拿到内容后走标准 10 步交付（中文总结→落盘→history→GitHub→HTML 邮件→Inkstone→notify）。不适用于会员专享视频。"
---

# YouTube 视频总结（Gemini 版）

## Purpose

本机 YouTube 出口被全拦（yt-dlp 连元数据/字幕都拿不到，见 AGENTS.md 的封锁记录）时的总结方案。
原理：YouTube URL + 提问直接发给 Gemini 的 agentic video 模型，Google 在自己那边从 YouTube 拉视频观看，
完全绕过本机下载。Gemini 只负责"看视频并回答"，最终中文读书报告由 Muse 按格式撰写。

触发：用户说"总结视频"但 yt-dlp 探针全拦；或用户明确要求用 Gemini。

## Tooling

用 watch skill 的 Gemini 引擎（`~/workspace/skills/watch/scripts/watch.py`）：

```bash
export PATH="$HOME/lavoro/venv/bin:$PATH"   # yt-dlp 在 venv 里（Gemini 引擎可不依赖它，但保持一致）
cd ~/workspace/skills/watch/scripts
timeout 850 python3 watch.py "<YouTube URL>" --engine gemini \
  --question "请完整详细地总结这个视频的全部内容：1) 先告诉我视频的准确标题、频道名、时长；2) 用中文分章节详细复述每一个核心观点、论据、案例和结论；3) 列出提到的关键人物、书籍或概念。"
```

- 批量处理必须**依次执行，不要并行**（并行烧配额）。
- 单视频超时 850 秒；长视频（>30 分钟）可放宽到 1200 秒。
- 模型切换：`WATCH_GEMINI_MODEL="gemini-3.6-flash" timeout 850 python3 watch.py ...`（3.8 持续 503 时用，见 Operating Rules）。

## Auth

Key 在 `~/.config/watch/.env`：`GEMINI_API_KEY`（主）+ `GEMINI_API_KEY_BACKUP`（备）。
watch skill 自带主备 key 自动切换与 429/5xx 退避重试，无需手写重试循环。
**绝不在输出、日志、报告、记忆里打印 key 的值。**

## Workflow

1. **去重**：`grep "<video_id>" /home/hatch/lavoro/muse_vm/youtube_scoops/history.jsonl`，有完整记录（非 legacy）则跳过。
2. **Gemini 看视频**：按 Tooling 跑（一次即可，skill 自带重试；不要自己写循环）。
3. **Muse 写中文总结**：按 `youtube-sumup-native` skill 的报告格式（标题、基本信息、概述、要点、⭐金句），转录方式记为 `gemini`。
4. **标准 10 步交付**（同 youtube-sumup-native 步骤 4–10）：落盘到 `/home/hatch/lavoro/muse_vm/youtube_scoops/<YYYYMMDD_HHMM>_<videoid>/` →
   追加 history.jsonl → 提交到 `seigneurtsui/muse_ai` 的 `youtube/` → 渲染 HTML 并 `--html` 直发 `gc40800@gmail.com`
   → 同步 Inkstone Youtube folder（`01m2q6tcqwkcypwj00efrz7kba`）→ notify 推送。跳过口令与原 skill 一致
   （"这次不发邮件"/"这次不同步 Inkstone"/"这次不通知"）；涉政内容不走邮件。
5. **失败处理**：记录失败原因继续下一个；**不要自动建重试任务**，把决定权留给用户。

## Operating Rules

1. **模型优先级**：默认 `gemini-3.8-flash`（`.env` 里已配）；持续 503 过载时换 `gemini-3.6-flash` 再试一次，不要死磕 3.8。
2. **429 是按分钟限流**：成功常夹在两次 429 之间，不是日配额见底；skill 自带退避能消化一部分，单 key 连 429 3 次再放弃该视频。
3. **配额**：免费 tier 约每天北京时间 15:00（太平洋午夜）重置；批量任务排在重置之后。
4. **长请求偶发 `RemoteDisconnected`**：短视频正常、长视频偶发被掐断，重试一次常能过，不要因单次网络失败判死刑。
5. **耗时**：Gemini 看视频约 1–2 分钟，单视频全套交付约 3–4 分钟；批量按每个视频 5 分钟估预算。
6. **VM 会换**：`/tmp` 会被清空，watch.py 的日志和中间产物写 workspace（goal 的 hidden_files/），不要只放 /tmp。
7. 会员专享视频无公开流，Gemini 也看不了，直接说明不绕路。
