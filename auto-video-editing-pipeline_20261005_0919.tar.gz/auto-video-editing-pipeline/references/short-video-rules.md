# 短视频移植规则

本技能移植 `chatgpt-short-video-editor` 的可复用生产约束：

- 八步：素材检查、转写、内容整理、剪辑决策、逐段粗剪、字幕/视觉、预览、QA/定稿。
- faster-whisper-stt 是默认 STT；其字幕按 lower-confidence phrase-level 处理。
- 先生成 preview，再生成 formal final；最多三次证据驱动修复，不静默循环。
- 字幕永远作为最后视觉操作；不默认添加 B-roll、音乐、CTA 或发布动作。
- 预览和正式文件都必须进行全片 decode；抽查开始、结束、中段和每个裁切边界。
- 原素材不移动、不改名、不覆盖；任务只在批次目录写派生文件。
- 需要词级精度时不能假称 faster-whisper 达到 Scribe 的词级质量；本 pipeline 不会
  自动上传或切换云端 STT。
