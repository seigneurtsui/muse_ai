# 剪辑留白、音频淡化与可追溯 EDL

## 边界规则

所有时间单位为秒。裁切/速度切换先验证源字幕短语边界：允许短语首尾或字幕间隙，
拒绝在短语内部切断；faster-whisper-stt 的时间精度仍是 lower-confidence phrase-level。
字幕间隙只是留白候选，不等于音频静音已被测量；≥400ms 静音优先需结合静音报告和试听。

- `--cut-padding-ms 120`：默认向两端扩展 120ms；范围 0–200ms，0 禁用。
- 扩展不能进入邻近短语，也不能超出源文件。邻近短语没有足够间隙时，实际留白会缩短。
- 连续源区间接缝不叠加留白，以免重复源内容；不连续重排/高光前置保留各自留白。
- `--audio-fade-ms 30`：默认每段在**输出时间轴**做约 30ms 音频淡入/淡出；
  极短片段最多各占半段，0 禁用。不是视频 crossfade，不改变画面拼接长度。
- 字幕根据真正渲染的留白区间、速度和每段实测视频时长重新计算。
- edit-plan 的 `ranges` 始终保存请求区间；`render_ranges` 保存实际留白区间，
  恢复不会再次累加 padding。自定义计划如需严格区间，显式使用 `--cut-padding-ms 0`。

## EDL

普通字幕/裁切模式和 edit-mode 均生成 `videos/<id>/edl.json`。合并 QA 通过后，
批次根目录生成 `edl.json`，保留单片源引用并转换为合并后的偏移。

每条 `entries` 包含：

- `source`、`source_sha256`；
- `start`、`end`：实际保留的源区间；`requested_start`、`requested_end`：原请求；
- `padding_before_ms`、`padding_after_ms`、`speed`、`audio_fade_ms`；
- `beat`、`quote`、`reason`；
- `transcript_engine: faster-whisper-stt`、`confidence: lower-confidence phrase-level`；
- `output_start`、`output_end`、`output_duration`。

`entries` 顺序就是输出顺序，允许明确重复/重排，不混用其他 STT 引擎时间戳。
edit-mode 输出偏移由逐段**实测视频帧时长**累加，不由 MP3/AAC 编码尾部填充累加。
普通单区间输出时长按源范围/速度计算，最终 QA 允许帧级误差并保留实际媒体时长。
合并 EDL 的 `video_id`、`per_video_edl` 用于反查单片。字幕最后烧录，不再在合并时烧录。

## 边界视听材料

preview/final/merged 各自的 `qa/.../boundaries/` 包含：

```text
boundary_001.mp4   # 当前渲染文件的边界 ±1.5s，首尾按片长截取
boundary_001.wav   # 同窗 PCM 48kHz 双声道；无音轨时为空引用而非伪造音频
index.json        # 位置、窗口、文件、当前视频哈希、extracted、human_review
review.md         # 人工检查清单
```

覆盖每个 EDL 首尾/内部接缝，加上全片开始、结束和中点；另有代表性抽帧和全片 decode。
检查材料来自渲染产物，不仅是源文件。

**材料生成成功不等于已观看或试听。** `human_review` 默认 pending；技术 QA 的 `ok`
只表示 decode、规格、字幕时长与材料生成通过。当前会话/用户仍须复核跳帧、闪帧、爆音、
音画同步、字幕安全区、叠层位置与混音清晰度，并把实际观察记录到批次 `project.md`。
最多三次证据驱动修复由当前会话管理，没有证据时不盲目重渲染，不声称人工视听检查通过。
