已基于你提供的 `inkstone_client_optimized_v1.py` 生成最新脚本：

**`inkstone_client_optimized_v1_latest.py`**

本次只做了必要的最小修改，没有删除原有功能，也没有重构整体程序结构。

## 本次修改

主要增加：

```python
FOLDER_SEARCH_QUERIES = [...]
```

以及：

```python
def search_folder_notes(folder_path: str, limit: int = 20)
```

该函数会：

- 使用多个常见中文、英文关键词搜索指定 folder。
- 合并不同关键词返回的结果。
- 根据笔记 ID 去重。
- 显示扫描进度。
- 显示扫描耗时。

`download --folder-id` 现在不再使用无效的：

```python
"query": "*"
```

而是改成：

```python
results = search_folder_notes(str(folder_path))
```

这样可以解决你之前遇到的：

```text
该 folder 没有返回文档
```

问题。

## 测试 folder 搜索

运行：

```bash
python3 -c "
from inkstone_client_optimized_v1_latest import search_folder_notes
import json

result = search_folder_notes('SeigneurTsui')
print(json.dumps(result, ensure_ascii=False, indent=2))
"
```

也可以使用文件夹 ID 测试下载：

```bash
python3 inkstone_client_optimized_v1_latest.py download \
  --folder-id 01m2mqxbahbxav2aj43zkv558s
```

## 其他功能保持不变

原有命令仍然保留：

```bash
python3 inkstone_client_optimized_v1_latest.py folders
```

```bash
python3 inkstone_client_optimized_v1_latest.py search "直觉"
```

```bash
python3 inkstone_client_optimized_v1_latest.py create ./notes
```

```bash
python3 inkstone_client_optimized_v1_latest.py update NOTE_ID ./updated.md
```

```bash
python3 inkstone_client_optimized_v1_latest.py download NOTE_ID
```

```bash
python3 inkstone_client_optimized_v1_latest.py create-folder "新文件夹"
```

批量导入、递归扫描、断点续传、SSL 兼容、进度提示和耗时统计均保留。

需要注意：当前 Inkstone 的公开工具中没有提供“按 folder 无条件枚举全部笔记”的接口，因此 folder 下载暂时通过多个关键词合并搜索实现。对中文长文档通常有效，但极短或完全不包含预设关键词的笔记仍可能无法被发现。




已生成优化后的 Python 脚本 **`inkstone_client_optimized.py`**，在保留原有功能的基础上增加了：


- `create` 支持单个 Markdown 文件或整个文件夹。
- 支持递归导入子文件夹中的 Markdown。
- 默认导入 folder 可通过变量统一维护。
- 新增实时创建文件夹命令。
- `download` 支持下载指定 folder 中的文档。
- 默认下载路径为 `~/Downloads/inkstone_md`。
- 每次 folder 下载自动创建带时间和名称的独立目录。
- 导入和下载均支持 JSONL 断点记录。
- 支持失败后再次运行自动跳过成功项目。
- 支持进度显示、耗时统计、失败统计。
- 保留原来的 `folders`、`search`、单文件 `create`、`update`、单笔记 `download` 功能。
- 保留 macOS SSL 证书兼容处理。
- 保留 SSE 和 JSON-RPC 错误解析。

## 关键配置

脚本顶部提供了默认配置：

```python
DEFAULT_IMPORT_FOLDER_ID = "01m2mrk9wth9y55961cxxmfarm"
DEFAULT_DOWNLOAD_ROOT = Path.home() / "Downloads" / "inkstone_md"
```

以后只需修改：

```python
DEFAULT_IMPORT_FOLDER_ID = "新的folder_id"
```

即可改变默认导入位置。

## 批量导入文件夹

导入当前文件夹下的 Markdown：

```bash
python3 inkstone_client_optimized.py create \
  "/Users/seigneur/Documents/markdown"
```

默认会导入到：

```text
01m2mrk9wth9y55961cxxmfarm
```

指定目标 folder：

```bash
python3 inkstone_client_optimized.py create \
  "/Users/seigneur/Documents/markdown" \
  --folder-id "目标folder_id"
```

递归导入所有子文件夹：

```bash
python3 inkstone_client_optimized.py create \
  "/Users/seigneur/Documents/markdown" \
  --recursive
```

脚本默认会在源文件夹中生成：

```text
.inkstone-import.jsonl
```

下次再次运行时，成功上传过的文件会自动跳过。

强制重新上传：

```bash
python3 inkstone_client_optimized.py create \
  "/Users/seigneur/Documents/markdown" \
  --no-resume
```

遇到第一个错误立即停止：

```bash
python3 inkstone_client_optimized.py create \
  "/Users/seigneur/Documents/markdown" \
  --stop-on-error
```

## 创建文件夹

创建根文件夹：

```bash
python3 inkstone_client_optimized.py create-folder "新资料"
```

创建子文件夹：

```bash
python3 inkstone_client_optimized.py create-folder "第一章" \
  --parent-id "父文件夹ID"
```

指定图标和颜色：

```bash
python3 inkstone_client_optimized.py create-folder "重要资料" \
  --icon "📚" \
  --color "#3b82f6"
```

该功能使用 Inkstone 的 `create_folder` 工具，并自动生成 `operation_id`。对应 API 支持 `name`、`parent_id`、`folder_id`、`icon` 和 `color` 参数。 [github](https://github.com/shuaiplus/inkstone)

## 下载整个 folder

```bash
python3 inkstone_client_optimized.py download \
  --folder-id "01m2mrk9wth9y55961cxxmfarm"
```

默认保存到：

```text
~/Downloads/inkstone_md
```

脚本会自动创建类似：

```text
~/Downloads/inkstone_md/20260917_1559_Notes/
```

每篇笔记保存为独立的 Markdown 文件：

```text
~/Downloads/inkstone_md/20260917_1559_Notes/SKILL.md
```

下载断点文件位于对应目录中：

```text
.inkstone-download.jsonl
```

如果下载过程中断，再执行同样的命令即可跳过已经成功下载的笔记。

强制重新下载：

```bash
python3 inkstone_client_optimized.py download \
  --folder-id "01m2mrk9wth9y55961cxxmfarm" \
  --no-resume
```

下载单篇笔记的原有用法仍然保留：

```bash
python3 inkstone_client_optimized.py download \
  "01m2q589sfp93nd08dvqescej8"
```

## 重要限制

当前批量下载实现使用：

```json
{
  "name": "search_notes",
  "arguments": {
    "query": "*",
    "folder": "Notes",
    "limit": 20,
    "mode": "lexical"
  }
}
```

但你提供的工具 schema 中 `search_notes.limit` 最大值是 `20`，而且 Inkstone 是否支持 `query: "*"` 作为“列出 folder 全部笔记”，需要以实际服务端行为为准。

因此，如果某个 folder 超过 20 篇笔记，或者服务器不接受 `*`，脚本会提示无法完整获取列表。此时需要使用 Inkstone 支持的分页方式，或者根据实际 API 返回增加分页逻辑。

另外，`search_notes.folder` 在你提供的 schema 中是字符串，实际可能接受 folder 路径，也可能需要 folder 名称；脚本会优先使用 folder 的 `path`，如果你的服务端要求 folder ID，可以将脚本中的：

```python
folder.get("path") or folder.get("name")
```

改成：

```python
folder.get("id")
```

## 使用前建议

先检查帮助信息：

```bash
python3 inkstone_client_optimized.py --help
```

查看新建文件夹帮助：

```bash
python3 inkstone_client_optimized.py create-folder --help
```

查看批量导入帮助：

```bash
python3 inkstone_client_optimized.py create --help
```

查看批量下载帮助：

```bash
python3 inkstone_client_optimized.py download --help
```

脚本中仍然保留了你要求直接嵌入的 API Key，但该 Key 已经在对话中公开，建议在 Inkstone 后台撤销并生成新的 Key，然后只修改脚本顶部的 `API_KEY`。
