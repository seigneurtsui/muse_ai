# Release Package Contract

The release package is a human-reviewable publishing checklist. It never
uploads, schedules, or publishes content.

Create it only after `final.mp4` and QA pass. Read the corrected transcript,
final SRT/ASS timing, QA report, and creator profile first. Every claim must be
traceable to the finished video.

## Invocation and current-session handoff

```bash
python3 "$PIPE" <videos> --release-pack
# Or reuse an existing batch without STT or rendering:
python3 "$PIPE" --resume-batch <batch> --release-pack
```

`--release-pack` explicitly requests all eight platforms below. Initial default
is off; a resume restores the saved setting, and `--no-release-pack` disables it.
With merge on, create one pack for the verified batch film. With `--no-merge`,
create one pack per verified single video; an old merged file is ignored.

1. `scripts/release_pack.py` verifies final SHA-256 against successful QA and
   builds `request.json` from the final-timeline SRT, frame paths and profile.
2. It returns exit **10** and `release_pack.pending_requests`. The agent reads
   the complete request and available frame images; the current OmniRush model
   writes `response.json` using the provided schema. No external AI credentials
   or model service are used.
3. Resume the same batch. Validate request ID, eight platforms, 3–5 unique titles,
   editorial length budgets, distinct descriptions, recommended index, tags,
   evidence IDs and B站 fan post. Invalid or stale responses fail visibly.
4. Only validated responses become the 11 Markdown files and `manifest.json`.
   The agent must complete this step before claiming a pack was generated.

Input changes produce a new fingerprint directory; completed drafts are retained.
The script checks structural grounding, while factual/linguistic quality is the
current model's responsibility. Do not claim automated semantic verification.

## Output

```text
发布包/<merged-or-video-id>/<content-fingerprint>/
├── request.json
├── response.json
├── manifest.json
├── 一页总览.md
├── B站.md
├── 油管.md
├── 抖音.md
├── TikTok.md
├── 小红书.md
├── 视频号.md
├── 百家号.md
├── 头条号.md
├── 封面提示词.md
└── 发布计划.md
```

Each platform file contains independently written title candidates, one
recommendation with rationale, description, tags, and source evidence IDs.
The overview includes the final video path, hash and timed evidence excerpts.
TikTok copy is English; YouTube copy follows the project language. The profile
controls tone and positioning; it does not remove platforms from this all-eight
CLI option. Cover prompts and publishing suggestions are separate documents.

## Rules

- One platform, one rewrite; never copy a title or description unchanged.
- Editorial title budgets: B站/抖音/视频号 30, 小红书 20, 油管/TikTok 100,
  百家号/头条号 40 Unicode characters. These are writing budgets, not a claim
  about current platform API limits.
- Put the real value, result, or demonstration in the first lines.
- Do not invent statistics, testimonials, identities, sponsorships, or claims.
- YouTube/TikTok International may reference an approved English SRT; do not
  claim a translation exists when it was not generated and QA-checked.
- Cover prompts should specify one horizontal and one vertical composition, with
  the real topic/product as the largest readable text.
- The package remains pending human review.
