## Known Issues

### /toc/ 排序按钮无效

**现象**: 点击 `最新优先` / `最早优先` / `名称 A→Z` 按钮，active 状态切换但卡片顺序不变。

**根原因**: `render()` 只通过 `hidden` class 显示/隐藏卡片，但从未重排 DOM 元素。当所有卡片都在一页内（PAGE_SIZE=12 >= 卡片数），`filtered.slice(0, N)` 返回全部卡片 → 全部 `classList.remove('hidden')` → 视觉顺序与 DOM 顺序一致（即创建时的初始顺序），排序不产生可见效果。

**修复方法**:
1. 在 `render()` 中添加 DOM 重排逻辑，在 show/hide 之前将卡片按排序顺序物理移动到 grid 末尾：

```javascript
grid.removeChild(emptyMsgEl);
filtered.forEach(function(c) { grid.appendChild(c); });
grid.appendChild(emptyMsgEl);
```

`appendChild` 对已在 DOM 中的元素会将其**移动到末尾**，遍历 sorted array 即可完成重排。

2. 同时将卡片生成从 bash/Python 替换改为纯 JavaScript 动态生成（`createCards()` from `REPORTS_DATA`），消除 bash heredoc 中特殊字符转义不一致导致的隐患。

**涉及文件**: `scripts/deploy-subpath.sh` — TOC 页面模板中的 `<script>` 部分

**验证方式**: 使用 Playwright CLI 打开页面，点击排序按钮后用 `document.querySelectorAll('.card .card-title')` 确认顺序变化。

**历史**: 2026-07-06 — 首次修复 DOM 重排问题（v2 部署才真正修复，v1 只改了 JS 生成卡片未解决 DOM 顺序问题）。
