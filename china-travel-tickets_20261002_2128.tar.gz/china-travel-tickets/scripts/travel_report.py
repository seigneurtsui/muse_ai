#!/usr/bin/env python3
"""Ticket query -> local report -> optional email. Stdout is one JSON object."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from render_report import render, safe_slug

SKILL_DIR = Path(__file__).resolve().parent.parent
DOWNLOADS = Path.home() / "Downloads"


class CommandError(RuntimeError):
    def __init__(self, code, payload):
        super().__init__("子命令失败；详见错误输出和发送状态文件")
        self.code = code
        self.payload = payload


def run_json(command: list[str]) -> dict:
    result = subprocess.run(command, text=True, capture_output=True)
    try:
        data = json.loads(result.stdout)
        if not isinstance(data, dict):
            raise ValueError("不是 JSON 对象")
    except (ValueError, TypeError):
        data = {"success": False, "error": "子命令未返回有效 JSON"}
    if result.returncode or data.get("success") is False:
        if result.stderr:
            print(result.stderr, file=sys.stderr, end="")
        raise CommandError(result.returncode or 1, data)
    return data


def add_query_arguments(parser):
    parser.add_argument("--mode", required=True, choices=("train", "flight"))
    parser.add_argument("--from", dest="origin", required=True)
    parser.add_argument("--to", dest="destination", required=True)
    parser.add_argument("--date", required=True, help="中国上海时区出发日期 YYYY-MM-DD")
    parser.add_argument("--kind", default="")
    parser.add_argument("--limit", type=int, default=50)
    parser.add_argument("--refresh-cache", action="store_true")
    parser.add_argument("--direct-only", action="store_true")
    parser.add_argument("--max-stops", type=int)
    parser.add_argument("--max-transfer-minutes", type=int)
    parser.add_argument("--avoid-overnight", action="store_true")
    parser.add_argument("--sort", choices=("price", "duration", "arrival", "departure"))
    parser.add_argument("--departure-after")
    parser.add_argument("--arrival-before")
    parser.add_argument("--prefer-airline", action="append", default=[])
    parser.add_argument("--same-airport-only", action="store_true")
    parser.add_argument("--same-terminal-only", action="store_true")
    parser.add_argument("--min-connection-minutes", type=int, help="机票每次换乘的用户指定等待下限，非机场官方 MCT")
    parser.add_argument("--transfers", action="store_true")
    parser.add_argument("--max-transfers", type=int, default=1)
    parser.add_argument("--transfer-stations")
    parser.add_argument("--transfer-limit", type=int)
    parser.add_argument("--min-transfer-minutes", type=int, default=30)
    parser.add_argument("--max-total-minutes", type=int, default=1440)


def validate_query(args, parser):
    try:
        day = datetime.strptime(args.date, "%Y-%m-%d").date()
    except ValueError:
        parser.error("--date 必须为 YYYY-MM-DD")
    if day.isoformat() != args.date or day < datetime.now(ZoneInfo("Asia/Shanghai")).date():
        parser.error("--date 须为有效的今天或未来日期 YYYY-MM-DD")
    if args.limit < 1 or (args.mode == "flight" and args.limit > 50):
        parser.error("--limit 须大于 0；机票最多 50")
    if args.mode == "flight" and (args.transfers or args.transfer_stations):
        parser.error("--transfers/--transfer-stations 仅适用于高铁")


def build_query_command(args):
    if args.mode == "train":
        command = [sys.executable, str(SKILL_DIR / "scripts/train_query.py"), "--format", "json"]
        for enabled, flag in ((args.transfers, "--transfers"), (args.refresh_cache, "--refresh-cache")):
            if enabled:
                command.append(flag)
        values = ((args.kind, "--kind"), (args.max_transfers, "--max-transfers"),
                  (args.transfer_stations, "--transfer-stations"), (args.transfer_limit, "--transfer-limit"),
                  (args.min_transfer_minutes, "--min-transfer-minutes"), (args.max_total_minutes, "--max-total-minutes"))
    else:
        command = ["node", str(SKILL_DIR / "scripts/flight_query.cjs"), "--json"]
        for enabled, flag in ((args.direct_only, "--direct-only"), (args.avoid_overnight, "--avoid-overnight"),
                              (args.same_airport_only, "--same-airport-only"), (args.same_terminal_only, "--same-terminal-only")):
            if enabled:
                command.append(flag)
        for airline in args.prefer_airline:
            command += ["--prefer-airline", airline]
        values = ((args.max_stops, "--max-stops"), (args.sort, "--sort"),
                  (args.departure_after, "--departure-after"), (args.arrival_before, "--arrival-before"),
                  (args.min_connection_minutes, "--min-connection-minutes"))
    for value, flag in (*values, (args.max_transfer_minutes, "--max-transfer-minutes")):
        if value is not None and value != "":
            command += [flag, str(value)]
    return command + ["--from", args.origin, "--to", args.destination, "--date", args.date, "--limit", str(args.limit)]


def query_slug(args):
    # Hash includes Unicode city names and filters so routes never collide.
    key = hashlib.sha256(json.dumps(build_query_command(args), ensure_ascii=False).encode()).hexdigest()[:12]
    return f"china-{args.mode}-{args.date}-{key}"


def save_report(data, output_dir, slug):
    output_dir = output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    slug = safe_slug(slug)
    raw_path = output_dir / f"{slug}.json"
    raw_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    md_path, html_path = render(raw_path, output_dir, slug)
    return {"raw": str(raw_path), "markdown": str(md_path), "html": str(html_path)}


def send_report(report, recipient, subject, retries=2, retry_delay_ms=1000, status_file=None):
    command = ["node", str(SKILL_DIR / "scripts/send_report.cjs"),
               "--html", report["html"], "--text", report["markdown"],
               "--subject", subject, "--to", recipient,
               "--retries", str(retries), "--retry-delay-ms", str(retry_delay_ms)]
    if status_file:
        command += ["--status-file", str(status_file)]
    return run_json(command)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    add_query_arguments(parser)
    parser.add_argument("--output-dir", type=Path, default=DOWNLOADS)
    parser.add_argument("--slug")
    parser.add_argument("--to-email", default=os.environ.get("TICKET_REPORT_TO") or "gc40800@gmail.com")
    sending = parser.add_mutually_exclusive_group()
    sending.add_argument("--send", action="store_true", help="默认发送")
    sending.add_argument("--no-send", action="store_true")
    parser.add_argument("--retries", type=int, choices=range(5), default=2)
    parser.add_argument("--retry-delay-ms", type=int, default=1000)
    parser.add_argument("--status-file", type=Path)
    args = parser.parse_args(argv)
    validate_query(args, parser)
    if not 0 <= args.retry_delay_ms <= 600000:
        parser.error("--retry-delay-ms 须为 0–600000")
    output = {}
    try:
        data = run_json(build_query_command(args))
        output.update(save_report(data, args.output_dir, args.slug or query_slug(args)))
        output["email"] = None
        if not args.no_send:
            subject = f"{args.origin} → {args.destination}出行报告｜{args.date}"
            output["email"] = send_report(output, args.to_email, subject, args.retries, args.retry_delay_ms, args.status_file)
        output["success"] = True
    except CommandError as exc:
        output.update(success=False, failure=exc.payload)
        print(json.dumps(output, ensure_ascii=False, indent=2))
        return exc.code
    print(json.dumps(output, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
