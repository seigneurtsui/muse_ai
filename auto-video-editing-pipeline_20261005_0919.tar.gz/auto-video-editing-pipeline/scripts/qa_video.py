#!/usr/bin/env python3
"""Evidence-based media, subtitle, decode, frame, and hash QA."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import subprocess
from pathlib import Path

try:
    from .srt_utils import read_cues
except ImportError:  # direct CLI execution
    from srt_utils import read_cues


def probe(path: Path) -> dict:
    completed = subprocess.run(
        ["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)],
        capture_output=True, text=True, check=True,
    )
    return json.loads(completed.stdout)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def decode_check(path: Path, stderr_path: Path) -> bool:
    completed = subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-f", "null", "-"], capture_output=True, text=True)
    stderr_path.write_text(completed.stderr or "", encoding="utf-8")
    return completed.returncode == 0 and not (completed.stderr or "").strip()


def extract_frames(path: Path, duration: float, output: Path) -> list[str]:
    output.mkdir(parents=True, exist_ok=True)
    positions = sorted({max(0.05, min(duration - 0.05, x)) for x in (0.1, duration * 0.25, duration * 0.5, duration * 0.75, duration - 0.1) if duration > 0.1})
    files: list[str] = []
    for index, position in enumerate(positions, 1):
        frame = output / f"frame_{index:02d}.jpg"
        completed = subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{position:.3f}", "-i", str(path), "-frames:v", "1", "-q:v", "3", str(frame)], capture_output=True, text=True)
        if completed.returncode == 0 and frame.is_file() and frame.stat().st_size:
            files.append(str(frame))
    return files


def run_qa(args: argparse.Namespace) -> dict:
    video = args.video.expanduser().resolve()
    if not video.is_file():
        raise FileNotFoundError(video)
    output = args.output.expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    media = probe(video)
    duration = float(media.get("format", {}).get("duration") or 0)
    video_stream = next((stream for stream in media.get("streams", []) if stream.get("codec_type") == "video"), {})
    audio_stream = next((stream for stream in media.get("streams", []) if stream.get("codec_type") == "audio"), {})
    frames = extract_frames(video, duration, output / "frames")
    decode_ok = decode_check(video, output / "decode.stderr")
    expected = (args.width, args.height) if args.width and args.height else None
    resolution_ok = expected is None or (video_stream.get("width"), video_stream.get("height")) == expected
    fps = str(video_stream.get("avg_frame_rate", ""))
    fps_ok = args.fps is None or fps == f"{args.fps}/1"
    subtitle_count = None
    subtitle_last_end = None
    subtitle_ok = True
    if args.srt:
        cues = read_cues(args.srt.expanduser().resolve())
        subtitle_count = len(cues)
        subtitle_last_end = max((cue[1] for cue in cues), default=0.0)
        subtitle_ok = bool(cues) and subtitle_last_end <= duration + 0.1
    ass_count = None
    if args.ass:
        ass_count = sum(1 for line in args.ass.expanduser().read_text(encoding="utf-8").splitlines() if line.startswith("Dialogue:"))
    report = {
        "video": str(video), "duration": duration, "media": media,
        "resolution": [video_stream.get("width"), video_stream.get("height")],
        "fps": fps, "audio": {"codec": audio_stream.get("codec_name"), "sample_rate": audio_stream.get("sample_rate"), "channels": audio_stream.get("channels")},
        "checks": {"decode": decode_ok, "resolution": resolution_ok, "fps": fps_ok, "subtitles": subtitle_ok, "frames": bool(frames)},
        "subtitle_count": subtitle_count, "subtitle_last_end": subtitle_last_end,
        "ass_dialogue_count": ass_count, "frames": frames, "sha256": sha256(video),
    }
    report["ok"] = all(report["checks"].values())
    (output / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [
        "# QA报告", "", f"文件：`{video}`", f"时长：{duration:.3f}s",
        f"视频：{video_stream.get('codec_name', 'unknown')} {video_stream.get('width')}x{video_stream.get('height')} {fps}",
        f"音频：{audio_stream.get('codec_name', 'none')} {audio_stream.get('sample_rate', '-')}Hz {audio_stream.get('channels', '-')}ch", "",
        "## 检查", "",
    ]
    labels = {"decode": "全片解码", "resolution": "分辨率", "fps": "帧率", "subtitles": "字幕时间轴", "frames": "抽帧"}
    lines.extend(f"- [{'x' if value else ' '}] {labels[key]}" for key, value in report["checks"].items())
    lines += [f"- SHA-256：`{report['sha256']}`", "", f"结论：{'通过' if report['ok'] else '失败/需复核'}", ""]
    (output / "QA报告.md").write_text("\n".join(lines), encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--video", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--srt", type=Path)
    parser.add_argument("--ass", type=Path)
    parser.add_argument("--width", type=int)
    parser.add_argument("--height", type=int)
    parser.add_argument("--fps", type=int)
    args = parser.parse_args()
    report = run_qa(args)
    print(json.dumps({"ok": report["ok"], "report": str(args.output / 'report.json')}, ensure_ascii=False))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
