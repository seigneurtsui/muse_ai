# edge-tts 使用说明

以下命令在本目录运行；也可以把 `tts.py` 替换为技能中 `scripts/tts.py` 的绝对路径。

## 语音合成与 AI 文本处理是两条独立路径

- `sentence`（默认）和 `edge` 仍调用 Microsoft Edge 云端 TTS。`azure` 仍是可选的 Azure Speech 备用方案，使用原有 `AZURE_SPEECH_KEY` / `AZURE_SPEECH_REGION`；这些是**语音服务**配置，不是 LLM 配置。
- 所有 AI 文本任务（语义断句、高亮关键字、字幕翻译、AI 标点）仅调用已登录的 **OmniRush CLI 内置模型**。不再配置 AI 服务环境变量、API Key、provider 列表或外部 chat/completions 地址。
- 正音表、同音异体替换、OpenCC、字幕样式、动态订阅提示和 TTS 重试保持原有本地处理逻辑。

```bash
pip install edge-tts opencc-python-reimplemented
# 可选：音频拼接
pip install pydub
# AI 文本功能需要登录；已登录则无需再次登录
omnirush login
```

## 已知现有边界

运行时请明确提供 `-o /path/to/output.mp3`。原脚本省略 `-o` 时的关键字输出路径初始化
可能触发 `Path(None)`；此问题早于本次 AI 服务迁移，未在本次改造中修改。
AI 回归与视频配音适配层均显式提供输出路径；离线测试不代表 Edge 云端语音质量已验证。

## OmniRush 调用接口与隐私

AI 子进程使用 `--engine pi --provider omnirush --print --mode json --no-session --no-tools --no-extensions --no-skills --no-prompt-templates --no-themes --no-context-files`。不继续父会话、不提供工具、不加载本技能，因此不会通过模型递归启动 TTS 或执行代码。

任务及正文以 JSON 消息经 stdin 传入；不写私密提示文件、不把正文放入 argv。临时空工作目录在完成后删除，子会话不持久化。只解析完成的 assistant 文本，不把流式增量、thinking 或进度当成回答。原始子进程输出不写日志；正常音频、字幕和指定的关键字输出仍会保存。

复用 CLI 的登录账户及状态目录，不读取或导出登录凭据。会话中继承 `OMNIRUSH_MODEL` 和存在时的 `OMNIRUSH_REASONING_LEVEL`，并校验返回模型；没有导出的模型元数据时使用 CLI 默认规则，不读取父会话私密历史。不会切换到其他账户或服务。**这仍是联网模型调用**，文本送到 OmniRush 并计入同一账户用量；不是离线推理，也不保证服务端零保留。CLI 可能正常刷新登录或模型元数据；技能关闭本次自动升级、崩溃报告和调试输出，不改全局设置。

支持的非密钥配置：

| 环境变量 | 含义 |
|---|---|
| `EDGE_TTS_OMNIRUSH_BIN` | 原生 OmniRush CLI 可执行文件路径；单个路径，不接受附加参数 |
| `EDGE_TTS_AI_TIMEOUT` | 每次总调用超时秒数，默认 180，范围 1–600 |
| `OMNIRUSH_MODEL` | 当前 OmniRush 模型选择，由 CLI / 会话提供；不另设技能模型 |

默认优先选择 `~/.npm-global/bin/omnirush`，否则查找 PATH。此机器的 `~/.omnirush/agent/bin/omnirush` 包装器会注入显式 `--skill`，即使存在 `--no-skills` 也不能安全使用，所以绕过该包装器。自定义路径也必须指向原生 CLI，不应指向会增加工具、扩展或技能的包装器。

单次 AI 任务最多尝试 3 次（含第一次），重试有短暂退避；超时终止启动器及引擎子进程。失败时：语义分段回退本地规则，高亮不生成，AI 标点使用 `--punctuation-fallback`；真正的字幕翻译失败则明确报错，不使用原文假装译文。中文到简/繁中文仍可由 OpenCC 直接转换，不必调用 LLM。

## 基础语音与双语字幕

```bash
python3 tts.py "你好，欢迎使用语音合成" -o speech.mp3
python3 tts.py -v zh-CN-YunxiNeural -r "+20%" -V "+50%" "调节语音" -o speech.mp3
python3 tts.py -f input.txt --srt --ass --languages zh-Hant,fr -o output.mp3
python3 tts.py -f input.txt --semantic --srt --ass -o output.mp3
```

当前脚本在没有手动关键字输入时会自动尝试 AI 关键字提取，即使不输出 ASS；字幕标点模式默认 `ai`。只做云端 TTS、完全关闭 LLM 调用时使用空关键字文件，不加 `--semantic`，选择本地标点模式及无需 AI 翻译的语言：

```bash
: > empty-keywords.txt
python3 tts.py -f input.txt --highlight-keyword-file empty-keywords.txt \
  --punctuation-mode keep --languages zh-Hant -o output.mp3
```

`zh-Hant` 不需 AI 翻译的前提是输入为中文；非中文转中文仍需要翻译。纯音频不加 `--srt` / `--ass` 时不做字幕翻译。

## 动态订阅提示（ASS）

```bash
# 默认开启，每 5 分钟显示一次“歡迎訂閱”
python3 tts.py -f input.txt --ass -o output.mp3
# 关闭动态提示
python3 tts.py -f input.txt --ass --no-subscribe-overlay -o output.mp3
# 每 3 分钟显示一次
python3 tts.py -f input.txt --ass --subscribe-interval 180 -o output.mp3
# 自定义文字（仍按长度调整位置）
python3 tts.py -f input.txt --ass --subscribe-text "請訂閱我的頻道" -o output.mp3
```

## 语音重试

每个片段默认总共尝试 3 次，间隔 1.5 秒；始终使用同一 TTS provider，保持音色一致。失败的音频会先删除，非空音频文件才算成功。此重试独立于 OmniRush 文本任务重试。

```bash
python3 tts.py -f input.txt --tts-retries 5 --tts-retry-delay 3 -o output.mp3
# 仅尝试一次，不重试
python3 tts.py -f input.txt --tts-retries 1 -o output.mp3
```

## 本地正音与字幕保护

```bash
# 默认：现有同音异体正音表
python3 tts.py -f input.txt --pron-fix-mode homophone -o output.mp3
# 原有 normal 正音模式
python3 tts.py -f input.txt --pron-fix-mode normal -o output.mp3
```

正音表不调用 AI。字幕的成对标点保护、中文 OpenCC 字形确认、关键字高亮字体/颜色和双语折行逻辑均保留。手动高亮可用 `--highlight` 或 `--highlight-keyword-file`。

## 离线回归测试

```bash
python3 -B -m unittest discover -s ../tests -v
python3 -B tts.py --help
```

测试替换 subprocess / TTS 客户端，不发起模型请求或语音合成网络请求。真实 AI 调用需要可用的原生 CLI、同一账户的有效登录和网络。
