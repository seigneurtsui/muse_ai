---
name: github-muse-ai
description: Push documents to and fetch files from the seigneurtsui/muse_ai GitHub repo using a personal access token via the GitHub Contents API. Use when the user asks to upload/commit a file to muse_ai, download a file from muse_ai, list its contents, or check whether a file exists there.
---

# GitHub muse_ai 仓库存取

目标仓库：`seigneurtsui/muse_ai`，分支 `main`。用 GitHub Contents API 做轻量存取，不走 git clone。

## 认证（安全红线）

- Token 只从环境变量 `GITHUB_TOKEN` 读取。
- **绝不**把 token 写进 skill、脚本、日志、回复或记忆；**绝不**在聊天里要求用户粘贴 token；**绝不**打印 token 的值（哪怕前几位）。
- 如需配置，把 `GITHUB_TOKEN` 和 `GITHUB_REPO` 写入 `~/workspace/skills/.env`
  （`GITHUB_TOKEN=...`，`GITHUB_REPO=seigneurtsui/muse_ai`，文件权限 600），
  用时 `set -a; . ~/workspace/skills/.env; set +a` 加载。
- 历史上曾在聊天中明文出现过的 PAT 视为已泄露——提醒用户去 GitHub Settings → Developer settings → Personal access tokens 撤销并重新生成。

```bash
# 每次操作前加载（不打印值）
set -a; . ~/workspace/skills/.env >/dev/null 2>&1; set +a
[ -n "$GITHUB_TOKEN" ] || { echo "未配置 GITHUB_TOKEN"; exit 1; }
REPO="${GITHUB_REPO:-seigneurtsui/muse_ai}"; BRANCH="main"
API="https://api.github.com/repos/$REPO"
AUTH=(-H "Authorization: Bearer $GITHUB_TOKEN" -H "Accept: application/vnd.github+json")
```

## 上传/新建文件

```bash
# FILE 为仓库内路径，如 muse_ai/notes.md；LOCAL 为本地文件
FILE="muse_ai/notes.md"; LOCAL="/path/to/local.md"
B64=$(base64 -w0 "$LOCAL")
curl -s "${AUTH[@]}" -X PUT "$API/contents/$FILE" \
  -d "$(jq -n --arg m "Add $FILE" --arg b "$B64" \
    '{message:$m, content:$b, branch:"main"}')" | jq -r '.commit.sha // .message'
```

## 更新已存在文件（需先取 sha）

```bash
SHA=$(curl -s "${AUTH[@]}" "$API/contents/$FILE?ref=main" | jq -r '.sha')
B64=$(base64 -w0 "$LOCAL")
curl -s "${AUTH[@]}" -X PUT "$API/contents/$FILE" \
  -d "$(jq -n --arg m "Update $FILE" --arg b "$B64" --arg s "$SHA" \
    '{message:$m, content:$b, sha:$s, branch:"main"}')" | jq -r '.commit.sha // .message'
```

## 下载文件

```bash
# 私有仓库必须带认证；公开仓库可直接用 raw.githubusercontent.com
curl -s "${AUTH[@]}" -H "Accept: application/vnd.github.raw" \
  "$API/contents/$FILE?ref=main" -o "$LOCAL"
```

## 列目录 / 查文件是否存在

```bash
# 列仓库根目录
curl -s "${AUTH[@]}" "$API/contents?ref=main" | jq -r '.[].path'
# 列子目录
curl -s "${AUTH[@]}" "$API/contents/muse_ai?ref=main" | jq -r '.[].path'
# 查文件是否存在（200 存在，404 不存在）
curl -s -o /dev/null -w "%{http_code}\n" "${AUTH[@]}" "$API/contents/$FILE?ref=main"
```

## 约定

- 提交信息用英文动词开头：`Add ...` / `Update ...` / `Fix ...`。
- 二进制文件同样 base64 上传；超过 100MB 的文件 Contents API 不支持，改走 git。
- 每次写操作后把返回的 commit sha 告诉用户；失败时打印 `.message` 里的错误原文。
- 不要用 `https://TOKEN@github.com/...` 形式的 git URL——token 会进 shell 历史和日志。
