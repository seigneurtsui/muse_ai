# Badge 参数契约

Badge 在 `srt-ass-studio` 生成的 ASS 文件之后注入，和主字幕独立，因此不会改变
字幕 cue 的时间或样式。

```text
--badge-text TEXT
--badge-start 0.4
--badge-end 2.0
--badge-position top-right
--badge-font FONT
--badge-font-file ~/Library/Fonts/字魂霸道手书.ttf
--badge-font-name FONT_FAMILY
--badge-size 72
--badge-color FFFFFF
--badge-outline-color 151515
--badge-back-color 80000000
--badge-outline 3
--badge-shadow 1
--badge-anim none|fade|pop|zoom|fly
--badge-fade-in-ms 120
--badge-fade-out-ms 250
```

可用位置：`top-left`、`top-center`、`top-right`、`center-left`、`center`、
`center-right`、`bottom-left`、`bottom-center`、`bottom-right`。

`end - start` 就是持续显示时长；例如 `0.4` 到 `2.8` 表示 2.4 秒。时间均为
**输出时间轴**，所以变速/裁切之后仍按最终成片时间解释。Badge 结束时间超过最终
时长会被截断并写入 QA 警告。

## Highlight keyword 独立样式

高亮关键词不再绑定主字幕的字体和颜色，可单独设置：

```text
--highlight "襄阳古城"
--highlight-font-file ~/Library/Fonts/字魂国潮手书.ttf
--highlight-size 260
--highlight-color FFD166
```

也可以直接给字体族名：

```text
--highlight-font-name ZHGTCS_T
```

`srt-ass-studio` 通过 `highlight_scale` 实现独立字号；字号必须在主字幕字号的
`1x–2x` 范围内，以保证布局和安全区校验仍然有效。
