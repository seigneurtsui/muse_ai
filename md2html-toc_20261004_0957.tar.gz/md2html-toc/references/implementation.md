# 实现与安全边界

## 渲染管线

1. `split_front_matter`：解析简单 YAML front matter（不依赖 PyYAML），`title` 用作 HTML `<title>`。
2. `markdown_to_html`：Python-Markdown，扩展 `extra`、`admonition`、`md_in_html`、`sane_lists`、`nl2br`。
   不使用 `codehilite`/Pygments，也不使用 Markdown 自带的 `toc` 扩展——围栏代码保留 `language-*` 类名，
   标题 ID 由本工具统一生成。
3. `heading_ids`：在清洗之前运行，为 H1–H6 生成唯一 ID。ID 来自标题原文
   （`# Intro <draft>` → `intro-draft`），TOC 显示文本用去标签后的纯文本。
4. `sanitize_html`（默认）：Bleach 白名单清洗正文，移除脚本、事件属性、危险协议和白名单外标签。
5. `rewrite_links`：相对 `.md`/`.markdown`/`.mdown`/`.mkdn` 链接改写为 `.html`，保留 query 和 fragment。
6. `postprocess_tables` / `postprocess_images`：表格加 `.md-table` 与 `.table-wrap`，图片加 `.md-image`。
7. `external_links_safe`：`http(s)` 链接补 `target="_blank"` 与 `rel="noopener noreferrer"`。

## 安全边界

- 链接与 reparse point：`linklike` 用 `lstat()` + `stat.S_ISLNK`（以及 Windows
  `FILE_ATTRIBUTE_REPARSE_POINT`）判断，绝不跟随链接；输入根、输出根、输出父目录和目标文件逐一校验。
- 输出目录不再提前 `resolve()`：否则符号链接会被跟随到目标而绕过链接检查。
- 原子写入：临时文件写入 → `fsync` → `os.replace`，并 `fsync` 父目录；已有链接、非普通文件或
  硬链接数大于 1 的目标拒绝写入。
- 输出碰撞：同一批次内多个源文件映射到同一输出路径时，在写任何文件或创建输出目录之前报
  `output_collision`。
- 输出目录在碰撞预检与 dry-run 通过之后才创建。
- 跳过：隐藏文件/目录（`.` 前缀）、符号链接、非目标扩展名。
- 不做的事：不扫描 Downloads 或家目录、不联网、不 `pip install`、不执行 Markdown 中的内容。

## 限制常量

| 常量 | 值 | 含义 |
|---|---|---|
| `MAX_FILES` | 5000 | 目录条目上限（`directory_entry_limit`）与 Markdown 文件数上限（`markdown_file_limit`） |
| `MAX_FILE_BYTES` | 16 MiB | 单个输入文件上限 |
| `MAX_TOTAL_BYTES` | 256 MiB | 单批输入总字节上限 |
| `MAX_REPORT_BYTES` | 16 MiB | 报告上限 |

## 安全模式与增强脚本

- `sanitize=True`（默认）：正文清洗，且**不注入** TOC 增强 `<script>`，因此输出中不含任何脚本文本。
  静态锚点目录照常生成。
- `--unsafe-raw-html`（`sanitize=False`）：保留原始 HTML，并注入折叠/进度/高亮增强脚本。
