# r2explorer-share 排错与经验（2026-10-09 实战沉淀）

针对 `https://disk.allez.cc.cd`（R2 Explorer **v1.1.10**）的实测经验。
通用 API 形状见 [api.md](api.md)。

## 1. Cloudflare 按浏览器指纹拦截（error 1010）

**症状**：Python `urllib` 默认 UA 请求返回 `HTTP 403 error code: 1010`，
而 curl 同样请求却正常（401）。

**原因**：Cloudflare 按浏览器签名 ban 非浏览器请求。

**处理**：所有请求强制带浏览器 UA（已写入 `bin/r2x.py` 的 `_req`）：
`Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36`

## 2. 凭据环境变量没传到执行环境

**症状**：用户说配好了 `R2X_USER`/`R2X_PASS`，但 exec 里 `env | grep R2X_` 为空，
`~/.bashrc` 和 `~/workspace/skills/.env` 里也没有 → 持续 401。

**处理**：`bin/r2x.py` 启动时按优先级加载凭据：
① 进程环境变量 → ② `~/workspace/skills/.env`（600 权限，打包时排除）。
以后配一次 `.env` 即可，不依赖外部环境注入。

## 3. connector 建不了（Basic Auth 不支持）

`credentials.request_api_access` 对 `auth_scheme: "password"` 直接 declined：
R2 Explorer 是用户名+密码的 Basic Auth，不属于 API key 类 connector。
**结论**：别在这上面浪费时间，直接走 `.env` 文件；
`muse.ai/connect/browser-credentials` 页面提交卡住是产品侧问题，同样绕行 `.env`。

## 4. v1.1.10 分享接口与最新文档不一致

最新文档（r2explorer.com）写的是 `POST /api/buckets/:bucket/:base64Key/share`，
但 v1.1.10 实际路由是：

```
POST /api/buckets/:bucket/share
Content-Type: application/json
{"key": "docs/report.pdf", "customMetadata": {}, "httpMetadata": {},
 "expiresIn": 3600, "password": "x", "maxDownloads": 10}
```

- key 在 **body 里用明文**（非 path、非 base64）
- `customMetadata` / `httpMetadata` 必填（可为空对象），缺了报 400 且错误信息很明确
- 判定时看 400 的 `errors[].path`，按提示补字段即可

## 5. 分享子系统服务端 500（2026-10-09 实测）

**症状**：`share`（创建）、`shares`（列表）、`revoke`（撤销）、`delete`（删除）
全部返回 `500` 空响应体；换 key 格式、补字段均无效。

**判定**：服务端问题，非调用方式错误。佐证：
- `GET /api/buckets/:bucket/shares` 不带任何参数也 500
- 该版本管理台 UI 的 "Get sharable link" 只是复制**带鉴权**的文件 URL，
  根本没有调用公开分享接口

**处理**：`r2x.py share/shares/revoke` 已按 v1.1.10 的正确形状实现，
服务端修复或升级后可直接用；现阶段公开分享需求无解，不要反复重试。

## 6. `ls` 带 prefix 参数 500

`GET /api/buckets/:bucket?prefix=xxx` 在该部署上 500。
**处理**：不带参数全量列出，在客户端按前缀过滤（`r2x.py ls` 已这样做）。

## 7. Key 的 base64 编码规则

- 上传：`POST /api/buckets/:bucket/upload?key=<base64>`，
  key = `base64(utf-8)` 再 URL 转义（`_b64key()`）
- 下载：`GET /api/buckets/:bucket/<base64key>`（path 段同样编码）
- 服务端用 `decodeURIComponent(escape(atob(key)))` 解码，即 base64 套 UTF-8

## 8. GitHub 中文/# 文件名下载

`download_url` 含中文或 `#` 时 `urllib` 直接报
`URL can't contain control characters` / `#` 被当成 fragment 截断。

**处理**：不用 `download_url`，改调 Contents API 逐个取：

```python
path = "youtube/" + urllib.parse.quote(filename, safe="")  # safe="" 让 # → %23
url = f"https://api.github.com/repos/{repo}/contents/{path}?ref=main"
req = Request(url, headers={"Authorization": f"Bearer {token}",
                            "Accept": "application/vnd.github.raw"})
```

## 9. 迁移检查清单（GitHub → R2）

1. `GET /repos/{repo}/contents/{dir}?per_page=100` 拿文件列表（含 `size`）
2. 逐个下载（注意上面的文件名编码坑），落到本地临时目录
3. `r2x.py upload <file> --key "Youtube/<filename>"` 逐个上传
4. `r2x.py ls` 全量列出，核对 16/16 且 size 一致
5. 删临时目录；测试文件若删不掉（delete 500）记下来告诉用户手动删
