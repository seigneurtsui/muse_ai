"""Portable file handling adapted from the original s2t batch loop."""
from __future__ import annotations

import hashlib
import json
import os
import stat
import tempfile
import time
import unicodedata
import uuid
from pathlib import Path

from conversion_core import ConversionError, decode_document, encode_document, normalize_document, srt_dialogue_ranges

SUPPORTED_EXTS = {".txt", ".md", ".markdown", ".srt"}
MAX_FILE_BYTES = 16 * 1024 * 1024
MAX_BATCH_BYTES = 128 * 1024 * 1024
MAX_FILES = 5000


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def linklike(path: Path) -> bool:
    info = path.lstat()
    return stat.S_ISLNK(info.st_mode) or bool(getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))


def portable_key(path: Path) -> str:
    return unicodedata.normalize("NFC", str(path.resolve(strict=False))).casefold()


def collect_text_files(source: Path, recursive: bool, output: Path) -> tuple[list[Path], list[dict], Path]:
    source = source.expanduser().absolute()
    if not source.exists() or linklike(source):
        raise ConversionError("input_missing_or_link")
    if source.is_file():
        if source.suffix.lower() not in SUPPORTED_EXTS:
            raise ConversionError("unsupported_file_extension")
        return [source.resolve()], [], source.parent.resolve()
    if not source.is_dir():
        raise ConversionError("input_not_directory_or_file")
    root = source.resolve()
    if output.resolve(strict=False) == root:
        raise ConversionError("output_directory_equals_input")
    files, excluded = [], []
    visited = 0
    def walk(directory: Path, depth: int):
        nonlocal visited
        if depth > 32:
            raise ConversionError("directory_depth_limit")
        if linklike(directory) or not directory.resolve().is_relative_to(root):
            raise ConversionError("input_directory_changed_or_link")
        for item in sorted(directory.iterdir(), key=lambda p: p.name):
            visited += 1
            if visited > 50000:
                raise ConversionError("directory_entry_limit")
            if linklike(item):
                excluded.append({"path": str(item.relative_to(root)), "reason": "link_not_followed"})
                continue
            if item.resolve(strict=False) == output.resolve(strict=False):
                excluded.append({"path": str(item.relative_to(root)), "reason": "output_directory_excluded"})
                continue
            if item.name.startswith(".") or item.name in {"node_modules", "__pycache__"}:
                continue
            if item.is_dir() and recursive:
                walk(item, depth + 1)
            elif item.is_file() and item.suffix.lower() in SUPPORTED_EXTS:
                files.append(item)
                if len(files) > MAX_FILES:
                    raise ConversionError("file_count_limit")
    walk(root, 0)
    return sorted(files), excluded, root


def read_input(path: Path, root: Path) -> bytes:
    if linklike(path) or not path.resolve().is_relative_to(root):
        raise ConversionError("input_changed_or_link")
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_FILE_BYTES:
            raise ConversionError("input_not_regular_or_over_16_mib")
        with os.fdopen(fd, "rb", closefd=False) as stream:
            raw = stream.read(MAX_FILE_BYTES + 1)
        if len(raw) > MAX_FILE_BYTES:
            raise ConversionError("input_over_16_mib")
        return raw
    finally:
        os.close(fd)


def safe_output_root(output: Path) -> Path:
    output = output.expanduser().absolute()
    if output.exists() or output.is_symlink():
        if linklike(output) or not output.is_dir():
            raise ConversionError("output_root_not_regular_directory")
    return output.resolve(strict=False)


def ensure_parent(root: Path, parent: Path) -> None:
    if not parent.is_relative_to(root):
        raise ConversionError("destination_outside_output")
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    if linklike(root):
        raise ConversionError("output_root_is_link")
    current = root
    for part in parent.relative_to(root).parts:
        current = current / part
        current.mkdir(exist_ok=True, mode=0o700)
        if linklike(current) or not current.is_dir():
            raise ConversionError("output_parent_is_link")


def check_destination(destination: Path, sources: list[Path], replace: bool, source_index=None) -> None:
    if source_index is None:
        source_index = ({portable_key(p) for p in sources}, {(p.stat().st_dev, p.stat().st_ino) for p in sources})
    source_keys, source_ids = source_index
    if portable_key(destination) in source_keys:
        raise ConversionError("refusing_to_overwrite_input")
    if destination.exists() or destination.is_symlink():
        if linklike(destination) or not destination.is_file():
            raise ConversionError("output_is_link_or_not_file")
        info = destination.stat()
        if (info.st_dev, info.st_ino) in source_ids:
            raise ConversionError("output_aliases_input")
        if not replace:
            raise ConversionError("output_exists_use_replace_only_if_authorized")


def atomic_write(path: Path, raw: bytes, replace: bool = False) -> None:
    """Same-directory temp + atomic replace; exclusive reservation prevents clobbering.

    Reservation works on Windows/exFAT without requiring hardlink support. A hard
    process kill before replace can leave an empty reserved file; it is never
    reported as success and a later run will not silently overwrite it.
    """
    fd, name = tempfile.mkstemp(prefix=".s2t-", suffix=".tmp", dir=path.parent)
    temp = Path(name)
    reserved = None
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        if not replace:
            reserve_fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0), 0o600)
            try:
                reserved = os.fstat(reserve_fd)
            finally:
                os.close(reserve_fd)
            now = path.lstat()
            if (now.st_dev, now.st_ino) != (reserved.st_dev, reserved.st_ino) or linklike(path) or now.st_size:
                raise ConversionError("output_reservation_changed")
        elif path.exists() and linklike(path):
            raise ConversionError("output_changed_to_link")
        os.replace(temp, path)
        reserved = None
    finally:
        if temp.exists():
            temp.unlink()
        if reserved is not None:
            try:
                now = path.lstat()
                if (now.st_dev, now.st_ino) == (reserved.st_dev, reserved.st_ino) and now.st_size == 0 and not linklike(path):
                    path.unlink()
            except FileNotFoundError:
                pass


def reason(error: Exception) -> str:
    code = getattr(error, "code", None)
    if isinstance(code, str) and code.replace("_", "").isalnum() and len(code) < 100:
        return code
    if isinstance(error, PermissionError):
        return "permission_denied"
    if isinstance(error, FileExistsError):
        return "output_exists"
    return "file_operation_failed"


def run_batch(args, engine_factory) -> tuple[dict, int]:
    output = safe_output_root(args.output)
    if any(ch in args.suffix for ch in '/\\:*?"<>|') or any(ord(ch) < 32 for ch in args.suffix) or len(args.suffix) > 80:
        raise ConversionError("invalid_suffix")
    files, excluded, root = collect_text_files(args.input, args.recursive, output)
    suffix = "" if args.overwrite else args.suffix
    jobs = [(src, output / src.relative_to(root).parent / (src.stem + suffix + src.suffix)) for src in files]
    keys = [portable_key(dst) for _, dst in jobs]
    if len(set(keys)) != len(keys):
        raise ConversionError("portable_output_name_collision")
    report = {"status": "dry_run" if args.dry_run else "complete", "mode": args.mode,
              "input": str(args.input.expanduser().absolute()), "output": str(output),
              "recursive": args.recursive, "strict": args.strict, "excluded": excluded,
              "total": len(jobs), "results": []}
    if not jobs:
        report.update(reason="no_supported_files", converted=0, unchanged=0, planned=0, needs_review=0, failed=0)
        return report, 0
    engine = None
    source_index = ({portable_key(p) for p in files}, {(p.stat().st_dev, p.stat().st_ino) for p in files})
    lock = output / ".s2t.lock"
    acquired = False
    total_bytes = 0
    budget_exhausted = False
    started = time.monotonic()
    try:
        if not args.dry_run or args.preview:
            engine = engine_factory(args.mode, args.engine)
        if not args.dry_run:
            ensure_parent(output, output)
            try:
                lock.mkdir(mode=0o700)
            except FileExistsError:
                raise ConversionError("output_locked_review_before_removing_lock") from None
            acquired = True
            atomic_write(lock / "owner.json", json.dumps({"pid": os.getpid(), "created_at": time.time()}).encode())
        for src, dst in jobs:
            row = {"source": str(src), "destination": str(dst)}
            try:
                check_destination(dst, files, args.replace, source_index)
                if budget_exhausted or total_bytes + src.stat().st_size > MAX_BATCH_BYTES:
                    budget_exhausted = True
                    raise ConversionError("batch_over_128_mib")
                raw = read_input(src, root)
                total_bytes += len(raw)
                if total_bytes > MAX_BATCH_BYTES:
                    budget_exhausted = True
                    raise ConversionError("batch_over_128_mib")
                doc = decode_document(raw, args.encoding)
                fmt = "srt" if src.suffix.lower() == ".srt" else "text"
                if fmt == "srt":
                    srt_dialogue_ranges(doc.text)
                row.update(input_encoding=doc.encoding, input_bom=doc.bom.hex() or None,
                           source_sha256=digest(raw), input_bytes=len(raw), input_chars=len(doc.text), format=fmt)
                if args.dry_run and not args.preview:
                    row["status"] = "planned"
                else:
                    converted, checks = normalize_document(doc.text, engine, args.mode, fmt)
                    row.update(checks=checks, engine=engine.metadata(), output_chars=len(converted))
                    if args.preview:
                        row["preview"] = {"before": doc.text[:200], "after": converted[:200]}
                    needs_review = checks["passed"] is False
                    if needs_review and args.strict:
                        row.update(status="failed", reason="glyph_confirmation_failed_no_output")
                    else:
                        encoded = encode_document(converted, doc, args.output_encoding)
                        row.update(output_encoding=doc.encoding if args.output_encoding == "same" else "utf-8",
                                   output_bytes=len(encoded), output_sha256=digest(encoded))
                        if args.dry_run:
                            row["status"] = "needs_review" if needs_review else "previewed"
                        else:
                            ensure_parent(output, dst.parent)
                            check_destination(dst, files, args.replace, source_index)
                            if digest(read_input(src, root)) != row["source_sha256"]:
                                raise ConversionError("source_changed_during_conversion")
                            atomic_write(dst, encoded, args.replace)
                            row["status"] = "needs_review" if needs_review else "unchanged" if raw == encoded else "converted"
            except Exception as error:
                row.update(status="failed", reason=reason(error))
            report["results"].append(row)
        for state in ("converted", "unchanged", "planned", "previewed", "needs_review", "failed"):
            report[state] = sum(row["status"] == state for row in report["results"])
        report["elapsed_seconds"] = round(time.monotonic() - started, 3)
        if engine:
            report["engine"] = engine.metadata()
        if not args.dry_run:
            try:
                report_dir = output / ".s2t-reports"
                ensure_parent(output, report_dir)
                report_file = report_dir / (time.strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:12] + ".json")
                report["report_path"] = str(report_file)
                atomic_write(report_file, (json.dumps(report, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
            except Exception as error:
                report.pop("report_path", None)
                report.update(status="report_error", report_error=reason(error))
                return report, 2
        return report, 1 if report["failed"] or report["needs_review"] else 0
    finally:
        try:
            if engine:
                engine.close()
        finally:
            if acquired:
                (lock / "owner.json").unlink(missing_ok=True)
                lock.rmdir()
