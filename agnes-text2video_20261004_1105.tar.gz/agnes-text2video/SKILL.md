---
name: agnes-text2video
description: "Use Agnes AI models to generate images and videos from text prompts. Supports text-to-image with customizable sizes and text-to-video with async task polling. Default output: ~/Downloads/text2video"
---

# Agnes AI Text-to-Image & Text-to-Video

Use this skill when the user wants to generate images or videos from text descriptions using the Agnes AI API. The skill wraps the Agnes AI API endpoints with convenient CLI tools.

## Prerequisites

- `AGNES_API_KEY` must be set in the environment (from `.env`)
- Node.js 18+ for the scripts
- Default output directory: `~/Downloads/text2video`

## Available Models

| Model | Purpose |
|-------|---------|
| `agnes-image-2.1-flash` | Image generation (text-to-image, image-to-image) |
| `agnes-image-2.0-flash` | Image generation (older) |
| `agnes-video-v2.0` | Video generation (text-to-video, image-to-video, keyframes) |
| `agnes-2.0-flash` | Text chat / prompt expansion |
| `agnes-1.5-flash` | Text chat (older) |

## Usage

### Generate Image

```bash
node SKILL_DIR/scripts/text2image.mjs --prompt "A cinematic product shot of a silver watch on black stone"
```

Optional flags:
- `--model` — model name (default: `agnes-image-2.1-flash`)
- `--size` — dimensions like `2048x2048` (default: `2048x2048`)
- `--output` — output filename (auto-generated if omitted)
- `--dir` — output directory (default: `~/Downloads/text2video`)

### Generate Video

```bash
node SKILL_DIR/scripts/text2video.mjs --prompt "A cinematic drone shot of waves at dusk"
```

Optional flags:
- `--model` — model name (default: `agnes-video-v2.0`)
- `--width` — video width (default: `1920`)
- `--height` — video height (default: `1080`)
- `--num-frames` — frame count, must be 8n+1, ≤441 (default: `241`)
- `--frame-rate` — FPS 1–60 (default: `24`)
- `--negative-prompt` — what to avoid
- `--poll-interval` — seconds between status polls (default: `5`)
- `--max-wait` — max seconds to wait (default: `900`)
- `--dir` — output directory (default: `~/Downloads/text2video`)

### Expand Prompt via Chat

```bash
node SKILL_DIR/scripts/chat.mjs --prompt "a cat walking on a beach at sunset, cinematic"
```
