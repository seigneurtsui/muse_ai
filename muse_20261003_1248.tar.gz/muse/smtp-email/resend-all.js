const nodemailer = require('nodemailer');
const fs = require('fs');

const config = JSON.parse(fs.readFileSync('/home/seiyacui/.config/opencode/skills/smtp-email/config.json', 'utf8'));
const transporter = nodemailer.createTransport({
  host: config.host,
  port: 465,
  secure: true,
  auth: { user: config.user, pass: config.pass }
});

const mdPath = '/home/seiyacui/Downloads/voyagePlanner/brunei15d-南阳出发.md';
const mdContent = fs.readFileSync(mdPath, 'utf8');

async function main() {
  // 1. Brunei 行程书
  await transporter.sendMail({
    from: config.from, to: 'gc40800@gmail.com',
    subject: '🗺️ 婆罗洲大环线 15日行程书（含完整附件）',
    html: '<p>行程书附件请查收</p>',
    attachments: [{ filename: 'brunei15d-南阳出发.md', content: mdContent, contentType: 'text/markdown; charset=utf-8' }]
  });
  console.log('✅ 1/3 行程书 sent');

  // 2. travel-manager skill
  await transporter.sendMail({
    from: config.from, to: 'gc40800@gmail.com',
    subject: '📦 travel-manager skill 打包',
    html: '<p>trip-planner-0to1 完整文件夹</p>',
    attachments: [{ filename: 'travel-manager.tar.gz', content: fs.readFileSync('/home/seiyacui/.config/opencode/skills/travel-manager.tar.gz' || ''), contentType: 'application/gzip' }]
  });

  // 3. trip-planner-0to1 skill
  await transporter.sendMail({
    from: config.from, to: 'gc40800@gmail.com',
    subject: '📦 trip-planner-0to1 skill 打包',
    html: '<p>trip-planner-0to1 完整文件夹</p>',
    attachments: [{ filename: 'trip-planner-0to1.tar.gz', contentType: 'application/gzip' }]
  });
  console.log('✅ 3/3 all sent');
}
main().catch(e => { console.error('❌', e.message); process.exit(1); });
