#!/usr/bin/env python3
"""Live, no-API-key 12306 direct-train and bounded transfer query.

This deliberately supports search only. It does not log in, book, or pay.
"""
from __future__ import annotations

import argparse
import gzip
import json
import re
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from http.cookiejar import CookieJar
from pathlib import Path
from urllib.error import HTTPError, URLError
from zoneinfo import ZoneInfo

BASE = "https://kyfw.12306.cn"
STATION_JS = f"{BASE}/otn/resources/js/framework/station_name.js"
CACHE_DIR = Path(__file__).resolve().parent / ".cache"
STATION_CACHE = CACHE_DIR / "stations.json"
QUERY_PATH_CACHE = CACHE_DIR / "query-path.json"
STATION_CACHE_TTL = 24 * 60 * 60
QUERY_PATH_CACHE_TTL = 60 * 60
RETRY_DELAYS = (0.5, 1.5)
UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/131 Safari/537.36"
HEADERS = {
    "User-Agent": UA,
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Referer": f"{BASE}/otn/leftTicket/init",
    "X-Requested-With": "XMLHttpRequest",
}

# 12306's pipe-delimited response fields used by this script.
FIELD = {
    "train_no": 2,
    "train_code": 3,
    "from_code": 6,
    "to_code": 7,
    "start_time": 8,
    "arrive_time": 9,
    "duration": 10,
    "start_date": 13,
    "yz": 29,
    "ze": 30,
    "zy": 31,
    "swz": 32,
    "srrb": 33,
    "price_info": 39,
    "flags": 46,
    "seat_types": 35,
}
SEATS = {
    "9": ("商务座", "swz"), "P": ("特等座", "tz"), "M": ("一等座", "zy"),
    "D": ("优选一等座", "zy"), "O": ("二等座", "ze"), "S": ("二等包座", "ze"),
    "4": ("软卧", "rw"), "I": ("一等卧", "rw"), "F": ("动卧", "rw"),
    "3": ("硬卧", "yw"), "J": ("二等卧", "yw"), "2": ("软座", "rz"),
    "1": ("硬座", "yz"), "W": ("无座", "wz"), "H": ("其他", "qt"),
}
STATUS_FIELDS = {"swz": 32, "zy": 31, "ze": 30, "yz": 29, "yw": 28, "rw": 23, "wz": 26}

# Automatic transfer searches stay deliberately bounded.  Users can replace
# this list with --transfer-stations when a smaller/local interchange is more
# appropriate.
DEFAULT_TRANSFER_CITIES = ("郑州东", "武汉", "西安北", "南京南")
MAX_TRANSFER_CANDIDATES = 6
DEFAULT_MIN_TRANSFER_MINUTES = 30
DEFAULT_MAX_TRANSFER_MINUTES = 360
DEFAULT_MAX_TOTAL_MINUTES = 24 * 60


def fail(message: str) -> None:
    print(f"错误：{message}", file=sys.stderr)
    raise SystemExit(2)


def get_opener() -> urllib.request.OpenerDirector:
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(CookieJar()))


def request(opener: urllib.request.OpenerDirector, url: str, params: dict[str, str] | None = None) -> bytes:
    if params:
        url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
    last_error: Exception | None = None
    for attempt in range(len(RETRY_DELAYS) + 1):
        req = urllib.request.Request(url, headers=HEADERS)
        try:
            with opener.open(req, timeout=25) as response:
                body = response.read()
                if response.headers.get("Content-Encoding", "").lower() == "gzip":
                    body = gzip.decompress(body)
                return body
        except (HTTPError, URLError, TimeoutError, OSError) as exc:
            last_error = exc
            retryable = not isinstance(exc, HTTPError) or exc.code == 429 or exc.code >= 500
            if attempt < len(RETRY_DELAYS) and retryable:
                time.sleep(RETRY_DELAYS[attempt])
                continue
            break
    fail(f"访问 12306 失败（可能是网络、频率限制或站点临时不可用，已重试）：{last_error}")


def text_request(opener: urllib.request.OpenerDirector, url: str, params: dict[str, str] | None = None) -> str:
    return request(opener, url, params).decode("utf-8-sig", errors="replace")


def json_request(opener: urllib.request.OpenerDirector, url: str, params: dict[str, str] | None = None):
    last_error: Exception | None = None
    for attempt in range(len(RETRY_DELAYS) + 1):
        try:
            return json.loads(text_request(opener, url, params))
        except json.JSONDecodeError as exc:
            last_error = exc
            if attempt < len(RETRY_DELAYS):
                time.sleep(RETRY_DELAYS[attempt])
                continue
            break
    fail(f"12306 返回了网页或无效数据（可能是临时限流/网络错误，已重试）：{last_error}")


def read_cache(path: Path, ttl: int):
    try:
        if time.time() - path.stat().st_mtime <= ttl:
            return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, OSError, json.JSONDecodeError):
        return None
    return None


def write_cache(path: Path, value):
    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
        temporary.replace(path)
    except OSError:
        pass


def stations_from_data(data: dict[str, dict[str, str]]) -> tuple[dict[str, dict[str, str]], dict[str, list[dict[str, str]]]]:
    cities: dict[str, list[dict[str, str]]] = {}
    for item in data.values():
        if item.get("city"):
            cities.setdefault(item["city"], []).append(item)
    return data, cities


def load_stations(opener: urllib.request.OpenerDirector, refresh: bool = False) -> tuple[dict[str, dict[str, str]], dict[str, list[dict[str, str]]]]:
    if not refresh:
        cached = read_cache(STATION_CACHE, STATION_CACHE_TTL)
        if isinstance(cached, dict) and cached:
            return stations_from_data(cached)
    raw = text_request(opener, STATION_JS)
    match = re.search(r"station_names\s*=\s*'([^']+)'", raw)
    if not match:
        fail("无法解析 12306 车站数据")
    stations: dict[str, dict[str, str]] = {}
    cities: dict[str, list[dict[str, str]]] = {}
    parts = match.group(1).split("|")
    for i in range(0, len(parts) - 9, 10):
        if not parts[i].startswith("@"):
            continue
        item = {
            "name": re.sub(r"\s+", "", parts[i + 1]),
            "code": parts[i + 2],
            "pinyin": parts[i + 3],
            "short": parts[i + 4],
            "city": re.sub(r"\s+", "", parts[i + 7]),
        }
        if item["code"]:
            stations[item["code"]] = item
            if item["city"]:
                cities.setdefault(item["city"], []).append(item)
    if not stations:
        fail("12306 车站数据为空")
    write_cache(STATION_CACHE, stations)
    return stations, cities


def resolve_station(value: str, stations: dict[str, dict[str, str]], cities: dict[str, list[dict[str, str]]]) -> dict[str, str]:
    value = value.strip()
    upper = value.upper()
    if upper in stations:
        return stations[upper]
    normalized = re.sub(r"\s+", "", value.removesuffix("站"))
    for item in stations.values():
        if item["name"] == normalized:
            return item
    candidates = cities.get(normalized, [])
    if candidates:
        # Prefer the station whose name equals the city; otherwise the first main station.
        return next((item for item in candidates if item["name"] == normalized), candidates[0])
    fail(f"找不到车站或城市：{value}")


def get_query_path(opener: urllib.request.OpenerDirector, refresh: bool = False) -> str:
    if not refresh:
        cached = read_cache(QUERY_PATH_CACHE, QUERY_PATH_CACHE_TTL)
        if isinstance(cached, dict) and cached.get("path"):
            return cached["path"]
    html = text_request(opener, f"{BASE}/otn/leftTicket/init")
    match = re.search(r"CLeftTicketUrl\s*=\s*'([^']+)'", html)
    path = "/otn/" + match.group(1).lstrip("/") if match else "/otn/leftTicket/queryG"
    write_cache(QUERY_PATH_CACHE, {"path": path})
    return path


def status(value: str) -> str:
    value = (value or "").strip()
    if value.isdigit():
        return "无票" if value == "0" else f"余{value}张"
    if value in {"有", "充足"}:
        return "有票"
    if value in {"无", "--", ""}:
        return "无票"
    if value == "候补":
        return "候补"
    return value


def parse_prices(row: list[str]) -> list[dict[str, object]]:
    encoded = row[FIELD["price_info"]] if len(row) > FIELD["price_info"] else ""
    result: list[dict[str, object]] = []
    for i in range(0, len(encoded) - 9, 10):
        chunk = encoded[i : i + 10]
        try:
            code = chunk[0]
            price = int(chunk[1:6]) / 10
        except ValueError:
            continue
        if code not in SEATS:
            continue
        name, short = SEATS[code]
        seat_index = STATUS_FIELDS.get(short)
        candidate = {"seat": name, "price": price, "availability": status(row[seat_index] if seat_index is not None and len(row) > seat_index else "")}
        if candidate not in result:
            result.append(candidate)
    return result


def parse_row(raw: str, name_map: dict[str, str]) -> dict[str, object] | None:
    row = raw.split("|")
    if len(row) < 40 or not row[FIELD["train_code"]]:
        return None
    from_code = row[FIELD["from_code"]]
    to_code = row[FIELD["to_code"]]
    return {
        "train": row[FIELD["train_code"]],
        "from": name_map.get(from_code, from_code),
        "to": name_map.get(to_code, to_code),
        "from_code": from_code,
        "to_code": to_code,
        "departure": row[FIELD["start_time"]],
        "arrival": row[FIELD["arrive_time"]],
        "duration": row[FIELD["duration"]],
        "date": row[FIELD["start_date"]],
        "prices": parse_prices(row),
        "tags": [tag for tag in ("复兴号" if len(row) > FIELD["flags"] and "1" in row[FIELD["flags"]].split("#")[:2] else "",) if tag],
    }

def _duration_minutes(value: object) -> int | None:
    match = re.fullmatch(r"(\d+):(\d{2})", str(value or "").strip())
    if not match:
        return None
    return int(match.group(1)) * 60 + int(match.group(2))


def _clock_datetime(date_value: object, clock_value: object) -> datetime | None:
    try:
        raw_date = str(date_value)
        day = datetime.strptime(raw_date, "%Y%m%d" if re.fullmatch(r"\d{8}", raw_date) else "%Y-%m-%d").date()
        hour, minute = map(int, str(clock_value).split(":")[:2])
        return datetime(day.year, day.month, day.day, hour, minute)
    except (TypeError, ValueError):
        return None


def _leg_times(leg: dict[str, object]) -> tuple[datetime, datetime] | None:
    departure = _clock_datetime(leg.get("date"), leg.get("departure"))
    duration = _duration_minutes(leg.get("duration"))
    if departure is None or duration is None:
        return None
    return departure, departure + timedelta(minutes=duration)


def _station_key(item: dict[str, object], side: str) -> str:
    code = item.get(f"{side}_code")
    return str(code or item.get(side) or "").strip().upper()


def _format_duration(minutes: int) -> str:
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def _combined_prices(first: dict[str, object], second: dict[str, object]) -> list[dict[str, object]]:
    """Combine matching seat fares without claiming a single-seat inventory."""
    first_prices = {str(item.get("seat")): item for item in first.get("prices", []) if isinstance(item, dict)}
    second_prices = {str(item.get("seat")): item for item in second.get("prices", []) if isinstance(item, dict)}
    combined = []
    for seat in first_prices.keys() & second_prices.keys():
        left, right = first_prices[seat], second_prices[seat]
        try:
            price = float(left["price"]) + float(right["price"])
        except (KeyError, TypeError, ValueError):
            continue
        statuses = {str(left.get("availability", "")), str(right.get("availability", ""))}
        if "无票" in statuses:
            availability = "无票"
        elif "候补" in statuses:
            availability = "候补"
        else:
            all_available = all(value == '有票' or re.fullmatch(r'余[1-9]\d*张', value) for value in statuses)
            availability = '分段均有票' if all_available else '未提供'
        combined.append({"seat": seat, "price": price, "availability": availability})
    return sorted(combined, key=lambda item: str(item["seat"]))


def combine_transfer_results(
    first_legs: list[dict[str, object]],
    second_legs: list[dict[str, object]],
    transfer_station: str,
    *,
    min_transfer_minutes: int = DEFAULT_MIN_TRANSFER_MINUTES,
    max_transfer_minutes: int = DEFAULT_MAX_TRANSFER_MINUTES,
    max_total_minutes: int = DEFAULT_MAX_TOTAL_MINUTES,
) -> list[dict[str, object]]:
    """Join two already-fetched direct-leg result sets at one station.

    This is intentionally pure so callers and tests can compose saved 12306
    responses without network access.  Both legs must use the same transfer
    station, have a real schedule, and satisfy the wait/total-time bounds.
    """
    joined: list[dict[str, object]] = []
    seen = set()
    for first in first_legs:
        # A city query can return several stations. Join only the ACTUAL same
        # station code, not the city code used for the request.
        station_key = _station_key(first, "to")
        if not station_key:
            continue
        first_times = _leg_times(first)
        if first_times is None or _station_key(first, "from") == station_key:
            continue
        for second in second_legs:
            if _station_key(second, "from") != station_key:
                continue
            if _station_key(second, "to") in {station_key, _station_key(first, "from")}:
                continue
            second_times = _leg_times(second)
            if second_times is None or second_times[0] <= first_times[1]:
                continue
            wait = int((second_times[0] - first_times[1]).total_seconds() // 60)
            total = int((second_times[1] - first_times[0]).total_seconds() // 60)
            if wait < min_transfer_minutes or wait > max_transfer_minutes or total > max_total_minutes:
                continue
            trains = (str(first.get("train", "")), str(second.get("train", "")))
            key = (trains[0], trains[1], station_key, first_times[0], second_times[0])
            if not trains[0] or not trains[1] or trains[0] == trains[1] or key in seen:
                continue
            seen.add(key)
            joined.append({
                "train": f"{trains[0]} + {trains[1]}",
                "from": first.get("from", ""),
                "to": second.get("to", ""),
                "from_code": first.get("from_code", ""),
                "to_code": second.get("to_code", ""),
                "departure": first.get("departure", ""),
                "arrival": second_times[1].strftime("%H:%M"),
                "date": first_times[0].date().isoformat(),
                "departure_datetime": first_times[0].isoformat(),
                "arrival_datetime": second_times[1].isoformat(),
                "duration": _format_duration(total),
                "total_duration": total,
                "transfer_count": 1,
                "transfer_station": first.get("to") or transfer_station,
                "transfer_wait": _format_duration(wait),
                "transfer_wait_minutes": wait,
                "prices": _combined_prices(first, second),
                "tags": ["中转"],
                "legs": [first, second],
            })
    joined.sort(key=lambda item: (int(item["total_duration"]), str(item["arrival"]), int(item["transfer_wait_minutes"])))
    return joined


def _filter_results(results: list[dict[str, object]], args: argparse.Namespace) -> list[dict[str, object]]:
    if args.kind:
        kinds = tuple(args.kind.upper())
        results = [item for item in results if str(item["train"])[0].upper() in kinds or ("G" in kinds and str(item["train"])[0].upper() == "C")]
    results.sort(key=lambda item: str(item["departure"]))
    return results


def _query_leg(
    opener: urllib.request.OpenerDirector,
    path: str,
    stations: dict[str, dict[str, str]],
    origin: dict[str, str],
    destination: dict[str, str],
    date: str,
    args: argparse.Namespace,
) -> list[dict[str, object]]:
    payload = json_request(opener, f"{BASE}{path}", {
        "leftTicketDTO.train_date": date,
        "leftTicketDTO.from_station": origin["code"],
        "leftTicketDTO.to_station": destination["code"],
        "purpose_codes": "ADULT",
    })
    data = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(data, dict) or payload.get("status") is False or not isinstance(data.get("result"), list):
        fail("12306 返回查询失败或无法识别的数据；不能据此判断无票")
    rows = data["result"]
    name_map = data.get("map") or {code: item["name"] for code, item in stations.items()}
    results = [item for raw in rows if isinstance(raw, str) and (item := parse_row(raw, name_map))]
    for item in results:
        # Field 13 is the train's origin service date, not necessarily the
        # boarding date at the requested station. The request supplies that.
        item["service_date"] = item["date"]
        item["date"] = date
    return _filter_results(results, args)


def _candidate_stations(
    args: argparse.Namespace,
    stations: dict[str, dict[str, str]],
    cities: dict[str, list[dict[str, str]]],
    origin: dict[str, str],
    destination: dict[str, str],
) -> list[dict[str, str]]:
    raw_values = re.split(r"[,，]", args.transfer_stations) if args.transfer_stations else list(DEFAULT_TRANSFER_CITIES)
    result: list[dict[str, str]] = []
    seen: set[str] = set()
    endpoint_codes = {origin["code"], destination["code"]}
    for raw in raw_values:
        value = raw.strip()
        if not value:
            continue
        try:
            candidate = resolve_station(value, stations, cities)
        except SystemExit:
            if args.transfer_stations:
                raise
            continue
        if candidate["code"] not in endpoint_codes and candidate["code"] not in seen:
            seen.add(candidate["code"])
            result.append(candidate)
    if len(result) > MAX_TRANSFER_CANDIDATES:
        fail(f"候选中转站最多 {MAX_TRANSFER_CANDIDATES} 个，以限制查询频率")
    return result


def search(args: argparse.Namespace) -> list[dict[str, object]]:
    opener = get_opener()
    stations, cities = load_stations(opener, args.refresh_cache)
    origin = resolve_station(args.from_station, stations, cities)
    destination = resolve_station(args.to_station, stations, cities)
    path = get_query_path(opener, args.refresh_cache)
    direct = _query_leg(opener, path, stations, origin, destination, args.date, args)
    if not args.transfers:
        return direct[:args.limit] if args.limit else direct
    if args.max_transfers != 1:
        fail("目前中转模式仅支持一次换乘；请将 --max-transfers 设为 1")
    candidates = _candidate_stations(args, stations, cities, origin, destination)
    transfers: list[dict[str, object]] = []
    for candidate in candidates:
        first = _query_leg(opener, path, stations, origin, candidate, args.date, args)
        departure_dates = set()
        for leg in first:
            times = _leg_times(leg)
            if times is None:
                continue
            earliest = times[1] + timedelta(minutes=args.min_transfer_minutes)
            latest = min(times[1] + timedelta(minutes=args.max_transfer_minutes),
                         times[0] + timedelta(minutes=args.max_total_minutes))
            day = earliest.date()
            while day <= latest.date():
                departure_dates.add(day.isoformat())
                day += timedelta(days=1)
        second = []
        for departure_date in sorted(departure_dates):
            time.sleep(0.2)
            second += _query_leg(opener, path, stations, candidate, destination, departure_date, args)
        combined = combine_transfer_results(
            first,
            second,
            candidate["code"],
            min_transfer_minutes=args.min_transfer_minutes,
            max_transfer_minutes=args.max_transfer_minutes,
            max_total_minutes=args.max_total_minutes,
        )
        transfers.extend(combined)
    transfers.sort(key=lambda item: (int(item["total_duration"]), str(item["arrival"])))
    limit = args.transfer_limit if args.transfer_limit is not None else args.limit
    args._direct_results = direct[:args.limit] if args.limit else direct
    unique = {}
    for item in transfers:
        key = (item["train"], item["transfer_station"], item["departure_datetime"], item["arrival_datetime"])
        unique.setdefault(key, item)
    transfers = list(unique.values())
    return transfers[:limit] if limit else transfers


def main() -> int:
    parser = argparse.ArgumentParser(description="无需 API Key 的 12306 直达/中转换乘查询")
    parser.add_argument("--date", required=True, help="出发日期 YYYY-MM-DD")
    parser.add_argument("--from", dest="from_station", required=True, help="出发城市或车站")
    parser.add_argument("--to", dest="to_station", required=True, help="到达城市或车站")
    parser.add_argument("--kind", default="", help="车次类型，例如 G、D、K；G 同时包含 C")
    parser.add_argument("--refresh-cache", action="store_true", help="忽略本地车站/路径缓存并刷新")
    parser.add_argument("--limit", type=int, default=10, help="最终结果最多返回数量，0 表示全部；分段不提前截断")
    parser.add_argument("--format", choices=("text", "json"), default="text")
    parser.add_argument("--transfers", action="store_true", help="查询中转换乘方案（会先查询一程直达结果）")
    parser.add_argument("--max-transfers", type=int, default=1, help="最多换乘次数；当前支持 1")
    parser.add_argument("--transfer-stations", help="候选中转站/城市，逗号分隔；不传则使用常见枢纽")
    parser.add_argument("--transfer-limit", type=int, help="最多返回中转方案数量，默认跟随 --limit")
    parser.add_argument("--min-transfer-minutes", type=int, default=DEFAULT_MIN_TRANSFER_MINUTES, help="最短换乘等待分钟数，默认 30")
    parser.add_argument("--max-transfer-minutes", type=int, default=DEFAULT_MAX_TRANSFER_MINUTES, help="最长换乘等待分钟数，默认 360")
    parser.add_argument("--max-total-minutes", type=int, default=DEFAULT_MAX_TOTAL_MINUTES, help="单个方案最长总历时分钟数，默认 1440")
    args = parser.parse_args()
    if args.limit < 0 or (args.transfer_limit is not None and args.transfer_limit < 0):
        parser.error("--limit 和 --transfer-limit 不能为负数")
    if not 1 <= args.min_transfer_minutes <= args.max_transfer_minutes <= 720 or not 1 <= args.max_total_minutes <= 2880:
        parser.error("换乘等待须为 1–720 分钟，总历时须为 1–2880 分钟")
    if args.max_transfers != 1:
        parser.error("目前只支持 --max-transfers 1")
    try:
        requested = datetime.strptime(args.date, "%Y-%m-%d").date()
        today = datetime.now(ZoneInfo("Asia/Shanghai")).date()
        if requested < today:
            fail("出发日期不能早于今天")
        results = search(args)
        payload = {
            "source": "12306",
            "query": {"from": args.from_station, "to": args.to_station, "date": args.date, "kind": args.kind},
            "queried_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
            "results": results,
        }
        if args.transfers:
            payload.update({
                "mode": "transfers",
                "direct_results": getattr(args, "_direct_results", []),
                "transfer_constraints": {
                    "min_wait_minutes": args.min_transfer_minutes,
                    "max_wait_minutes": args.max_transfer_minutes,
                    "max_total_minutes": args.max_total_minutes,
                },
            })
        if args.format == "json":
            print(json.dumps(payload, ensure_ascii=False))
        elif results:
            for item in results:
                seats = "；".join(f"{seat['seat']} {seat['price']}元/{seat['availability']}" for seat in item["prices"])
                wait = f"，换乘等待{item['transfer_wait']}" if item.get("transfer_wait") else ""
                print(f"{item['train']}  {item['from']} → {item['to']}  {item['departure']} → {item['arrival']}  历时{item['duration']}{wait}")
                if item.get("transfer_station"):
                    print(f"  中转站：{item['transfer_station']}")
                if seats:
                    print(f"  {seats}")
        else:
            message = "没有查询到合理的中转方案；可指定 --transfer-stations、放宽换乘等待限制或改查直达车次。" if args.transfers else "没有查询到直达车次；可加 --transfers 查询中转方案或放宽车次类型。"
            print(message)
        return 0
    except SystemExit:
        raise
    except Exception as exc:
        fail(str(exc))
    return 2


if __name__ == "__main__":
    main()
