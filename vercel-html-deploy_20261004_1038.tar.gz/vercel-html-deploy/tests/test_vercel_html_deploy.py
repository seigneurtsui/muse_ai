from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import vercel_html_deploy as app

BIG = "<!doctype html><html><body><h1>{title}</h1>" + ("x" * 1200) + "</body></html>"


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        self.state = self.root / "state.json"
        self.env_patch = patch.object(
            app, "DEFAULT_ENV_FILE", self.root / "missing.env"
        )
        self.env_patch.start()
        self.addCleanup(self.env_patch.stop)
        self.creds = patch.dict(
            os.environ,
            {
                "VERCEL_TOKEN": "tok",
                "VERCEL_SCOPE": "team-x",
                "VERCEL_PROJECT": "proj-x",
                "PROD_URL": "city.example.com",
            },
            clear=False,
        )
        self.creds.start()
        self.addCleanup(self.creds.stop)

    def write_html(self, rel, title, size_ok=True):
        path = self.root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        body = BIG.format(title=title) if size_ok else f"<h1>{title}</h1>"
        path.write_text(body, encoding="utf-8")
        return path

    def write_config(self, deployments, defaults=None):
        lines = []
        if defaults:
            lines.append("defaults:")
            for key, value in defaults.items():
                lines.append(f"  {key}: {json.dumps(value)}")
        lines.append("deployments:")
        for name, data in deployments.items():
            lines.append(f"  {name}:")
            for key, value in data.items():
                lines.append(f"    {key}: {json.dumps(value)}")
        path = self.root / "vercel.yaml"
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return path

    def deploy_args(self, *extra):
        return app.build_parser().parse_args(
            ["deploy", "--state", str(self.state), "--jobs", "1", *extra]
        )


class EnvTests(Base):
    def test_parse_env_file_tolerates_spaces_and_quotes(self):
        env_file = self.root / ".env"
        env_file.write_text(
            textwrap.dedent("""\
                ## vercel deployment
                PROD_URL = city.allez.cc.cd
                VERCEL_TOKEN = "vcp_secret"

                export VERCEL_SCOPE='my-team'
                """),
            encoding="utf-8",
        )
        values = app.parse_env_file(env_file)
        self.assertEqual(values["PROD_URL"], "city.allez.cc.cd")
        self.assertEqual(values["VERCEL_TOKEN"], "vcp_secret")
        self.assertEqual(values["VERCEL_SCOPE"], "my-team")

    def test_load_env_files_does_not_override_real_env(self):
        env_file = self.root / ".env"
        env_file.write_text("VERCEL_TOKEN=from_file\n", encoding="utf-8")
        with patch.dict(os.environ, {"VERCEL_TOKEN": "from_env"}, clear=False):
            app.load_env_files([str(env_file)])
            self.assertEqual(os.environ["VERCEL_TOKEN"], "from_env")

    def test_credentials_reads_all_fields(self):
        creds = app.credentials()
        self.assertEqual(creds.token, "tok")
        self.assertEqual(creds.scope, "team-x")
        self.assertEqual(creds.project, "proj-x")
        self.assertEqual(creds.prod_url, "city.example.com")


class ConfigTests(Base):
    def test_defaults_merge_and_relative_source(self):
        self.write_html("site/index.html", "Home")
        config = self.write_config(
            {"my-site": {"source_dir": "./site"}},
            defaults={"scope": "team-x", "prod": False},
        )
        specs = app.load_config(str(config))
        self.assertEqual(len(specs), 1)
        self.assertEqual(Path(specs[0].source), self.root / "site")
        self.assertEqual(specs[0].scope, "team-x")
        self.assertFalse(specs[0].prod)

    def test_entry_overrides_defaults(self):
        self.write_html("site/index.html", "Home")
        config = self.write_config(
            {"s": {"source_dir": "./site", "prod": True}}, defaults={"prod": False}
        )
        self.assertTrue(app.load_config(str(config))[0].prod)

    def test_cli_prod_preview_overrides_config(self):
        self.write_html("site/index.html", "Home")
        config = self.write_config({"s": {"source_dir": "./site", "prod": True}})
        preview = app.build_parser().parse_args(
            ["deploy", "--config", str(config), "--preview"]
        )
        self.assertFalse(app.specs_from_args(preview)[0].prod)
        prod = app.build_parser().parse_args(
            ["deploy", "--config", str(config), "--prod"]
        )
        self.assertTrue(app.specs_from_args(prod)[0].prod)
        # With no CLI flag, the config value is preserved.
        plain = app.build_parser().parse_args(["deploy", "--config", str(config)])
        self.assertTrue(app.specs_from_args(plain)[0].prod)

    def test_invalid_mode_and_name(self):
        self.write_config({"s": {"source_dir": "./site", "mode": "nope"}})
        with self.assertRaisesRegex(app.DeployError, "invalid_mode"):
            app.load_config(str(self.root / "vercel.yaml"))
        self.write_config({"Bad Name": {"source_dir": "./site"}})
        with self.assertRaisesRegex(app.DeployError, "invalid_project_name"):
            app.load_config(str(self.root / "vercel.yaml"))

    def test_missing_config(self):
        with self.assertRaisesRegex(app.DeployError, "config_not_found"):
            app.load_config(str(self.root / "nope.yaml"))

    def test_discover_specs(self):
        self.write_html("alpha/index.html", "A")
        self.write_html("Beta Site/index.html", "B")
        (self.root / "empty").mkdir()
        specs = app.discover_specs(str(self.root), "team-x", name_prefix="v-")
        self.assertEqual(sorted(s.name for s in specs), ["v-alpha", "v-beta-site"])


class CollectionTests(Base):
    def _collection_spec(self, **overrides):
        data = {"source_dir": str(self.root / "src"), "mode": "collection"}
        data.update(overrides)
        return app.DeploymentSpec(
            name="zhongnanshan",
            source=data["source_dir"],
            mode="collection",
            prod_url="city.example.com",
            **{k: v for k, v in overrides.items() if k != "source_dir"},
        )

    def setUp(self):
        super().setUp()
        self.write_html("src/city-a/index.html", "Beijing 🏯")
        self.write_html("src/city-b/index.html", "Shanghai")
        self.write_html("src/20240101T101010==z--notes.html", "Chengdu")
        self.write_html("src/small.html", "Tiny", size_ok=False)
        self.write_html("src/20240101T101010==z--x-email.html", "Email copy")

    def test_scan_items_includes_dirs_and_files_and_skips_small_and_email(self):
        items = app.scan_items(self._collection_spec())
        titles = sorted(item.title for item in items)
        self.assertEqual(titles, ["Beijing 🏯", "Chengdu", "Shanghai"])
        self.assertTrue(all(len(item.slug) > 6 for item in items))

    def test_slug_is_stable_and_configurable(self):
        spec = self._collection_spec(slug_prefix="city", slug_algo="md5", slug_len=6)
        first = app.slug_for("city-a", spec)
        self.assertEqual(first, app.slug_for("city-a", spec))
        self.assertTrue(first.startswith("city-"))
        self.assertEqual(len(first), len("city-") + 6)
        spec2 = self._collection_spec(
            slug_prefix="item", slug_algo="sha256", slug_len=8
        )
        self.assertNotEqual(app.slug_for("city-a", spec), app.slug_for("city-a", spec2))

    def test_toc_html_has_cards_and_no_placeholders(self):
        spec = self._collection_spec(item_label="城市", title="🗺️ 目录")
        items = app.scan_items(spec)
        toc = app.build_toc_html(items, spec)
        self.assertNotIn("__", toc)
        self.assertIn("city.example.com", toc)
        self.assertIn(f"/{items[0].slug}/", toc)
        self.assertIn("城市", toc)

    def test_stage_collection_builds_tree(self):
        spec = self._collection_spec()
        staging = self.root / "stage"
        staging.mkdir()
        details = app.stage_collection(spec, staging)
        self.assertEqual(details["items"], 3)
        self.assertTrue((staging / "toc" / "index.html").is_file())
        self.assertTrue((staging / "index.html").is_file())
        self.assertEqual(
            len(
                [p for p in staging.iterdir() if p.is_dir() and p.name not in ("toc",)]
            ),
            3,
        )

    def test_collection_no_items_fails(self):
        (self.root / "empty-src").mkdir()
        spec = app.DeploymentSpec(
            name="s", source=str(self.root / "empty-src"), mode="collection"
        )
        with self.assertRaisesRegex(app.DeployError, "collection_found_no_items"):
            app.stage_collection(spec, self.root / "stage2")

    def test_root_mode_none_skips_root_index(self):
        spec = self._collection_spec(root_mode="none")
        staging = self.root / "stage3"
        staging.mkdir()
        app.stage_collection(spec, staging)
        self.assertFalse((staging / "index.html").exists())


class StaticTests(Base):
    def test_stage_static_directory_ignores_skip_dirs(self):
        self.write_html("site/index.html", "Home")
        (self.root / "site" / "node_modules").mkdir()
        (self.root / "site" / "node_modules" / "x.js").write_text("x", encoding="utf-8")
        spec = app.DeploymentSpec(name="s", source=str(self.root / "site"))
        staging = self.root / "stage"
        staging.mkdir()
        app.stage_static(spec, staging)
        self.assertTrue((staging / "index.html").is_file())
        self.assertFalse((staging / "node_modules").exists())

    def test_stage_static_single_file_becomes_index(self):
        page = self.write_html("one.html", "One")
        spec = app.DeploymentSpec(name="s", source=str(page))
        staging = self.root / "stage"
        staging.mkdir()
        app.stage_static(spec, staging)
        self.assertTrue((staging / "index.html").is_file())

    def test_stage_static_rejects_non_html_file(self):
        other = self.root / "readme.txt"
        other.write_text("x", encoding="utf-8")
        spec = app.DeploymentSpec(name="s", source=str(other))
        with self.assertRaisesRegex(app.DeployError, "source_not_html_file"):
            app.stage_static(spec, self.root / "stage")


class FingerprintTests(Base):
    def test_static_fingerprint_changes_with_content(self):
        site = self.root / "site"
        self.write_html("site/index.html", "Home")
        spec = app.DeploymentSpec(name="s", source=str(site))
        first = app.input_fingerprint(spec)
        self.assertEqual(first, app.input_fingerprint(spec))
        (site / "index.html").write_text("changed", encoding="utf-8")
        self.assertNotEqual(first, app.input_fingerprint(spec))

    def test_collection_fingerprint_changes_with_new_item(self):
        self.write_html("src/a/index.html", "A")
        spec = app.DeploymentSpec(
            name="s", source=str(self.root / "src"), mode="collection"
        )
        first = app.input_fingerprint(spec)
        self.write_html("src/b/index.html", "B")
        self.assertNotEqual(first, app.input_fingerprint(spec))


class WranglerEquivTests(Base):
    def test_build_deploy_command_flags(self):
        spec = app.DeploymentSpec(
            name="zhongnanshan",
            source="/tmp/x",
            scope="team-x",
            prod=True,
            archive="tgz",
        )
        command = app.build_deploy_command(["vercel"], Path("/tmp/stage"), spec, "tok")
        self.assertEqual(command[:3], ["vercel", "deploy", "/tmp/stage"])
        self.assertIn("--prod", command)
        self.assertIn("--project", command)
        self.assertIn("zhongnanshan", command)
        self.assertIn("--scope", command)
        self.assertIn("--archive", command)
        self.assertIn("-y", command)

    def test_preview_omits_prod(self):
        spec = app.DeploymentSpec(name="s", source="/tmp/x", prod=False, archive=None)
        command = app.build_deploy_command(["vercel"], Path("/tmp/s"), spec, "tok")
        self.assertNotIn("--prod", command)
        self.assertNotIn("--archive", command)

    def test_masked_command_hides_token(self):
        command = ["vercel", "deploy", "/x", "--token", "supersecret", "-y"]
        masked = app.masked_command(command)
        self.assertNotIn("supersecret", masked)
        self.assertIn("***", masked)

    def test_find_deployment_url_from_json_and_text(self):
        payload = json.dumps({"deployment": {"url": "https://proj-abc.vercel.app"}})
        self.assertEqual(
            app.find_deployment_url(payload), "https://proj-abc.vercel.app"
        )
        self.assertEqual(
            app.find_deployment_url("Inspect: https://proj-xyz.vercel.app"),
            "https://proj-xyz.vercel.app",
        )
        self.assertIsNone(app.find_deployment_url("nothing here"))


class DeployTests(Base):
    def _patch(self, deploy_ok=True):
        self.calls: list[list] = []

        def fake_run(command, timeout, cwd=None):
            self.calls.append(command)
            if command[1] == "project":
                return app.CommandResult(0, "", "")
            if deploy_ok:
                return app.CommandResult(
                    0, json.dumps({"deployment": {"url": "https://new.vercel.app"}}), ""
                )
            return app.CommandResult(1, "", "deploy boom")

        patches = [
            patch.object(app, "run_process", side_effect=fake_run),
            patch.object(app, "find_vercel", return_value=["vercel"]),
            patch.object(app, "project_exists", return_value=True),
        ]
        for item in patches:
            item.start()
            self.addCleanup(item.stop)

    def test_dry_run_no_network_no_state(self):
        self.write_html("site/index.html", "Home")
        config = self.write_config({"my-site": {"source_dir": "./site"}})
        with patch.object(app, "run_process", side_effect=AssertionError("no network")):
            report = app.batch(self.deploy_args("--config", str(config), "--dry-run"))
        self.assertEqual(report["status"], "dry_run")
        self.assertEqual(report["summary"]["planned"], 1)
        self.assertFalse(self.state.exists())

    def test_static_deploy_success_records_state(self):
        self._patch()
        self.write_html("site/index.html", "Home")
        config = self.write_config({"my-site": {"source_dir": "./site"}})
        report = app.batch(self.deploy_args("--config", str(config)))
        self.assertEqual(report["summary"]["success"], 1)
        result = report["results"][0]
        self.assertEqual(result["url"], "https://new.vercel.app")
        state = json.loads(self.state.read_text())
        self.assertEqual(state["deployments"]["my-site"]["status"], "success")
        self.assertTrue(state["deployments"]["my-site"]["fingerprint"])
        # deploy command actually issued
        deploy_cmds = [c for c in self.calls if c[1] == "deploy"]
        self.assertEqual(len(deploy_cmds), 1)

    def test_unchanged_skip_then_force(self):
        self._patch()
        self.write_html("site/index.html", "Home")
        config = self.write_config({"my-site": {"source_dir": "./site"}})
        app.batch(self.deploy_args("--config", str(config)))
        self.calls.clear()
        second = app.batch(self.deploy_args("--config", str(config)))
        self.assertEqual(second["results"][0]["reason"], "unchanged")
        self.assertEqual([c for c in self.calls if c[1] == "deploy"], [])
        third = app.batch(self.deploy_args("--config", str(config), "--force"))
        self.assertEqual(third["results"][0]["status"], "success")

    def test_retry_failed_skips_success(self):
        self._patch()
        self.write_html("site/index.html", "Home")
        config = self.write_config(
            {"a": {"source_dir": "./site"}, "b": {"source_dir": "./site"}}
        )
        app.batch(self.deploy_args("--config", str(config), "--only", "a"))
        report = app.batch(self.deploy_args("--config", str(config), "--retry-failed"))
        by_name = {r["name"]: r for r in report["results"]}
        self.assertEqual(by_name["a"]["reason"], "retry_failed_skip")
        self.assertEqual(by_name["b"]["status"], "success")

    def test_project_missing_when_create_disabled(self):
        self.write_html("site/index.html", "Home")
        config = self.write_config(
            {"s": {"source_dir": "./site", "create_if_missing": False}}
        )
        with patch.object(app, "find_vercel", return_value=["vercel"]), patch.object(
            app, "project_exists", return_value=False
        ), patch.object(
            app, "run_process", side_effect=AssertionError("must not deploy")
        ):
            report = app.batch(self.deploy_args("--config", str(config)))
        self.assertEqual(report["results"][0]["reason"], "project_missing")

    def test_deploy_failure_reason_and_detail(self):
        self.write_html("site/index.html", "Home")
        config = self.write_config({"s": {"source_dir": "./site"}})
        with patch.object(app, "find_vercel", return_value=["vercel"]), patch.object(
            app, "project_exists", return_value=True
        ), patch.object(
            app,
            "run_process",
            return_value=app.CommandResult(1, "", "boom" * 500),
        ), patch.object(
            app.time, "sleep"
        ):
            report = app.batch(self.deploy_args("--config", str(config)))
        result = report["results"][0]
        self.assertEqual(result["reason"], "deploy_failed")
        self.assertLessEqual(len(result["detail"]), app.MAX_WARNING_CHARS + 3)

    def test_parallel_batch(self):
        self._patch()
        self.write_html("a/index.html", "A")
        self.write_html("b/index.html", "B")
        config = self.write_config(
            {"a": {"source_dir": "./a"}, "b": {"source_dir": "./b"}}
        )
        report = app.batch(
            app.build_parser().parse_args(
                [
                    "deploy",
                    "--config",
                    str(config),
                    "--state",
                    str(self.state),
                    "--jobs",
                    "2",
                ]
            )
        )
        self.assertEqual(report["summary"]["success"], 2)
        state = json.loads(self.state.read_text())
        self.assertEqual(sorted(state["deployments"]), ["a", "b"])


class CliTests(Base):
    def test_jobs_validation(self):
        self.assertEqual(app.resolve_jobs("auto", 10), 4)
        self.assertEqual(app.resolve_jobs("2", 10), 2)
        self.assertEqual(app.resolve_jobs("99", 3), 3)
        with self.assertRaisesRegex(app.DeployError, "invalid_jobs_value"):
            app.resolve_jobs("lots", 5)

    def test_missing_credentials(self):
        self.write_html("site/index.html", "Home")
        with patch.dict(os.environ, {}, clear=False):
            for key in ("VERCEL_TOKEN", "VERCEL_API_TOKEN"):
                os.environ.pop(key, None)
            code = app.main(
                [
                    "deploy",
                    "--dir",
                    str(self.root / "site"),
                    "--project-name",
                    "s",
                    "--state",
                    str(self.state),
                ]
            )
        self.assertEqual(code, 1)

    def test_no_input_specified(self):
        with self.assertRaisesRegex(app.DeployError, "no_input_specified"):
            app.specs_from_args(app.build_parser().parse_args(["deploy"]))

    def test_discover_command_writes_config(self):
        self.write_html("alpha/index.html", "A")
        self.write_html("beta/index.html", "B")
        output = self.root / "vercel.yaml"
        code = app.main(["discover", "--root", str(self.root), "--output", str(output)])
        self.assertEqual(code, 0)
        specs = app.load_config(str(output))
        self.assertEqual(sorted(s.name for s in specs), ["alpha", "beta"])

    def test_list_command_uses_cli(self):
        with patch.object(
            app,
            "list_projects",
            return_value=[{"name": "zhongnanshan", "latestProductionUrl": "https://x"}],
        ), patch.object(app, "find_vercel", return_value=["vercel"]):
            code = app.main(["list", "--json"])
        self.assertEqual(code, 0)

    def test_cli_help_and_real_dry_run_subprocess(self):
        script = Path(app.__file__)
        help_result = subprocess.run(
            [sys.executable, "-B", str(script), "--help"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Vercel", help_result.stdout)

        self.write_html("site/index.html", "Home")
        config = self.write_config({"my-site": {"source_dir": "./site"}})
        result = subprocess.run(
            [
                sys.executable,
                "-B",
                str(script),
                "deploy",
                "--config",
                str(config),
                "--dry-run",
                "--json",
                "--state",
                str(self.state),
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        report = json.loads(result.stdout)
        self.assertEqual(report["status"], "dry_run")
        self.assertEqual(report["summary"]["planned"], 1)


if __name__ == "__main__":
    unittest.main()
