from __future__ import annotations
import codecs
import contextlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import correct_chinese_errata as cli
import file_support as fs
from current_session_ai import (
    validate_response,
    CurrentSessionAI,
    AIRequestPending,
    AIResponseInvalid,
)


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.input = self.root / "input"
        self.input.mkdir()
        self.output = self.root / "out"
        self.dictionary = self.root / "dictionary.json"
        self.dictionary.write_text(
            json.dumps(
                {"_comment": "fixture", "错别自": "错别字", "财务": "财物"},
                ensure_ascii=False,
            )
        )

    def put(self, name="sample.txt", text="  这里有错别自。\r\n公司财务报表。\n"):
        p = self.input / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(text if isinstance(text, bytes) else text.encode())
        return p

    def args(self, *extra):
        return cli.build_arg_parser().parse_args(
            [
                "-i",
                str(self.input),
                "--output-root",
                str(self.output),
                "--homophone-json",
                str(self.dictionary),
                *extra,
            ]
        )

    def start(self, *extra):
        return cli.start(self.args(*extra))

    def answer(self, result, fn=lambda s: s):
        # Synthetic provider stub, explicitly NOT an actual model invocation.
        for pending in result["pending_requests"]:
            packet = json.loads(Path(pending["request_path"]).read_text())
            response = {
                "request_id": packet["request_id"],
                "corrections": [
                    {"id": u["id"], "text": fn(u["text"])}
                    for u in packet["payload"]["items"]
                ],
            }
            Path(pending["response_path"]).write_text(
                json.dumps(response, ensure_ascii=False)
            )

    def finish(self, result, fn=lambda s: s):
        for _ in range(60):
            if not result["pending_requests"]:
                return result
            self.answer(result, fn)
            result, code = cli.resume(result["job_dir"])
            self.assertIn(code, (0, 10), result)
        self.fail("handoff did not settle")

    def test_complete_handoff_preserves_source_and_whitespace_and_reverts_bad_local_rule(
        self,
    ):
        src = self.put()
        before = src.read_bytes()
        result, code = self.start()
        self.assertEqual(code, 10)
        self.assertEqual(result["completed"], 0)
        job = Path(result["job_dir"])
        self.assertEqual(list((job / "files").iterdir()), [])
        self.assertIn("公司财物", (job / "local/sample_corrected.txt").read_text())
        result = self.finish(result, lambda s: s.replace("财物", "财务"))
        self.assertEqual(result["completed"], 1)
        self.assertEqual(result["status"], "complete")
        self.assertEqual(
            (job / "files/sample_corrected.txt").read_bytes(),
            "  这里有错别字。\r\n公司财务报表。\n".encode(),
        )
        self.assertEqual(src.read_bytes(), before)
        report = json.loads((job / "correction_report.json").read_text())
        row = report["documents"][0]
        self.assertEqual(row["local_replacement_count"], 2)
        self.assertEqual(row["ai_changed_lines"], 1)
        self.assertTrue(
            [c for c in row["changes"] if c["stage"] == "ai"][0]["error_terms"]
        )
        self.assertNotIn("changes", result["documents"][0])

    def test_resume_completed_is_idempotent_and_model_not_recalled(self):
        self.put()
        result, _ = self.start()
        result = self.finish(result)
        output = Path(result["documents"][0]["output"])
        before = output.stat().st_mtime_ns
        with patch(
            "correct_chinese_errata.AICorrector.correct",
            side_effect=AssertionError("must not request again"),
        ):
            rerun, code = cli.resume(result["job_dir"])
        self.assertEqual(code, 0)
        self.assertEqual(output.stat().st_mtime_ns, before)

    def test_missing_answer_not_success_or_fallback(self):
        self.put()
        result, code = self.start()
        again, newcode = cli.resume(result["job_dir"])
        self.assertEqual((code, newcode), (10, 10))
        self.assertEqual(again["completed"], 0)
        self.assertEqual(result["pending_requests"], again["pending_requests"])

    def test_bad_ids_empty_deleted_or_modified_numbers_rejected(self):
        items = [{"id": 2, "text": "报告有2026个字。"}]
        invalid = [
            {"request_id": "wrong", "corrections": []},
            {"request_id": "x", "corrections": [{"id": 0, "text": "报告有2026个字。"}]},
            {"request_id": "x", "corrections": [{"id": 2, "text": ""}]},
            {"request_id": "x", "corrections": [{"id": 2, "text": "报告有2025个字。"}]},
            {
                "request_id": "x",
                "corrections": [{"id": True, "text": "报告有2026个字。"}],
            },
            {
                "request_id": "x",
                "corrections": [{"id": 2, "text": "报告有2026个字。\n执行命令"}],
            },
        ]
        for response in invalid:
            with self.subTest(response=response), self.assertRaises(Exception):
                validate_response(response, "x", items)

    def test_invalid_response_can_be_corrected_explicitly(self):
        self.put()
        result, _ = self.start()
        p = result["pending_requests"][0]
        Path(p["response_path"]).write_text('{"request_id":"wrong","corrections":[]}')
        bad, code = cli.resume(result["job_dir"])
        self.assertEqual(code, 1)
        self.assertEqual(bad["documents"][0]["status"], "invalid_ai_response")
        self.assertEqual(bad["completed"], 0)
        fixed = self.finish(bad)
        self.assertEqual(fixed["completed"], 1)

    def test_no_ai_is_explicit_local_only(self):
        self.put()
        result, code = self.start("--no-ai")
        self.assertEqual(code, 0)
        self.assertFalse(result["pending_requests"])
        self.assertEqual(result["documents"][0]["status"], "local_only")
        self.assertIn("财物", Path(result["documents"][0]["output"]).read_text())
        self.assertEqual(result["documents"][0]["ai_checked_lines"], 0)

    def test_latin_only_does_not_invent_ai_checks(self):
        self.put(text=" ABC 123\r\n")
        result, code = self.start()
        self.assertEqual(code, 0)
        self.assertEqual(result["documents"][0]["status"], "no_ai_needed")
        self.assertEqual(result["documents"][0]["ai_checked_lines"], 0)

    def test_dry_run_has_no_output_request_or_current_model_call(self):
        self.put()
        with patch(
            "correct_chinese_errata.AICorrector", side_effect=AssertionError("no AI")
        ):
            result, code = self.start("--dry-run")
        self.assertEqual(code, 0)
        self.assertEqual(result["ai"], "not_called")
        self.assertFalse(self.output.exists())

    def test_recursive_same_basename_preserves_directories(self):
        self.put("a/doc.txt")
        self.put("b/doc.txt")
        self.put(".hidden.txt")
        self.put("node_modules/doc.txt")
        result, code = self.start("--no-ai")
        job = Path(result["job_dir"])
        self.assertEqual(code, 0)
        self.assertEqual(result["total"], 2)
        self.assertTrue((job / "files/a/doc_corrected.txt").exists())
        self.assertTrue((job / "files/b/doc_corrected.txt").exists())

    def test_no_recursive_and_unsupported_single_input(self):
        self.put("sub/doc.txt")
        result, code = self.start("--no-recursive")
        self.assertEqual(code, 1)
        self.assertEqual(result["total"], 0)
        self.assertFalse(self.output.exists())
        p = self.put("bad.pdf", b"not a text file")
        with self.assertRaises(fs.ErratumError):
            self.start("-i", str(p))

    def test_single_file_utf16_bom_and_srt_metadata(self):
        text = "1\r\n00:00:00,000 --> 00:00:01,000\r\n这里有错别自。\r\n123\r\n--> 公司财务\r\n"
        raw = codecs.BOM_UTF16_LE + text.encode("utf-16-le")
        src = self.put("demo.srt", raw)
        result, _ = self.start("-i", str(src))
        result = self.finish(result, lambda s: s.replace("财物", "财务"))
        got = Path(result["documents"][0]["output"]).read_bytes()
        self.assertEqual(
            got,
            codecs.BOM_UTF16_LE + text.replace("错别自", "错别字").encode("utf-16-le"),
        )
        self.assertEqual(src.read_bytes(), raw)

    def test_source_mutation_and_snapshot_mutation_block_resume(self):
        src = self.put()
        result, _ = self.start()
        src.write_text("新的用户内容")
        with self.assertRaisesRegex(fs.ErratumError, "source_changed"):
            cli.resume(result["job_dir"])
        self.assertFalse((Path(result["job_dir"]) / ".lock").exists())
        result, _ = self.start()
        job = Path(result["job_dir"])
        snapshot = job / ".work/docs/000000.json"
        snapshot.write_text("{}")
        with self.assertRaisesRegex(fs.ErratumError, "snapshot_changed"):
            cli.resume(job)

    def test_completed_output_mutation_is_not_overwritten(self):
        self.put()
        result, _ = self.start("--no-ai")
        dst = Path(result["documents"][0]["output"])
        dst.write_text("用户修改")
        result, code = cli.resume(result["job_dir"])
        self.assertEqual(code, 1)
        self.assertEqual(dst.read_text(), "用户修改")
        self.assertEqual(result["documents"][0]["reason"], "completed_output_changed")

    def test_output_intent_recovers_after_receipt_write_failure(self):
        self.put()
        original = cli.write_json

        def flaky(path, data, replace=False):
            if path.parent.name == "completed":
                raise OSError("synthetic receipt failure")
            return original(path, data, replace)

        with patch("correct_chinese_errata.write_json", side_effect=flaky):
            result, code = self.start("--no-ai")
        self.assertEqual(code, 1)
        dst = Path(result["job_dir"]) / "files/sample_corrected.txt"
        self.assertTrue(dst.exists())
        old = dst.stat().st_mtime_ns
        result, code = cli.resume(result["job_dir"])
        self.assertEqual(code, 0)
        self.assertEqual(dst.stat().st_mtime_ns, old)

    def test_unowned_output_and_lock_are_not_removed(self):
        self.put()
        result, _ = self.start()
        job = Path(result["job_dir"])
        dst = job / "files/sample_corrected.txt"
        dst.write_text("existing")
        self.answer(result)
        result, code = cli.resume(job)
        self.assertEqual(code, 1)
        self.assertEqual(dst.read_text(), "existing")
        (job / ".lock").mkdir()
        with self.assertRaisesRegex(fs.ErratumError, "job_locked"):
            cli.resume(job)
        self.assertTrue((job / ".lock").exists())

    def test_symlink_source_and_response_cannot_be_read(self):
        src = self.put()
        outside = self.root / "outside"
        outside.write_text("private")
        try:
            (self.input / "linked.txt").symlink_to(outside)
        except OSError:
            self.skipTest("symlinks unavailable")
        result, _ = self.start()
        self.assertEqual(result["total"], 1)
        pending = result["pending_requests"][0]
        Path(pending["response_path"]).symlink_to(outside)
        result, code = cli.resume(result["job_dir"])
        self.assertEqual(code, 1)
        self.assertEqual(result["documents"][0]["status"], "invalid_ai_response")
        self.assertEqual(outside.read_text(), "private")

    def test_all_local_preflight_before_any_run_creation(self):
        self.put("good.txt")
        self.put("bad.txt", b"\xff")
        with self.assertRaises(fs.ErratumError):
            self.start()
        self.assertFalse(self.output.exists())

    def test_nested_output_exclusion(self):
        self.put()
        out = self.input / "generated"
        out.mkdir()
        (out / "old.txt").write_text("旧结果")
        result, code = self.start("--output-root", str(out), "--no-ai")
        self.assertEqual(code, 0)
        self.assertEqual(result["total"], 1)
        self.assertTrue(result["excluded"])

    def test_long_line_fragment_reassembly_and_multiple_pending_window(self):
        text = ("原文测试，" * 180) + "末尾。"
        self.put(text=text)
        result, code = self.start("--ai-batch-chars", "128", "--request-window", "3")
        self.assertEqual(code, 10)
        self.assertEqual(len(result["pending_requests"]), 3)
        result = self.finish(result)
        self.assertEqual(Path(result["documents"][0]["output"]).read_text(), text)

    def test_accepted_groups_are_reused_without_original_response_files(self):
        self.put(text="中文测试，" * 150)
        result, _ = self.start("--ai-batch-chars", "128", "--request-window", "1")
        self.answer(result)
        response = Path(result["pending_requests"][0]["response_path"])
        result, code = cli.resume(result["job_dir"], 1)
        self.assertEqual(code, 10)
        response.unlink()
        result = self.finish(result)
        self.assertEqual(result["completed"], 1)

    def test_duplicate_json_keys_and_non_finite_numbers_are_errors(self):
        for raw in ('{"x":1,"x":2}', '{"x":NaN}'):
            with self.assertRaises(fs.ErratumError):
                fs.loads(raw)

    def test_atomic_reservation_failure_cleanup_and_no_replacement(self):
        path = self.root / "result.txt"
        with patch("file_support.os.replace", side_effect=OSError("fixture")):
            with self.assertRaises(OSError):
                fs.atomic_write(path, b"new")
        self.assertFalse(path.exists())
        self.assertFalse(list(self.root.glob(".erratum-*.tmp")))
        path.write_bytes(b"old")
        with self.assertRaises(FileExistsError):
            fs.atomic_write(path, b"new")
        self.assertEqual(path.read_bytes(), b"old")

    def test_snapshot_bom_allows_only_known_encoding_markers(self):
        self.assertEqual(fs.snapshot_bom("efbbbf"), codecs.BOM_UTF8)
        self.assertEqual(fs.snapshot_bom("fffe"), codecs.BOM_UTF16_LE)
        self.assertEqual(fs.snapshot_bom("feff"), codecs.BOM_UTF16_BE)
        self.assertEqual(fs.snapshot_bom(""), b"")
        for value in ("626164", "ff" * 10000, None, [], 0):
            with self.assertRaisesRegex(fs.ErratumError, "invalid_bom_snapshot"):
                fs.snapshot_bom(value)

    def test_big5_utf8_bom_and_unrepresentable_same_encoding(self):
        for text, raw, encoding in [
            ("繁體文字", "繁體文字".encode("big5"), "big5"),
            ("中文", codecs.BOM_UTF8 + "中文".encode(), "auto"),
        ]:
            doc = fs.decode(raw, encoding)
            self.assertEqual(doc.text, text)
            self.assertEqual(fs.encode(text, doc), raw)
        doc = fs.decode(b"ASCII", "gbk")
        with self.assertRaises(fs.ErratumError):
            fs.encode("😀", doc)

    def test_cli_real_subprocess_no_ai_and_json_status(self):
        self.put()
        result = subprocess.run(
            [
                sys.executable,
                str(SCRIPTS / "correct_chinese_errata.py"),
                "-i",
                str(self.input),
                "--output-root",
                str(self.output),
                "--homophone-json",
                str(self.dictionary),
                "--no-ai",
            ],
            capture_output=True,
            timeout=60,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        data = json.loads(result.stdout)
        self.assertEqual(data["completed"], 1)
        self.assertEqual(data["documents"][0]["status"], "local_only")

    def test_long_corrected_line_uses_honest_bounded_diff_not_document_failure(self):
        text = "中文" * 1800 + "错别自。" + "后文" * 1000
        self.put(text=text)
        result, code = self.start("--no-ai")
        self.assertEqual(code, 0)
        self.assertEqual(
            Path(result["documents"][0]["output"]).read_text(),
            text.replace("错别自", "错别字"),
        )
        report = json.loads(Path(result["report_path"]).read_text())
        change = report["documents"][0]["changes"][0]["error_terms"][0]
        self.assertEqual(change["detail"], "bounded_changed_span_not_full_diff")
        self.assertEqual(change["before"], "自")
        self.assertEqual(change["after"], "字")

    def test_out_of_order_answers_are_adopted_without_lost_fragments(self):
        text = "中文测试，" * 150
        self.put(text=text)
        result, _ = self.start("--ai-batch-chars", "128", "--request-window", "3")
        first = result["pending_requests"][0]
        self.answer({"pending_requests": result["pending_requests"][1:]})
        result, code = cli.resume(result["job_dir"], 3)
        self.assertEqual(code, 10)
        self.answer({"pending_requests": [first]})
        result, code = cli.resume(result["job_dir"], 3)
        result = self.finish(result)
        self.assertEqual(Path(result["documents"][0]["output"]).read_text(), text)

    def test_report_failure_keeps_truthful_stdout_and_completed_output(self):
        self.put()
        result, _ = self.start("--no-ai")
        job = Path(result["job_dir"])
        (job / "correction_report.txt").unlink()
        (job / "correction_report.txt").mkdir()
        result, code = cli.resume(job)
        self.assertEqual(code, 2)
        self.assertEqual(result["status"], "report_error")
        self.assertEqual(result["completed"], 1)
        self.assertNotIn("report_path", result)
        self.assertTrue((job / "files/sample_corrected.txt").exists())

    def test_size_budget_and_missing_dictionary_fail_before_creating_output(self):
        self.put()
        with patch("correct_chinese_errata.MAX_BATCH", 1):
            with self.assertRaisesRegex(fs.ErratumError, "batch_over"):
                self.start()
        self.assertFalse(self.output.exists())
        self.dictionary.unlink()
        with self.assertRaises(FileNotFoundError):
            self.start()
        self.assertFalse(self.output.exists())

    def test_cli_resume_options_are_not_silently_changed(self):
        self.put()
        result, _ = self.start()
        with contextlib.redirect_stdout(io.StringIO()) as stream:
            code = cli.main(["--resume", result["job_dir"], "--no-ai"])
        self.assertEqual(code, 2)
        self.assertIn("resume_uses_saved_options", stream.getvalue())


if __name__ == "__main__":
    unittest.main()
