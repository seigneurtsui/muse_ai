"""Format-neutral extracted text and structural boundaries (Python 3.10+)."""
from dataclasses import dataclass, field


class SplitError(ValueError):
    """A safe, actionable local failure; never include document contents."""


@dataclass
class Boundary:
    position: int  # Character offset into Extracted.text; not byte offset.
    title: str
    level: int = 1
    children: int = 0
    locator: dict = field(default_factory=dict)


@dataclass
class Extracted:
    text: str
    toc: list[Boundary]
    method: str
    warnings: list[str] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)
