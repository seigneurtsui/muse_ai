#!/usr/bin/env python3
"""Small, conservative SRT helpers used only for output-timeline retiming."""
from __future__ import annotations

import re
from pathlib import Path

TIMING = re.compile(
    r"^(?P<start>\d{1,2}:\d{2}:\d{2}[,.]\d{3})\s+-->\s+"
    r"(?P<end>\d{1,2}:\d{2}:\d{2}[,.]\d{3})(?P<tail>.*)$"
)


def parse_time(value: str) -> float:
    value = value.replace(",", ".")
    hours, minutes, seconds = value.split(":")
    return int(hours) * 3600 + int(minutes) * 60 + float(seconds)


def format_time(value: float) -> str:
    value = max(0.0, value)
    hours = int(value // 3600)
    minutes = int((value % 3600) // 60)
    seconds = value - hours * 3600 - minutes * 60
    whole = int(seconds)
    millis = int(round((seconds - whole) * 1000))
    if millis >= 1000:
        whole += 1
        millis -= 1000
    return f"{hours:02d}:{minutes:02d}:{whole:02d},{millis:03d}"


def read_cues(path: str | Path) -> list[tuple[float, float, list[str]]]:
    text = Path(path).read_text(encoding="utf-8-sig")
    blocks = re.split(r"(?:\r\n|\r|\n){2,}", text.strip()) if text.strip() else []
    cues: list[tuple[float, float, list[str]]] = []
    for block in blocks:
        lines = re.split(r"\r\n|\r|\n", block)
        timing_index = next((i for i, line in enumerate(lines) if "-->" in line), None)
        if timing_index is None:
            continue
        match = TIMING.match(lines[timing_index].strip())
        if not match:
            raise ValueError(f"invalid SRT timing: {lines[timing_index]}")
        start = parse_time(match.group("start"))
        end = parse_time(match.group("end"))
        if end <= start:
            raise ValueError("SRT cue end must be after start")
        body = lines[timing_index + 1 :]
        if body:
            cues.append((start, end, body))
    return cues


def write_cues(path: str | Path, cues: list[tuple[float, float, list[str]]]) -> None:
    lines: list[str] = []
    for index, (start, end, body) in enumerate(cues, 1):
        lines.extend([str(index), f"{format_time(start)} --> {format_time(end)}", *body, ""])
    Path(path).write_text("\n".join(lines), encoding="utf-8")


def retime_srt(
    source: str | Path,
    destination: str | Path,
    *,
    speed: float = 1.0,
    trim_start: float = 0.0,
    trim_end: float | None = None,
) -> dict:
    if speed <= 0:
        raise ValueError("speed must be greater than zero")
    if trim_start < 0 or (trim_end is not None and trim_end <= trim_start):
        raise ValueError("invalid trim range")
    cues = read_cues(source)
    last_end = max((cue[1] for cue in cues), default=0.0)
    boundary = last_end if trim_end is None else trim_end
    output: list[tuple[float, float, list[str]]] = []
    for start, end, body in cues:
        if end <= trim_start or start >= boundary:
            continue
        clipped_start = max(start, trim_start)
        clipped_end = min(end, boundary)
        out_start = (clipped_start - trim_start) / speed
        out_end = (clipped_end - trim_start) / speed
        if out_end > out_start:
            output.append((out_start, out_end, body))
    Path(destination).parent.mkdir(parents=True, exist_ok=True)
    write_cues(destination, output)
    return {
        "source_cues": len(cues),
        "output_cues": len(output),
        "source_duration": last_end,
        "output_duration": max((cue[1] for cue in output), default=0.0),
        "speed": speed,
        "trim_start": trim_start,
        "trim_end": trim_end,
    }
