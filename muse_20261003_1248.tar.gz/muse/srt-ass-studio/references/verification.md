# 安装验证记录

本技能安装于 `~/.config/omnirush/skills/srt-ass-studio/`。参考源文件 `~/Downloads/srt2ass_batch.py` 未改动；没有复制其中的第三方 AI 配置、关闭证书校验代码或旧 HTTP provider。

## 已执行的检查

### 自动化测试与语法

```bash
python3 -m unittest discover \
  -s "$HOME/.config/omnirush/skills/srt-ass-studio/tests" -v

python3 -m compileall -q \
  "$HOME/.config/omnirush/skills/srt-ass-studio/scripts" \
  "$HOME/.config/omnirush/skills/srt-ass-studio/tests"
```

结果：**68 项测试通过**，Python 编译检查通过，所有脚本和测试也通过 Python 3.10 语法解析检查。覆盖 SRT 编码/时间轴/序号、非法输入、双语多行、颜色通道、文本转义、十种效果、关键词样式恢复、时长量化、批次原子输出、语言结果复用、缓存并发、OpenCC 边界、通知授权/模拟发送、AI 子进程隔离/时限/输出大小/错误脱敏。

未配置独立的 lint/typecheck/build 工具链；没有安装新依赖。测试通过不等于所有语言翻译质量已认证。

OmniRush 1.0.15 原生 `loadSkillsFromDir` 成功识别 `srt-ass-studio`，诊断列表为空。没有修改全局模型、账号或资源设置。

### 真实本地批处理

通过 CLI 实际处理两个合成源文件（UTF-16 与 GB18030，包含不连续序号、毫秒时间和纯数字字幕），同时输出简体/繁体版本。已安装 OpenCC 的本地转换通过，2/2 文件成功，AI 请求数为 0；核对繁体字、`2026` 数字字幕和 `00:00:01,005` 时间均正确保留。此项使用临时目录，检查后清理。

### 真实 AI 端到端样例

仅使用随技能创建的无隐私 `assets/demo.srt`，未处理用户其他字幕：

```bash
STUDIO="$HOME/.config/omnirush/skills/srt-ass-studio/scripts/srt_ass.py"
python3 "$STUDIO" \
  "$HOME/.config/omnirush/skills/srt-ass-studio/assets/demo.srt" \
  --languages source,en --separate-languages en --ai-highlight \
  --preset pop --font-name 'PingFang SC' --secondary-font Arial \
  --notify-channels bark,telegram --notify-dry-run \
  --output-root "$HOME/Downloads/srt_ass_studio_validation"
```

结果：1 个源文件、4 个 cue 完成；输出双语及英文独立 SRT/ASS、关键词文件和报告。报告为 `provider=omnirush`、`model=gpt-6-astra`，当前会话模型自动继承，未硬编码。2 次模型调用分别用于英文翻译与关键词提取，独立英文输出没有再次翻译。

本次样例目录：

`~/Downloads/srt_ass_studio_validation/20261003_112957_05vf4sz1/`

通知结果是 `dry_run`，仅离线检查通过，**没有发送真实通知**。模型名称为 CLI 返回的身份信息，不是独立的模型证明；以后会跟随当前 OmniRush 模型配置。

### FFmpeg/libass 渲染

使用合成黑底视频，在字幕时间内逐一渲染 `static`、`fade`、四向滑入、`pop`、`blur`、`karaoke`、`typewriter`；10 种效果均退出成功，并检查生成 RGB 帧含非背景像素。渲染样例包含中文/英文两行和关键词高亮。此检查证明字幕可被本机 libass 渲染，不证明每种播放器完全一致。

检查产物与示例截图：

- `~/Downloads/srt_ass_studio_validation/render_checks_bsq630we/render-report.json`
- `~/Downloads/srt_ass_studio_validation/render_checks_bsq630we/pop-preview.png`

已查看 `pop-preview.png`：中英两行清晰显示，关键词为金色，文字位于底部安全区域。

## 尚需针对实际素材确认

- 用户实际字体、分辨率、极长字幕、复杂语言的视觉布局。
- 长批次的真实服务限流/额度，以及需要人工审校的翻译质量。
- 卡拉 OK/打字机使用时间估算，没有音频强制对齐。
- 新技能的通知真实发送没有在此次安装中执行；复用已有验证过的通知技能，但实际通知仍需用户显式授权。
