---
name: upload-post
description: >
  Upload content to social media platforms via Upload-Post API. Use when posting
  videos, photos, text, or documents to TikTok, Instagram, YouTube, LinkedIn,
  Facebook, X (Twitter), Threads, Pinterest, Reddit, or Bluesky. Supports
  scheduling, analytics, FFmpeg processing, and upload history.
---

# Upload-Post API

Post content to multiple social media platforms with a single API call.

## Quick Reference

See `references/platforms.md` for platform-specific parameters and `references/requirements.md` for media format specs.

## Setup

1. Create account at [upload-post.com](https://upload-post.com)
2. Connect your social media accounts
3. Create a Profile (e.g. "mybrand")
4. Generate an API Key

## Authentication

```
Authorization: Apikey YOUR_API_KEY
```

Base URL: `https://api.upload-post.com/api`

## Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/upload_videos` | POST | Upload videos |
| `/upload_photos` | POST | Upload photos/carousels |
| `/upload_text` | POST | Text-only posts |
| `/upload_document` | POST | Upload documents (LinkedIn) |
| `/uploadposts/status?request_id=X` | GET | Check upload status |
| `/uploadposts/history` | GET | Upload history |
| `/uploadposts/schedule` | GET | List scheduled posts |
| `/uploadposts/schedule/<job_id>` | PATCH | Edit scheduled post |
| `/uploadposts/schedule/<job_id>` | DELETE | Cancel scheduled post |
| `/analytics/<profile>` | GET | Get analytics |
| `/ffmpeg` | POST | FFmpeg media processing |

## Upload Video

```bash
curl -X POST "https://api.upload-post.com/api/upload_videos" \
  -H "Authorization: Apikey YOUR_KEY" \
  -F "user=profile_name" \
  -F "platform[]=instagram" \
  -F "platform[]=tiktok" \
  -F "video=@video.mp4" \
  -F "title=My caption"
```

Key params: `user`, `platform[]`, `video`, `title`, `scheduled_date`, `timezone`, `async_upload`, `first_comment`

## Upload Photo

```bash
curl -X POST "https://api.upload-post.com/api/upload_photos" \
  -H "Authorization: Apikey YOUR_KEY" \
  -F "user=profile_name" \
  -F "platform[]=instagram" \
  -F "photos[]=@photo1.jpg" \
  -F "photos[]=@photo2.jpg" \
  -F "title=My caption"
```

## Upload Text

```bash
curl -X POST "https://api.upload-post.com/api/upload_text" \
  -H "Authorization: Apikey YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"user":"profile_name","platform":["x","threads","bluesky"],"title":"My text post"}'
```

## Upload Document (LinkedIn)

```bash
curl -X POST "https://api.upload-post.com/api/upload_document" \
  -H "Authorization: Apikey YOUR_KEY" \
  -F "user=profile_name" \
  -F "platform[]=linkedin" \
  -F "document=@presentation.pdf" \
  -F "title=Document Title"
```

## Scheduling

Add `scheduled_date` (ISO-8601) + `timezone` (IANA) to any upload.

## Analytics

```bash
curl "https://api.upload-post.com/api/analytics/profile_name?platforms=instagram,tiktok" \
  -H "Authorization: Apikey YOUR_KEY"
```

## Error Codes

| Code | Meaning |
|------|---------|
| 400 | Bad request / missing params |
| 401 | Invalid API key |
| 404 | Resource not found |
| 429 | Rate limit / quota exceeded |
| 500 | Server error |

## Notes

- Videos auto-switch to async if >59s processing time
- Facebook requires Page ID (personal profiles not supported)
- Instagram/Threads support mixed carousels (photos + videos)
