#!/usr/bin/env python3
"""youtube_audio_downloader.py

批量下载 YouTube 视频音频，并按视频标题保存为音频文件。
依赖：Python 3.9+、yt-dlp、ffmpeg。

示例：
  python3 youtube_audio_downloader.py URL
  python3 youtube_audio_downloader.py --urls URL1 URL2 URL3
  python3 youtube_audio_downloader.py --file urls.txt
  cat urls.txt | python3 youtube_audio_downloader.py --stdin
"""

from __future__ import annotations

import argparse
import concurrent.futures
import os
import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

try:
    import yt_dlp
except ImportError:
    print("错误：未安装 yt-dlp。请执行：python3 -m pip install -U yt-dlp", file=sys.stderr)
    raise SystemExit(2)

DEFAULT_OUTPUT = Path.home() / "Downloads" / "youtube_audio_downloader"
BROWSERS = ("chrome", "firefox", "edge", "safari", "chromium", "brave", "opera", "vivaldi")
URL_RE = re.compile(r"https?://(?:www\.)?(?:youtube\.com|youtu\.be)/\S+", re.I)


@dataclass
class Result:
    url: str
    success: bool
    path: Optional[Path] = None
    title: Optional[str] = None
    error: Optional[str] = None


def clean_title(title: str) -> str:
    title = re.sub(r"[\\/:*?\"<>|\x00-\x1f]", "_", title).strip(" .")
    return title or "untitled"


def normalize_urls(values: list[str]) -> list[str]:
    urls: list[str] = []
    seen: set[str] = set()
    for value in values:
        value = value.strip()
        if not value or value.startswith("#"):
            continue
        match = URL_RE.search(value)
        if not match:
            print(f"警告：忽略无效 URL：{value}", file=sys.stderr)
            continue
        url = match.group(0).rstrip(".,;，。；")
        if url not in seen:
            seen.add(url)
            urls.append(url)
    return urls


def ydl_options(output_dir: Path, cookies_browser: Optional[str] = None) -> dict:
    opts = {
        "format": "bestaudio/best",
        "outtmpl": str(output_dir / "%(title)s [%(id)s].%(ext)s"),
        "postprocessors": [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}],
        "noplaylist": True,
        "continuedl": True,
        "retries": 3,
        "fragment_retries": 3,
        "concurrent_fragment_downloads": 1,
        "restrictfilenames": False,
        "windowsfilenames": True,
        "overwrites": False,
        "quiet": True,
        "no_warnings": True,
    }
    if cookies_browser:
        opts["cookiesfrombrowser"] = (cookies_browser,)
    return opts


def download_one(url: str, output_dir: Path, use_cookies: bool = True) -> Result:
    errors: list[str] = []
    browsers = BROWSERS if use_cookies else ()
    attempts = list(browsers) + [None]
    for browser in attempts:
        try:
            opts = ydl_options(output_dir, browser)
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=True)
                if not info:
                    raise RuntimeError("yt-dlp 未返回视频信息")
                title = info.get("title") or "untitled"
                video_id = info.get("id") or ""
                base = Path(ydl.prepare_filename(info))
                expected = base.with_suffix(".mp3")
            candidates = list(output_dir.glob(f"*[{video_id}].mp3")) if video_id else []
            path = expected if expected.exists() else (candidates[0] if candidates else None)
            if path is None:
                raise FileNotFoundError("下载完成后未找到音频文件")
            return Result(url, True, path, title)
        except Exception as exc:
            label = browser or "无 Cookie"
            errors.append(f"{label}: {exc}")
    return Result(url, False, error="；".join(errors[-3:]))


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="youtube_audio_downloader.py",
        description="批量下载 YouTube 视频音频，默认保存为 192 kbps MP3，并按“视频标题 [视频ID]”命名。",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
输入方式（任选其一）：
  1. 单个 URL（位置参数）：
     %(prog)s https://www.youtube.com/watch?v=VIDEO_ID
  2. 文本文件：每行一个 URL，空行和 # 开头的行会忽略：
     %(prog)s --file urls.txt
  3. 命令行 URL 列表：
     %(prog)s --urls URL1 URL2 URL3
  4. 从标准输入读取 URL 列表：
     cat urls.txt | %(prog)s --stdin

常用示例：
  %(prog)s URL -o ~/Music/youtube
  %(prog)s --file urls.txt --format wav --workers 2
  %(prog)s --urls URL1 URL2 --no-cookies
  %(prog)s --file urls.txt --dry-run

注意：需要先安装 yt-dlp 和 ffmpeg；请仅下载你有权保存或使用的内容。
""",
    )
    source = parser.add_mutually_exclusive_group()
    source.add_argument("url", nargs="?", help="单个 YouTube URL")
    source.add_argument("--file", "-f", metavar="PATH", help="URL 文本列表文件，每行一个 URL")
    source.add_argument("--urls", "-u", nargs="+", metavar="URL", help="从命令行提供多个 URL")
    source.add_argument("--stdin", action="store_true", help="从标准输入读取 URL 列表")
    parser.add_argument("-o", "--output", default=str(DEFAULT_OUTPUT), metavar="DIR", help=f"输出目录（默认：{DEFAULT_OUTPUT}）")
    parser.add_argument("--format", choices=("mp3", "wav", "m4a", "opus"), default="mp3", help="音频格式（默认：mp3）")
    parser.add_argument("-w", "--workers", type=int, default=3, help="并发下载数，建议 1-5（默认：3）")
    parser.add_argument("--no-cookies", action="store_true", help="不尝试读取浏览器 Cookie")
    parser.add_argument("--dry-run", action="store_true", help="只检查并显示 URL，不实际下载")
    args = parser.parse_args()

    if args.workers < 1 or args.workers > 20:
        parser.error("--workers 必须在 1 到 20 之间")
    if args.file:
        try:
            values = Path(args.file).expanduser().read_text(encoding="utf-8").splitlines()
        except OSError as exc:
            parser.error(f"无法读取 URL 文件：{exc}")
    elif args.urls:
        values = args.urls
    elif args.stdin:
        values = sys.stdin.read().splitlines()
    elif args.url:
        values = [args.url]
    else:
        parser.error("请提供单个 URL、--file、--urls 或 --stdin")

    urls = normalize_urls(values)
    if not urls:
        parser.error("没有找到有效的 YouTube URL")
    if args.dry_run:
        print("有效 URL：")
        print("\n".join(urls))
        return 0

    if shutil.which("ffmpeg") is None:
        print("错误：找不到 ffmpeg，请先安装并确保它在 PATH 中。", file=sys.stderr)
        return 2

    output_dir = Path(args.output).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"开始下载 {len(urls)} 个视频 → {output_dir}")

    results: list[Result] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(args.workers, len(urls))) as pool:
        futures = [pool.submit(download_one, url, output_dir, not args.no_cookies) for url in urls]
        for index, future in enumerate(concurrent.futures.as_completed(futures), 1):
            result = future.result()
            results.append(result)
            if result.success:
                print(f"[{index}/{len(urls)}] 成功：{result.title}\n    {result.path}")
            else:
                print(f"[{index}/{len(urls)}] 失败：{result.url}\n    {result.error}", file=sys.stderr)

    ok = sum(item.success for item in results)
    print(f"完成：成功 {ok}，失败 {len(results) - ok}，共 {len(results)}")
    return 0 if ok == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
