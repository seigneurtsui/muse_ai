import contextlib
import fcntl
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import travel_report as flow
import watch_tickets as watch


def fixture(price='500.00'):
    return {'source': 'offline fixture', 'timestamp': '2099-01-01T00:00:00Z',
            'query': {'from': '北京', 'to': '上海', 'date': '2099-01-02'}, 'results': [{
                'ticketPrice': price, 'journeys': [{'totalDuration': 120, 'segments': [{
                    'marketingTransportNo': 'CA1001', 'marketingTransportName': '国航',
                    'depDateTime': '2099-01-02 08:00:00', 'arrDateTime': '2099-01-02 10:00:00',
                    'depCityName': '北京', 'arrCityName': '上海',
                    'depStationCode': 'PEK', 'arrStationCode': 'SHA',
                }]}]}]}


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.args = ['--mode', 'flight', '--from', '北京', '--to', '上海', '--date', '2099-01-02',
                     '--output-dir', str(self.root)]
        self.state = self.root / 'state.json'

    def invoke(self, main, args):
        with contextlib.redirect_stdout(io.StringIO()) as stream:
            code = main(args)
        return code, json.loads(stream.getvalue())

    def test_no_send_flow_is_one_json_and_preserves_route_filename(self):
        with patch.object(flow, 'run_json', return_value=fixture()), patch.object(flow, 'send_report') as send:
            code, data = self.invoke(flow.main, self.args + ['--no-send'])
        self.assertEqual(code, 0)
        self.assertTrue(Path(data['html']).exists())
        self.assertIsNone(data['email'])
        send.assert_not_called()

    def test_email_failure_keeps_report_paths_and_status(self):
        with patch.object(flow, 'run_json', return_value=fixture()), \
             patch.object(flow, 'send_report', side_effect=flow.CommandError(1, {'status': 'failed'})):
            code, data = self.invoke(flow.main, self.args)
        self.assertEqual(code, 1)
        self.assertTrue(Path(data['markdown']).exists())
        self.assertEqual(data['failure']['status'], 'failed')

    def test_monitor_first_unchanged_then_empty_notification(self):
        args = self.args + ['--state', str(self.state), '--send-on-change']
        empty = fixture()
        empty['results'] = []
        with patch.object(watch, 'run_json', side_effect=[fixture(), fixture(), empty]), \
             patch.object(watch, 'send_report', return_value={'status': 'sent'}) as send:
            first = self.invoke(watch.main, args)[1]
            second = self.invoke(watch.main, args)[1]
            third = self.invoke(watch.main, args)[1]
        self.assertTrue(first['firstCheck'])
        self.assertFalse(second['changed'])
        self.assertTrue(third['changed'])
        self.assertEqual(send.call_count, 2)
        self.assertIn('没有找到满足', Path(third['markdown']).read_text())
        self.assertEqual(self.state.stat().st_mode & 0o777, 0o600)

    def test_failed_notification_retries_on_unchanged_query(self):
        args = self.args + ['--state', str(self.state), '--send-on-change']
        failure = flow.CommandError(1, {'status': 'failed'})
        with patch.object(watch, 'run_json', return_value=fixture()), \
             patch.object(watch, 'send_report', side_effect=[failure, {'status': 'sent'}]) as send:
            self.assertEqual(self.invoke(watch.main, args)[0], 1)
            code, output = self.invoke(watch.main, args)
        self.assertEqual(code, 0)
        self.assertFalse(output['changed'])
        self.assertEqual(send.call_count, 2)

    def test_ambiguous_notification_is_not_automatically_duplicated(self):
        args = self.args + ['--state', str(self.state), '--send-on-change']
        with patch.object(watch, 'run_json', return_value=fixture()), \
             patch.object(watch, 'send_report', side_effect=flow.CommandError(1, {'status': 'unknown'})) as send:
            self.invoke(watch.main, args)
            code, output = self.invoke(watch.main, args)
        self.assertEqual(code, 1)
        self.assertEqual(output['notification'], 'unknown')
        self.assertEqual(send.call_count, 1)

    def test_concurrent_monitor_skips_before_query(self):
        args = self.args + ['--state', str(self.state)]
        with self.state.with_suffix('.json.lock').open('w') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            with patch.object(watch, 'run_json') as query:
                code, output = self.invoke(watch.main, args)
            query.assert_not_called()
        self.assertEqual(code, 0)
        self.assertTrue(output['skipped'])

    def test_failed_query_never_overwrites_snapshot(self):
        args = self.args + ['--state', str(self.state)]
        with patch.object(watch, 'run_json', return_value=fixture()):
            self.invoke(watch.main, args)
        before = self.state.read_bytes()
        with patch.object(watch, 'run_json', side_effect=flow.CommandError(1, {})):
            self.assertEqual(self.invoke(watch.main, args)[0], 1)
        self.assertEqual(self.state.read_bytes(), before)

    def test_different_chinese_routes_do_not_collide(self):
        with patch.object(watch, 'DEFAULT_STATE_DIR', self.root), patch.object(watch, 'run_json', return_value=fixture()):
            first = self.invoke(watch.main, self.args)[1]
            other = [*self.args]
            other[other.index('北京')] = '南阳'
            second = self.invoke(watch.main, other)[1]
        self.assertNotEqual(first['state'], second['state'])


if __name__ == '__main__':
    unittest.main()
