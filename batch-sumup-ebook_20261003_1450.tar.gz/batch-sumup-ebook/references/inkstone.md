# 默认合并与 Inkstone 提交

## 流程与范围

用户已明确要求增加默认流程：每本书的 `summary`、`insights` 阶段完成后，将 **`summary.md` 与 `modern_insights.md`** 合为一篇 Markdown，使用 `inkstone-md` 提交到默认服务。

- 默认服务：`https://md.allez.cc.cd/mcp`。
- 电子书目标文件夹：用户指定的 **`Ebooks`**，ID **`01m407exy0s1sa80y44e567ym7`**，`parent_id: null`、`path: Ebooks`。
- URL 从兄弟技能 `inkstone-md/scripts/inkstone_client_optimized.py` 读取；本流程显式传入 Ebooks ID，通用 Inkstone 客户端的 Notes 默认值不变。没有联网核验用户提供的 `note_count: 0`，也不把该数量作为运行前提。
- 每本书单独生成 `~/Downloads/summary_voice/<书名>/reading_notes.md`，笔记标题为 `<书名>｜摘要与现代启示`。
- 只使用这两份 Markdown。`summary.txt`、`summary_voice.txt`、原电子书、分块、AI 提示词、状态和校验文件不提交。
- 不递归扫描输出目录，不调用额外 AI，不修改原书或两份源 Markdown。
- 合并/提交在 `insights` 完成后、`voice` 开始前执行；即使后续播报稿未达标，已提交的笔记也不会被删除。

合并结构如下；正文原样保留，不用模型再加工：

```markdown
# 书名｜摘要与现代启示

## 内容摘要

（summary.md 全文）

---

## 现代启示与行动建议

（modern_insights.md 全文）
```

`summary` 的 AI 响应仍须严格提供 `---summary.txt---` 和 `---summary.md---` 两个非空段落。不合规会报生成错误，不把未拆分响应当成 Markdown 提交；修正对应 AI 响应后再运行。

## 执行与授权

正常使用技能时直接给电子书目录，当前会话按既有 AI 文件交接循环推进：

```bash
python3 ~/.config/omnirush/skills/batch-sumup-ebook/scripts/batch_sumup_ebook.py "/path/to/books"
```

这是**带远端写入的默认流程**。每次开始时告知发送内容和目标；用户要求只生成本地文件时必须使用：

```bash
python3 ~/.config/omnirush/skills/batch-sumup-ebook/scripts/batch_sumup_ebook.py "/path/to/books" --local-only
```

`--local-only` 仍生成合并文档，但不加载 Inkstone 客户端、不读提交凭据、不连接远端。每次 AI 交接重跑都保留这个参数。之后用户明确要提交时，可去掉该参数：合格播报稿不会重写，来源匹配的 Markdown 会补提交。

安装或验证功能不授权发送已有书稿。本次测试只使用临时合成内容和本机回环 MCP 服务。

### 凭据

沿用 `inkstone-md`：仅由运行脚本的进程环境变量 `INKSTONE_API_KEY` 提供。

- 不读取、修改或同步共享 `.env`；不从旧脚本或配置复制密钥。
- 不打印 Key、不让用户将 Key 粘贴到聊天里。
- 缺少变量时保留本地合并文档，标记 `blocked / INKSTONE_API_KEY_not_set`，继续生成播报稿。
- `curl` 仍是原有传输层，TLS 校验和代理行为不改变；Bearer 请求头经标准输入传给 curl，不放进进程命令参数。

## 重复运行、更新和冲突

`ebook_inkstone.py` 复用兄弟技能的 **MCP 传输函数**，不复制 HTTP 服务实现。它使用独立的内容指纹与私有凭据文件，不使用旧 `create` 命令“只按文件路径跳过”的 `.inkstone-import.jsonl` 机制。

- 文档 SHA-256 与已成功记录一致：`already_submitted`，不再请求远端。该状态可能是同一批次在 AI 交接时的复用，不一定来自以前批次；也不代表刚刚重新核验了远端是否仍存在。
- 文档变化：根据之前成功创建的 `note_id` 获取原笔记。只有远端正文和标题与上次提交一致、返回可用修订号、且已返回的 folder ID 未改变时，才使用 `edit_note / replace_all / expected_rev` 更新同一笔记。
- 远端正文/标题被手动修改、移入其他已知文件夹、修订信息不可核验：阻塞，不覆盖、不另建副本。
- 服务或目标文件夹与历史凭据不一致：阻塞，先检查目标，不跨目标复用 note ID；以前如有 Notes 的提交记录，不会自动迁移或覆盖。
- 无来源记录的旧输出、缺失/空白/软链接 Markdown、损坏凭据：阻塞，不猜测，不提交。

### 网络不确定性

每本书使用文件锁。发出写请求之前，先原子保存并 fsync `.inkstone-submit.json` 中的目标、内容指纹、operation ID 和 `in_flight` 意图。

只有得到可识别的正确 note ID 回执并成功保存后，才记为 `submitted` 或 `updated`。MCP `isError`、失败标志、异常响应不会算成功。

超时、断连、中断、响应缺少 ID 或写回本地凭据失败时，远端可能已经创建/修改笔记。状态为 `uncertain`，后续交接及重复运行**不自动重发**，即便本地内容已改变也不会绕过该保护。不要随意删除凭据、添加 `--no-resume` 或按标题盲目再创建。

应先在 Inkstone 中人工核对结果，再由用户明确决定如何恢复。当前未提供自动搜索猜测、自动冲突覆盖或通用“强制重试”开关。若手动使用 Inkstone 客户端处理了笔记，还需核对本地凭据，避免两套断点互相矛盾。

## 结果与退出码

每本书的 `inkstone_result.json` 和最终 `batch_result.json.results[].inkstone` 保存独立状态；最终报告顶层 `inkstone` 保存数量（`complete` 为提交、更新及成功复用总数）：

| 状态 | 含义 |
| --- | --- |
| `submitted` | 服务返回创建回执，私有凭据已保存 |
| `updated` | 带修订保护更新了同一 note ID |
| `already_submitted` | 相同内容此前已有成功凭据，未再次发送 |
| `local_only` | 用户明确只生成本地文档 |
| `blocked` | 配置、文件、来源、目标或远端冲突阻止提交 |
| `uncertain` | 曾发起写请求，结果不明，必须先核对 |
| `not_generated` | 尚未完成 Markdown 两阶段，没有可提交内容 |

- 文稿 `success/skipped/needs_update/failed` 与 Inkstone 状态分别记录，互不冒充。
- `status: complete` 是批次流程结束，不等于一切成功；存在生成失败、待更新或提交未完成时退出码为 1。
- `awaiting_ai` 仍返回 10；其中可能已经有笔记提交结果，必须继续完成剩余文稿阶段。
- 通知仍需单独授权；启用后会包含 Inkstone 数量和逐书状态，不附带摘要全文、Key 或远端原始错误。

## 验证边界

自动测试验证合并内容、每书一篇、默认提交流程、仅本地开关、已有稿补提交、重跑去重、受保护更新、远端编辑冲突、缺少密钥、丢失回执、锁、私有断点、严格摘要拆分、通知中的分离统计，以及真实 curl 到本机回环 MCP 的请求头/正文/SSE 处理。

没有真实调用默认 Inkstone 服务，尚未验证当前 Key 的有效性、服务端实际回执字段与修订/更新行为。无法确认回执的写请求会被保守标为 `uncertain`，不会假报成功或盲目重复写入。
