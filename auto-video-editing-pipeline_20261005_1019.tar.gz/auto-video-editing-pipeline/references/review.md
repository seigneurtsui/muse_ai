# Review Package and Approval Gate

The pipeline uses evidence before irreversible editing decisions. `ffprobe`
derives resolution, orientation, duration, streams, and frame behavior; do not
ask the user for facts that can be measured.

## Review contents

When a review is requested, present one consolidated review containing:

1. source facts and detected VFR/CFR behavior;
2. subtitle corrections and uncertain terms;
3. candidate highlights with source ranges, transcript evidence, and intended
   placement;
4. speed and trim alternatives, including why a silent interval is or is not a
   40x candidate;
5. subtitle languages, style, highlighted terms, badge settings, and output
   canvas;
6. target platforms and any creator-profile constraints when a release package
   is requested.

The user-named moment outranks heuristic scoring, but every cut still obeys
phrase boundaries and final QA.

## Current CLI gate

For a subtitle/badge/render review after the ASS has been generated:

```bash
python3 "$PIPE" <input> --stop-for-review --resume
# inspect each video's review.md, then:
python3 "$PIPE" --resume-batch <batch> --approve-review --resume
```

For `--edit-mode --stop-for-review`, the pipeline instead pauses before encoding
and writes `edit-review.md` plus `edit-plan.json`. The user can edit its `ranges`
to override the selected highlight and per-range speeds. `--approve-review`
reuses this file; saved options are restored from `state.json`.

Without `--stop-for-review`, explicit `--edit-mode` executes the automatic plan;
it records an automatic choice, not a user-approved score. A normal subtitle-only
request does not require an added review gate. Waiting reviews return exit 11
and defer merging, release packaging, and completion notifications.

Record the decision in `project.md`, including high-light ranges, speed, body
retention/deletion, subtitle languages, and remaining risks.
