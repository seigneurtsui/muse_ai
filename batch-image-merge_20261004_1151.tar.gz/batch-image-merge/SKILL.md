---
name: batch-image-merge
description: "批量处理并合并目录中的图片：竖向/横向拼接、任意 列x行 矩阵拼图（自动分页）、GIF 动图、PDF 相册导出；支持文件名/EXIF 时间等排序、去重、抽样、标签、水印、尺寸限制。Use when the user asks to 合并图片、拼图、图片排版、批量处理图片目录、生成 GIF 或 PDF 相册 (merge images, contact sheet, grid collage, batch image processing, GIF slideshow, PDF album)."
version: 2.0.0
metadata:
  needs:
    pythonPackages:
      - Pillow
---

# batch-image-merge

批量图片处理与合并技能。扫描一个图片目录，按指定顺序与规则，输出竖向/横向合并图、
矩阵拼图、GIF 动图或 PDF 相册。无需云端，全部本地完成（基于 Pillow）。

## 何时使用

- 用户要求把某个目录里的图片**合并成一张长图**（竖向/横向）
- 需要**拼图 / 九宫格 / contact sheet / 矩阵排版**（支持自动分页）
- 需要把一批图片转成 **GIF 动图**（可逐张设置显示时长）
- 需要把图片目录汇总成 **PDF 相册**
- 批量预处理图片：排序、去重、抽样、限制数量、加标签、加水印、限制输出尺寸

## 环境要求（本机已满足）

- Python 3.10+（本机 3.12）
- Pillow（本机 12.3）

```bash
python3 -m pip install Pillow   # 仅在缺失时安装
```

## 快速用法

脚本位置：`{baseDir}/scripts/merge_images.py`

```bash
# 全量输出（竖向 + 横向 + 矩阵 + GIF + PDF）
python3 {baseDir}/scripts/merge_images.py "/path/to/photos" --mode all --grid 3x6

# 竖向长图
python3 {baseDir}/scripts/merge_images.py "/path/to/photos" --mode vertical

# 矩阵拼图，3 列 6 行，超出自动分页
python3 {baseDir}/scripts/merge_images.py "/path/to/photos" --mode grid --grid 3x6 --gap 8 --label

# GIF：每张 0.8 秒，宽度 640
python3 {baseDir}/scripts/merge_images.py "/path/to/photos" --mode gif --gif-duration 0.8 --gif-width 640

# GIF：逐张自定义时长（文件内容：文件名 秒数）
python3 {baseDir}/scripts/merge_images.py "/path/to/photos" --mode gif --durations-file durations.txt

# PDF 相册
python3 {baseDir}/scripts/merge_images.py "/path/to/photos" --mode pdf --pdf-name album.pdf

# 先预览排序结果，不产生任何输出（不建目录）
python3 {baseDir}/scripts/merge_images.py "/path/to/photos" --dry-run
```

默认输出目录：`~/Downloads/matrix_pix/YYYYMMDD_HHMM_<输入文件夹名>/`
可用 `--output-root` / `--output-subdir` / `--output-date` / `--output-code` 定制。

## 主要参数

| 参数 | 默认 | 说明 |
|---|---|---|
| `input_dir` | 必填 | 输入图片目录 |
| `--mode` | `all` | `vertical` / `horizontal` / `grid` / `gif` / `pdf` / `all`；`all` 输出全部五类 |
| `--grid` | 空 | 矩阵规格，可多个：`--grid 3x6 2x2`；每页超出容量自动分页 |
| `--cell-size` | 自动 | 矩阵单格尺寸 `WxH`，默认取所有图的最大宽高 |
| `--gap` | `0` | 图片间距（像素） |
| `--bg` | `white` | 背景色 |
| `--output-format` | `jpg` | 静态图输出格式：`jpg`/`png`/`webp` |
| `--quality` | `90` | jpg/webp 质量 |
| `--max-dimension` | 无 | 输出最长边像素上限 |
| `--sort` | `name` | `name`/`type`/`mtime`/`ctime`/`exif`/`size`/`random`/`list` |
| `--reverse` | 关 | 反向排序 |
| `--order-file` | 无 | `--sort list` 时的自定义顺序清单（每行一个文件名） |
| `--seed` | 无 | `random` 排序 / `--sample` 的随机种子 |
| `--dedup` | 关 | 按内容哈希去重（并行计算） |
| `--sample` | 无 | 随机抽样 N 张 |
| `--limit` | 无 | 只取前 N 张 |
| `--label` / `--label-mode` | 关 / `filename` | 图片下方标签；`filename` 或 `index` |
| `--watermark` / `--watermark-text` | 无 | 图片水印 / 文字水印 |
| `--watermark-opacity` / `--watermark-position` | `0.6` / `bottom-right` | 水印透明度 / 位置 |
| `--recursive` | 关 | 递归子目录 |
| `--ext` | 内置常见格式 | 自定义扩展名，如 `.jpg,.png` |
| `--gif-duration` | `0.5` | GIF 每张默认秒数 |
| `--durations-file` | 无 | 逐张时长：每行 `文件名 秒数` |
| `--gif-width` / `--gif-height` / `--gif-loop` | 无 / 无 / `0` | GIF 尺寸与循环（0=无限） |
| `--gif-optimize` | 关 | 启用调色板优化（体积更小、略慢） |
| `--pdf-name` / `--pdf-resolution` | `album.pdf` / `90` | PDF 文件名与 DPI |
| `--workers` | CPU 核数（上限 8） | 并行解码线程数 |
| `--no-parallel` | 关 | 等价于 `--workers 1` |
| `--no-manifest` | 关 | 不写 `manifest.json` |
| `--dry-run` | 关 | 只打印排序结果，不建目录、不输出 |
| `--version` | — | 打印版本 |

## 输出结构

```
<output_root>/<YYYYMMDD_HHMM_文件夹名>/
├── vertical_merged.jpg        # 竖向合并
├── horizontal_merged.jpg      # 横向合并
├── grid_3x6.jpg               # 矩阵；多页时为 grid_3x6_p01.jpg ...
├── images.gif                 # GIF 动图
├── album.pdf                  # PDF 相册
└── manifest.json              # 运行清单：版本、设置、图片列表、产物、耗时
```

## 性能说明（相对原脚本的改进）

- **并行解码**：`--workers`（默认取 CPU 核数，上限 8）同时解码/缩放，矩阵拼图与 GIF
  在 30 张 2400×1600 图片上实测约快 1.6–2 倍。串行或内存紧张时用 `--workers 1` / `--no-parallel`。
- **单次打开**：每张图片只打开解码一次（原脚本为取尺寸会重复打开）。
- **方向校正**：画布尺寸按 EXIF 方向校正后的真实宽高计算，修正竖拍图合并错位。
- 并行会同时驻留多张图片，峰值内存更高；超大目录可降低 `--workers`。

## 运行规则（agent 执行时遵守）

1. **只在输出目录写产物**，绝不修改或删除输入目录里的原始图片。
2. 执行前确认输入目录存在；批量较大时先用 `--dry-run` 展示排序结果让用户确认。
3. 交付前核对 `manifest.json` 中的 `outputs` 与磁盘产物一致；`--dry-run` 不产生任何文件。
4. `--mode grid` 未提供 `--grid` 时不会产出拼图，需补上规格。
5. 报告时给出输出目录路径、产物数量与耗时，不得声称未生成的产物已生成。

## 测试

本地回归测试（只在临时目录生成合成图，不触碰用户数据）：

```bash
python3 -m unittest discover -s {baseDir}/tests -v
```
