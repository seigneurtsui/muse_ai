---
name: auto-video-editing-pipeline
description: >-
  批量处理指定目录中的本地视频：ffprobe 检查、faster-whisper-stt 离线转写、
  erratum-correction 字幕勘误、s2t 简繁转换、srt-ass-studio ASS 样式化、
  可配置 badge、FFmpeg 渲染、完整预览审批、EDL 与剪辑边界视听材料，默认按文件名合并成片；
  可选 edge-tts 逐句缓存/时间轴配音/原声压低、edit-mode 五轴高光/分段变速、release-pack 八平台发布包、静音/冻结审计、
  HyperFrames HTML promo 路由和创作者画像。可通过
  multiple-channel-notifier 发送批次摘要；不自动上传或发布视频。
version: 2.3.0
metadata:
  short-description: Local batch video editing with reusable STT, review gates, subtitles, silence evidence, rendering, QA, and release packaging
  dependencies:
    - faster-whisper-stt
    - erratum-correction
    - s2t
    - srt-ass-studio
    - multiple-channel-notifier
    - edge-tts (optional; script opt-in)
    - ffmpeg
    - ffprobe
---

# Auto Video Editing Pipeline

这是一个**批量、本地、可恢复**的视频编辑技能。它以 `/tmp/auto_video_pipeline/`
的成熟交付流程为基础，吸收 `/tmp/auto-video-editing-pipeline/` 的项目契约与 QA
规则，并移植 `chatgpt-short-video-editor` 的八步顺序、源文件保护、短视频预览门和
phrase-level STT 边界纪律。

## 硬性流程

```text
ffprobe intake
  → faster-whisper-stt（本地、断点、SRT/TXT）
  → erratum-correction（当前会话模型；白名单进入校对上下文）
  → s2t（仅在目标字形不同且明确时调用）
  → edit-mode（可选：分析/分段变速/拼接并重算字幕）
  → srt-ass-studio（SRT → ASS，样式/动效/高亮/双语可选）
  → badge 注入（精确时间、位置、时长）
  → EDL / 逐段粗剪（短语边界留白、音频淡入淡出）
  → edge-tts（可选：明确提供脚本才合成/缓存/放置/原声压低）
  → FFmpeg 变速/缩放/混音/字幕最后烧录
  → complete preview / full-decode / frames / boundary clips+audio / QA report
  → preview approval（仅 --stop-for-preview 开启；批准后才渲染 final）
  → merge（默认开启：文件名排序/规格归一化/拼接 QA）
  → release-pack（可选：当前会话生成八平台文案/校验落盘）
  → multiple-channel-notifier（仅明确指定渠道时）
```

对于长视频或需要变速/裁切的项目，推荐在编辑前追加：

```text
silence_motion.py（静音 + 画面冻结证据）
  → review package（一次性审核门）
  → approved edit
```

所有源视频保持不变。所有中间文件、请求、响应、报告和成片写入独立批次目录。
默认关闭真实通知；`--notify-channels`、`--notify-all` 或 `--notify-dry-run` 才会
启用通知流程。不会读取、复制或硬编码外部 AI 密钥。

默认技能家目录统一为 `~/.config/omnirush/skills`，不使用源技能示例中的其他目录。
STT 仍在本地完成。**edge-tts 是云端语音合成**：明确提供 `--voiceover-script`
表示启用配音，将脚本文字发送至 Microsoft Edge 服务，不上传视频或源音轨；
未提供脚本时不调用 TTS、不读取其配置，也不默认生成旁白。

### 模式路由

- **批量口播/教程/演示/游戏视频**：使用当前脚本的 STT → 勘误 → ASS →
  badge → FFmpeg → QA 流程。
- **字幕-only**：保持 `--speed 1.0`，不自动裁切，不凭空添加高光。
- **edit-mode**：显式使用 `--edit-mode` 才开启五轴高光分析、片头高光前置和
  分区间变速。默认生成文本启发式评分，五轴及证据全部落盘；不假称做过音视频
  语义分析。初次运行默认关闭；恢复时沿用已有设置，`--no-edit-mode` 可关闭。
- **完整预览审批**：`--stop-for-preview` 在每个视频完整预览及技术 QA 后暂停；
  `--approve-preview` 批准本批次已有、未变更的预览。审稿与预览审批是独立的门，
  `--approve-review` 不等于批准预览。`--preview` 仅生成预览，不强制审批。
- **时间轴配音**：`--voiceover-script` 接收输出时间轴 JSON；逐句缓存、验证音频、
  在指定时间放置并只在配音发声期间压低原声。超出时槽不会静默截断或变速。
- **静音/冻结审计**：显式使用 `--silence-motion`；报告只提供证据，不自动
  把静音片段加速到 40x。
- **HTML/Webpage promo**：先读取 `references/hyperframes-promo.md`，通过
  HyperFrames 生成 MP4，再按需要把 MP4 交给本技能做字幕、规格归一化和 QA；
  不对 HTML 源码运行 faster-whisper。
- **发布包**：成片和 QA 通过后，读取 `references/release-package.md` 与
  `references/platform-publish-pack.md`。`--release-pack` 请求八平台物料，通过
  当前会话 request/response 接续生成；脚本不调用外部模型，也不把通用模板当正文。

## 快速开始

入口脚本：

```bash
PIPE="$HOME/.config/omnirush/skills/auto-video-editing-pipeline/scripts/auto_video_pipeline.py"

# 先只探测并生成处理计划，不写出片文件
python3 "$PIPE" "/path/to/videos" --dry-run

# 批量处理目录：中文字幕 + cinematic ASS + H.264/AAC + QA
python3 "$PIPE" "/path/to/videos" --language zh --resume

# 竖屏短视频：保留语音，字幕最后烧录，生成预览和正式成片
python3 "$PIPE" "/path/to/videos" \
  --canvas vertical --preset cinematic --effect fade \
  --preview --resume

# 完整预览 + 边界材料审核后再定稿（初次等待退出码 11）
python3 "$PIPE" "/path/to/videos" --stop-for-preview --resume
# 完整观看各视频 preview.mp4 与 qa/preview/boundaries/ 后，用户明确批准：
python3 "$PIPE" --resume-batch "/实际的批次目录" --approve-preview

# 仅在明确提供脚本时启用配音；脚本文字会发送到 Edge 云端
python3 "$PIPE" "/path/to/video.mp4" --voiceover-script "/path/to/voiceover.json" \
  --voiceover-voice zh-CN-YunxiNeural --voiceover-duck-db -12 \
  --voiceover-captions voiceover --stop-for-preview --resume

# 明确要求繁体字幕时，使用成熟 s2t 适配层
python3 "$PIPE" "/path/to/videos" \
  --subtitle-lang zh-Hant --source-script zh-Hans --resume

# 自定义 badge：从 0.4s 显示到 2.8s，右上角，精确 2.4s
python3 "$PIPE" "/path/to/videos" \
  --badge-text "高能时刻" --badge-start 0.4 --badge-end 2.8 \
  --badge-position top-right --badge-anim pop

# 开启剪辑模式：五轴候选分析、片头高光、正文分区间变速
python3 "$PIPE" "/path/to/videos" \
  --edit-mode --edit-body-speed 1.15 --edit-highlight-speed 1.0 --resume

# 默认会合并；如只需要每个视频自己的 final.mp4，显式关闭
python3 "$PIPE" "/path/to/videos" --no-merge --resume

# final QA 后生成多平台发布包草稿
python3 "$PIPE" "/path/to/videos" --release-pack --resume

# 先生成静音/冻结证据报告，不改变视频速度
python3 "$PIPE" "/path/to/videos" --silence-motion --resume
```

### 当前会话 AI 勘误的接续

`erratum-correction` 遇到 AI 请求时会返回退出码 `10`，这表示“等待当前
OmniRush 会话写入 response”，不是失败。读取终端 JSON 中的 `pending_requests`，
完整读取每个 `request_path`，严格按其中的 schema 将结果写入 `response_path`，然后
用同一个批次继续：

```bash
python3 "$PIPE" --resume-batch "/实际的批次目录"
```

不要重新输入源目录创建新批次，也不要用外部 provider、HTTP API 或另一模型替代。

### 发布包接续（--release-pack）

最终视频通过 QA 后若返回 `status: awaiting_ai` / 退出码 `10`，读取
`release_pack.pending_requests` 中每个完整 `request_path`（包含最终字幕证据、
抽帧路径、画像与 response schema）。由**当前会话**完成八平台独立文案，将 JSON
写到对应 `response_path`，然后使用同一 `--resume-batch` 继续，直到状态 complete。
请求 ID 绑定成片哈希、字幕和画像；内容变化时自动创建新版本，拒绝旧 response。
这属于 Agent 执行步骤，不能仅留下 request 就声称发布包已经生成。

`--stop-for-review` 等待审稿的退出码为 `11`，不是处理失败。编辑模式在分段渲染前
暂停，可修改该视频的 `edit-plan.json`，再 `--approve-review` 接续。普通字幕模式
在 ASS 生成后暂停。所有已知参数会从批次恢复，不需要重复输入字体、高亮、速度等。

`--stop-for-preview` 同样使用退出码 `11`，但状态是 `awaiting_preview`，
`summary.awaiting_preview` 单独计数。必须先有完整预览、通过其技术 QA，再用同一批次
`--approve-preview` 接续。审批绑定预览 SHA-256、源素材、字幕、EDL、混音和渲染参数；
任一变化或 `--force-render` 都会生成新预览并再次等待，不能顺便批准新内容。
审批参数是单次动作，不从 `state.json` 自动继承。所有单片通过后才允许合并/发布包。
最多三次**证据驱动**修复由当前会话控制；脚本不进行盲目自动修复循环。

## 输入与输出

- 输入可以是一个视频、多个视频路径或目录；目录默认递归扫描。
- 支持 `.mp4 .mov .mkv .avi .webm .m4v .ts .flv .wmv`。
- 默认输出：`~/Downloads/auto_video_editing_pipeline/<YYYYMMDD_HHMM_slug>/`。
- 每个视频独立处理，不因一个文件失败而覆盖或丢弃其他文件。
- 断点时使用 `--resume-batch <batch_dir>`，或在首次命令中使用 `--resume` 让各阶段
  复用已经验证的产物。
- 中文主字幕默认字号为 `200`，默认字体文件为
  `~/Library/Fonts/字魂龙腾楷书.ttf`；字体文件会自动解析为 fontconfig/libass
  字体族名。可用 `--subtitle-font-file` 或 `--subtitle-font-name` 切换字体。
- 可选的 `creator-profile.md` 只属于当前批次/项目；发布包生成前读取，不能把
  真实画像写回共享 skill。

批次结构：

```text
batch/
├── batch.json                  # 创建时的输入/参数快照
├── state.json                  # 可恢复状态快照
├── project.md                  # 机器/人工决策与风险记录
├── stt/                        # faster-whisper-stt 适配层的共享模型批次
├── erratum/                    # 私有勘误批次、pending request、response、报告
├── videos/<video-id>/
│   ├── transcripts/subtitle_clean.srt
│   ├── transcripts/transcript_merged.txt
│   ├── corrections/<name>_corrected.srt
│   ├── subtitles/<name>_timeline.srt  # edit-mode 为 <name>_edit_timeline.srt
│   ├── subtitles/<name>.ass
│   ├── edl.json                 # 源区间、留白、速度、输出偏移、引用/理由/STT 引擎
│   ├── preview.mp4              # --preview 或 --stop-for-preview，完整片长
│   ├── preview-review.md        # 开启预览审批时
│   ├── tts/                    # 提供配音脚本时：逐句 MP3/cache/manifest/WAV/SRT
│   ├── final.mp4
│   ├── edit-plan.json             # 使用 --edit-mode 时
│   ├── edit-review.md             # 使用 --edit-mode 时
│   ├── edit_mode/segments/        # 使用 --edit-mode 时
│   └── qa/
│       ├── final/QA报告.md + report.json + frames/
│       ├── preview/              # --preview 或 --stop-for-preview
│       │   └── boundaries/       # 每个 EDL 边界 ±1.5s 视频/WAV/index/review
│       ├── final/boundaries/     # 正式文件另生成视听材料
│       ├── silence-motion-report.md  # 使用 --silence-motion 时
│       └── silence-motion-report.json
├── creator-profile.md           # 可选，用户明确提供后复制
├── 发布包/<merged或video-id>/<内容指纹>/  # request/response + 八平台文案/总览/封面/计划
├── final.mp4                     # 默认生成，按输入文件名顺序合并
├── final.srt                     # 同步合并后的字幕时间轴；无需再次烧录
├── edl.json                      # 批次 EDL：保留源引用与合并后输出偏移
├── qa/merged/                    # 合并成片 QA
└── batch_report.json
```

## 关键边界

1. **STT**：只通过已安装的 `faster-whisper-stt`；输出按 phrase-level 处理并标记
   lower-confidence。裁切点必须落在字幕短语边缘或字幕间隙；拒绝短语中间切断。
   默认留白 120ms，只向字幕间隙扩展（邻近语音/源首尾可缩短）；连续源区间的接缝
   不加重叠留白。每段音频默认约 30ms 淡入淡出；字幕按实际渲染区间重算。
2. **字幕纠错**：只通过已安装的 `erratum-correction`。本技能的
   `ai_whitelist.txt` 会被适配层作为 `context.protected_terms` 传给当前会话模型，
   同时保留成熟技能的结构校验、请求接续、报告和原文不覆盖规则。
3. **简繁转换**：不自行导入 OpenCC。只有 `--source-script` 与
   `--subtitle-lang` 明确冲突时调用已安装的 `s2t` CLI。
4. **ASS**：不复制旧的 SRT→ASS 实现；直接调用 `srt-ass-studio`，包括预设、折行、
   高亮、双语、动效和样式校验。
5. **Badge**：在成熟 ASS 产物之后注入独立 `Badge` 样式，允许独立控制文本、开始时间、
   结束时间、位置、字体、字号、颜色、描边、淡入淡出和 pop 动画。
6. **通知**：通过 `multiple-channel-notifier`，先执行相同消息的 `--dry-run`，再在
   用户明确给出渠道时发送。通知正文只包含计数和状态，不含字幕正文、密钥或本地路径。
7. **QA**：没有 `final.mp4` 的完整解码、分辨率/帧率/音频检查、抽帧和字幕时间检查，
   不称为完成。预览和正式成片必须分开记录。完整 720p 预览为竖屏 720×1280、
   横屏 1280×720（小素材不放大），不是竖屏最长边 720px。边界材料生成成功不等于
   人工已经观看/试听；跳帧、爆音、同步、字幕安全区、叠层与混音需明确复核。
8. **静音证据**：静音但有可读文字、UI 操作、游戏结果或有用运动的区间不得仅凭
   音频判定为 40x；`eligible_40x` 仍需人工确认。
9. **发布边界**：平台标题、简介、标签、封面提示词和发布时间建议必须先经过人工
   审核；本技能不发布、不上传、不定时。
10. **合并顺序**：`--merge` 默认开启，使用批次记录的输入文件名顺序合并；
    文件名按忽略大小写的字典序排列，同名以完整路径排序，建议使用 `01_`、`02_`
    前缀。`--no-merge` 跳过批次成片。已有批次首次启用新功能会固定 filename 顺序。
    必须所有单片完成后才合并，不把缺失片段静默跳过。规格不同时以排序首片画布
    等比缩放加黑边，帧率用 `--fps`，缺音轨补静音；拼接点额外抽帧并检验总时长。

## 常用参数

| 参数 | 说明 |
|---|---|
| `--resume-batch PATH` | 继续同一批次，尤其用于 AI 勘误请求接续 |
| `--resume` | 复用同批次内已成功阶段；首次运行也建议开启 |
| `--creator-profile PATH` | 将用户明确提供的画像模板复制到当前批次 |
| `--language zh` | faster-whisper 语言；省略则自动识别 |
| `--model PATH_OR_HF` | 传给 faster-whisper-stt 的模型；默认本地 large-v3-turbo int8 |
| `--chunk-duration SEC` | STT 长音频分片，默认 900 |
| `--subtitle-lang zh-Hans/zh-Hant` | 输出字形目标 |
| `--source-script zh-Hans/zh-Hant/auto` | 输入字形；默认 `zh-Hans`，因此目标 `zh-Hant` 会走 s2t；不确定时用 `auto` 跳过转换 |
| `--preset` | 传给 srt-ass-studio，如 `cinematic`、`vertical`、`karaoke` |
| `--effect` | `static`、`fade`、`slide-*`、`karaoke`、`typewriter` 等 |
| `--highlight TERM` | 可重复，传给 srt-ass-studio 做字幕高亮 |
| `--canvas auto/vertical/landscape` | 输出画布；auto 使用源视频尺寸 |
| `--speed N` | 全片速度；字幕按输出时间轴重算 |
| `--trim-start/--trim-end` | 源时间轴裁切，须由用户确认且尽量贴合 phrase 边界 |
| `--loudnorm` | 用 FFmpeg loudnorm 统一音量 |
| `--preview` | 输出完整 720p 预览并技术 QA，不强制审批 |
| `--stop-for-preview` / `--no-stop-for-preview` | 开启/关闭完整预览审批；默认关闭 |
| `--approve-preview` | 批准同批次已有且未变更的 QA 通过预览；不能代替审稿 |
| `--cut-padding-ms N` | 默认 120，范围 0–200ms；0 禁用；只向字幕间隙扩展 |
| `--audio-fade-ms N` | 每段音频边界淡入淡出，默认 30，0 禁用 |
| `--voiceover-script PATH` | 显式启用 Edge 云端配音；输出时间轴 JSON，支持 videos 映射 |
| `--voiceover-voice/--voiceover-rate/--voiceover-volume` | 音色、语速、音量；百分比负值建议写成 `--voiceover-rate=-10%` |
| `--voiceover-duck-db N` | 配音发声时原声压低，默认 -12dB，允许 -60–0 |
| `--voiceover-captions source/voiceover` | 保留源字幕（默认）或使用配音脚本字幕 |
| `--force-render` | 复用 STT/勘误结果，重新生成字幕、成片和 QA |
| `--silence-motion` | 生成静音/冻结审计 Markdown + JSON，不自动加速 |
| `--merge` / `--no-merge` | 默认合并/关闭批次级合并；合并输出为批次根目录 `final.mp4` |
| `--edit-mode` | 开启五轴高光分析、开场高光前置和分区间变速；默认关闭 |
| `--edit-highlight-duration SEC` | edit-mode 片头高光目标时长，默认 8 秒 |
| `--edit-highlight-speed N` | edit-mode 片头高光速度，默认 1.0x |
| `--edit-body-speed N` | edit-mode 正文速度；省略时沿用 `--speed` |
| `--edit-plan PATH` | 自定义输出顺序和逐区间速度 JSON；与 `--edit-mode` 配合 |
| `--stop-for-review` / `--approve-review` | 生成审核草稿后暂停 / 使用已保存计划继续 |
| `--release-pack` / `--no-release-pack` | 开启/关闭八平台发布包；初次默认关闭，恢复沿用设置 |
| `--subtitle-font-size 200` | 中文主字幕字号，默认 200 |
| `--subtitle-font-file PATH` | 中文主字幕字体文件，默认字魂龙腾楷书 |
| `--subtitle-font-name NAME` | 直接指定 libass/fontconfig 字体族名 |
| `--highlight-font-file PATH` | highlight keyword 独立字体文件 |
| `--highlight-font-name NAME` | highlight keyword 独立字体族名 |
| `--highlight-size N` | highlight keyword 独立字号 |
| `--highlight-color RRGGBB` | highlight keyword 独立字色 |
| `--badge-font-file PATH` | badge 独立字体文件 |
| `--badge-font-name NAME` | badge 独立字体族名 |
| `--badge-size N` / `--badge-color RRGGBB` | badge 独立字号和字色 |
| `--badge-*` | badge 的文本、时间、位置、样式和动画 |
| `--notify-channels a,b` | 明确指定 notifier 实例；不指定则不发送 |
| `--notify-dry-run` | 只检查 notifier，不发送 |

完整参数：

```bash
python3 "$PIPE" --help
```

## 白名单文件

默认文件：`ai_whitelist.txt`。每行一个词条，支持注释和三段式备注：

```text
# 词 | 类别 | 备注
襄阳古城 | 地名
护城河 | 地物 | ASR 常误写为"城河"
```

白名单不会被写入公共技能之外的词典，也不会自动发布为正式纠错规则；它只在本批次
勘误请求中作为受保护专名使用。可用 `--whitelist-file` 指定另一份文件。

## 移植的短视频能力

本技能默认采用 `chatgpt-short-video-editor` 的适配规则：八步工作顺序、ffprobe
intake、源素材 immutable、Whisper lower-confidence 标注、短语边界与至少 400ms 静音
优先、显式开启完整预览审批后预览先于正式输出、最多三次证据驱动修复、字幕作为最后视觉操作、完整 QA 后才
交付。它不默认添加 B-roll、音乐、CTA、上传或发布动作；这些必须由用户另行授权。

参考细节见：

- `references/pipeline.md`
- `references/short-video-rules.md`
- `references/badge.md`
- `references/review.md`
- `references/edit-evidence.md`
- `references/voiceover.md`
- `references/edit-mode.md`
- `references/silence-motion.md`
- `references/creator-profile-template.md`
- `references/hyperframes-promo.md`
- `references/hyperframes-setup.md`
- `references/release-package.md`
- `references/platform-publish-pack.md`
