#!/usr/bin/env python3
"""Inkstone MCP Markdown client with batch import/export support."""

from __future__ import annotations

import argparse
import json
import re
import ssl
import sys
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

BASE_URL = "https://md.allez.cc.cd/mcp"
API_KEY = "ink_Zldd3EjGqmbaS_Hy6Wp5KKle0BTxOnsmMPJBtJUiiII"

        # ~ "name": "Notes",
        # ~ "path": "Notes",
DEFAULT_IMPORT_FOLDER_ID = "01m2mrk9wth9y55961cxxmfarm"
DEFAULT_DOWNLOAD_ROOT = Path.home() / "Downloads" / "inkstone_md"


PROTOCOL_VERSION = "2025-11-25"
DEFAULT_TIMEOUT = 120

FOLDER_SEARCH_QUERIES = [
    "的", "是", "了", "人", "我", "你", "一", "不", "有", "在",
    "这", "他", "和", "就", "上", "也", "为", "到", "来源", "视频",
    "基本信息", "YouTube", "the", "of", "to", "and",
]


def ssl_context() -> ssl.SSLContext:
    try:
        import certifi  # type: ignore
        return ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        return ssl.create_default_context()


def mcp_call(method: str, params: dict[str, Any] | None = None, request_id: int = 1) -> dict[str, Any]:
    payload: dict[str, Any] = {"jsonrpc": "2.0", "id": request_id, "method": method}
    if params is not None:
        payload["params"] = params
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(
        BASE_URL,
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            "MCP-Protocol-Version": PROTOCOL_VERSION,
            "User-Agent": "inkstone-python-client/1.2",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=DEFAULT_TIMEOUT, context=ssl_context()) as response:
            raw = response.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {detail}") from exc
    except urllib.error.URLError as exc:
        reason = getattr(exc, "reason", exc)
        raise RuntimeError(
            f"网络/SSL 请求失败: {reason}\n"
            "macOS 可执行: python3 -m pip install -U certifi"
        ) from exc

    data_lines = [line[6:] for line in raw.splitlines() if line.startswith("data: ")]
    raw_json = data_lines[-1] if data_lines else raw.strip()
    if not raw_json:
        raise RuntimeError(f"服务器没有返回 JSON。原始响应:\n{raw}")
    try:
        result = json.loads(raw_json)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"无法解析服务器响应:\n{raw}") from exc
    if "error" in result:
        error = result["error"]
        raise RuntimeError(f"MCP 错误 {error.get('code', '')}: {error.get('message', error)}")
    return result


def tool_call(name: str, arguments: dict[str, Any], request_id: int = 1) -> Any:
    response = mcp_call("tools/call", {"name": name, "arguments": arguments}, request_id)
    result = response.get("result", {})
    structured = result.get("structuredContent")
    if structured is not None:
        return structured
    for item in result.get("content", []):
        if item.get("type") == "text":
            text = item.get("text", "")
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return text
    return result


def print_json(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2))


def folders(_: argparse.Namespace) -> None:
    print_json(tool_call("list_folders", {}, 10))


def search(args: argparse.Namespace) -> None:
    if args.folder or args.tags or args.starred is not None or args.archived is not None:
        arguments: dict[str, Any] = {"query": args.query, "limit": args.limit, "mode": args.mode}
        if args.folder:
            arguments["folder"] = args.folder
        if args.tags:
            arguments["tags"] = args.tags
        if args.starred is not None:
            arguments["starred"] = args.starred
        if args.archived is not None:
            arguments["archived"] = args.archived
        result = tool_call("search_notes", arguments, 20)
    else:
        result = tool_call("search", {"query": args.query, "mode": args.mode}, 20)
    print_json(result)


def read_markdown(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError as exc:
        raise RuntimeError(f"文件不是有效 UTF-8 Markdown: {path}") from exc


def markdown_files(root: Path, recursive: bool) -> list[Path]:
    pattern = "**/*" if recursive else "*"
    return sorted(
        p for p in root.glob(pattern)
        if p.is_file() and p.suffix.lower() in {".md", ".markdown"}
    )


def load_checkpoint(path: Path) -> set[str]:
    if not path.exists():
        return set()
    completed: set[str] = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            item = json.loads(line)
            if item.get("status") == "success" and item.get("source"):
                completed.add(item["source"])
        except json.JSONDecodeError:
            continue
    return completed


def append_checkpoint(path: Path, source: str, result: Any, status: str = "success", error: str | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    item: dict[str, Any] = {
        "time": datetime.now().isoformat(timespec="seconds"),
        "source": source,
        "status": status,
    }
    if status == "success":
        item["result"] = result
    if error:
        item["error"] = error
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(item, ensure_ascii=False) + "\n")


def create_one(path: Path, folder_id: str, title: str | None = None) -> Any:
    return tool_call(
        "create_note",
        {
            "operation_id": str(uuid.uuid4()),
            "title": title or path.stem,
            "content": read_markdown(path),
            "folder_id": folder_id,
        },
        30,
    )


def create(args: argparse.Namespace) -> None:
    source = Path(args.file).expanduser().resolve()
    folder_id = args.folder_id or DEFAULT_IMPORT_FOLDER_ID
    if not source.exists():
        raise RuntimeError(f"路径不存在: {source}")

    if source.is_file():
        files = [source]
    elif source.is_dir():
        files = markdown_files(source, args.recursive)
        if not files:
            print(f"没有找到 Markdown 文件: {source}")
            return
    else:
        raise RuntimeError(f"不是有效文件或文件夹: {source}")

    checkpoint = Path(args.checkpoint).expanduser().resolve() if args.checkpoint else (
        source / ".inkstone-import.jsonl" if source.is_dir() else source.with_name(".inkstone-import.jsonl")
    )
    completed = load_checkpoint(checkpoint) if not args.no_resume else set()
    pending = [p for p in files if str(p) not in completed]
    started = time.perf_counter()
    success = 0
    skipped = len(files) - len(pending)
    failed = 0

    print(f"导入范围: {source}")
    print(f"目标 folder_id: {folder_id}")
    print(f"总文件: {len(files)}，已完成: {skipped}，待处理: {len(pending)}")

    for index, path in enumerate(pending, 1):
        print(f"[{index}/{len(pending)}] 上传: {path}")
        try:
            result = create_one(path, folder_id, args.title if len(files) == 1 else None)
            append_checkpoint(checkpoint, str(path), result)
            success += 1
            print(f"  成功 | 已耗时 {time.perf_counter() - started:.1f}s")
        except Exception as exc:
            failed += 1
            append_checkpoint(checkpoint, str(path), None, "failed", str(exc))
            print(f"  失败: {exc}", file=sys.stderr)
            if args.stop_on_error:
                raise

    total_time = time.perf_counter() - started
    print(f"完成：成功 {success}，跳过 {skipped}，失败 {failed}，耗时 {total_time:.1f}s")
    print(f"断点文件: {checkpoint}")


def update(args: argparse.Namespace) -> None:
    note_id = args.note_id
    current = tool_call("fetch", {"id": note_id}, 40)
    current_data = current.get("data", current) if isinstance(current, dict) else {}
    current_rev = current_data.get("rev") or current_data.get("revision") or args.expected_rev
    if current_rev is None:
        raise RuntimeError("fetch 没有返回 rev，请使用 --expected-rev 指定当前版本号")
    new_content = read_markdown(Path(args.file).expanduser().resolve())
    arguments: dict[str, Any] = {
        "operation_id": str(uuid.uuid4()),
        "note_id": note_id,
        "expected_rev": int(current_rev),
        "operation": args.operation,
        "text": new_content,
    }
    if args.title:
        arguments["title"] = args.title
    started = time.perf_counter()
    result = tool_call("edit_note", arguments, 50)
    print_json(result)
    print(f"更新完成，耗时 {time.perf_counter() - started:.1f}s")


def safe_filename(title: str, note_id: str) -> str:
    cleaned = re.sub(r"[\\/:*?\"<>|\r\n]+", "_", title).strip(" .")
    return (cleaned or note_id) + ".md"


def folder_timestamp_name(folder: dict[str, Any]) -> str:
    stamp = datetime.now().strftime("%Y%m%d_%H%M")
    name = str(folder.get("name") or folder.get("path") or folder.get("id") or "folder")
    name = re.sub(r"[\\/:*?\"<>|\r\n]+", "_", name).strip(" .") or "folder"
    return f"{stamp}_{name}"


def get_folder_data(value: Any) -> list[dict[str, Any]]:
    data = value.get("data", value) if isinstance(value, dict) else {}
    folders_value = data.get("folders", []) if isinstance(data, dict) else []
    return folders_value if isinstance(folders_value, list) else []


def get_search_results(value: Any) -> list[dict[str, Any]]:
    data = value.get("data", value) if isinstance(value, dict) else {}
    results = data.get("results", []) if isinstance(data, dict) else []
    return results if isinstance(results, list) else []


def search_folder_notes(folder_path: str, limit: int = 20) -> list[dict[str, Any]]:
    """Search a folder with several common terms and merge duplicate note IDs."""
    merged: dict[str, dict[str, Any]] = {}
    started = time.perf_counter()
    print(f"正在按多个关键词扫描 folder: {folder_path}")

    for index, query in enumerate(FOLDER_SEARCH_QUERIES, 1):
        print(
            f"\r扫描关键词: {index}/{len(FOLDER_SEARCH_QUERIES)}，当前: {query}",
            end="",
            flush=True,
        )
        result = tool_call(
            "search_notes",
            {
                "query": query,
                "folder": folder_path,
                "limit": limit,
                "mode": "lexical",
            },
            200 + index,
        )
        for note in get_search_results(result):
            note_id = note.get("id")
            if note_id:
                merged[str(note_id)] = note

    print(f"\n扫描完成：发现 {len(merged)} 篇，耗时 {time.perf_counter() - started:.1f}s")
    return list(merged.values())


def download_one(note_id: str, output: Path) -> Any:
    result = tool_call("fetch", {"id": note_id}, 60)
    data = result.get("data", result) if isinstance(result, dict) else {}
    title = str(data.get("title") or note_id)
    text = data.get("text", data.get("content", ""))
    if not isinstance(text, str):
        text = json.dumps(text, ensure_ascii=False, indent=2)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(text, encoding="utf-8")
    return {"title": title, "output": str(output)}


def download(args: argparse.Namespace) -> None:
    started = time.perf_counter()

    if args.folder_id:
        folder_value = tool_call("list_folders", {}, 60)
        folders_value = get_folder_data(folder_value)
        folder = next((f for f in folders_value if f.get("id") == args.folder_id), None)
        if folder is None:
            raise RuntimeError(f"找不到 folder_id: {args.folder_id}")

        folder_path = folder.get("path") or folder.get("name")
        if not folder_path:
            raise RuntimeError(f"folder 缺少 path/name: {folder}")
        results = search_folder_notes(str(folder_path))
        if not results:
            print("该 folder 没有搜索到文档，无需下载")
            return

        output_root = Path(args.output).expanduser().resolve() / folder_timestamp_name(folder)
        checkpoint = output_root / ".inkstone-download.jsonl"
        completed = load_checkpoint(checkpoint) if not args.no_resume else set()
        pending = [item for item in results if str(item.get("id")) not in completed]
        print(f"下载 folder: {folder_path}")
        print(f"总文档: {len(results)}，已完成: {len(results) - len(pending)}，待处理: {len(pending)}")
        success = 0
        failed = 0
        for index, item in enumerate(pending, 1):
            note_id = str(item.get("id"))
            title = str(item.get("title") or note_id)
            output = output_root / safe_filename(title, note_id)
            print(f"[{index}/{len(pending)}] 下载: {title}")
            try:
                result = download_one(note_id, output)
                append_checkpoint(checkpoint, note_id, result)
                success += 1
            except Exception as exc:
                failed += 1
                append_checkpoint(checkpoint, note_id, None, "failed", str(exc))
                print(f"  失败: {exc}", file=sys.stderr)
                if args.stop_on_error:
                    raise
        print(f"完成：成功 {success}，失败 {failed}，耗时 {time.perf_counter() - started:.1f}s")
        print(f"保存目录: {output_root}")
        print(f"断点文件: {checkpoint}")
        return

    if not args.note_id:
        raise RuntimeError("download 需要 note_id，或者使用 --folder-id 下载整个 folder")
    output_dir = Path(args.output).expanduser().resolve()
    output = Path(args.file).expanduser().resolve() if args.file else output_dir / f"{args.note_id}.md"
    print_json(download_one(args.note_id, output))
    print(f"下载完成，耗时 {time.perf_counter() - started:.1f}s")


def create_folder(args: argparse.Namespace) -> None:
    arguments: dict[str, Any] = {
        "operation_id": str(uuid.uuid4()),
        "name": args.name,
    }
    if args.parent_id:
        arguments["parent_id"] = args.parent_id
    if args.folder_id:
        arguments["folder_id"] = args.folder_id
    if args.icon:
        arguments["icon"] = args.icon
    if args.color:
        arguments["color"] = args.color
    started = time.perf_counter()
    result = tool_call("create_folder", arguments, 70)
    print_json(result)
    print(f"创建完成，耗时 {time.perf_counter() - started:.1f}s")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="通过 Inkstone MCP API 管理 Markdown 笔记")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("folders", help="列出所有文件夹")
    p.set_defaults(func=folders)

    p = sub.add_parser("search", help="搜索笔记")
    p.add_argument("query")
    p.add_argument("--folder")
    p.add_argument("--tag", dest="tags", action="append")
    p.add_argument("--starred", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--archived", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--limit", type=int, default=10)
    p.add_argument("--mode", choices=("auto", "lexical", "semantic", "hybrid"), default="auto")
    p.set_defaults(func=search)

    p = sub.add_parser("create", help="上传单个或文件夹中的 Markdown")
    p.add_argument("file", help="Markdown 文件或文件夹")
    p.add_argument("--folder-id", default=DEFAULT_IMPORT_FOLDER_ID, help=f"目标 folder_id，默认 {DEFAULT_IMPORT_FOLDER_ID}")
    p.add_argument("--title")
    p.add_argument("--recursive", action="store_true", help="递归扫描子文件夹")
    p.add_argument("--checkpoint", help="自定义断点文件路径")
    p.add_argument("--no-resume", action="store_true", help="忽略已有成功记录，重新上传")
    p.add_argument("--stop-on-error", action="store_true", help="遇到错误立即停止")
    p.set_defaults(func=create)

    p = sub.add_parser("update", help="用本地 Markdown 更新指定笔记")
    p.add_argument("note_id")
    p.add_argument("file")
    p.add_argument("--operation", choices=("replace_all", "replace"), default="replace_all")
    p.add_argument("--title")
    ##p.add_argument("--expected-rev", type=int)
    p.add_argument("--expected-rev", type=int, default=1)
    p.set_defaults(func=update)

    p = sub.add_parser("download", help="下载指定笔记或整个 folder")
    p.add_argument("note_id", nargs="?", help="Inkstone note_id")
    p.add_argument("--folder-id", help="下载指定 folder 中的文档")
    p.add_argument("--output", default=str(DEFAULT_DOWNLOAD_ROOT), help=f"输出目录，默认 {DEFAULT_DOWNLOAD_ROOT}")
    p.add_argument("--file", help="下载单个笔记时指定完整文件路径")
    p.add_argument("--no-resume", action="store_true", help="忽略已有成功记录，重新下载")
    p.add_argument("--stop-on-error", action="store_true", help="遇到错误立即停止")
    p.set_defaults(func=download)

    p = sub.add_parser("create-folder", help="实时创建 Inkstone 文件夹")
    p.add_argument("name")
    p.add_argument("--parent-id")
    p.add_argument("--folder-id")
    p.add_argument("--icon")
    p.add_argument("--color")
    p.set_defaults(func=create_folder)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        args.func(args)
        return 0
    except KeyboardInterrupt:
        print("已取消", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
