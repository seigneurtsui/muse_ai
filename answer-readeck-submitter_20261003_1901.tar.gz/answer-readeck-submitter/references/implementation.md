# 实现来源与边界

## 复用原项目，不启动 GUI

来源是用户提供的 `/tmp/answer_readeck_submitter`，原包名为 `md-publisher`。原文件的 SHA-256 记录在 `source-hashes.json`，安装和适配不修改原目录。

- `lib/answer.js`：由 `server.js` 的 `apacheLogin`、`publishOneToAnswer` 适配。沿用 `/answer/api/v1/user/login/email`、`/answer/api/v1/question`、`e_mail/pass`、原始访问令牌授权头及 `{title, content, tags}` 格式。
- `lib/markdown.js`：从原 `buildReadeckHtml` 提取，保留块解析和样式，修复链接属性/协议注入、占位符碰撞、图片外部资源等边界。
- `lib/readeck.js`：保留 `POST /api/bookmarks` 的 `{url,title,labels}` 方式，增加随机临时路由、抓取信号验证与生命周期管理。具体依据见 `readeck.md`。
- `lib/transport.js`：沿用 Node 原生 HTTP/HTTPS，补充 TLS 验证、超时、响应大小限制及固定错误码；不跟随重定向。
- `lib/files.js`：沿用“前十行标题 / 文件名”规则，但不再丢弃标题之前的段落；增加预览、文件边界与内容指纹。
- `lib/environment.js`：根据用户授权，只读共享 `.env` 中所选平台的字段，进程环境优先；不执行 shell。
- `lib/state.js`、`lib/workflow.js`、`scripts/cli.js`：CLI 编排、明确执行、私有状态、写入意图、结果和重复运行保护。

原 GUI 依赖 Express 和 open。CLI 没有启动静态站点、`/api/config` 或目录扫描 HTTP 接口，因此不需要安装这两个包。此技能没有复制原 GUI 的硬编码凭据，也没有更换用户现有配置。

## 相比原 GUI 的有意差异

1. 原 GUI 点击即发；CLI 默认无网络预览，实际执行必须 `--execute --expect-plan`。
2. 原 Answer 自动截断；现在默认拒绝超长正文，只有明确授权才截断并标记。
3. 原 Readeck 页面固定保留一分钟、收到创建响应就报成功；现在等待回抓及文章就绪，超时保留远端 ID 而不再创建。
4. 原 HTTP 请求没有超时和响应上限；现在都有边界，未知写入不自动重试。
5. 原标题提取丢弃标题之前的文字；现在仅移除选作标题的那一行。
6. 原固定 LAN IP 不复制；回抓 URL 必须明确配置。不会自动放宽平台 SSRF 防护或网络策略。
7. 默认仍递归，但明确跳过隐藏项、node_modules 和符号链接，额外支持 `.markdown` 及大小写扩展名。
8. 重复标题不能证明内容一致，单独报告；相同内容成功凭据才能算复用。内容变化没有自动更新或新增副本的隐含操作。

## 凭据与状态

所有测试凭据都是合成值。生产凭据不进入源码、命令行参数、正文报告或 HTTP 回抓页面。
状态目录按目标及身份隔离，写入 JSON 使用私有临时文件、fsync 和原子替换。提交前写入 `in_flight`，收到 Readeck ID 后先记为待抓取，再开始轮询。没有“删掉断点并强制重新发”的便捷开关。

成功复用属于本机记录范围，不会证明文章仍在远端。切换 Token、状态目录、文件位置或命名空间时，应先核对已有数据；无法在没有平台幂等保证的情况下承诺全局去重。不要并行使用 GUI 和 CLI 发布同一批文档。

本 CLI 不调用模型、通知服务或远程脚本。原生 HTTP 传输不自动配置系统代理；如平台只能经特定代理到达，需要后续明确适配，而不是关闭 TLS 验证。

## 测试与运行边界

使用 Node 内置 `node:test`，无需下载测试依赖。测试包含：

- 真正 CLI 进程的帮助、无网络预览、私有配置加载与平台提交流程。
- Answer 回环模拟登录、元数据和正文、认证错误、明确拒绝、重复标题、未知回执与断连。
- Readeck 回环模拟创建、延迟回抓、HEAD/GET 差别、抓取失败、轮询状态、超时与清理。
- 文件筛选、编码、大小限制、超长授权截断、标题前文保留。
- 计划变化、来源变化、身份范围、别名去重、并发锁及损坏状态。
- 恶意 Markdown、回抓路径、返回 ID/Location、错误信息与凭据边界。

具体测试数量与最新执行结果见 `verification.md`。安装期间没有登录用户真实 Answer/Readeck，没有发布真实文档。模拟协议通过不等于已验证特定部署版本、权限、反向代理、限流、标签创建政策或回抓网络。Readeck 会自行进行可读性提取，不能承诺像原文件一样逐字、逐表保留全部排版。
