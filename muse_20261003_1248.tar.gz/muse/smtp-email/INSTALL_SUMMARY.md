# SMTP 邮件技能安装摘要

## 安装位置

`~/.config/omnirush/skills/smtp-email/`

Omnirush 默认技能路径通过以下链接指向该目录：

`~/.omnirush/agent/skills -> ~/.config/omnirush/skills`

## 配置

SMTP 凭据从以下私有文件读取：

`~/.config/omnirush/.env`

需要的变量：

- `SMTP_HOST`
- `SMTP_PORT`
- `SMTP_USER`
- `SMTP_PASS`
- `SMTP_FROM`

技能代码不会在文档或脚本中保存凭据；本地 `config.json` 已移除。

## 使用

```bash
cd ~/.config/omnirush/skills/smtp-email
node index.js config
node index.js verify
node index.js send --to recipient@example.com --subject "主题" --html "<p>内容</p>"
```

依赖已安装到技能目录的 `node_modules` 中。
