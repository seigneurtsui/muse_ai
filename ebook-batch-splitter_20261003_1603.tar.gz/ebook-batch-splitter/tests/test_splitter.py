"""Offline synthetic fixtures; no user ebooks or external service calls."""
from dataclasses import asdict
from html import escape
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from zipfile import ZipFile, ZIP_DEFLATED

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
from models import Boundary, Extracted, SplitError
import structured
import partition
import split_ebooks as app


def epub_fixture(path, titles, *, shared=True, ncx=False, preface="", broken_anchor=False, inline=False):
    container = '<container xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OPS/book.opf"/></rootfiles></container>'
    manifest, spine, entries, pages = [], [], [], {}
    if shared:
        body = "<p>" + escape(preface) + "</p>" if preface else ""
        for i, title in enumerate(titles):
            body += f'<h1 id="b{i}">{escape(title)}</h1><p>START_{i}_ONLY：正文出现第八册、第三十一卷，并非分书边界。END_{i}_ONLY</p>'
        if inline: body += '<p><span>你</span><em>好</em>，<strong>世界</strong>。</p>'
        pages["OPS/body.xhtml"] = '<html><head><title>HEAD_NOT_BODY</title><script>DO_NOT_EXECUTE</script></head><body>' + body + '</body></html>'
        manifest.append('<item id="body" href="body.xhtml" media-type="application/xhtml+xml"/>')
        spine.append('<itemref idref="body"/>')
        for i, title in enumerate(titles): entries.append((title, "body.xhtml#" + ("missing" if broken_anchor and i == 1 else f"b{i}")))
    else:
        for i, title in enumerate(titles):
            name = f"p{i}.xhtml"
            pages["OPS/"+name] = f'<html><body><h1>{escape(title)}</h1><p>START_{i}_ONLY：正文。END_{i}_ONLY</p></body></html>'
            manifest.append(f'<item id="p{i}" href="{name}" media-type="application/xhtml+xml"/>')
            spine.append(f'<itemref idref="p{i}"/>')
            entries.append((title, name))
    if ncx:
        toc = '<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/"><navMap>' + ''.join(f'<navPoint id="n{i}"><navLabel><text>{escape(t)}</text></navLabel><content src="{escape(h,quote=True)}"/></navPoint>' for i,(t,h) in enumerate(entries)) + '</navMap></ncx>'
        pages['OPS/toc.ncx'] = toc
        manifest.append('<item id="toc" href="toc.ncx" media-type="application/x-dtbncx+xml"/>')
    else:
        toc = '<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops"><body><nav epub:type="toc"><ol>' + ''.join(f'<li><a href="{escape(h,quote=True)}">{escape(t)}</a></li>' for t,h in entries) + '</ol></nav></body></html>'
        pages['OPS/nav.xhtml'] = toc
        manifest.append('<item id="toc" href="nav.xhtml" properties="nav" media-type="application/xhtml+xml"/>')
    package = ('<package xmlns="http://www.idpf.org/2007/opf" xmlns:dc="http://purl.org/dc/elements/1.1/" version="' + ('2.0' if ncx else '3.0') + '" unique-identifier="uid">'
               + '<metadata><dc:identifier id="uid">urn:uuid:synthetic-splitter-fixture</dc:identifier><dc:title>' + escape(path.stem) + '</dc:title><dc:language>zh</dc:language><dc:creator>Offline Fixture</dc:creator></metadata><manifest>'
               + ''.join(manifest) + '</manifest><spine' + (' toc="toc"' if ncx else '') + '>' + ''.join(spine) + '</spine></package>')
    with ZipFile(path,'w',ZIP_DEFLATED) as z:
        z.writestr('mimetype','application/epub+zip',compress_type=0)
        z.writestr('META-INF/container.xml',container)
        z.writestr('OPS/book.opf',package)
        for name,value in pages.items(): z.writestr(name,value)
    return path


class SplitterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.source = self.root / 'source'
        self.source.mkdir()
        self.output = self.root / 'output'
        self.output.mkdir()

    def options(self, **changes):
        defaults = vars(app.parser().parse_args([str(self.source)]))
        keys = ('force','refresh_cache','mode','toc_level','min_section_chars','split_chapters','pdf_via_epub','ocr','ocr_language','dpi','min_page_chars','timeout','encoding')
        result = {key: defaults[key] for key in keys}
        result.update(changes)
        return result

    def process(self, source, **options):
        return app.process_book(str(source), str(self.output), self.options(**options))

    def manifest(self, result):
        return json.loads(Path(result['manifest']).read_text())

    def assert_coverage(self, extracted, parts):
        self.assertEqual(''.join(extracted.text[p.start:p.end] for p in parts), extracted.text)

    def test_thirteen_heterogeneous_titles_and_shared_xhtml_anchors(self):
        titles = ['活着','《许三观卖血记》','兄弟','在细雨中呼喊','第七天','现实一种','呼喊与细雨','往事与刑罚','世事如烟','鲜血梅花','战栗','黄昏里的男孩','余华随笔']
        source = epub_fixture(self.source/'余华全集（全13册）.epub', titles, preface='短序言也必须保留。')
        original = source.read_bytes()
        extracted = structured.extract_epub(source)
        parts, decision = partition.decide(extracted, source.stem)
        self.assertEqual(decision['book_count'],13)
        self.assertEqual(decision['part_count'],14)
        self.assertEqual(parts[0].kind,'preface')
        self.assertEqual(extracted.metadata['documents_parsed'],1)
        for i, part in enumerate(parts[1:]):
            text = extracted.text[part.start:part.end]
            self.assertIn(f'START_{i}_ONLY',text)
            self.assertEqual(sum(f'START_{j}_ONLY' in text for j in range(13)),1)
        self.assert_coverage(extracted,parts)
        result = self.process(source)
        self.assertEqual(result['status'],'success',result)
        manifest = self.manifest(result)
        self.assertTrue(manifest['coverage_verified'])
        self.assertEqual(manifest['extracted_chars'], manifest['written_volume_chars'])
        self.assertEqual(source.read_bytes(),original)

    def test_eight_volumes_ignore_body_noise_with_ncx(self):
        source = epub_fixture(self.source/'苏东坡全集（全八册）.epub',[f'东坡文集 {i}' for i in range(8)],ncx=True)
        value = structured.extract_epub(source)
        parts, info = partition.decide(value,source.stem)
        self.assertEqual(info['book_count'],8)
        self.assertFalse(info['needs_review'])
        self.assert_coverage(value,parts)

    def test_spine_order_and_every_document_parsed_once(self):
        source = epub_fixture(self.source/'套装.epub',['甲书','乙书','丙书'],shared=False)
        extracted = structured.extract_epub(source)
        self.assertEqual(extracted.metadata['documents_parsed'],3)
        self.assertLess(extracted.text.index('START_0'),extracted.text.index('START_2'))
        parts, info = partition.decide(extracted,source.stem)
        self.assertEqual(info['book_count'],3)
        self.assert_coverage(extracted,parts)

    def test_inline_characters_not_broken_and_head_not_leaked(self):
        value = structured.extract_epub(epub_fixture(self.source/'book.epub',['篇章'],inline=True))
        self.assertIn('你好，世界。',value.text)
        self.assertNotIn('HEAD_NOT_BODY',value.text)
        self.assertNotIn('DO_NOT_EXECUTE',value.text)

    def test_missing_anchor_fails_closed_without_body_guessing(self):
        value = structured.extract_epub(epub_fixture(self.source/'全三册.epub',['甲','乙','丙'],broken_anchor=True))
        parts, info = partition.decide(value,'全三册')
        self.assertEqual(len(parts),1)
        self.assertTrue(info['needs_review'])
        self.assertEqual(info['decision'],'uncertain_structure_preserved_whole')
        self.assertIn('START_1_ONLY',value.text)

    def test_single_book_chapters_and_many_flat_entries(self):
        text = ''.join(f'{i}正文\n' for i in range(100))
        value = Extracted(text,[Boundary(i*3,f'第{i+1}章 章节') for i in range(10)],'epub_toc')
        parts, info = partition.decide(value,'普通书')
        self.assertEqual(len(parts),1)
        self.assertFalse(info['needs_review'])
        value.toc = [Boundary(i*3,f'任意短文{i}') for i in range(50)]
        parts, info = partition.decide(value,'普通书')
        self.assertEqual(len(parts),1)
        self.assertTrue(info['needs_review'])
        safe, _ = partition.decide(value,'短篇合集')
        self.assertEqual(len(safe),1,'a collection filename alone must not turn 50 essays into 50 books')
        forced, _ = partition.decide(value,'普通书',mode='collection')
        self.assertEqual(len(forced),50)

    def test_ambiguous_moderate_toc_and_explicit_override(self):
        value = Extracted('x'*100,[Boundary(i*10,f'标题{i}') for i in range(8)],'epub_toc')
        parts,info = partition.decide(value,'一般书籍')
        self.assertEqual(len(parts),1)
        self.assertTrue(info['needs_review'])
        parts,info = partition.decide(value,'一般书籍',mode='collection')
        self.assertEqual(info['book_count'],8)
        self.assert_coverage(value,parts)

    def test_structural_frontmatter_and_progressive_parts_stay_single(self):
        titles=['序言','目录','第一部','第二部','第三部','附录','后记']
        value=Extracted('x'*100,[Boundary(i*10,t,children=2 if '部' in t else 0) for i,t in enumerate(titles)],'epub_toc')
        parts,info=partition.decide(value,'普通小说')
        self.assertEqual(len(parts),1)
        self.assertEqual(info['decision'],'single_book_structural_sections')

    def test_chapter_resets_regroup_but_keep_all_text(self):
        titles=['前言','第一章','第二章','前言','第一章','第二章']
        value=Extracted('x'*60,[Boundary(i*10,t) for i,t in enumerate(titles)],'epub_toc')
        parts,info=partition.decide(value,'作品全集')
        self.assertEqual(info['book_count'],2)
        self.assertTrue(info['needs_review'])
        self.assert_coverage(value,parts)
        self.assertEqual(partition.chinese_number('一百零二'),102)
        self.assertEqual(partition.chinese_number('二千三百四十五'),2345)

    def test_same_position_bookmarks_do_not_duplicate_text(self):
        value=Extracted('whole body',[Boundary(0,'A'),Boundary(0,'B')],'pdf_toc')
        parts,info=partition.decide(value,'合集',mode='collection')
        self.assertEqual(len(parts),1)
        self.assertTrue(info['needs_review'])
        self.assert_coverage(value,parts)

    def test_first_branching_level_and_explicit_level(self):
        value=Extracted('x'*100,[Boundary(0,'全集',1,2),Boundary(0,'Book 1',2,1),Boundary(2,'第一章',3),Boundary(50,'Book 2',2,1),Boundary(52,'第一章',3)],'epub_toc')
        parts,info=partition.decide(value,'合集')
        self.assertEqual(info['book_count'],2)
        explicit,_=partition.decide(value,'合集',mode='collection',toc_level=3)
        self.assertEqual(len(explicit),3)  # short preface is retained
        with self.assertRaises(SplitError): partition.decide(value,'合集',toc_level=5)

    def test_strict_text_fallback_keeps_preface_and_rejects_short_final_quote(self):
        text='短前言\n\n《甲》\n\n'+'甲'*3001+'\n\n《乙》\n\n'+'乙'*3001+'\n\n《短引用》\n\n短尾声'
        value=Extracted(text,[],'text_pattern_fallback')
        parts,info=partition.decide(value,'TXT合集')
        self.assertEqual(info['book_count'],2)
        self.assertTrue(info['needs_review'])
        self.assert_coverage(value,parts)
        self.assertIn('短尾声',value.text[parts[-1].start:parts[-1].end])
        inline='正文中提到\n《甲》\n'+'甲'*4000
        self.assertEqual(partition.title_candidates(inline),[])

    def test_chapter_views_keep_repeated_numbers_and_parent_text(self):
        text='前言\n\n第一章 简介\n\n短预告\n\n第一章 正文\n\n长正文独特信息\n\n第十一章 结束\n\n尾声'
        path=self.source/'novel.txt';path.write_text(text)
        result=self.process(path,mode='single',split_chapters=True)
        self.assertEqual(result['status'],'success',result)
        manifest=self.manifest(result)
        volume=manifest['volumes'][0]
        self.assertEqual(len(volume['chapters']),4)
        root=Path(result['output_dir'])
        self.assertEqual(''.join((root/p['file']).read_text() for p in volume['chapters']),text)
        self.assertEqual((root/volume['file']).read_text(),text)
        self.assertEqual([p['chapter_number'] for p in volume['chapters']],[None,1,1,11])

    def test_docx_headings_tables_short_preface_and_body_titles(self):
        try:
            from docx import Document
        except ImportError: self.skipTest('python-docx only used to build a synthetic fixture')
        doc=Document();doc.add_paragraph('短前言')
        doc.add_heading('甲书',0)  # Title is not Heading 1
        doc.add_heading('第一册',1);doc.add_paragraph('甲书正文')
        table=doc.add_table(rows=1,cols=2);table.cell(0,0).text='TABLE_LEFT';table.cell(0,1).text='TABLE_RIGHT'
        doc.add_heading('第二册',1);doc.add_paragraph('乙书正文')
        path=self.source/'全两册.docx';doc.save(path)
        value=structured.extract_docx(path)
        parts,info=partition.decide(value,path.stem)
        self.assertEqual(info['book_count'],2)
        self.assertEqual(info['part_count'],3)
        self.assertIn('TABLE_LEFT',value.text)
        self.assertIn('TABLE_RIGHT',value.text)
        self.assert_coverage(value,parts)

    def test_structured_child_chapters_preserve_non_numeric_titles(self):
        text='Book heading\nChapter Alpha\nAlpha body\nChapter Beta\nBeta body'
        value=Extracted(text,[Boundary(0,'Book 1',1,2,{'href':'book'}),Boundary(13,'Alpha',2,0,{'href':'alpha'}),Boundary(38,'Beta',2,0,{'href':'beta'})],'epub_toc')
        part=partition.Part('Book 1',0,len(text),locator={'href':'book'})
        chapters=partition.chapter_parts(text,value,part)
        self.assertEqual([p.title for p in chapters],['前言_或_未分类内容','Alpha','Beta'])
        self.assertEqual(''.join(text[p.start:p.end] for p in chapters),text)

    def test_pdf_integration_page_order_bookmarks_and_sparse_pages(self):
        import pymupdf
        source=self.source/'PDF全两册.pdf'
        doc=pymupdf.open()
        for i in range(3):
            page=doc.new_page()
            page.insert_text((72,72),f'PAGE_{i}_CONTENT')
            page.insert_text((72,110),'中文正文测试',fontname='china-s')
        doc.set_toc([[1,'第一册',2],[2,'First chapter',2],[1,'第二册',3]])
        doc.save(source);doc.close()
        result=self.process(source)
        self.assertEqual(result['status'],'success',result)
        manifest=self.manifest(result)
        self.assertEqual(manifest['decision']['book_count'],2)
        self.assertEqual(manifest['decision']['part_count'],3)
        self.assertEqual(manifest['extraction']['native_extraction_calls'],3)
        joined=''.join((Path(result['output_dir'])/v['file']).read_text() for v in manifest['volumes'])
        for i in range(3):self.assertEqual(joined.count(f'PAGE_{i}_CONTENT'),1)
        self.assertIn('中文正文测试',joined)
        self.assertTrue(manifest['extraction']['toc_present'])
        self.assertFalse(manifest['extraction']['structure_uncertain'])

    def test_real_chinese_ocr_on_generated_image_only_pdf(self):
        import pymupdf
        from pdf_backend import extract_pdf
        executable=app.shutil.which('tesseract')
        if not executable:self.skipTest('Tesseract unavailable')
        languages=subprocess.run([executable,'--list-langs'],capture_output=True,text=True,timeout=15)
        if 'chi_sim' not in languages.stdout.split():self.skipTest('chi_sim language data unavailable')
        drawing=pymupdf.open();page=drawing.new_page(width=600,height=400)
        lines=['这是中文电子书拆分测试。','目录结构用于拆分书籍。','保留完整正文不会自动上传。','独立分册处理不会删除原书。','本地缓存让重复处理更加方便。']
        for index,line in enumerate(lines):page.insert_text((40,65+index*55),line,fontname='china-s',fontsize=24)
        png=page.get_pixmap(matrix=pymupdf.Matrix(2,2)).tobytes('png')
        drawing.close()
        source=self.source/'chinese-scan.pdf'
        doc=pymupdf.open();page=doc.new_page(width=600,height=400)
        page.insert_image(page.rect,stream=png);doc.save(source);doc.close()
        result=extract_pdf(source,cache_dir=self.root/'chinese-cache',ocr='auto',ocr_language='chi_sim+eng',dpi=150,timeout=30)
        self.assertFalse(result.metadata['incomplete'],result.warnings)
        self.assertEqual(result.metadata['native_text_pages'],0)
        self.assertEqual(result.metadata['ocr_success_pages'],1)
        normalized=''.join(result.text.split())
        self.assertIn('中文电子书',normalized)
        self.assertIn('目录结构',normalized)

    def test_real_calibre_mobi_and_azw3_structural_roundtrip(self):
        binary=app.calibre()
        if not binary:self.skipTest('Calibre unavailable')
        source=epub_fixture(self.source/'合成套装.epub',['Book 1','Book 2'],shared=False)
        environment={**os.environ,'CALIBRE_CONFIG_DIRECTORY':str(self.root/'calibre-config')}
        with patch.dict(os.environ,environment,clear=True):
            for extension in ('mobi','azw3'):
                target=self.source/f'合成套装.{extension}'
                converted=subprocess.run([binary,str(source),str(target)],capture_output=True,timeout=120,env=environment)
                self.assertEqual(converted.returncode,0,'synthetic Calibre conversion failed')
                self.assertTrue(target.is_file())
                result=self.process(target,mode='collection')
                self.assertIn(result['status'],('success','needs_review'),result)
                manifest=self.manifest(result)
                joined=''.join((Path(result['output_dir'])/v['file']).read_text() for v in manifest['volumes'])
                self.assertIn('START_0_ONLY',joined)
                self.assertIn('START_1_ONLY',joined)
                self.assertTrue(manifest['coverage_verified'])

    def test_internal_paths_entities_and_archive_safety(self):
        for href in ('../../private.env','/etc/passwd','https://evil.invalid/book','%2e%2e/%2e%2e/private','..%5csecret'):
            with self.assertRaises(SplitError): structured.reference('OPS/book.opf',href)
        path=self.source/'entity.epub'
        with ZipFile(path,'w') as z:z.writestr('x.xml','<!DOCTYPE x [<!ENTITY leak "private">]><x>&leak;</x>')
        with structured.Archive(path) as z:
            with self.assertRaises(SplitError):z.xml('x.xml')

    def test_resume_verifies_content_source_and_output_hashes(self):
        path=self.source/'book.txt';path.write_text('原始正文')
        first=self.process(path,mode='single')
        self.assertEqual(first['status'],'success')
        with patch.object(app,'extract',side_effect=AssertionError('should reuse')):
            self.assertEqual(self.process(path,mode='single')['status'],'skipped')
        manifest=self.manifest(first)
        target=Path(first['output_dir'])/manifest['volumes'][0]['file']
        target.write_text('人为修改')
        repaired=self.process(path,mode='single')
        self.assertEqual(repaired['status'],'success')
        self.assertNotEqual(repaired['output_dir'],first['output_dir'])
        self.assertEqual(target.read_text(),'人为修改','history must not be overwritten')
        path.write_text('更新后的正文')
        changed=self.process(path,mode='single')
        self.assertEqual(changed['status'],'success')
        self.assertNotEqual(self.manifest(changed)['source_sha256'],manifest['source_sha256'])

    def test_force_preserves_history_and_refresh_reextracts(self):
        path=self.source/'book.txt';path.write_text('正文')
        first=self.process(path,mode='single')
        with patch.object(app,'extract',wraps=app.extract) as extract:
            second=self.process(path,mode='single',force=True)
            extract.assert_not_called()
        self.assertTrue(Path(first['manifest']).is_file())
        self.assertNotEqual(first['output_dir'],second['output_dir'])
        with patch.object(app,'extract',wraps=app.extract) as extract:
            third=self.process(path,mode='single',refresh_cache=True)
            self.assertEqual(extract.call_count,1)
        self.assertEqual(third['status'],'success')

    def test_same_names_and_case_insensitive_scan_with_output_exclusion(self):
        for folder in ('one','two'):
            (self.source/folder).mkdir();(self.source/folder/'BOOK.TXT').write_text(folder)
        output=self.source/'generated';output.mkdir();(output/'old.txt').write_text('not input')
        (self.source/'linked.txt').symlink_to(self.source/'one/BOOK.TXT')
        files=app.discover(self.source,output,'*.txt')
        self.assertEqual(len(files),2)
        results=[self.process(p,mode='single') for p in files]
        self.assertEqual(len({r['output_dir'] for r in results}),2)

    def test_symlinked_state_ancestor_and_foreign_directory_refused(self):
        path=self.source/'book.txt';path.write_text('正文')
        first=self.process(path,mode='single')
        destination=Path(first['output_dir']).parent.parent
        current=destination/'current.json'; saved=current.read_bytes();current.unlink();current.symlink_to(self.root/'foreign.json')
        (self.root/'foreign.json').write_bytes(saved)
        self.assertEqual(self.process(path,mode='single')['status'],'failed')
        self.assertEqual((self.root/'foreign.json').read_bytes(),saved)
        current.unlink();current.write_bytes(saved)
        cache=destination/'.cache';backup=destination/'saved-cache';cache.rename(backup)
        outside=self.root/'outside';outside.mkdir();cache.symlink_to(outside,target_is_directory=True)
        self.assertEqual(self.process(path,mode='single',force=True)['status'],'failed')
        self.assertEqual(list(outside.iterdir()),[])

    def test_partial_write_does_not_publish_or_replace_old_outputs(self):
        path=self.source/'book.txt';path.write_text('正文')
        first=self.process(path,mode='single')
        destination=Path(first['output_dir']).parent.parent
        before=(destination/'current.json').read_bytes()
        with patch.object(app,'write_part',side_effect=OSError('fixture disk failure')):
            failed=self.process(path,mode='single',force=True)
        self.assertEqual(failed['status'],'failed')
        self.assertEqual((destination/'current.json').read_bytes(),before)
        self.assertFalse(list(destination.glob('.staging-*')))

    def test_encoding_and_empty_text(self):
        path=self.source/'book.txt'
        for encoding in ('utf-8-sig','utf-16','gb18030'):
            path.write_bytes('中文内容'.encode(encoding))
            self.assertEqual(app.decode_text(path,'auto').text,'中文内容')
        path.write_text(' \n')
        self.assertEqual(self.process(path)['status'],'failed')

    def test_cli_list_only_and_multi_process_batch(self):
        (self.source/'a.txt').write_text('甲正文');(self.source/'b.txt').write_text('乙正文')
        output=self.root/'not-created'
        cli=[sys.executable,str(SCRIPTS/'split_ebooks.py'),str(self.source),'-o',str(output)]
        listed=subprocess.run(cli+['--list-only'],capture_output=True,text=True)
        self.assertEqual(listed.returncode,0,listed.stderr)
        self.assertEqual(json.loads(listed.stdout)['count'],2)
        self.assertFalse(output.exists())
        ran=subprocess.run(cli+['--workers','2','--mode','single'],capture_output=True,text=True,timeout=60)
        self.assertEqual(ran.returncode,0,ran.stderr+ran.stdout)
        value=json.loads(ran.stdout)
        self.assertEqual(value['success'],2)
        self.assertTrue(Path(value['report_file']).is_file())

    def test_cli_empty_directory_invalid_args_and_partial_failure(self):
        cli=[sys.executable,str(SCRIPTS/'split_ebooks.py'),str(self.source),'-o',str(self.output)]
        empty=subprocess.run(cli,capture_output=True,text=True)
        self.assertEqual(empty.returncode,0)
        self.assertEqual(json.loads(empty.stdout)['total'],0)
        self.assertEqual(subprocess.run(cli+['--workers','0'],capture_output=True).returncode,2)
        (self.source/'a.txt').write_text('good');(self.source/'b.epub').write_text('not zip')
        result=subprocess.run(cli+['--mode','single'],capture_output=True,text=True)
        self.assertEqual(result.returncode,1)
        self.assertEqual(json.loads(result.stdout)['failed'],1)
        self.assertEqual(json.loads(result.stdout)['success'],1)

    def test_changing_source_during_extraction_never_publishes(self):
        path=self.source/'book.txt';path.write_text('old')
        original=app.extract
        def changed(*args):
            result=original(*args)
            path.write_text('changed during extraction')
            return result
        with patch.object(app,'extract',side_effect=changed):
            result=self.process(path,mode='single')
        self.assertEqual(result['status'],'failed')
        self.assertFalse(list(self.output.rglob('current.json')))


if __name__=='__main__': unittest.main()
