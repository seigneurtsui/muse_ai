"""Bounded standard-library file I/O, adapted from the installed erratum/s2t skills.
No configuration, credentials, network, or model calls.
"""

from __future__ import annotations
import codecs
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import stat
import tempfile
import unicodedata

MAX_FILE = 16 * 1024 * 1024
MAX_BATCH = 64 * 1024 * 1024
MAX_FILES = 500
MAX_OUTPUT = 64 * 1024 * 1024
SUPPORTED = {".txt", ".md", ".markdown", ".srt", ".vtt", ".csv", ".json"}
ENCODINGS = (
    "auto",
    "utf-8",
    "utf-8-sig",
    "utf-16",
    "utf-16-le",
    "utf-16-be",
    "gbk",
    "gb18030",
    "big5",
)


class TranslationError(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def reason(error):
    code = getattr(error, "code", "")
    if isinstance(code, str) and code.replace("_", "").isalnum() and len(code) < 100:
        return code
    return (
        "permission_denied"
        if isinstance(error, PermissionError)
        else "file_operation_failed"
    )


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def packed(value):
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def json_pairs(rows):
    data = {}
    for key, value in rows:
        if key in data:
            raise TranslationError("duplicate_json_key")
        data[key] = value
    return data


def loads(raw):
    try:
        return json.loads(
            raw,
            object_pairs_hook=json_pairs,
            parse_constant=lambda _: (_ for _ in ()).throw(ValueError()),
        )
    except (ValueError, UnicodeError, RecursionError):
        raise TranslationError("invalid_json") from None


def linklike(path):
    info = path.lstat()
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, "st_file_attributes", 0)
        & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    )


def key(path):
    return unicodedata.normalize("NFC", str(path)).casefold()


def root_path(path):
    path = Path(path).expanduser().absolute()
    if (path.exists() or path.is_symlink()) and (linklike(path) or not path.is_dir()):
        raise TranslationError("output_root_not_directory_or_link")
    return path.resolve(strict=False)


def relative_path(value):
    if (
        not isinstance(value, str)
        or not value
        or "\\" in value
        or ":" in value
        or any(ord(c) < 32 for c in value)
    ):
        raise TranslationError("invalid_relative_path")
    path = Path(value)
    if path.is_absolute() or any(
        p in ("", "..", ".") or p.rstrip(" .") != p for p in value.split("/")
    ):
        raise TranslationError("invalid_relative_path")
    return path


def mkdir(root, parent):
    if not parent.is_relative_to(root):
        raise TranslationError("path_outside_job")
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    if linklike(root) or not root.is_dir():
        raise TranslationError("job_root_is_link")
    current = root
    for part in parent.relative_to(root).parts:
        current = current / part
        current.mkdir(exist_ok=True, mode=0o700)
        if linklike(current) or not current.is_dir():
            raise TranslationError("output_parent_is_link")


def read_regular(path, limit=MAX_FILE, root=None):
    path = Path(path)
    info = path.lstat()
    if linklike(path) or (root is not None and not path.resolve().is_relative_to(root)):
        raise TranslationError("input_is_link_or_outside_root")
    if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
        raise TranslationError("file_not_regular_or_over_limit")
    fd = os.open(
        path,
        os.O_RDONLY
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_BINARY", 0)
        | getattr(os, "O_NONBLOCK", 0),
    )
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise TranslationError("file_not_regular_or_over_limit")
        with os.fdopen(fd, "rb", closefd=False) as stream:
            raw = stream.read(limit + 1)
        if len(raw) > limit:
            raise TranslationError("file_over_limit")
        return raw
    finally:
        os.close(fd)


def read_json(path, limit=MAX_FILE, root=None):
    return loads(read_regular(path, limit, root))


def sync_directory(path):
    # Windows does not expose portable directory fsync. Atomic replacement still
    # applies there; sudden power-loss durability is not claimed on that platform.
    if os.name == "nt":
        return
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def atomic_write(path, raw, replace=False):
    fd, name = tempfile.mkstemp(prefix=".translator-", suffix=".tmp", dir=path.parent)
    temp = Path(name)
    reserved = None
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        if not replace:
            reserve = os.open(
                path,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0),
                0o600,
            )
            try:
                reserved = os.fstat(reserve)
            finally:
                os.close(reserve)
            current = path.lstat()
            if (
                linklike(path)
                or current.st_size
                or (current.st_dev, current.st_ino)
                != (reserved.st_dev, reserved.st_ino)
            ):
                raise TranslationError("output_reservation_changed")
        elif path.exists() or path.is_symlink():
            if linklike(path) or not path.is_file() or path.stat().st_nlink > 1:
                raise TranslationError("state_target_is_link_or_not_regular")
        os.replace(temp, path)
        reserved = None
        sync_directory(path.parent)
    finally:
        temp.unlink(missing_ok=True)
        if reserved is not None:
            try:
                current = path.lstat()
                if (
                    (current.st_dev, current.st_ino)
                    == (reserved.st_dev, reserved.st_ino)
                    and not current.st_size
                    and not linklike(path)
                ):
                    path.unlink()
            except FileNotFoundError:
                pass


def write_json(path, value, replace=False):
    atomic_write(path, packed(value) + b"\n", replace)


@contextmanager
def job_lock(job):
    path = job / ".lock"
    try:
        path.mkdir(mode=0o700)
    except FileExistsError:
        raise TranslationError("job_locked_review_before_removing_lock") from None
    info = path.stat()
    owner = path / "owner.json"
    owner_info = None
    try:
        write_json(owner, {"pid": os.getpid()})
        owner_info = owner.lstat()
        yield
    finally:
        observed = path.lstat()
        if linklike(path) or (observed.st_dev, observed.st_ino) != (
            info.st_dev,
            info.st_ino,
        ):
            raise TranslationError("job_lock_changed")
        if owner.exists() or owner.is_symlink():
            observed = owner.lstat()
            if (
                owner_info is None
                or linklike(owner)
                or (observed.st_dev, observed.st_ino)
                != (owner_info.st_dev, owner_info.st_ino)
            ):
                raise TranslationError("job_lock_owner_changed")
            owner.unlink()
        path.rmdir()


@dataclass(frozen=True)
class Document:
    text: str
    encoding: str
    bom: bytes = b""


def snapshot_bom(value):
    allowed = {
        "": b"",
        "efbbbf": codecs.BOM_UTF8,
        "fffe": codecs.BOM_UTF16_LE,
        "feff": codecs.BOM_UTF16_BE,
    }
    if not isinstance(value, str) or value not in allowed:
        raise TranslationError("invalid_bom_snapshot")
    return allowed[value]


def decode(raw, encoding="auto"):
    if encoding not in ENCODINGS:
        raise TranslationError("unsupported_encoding")
    if raw.startswith((codecs.BOM_UTF32_LE, codecs.BOM_UTF32_BE)):
        raise TranslationError("utf32_not_supported")
    for bom, codec in (
        (codecs.BOM_UTF8, "utf-8"),
        (codecs.BOM_UTF16_LE, "utf-16-le"),
        (codecs.BOM_UTF16_BE, "utf-16-be"),
    ):
        if raw.startswith(bom):
            if encoding not in {
                "auto",
                codec,
                "utf-8-sig" if codec == "utf-8" else "utf-16",
            }:
                raise TranslationError("encoding_conflicts_with_bom")
            try:
                text = raw[len(bom) :].decode(codec)
            except UnicodeError:
                raise TranslationError("invalid_text_encoding") from None
            if "\0" in text:
                raise TranslationError("nul_in_text")
            return Document(text, codec, bom)
    for codec in (("utf-8", "gb18030") if encoding == "auto" else (encoding,)):
        try:
            text = raw.decode(codec)
        except UnicodeError:
            continue
        if "\0" in text:
            raise TranslationError("nul_in_text_use_explicit_encoding")
        return Document(text, "utf-8" if codec == "utf-8-sig" else codec)
    raise TranslationError("invalid_text_encoding")


def encode(text, document, encoding="utf-8"):
    if encoding not in ("same", "utf-8"):
        raise TranslationError("unsupported_output_encoding")
    codec = document.encoding if encoding == "same" else "utf-8"
    bom = (
        document.bom
        if encoding == "same"
        else (codecs.BOM_UTF8 if document.bom == codecs.BOM_UTF8 else b"")
    )
    try:
        return bom + text.encode(codec)
    except UnicodeError:
        raise TranslationError("output_encoding_cannot_represent_translation") from None


def collect(source, output, recursive=True, extensions=None):
    allowed = set(extensions or SUPPORTED)
    if not allowed <= SUPPORTED:
        raise TranslationError("unsupported_extension_filter")
    source = Path(source).expanduser().absolute()
    if not source.exists() or linklike(source):
        raise TranslationError("input_missing_or_link")
    if source.is_file():
        if source.suffix.lower() not in allowed:
            raise TranslationError("unsupported_extension")
        return [source.resolve()], source.parent.resolve(), []
    if not source.is_dir():
        raise TranslationError("input_not_file_or_directory")
    source = source.resolve()
    if source == output:
        raise TranslationError("output_equals_input_directory")
    files = []
    excluded = []
    visited = 0

    def walk(directory, depth):
        nonlocal visited
        if depth > 32:
            raise TranslationError("directory_depth_limit")
        if linklike(directory) or not directory.resolve().is_relative_to(source):
            raise TranslationError("input_tree_changed")
        for entry in sorted(directory.iterdir()):
            visited += 1
            if visited > 50000:
                raise TranslationError("directory_entry_limit")
            if linklike(entry):
                excluded.append(
                    {
                        "path": str(entry.relative_to(source)),
                        "reason": "link_not_followed",
                    }
                )
                continue
            if entry.resolve() == output:
                excluded.append(
                    {
                        "path": str(entry.relative_to(source)),
                        "reason": "output_excluded",
                    }
                )
                continue
            if entry.name.startswith(".") or entry.name in (
                "node_modules",
                "__pycache__",
            ):
                continue
            if entry.is_dir() and recursive:
                walk(entry, depth + 1)
            elif entry.is_file() and entry.suffix.lower() in allowed:
                files.append(entry)
                if len(files) > MAX_FILES:
                    raise TranslationError("file_count_limit")

    walk(source, 0)
    return sorted(files), source, excluded
