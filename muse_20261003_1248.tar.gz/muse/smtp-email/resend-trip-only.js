const nodemailer = require('nodemailer');
const fs = require('fs');
const config = JSON.parse(fs.readFileSync(__dirname + '/config.json', 'utf8'));

async function send(port, secure) {
  const t = nodemailer.createTransport({host:config.host,port,secure,auth:{user:config.user,pass:config.pass}});
  await t.sendMail({
    from: config.user,
    to: 'gc40800@gmail.com',
    subject: 'trip-planner-0to1 skill package',
    text: 'trip-planner-0to1 skill folder as attachment',
    attachments: [{
      filename: 'trip-planner-0to1.tar.gz',
      content: fs.readFileSync('/tmp/trip-planner-0to1.tar.gz'),
      contentType: 'application/gzip'
    }]
  });
  return port;
}

(async () => {
  for (const p of [465, 587]) {
    try {
      const r = await send(p, p === 465);
      console.log('✅ Sent on port ' + r);
      process.exit(0);
    } catch(e) {
      console.log('❌ Port ' + p + ': ' + e.message);
    }
  }
  console.log('❌ All attempts failed');
  process.exit(1);
})();
