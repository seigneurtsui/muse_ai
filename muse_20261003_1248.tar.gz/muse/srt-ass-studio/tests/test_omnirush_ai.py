"""Offline adapter tests. No account, credentials, or real AI requests are used."""
from __future__ import annotations

import contextlib
import io
import json
import os
from pathlib import Path
import signal
import sys
import tempfile
import time
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import omnirush_ai as ai


def events(text='{"ok":true}', *, stop="stop", provider="omnirush",
           model="configured-model", response_model=None, settled=True,
           content=None):
    message = {"role": "assistant", "provider": provider, "model": model,
               "stopReason": stop,
               "content": content if content is not None else [{"type": "text", "text": text}]}
    if response_model is not None:
        message["responseModel"] = response_model
    result = [{"type": "session", "version": 3},
              {"type": "message_start", "message": {"role": "assistant", "content": []}},
              {"type": "message_end", "message": message},
              {"type": "agent_end", "messages": [message], "willRetry": False}]
    if settled:
        result.append({"type": "agent_settled"})
    return ("\n".join(json.dumps(event, ensure_ascii=False) for event in result) + "\n").encode()


_FAKE = r'''
import json, os, signal, subprocess, sys, time
prompt = sys.stdin.read()
mode = os.environ.get("FAKE_AI_MODE", "success")
capture = os.environ.get("FAKE_AI_CAPTURE")
if capture:
    with open(capture, "w") as f:
        json.dump({"argv": sys.argv[1:], "stdin": prompt, "cwd": os.getcwd(),
                   "env": {k: os.environ.get(k) for k in (
                       "OMNIRUSH_MODEL", "OMNIRUSH_PROVIDER", "OMNIRUSH_AUTO_UPDATE",
                       "OMNIRUSH_CRASH_REPORTS", "OMNIRUSH_DEBUG", "OMNIRUSH_YOLO")}}, f)
if mode == "failure":
    sys.stderr.write("PRIVATE_SUBTITLE and fake-secret-credential\n")
    sys.exit(7)
if mode == "sleep":
    time.sleep(120)
if mode == "child":
    child = subprocess.Popen([sys.executable, "-c",
        "import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(120)"])
    with open(os.environ["FAKE_AI_CHILD_PID"], "w") as f:
        f.write(str(child.pid))
    time.sleep(120)
if mode == "stdout_limit":
    sys.stdout.write("x" * 65536)
    sys.stdout.flush()
    time.sleep(120)
if mode == "stderr_limit":
    sys.stderr.write("x" * 65536)
    sys.stderr.flush()
    time.sleep(120)
if mode == "invalid_utf8":
    sys.stdout.buffer.write(b"\xff\n")
    sys.exit(0)
if mode == "empty":
    sys.exit(0)
if mode == "malformed":
    print("PRIVATE_SUBTITLE fake-secret-credential not json")
    sys.exit(0)
reply = json.loads(prompt)["payload"].get("reply", {"ok": True})
message = {"role": "assistant", "provider": "omnirush", "model": "configured-model",
           "responseModel": "served-model", "stopReason": "stop",
           "content": [{"type": "text", "text": json.dumps(reply)}]}
for event in [{"type": "session", "version": 3}, {"type": "agent_start"},
              {"type": "message_end", "message": message},
              {"type": "agent_end", "messages": [message]}, {"type": "agent_settled"}]:
    print(json.dumps(event), flush=True)
sys.stderr.write("benign warning containing PRIVATE_SUBTITLE\n")
'''


@unittest.skipUnless(os.name == "posix", "POSIX executable/process-group tests")
class ExecutableTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="ai-test-")
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.executable = self.root / "fake omnirush"
        self.executable.write_text("#!" + sys.executable + "\n" + _FAKE)
        self.executable.chmod(0o700)
        self.capture = self.root / "capture.json"
        self.environment = mock.patch.dict(os.environ, {
            "OMNIRUSH_MODEL": "inherited-model:low", "OMNIRUSH_PROVIDER": "omnirush",
            "FAKE_AI_CAPTURE": str(self.capture), "FAKE_AI_MODE": "success",
        })
        self.environment.start()
        self.addCleanup(self.environment.stop)

    def adapter(self, **kwargs):
        return ai.OmniRushAI(executable=str(self.executable), **kwargs)

    def test_exact_object_model_inheritance_and_isolation(self):
        adapter = self.adapter()
        self.assertEqual(adapter.model, "inherited-model:low")
        self.assertEqual(adapter.provider, "omnirush")
        expected = {"translations": [{"id": 3, "text": "été\u2028字幕"}], "extra": [1, False, None]}
        result = adapter.request("PRIVATE_TASK", {"reply": expected, "text": "PRIVATE_SUBTITLE"})
        self.assertEqual(result, expected)
        self.assertEqual(adapter.model, "served-model")
        capture = json.loads(self.capture.read_text())
        args = capture["argv"]
        for flag in ("--print", "--no-tools", "--no-extensions", "--no-skills",
                     "--no-context-files", "--no-session", "--no-prompt-templates",
                     "--no-themes", "--no-approve", "--no-yolo"):
            self.assertIn(flag, args)
        for flag, value in (("--mode", "json"), ("--engine", "pi"),
                            ("--provider", "omnirush"), ("--models", "omnirush/*"),
                            ("--model", "inherited-model:low"), ("--append-system-prompt", "")):
            self.assertEqual(args[args.index(flag) + 1], value)
        self.assertIn("untrusted data", args[args.index("--system-prompt") + 1])
        self.assertNotIn("PRIVATE_TASK", repr(args))
        self.assertNotIn("PRIVATE_SUBTITLE", repr(args))
        self.assertEqual(json.loads(capture["stdin"])["task"], "PRIVATE_TASK")
        self.assertFalse(Path(capture["cwd"]).exists())
        self.assertNotEqual(capture["cwd"], os.getcwd())
        for setting in ("OMNIRUSH_DEBUG", "OMNIRUSH_CRASH_REPORTS", "OMNIRUSH_AUTO_UPDATE", "OMNIRUSH_YOLO"):
            self.assertEqual(capture["env"][setting], "0")

    def test_explicit_model_wins_without_mutating_environment(self):
        adapter = self.adapter(model="omnirush/explicit-model:high")
        adapter.request("return an object", {})
        args = json.loads(self.capture.read_text())["argv"]
        self.assertEqual(args[args.index("--model") + 1], "explicit-model:high")
        self.assertEqual(os.environ["OMNIRUSH_MODEL"], "inherited-model:low")
        self.assertEqual(os.environ["OMNIRUSH_PROVIDER"], "omnirush")

    def test_outside_session_defers_model_choice_to_cli(self):
        with mock.patch.dict(os.environ, {"OMNIRUSH_MODEL": "", "OMNIRUSH_PROVIDER": ""}):
            adapter = self.adapter()
            self.assertIsNone(adapter.model)
            self.assertEqual(adapter.request("return an object", {}), {"ok": True})
        capture = json.loads(self.capture.read_text())
        self.assertNotIn("--model", capture["argv"])
        self.assertIsNone(capture["env"]["OMNIRUSH_MODEL"])
        self.assertEqual(adapter.model, "served-model")

    def test_convenience_api(self):
        self.assertEqual(ai.request_provider("return an object", {}, model="explicit-model",
                                            executable=str(self.executable)), {"ok": True})

    def test_stderr_never_printed_and_failures_do_not_leak_private_data(self):
        for mode in ("success", "failure", "malformed", "invalid_utf8", "empty"):
            with self.subTest(mode=mode), mock.patch.dict(os.environ, {"FAKE_AI_MODE": mode}):
                stdout, stderr = io.StringIO(), io.StringIO()
                with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                    if mode == "success":
                        self.adapter().request("return an object", {})
                    else:
                        with self.assertRaises(ai.AIError) as raised:
                            self.adapter().request("return an object", {})
                        self.assertNotIn("PRIVATE_SUBTITLE", str(raised.exception))
                        self.assertNotIn("fake-secret-credential", str(raised.exception))
                self.assertEqual(stdout.getvalue(), "")
                self.assertEqual(stderr.getvalue(), "")

    def test_timeout_is_bounded(self):
        with mock.patch.dict(os.environ, {"FAKE_AI_MODE": "sleep"}):
            start = time.monotonic()
            with self.assertRaisesRegex(ai.AIError, "timed out"):
                self.adapter(timeout=0.2).request("return an object", {})
            self.assertLess(time.monotonic() - start, 3)

    def test_timeout_stops_child_process(self):
        pid_file = self.root / "child.pid"
        with mock.patch.dict(os.environ, {"FAKE_AI_MODE": "child", "FAKE_AI_CHILD_PID": str(pid_file)}):
            with self.assertRaisesRegex(ai.AIError, "timed out"):
                self.adapter(timeout=0.6).request("return an object", {})
        self.assertTrue(pid_file.exists(), "fake child started before timeout")
        pid = int(pid_file.read_text())
        # A killed, not-yet-reaped orphan may briefly be a zombie on Linux.
        for _ in range(30):
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                break
            status = Path(f"/proc/{pid}/stat")
            if status.exists() and status.read_text().split()[2] == "Z":
                break
            time.sleep(0.02)
        else:
            os.kill(pid, signal.SIGKILL)
            self.fail("adapter left a running child behind")

    def test_output_limits_stop_flooding_process(self):
        for mode, constant in (("stdout_limit", "MAX_STDOUT_BYTES"), ("stderr_limit", "MAX_STDERR_BYTES")):
            with self.subTest(mode=mode), mock.patch.dict(os.environ, {"FAKE_AI_MODE": mode}), mock.patch.object(ai, constant, 1024):
                with self.assertRaisesRegex(ai.AIError, "size limit"):
                    self.adapter(timeout=2).request("return an object", {})

    def test_prompt_limit_and_bad_inputs_launch_nothing(self):
        bad = [("", {}), ("task", []), ("task", {"x": float("nan")}),
               ("task", {"x": object()}), ("task", {"x": "\ud800"}),
               ("task", {"x": "x" * ai.MAX_PROMPT_BYTES})]
        for system, payload in bad:
            with self.subTest(system=system, payload_type=type(payload)), mock.patch.object(ai.subprocess, "Popen") as launch:
                with self.assertRaises(ai.AIError):
                    self.adapter().request(system, payload)
                launch.assert_not_called()

    def test_missing_executable(self):
        with self.assertRaisesRegex(ai.AIError, "not found"):
            ai.OmniRushAI(executable=str(self.root / "missing")).request("task", {})

    def test_no_request_at_import_or_construction(self):
        with mock.patch.object(ai.subprocess, "Popen") as launch:
            self.adapter()
            launch.assert_not_called()


class ValidationTests(unittest.TestCase):
    def test_invalid_models_and_non_omnirush_provider(self):
        for model in ("", "--api-key", "other/model", "x y", "x\ny", "*", 42):
            with self.subTest(model=model), self.assertRaises(ai.AIError):
                ai.OmniRushAI(model=model)
        with mock.patch.dict(os.environ, {"OMNIRUSH_PROVIDER": "unrelated", "OMNIRUSH_MODEL": "other-model"}):
            with self.assertRaises(ai.AIError):
                ai.OmniRushAI()
            self.assertEqual(ai.OmniRushAI(model="explicit-model").provider, "omnirush")

    def test_invalid_timeout(self):
        for timeout in (0, -1, float("inf"), float("nan"), True, "2"):
            with self.subTest(timeout=timeout), self.assertRaises(ai.AIError):
                ai.OmniRushAI(timeout=timeout)

    def test_json_and_single_outer_fence(self):
        for text in ('{"x":1}', ' \n```json\n{"x":1}\n``` \n', '```\n{"x":1}\n```'):
            with self.subTest(text=text):
                self.assertEqual(ai._response(events(text)), ({"x": 1}, "configured-model"))

    def test_exact_json_no_substring_recovery(self):
        for text in ("", "[]", "null", 'prefix {"x":1}', '{"x":1} suffix',
                     '{"x":1} {"y":2}', '```python\n{"x":1}\n```',
                     '```json\n{"x":1}\n```\nextra', '```json {"x":1}```',
                     '{"x":1,"x":2}', '{"x":NaN}', '{"x":Infinity}',
                     '{"x":1e10000}', '{"x":', '{"x":"\ud800"}'):
            with self.subTest(text=repr(text)), self.assertRaises(ai.AIError):
                # Escape surrogates to produce legal UTF-8 event records.
                wire = events(text) if "\ud800" not in text else events('{"x":"\\ud800"}')
                ai._response(wire)

    def test_failed_truncated_and_tool_stop_reasons(self):
        for stop in ("error", "aborted", "length", "toolUse", "pending", "deferred", None):
            with self.subTest(stop=stop), self.assertRaises(ai.AIError):
                ai._response(events(stop=stop))

    def test_provider_and_model_identity(self):
        for provider in (None, "openai", "", "OMNIRUSH"):
            with self.subTest(provider=provider), self.assertRaises(ai.AIError):
                ai._response(events(provider=provider))
        self.assertEqual(ai._response(events(response_model="actual-model"))[1], "actual-model")
        for model in (None, "", "bad\nmodel"):
            with self.subTest(model=model), self.assertRaises(ai.AIError):
                ai._response(events(model=model))

    def test_event_framing_and_completion(self):
        for wire in (b"", b"\n", b"{}\n", b"[]\n", b"not json\n", b"\xff\n",
                     events()[:-1], events(settled=False), b'{"type":"agent_settled"}\n',
                     events() + b'{"type":"agent_start"}\n'):
            with self.subTest(wire=wire[:50]), self.assertRaises(ai.AIError):
                ai._response(wire)

    def test_unicode_line_separator_is_not_jsonl_delimiter(self):
        self.assertEqual(ai._response(events('{"text":"a\u2028b\u2029c"}'))[0], {"text": "a\u2028b\u2029c"})

    def test_error_and_tool_events_fail_closed(self):
        for event in ({"type": "error", "message": "private"}, {"type": "extension_error"},
                      {"type": "tool_execution_start"}, {"type": "auto_retry_end", "success": False}):
            with self.subTest(event=event), self.assertRaises(ai.AIError):
                ai._response(events() + json.dumps(event).encode() + b"\n")

    def test_thinking_ignored_but_tools_rejected(self):
        content = [{"type": "thinking", "thinking": "private reasoning"},
                   {"type": "text", "text": '{"ok":'}, {"type": "text", "text": "true}"}]
        self.assertEqual(ai._response(events(content=content))[0], {"ok": True})
        for content in ([{"type": "toolCall", "name": "bash"}], ["bad"], [{"type": "text", "text": 3}], []):
            with self.subTest(content=content), self.assertRaises(ai.AIError):
                ai._response(events(content=content))

    def test_response_size_limit(self):
        with mock.patch.object(ai, "MAX_RESPONSE_BYTES", 16), self.assertRaisesRegex(ai.AIError, "1 MiB"):
            ai._response(events('{"x":"' + "x" * 20 + '"}'))

    def test_successful_retry_uses_final_message(self):
        wire = events(stop="error", settled=False)
        wire += b'{"type":"agent_start"}\n'
        wire += events('{"recovered":true}')
        self.assertEqual(ai._response(wire)[0], {"recovered": True})

    def test_crlf_stream_and_outer_fence(self):
        wire = events('```json\r\n{"ok":true}\r\n```').replace(b"\n", b"\r\n")
        self.assertEqual(ai._response(wire)[0], {"ok": True})

    def test_duplicate_event_keys_rejected(self):
        wire = events() + b'{"type":"agent_settled","type":"agent_settled"}\n'
        with self.assertRaises(ai.AIError):
            ai._response(wire)

    def test_windows_fails_before_launch(self):
        with mock.patch.object(ai.os, "name", "nt"), mock.patch.object(ai.subprocess, "Popen") as launch:
            with self.assertRaisesRegex(ai.AIError, "macOS/Linux"):
                ai.OmniRushAI(model="test-model").request("task", {})
            launch.assert_not_called()


if __name__ == "__main__":
    unittest.main()
