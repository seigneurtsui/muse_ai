import sys
import unittest
import argparse
from unittest.mock import patch
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_DIR / "scripts"))
import train_query  # noqa: E402


class TrainQueryTests(unittest.TestCase):
    @staticmethod
    def leg(train, origin, destination, departure, duration, *, origin_code=None, destination_code=None, prices=None):
        return {
            "train": train,
            "from": origin,
            "to": destination,
            "from_code": origin_code or origin,
            "to_code": destination_code or destination,
            "departure": departure,
            "arrival": departure,
            "duration": duration,
            "date": "2099-01-02",
            "prices": prices or [],
            "tags": [],
        }

    def test_duplicate_prices_are_removed(self):
        row = [""] * 57
        row[train_query.FIELD["price_info"]] = "O038400000O038400000"
        row[train_query.FIELD["ze"]] = "有"
        prices = train_query.parse_prices(row)
        self.assertEqual(len(prices), 1)
        self.assertEqual(prices[0]["seat"], "二等座")
        self.assertEqual(prices[0]["price"], 384.0)

    def test_status_preserves_waitlist_and_counts(self):
        self.assertEqual(train_query.status("候补"), "候补")
        self.assertEqual(train_query.status("12"), "余12张")
        self.assertEqual(train_query.status("0"), "无票")

    def test_transfer_fixture_combines_legs_and_wait(self):
        prices = [{"seat": "二等座", "price": 100, "availability": "余8张"}]
        first = self.leg("G101", "甲", "枢纽", "08:00", "02:00", origin_code="A", destination_code="H", prices=prices)
        second = self.leg("G202", "枢纽", "乙", "10:45", "02:00", origin_code="H", destination_code="B", prices=[{"seat": "二等座", "price": 120, "availability": "余5张"}])

        results = train_query.combine_transfer_results([first], [second], "H")

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["train"], "G101 + G202")
        self.assertEqual(results[0]["transfer_station"], "枢纽")
        self.assertEqual(results[0]["transfer_wait"], "00:45")
        self.assertEqual(results[0]["duration"], "04:45")
        self.assertEqual(results[0]["prices"], [{"seat": "二等座", "price": 220.0, "availability": "分段均有票"}])

    def test_real_wire_date_becomes_requested_boarding_date_without_early_limit(self):
        row = [''] * 57
        row[3], row[6], row[7], row[8], row[9], row[10], row[13] = 'G1', 'AAA', 'HHH', '22:00', '23:50', '01:50', '20990101'
        args = argparse.Namespace(kind='G', limit=1)
        with patch.object(train_query, 'json_request', return_value={'status': True, 'data': {'result': ['|'.join(row), '|'.join(row)], 'map': {}}}):
            legs = train_query._query_leg(None, '/test', {}, {'code': 'AAA'}, {'code': 'HHH'}, '2099-01-02', args)
        self.assertEqual(len(legs), 2)
        self.assertEqual(legs[0]['date'], '2099-01-02')
        self.assertEqual(legs[0]['service_date'], '20990101')
        second = self.leg('G2', '枢纽', '乙', '00:30', '02:00', origin_code='HHH', destination_code='BBB')
        second['date'] = '2099-01-03'
        joined = train_query.combine_transfer_results(legs, [second], 'CITY')
        self.assertEqual(len(joined), 1)
        self.assertEqual(joined[0]['transfer_wait_minutes'], 40)
        self.assertEqual(joined[0]['arrival_datetime'], '2099-01-03T02:30:00')

    def test_failure_payload_is_not_empty_inventory(self):
        with patch.object(train_query, 'json_request', return_value={'status': False}), self.assertRaises(SystemExit):
            train_query._query_leg(None, '/test', {}, {'code': 'A'}, {'code': 'B'}, '2099-01-02', argparse.Namespace(kind='', limit=10))

    def test_search_fetches_next_day_for_late_evening_connection(self):
        a, h, b = ({'code': code, 'name': code} for code in ('A', 'H', 'B'))
        first = self.leg('G1', 'A', 'H', '22:00', '01:50')
        second = self.leg('G2', 'H', 'B', '00:30', '02:00')
        second['date'] = '2099-01-03'
        queried = []
        def query(_op, _path, _stations, origin, dest, date, _args):
            queried.append((origin['code'], dest['code'], date))
            if dest['code'] == 'H': return [first]
            if origin['code'] == 'H' and date == '2099-01-03': return [second]
            return []
        args = argparse.Namespace(date='2099-01-02', kind='G', limit=1, refresh_cache=False,
                                  from_station='A', to_station='B', transfers=True, max_transfers=1,
                                  transfer_stations='H', transfer_limit=1, min_transfer_minutes=30,
                                  max_transfer_minutes=360, max_total_minutes=1440)
        with patch.object(train_query, 'load_stations', return_value=({'A': a, 'H': h, 'B': b}, {})), \
             patch.object(train_query, 'get_query_path', return_value='/test'), \
             patch.object(train_query, '_query_leg', side_effect=query), patch.object(train_query.time, 'sleep'):
            result = train_query.search(args)
        self.assertEqual(len(result), 1)
        self.assertIn(('H', 'B', '2099-01-03'), queried)

    def test_transfer_fixture_rejects_bad_wait_and_repeated_destination(self):
        first = self.leg("G101", "甲", "枢纽", "08:00", "02:00", origin_code="A", destination_code="H")
        too_soon = self.leg("G202", "枢纽", "乙", "10:10", "02:00", origin_code="H", destination_code="B")
        returns_to_origin = self.leg("G203", "枢纽", "甲", "10:45", "02:00", origin_code="H", destination_code="A")

        self.assertEqual(train_query.combine_transfer_results([first], [too_soon], "H"), [])
        self.assertEqual(train_query.combine_transfer_results([first], [returns_to_origin], "H"), [])


if __name__ == "__main__":
    unittest.main()
