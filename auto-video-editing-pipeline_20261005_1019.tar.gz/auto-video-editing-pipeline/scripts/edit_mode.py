#!/usr/bin/env python3
"""Deterministic five-axis highlight analysis and output-timeline planning."""
from __future__ import annotations

import json
import math
import re
from pathlib import Path

try:
    from .srt_utils import read_cues, write_cues
except ImportError:
    from srt_utils import read_cues, write_cues


AXES = ("hook_strength", "emotional_payoff", "quotability", "self_contained", "information_density")


def clamp(value: float) -> float:
    return round(max(0.0, min(100.0, value)), 1)


def score_cue(index: int, cue: tuple[float, float, list[str]], total_duration: float) -> dict:
    start, end, body = cue
    text = " ".join(body).strip()
    compact = re.sub(r"\s+", "", text)
    duration = max(0.1, end - start)
    position = 1.0 - min(1.0, start / max(30.0, total_duration))
    hook_signal = bool(re.search(r"[?？!！]|为什么|关键|注意|看这里|先说|结果|到底", text))
    payoff_signal = bool(re.search(r"但是|所以|因此|终于|原来|竟然|直接|成功|失败|解决|核心|最重要", text))
    quote_shape = 15 <= len(compact) <= 70
    context_shape = len(compact) >= 10 and bool(re.search(r"[，。！？,:：]|是|有|能|会|让|把", text))
    density = min(1.0, len(compact) / duration / 7.0)
    axes = {
        "hook_strength": clamp(45 + position * 25 + (25 if hook_signal else 0)),
        "emotional_payoff": clamp(35 + (45 if payoff_signal else 0) + (10 if "！" in text or "!" in text else 0)),
        "quotability": clamp(35 + (45 if quote_shape else 0) + (10 if hook_signal or payoff_signal else 0)),
        "self_contained": clamp(35 + (45 if context_shape else 0) + (10 if len(compact) >= 18 else 0)),
        "information_density": clamp(25 + density * 75),
    }
    return {
        "cue_index": index,
        "start": start,
        "end": end,
        "text": text,
        "axes": axes,
        "score": round(sum(axes.values()) / len(axes), 1),
        "total": round(sum(axes.values()), 1),
        "evidence": {"hook_terms_or_punctuation": hook_signal, "payoff_terms": payoff_signal, "chars_per_second": round(len(compact) / duration, 2)},
    }


def build_plan(source_srt: Path, duration: float, highlight_duration: float, body_speed: float, highlight_speed: float, trim_start: float = 0.0, trim_end: float | None = None) -> dict:
    cues = read_cues(source_srt)
    boundary = duration if trim_end is None else min(duration, trim_end)
    candidates = [score_cue(index, cue, duration) for index, cue in enumerate(cues) if cue[1] > trim_start and cue[0] < boundary]
    candidates.sort(key=lambda item: (-item["score"], item["start"], item["cue_index"]))
    if not candidates:
        return {"mode": "edit", "candidate_count": 0, "approved": False, "ranges": [{"kind": "body", "start": trim_start, "end": boundary, "speed": body_speed}], "candidates": []}

    selected = candidates[0]
    high_start = max(trim_start, selected["start"])
    high_end = min(boundary, selected["end"])
    selected_index = selected["cue_index"]
    while high_end - high_start < highlight_duration and selected_index + 1 < len(cues):
        next_start, next_end, _ = cues[selected_index + 1]
        if next_start >= boundary:
            break
        high_end = min(boundary, next_end)
        selected_index += 1
    ranges = []
    if high_end > high_start:
        ranges.append({"kind": "opening_highlight", "start": high_start, "end": high_end, "speed": highlight_speed, "reason": "top five-axis candidate moved to the opening"})
    if boundary > trim_start:
        ranges.append({"kind": "body", "start": trim_start, "end": boundary, "speed": body_speed, "reason": "keep the approved body complete after the opening highlight"})
    return {
        "mode": "edit",
        "candidate_count": len(candidates),
        "selection": "automatic_heuristic",
        "analysis_scope": "subtitle text only; audio/visual judgement is not measured",
        "selected_candidate": selected,
        "ranges": ranges,
        "candidates": candidates[:10],
    }


def write_plan_files(plan: dict, json_path: Path, review_path: Path) -> None:
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = ["# Edit Mode Review", "", "## Policy", "", "- 五轴为文本启发式候选评分，不代表听过音频/看过画面或用户批准。", "- 显式 --edit-mode 允许自动选择；--stop-for-review 可先停下修改计划。", "- 片头高光前置会让该片段在正文中再次出现。", "- 每个速度区间只在字幕短语边界切换。", "", "## Candidates", "", "| Rank | Range | 开冲 | 情峰 | 引用 | 自含 | 密度 | 总分/500 | Text |", "|---:|---|---:|---:|---:|---:|---:|---:|---|"]
    for rank, candidate in enumerate(plan.get("candidates", []), 1):
        text = candidate["text"].replace("|", "／").replace("\n", " ")
        scores = " | ".join(str(candidate["axes"][axis]) for axis in AXES)
        lines.append(f"| {rank} | {candidate['start']:.3f}-{candidate['end']:.3f}s | {scores} | {sum(candidate['axes'].values()):.1f} | {text} |")
    lines += ["", "## Planned ranges", "", "| Kind | Source range | Speed |", "|---|---|---:|"]
    for item in plan.get("ranges", []):
        lines.append(f"| {item['kind']} | {item['start']:.3f}-{item['end']:.3f}s | {item['speed']}x |")
    lines += ["", "请在正式发布前检查片头高光、速度变化和正文重复是否符合预期。"]
    review_path.parent.mkdir(parents=True, exist_ok=True)
    review_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def validate_plan(plan: dict, source_srt: Path, duration: float) -> None:
    ranges = plan.get("ranges")
    if not isinstance(ranges, list) or not ranges:
        raise ValueError("edit plan requires non-empty ranges")
    cues = read_cues(source_srt)
    for item in ranges:
        start, end, speed = (float(item[key]) for key in ("start", "end", "speed"))
        if not all(math.isfinite(value) for value in (start, end, speed)) or not 0 <= start < end <= duration + 0.001 or speed <= 0:
            raise ValueError("invalid edit range or speed")
        for boundary in (start, end):
            if any(a + 0.001 < boundary < b - 0.001 for a, b, _ in cues):
                raise ValueError(f"edit boundary {boundary}s cuts a subtitle phrase; use its start/end")
        if speed >= 10 and any(a < end and b > start for a, b, _ in cues):
            raise ValueError("timelapse range contains speech; keep speech at a readable speed")
        item.update(start=start, end=end, speed=speed)
        item.setdefault("kind", "body")


def retime_for_ranges(source_srt: Path, ranges: list[dict], segment_durations: list[float], destination: Path) -> dict:
    if len(ranges) != len(segment_durations) or any(not math.isfinite(value) or value <= 0 for value in segment_durations):
        raise ValueError("each range needs one positive, actual video duration")
    cues = read_cues(source_srt)
    output = []
    offset = 0.0
    for item, actual_duration in zip(ranges, segment_durations):
        start, end, speed = float(item["start"]), float(item["end"]), float(item["speed"])
        for cue_start, cue_end, body in cues:
            if cue_end <= start or cue_start >= end:
                continue
            clipped_start = max(cue_start, start)
            clipped_end = min(cue_end, end)
            out_start = offset + (clipped_start - start) / speed
            out_end = min(offset + actual_duration, offset + (clipped_end - start) / speed)
            if out_end > out_start:
                output.append((out_start, out_end, body))
        offset += actual_duration
    output.sort(key=lambda cue: (cue[0], cue[1]))
    destination.parent.mkdir(parents=True, exist_ok=True)
    write_cues(destination, output)
    return {"source_cues": len(cues), "output_cues": len(output), "output_duration": offset, "ranges": len(ranges)}
