# 短视频移植规则

本技能移植 `chatgpt-short-video-editor` 的可复用生产约束：

- 八步：素材检查、转写、内容整理、剪辑决策、逐段粗剪、字幕/视觉、预览、QA/定稿。
- faster-whisper-stt 是默认 STT；其字幕按 lower-confidence phrase-level 处理。
- 批量默认不强制新增审批；`--preview` 先生成完整 preview 再生成 final；
  `--stop-for-preview` 在完整 720p 预览 QA 后等待显式批准，再渲染 formal final。
  最多三次证据驱动修复由当前会话管理，不静默自动循环。
- 每个短语安全剪辑点默认向字幕间隙留白 120ms（可配置 0–200ms），每段音频约
  30ms 淡入淡出；实际区间、速度、引用/理由/STT 引擎/输出偏移写入 edl.json。
- 预览/正式/合并各自生成每个 EDL 边界 ±1.5s 视频片段与 WAV 试听材料；
  human_review=pending，不能把完整解码当作已人工检查音画同步或爆音。
- 仅在提供时间轴脚本时复用 edge-tts，逐句缓存并验证、输出时间轴放置、发声期间
  压低原声；说明 Microsoft Edge 接收脚本文字，不上传源视频，不自动开启 AI 功能。
- 字幕永远作为最后视觉操作；不默认添加 B-roll、音乐、CTA 或发布动作。
- 预览和正式文件都必须进行全片 decode；抽查开始、结束、中段和每个裁切边界。
- 原素材不移动、不改名、不覆盖；任务只在批次目录写派生文件。
- 需要词级精度时不能假称 faster-whisper 达到 Scribe 的词级质量；本 pipeline 不会
  自动上传或切换云端 STT。
