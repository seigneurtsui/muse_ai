'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const execute = promisify(execFile);
const { parse } = require('../scripts/cli');
const { run, credentials } = require('../lib/workflow');
const { buildPlan, extractTitleAndContent } = require('../lib/files');
const { prepareAnswer, createAnswerSession } = require('../lib/answer');
const { request, normalizeServiceUrl, PublishError } = require('../lib/transport');
const { openState } = require('../lib/state');
const { parseDotenv, resolveEnvironment } = require('../lib/environment');
const CLI = path.resolve(__dirname, '../scripts/cli.js');
const fakeEnv = { APACHE_ANSWER_EMAIL: 'fixture@example.invalid', APACHE_ANSWER_PASSWORD: 'synthetic-password-only', READECK_TOKEN: 'synthetic-readeck-only' };
function fixture(t) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'md-submit-test-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const input = path.join(dir, 'input'); fs.mkdirSync(input);
  return { dir, input, stateDir: path.join(dir, 'state') };
}
function config(f, extra = {}) {
  return { command: 'plan', directory: f.input, platform: 'answer', url: 'http://127.0.0.1:1', titleRule: 'heading', tags: ['autoNotes'], recursive: true,
    allowHttp: false, allowTruncate: false, stateDir: f.stateDir, continueOnError: false, execute: false,
    timeoutMs: 500, useEnvFile: false, captureTimeoutMs: 500, pollIntervalMs: 25, bind: '127.0.0.1', port: 8900, ...extra };
}
function write(f, name = 'doc.md', content = '# A useful title\n\n正文与代码。') {
  const file = path.join(f.input, name); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, content); return file;
}
function executing(c) { return { ...c, command: 'submit', execute: true, expectPlan: buildPlan(c).plan.planId }; }
async function server(t, handler) {
  const s = http.createServer(handler); await new Promise(resolve => s.listen(0, '127.0.0.1', resolve));
  t.after(async () => { s.closeAllConnections(); await new Promise(resolve => s.close(resolve)); });
  return 'http://127.0.0.1:' + s.address().port;
}
function json(res, status, data) { res.writeHead(status, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(data)); }
async function body(req) { let text = ''; for await (const part of req) text += part; return JSON.parse(text); }
async function answerMock(t, publishHandler) {
  const calls = [];
  const url = await server(t, async (req, res) => {
    const payload = await body(req); calls.push({ path: req.url, headers: req.headers, body: payload });
    if (req.url.endsWith('/login/email')) json(res, 200, { code: 200, data: { access_token: 'synthetic-access' } });
    else if (publishHandler) await publishHandler(req, res, payload, calls);
    else json(res, 200, { code: 200, data: { id: String(calls.length) } });
  });
  return { url, calls };
}

test('CLI help/version are headless and dependency-free', async () => {
  const help = await execute(process.execPath, [CLI, '--help']); assert.match(help.stdout, /--expect-plan/); assert.match(help.stdout, /只读/);
  const version = await execute(process.execPath, [CLI, '--version']); assert.match(version.stdout, /1\.0\.0/);
});
test('argument errors do not echo arbitrary values', async () => {
  await assert.rejects(execute(process.execPath, [CLI, '--unknown=synthetic-secret']), e => e.code === 2 && !e.stdout.includes('synthetic-secret'));
});
test('parse rejects unsafe URLs and conflicting flags', () => {
  const base = ['plan','/tmp','--platform','answer','--url','https://example.invalid','--no-env-file'];
  assert.throws(() => parse([...base,'--execute'], {}));
  assert.throws(() => parse([...base,'--title-rule','bad'], {}));
  assert.throws(() => parse([...base,'--port','0'], {}));
  for (const url of ['file:///tmp/x','https://u:p@example.invalid','https://example.invalid/?key=value','https://example.invalid/#secret','http://192.0.2.1']) assert.throws(() => normalizeServiceUrl(url));
  assert.equal(normalizeServiceUrl('http://192.0.2.1/', true), 'http://192.0.2.1');
  assert.equal(normalizeServiceUrl('https://example.invalid/base/'), 'https://example.invalid/base');
});
test('heading extraction preserves preamble, CRLF, and ignores code fences', () => {
  const d = extractTitleAndContent('\uFEFFIntro\r\n# 标题\r\n\r\nBody', 'doc.md', 'heading');
  assert.equal(d.title, '标题'); assert.equal(d.content, 'Intro\n\nBody');
  const code = extractTitleAndContent('```md\n# not a title\n```\n# Real title\nBody', 'doc.md', 'heading');
  assert.equal(code.title, 'Real title'); assert.match(code.content, /# not a title/);
  assert.equal(extractTitleAndContent('\n'.repeat(10) + '# Late', 'FILE.MARKDOWN', 'heading').title, 'FILE');
});
test('scan handles extension case, recursion, hidden paths and excludes symlinks', t => {
  const f = fixture(t); write(f, 'a.MD'); write(f, 'sub/b.markdown'); write(f, '.hidden.md'); write(f, 'node_modules/c.md'); write(f, 'ignore.txt');
  fs.symlinkSync(path.join(f.input, 'a.MD'), path.join(f.input, 'link.md'));
  let p = buildPlan(config(f)).plan; assert.equal(p.total, 2); assert.equal(p.excluded[0].reason, 'symlink_not_followed');
  p = buildPlan(config(f, { recursive: false })).plan; assert.equal(p.total, 1);
  assert.equal(buildPlan(config(f, { limit: 1 })).plan.total, 1);
});
test('symlink input directory is rejected', t => {
  const f = fixture(t); const link = path.join(f.dir, 'link'); fs.symlinkSync(f.input, link);
  assert.throws(() => buildPlan(config(f, { directory: link })), /non_symlink/);
});
test('empty, binary, invalid UTF8, and oversized files are visible invalid items', t => {
  const f = fixture(t); write(f, 'empty.md', '# Heading only'); write(f, 'binary.md', Buffer.from([0])); write(f, 'encoding.md', Buffer.from([0xff])); write(f, 'large.md', Buffer.alloc(2 * 1024 * 1024 + 1, 65));
  const p = buildPlan(config(f)).plan; assert.equal(p.invalid, 4); assert.deepEqual(new Set(p.documents.map(x => x.reason)), new Set(['empty_document_body','binary_markdown','invalid_utf8','file_over_2_mib']));
});
test('Answer limits never silently truncate; explicit truncation fits limit', () => {
  assert.throws(() => prepareAnswer('x', 'a'.repeat(65001)), /over_65000/);
  const d = prepareAnswer('x', 'a'.repeat(65001), true); assert.equal(d.content.length, 65000); assert.ok(d.truncated); assert.ok(d.title.length >= 6);
  assert.equal(prepareAnswer('a'.repeat(200), 'body').title.length, 150);
});
test('preview and empty execution never create sessions or state', async t => {
  const f = fixture(t); let calls = 0; const dependencies = { createSession: async () => { calls++; throw new Error(); } };
  const empty = await run(executing(config(f)), {}, dependencies); assert.equal(empty.output.reason, 'no_markdown_files');
  write(f); const preview = await run(config(f, { command: 'submit' }), {}, dependencies);
  assert.equal(preview.output.status, 'preview'); assert.equal(preview.output.networkPerformed, false); assert.equal(calls, 0); assert.equal(fs.existsSync(f.stateDir), false);
});
test('changed reviewed plan and invalid preflight cannot authenticate', async t => {
  const f = fixture(t); write(f); const c = executing(config(f)); write(f, 'doc.md', 'Changed content');
  await assert.rejects(run(c, {}, { createSession: () => { throw new Error('must not run'); } }), /plan_id/);
  write(f, 'empty.md', ''); const result = await run(executing(config(f)), {}); assert.equal(result.output.status, 'blocked'); assert.equal(fs.existsSync(f.stateDir), false);
});
test('real CLI preview does not require credentials or contact the selected server', async t => {
  const f = fixture(t); write(f); let hits = 0; const url = await server(t, (req, res) => { hits++; res.end(); });
  const result = await execute(process.execPath, [CLI, 'submit', f.input, '--platform','answer','--url',url,'--no-env-file']);
  assert.equal(JSON.parse(result.stdout).status, 'preview'); assert.equal(hits, 0);
});
test('Answer full loopback flow logs in once, preserves body and metadata, skips on resume', async t => {
  const f = fixture(t); write(f, 'first.md', 'Keep preamble\n# Valid title\n\nbody'); write(f, 'second.md', '# Second title\n\nOther body');
  const mock = await answerMock(t); const c = executing(config(f, { url: mock.url, tags: ['one','二'] }));
  const result = await run(c, fakeEnv); assert.equal(result.exitCode, 0); assert.equal(result.output.counts.submitted, 2);
  assert.equal(mock.calls.filter(x => x.path.endsWith('/login/email')).length, 1);
  assert.equal(mock.calls[0].body.pass, fakeEnv.APACHE_ANSWER_PASSWORD);
  assert.equal(mock.calls[1].headers.authorization, 'synthetic-access'); assert.equal(mock.calls[1].body.content, 'Keep preamble\n\nbody');
  assert.deepEqual(mock.calls[1].body.tags, [{ slug_name: 'one', display_name: 'one' }, { slug_name: '二', display_name: '二' }]);
  const resumed = await run(c, fakeEnv); assert.equal(resumed.output.counts.already_submitted, 2); assert.equal(mock.calls.length, 3);
  const text = fs.readFileSync(result.output.reportPath, 'utf8'); assert.ok(!text.includes(fakeEnv.APACHE_ANSWER_PASSWORD)); assert.ok(!text.includes('synthetic-access'));
  assert.equal(fs.statSync(result.output.reportPath).mode & 0o077, 0);
});
test('same-payload duplicates are reused and alias paths cannot later bypass change protection', async t => {
  const f = fixture(t); write(f, 'a.md'); write(f, 'b.md'); const mock = await answerMock(t);
  const c = config(f, { url: mock.url }); const first = await run(executing(c), fakeEnv);
  assert.equal(first.output.counts.submitted, 1); assert.equal(first.output.counts.already_submitted, 1);
  write(f, 'b.md', '# Changed title\nNew body'); const next = await run(executing(c), fakeEnv);
  assert.equal(next.output.counts.blocked, 1); assert.equal(mock.calls.length, 2);
});
test('changed prior file is blocked even after new plan review', async t => {
  const f = fixture(t); write(f); const mock = await answerMock(t); const c = config(f, { url: mock.url });
  await run(executing(c), fakeEnv); write(f, 'doc.md', '# Different title\nDifferent body');
  const result = await run(executing(c), fakeEnv); assert.equal(result.output.counts.blocked, 1); assert.equal(mock.calls.length, 2);
});
test('raw remote error messages and credentials are not exposed', async t => {
  const f = fixture(t); write(f); const mock = await answerMock(t, (req, res) => json(res, 400, { code: 400, msg: fakeEnv.APACHE_ANSWER_PASSWORD }));
  const result = await run(executing(config(f, { url: mock.url })), fakeEnv);
  assert.equal(result.output.counts.failed, 1); assert.ok(!JSON.stringify(result).includes(fakeEnv.APACHE_ANSWER_PASSWORD));
});
test('duplicate title is not counted as verified submission', async t => {
  const f = fixture(t); write(f); const mock = await answerMock(t, (req, res) => json(res, 400, { code: 400, msg: 'Duplicate title' }));
  const c = executing(config(f, { url: mock.url })); const result = await run(c, fakeEnv);
  assert.equal(result.output.counts.duplicate_title, 1); assert.equal(result.output.counts.complete, 0); assert.equal(result.exitCode, 1);
  await run(c, fakeEnv); assert.equal(mock.calls.length, 2);
});
test('missing acknowledgement blocks uncertain write retries', async t => {
  const f = fixture(t); write(f); const mock = await answerMock(t, (req, res) => json(res, 200, { code: 200, data: {} }));
  const c = executing(config(f, { url: mock.url })); const first = await run(c, fakeEnv); assert.equal(first.output.counts.uncertain, 1);
  const second = await run(c, fakeEnv); assert.equal(second.output.counts.uncertain, 1); assert.equal(mock.calls.length, 2);
});
test('network loss after create is uncertain and stops later documents', async t => {
  const f = fixture(t); write(f, 'a.md'); write(f, 'b.md', '# Another title\nOther body');
  const mock = await answerMock(t, (req, res) => req.socket.destroy());
  const c = executing(config(f, { url: mock.url, continueOnError: true }));
  const result = await run(c, fakeEnv); assert.equal(result.output.counts.uncertain, 1); assert.equal(result.output.counts.deferred, 1);
  await run(c, fakeEnv); assert.equal(mock.calls.length, 2);
});
test('auth failure stops batch even with continue-on-error', async t => {
  const f = fixture(t); write(f, 'a.md'); write(f, 'b.md', '# Another title\nOther body');
  const mock = await answerMock(t, (req, res) => json(res, 401, { msg: 'no' }));
  const result = await run(executing(config(f, { url: mock.url, continueOnError: true })), fakeEnv);
  assert.equal(result.output.counts.failed, 1); assert.equal(result.output.counts.deferred, 1); assert.equal(mock.calls.length, 2);
});
test('explicit rejection can continue without retrying the failing item', async t => {
  const f = fixture(t); write(f, 'a.md'); write(f, 'b.md', '# Another title\nOther body');
  const mock = await answerMock(t, (req, res, payload, calls) => calls.length === 2 ? json(res, 422, {}) : json(res, 200, { code: 200, data: { id: 'good' } }));
  const result = await run(executing(config(f, { url: mock.url, continueOnError: true })), fakeEnv);
  assert.equal(result.output.counts.failed, 1); assert.equal(result.output.counts.submitted, 1); assert.equal(mock.calls.length, 3);
});
test('pending Readeck acknowledgement is durable and never recreated', async t => {
  const f = fixture(t); write(f); let calls = 0, closes = 0;
  const c = executing(config(f, { platform: 'readeck', callbackUrl: 'http://127.0.0.1:8900' }));
  const dependencies = { createSession: async () => ({ publish: async (doc, { onAccepted }) => { calls++; await onAccepted({ remoteId: 'saved-id' }); throw new PublishError('capture_failed'); }, close: async () => { closes++; } }) };
  let result = await run(c, fakeEnv, dependencies); assert.equal(result.output.counts.pending_capture, 1); assert.equal(closes, 1);
  result = await run(c, fakeEnv, dependencies); assert.equal(result.output.counts.pending_capture, 1); assert.equal(calls, 1);
});
test('unexpected adapter exception after intent remains uncertain', async t => {
  const f = fixture(t); write(f);
  const result = await run(executing(config(f)), fakeEnv, { createSession: async () => ({ publish: async () => { throw new Error('opaque synthetic secret'); }, close: async () => {} }) });
  assert.equal(result.output.counts.uncertain, 1); assert.ok(!JSON.stringify(result).includes('opaque synthetic secret'));
});
test('private state validates permissions, locks and corrupted ledgers', t => {
  const f = fixture(t); const c = config(f); const one = openState(c, 'synthetic-account');
  assert.throws(() => openState(c, 'synthetic-account'), /locked/);
  const ledger = path.join(one.dir, 'ledger.json'); one.close(); fs.writeFileSync(ledger, '{bad', { mode: 0o600 });
  assert.throws(() => openState(c, 'synthetic-account'), /invalid_requires_review/);
  assert.equal(fs.existsSync(path.join(one.dir, 'batch.lock')), false);
});
test('state cannot be stored inside the document root', async t => {
  const f = fixture(t); write(f); await assert.rejects(run(executing(config(f, { stateDir: path.join(f.input, '.state') })), fakeEnv), /outside_input/);
});
test('transport bounds requests, rejects malformed protocols and does not follow redirects', async t => {
  let hits = 0; const url = await server(t, (req, res) => { hits++; res.writeHead(302, { Location: '/follow' }); res.end(); });
  const r = await request(url); assert.equal(r.status, 302); assert.equal(hits, 1);
  await assert.rejects(request('file:///tmp/test'), /invalid_url/);
  const slow = await server(t, () => {}); await assert.rejects(request(slow, { timeoutMs: 25 }), /timeout/);
  const big = await server(t, (req, res) => res.end('x'.repeat(10000))); await assert.rejects(request(big, { maxBytes: 100 }), /too_large/);
});
test('read-only selected dotenv parsing supports shared quoting without expansion', t => {
  const f = fixture(t); const file = path.join(f.dir, 'private.env');
  const source = 'export APACHE_ANSWER_URL="https://example.invalid" # comment\nAPACHE_ANSWER_EMAIL=fixture@example.invalid\nAPACHE_ANSWER_PASSWORD=\'literal$HOME$(never-run)\'\nREADECK_TOKEN="synthetic\\nnewline"\nUNRELATED="malformed\n';
  fs.writeFileSync(file, source, { mode: 0o600 });
  const selected = resolveEnvironment(['APACHE_ANSWER_PASSWORD','APACHE_ANSWER_EMAIL'], { APACHE_ANSWER_EMAIL: 'override@example.invalid' }, file);
  assert.equal(selected.APACHE_ANSWER_PASSWORD, 'literal$HOME$(never-run)'); assert.equal(selected.APACHE_ANSWER_EMAIL, 'override@example.invalid');
  assert.equal(fs.readFileSync(file, 'utf8'), source); assert.equal(Object.hasOwn(selected, 'READECK_TOKEN'), false);
  assert.throws(() => parseDotenv('A=one\nA=two', new Set(['A'])), /duplicate/);
  assert.throws(() => parseDotenv('A="bad', new Set(['A'])), /invalid_selected/);
  fs.chmodSync(file, 0o644); assert.throws(() => resolveEnvironment(['MISSING'], {}, file), /private/);
  assert.deepEqual(resolveEnvironment(['A'], { A: 'process' }, file), { A: 'process' });
});
test('reviewed plan binds state, transport and continuation settings', t => {
  const f = fixture(t); write(f); const c = config(f), id = buildPlan(c).plan.planId;
  for (const change of [{ stateDir: path.join(f.dir, 'other-state') }, { continueOnError: true }, { timeoutMs: 1000 }, { allowTruncate: true }]) assert.notEqual(buildPlan({ ...c, ...change }).plan.planId, id);
});
test('Readeck oversize content and HTML are rejected during offline planning', t => {
  const f = fixture(t); write(f, 'body.md', 'a'.repeat(1024 * 1024 + 1)); write(f, 'html.md', '&'.repeat(450000));
  const p = buildPlan(config(f, { platform: 'readeck' })).plan;
  assert.equal(p.invalid, 2); assert.deepEqual(new Set(p.documents.map(d => d.reason)), new Set(['readeck_content_over_1_mib','readeck_html_over_2_mib']));
});
test('callback prefix and wildcard origin are rejected in CLI preflight', () => {
  for (const callback of ['https://example.invalid/prefix', 'http://0.0.0.0:8900']) assert.throws(() => parse(['plan','/tmp','--platform','readeck','--url','https://example.invalid','--callback-url',callback,'--allow-http','--no-env-file'], {}), /callback/);
});
test('Answer application-level server error is uncertain despite HTTP 200', async t => {
  const f = fixture(t); write(f); const mock = await answerMock(t, (req, res) => json(res, 200, { code: 500, msg: 'ambiguous' }));
  const result = await run(executing(config(f, { url: mock.url })), fakeEnv); assert.equal(result.output.counts.uncertain, 1);
});
test('real Answer CLI reads a private env file without changing it and reuses receipt', async t => {
  const f = fixture(t); write(f); const mock = await answerMock(t); const file = path.join(f.dir, 'private.env');
  const text = `APACHE_ANSWER_URL=${mock.url}\nAPACHE_ANSWER_EMAIL=fixture@example.invalid\nAPACHE_ANSWER_PASSWORD=synthetic-cli-password\n`;
  fs.writeFileSync(file, text, { mode: 0o600 });
  const args = [f.input,'--platform','answer','--env-file',file,'--state-dir',f.stateDir];
  const env = { PATH: process.env.PATH, HOME: f.dir };
  const preview = JSON.parse((await execute(process.execPath, [CLI,'plan',...args], { env })).stdout);
  assert.equal(mock.calls.length, 0);
  const submitArgs = [CLI,'submit',...args,'--execute','--expect-plan',preview.planId];
  const result = JSON.parse((await execute(process.execPath, submitArgs, { env })).stdout);
  assert.equal(result.counts.submitted, 1); assert.equal(fs.readFileSync(file, 'utf8'), text);
  assert.ok(!JSON.stringify(result).includes('synthetic-cli-password'));
  const again = JSON.parse((await execute(process.execPath, submitArgs, { env })).stdout);
  assert.equal(again.counts.already_submitted, 1); assert.equal(mock.calls.length, 2);
});
test('real Readeck CLI composes env, renderer, listener, acceptance, polling and deduplication', async t => {
  const f = fixture(t); write(f, 'doc.md', '# A complete article\n\n' + 'Substantial original paragraph with useful document content. '.repeat(20));
  const reservation = http.createServer(); await new Promise(resolve => reservation.listen(0, '127.0.0.1', resolve));
  const port = reservation.address().port; await new Promise(resolve => reservation.close(resolve));
  let posts = 0, captured = false, capturedHtml = '';
  const url = await server(t, async (req, res) => {
    assert.equal(req.headers.authorization, 'Bearer synthetic-cli-readeck');
    if (req.method === 'POST') {
      posts++; const payload = await body(req);
      const page = await request(payload.url); capturedHtml = page.data; captured = page.status === 200;
      res.writeHead(202, { 'Bookmark-Id': 'bookmark-fixture', Location: '/api/bookmarks/bookmark-fixture' }); res.end();
    } else json(res, 200, { id: 'bookmark-fixture', state: captured ? 0 : 2, loaded: captured, has_article: captured });
  });
  const file = path.join(f.dir, 'private.env');
  fs.writeFileSync(file, `READECK_URL=${url}\nREADECK_TOKEN=synthetic-cli-readeck\n`, { mode: 0o600 });
  const args = [f.input,'--platform','readeck','--env-file',file,'--state-dir',f.stateDir,'--callback-url',`http://127.0.0.1:${port}`,'--port',String(port),'--capture-timeout-ms','2000','--poll-ms','20'];
  const env = { PATH: process.env.PATH, HOME: f.dir };
  const preview = JSON.parse((await execute(process.execPath, [CLI,'plan',...args], { env })).stdout); assert.equal(posts, 0);
  const submitArgs = [CLI,'submit',...args,'--execute','--expect-plan',preview.planId];
  const result = JSON.parse((await execute(process.execPath, submitArgs, { env })).stdout);
  assert.equal(result.counts.submitted, 1); assert.equal(result.results[0].callbackReceived, true); assert.match(capturedHtml, /<article>/);
  await assert.rejects(request(`http://127.0.0.1:${port}/`, { timeoutMs: 100 }), /network/);
  const again = JSON.parse((await execute(process.execPath, submitArgs, { env })).stdout);
  assert.equal(again.counts.already_submitted, 1); assert.equal(posts, 1);
});
test('CLI config reads only public platform fields; credentials resolved only for execution', t => {
  const f = fixture(t); const file = path.join(f.dir, 'private.env');
  fs.writeFileSync(file, 'APACHE_ANSWER_URL=https://example.invalid\nAPACHE_ANSWER_TAG=one,two\nAPACHE_ANSWER_PASSWORD="malformed', { mode: 0o600 });
  const c = parse(['plan',f.input,'--platform','answer','--env-file',file], {});
  assert.equal(c.url, 'https://example.invalid'); assert.deepEqual(c.tags, ['one','two']); assert.equal(Object.hasOwn(c, 'password'), false);
  assert.throws(() => credentials(c, {}), /invalid_selected/);
});
