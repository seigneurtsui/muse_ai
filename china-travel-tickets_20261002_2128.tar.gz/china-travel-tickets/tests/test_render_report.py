import json
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_DIR / "scripts"))
import render_report  # noqa: E402


class FlightReportTests(unittest.TestCase):
    def write_result(self, payload):
        directory = Path(tempfile.mkdtemp())
        source = directory / "result.json"
        source.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        return directory, source

    def test_direct_flight_without_price_renders(self):
        directory, source = self.write_result({
            "source": "test",
            "timestamp": "2026-10-02T00:00:00.000Z",
            "results": [{
                "journeys": [{
                    "segments": [{
                        "depCityName": "北京",
                        "arrCityName": "厦门",
                        "depDateTime": "2026-10-10 08:00:00",
                        "arrDateTime": "2026-10-10 11:00:00",
                        "depStationName": "首都机场",
                        "arrStationName": "高崎机场",
                        "marketingTransportNo": "T1",
                        "marketingAirlineName": "测试航空",
                        "baggage": "托运行李 1 件",
                        "refundChange": "起飞前可退改",
                        "taxes": "含税 80 元",
                    }],
                    "totalDuration": "180",
                }],
            }],
        })
        md_path, html_path = render_report.render(source, directory / "out", "direct-no-price")
        markdown = md_path.read_text(encoding="utf-8")
        html = html_path.read_text(encoding="utf-8")
        self.assertIn("直飞 1 条 / 中转 0 条", markdown)
        self.assertIn("未提供", markdown)
        self.assertIn("测试航空", markdown)
        self.assertIn("托运行李 1 件", markdown)
        self.assertIn("起飞前可退改", markdown)
        self.assertIn("含税 80 元", markdown)
        self.assertIn("直飞", html)

    def test_rule_components_and_protection_remain_scoped(self):
        segment = {'marketingTransportNo': 'MU1234', 'marketingTransportName': '东航',
                   'depDateTime': '2099-01-02 08:00:00', 'arrDateTime': '2099-01-02 10:00:00',
                   'airportTax': 50, 'fuelSurcharge': 80, 'refundRule': '不可退', 'changeRule': '可改',
                   'arrStationCode': 'SHA', 'arrTerm': 'T2'}
        second = {'marketingTransportNo': 'CA1234', 'depDateTime': '2099-01-02 13:00:00',
                  'arrDateTime': '2099-01-02 15:00:00', 'depStationCode': 'PVG', 'depTerm': 'T1'}
        directory, source = self.write_result({'timestamp': '2099-01-01T00:00:00Z', 'results': [{
            'ticketPrice': '199.50', 'isProtected': False, 'journeys': [{'segments': [segment, second]}]}]})
        md, html = render_report.render(source, directory, 'rules')
        for path in (md, html):
            content = path.read_text()
            for text in ['东航', 'airportTax: 50', 'fuelSurcharge: 80', '不可退', '可改', 'isProtected: False', '需更换机场', '2099-01-01 08:00:00']:
                self.assertIn(text, content)

    def test_nonfinite_price_is_not_recommended_as_cheap(self):
        row = render_report._flight_record({'ticketPrice': 'NaN', 'journeys': [{'segments': [{}]}]})
        self.assertIsNone(row['price'])
        self.assertIsNone(row['price_text'])

    def test_empty_train_transfer_report_is_still_generated(self):
        directory, source = self.write_result({
            "source": "12306",
            "queried_at": "2099-01-02T08:00:00+08:00",
            "mode": "transfers",
            "direct_results": [{"from": "甲", "to": "乙", "date": "2099-01-02"}],
            "results": [],
        })
        md_path, html_path = render_report.render(source, directory / "out", "empty-transfer")
        self.assertIn("没有找到满足", md_path.read_text(encoding="utf-8"))
        self.assertIn("没有找到满足", html_path.read_text(encoding="utf-8"))

    def test_train_transfer_report_shows_wait_and_segment_fare(self):
        directory, source = self.write_result({
            "source": "12306",
            "queried_at": "2099-01-02T08:00:00+08:00",
            "mode": "transfers",
            "direct_results": [],
            "transfer_constraints": {"min_wait_minutes": 30, "max_wait_minutes": 360, "max_total_minutes": 1440},
            "results": [{
                "train": "G101 + G202",
                "from": "甲",
                "to": "乙",
                "departure": "08:00",
                "arrival": "12:45",
                "duration": "04:45",
                "total_duration": 285,
                "transfer_station": "枢纽",
                "transfer_wait": "00:45",
                "transfer_wait_minutes": 45,
                "prices": [{"seat": "二等座", "price": 220.0, "availability": "余5张"}],
                "legs": [],
            }],
        })
        md_path, html_path = render_report.render(source, directory / "out", "train-transfer")
        markdown = md_path.read_text(encoding="utf-8")
        html = html_path.read_text(encoding="utf-8")
        self.assertIn("高铁中转换乘报告", markdown)
        self.assertIn("枢纽", markdown)
        self.assertIn("00:45", markdown)
        self.assertIn("分段合计", markdown)
        self.assertIn("TRANSFER QUERY REPORT", html)

    def test_transfer_report_counts_routes_and_preserves_decimal_price(self):
        directory, source = self.write_result({
            "source": "test",
            "timestamp": "2026-10-02T00:00:00.000Z",
            "results": [{
                "ticketPrice": "219.50",
                "journeys": [{
                    "segments": [
                        {"depCityName": "南阳", "arrCityName": "西安", "depDateTime": "2026-10-10 16:35:00", "arrDateTime": "2026-10-10 17:40:00", "depStationName": "姜营", "arrStationName": "咸阳", "marketingTransportNo": "9H8414"},
                        {"depCityName": "西安", "arrCityName": "厦门", "depDateTime": "2026-10-10 20:45:00", "arrDateTime": "2026-10-10 23:30:00", "depStationName": "咸阳", "arrStationName": "高崎", "marketingTransportNo": "MF8238"},
                    ],
                    "totalDuration": "415",
                    "transferDuration": "185",
                    "taxFee": "税费 120 元",
                }],
            }],
        })
        md_path, _ = render_report.render(source, directory / "out", "transfer")
        markdown = md_path.read_text(encoding="utf-8")
        self.assertIn("直飞 0 条 / 中转 1 条", markdown)
        self.assertIn("¥219.50", markdown)
        self.assertIn("9H8414, MF8238", markdown)
        self.assertIn("税费 120 元", markdown)


if __name__ == "__main__":
    unittest.main()
