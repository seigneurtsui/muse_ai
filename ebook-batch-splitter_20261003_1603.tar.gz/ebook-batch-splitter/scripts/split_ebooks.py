#!/usr/bin/env python3
"""Local, structure-first batch ebook -> TXT splitter. Never installs or uploads."""
import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
from contextlib import contextmanager
from dataclasses import asdict
from datetime import datetime, timezone
import fcntl
import fnmatch
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
import unicodedata
import uuid

from models import Boundary, Extracted, SplitError
from partition import chapter_number, chapter_parts, decide
from structured import extract_docx, extract_epub

VERSION = 1
FORMATS = {".epub", ".pdf", ".mobi", ".azw3", ".docx", ".txt"}
DEFAULT_OUTPUT = Path.home() / "Downloads/ebook_splitter"
CALIBRE_APP = Path("/Applications/calibre.app/Contents/MacOS/ebook-convert")


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def sha_file(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""): h.update(chunk)
    return h.hexdigest()


def snapshot(path):
    stat = path.stat()
    return stat.st_size, stat.st_mtime_ns, stat.st_ino, stat.st_dev


def no_symlinks(path):
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise SplitError("拒绝软链接输出/缓存路径")


def private_dir(path):
    no_symlinks(path)
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    if not path.is_dir(): raise SplitError("输出路径不是目录")


def read_json(path):
    no_symlinks(path)
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        raise SplitError("状态文件无法读取或损坏；未覆盖旧结果") from None


def atomic_json(path, value):
    no_symlinks(path)
    fd, name = tempfile.mkstemp(prefix=".write-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
        sync_dir(path.parent)
    finally:
        Path(name).unlink(missing_ok=True)


def sync_dir(path):
    fd = os.open(path, os.O_RDONLY)
    try: os.fsync(fd)
    finally: os.close(fd)


@contextmanager
def lock(path):
    fd = os.open(path, os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
    try:
        try: fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError: raise SplitError("同一输出已有任务运行，请等待而非并行重复启动") from None
        yield
    finally: os.close(fd)


def safe_name(value, maximum=140):
    text = unicodedata.normalize("NFC", value)
    text = re.sub(r'[<>:"/\\|?*\x00-\x1f\x7f]', "_", text).strip(" .")
    return text.encode("utf-8")[:maximum].decode("utf-8", errors="ignore").rstrip(" .") or "未命名"


def discover(source, output, include=None, exclude=(), limit=0):
    source = Path(source).expanduser()
    if source.is_symlink(): raise SplitError("输入不能是软链接；请指定实际文件/目录")
    source, output = source.resolve(), Path(output).expanduser().resolve()
    if not source.exists(): raise SplitError("输入路径不存在")
    if source == output or source.is_relative_to(output): raise SplitError("输入不能位于拆分输出目录中")
    candidates = []
    if source.is_file():
        if source.suffix.lower() not in FORMATS: raise SplitError("文件格式不支持")
        candidates = [source]
    else:
        for folder, dirs, files in os.walk(source, followlinks=False):
            base = Path(folder)
            dirs[:] = sorted(d for d in dirs if not d.startswith(".") and not (base/d).is_symlink()
                             and (base/d).resolve() != output)
            # Also skip previous splitter outputs copied/selected inside a library.
            if (base / ".splitter-owner.json").is_file():
                dirs[:] = []
                continue
            for name in files:
                path = base / name
                if not name.startswith(".") and not path.is_symlink() and path.suffix.lower() in FORMATS: candidates.append(path)
    chosen = []
    for path in sorted(set(candidates), key=lambda p: str(p).casefold()):
        relative = str(path.relative_to(source)) if source.is_dir() else path.name
        matches = lambda pattern: fnmatch.fnmatchcase(relative.casefold(), pattern.casefold()) or fnmatch.fnmatchcase(path.name.casefold(), pattern.casefold())
        if include and not matches(include): continue
        if any(matches(pattern) for pattern in exclude): continue
        chosen.append(path)
    return chosen[:limit] if limit else chosen


def calibre():
    return shutil.which("ebook-convert") or (str(CALIBRE_APP) if CALIBRE_APP.is_file() else None)


def decode_text(path, encoding):
    raw = path.read_bytes()
    codecs = [encoding] if encoding != "auto" else (["utf-16"] if raw.startswith((b"\xff\xfe", b"\xfe\xff")) else ["utf-8-sig", "gb18030"])
    for codec in codecs:
        try:
            text = raw.decode(codec).replace("\r\n", "\n").replace("\r", "\n")
            if "\0" in text: raise SplitError("TXT 含 NUL，可能是未声明编码或二进制文件")
            if not text.strip(): raise SplitError("TXT 正文为空")
            return Extracted(text, [], "text_pattern_fallback", ["采用 GB18030 解码，请核对文字"] if codec == "gb18030" else [], {"encoding": codec, "toc_present": False})
        except UnicodeError: continue
    raise SplitError("TXT 编码无法解析；请显式选择 --encoding")


def convert_epub(path, cache, timeout):
    binary = calibre()
    if not binary: raise SplitError("MOBI/AZW3/PDF 转 EPUB 需要已安装的 Calibre；不会自动安装")
    target = cache / "converted.epub"
    if target.is_symlink(): raise SplitError("拒绝软链接转换缓存")
    if target.is_file() and target.stat().st_size: return target
    temporary = Path(tempfile.mkdtemp(prefix=".convert-", dir=cache))
    try:
        converted = temporary / "book.epub"
        try:
            process = subprocess.run([binary, str(path), str(converted)], capture_output=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            raise SplitError("Calibre 转 EPUB 超时，原书未改动") from None
        if process.returncode or not converted.is_file() or not converted.stat().st_size:
            if b"drm" in process.stderr.lower(): raise SplitError("电子书受 DRM 保护，请提供合法无加密版本；不绕过保护")
            raise SplitError("Calibre 转 EPUB 失败，未记录原始错误/书籍内容")
        os.replace(converted, target)
        return target
    finally: shutil.rmtree(temporary)


def extraction_options(options):
    return {key: options[key] for key in ("ocr", "ocr_language", "dpi", "min_page_chars", "timeout", "encoding", "pdf_via_epub")}


def extract(path, cache, options):
    suffix = path.suffix.lower()
    if suffix == ".txt": return decode_text(path, options["encoding"])
    if suffix == ".docx": return extract_docx(path)
    if suffix == ".epub": return extract_epub(path)
    if suffix in (".mobi", ".azw3"):
        value = extract_epub(convert_epub(path, cache, options["timeout"]))
        value.method = "calibre_epub_toc"
        return value
    if options["pdf_via_epub"]:
        try:
            value = extract_epub(convert_epub(path, cache, options["timeout"]))
            value.method = "pdf_via_epub_experimental"
            value.metadata["structure_uncertain"] = True
            value.warnings.append("PDF→EPUB 为实验性转换，需人工核对重排/图片和目录")
            return value
        except SplitError:
            conversion_warning = "PDF→EPUB 不可用，已回退到原 PDF 书签方案"
    else: conversion_warning = None
    from pdf_backend import extract_pdf
    value = extract_pdf(path, cache_dir=cache / "pages", **{key: options[key] for key in ("ocr", "ocr_language", "dpi", "min_page_chars", "timeout")})
    if conversion_warning: value.warnings.append(conversion_warning)
    return value


def cached_extraction(path, cache, options):
    cache_file = cache / "extracted.json"
    if cache_file.exists():
        try:
            value = read_json(cache_file)
            text = value["text"]
            if not isinstance(text, str) or hashlib.sha256(text.encode()).hexdigest() != value["text_sha256"]: raise ValueError()
            if value["version"] != VERSION: raise ValueError()
            boundaries = [Boundary(**entry) for entry in value["toc"]]
            if not isinstance(value["method"], str) or not isinstance(value["metadata"], dict) or not isinstance(value["warnings"], list) or any(not isinstance(w, str) for w in value["warnings"]): raise ValueError()
            if any(type(b.position) is not int or not 0 <= b.position <= len(text) or type(b.level) is not int or b.level < 1 or not isinstance(b.title, str) or type(b.children) is not int or b.children < 0 or not isinstance(b.locator, dict) for b in boundaries): raise ValueError()
            result = Extracted(text, boundaries, value["method"], value["warnings"], value["metadata"])
            if not result.metadata.get("incomplete"):
                result.metadata = {**result.metadata, "extraction_cache_hit": True}
                for counter in ("documents_parsed", "native_extraction_calls", "ocr_attempted_pages", "cache_hits", "ocr_cache_hits"):
                    if counter in result.metadata: result.metadata[counter] = 0
                return result
        except (KeyError, TypeError, ValueError): pass
    result = extract(path, cache, options)
    if not result.text.strip():
        if result.metadata.get("incomplete"):
            raise SplitError("没有可用文本层或 OCR 未成功；扫描 PDF 请检查本地语言包并显式使用 --ocr auto/force")
        raise SplitError("没有可写出的正文；未把空白输出算作成功")
    # Incomplete OCR must be retried through its per-page cache, not hidden by a whole-book hit.
    if not result.metadata.get("incomplete"):
        atomic_json(cache_file, {"version": VERSION, **asdict(result), "text_sha256": hashlib.sha256(result.text.encode()).hexdigest()})
    return result


def write_part(root, relative, text):
    path = root / relative
    private_dir(path.parent)
    data = text.encode("utf-8")
    with path.open("xb") as stream:
        os.chmod(path, 0o600)
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    return {"file": relative, "chars": len(text), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def verified_current(destination, source, source_hash, settings):
    current = destination / "current.json"
    if not current.exists(): return None
    pointer = read_json(current)
    identifier = pointer.get("run_id", "")
    if not isinstance(identifier, str) or not re.fullmatch(r"[A-Za-z0-9_-]+", identifier): raise SplitError("结果指针无效")
    run = destination / "runs" / identifier
    if run.is_symlink(): raise SplitError("拒绝软链接结果目录")
    manifest = read_json(run / "manifest.json")
    if manifest.get("source") != str(source) or manifest.get("source_sha256") != source_hash or manifest.get("settings") != settings or manifest.get("version") != VERSION: return None
    if manifest.get("extraction", {}).get("incomplete"): return None
    outputs = manifest.get("files", [])
    if not outputs: return None
    for item in outputs:
        relative = item.get("file", "")
        if not isinstance(relative, str) or not relative or Path(relative).is_absolute() or ".." in Path(relative).parts: raise SplitError("结果清单包含危险路径")
        target = run / relative
        if target.is_symlink() or not target.resolve().is_relative_to(run.resolve()): raise SplitError("结果文件越出运行目录")
        if not target.is_file() or sha_file(target) != item.get("sha256"): return None
    return manifest, run


def process_book(path_string, output_string, options):
    path, output = Path(path_string), Path(output_string)
    started = time.monotonic()
    result = {"source": str(path), "book_name": path.stem, "status": "failed", "needs_review": False}
    staging = None
    try:
        before = snapshot(path)
        source_hash = sha_file(path)
        if snapshot(path) != before: raise SplitError("源文件在读取时发生变化，请保存后重试")
        identity = hashlib.sha256(str(path).encode()).hexdigest()[:12]
        destination = output / (safe_name(path.stem) + "--" + identity)
        locks = output / ".locks"
        private_dir(locks)
        with lock(locks / (identity + ".lock")):
            private_dir(destination)
            owner_file = destination / ".splitter-owner.json"
            if owner_file.exists():
                if read_json(owner_file) != {"skill": "ebook-batch-splitter", "source": str(path)}: raise SplitError("输出目录属于其他输入，拒绝覆盖")
            else:
                if any(destination.iterdir()): raise SplitError("输出目录含无归属文件，拒绝覆盖")
                atomic_json(owner_file, {"skill": "ebook-batch-splitter", "source": str(path)})
            settings = {key: value for key, value in options.items() if key not in ("force", "refresh_cache")}
            if not options["force"] and not options.get("refresh_cache"):
                existing = verified_current(destination, path, source_hash, settings)
                if existing:
                    manifest, run = existing
                    if snapshot(path) != before: raise SplitError("源文件在验证时发生变化")
                    return {**result, **manifest["decision"], "status": "skipped", "output_dir": str(run), "manifest": str(run / "manifest.json"), "elapsed_seconds": round(time.monotonic()-started, 3)}
            cache = destination / ".cache" / source_hash / digest({"version": VERSION, "options": extraction_options(options)})[:20]
            no_symlinks(cache)
            if options.get("refresh_cache") and cache.exists():
                cache.rename(cache.with_name(cache.name + "_previous_" + uuid.uuid4().hex[:12]))
            private_dir(cache)
            extracted = cached_extraction(path, cache, options)
            if snapshot(path) != before: raise SplitError("源文件在提取时发生变化，未发布结果")
            parts, decision = decide(extracted, path.stem, mode=options["mode"], toc_level=options["toc_level"], min_section_chars=options["min_section_chars"])
            if extracted.metadata.get("structure_uncertain") and options["pdf_via_epub"]:
                decision["needs_review"] = True
            runs = destination / "runs"
            private_dir(runs)
            identifier = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "_" + uuid.uuid4().hex[:12]
            staging = Path(tempfile.mkdtemp(prefix=".staging-", dir=destination))
            files, volumes, concatenated = [], [], hashlib.sha256()
            width = max(3, len(str(len(parts))))
            for index, part in enumerate(parts, 1):
                text = extracted.text[part.start:part.end]
                concatenated.update(text.encode())
                basename = f"{index:0{width}d}_" + safe_name(part.title)
                item = write_part(staging, basename + ".txt", text)
                files.append(item)
                volume = {**asdict(part), **item, "chapters": []}
                if options["split_chapters"]:
                    chapters = chapter_parts(text, extracted, part)
                    chapter_width = max(3, len(str(len(chapters))))
                    for number, chapter in enumerate(chapters, 1):
                        real_number = chapter_number(chapter.title)
                        prefix = f"{number:0{chapter_width}d}_" + (f"ch{real_number:03d}_" if real_number is not None else "")
                        chapter_file = write_part(staging, basename + "/" + prefix + safe_name(chapter.title) + ".txt", text[chapter.start:chapter.end])
                        files.append(chapter_file)
                        volume["chapters"].append({**asdict(chapter), **chapter_file, "chapter_number": real_number})
                volumes.append(volume)
            full_hash = hashlib.sha256(extracted.text.encode()).hexdigest()
            if concatenated.hexdigest() != full_hash: raise SplitError("拆分完整性校验失败，未发布结果")
            manifest = {"version": VERSION, "source": str(path), "source_sha256": source_hash, "source_snapshot": list(before),
                        "settings": settings, "decision": decision, "extraction": extracted.metadata,
                        "toc": [asdict(boundary) for boundary in extracted.toc],
                        "canonical_text_sha256": full_hash, "extracted_chars": len(extracted.text),
                        "written_volume_chars": sum(v["chars"] for v in volumes), "coverage_verified": True,
                        "volumes": volumes, "files": files}
            for directory in {staging / str(Path(item["file"]).parent) for item in files}:
                sync_dir(directory)
            atomic_json(staging / "manifest.json", manifest)
            if snapshot(path) != before: raise SplitError("源文件在写入时发生变化，未发布结果")
            run = runs / identifier
            staging.rename(run)
            staging = None
            sync_dir(runs)
            atomic_json(destination / "current.json", {"run_id": identifier})
            result.update(**decision, status="needs_review" if decision["needs_review"] else "success",
                          output_dir=str(run), manifest=str(run / "manifest.json"), extracted_chars=len(extracted.text), coverage_verified=True)
    except Exception as exc:
        result["error"] = str(exc) if isinstance(exc, SplitError) else "本地解析、依赖或文件操作失败（未输出原书/日志内容）"
        result["error_type"] = type(exc).__name__
    finally:
        if staging is not None: shutil.rmtree(staging, ignore_errors=True)
    result["elapsed_seconds"] = round(time.monotonic() - started, 3)
    return result


def doctor():
    return {"status": "dependencies", "python": sys.version.split()[0],
            "formats_without_extra_packages": ["TXT", "EPUB", "DOCX"],
            "PyMuPDF": bool(importlib.util.find_spec("pymupdf") or importlib.util.find_spec("fitz")),
            "calibre": calibre(), "tesseract": shutil.which("tesseract"),
            "automatic_install": False, "network_requests": 0}


def parser():
    command = argparse.ArgumentParser(description="本地电子书批量拆分为 TXT：优先结构目录，保留原文件，不上传")
    command.add_argument("source", nargs="?", type=Path, help="单个文件或递归扫描的电子书目录")
    command.add_argument("-o", "--output", type=Path, default=DEFAULT_OUTPUT)
    command.add_argument("--list-only", action="store_true", help="只列出文件，不创建输出/解析书籍")
    command.add_argument("--doctor", action="store_true", help="离线检查依赖，不安装")
    command.add_argument("--filter", "--include", dest="include")
    command.add_argument("--exclude", action="append", default=[])
    command.add_argument("--limit", type=int, default=0, help="0 表示全部")
    command.add_argument("--mode", choices=("auto", "collection", "single"), default="auto")
    command.add_argument("--toc-level", type=int, default=0, help="0 自动选择首个分叉层；其余指定实际目录层级")
    command.add_argument("--min-section-chars", type=int, default=3000)
    command.add_argument("--split-chapters", action="store_true", help="保留整册 TXT，额外生成无损章节视图，不删除重号内容")
    command.add_argument("--pdf-via-epub", action="store_true", help="实验性 PDF 重排，失败回退原 PDF")
    command.add_argument("--ocr", choices=("off", "auto", "force"), default="off")
    command.add_argument("--ocr-language", default="eng")
    command.add_argument("--dpi", type=int, default=150, help="OCR 渲染 DPI：72-400，默认 150")
    command.add_argument("--min-page-chars", type=int, default=40, help="稀疏页非空白字符阈值：1-10000，默认 40")
    command.add_argument("--timeout", type=int, default=120, help="OCR 每页/Calibre 每本的进程超时：1-3600 秒")
    command.add_argument("--encoding", choices=("auto", "utf-8-sig", "utf-16", "gb18030", "big5"), default="auto")
    command.add_argument("--workers", type=int, default=1, help="1-4 个独立进程；默认 1，PDF 不使用线程共享")
    command.add_argument("--force", action="store_true", help="生成新版本，仍保留历史输出和可用提取缓存")
    command.add_argument("--refresh-cache", action="store_true", help="重新提取/OCR，并保留旧缓存副本与历史输出")
    command.add_argument("--resume", action="store_true", help="兼容标志：默认已自动恢复缓存与校验合格结果")
    return command


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        if args.doctor:
            print(json.dumps(doctor(), ensure_ascii=False, indent=2)); return 0
        if args.source is None: raise SplitError("请提供电子书文件或目录")
        if not (1 <= args.workers <= 4 and 0 <= args.limit and 0 <= args.toc_level <= 30 and 1 <= args.min_section_chars <= 1000000
                and 72 <= args.dpi <= 400 and 1 <= args.min_page_chars <= 10000 and 1 <= args.timeout <= 3600):
            raise SplitError("参数超出安全范围；请查看 --help")
        if not re.fullmatch(r"[A-Za-z0-9_]+(?:\+[A-Za-z0-9_]+)*", args.ocr_language): raise SplitError("OCR 语言格式无效")
        original_output = args.output.expanduser()
        if original_output.is_symlink(): raise SplitError("输出不能是软链接")
        output = original_output.resolve()
        books = discover(args.source, output, args.include, args.exclude, args.limit)
        if args.list_only:
            print(json.dumps({"status": "listed", "count": len(books), "files": [str(p) for p in books], "output": str(output), "network_requests": 0}, ensure_ascii=False, indent=2)); return 0
        private_dir(output)
        options = {key: getattr(args, key) for key in ("force", "refresh_cache", "mode", "toc_level", "min_section_chars", "split_chapters", "pdf_via_epub", "ocr", "ocr_language", "dpi", "min_page_chars", "timeout", "encoding")}
        with lock(output / ".ebook-splitter-batch.lock"):
            started = time.monotonic()
            results = [None] * len(books)
            def progress(index, value):
                results[index] = value
                complete = sum(r is not None for r in results)
                elapsed = time.monotonic() - started
                print(json.dumps({"event": "book_finished", "completed": complete, "total": len(books), "book_name": value["book_name"], "status": value["status"], "eta_seconds": round(elapsed / complete * (len(books)-complete), 1)}, ensure_ascii=False), file=sys.stderr, flush=True)
            if args.workers == 1:
                for i, book in enumerate(books): progress(i, process_book(str(book), str(output), options))
            else:
                with ProcessPoolExecutor(max_workers=args.workers) as pool:
                    futures = {pool.submit(process_book, str(book), str(output), options): i for i, book in enumerate(books)}
                    for future in as_completed(futures):
                        i = futures[future]
                        try: value = future.result()
                        except Exception: value = {"source": str(books[i]), "book_name": books[i].stem, "status": "failed", "needs_review": False, "error": "工作进程异常；未假报成功"}
                        progress(i, value)
            counts = Counter(r["status"] for r in results)
            review = sum(bool(r.get("needs_review")) for r in results)
            report = {"status": "complete", "total": len(books), "success": counts["success"], "skipped": counts["skipped"],
                      "failed": counts["failed"], "needs_review": review, "results": results,
                      "method_counts": dict(Counter(r.get("method_used", "failed") for r in results)),
                      "elapsed_seconds": round(time.monotonic()-started, 3), "source_files_modified": False, "network_requests": 0}
            reports = output / "batch_results"
            private_dir(reports)
            filename = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "_" + uuid.uuid4().hex[:12] + ".json"
            report["report_file"] = str(reports / filename)
            atomic_json(reports / filename, report)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 1 if counts["failed"] or review else 0
    except (SplitError, OSError) as exc:
        print(json.dumps({"status": "error", "message": str(exc) if isinstance(exc, SplitError) else "本地文件操作失败"}, ensure_ascii=False))
        return 2
    except KeyboardInterrupt:
        print(json.dumps({"status": "interrupted", "message": "已保留成功结果与原子缓存；重跑相同命令恢复"}, ensure_ascii=False))
        return 130


if __name__ == "__main__":
    sys.exit(main())
