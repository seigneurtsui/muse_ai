# 格式与接口

## 输入

- CLI 参数：`INPUT_DIR [OUTPUT_DIR] [-r] [--overwrite] [--copy-assets] [--unsafe-raw-html] [--dry-run] [--json]`。
- `INPUT_DIR`：包含 Markdown 的目录，必须存在且不是符号链接/reparse point。
- `OUTPUT_DIR`：可选，默认 `~/Downloads/html_toc_silo`。必须不在输入目录内，也不能等于输入目录。
- 识别的扩展名：`.md`、`.markdown`、`.mdown`、`.mkdn`（大小写不敏感）。
- 编码探测顺序：`utf-8-sig`、`utf-8`、`gb18030`、`gbk`；全部失败记为 `text_decode_failed`。

## 输出

- 每个 Markdown 对应一个独立的 `.html`；`-r` 时保留相对目录结构，否则只处理顶层并平铺输出。
- `--copy-assets` 时，输入目录内的本地图片复制到输出同级的 `assets/`，文件名带内容哈希前缀
  （`<stem>-<sha256[:12]><suffix>`）；输入目录外的路径、链接和缺失文件只记录警告，不改写。
- `conversion_report.json`：机器可读报告。
- `conversion_report.txt`：人类可读摘要。

## 报告字段（JSON）

- 顶层：`version`、`generated_at`、`input_dir`、`output_dir`、`recursive`、`sanitize`、
  `copy_assets`、`summary`、`files`、`status`。
- `summary`：`total`、`success`、`skipped`、`failed`。
- 每个文件：`source`、`output`、`status`（`success`/`skipped`/`failed`）、`encoding`、
  `title`、`toc_items`、`assets_copied`、`warnings`、`source_sha256`、`output_sha256`、
  `output_bytes`、`elapsed_seconds`；跳过时为 `reason`，失败时为 `reason`。
- 报告不写入 Markdown 正文。
- `--dry-run` 返回 `status: "dry_run"`，不创建输出、报告或 HTML。

## 退出码

- `0`：批次完成（`complete` 或 `dry_run`）且没有失败。
- `1`：批次无法启动（参数/目录边界错误、依赖缺失、`input_output_overlap` 等）。
- `2`：批次运行但至少一个文件失败（`partial_failure`）。
