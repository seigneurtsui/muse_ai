#!/usr/bin/env python3
"""Batch-deploy static HTML to Cloudflare Pages.

Adapted from the supplied ``cf_factory.py`` (a Workers + Pages batch factory).
This tool keeps that project's proven design — YAML-driven batch, persisted
state for resumable runs, retry with backoff, dual console/file logging — but
scopes it to publishing static HTML directories/files to Cloudflare Pages and
adds a few improvements:

* content-hash skip: unchanged sites are not re-uploaded;
* bounded parallelism across projects (``--jobs``);
* per-project API lookup instead of listing every project each time;
* config-relative source paths and a ``discover`` helper for a parent directory
  of per-site folders;
* atomic state writes and a machine-readable run report.

Examples:
    cf_pages_deploy.py discover --root ~/Downloads/sites --output cf.yaml
    cf_pages_deploy.py deploy --config cf.yaml
    cf_pages_deploy.py deploy --config cf.yaml --only voyage --force
    cf_pages_deploy.py deploy --dir ./site --project-name my-site
    cf_pages_deploy.py deploy --config cf.yaml --dry-run --json
    cf_pages_deploy.py list
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

try:
    import requests
except ImportError:  # pragma: no cover - exercised via dependency-code path
    requests = None  # type: ignore[assignment]

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None  # type: ignore[assignment]


VERSION = "1.0.0"

API_BASE = "https://api.cloudflare.com/client/v4"
DEFAULT_ENV_FILE = Path.home() / ".config" / "freebuff" / ".env"
DEFAULT_STATE_NAME = ".cf_pages_deploy_state.json"
DEFAULT_TIMEOUT = 600
DEFAULT_RETRIES = 3
RETRY_BASE_SECONDS = 2.0
MAX_JOBS = 8
HASH_CHUNK_BYTES = 1 << 20
MAX_WARNING_CHARS = 600

# Cloudflare Pages project names are lowercase alphanumeric with hyphens.
PROJECT_NAME_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,56}[a-z0-9])?$")
DEPLOY_URL_RE = re.compile(r"https://[A-Za-z0-9._-]+\.pages\.dev[^\s\"']*")
HTML_SUFFIXES = (".html", ".htm")

log = logging.getLogger("cf-pages-deploy")


class DeployError(Exception):
    """Error carrying a short, log-safe reason code."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def reason(error: BaseException) -> str:
    code = getattr(error, "code", "")
    if isinstance(code, str) and re.fullmatch(r"[a-z][a-z0-9_]{0,79}", code):
        return code
    return "unexpected_error"


# --------------------------------------------------------------------------
# Environment and credentials
# --------------------------------------------------------------------------


def parse_env_file(path: Path) -> dict[str, str]:
    """Parse a minimal ``KEY=VALUE`` env file; never mutates the process."""
    values: dict[str, str] = {}
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return values
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key.startswith("export "):
            key = key[len("export ") :].strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        if key:
            values[key] = value
    return values


def load_env_files(paths: list[Optional[str]]) -> list[str]:
    """Load env files into ``os.environ`` without overriding real variables.

    Returns the list of files that were actually read (for logging).
    """
    loaded: list[str] = []
    for raw in paths:
        if not raw:
            continue
        path = Path(raw).expanduser()
        if not path.is_file():
            continue
        loaded.append(str(path))
        for key, value in parse_env_file(path).items():
            os.environ.setdefault(key, value)
    return loaded


def credentials() -> tuple[Optional[str], Optional[str]]:
    token = os.environ.get("CF_API_TOKEN") or os.environ.get("CLOUDFLARE_API_TOKEN")
    account = os.environ.get("CF_ACCOUNT_ID") or os.environ.get("CLOUDFLARE_ACCOUNT_ID")
    return token, account


# --------------------------------------------------------------------------
# Specs and configuration
# --------------------------------------------------------------------------


@dataclass
class PageSpec:
    name: str
    source: str
    branch: str = "main"
    create_if_missing: bool = True
    commit_message: Optional[str] = None
    skip_caching: bool = False

    def source_path(self) -> Path:
        return Path(self.source).expanduser()

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "source": self.source,
            "branch": self.branch,
            "create_if_missing": self.create_if_missing,
        }


def validate_project_name(name: str) -> None:
    if not PROJECT_NAME_RE.match(name or ""):
        raise DeployError(f"invalid_project_name:{name}")


def _coerce_spec(name: str, data: dict[str, Any], base: Path) -> PageSpec:
    if not isinstance(data, dict) or "source_dir" not in data:
        raise DeployError(f"invalid_project_config:{name}")
    source = str(data["source_dir"])
    candidate = Path(source).expanduser()
    if not candidate.is_absolute():
        candidate = (base / candidate).resolve()
    return PageSpec(
        name=name,
        source=str(candidate),
        branch=str(data.get("branch", "main")),
        create_if_missing=bool(data.get("create_if_missing", True)),
        commit_message=data.get("commit_message"),
        skip_caching=bool(data.get("skip_caching", False)),
    )


def load_config(path: str) -> list[PageSpec]:
    """Load ``pages:`` entries; source paths resolve against the config dir."""
    config_path = Path(path).expanduser().resolve()
    if not config_path.is_file():
        raise DeployError("config_not_found")
    if yaml is None:
        raise DeployError("yaml_dependency_missing")
    try:
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        raise DeployError("config_parse_failed") from None
    pages = raw.get("pages") or {}
    if not isinstance(pages, dict) or not pages:
        raise DeployError("config_has_no_pages")
    specs: list[PageSpec] = []
    for name, data in pages.items():
        spec = _coerce_spec(str(name), data, config_path.parent)
        validate_project_name(spec.name)
        specs.append(spec)
    return specs


def discover_specs(
    root: str, branch: str = "main", name_prefix: str = ""
) -> list[PageSpec]:
    """Find immediate sub-directories that contain HTML and make a spec each."""
    root_path = Path(root).expanduser().resolve()
    if not root_path.is_dir():
        raise DeployError("discover_root_not_directory")
    specs: list[PageSpec] = []
    for child in sorted(root_path.iterdir(), key=lambda p: p.name.casefold()):
        if not child.is_dir() or child.name.startswith("."):
            continue
        if not any(
            p.is_file() and p.suffix.lower() in HTML_SUFFIXES for p in child.rglob("*")
        ):
            continue
        name = f"{name_prefix}{child.name}".lower()
        name = re.sub(r"[^a-z0-9-]+", "-", name).strip("-")
        if not name:
            continue
        specs.append(PageSpec(name=name, source=str(child), branch=branch))
    if not specs:
        raise DeployError("discover_found_no_sites")
    return specs


def specs_from_args(args: argparse.Namespace) -> list[PageSpec]:
    if args.config:
        specs = load_config(args.config)
    elif args.discover_root:
        specs = discover_specs(args.discover_root, args.branch, args.name_prefix or "")
    elif args.dir:
        if not args.project_name:
            raise DeployError("project_name_required")
        validate_project_name(args.project_name)
        specs = [
            PageSpec(
                name=args.project_name,
                source=str(Path(args.dir).expanduser().resolve()),
                branch=args.branch,
            )
        ]
    else:
        raise DeployError("no_input_specified")
    if args.only:
        wanted = {item.strip() for item in args.only.split(",") if item.strip()}
        specs = [spec for spec in specs if spec.name in wanted]
        if not specs:
            raise DeployError("only_matched_nothing")
    return specs


def default_state_path(args: argparse.Namespace) -> Path:
    if args.state:
        return Path(args.state).expanduser()
    if args.config:
        return Path(args.config).expanduser().resolve().parent / DEFAULT_STATE_NAME
    return Path.cwd() / DEFAULT_STATE_NAME


# --------------------------------------------------------------------------
# Source hashing
# --------------------------------------------------------------------------


def source_digest(path: Path) -> dict[str, Any]:
    """Hash a file or directory tree; streams bytes to stay memory-bounded."""
    if path.is_file():
        digest = hashlib.sha256()
        size = 0
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(HASH_CHUNK_BYTES), b""):
                size += len(chunk)
                digest.update(chunk)
        return {"sha256": digest.hexdigest(), "files": 1, "bytes": size, "mode": "file"}
    if not path.is_dir():
        raise DeployError("source_not_found")

    digest = hashlib.sha256()
    files = 0
    size = 0
    for file_path in sorted(
        (p for p in path.rglob("*") if p.is_file() and not p.is_symlink()),
        key=lambda p: p.relative_to(path).as_posix(),
    ):
        rel = file_path.relative_to(path).as_posix()
        digest.update(rel.encode("utf-8"))
        digest.update(b"\0")
        with file_path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(HASH_CHUNK_BYTES), b""):
                size += len(chunk)
                digest.update(chunk)
        digest.update(b"\0")
        files += 1
    return {"sha256": digest.hexdigest(), "files": files, "bytes": size, "mode": "dir"}


def count_html(path: Path) -> int:
    if path.is_file():
        return 1 if path.suffix.lower() in HTML_SUFFIXES else 0
    return sum(
        1 for p in path.rglob("*") if p.is_file() and p.suffix.lower() in HTML_SUFFIXES
    )


# --------------------------------------------------------------------------
# State
# --------------------------------------------------------------------------


def load_state(path: Path) -> dict[str, Any]:
    if path.is_file():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                data.setdefault("pages", {})
                return data
        except (OSError, json.JSONDecodeError):
            log.warning("state file unreadable, starting fresh: %s", path)
    return {"version": VERSION, "pages": {}}


def save_state(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True)
    fd, temp_name = tempfile.mkstemp(
        prefix=".cf-pages-", suffix=".tmp", dir=path.parent
    )
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


# --------------------------------------------------------------------------
# Cloudflare API client
# --------------------------------------------------------------------------


class CloudflareClient:
    """Thin Cloudflare API wrapper with retry + 404-aware project lookup."""

    def __init__(
        self,
        token: str,
        account_id: str,
        *,
        timeout: int = 30,
        retries: int = DEFAULT_RETRIES,
    ):
        if requests is None:
            raise DeployError("requests_dependency_missing")
        if not token or not account_id:
            raise DeployError("credentials_missing")
        self.account_id = account_id
        self.timeout = timeout
        self.retries = retries
        self.session = requests.Session()
        self.session.headers.update({"Authorization": f"Bearer {token}"})

    def _request(self, method: str, url: str, **kwargs: Any) -> tuple[int, dict]:
        last_error: Optional[BaseException] = None
        for attempt in range(1, self.retries + 1):
            try:
                response = self.session.request(
                    method, url, timeout=self.timeout, **kwargs
                )
            except Exception as exc:  # requests.RequestException + SSL errors
                last_error = exc
            else:
                if response.status_code == 404:
                    return 404, {}
                if response.status_code == 429 or response.status_code >= 500:
                    last_error = DeployError(f"http_{response.status_code}")
                else:
                    try:
                        data = response.json()
                    except ValueError:
                        last_error = DeployError("invalid_json_response")
                    else:
                        if response.status_code >= 400 or not data.get("success", True):
                            raise DeployError(
                                f"api_error_{response.status_code}:"
                                f"{_summarize_errors(data.get('errors'))}"
                            )
                        return response.status_code, data
            if attempt < self.retries:
                time.sleep(RETRY_BASE_SECONDS * attempt)
        raise DeployError(f"api_request_failed:{reason(last_error)}")

    def get_pages_project(self, name: str) -> Optional[dict]:
        url = f"{API_BASE}/accounts/{self.account_id}/pages/projects/{name}"
        status, data = self._request("GET", url)
        if status == 404:
            return None
        return data.get("result")

    def create_pages_project(self, name: str, branch: str = "main") -> dict:
        url = f"{API_BASE}/accounts/{self.account_id}/pages/projects"
        payload = {"name": name, "production_branch": branch}
        _, data = self._request("POST", url, json=payload)
        return data.get("result", {})

    def list_pages_projects(self) -> list[dict]:
        # Cloudflare rejects per_page > 10 for Pages projects (error 8000024),
        # so page through in chunks of 10 instead of asking for everything.
        url = f"{API_BASE}/accounts/{self.account_id}/pages/projects"
        projects: list[dict] = []
        page = 1
        while page <= 100:
            _, data = self._request("GET", url, params={"page": page, "per_page": 10})
            batch = data.get("result") or []
            projects.extend(batch)
            total_pages = (data.get("result_info") or {}).get("total_pages")
            if total_pages is not None:
                if page >= int(total_pages):
                    break
            elif len(batch) < 10:
                break
            page += 1
        return projects


def _summarize_errors(errors: Any) -> str:
    if not errors:
        return "unknown"
    try:
        codes = [str(item.get("code", "?")) for item in errors]
    except (AttributeError, TypeError):
        return "unknown"
    return ",".join(codes)


# --------------------------------------------------------------------------
# Wrangler
# --------------------------------------------------------------------------


def find_wrangler() -> list[str]:
    executable = shutil.which("wrangler")
    if executable:
        return [executable]
    npx = shutil.which("npx")
    if npx:
        return [npx, "--yes", "wrangler"]
    raise DeployError("wrangler_not_found")


@dataclass
class CommandResult:
    returncode: int
    stdout: str
    stderr: str


def build_wrangler_command(
    prefix: list[str], source: Path, spec: PageSpec
) -> list[str]:
    command = [
        *prefix,
        "pages",
        "deploy",
        str(source),
        "--project-name",
        spec.name,
        "--branch",
        spec.branch,
        "--commit-dirty=true",
    ]
    if spec.commit_message:
        command += ["--commit-message", spec.commit_message]
    if spec.skip_caching:
        command.append("--skip-caching")
    return command


def run_wrangler(
    prefix: list[str],
    source: Path,
    spec: PageSpec,
    token: str,
    account: str,
    timeout: int,
) -> CommandResult:
    env = os.environ.copy()
    env["CLOUDFLARE_API_TOKEN"] = token
    env["CLOUDFLARE_ACCOUNT_ID"] = account
    try:
        completed = subprocess.run(
            build_wrangler_command(prefix, source, spec),
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return CommandResult(1, "", f"wrangler timed out after {timeout}s")
    except OSError as error:
        return CommandResult(1, "", f"failed to run wrangler: {error}")
    return CommandResult(completed.returncode, completed.stdout, completed.stderr)


def deploy_wrangler(
    prefix: list[str],
    source: Path,
    spec: PageSpec,
    token: str,
    account: str,
    opts: "Options",
) -> CommandResult:
    result = CommandResult(1, "", "")
    for attempt in range(1, opts.retries + 1):
        result = run_wrangler(prefix, source, spec, token, account, opts.timeout)
        if result.returncode == 0:
            return result
        if attempt < opts.retries:
            wait = RETRY_BASE_SECONDS * (2 ** (attempt - 1))
            log.warning(
                "[%s] wrangler failed (attempt %d/%d), retrying in %.0fs",
                spec.name,
                attempt,
                opts.retries,
                wait,
            )
            time.sleep(wait)
    return result


def parse_deploy_url(output: str) -> Optional[str]:
    matches = DEPLOY_URL_RE.findall(output or "")
    return matches[-1] if matches else None


def _tail(text: str, limit: int = MAX_WARNING_CHARS) -> str:
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    return "..." + text[-limit:]


# --------------------------------------------------------------------------
# Options and per-project deployment
# --------------------------------------------------------------------------


@dataclass
class Options:
    force: bool = False
    retry_failed: bool = False
    dry_run: bool = False
    retries: int = DEFAULT_RETRIES
    timeout: int = DEFAULT_TIMEOUT


def decide_skip(
    spec: PageSpec,
    prior: Optional[dict],
    digest: dict,
    opts: Options,
) -> Optional[str]:
    if opts.force or not prior:
        return None
    if prior.get("status") != "success":
        return None
    if opts.retry_failed:
        return "retry_failed_skip"
    if (
        prior.get("content_sha256") == digest["sha256"]
        and prior.get("branch") == spec.branch
    ):
        return "unchanged"
    return None


def _validate_source(spec: PageSpec) -> tuple[Path, list[str]]:
    source = spec.source_path()
    if not source.exists():
        raise DeployError("source_not_found")
    if not (source.is_file() or source.is_dir()):
        raise DeployError("source_not_file_or_directory")
    warnings: list[str] = []
    if source.is_file() and source.suffix.lower() not in HTML_SUFFIXES:
        raise DeployError("source_not_html_file")
    return source, warnings


def plan_one(spec: PageSpec, prior: Optional[dict], opts: Options) -> dict[str, Any]:
    """Dry-run planning: filesystem checks only, no network, no writes."""
    started = time.perf_counter()
    source, warnings = _validate_source(spec)
    digest = source_digest(source)
    html_files = count_html(source)
    if digest["mode"] == "dir" and html_files == 0:
        warnings.append("no_html_files")
    if digest["mode"] == "file" and digest["bytes"] == 0:
        warnings.append("empty_html_file")
    skip_reason = decide_skip(spec, prior, digest, opts)
    result: dict[str, Any] = {
        "name": spec.name,
        "source": str(source),
        "branch": spec.branch,
        "mode": digest["mode"],
        "files": digest["files"],
        "bytes": digest["bytes"],
        "html_files": html_files,
        "content_sha256": digest["sha256"],
        "warnings": warnings,
        "elapsed_seconds": round(time.perf_counter() - started, 3),
    }
    if skip_reason:
        result["status"] = "skipped"
        result["reason"] = skip_reason
    else:
        result["status"] = "planned"
    return result


def deploy_one(
    spec: PageSpec,
    prior: Optional[dict],
    opts: Options,
    token: str,
    account: str,
    prefix: list[str],
) -> dict[str, Any]:
    started = time.perf_counter()
    source, warnings = _validate_source(spec)
    digest = source_digest(source)
    html_files = count_html(source)
    if digest["mode"] == "dir" and html_files == 0:
        warnings.append("no_html_files")
    if digest["mode"] == "file" and digest["bytes"] == 0:
        warnings.append("empty_html_file")

    skip_reason = decide_skip(spec, prior, digest, opts)
    if skip_reason:
        return {
            "name": spec.name,
            "source": str(source),
            "status": "skipped",
            "reason": skip_reason,
            "content_sha256": digest["sha256"],
            "branch": spec.branch,
            "elapsed_seconds": round(time.perf_counter() - started, 3),
        }

    client = CloudflareClient(token, account)
    existing = client.get_pages_project(spec.name)
    if existing is None:
        if not spec.create_if_missing:
            return _failure(spec, source, started, "project_missing", warnings, digest)
        client.create_pages_project(spec.name, spec.branch)
        created = True
    else:
        created = False

    command = deploy_wrangler(prefix, source, spec, token, account, opts)
    if command.returncode != 0:
        return _failure(
            spec,
            source,
            started,
            "wrangler_failed",
            warnings,
            digest,
            detail=_tail(command.stderr or command.stdout),
        )

    url = parse_deploy_url(command.stdout) or parse_deploy_url(command.stderr)
    return {
        "name": spec.name,
        "source": str(source),
        "status": "success",
        "url": url,
        "branch": spec.branch,
        "mode": digest["mode"],
        "files": digest["files"],
        "bytes": digest["bytes"],
        "html_files": html_files,
        "created_project": created,
        "content_sha256": digest["sha256"],
        "warnings": warnings,
        "elapsed_seconds": round(time.perf_counter() - started, 3),
    }


def _failure(
    spec: PageSpec,
    source: Path,
    started: float,
    code: str,
    warnings: list[str],
    digest: dict,
    detail: str = "",
) -> dict[str, Any]:
    result: dict[str, Any] = {
        "name": spec.name,
        "source": str(source),
        "status": "failed",
        "reason": code,
        "branch": spec.branch,
        "warnings": warnings,
        "content_sha256": digest["sha256"],
        "elapsed_seconds": round(time.perf_counter() - started, 3),
    }
    if detail:
        result["detail"] = detail
    return result


def merge_state(state: dict[str, Any], result: dict[str, Any]) -> None:
    # A skip must never downgrade a previously recorded success, otherwise the
    # next run would lose the content hash and re-upload an unchanged site.
    if result.get("status") == "skipped":
        return
    name = result["name"]
    pages = state.setdefault("pages", {})
    entry = pages.setdefault(name, {})
    entry["status"] = result["status"]
    entry["updated_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    for key in ("branch", "content_sha256", "url", "reason", "source"):
        if key in result and result[key] is not None:
            entry[key] = result[key]


# --------------------------------------------------------------------------
# Batch orchestration
# --------------------------------------------------------------------------


def resolve_jobs(requested: Optional[str], count: int) -> int:
    if count <= 0:
        return 1
    if requested in (None, "", "auto"):
        return max(1, min(4, count))
    try:
        value = int(requested)
    except (TypeError, ValueError):
        raise DeployError("invalid_jobs_value") from None
    return max(1, min(MAX_JOBS, value, count))


def batch(args: argparse.Namespace) -> dict[str, Any]:
    specs = specs_from_args(args)
    state_path = default_state_path(args)
    state = load_state(state_path)
    opts = Options(
        force=args.force,
        retry_failed=args.retry_failed,
        dry_run=args.dry_run,
        retries=args.retries,
        timeout=args.timeout,
    )
    order = {spec.name: index for index, spec in enumerate(specs)}
    started = time.perf_counter()

    if args.dry_run:
        results = []
        for spec in specs:
            try:
                results.append(plan_one(spec, state["pages"].get(spec.name), opts))
            except Exception as error:  # noqa: BLE001 - report, keep planning
                results.append(
                    {"name": spec.name, "status": "failed", "reason": reason(error)}
                )
        return _finalize(results, state, state_path, args, started, write=False)

    token, account = credentials()
    if not token or not account:
        raise DeployError("credentials_missing")
    prefix = find_wrangler()
    jobs = resolve_jobs(args.jobs, len(specs))
    log.info("deploying %d project(s) with %d worker(s)", len(specs), jobs)

    results: dict[str, dict[str, Any]] = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=jobs) as pool:
        futures = {
            pool.submit(
                deploy_one,
                spec,
                state["pages"].get(spec.name),
                opts,
                token,
                account,
                prefix,
            ): spec
            for spec in specs
        }
        for future in concurrent.futures.as_completed(futures):
            spec = futures[future]
            try:
                result = future.result()
            except Exception as error:  # noqa: BLE001 - keep batch going
                result = {
                    "name": spec.name,
                    "status": "failed",
                    "reason": reason(error),
                }
            results[spec.name] = result
            merge_state(state, result)
            save_state(state_path, state)
            _log_result(result)

    ordered = [results[spec.name] for spec in specs]
    return _finalize(ordered, state, state_path, args, started, write=True)


def _finalize(
    results: list[dict[str, Any]],
    state: dict[str, Any],
    state_path: Path,
    args: argparse.Namespace,
    started: float,
    *,
    write: bool,
) -> dict[str, Any]:
    summary = {
        "total": len(results),
        "success": sum(item["status"] == "success" for item in results),
        "planned": sum(item["status"] == "planned" for item in results),
        "skipped": sum(item["status"] == "skipped" for item in results),
        "failed": sum(item["status"] == "failed" for item in results),
    }
    report = {
        "version": VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "status": _overall_status(summary, args.dry_run),
        "dry_run": args.dry_run,
        "summary": summary,
        "results": results,
        "elapsed_seconds": round(time.perf_counter() - started, 3),
    }
    if write:
        report["state_path"] = str(state_path)
        if args.report:
            report_path = Path(args.report).expanduser()
            report_path.parent.mkdir(parents=True, exist_ok=True)
            report_path.write_text(
                json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            report["report_path"] = str(report_path)
    return report


def _overall_status(summary: dict[str, int], dry_run: bool) -> str:
    if summary["failed"]:
        return "partial_failure"
    if dry_run:
        return "dry_run"
    return "complete"


def _log_result(result: dict[str, Any]) -> None:
    status = result["status"]
    name = result["name"]
    if status == "success":
        log.info("[%s] deployed %s", name, result.get("url") or "")
    elif status == "skipped":
        log.info("[%s] skipped (%s)", name, result.get("reason"))
    elif status == "failed":
        log.error("[%s] failed (%s)", name, result.get("reason"))
    else:
        log.info("[%s] %s", name, status)


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="cf_pages_deploy.py",
        description="Batch-deploy static HTML to Cloudflare Pages.",
    )
    parser.add_argument(
        "-v", "--version", action="version", version=f"%(prog)s {VERSION}"
    )
    parser.add_argument(
        "--env-file",
        action="append",
        default=None,
        help=f"extra env file to load (default also reads {DEFAULT_ENV_FILE})",
    )
    parser.add_argument("--verbose", action="store_true", help="debug logging")
    parser.add_argument("--log-file", help="also write logs to this file")

    sub = parser.add_subparsers(dest="command", required=True)

    deploy = sub.add_parser("deploy", help="deploy one or many Pages projects")
    _add_source_args(deploy)
    deploy.add_argument("--only", help="comma-separated project names to deploy")
    deploy.add_argument("--force", action="store_true", help="ignore content-hash skip")
    deploy.add_argument(
        "--retry-failed",
        action="store_true",
        help="only attempt projects not recorded as successful",
    )
    deploy.add_argument("--dry-run", action="store_true", help="plan only, no network")
    deploy.add_argument(
        "--jobs", default="auto", help="parallel projects (default auto)"
    )
    deploy.add_argument("--retries", type=int, default=DEFAULT_RETRIES)
    deploy.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT)
    deploy.add_argument("--state", help="state file path")
    deploy.add_argument("--report", help="write a JSON report to this path")
    deploy.add_argument("--json", action="store_true", help="print report as JSON")

    discover = sub.add_parser(
        "discover", help="find per-site sub-directories and emit a config"
    )
    discover.add_argument("--root", required=True, help="parent directory of sites")
    discover.add_argument("--branch", default="main")
    discover.add_argument("--name-prefix", default="")
    discover.add_argument("--output", help="write YAML here (default stdout)")

    listing = sub.add_parser("list", help="list Pages projects in the account")
    listing.add_argument("--json", action="store_true")

    return parser


def _add_source_args(parser: argparse.ArgumentParser) -> None:
    group = parser.add_argument_group("source (choose one)")
    group.add_argument("--config", help="YAML config with a pages: section")
    group.add_argument("--dir", help="single directory or .html file to deploy")
    group.add_argument(
        "--discover-root",
        dest="discover_root",
        help="parent directory; deploy each HTML sub-directory as a project",
    )
    group.add_argument("--project-name", help="project name for --dir mode")
    group.add_argument("--branch", default="main")
    group.add_argument("--name-prefix", default="")


def _setup_logging(verbose: bool, log_file: Optional[str]) -> None:
    log.setLevel(logging.DEBUG if verbose else logging.INFO)
    log.handlers.clear()
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(message)s", datefmt="%H:%M:%S"
    )
    console = logging.StreamHandler(sys.stderr)
    console.setLevel(logging.DEBUG if verbose else logging.INFO)
    console.setFormatter(formatter)
    log.addHandler(console)
    if log_file:
        path = Path(log_file).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        handler = logging.FileHandler(path, encoding="utf-8")
        handler.setLevel(logging.DEBUG)
        handler.setFormatter(formatter)
        log.addHandler(handler)


def _dump_yaml(document: dict) -> str:
    """Dump config YAML, quoting strings that contain spaces or '#'."""
    if yaml is None:
        raise DeployError("yaml_dependency_missing")

    class _Dumper(yaml.SafeDumper):
        pass

    def _represent_str(dumper, data):
        style = '"' if any(ch in data for ch in " \t#") else None
        return dumper.represent_scalar("tag:yaml.org,2002:str", data, style=style)

    _Dumper.add_representer(str, _represent_str)
    # A very large width stops PyYAML wrapping long paths across lines.
    return yaml.dump(
        document, Dumper=_Dumper, allow_unicode=True, sort_keys=False, width=10**6
    )


def _discover_command(args: argparse.Namespace) -> int:
    specs = discover_specs(args.root, args.branch, args.name_prefix)
    document = {
        "pages": {
            spec.name: {
                "source_dir": spec.source,
                "branch": spec.branch,
                "create_if_missing": spec.create_if_missing,
            }
            for spec in specs
        }
    }
    text = _dump_yaml(document)
    if args.output:
        output = Path(args.output).expanduser()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(text, encoding="utf-8")
        log.info("wrote %d site(s) to %s", len(specs), output)
    else:
        sys.stdout.write(text)
    return 0


def _list_command(args: argparse.Namespace) -> int:
    token, account = credentials()
    if not token or not account:
        raise DeployError("credentials_missing")
    projects = CloudflareClient(token, account).list_pages_projects()
    if args.json:
        print(json.dumps(projects, ensure_ascii=False, indent=2))
        return 0
    log.info("%d Pages project(s):", len(projects))
    for project in projects:
        domains = ", ".join(project.get("domains", []))
        log.info("  - %s  (%s)", project.get("name"), domains or "no domain")
    return 0


def main(argv: Optional[list[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    env_files = list(args.env_file or [])
    env_files.append(str(DEFAULT_ENV_FILE))
    _setup_logging(getattr(args, "verbose", False), getattr(args, "log_file", None))
    loaded = load_env_files(env_files)
    if loaded:
        log.debug("loaded env files: %s", ", ".join(loaded))

    try:
        if args.command == "deploy":
            report = batch(args)
            if getattr(args, "json", False):
                print(json.dumps(report, ensure_ascii=False, indent=2))
            else:
                _print_summary(report)
            return 0 if report["summary"]["failed"] == 0 else 2
        if args.command == "discover":
            return _discover_command(args)
        if args.command == "list":
            return _list_command(args)
    except DeployError as error:
        if getattr(args, "json", False):
            print(json.dumps({"status": "error", "reason": error.code}))
        else:
            log.error("error: %s", error.code)
        return 1
    except Exception as error:  # noqa: BLE001 - top-level guard
        if getattr(args, "json", False):
            print(json.dumps({"status": "error", "reason": reason(error)}))
        else:
            log.error("unexpected error: %s", reason(error))
        return 1
    return 1


def _print_summary(report: dict[str, Any]) -> None:
    summary = report["summary"]
    log.info(
        "done: total=%d success=%d skipped=%d failed=%d (%.2fs)",
        summary["total"],
        summary["success"],
        summary["skipped"],
        summary["failed"],
        report["elapsed_seconds"],
    )
    failed = [item["name"] for item in report["results"] if item["status"] == "failed"]
    if failed:
        log.warning("failed projects: %s", ", ".join(failed))
        log.warning("re-run with --retry-failed to retry only those")


if __name__ == "__main__":
    raise SystemExit(main())
