# 验证记录

## 当前版本

- 安装目录：`~/.config/omnirush/skills/zip-subfolders/`
- 来源：`/tmp/zip_subfolders_cli.py`；SHA-256 保存在 `source-hashes.json`，原脚本未执行、未修改。
- 生产路径使用 Python 3.12.10 / macOS x86_64 标准库；没有安装依赖。
- 当前实现明确验证 ZIP/TAR.GZ；7z 只在用户显式选择并且本机已有 `7z`/`7zz` 时尝试，本次测试用 mock 验证缺少命令的失败边界，没有宣称实机 7z 成功。
- **16 项测试通过，0 失败，0 跳过**。
- Black 26.5.1 格式化后通过。
- Python 3.10 语法解析、编译检查和无 `.pyc` 交付检查在最终阶段执行。

测试日志：`/tmp/zip-subfolders-tests.log`。

## 合成目录验证

测试每次创建临时源/目标目录，包含普通文本、Unicode 文本、嵌套目录、空目录、隐藏目录、默认排除目录、符号链接和可选 FIFO；不会读取或压缩其他私人目录。

覆盖并验证：

- 深度 1–5 的发现、手工相对/绝对选择、默认排除、链接不跟随。
- dry-run 不创建目标目录、锁、压缩包或报告。
- ZIP 新建、CRC 校验、成员相对路径、子目录同名时的输出层次。
- TAR.GZ 新建和文件回读。
- 多 worker 独立归档。
- 已有归档跳过且修改时间不变。
- 源目录变化时默认拒绝使用旧归档，`--overwrite` 才重建。
- 已有损坏压缩包不被默认覆盖。
- 源/目标重叠、选择重叠、目标父级链接、特殊文件、残留锁和超限输入 fail-closed。
- 状态/报告记录统计和哈希，但不包含测试文件正文。
- 7z 工具缺失时每个任务都明确失败，不安装、不回退为另一格式。

## CLI 检查

```bash
cd ~/.config/omnirush/skills/zip-subfolders
python3 -B -m unittest discover -s tests -v
python3 -B scripts/zip_subfolders.py --help
python3 -B scripts/zip_subfolders.py --source /tmp/example --target /tmp/example-out --dry-run
```

`--dry-run` 的目录必须由调用者明确指定；文档不要求运行默认家目录路径。输出是安全原因码和任务统计，不把压缩中文件正文打印到终端。

## 加载与源文件

OmniRush 1.0.15 原生加载器识别 `zip-subfolders` 且诊断为空。原始 `/tmp/zip_subfolders_cli.py` 的字节哈希与 `references/source-hashes.json` 一致。未修改 `.env`、全局设置或原项目。没有执行原脚本的 Gradio UI、没有访问用户源目录、没有安装 py7zr/7z。

## 限制和诚实边界

- 未实测 Linux、Windows、Apple Silicon、Python 3.10 解释器；不能把 macOS Python 3.12 结果泛化为其他平台。
- 未宣称 7z 外部命令、cpgz、密码压缩或第三方 py7zr 功能成功。
- 指纹由路径、文件大小、mtime、权限和跳过项组成，不是内容哈希/防篡改签名，也不是冻结快照；不合作进程仍可在检查之后制造竞态。
- 压缩包完整性校验不等于备份语义或数据恢复保证。符号链接和特殊文件明确跳过，不是完整复制。
- 没有做跨设备性能基准，不声称固定加速倍数。并行只适用于独立子文件夹，磁盘 I/O 仍可能成为瓶颈。

## 安全扫描

本次实际运行 SkillSpector 2.12.0 `--no-llm`：**18/100 LOW，`CAUTION`，退出码 1，3 项问题**，报告 `/tmp/zip-subfolders-scan-final.json`。两项 RA2 把文档中的批次状态/锁与安装路径跨行匹配成会话持久化；它们是用户明确运行所需的可删除状态，不是后台任务、启动项或自修改。AST4 命中生产中用户显式选择 7z 时的 `subprocess.run`；该调用固定可执行文件和参数数组、`shell=False`、有超时，不执行源文件内容。没有为这些问题申请不必要的网络/环境权限，也没有把扫描结果改写成“clean”。安装和实际使用仍应遵守：只指定源目录、先 dry-run、默认不覆盖、重要归档另行回读验证。
