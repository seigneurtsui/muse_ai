# Skill: pm-rapport — 项目调研报告生成

用 pm- 系列技能对任意项目/业务/产品进行系统化调研，输出结构化 Markdown + HTML 报告。

**默认输出**: `~/Downloads/pm-rapport/`
**部署 URL**: `https://pm.allez.cc.cd`

## 环境变量配置

```bash
# ~/.config/opencode/.env
VERCEL_TOKEN=your_vercel_token
```

## 流程

### 1. 理解项目

与用户确定以下信息：
- 项目/业务名称
- 核心业务描述
- 目标市场/客群
- 关注重点（合规/竞争/定价/增长等）

### 2. 并行研究

根据项目类型，启动以下并行 Agent：

| Agent | 对应 pm- 技能 | 研究内容 |
|-------|-------------|---------|
| 宏观环境 | pestle-analysis | 政治/经济/社会/技术/法律/环境 |
| 行业竞争 | porters-five-forces | 五力分析 |
| 市场细分 | market-segments | 细分客群 |
| 市场估算 | market-sizing | TAM/SAM/SOM |
| 客户画像 | ideal-customer-profile | ICP 定义 |
| 竞争格局 | competitor-analysis | 主要竞品深度分析 |
| SWOT | swot-analysis | 优势/劣势/机会/威胁 |
| 价值主张 | value-proposition | 六部分 JTBD |
| 商业模式 | business-model | BMC 9 模块 |
| 定价策略 | pricing-strategy | 定价体系 |

每个 Agent 使用 WebSearch 搜索项目相关的实时信息，结合 pm- 技能框架产出结构化内容。

### 3. 合成 Markdown 文档

将并行 Agent 的产出按以下结构合成为单个 Markdown 文件：

```
01-executive-summary.md      — 执行摘要
02-pestle.md                 — 宏观环境 (PESTLE)
03-five-forces.md            — 五力竞争
04-market-segments.md         — 市场细分
05-market-sizing.md           — 市场估算
06-icp.md                    — 理想客户画像
07-competitor-analysis.md     — 竞争分析
08-swot.md                   — SWOT
09-value-proposition.md       — 价值主张
10-business-model.md          — 商业模式
11-pricing-strategy.md        — 定价策略
12-strategic-recommendations.md — 战略建议
```

**文件命名**: `{YYYYMMDDTHHMMSS}==z--{项目名}-调研报告.md`

保存到 `~/Downloads/pm-rapport/`

### 4. 生成 HTML 页面

```bash
node {baseDir}/scripts/send-report.js {md文件路径}
```

将 Markdown 转换为带 TOC 目录导航的 HTML 页面（water.css 极简排版），保存为同名 `.html` 文件。

### 5. 部署到 Vercel

**默认部署方案（按顺序执行方案1 + 方案2）：**

```bash
# 方案1: 部署最新报告到根路径
bash {baseDir}/scripts/deploy-report.sh

# 方案2: 部署所有报告到子路径 + /toc/ 目录页（依赖方案1已执行）
bash {baseDir}/scripts/deploy-subpath.sh
```

**方案1 —— 部署最新报告到根路径：**
```bash
bash {baseDir}/scripts/deploy-report.sh
```

**方案2 —— 部署所有报告到子路径 + /toc/ 目录页：**
```bash
bash {baseDir}/scripts/deploy-subpath.sh
```

**配置**：

| 配置项 | 值 |
|--------|-----|
| Vercel Project | `shenyang-deploy` |
| 域名 | `pm.allez.cc.cd` |
| Scope | `seigneurtsuis-projects` |

**子路径存档**：
- 每份报告存档到 `/{slug}/` 子路径
- 根路径 `index.html` 指向最新报告
- `/toc/` 目录页提供搜索、排序、分页、CSV 导出

### 6. 汇总报告

```
════ 调研完成 ═══════════════════════
📋 项目: {项目名}
📝 报告: {.md 文件路径}
🌐 HTML: {.html 文件路径}
📊 框架数: {X} 个
🌐 在线: https://pm.allez.cc.cd
📂 目录: https://pm.allez.cc.cd/toc/
```

## 关键约束

- 每个框架必须有数据支撑，不编造
- 使用 WebSearch 获取实时市场数据
- 没有确切信息时注明"待验证"
- MD 是主产出，HTML 是衍生产出
- 输出目录统一为 `~/Downloads/pm-rapport/`

## 可用框架速查

| 框架 | 适用场景 |
|------|---------|
| PESTLE | 评估外部宏观环境风险与机会 |
| 五力 | 分析行业竞争结构和吸引力 |
| 市场细分 | 识别不同客群及其需求 |
| 市场估算 | 量化市场机会（TAM/SAM/SOM）|
| ICP | 定义最高价值客户 |
| 竞争分析 | 了解竞品格局与差异化空间 |
| SWOT | 综合内外部因素制定策略 |
| 价值主张 | 定义产品/服务的核心价值 |
| BMC | 描述商业模式的 9 个要素 |
| 定价策略 | 制定定价体系 |
