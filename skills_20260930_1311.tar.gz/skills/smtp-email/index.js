const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const { marked } = require('marked');

const SKILL_DIR = path.join(__dirname);

function loadConfig() {
  // 首先尝试从 hermes 配置加载
  const hermesConfigPath = '/Users/seigneur/.hermes/config.yaml';
  if (fs.existsSync(hermesConfigPath)) {
    try {
      const content = fs.readFileSync(hermesConfigPath, 'utf8');
      const config = yaml.load(content);
      
      // 从 hermes 配置中获取 SMTP 配置
      if (config.skills?.config?.['smtp-email']) {
        return config.skills.config['smtp-email'];
      }
    } catch (error) {
      console.log('⚠️  读取 hermes 配置失败:', error.message);
    }
  }
  
  // 回退到本地配置文件
  const configPath = path.join(SKILL_DIR, 'config.json');
  if (fs.existsSync(configPath)) {
    return JSON.parse(fs.readFileSync(configPath, 'utf8'));
  }
  
  return null;
}

function loadEnvConfig() {
  // 从 hermes .env 文件加载配置
  const hermesEnvPath = '/Users/seigneur/.hermes/.env';
  if (fs.existsSync(hermesEnvPath)) {
    const content = fs.readFileSync(hermesEnvPath, 'utf8');
    const lines = content.split('\n');
    const config = {};
    
    lines.forEach(line => {
      if (line && !line.startsWith('#') && line.includes('=')) {
        const [key, ...valueParts] = line.split('=');
        const value = valueParts.join('=').trim();
        if (value) {
          config[key.trim()] = value;
        }
      }
    });
    
    return config;
  }
  return {};
}

// ── HTML Beautification ─────────────────────────────────────
function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function buildHtmlEmail(subject, body, style = 'red') {

  const themes = {
    red:    { accent: '#e74c3c', heading: '#2c3e50', bg: '#fef5f5', code_bg: '#f8f9fa' },
    blue:   { accent: '#2980b9', heading: '#2c3e50', bg: '#f0f7ff', code_bg: '#f0f4f8' },
    green:  { accent: '#27ae60', heading: '#1a5e2a', bg: '#f0faf4', code_bg: '#f4f9f6' },
    purple: { accent: '#8e44ad', heading: '#4a235a', bg: '#faf5ff', code_bg: '#f8f4fb' },
  };
  const c = themes[style] || themes.red;
  
  const bodyHtml = escapeHtml(body).replace(/\n/g, '<br>\n');
  const dateStr = new Date().toISOString().slice(0, 10);
  
  return `<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    background: #f5f5f5; padding: 24px; color: #333; line-height: 1.7;
  }
  .wrapper {
    max-width: 640px; margin: 0 auto; background: #fff;
    border-radius: 12px; overflow: hidden;
    box-shadow: 0 2px 12px rgba(0,0,0,0.08);
  }
  .header {
    background: linear-gradient(135deg, ${c.accent}, ${c.heading});
    color: #fff; padding: 28px 32px;
  }
  .header h1 { font-size: 20px; font-weight: 600; letter-spacing: 0.3px; }
  .header .meta { font-size: 13px; opacity: 0.85; margin-top: 6px; }
  .body {
    padding: 28px 32px; background: ${c.bg};
    font-size: 15px; color: #444;
  }
  .body pre, .body code {
    background: ${c.code_bg}; border-radius: 6px; padding: 2px 6px;
    font-family: 'SF Mono', Menlo, monospace; font-size: 13px;
  }
  .body pre { padding: 16px; overflow-x: auto; margin: 12px 0; }
  .footer {
    padding: 16px 32px; border-top: 1px solid #eee;
    font-size: 12px; color: #999; text-align: center;
  }
  .footer a { color: ${c.accent}; text-decoration: none; }
</style></head><body>
<div class="wrapper">
  <div class="header">
    <h1>📬 ${escapeHtml(subject)}</h1>
    <div class="meta">${dateStr} · via OpenCode</div>
  </div>
  <div class="body">${bodyHtml}</div>
  <div class="footer">
    此邮件通过 OpenCode smtp-email skill 发送 · ${dateStr}
  </div>
</div>
</body></html>`;
}

function buildMdEmail(subject, mdContent, style = 'blue') {
  // Support object-style call: buildMdEmail({ title, mdPath, style })
  if (typeof subject === 'object' && subject !== null) {
    const opts = subject;
    if (opts.mdPath) {
      const resolvedPath = opts.mdPath.replace(/^~/, process.env.HOME || '');
      if (fs.existsSync(resolvedPath)) {
        mdContent = fs.readFileSync(resolvedPath, 'utf8');
      }
      subject = opts.title || 'Report';
    } else {
      subject = opts.title || opts.subject || 'Report';
      mdContent = opts.mdContent || opts.body || '';
    }
    style = opts.style || 'blue';
  }
  const themes = {
    red:    { accent: '#e74c3c', heading: '#2c3e50', bg: '#fef5f5', code_bg: '#f8f9fa' },
    blue:   { accent: '#2980b9', heading: '#2c3e50', bg: '#f0f7ff', code_bg: '#f0f4f8' },
    green:  { accent: '#27ae60', heading: '#1a5e2a', bg: '#f0faf4', code_bg: '#f4f9f6' },
    purple: { accent: '#8e44ad', heading: '#4a235a', bg: '#faf5ff', code_bg: '#f8f4fb' },
  };
  const c = themes[style] || themes.red;
  const bodyHtml = marked.parse(mdContent);
  const dateStr = new Date().toISOString().slice(0, 10);

  const htmlStr = `<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background: #f0f2f5; padding: 20px; }
  .container { max-width: 700px; margin: 0 auto; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 12px rgba(0,0,0,0.08); }
  .header { background: linear-gradient(135deg, ${c.accent}, ${c.heading}); color: #fff; padding: 28px 32px; text-align: center; }
  .header h1 { margin: 0; font-size: 22px; }
  .header .subtitle { opacity: 0.85; font-size: 13px; margin-top: 6px; }
  .body { padding: 28px 32px; font-size: 15px; line-height: 1.7; color: #333; }
  .body h2 { font-size: 18px; color: ${c.heading}; margin: 20px 0 10px; border-bottom: 1px solid #eee; padding-bottom: 6px; }
  .body h3 { font-size: 16px; color: ${c.heading}; margin: 16px 0 8px; }
  .body h4 { font-size: 15px; color: ${c.heading}; margin: 12px 0 6px; }
  .body p { margin: 0 0 10px; }
  .body table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 14px; }
  .body th, .body td { border: 1px solid #e0e0e0; padding: 8px 12px; text-align: left; }
  .body th { background: #f5f7fa; font-weight: 600; }
  .body tr:nth-child(even) td { background: #fafafa; }
  .body code { background: ${c.code_bg}; padding: 2px 6px; border-radius: 4px; font-size: 13px; }
  .body pre { background: #f8f9fa; padding: 16px; border-radius: 8px; overflow-x: auto; }
  .body pre code { background: none; padding: 0; }
  .body ul, .body ol { padding-left: 24px; margin: 8px 0; }
  .body li { margin: 4px 0; }
  .body blockquote { border-left: 4px solid ${c.accent}; margin: 12px 0; padding: 8px 16px; background: #f9f9f9; }
  .body hr { border: none; border-top: 1px solid #eee; margin: 20px 0; }
  .footer { padding: 16px 32px; border-top: 1px solid #eee; font-size: 12px; color: #999; text-align: center; }
  .footer a { color: ${c.accent}; text-decoration: none; }
</style></head><body>
<div class="container">
  <div class="header">
    <h1>🏯 ${escapeHtml(subject)}</h1>
    <div class="subtitle">${dateStr} · via OpenCode</div>
  </div>
  <div class="body">${bodyHtml}</div>
  <div class="footer">此邮件由 OpenCode smtp-email skill 自动发送 · ${dateStr}</div>
</div>
</body></html>`;
  return { html: htmlStr };
}

async function sendSmtpEmail({ to, subject, html, text, from, style = 'red' }) {
  const config = loadConfig();
  const envConfig = loadEnvConfig();
  
  // 优先使用环境变量，其次使用配置
  const smtpHost = process.env.SMTP_HOST || envConfig.SMTP_HOST || config?.host;
  const smtpPort = process.env.SMTP_PORT || envConfig.SMTP_PORT || config?.port;
  const smtpUser = process.env.SMTP_USER || envConfig.SMTP_USER || config?.user;
  const smtpPass = process.env.SMTP_PASS || envConfig.SMTP_PASS || config?.pass;
  const smtpFrom = process.env.SMTP_FROM || envConfig.SMTP_FROM || config?.from || smtpUser;
  
  if (!smtpHost || !smtpPort || !smtpUser || !smtpPass) {
    throw new Error('Missing SMTP configuration. Set env vars or config.json');
  }

  const isSecure = smtpPort == 465;
  
  const transporter = nodemailer.createTransport({
    host: smtpHost,
    port: parseInt(smtpPort),
    secure: isSecure,
    auth: {
      user: smtpUser,
      pass: smtpPass
    }
  });

  try {
    await transporter.verify();
  } catch (error) {
    throw new Error(`SMTP connection failed: ${error.message}`);
  }

  const mailOptions = {
    from: from || smtpFrom,
    to: to,
    subject: subject,
    html: html,
  };
  
  if (text) {
    mailOptions.text = text;
  }
  
  try {
    const info = await transporter.sendMail(mailOptions);
    
    return {
      success: true,
      messageId: info.messageId,
      message: 'Email sent successfully'
    };
  } catch (error) {
    throw new Error(`Failed to send email: ${error.message}`);
  }
}

async function verifyConnection() {
  const config = loadConfig();
  const envConfig = loadEnvConfig();
  
  // 优先使用环境变量，其次使用配置
  const smtpHost = process.env.SMTP_HOST || envConfig.SMTP_HOST || config?.host;
  const smtpPort = process.env.SMTP_PORT || envConfig.SMTP_PORT || config?.port;
  const smtpUser = process.env.SMTP_USER || envConfig.SMTP_USER || config?.user;
  const smtpPass = process.env.SMTP_PASS || envConfig.SMTP_PASS || config?.pass;
  
  if (!smtpHost || !smtpPort || !smtpUser || !smtpPass) {
    throw new Error('Missing SMTP configuration');
  }

  const isSecure = smtpPort == 465;
  
  const transporter = nodemailer.createTransport({
    host: smtpHost,
    port: parseInt(smtpPort),
    secure: isSecure,
    auth: {
      user: smtpUser,
      pass: smtpPass
    }
  });

  try {
    await transporter.verify();
    console.log('✓ SMTP connection successful');
    return { success: true, message: 'Connection verified' };
  } catch (error) {
    throw new Error(`SMTP connection failed: ${error.message}`);
  }
}

function showConfig() {
  const config = loadConfig();
  const hasEnv = !!process.env.SMTP_HOST;
  const hasFile = !!config;
  
  console.log(`SMTP Config Status:`);
  console.log(`  config.json: ${hasFile ? '✓' : '✗'}`);
  console.log(`  Environment: ${hasEnv ? '✓' : '✗'}`);
  
  if (hasFile) {
    console.log('\nCurrent config:');
    console.log(`  Host: ${config.host}`);
    console.log(`  Port: ${config.port}`);
    console.log(`  User: ${config.user}`);
    console.log(`  From: ${config.from}`);
  }
}

// CLI
if (require.main === module) {
  const args = process.argv.slice(2);

  if (args.length === 0) {
    console.log('SMTP Email CLI - 发送邮件');
    console.log('\n用法:');
    console.log('  node index.js send --to <email> --subject "<subject>" --html "<html>"');
    console.log('  node index.js verify');
    console.log('  node index.js config');
    console.log('  node index.js setup <host> <port> <user> <pass> <from>');
    process.exit(1);
  }

  const action = args[0];

  const run = async () => {
    try {
      switch (action) {
        case 'send':
          const opts = {};
          for (let i = 1; i < args.length; i++) {
            if (args[i] === '--to' && args[i + 1]) opts.to = args[++i];
            else if (args[i] === '--subject' && args[i + 1]) opts.subject = args[++i];
            else if (args[i] === '--html' && args[i + 1]) opts.html = args[++i];
            else if (args[i] === '--text' && args[i + 1]) opts.text = args[++i];
            else if (args[i] === '--from' && args[i + 1]) opts.from = args[++i];
            else if (args[i] === '--style' && args[i + 1]) opts.style = args[++i];
            else if (args[i] === '--file' && args[i + 1]) {
              const filePath = args[++i];
              if (fs.existsSync(filePath)) {
                const content = fs.readFileSync(filePath, 'utf8');
                if (filePath.endsWith('.md')) {
                  const built = buildMdEmail(opts.subject, content, opts.style || 'red');
                  opts.html = built.html || built;
                } else {
                  opts.text = content;
                }
              } else {
                console.error('错误: 文件不存在:', filePath);
                process.exit(1);
              }
            }
          }
          
          if (!opts.to || !opts.subject || (!opts.html && !opts.text)) {
            console.error('错误: 需要 --to, --subject, --html 或 --text 参数');
            process.exit(1);
          }
          
          // Auto-wrap plain text into beautiful HTML
          if (!opts.html && opts.text) {
            opts.html = buildHtmlEmail(opts.subject, opts.text, opts.style || 'red');
            delete opts.text;
          }
          
          const result = await sendSmtpEmail(opts);
          console.log('✓ ' + result.message);
          break;

        case 'verify':
          await verifyConnection();
          break;

        case 'config':
          showConfig();
          break;

        case 'setup':
          if (args.length < 6) {
            console.error('错误: 需要 <host> <port> <user> <pass> <from>');
            process.exit(1);
          }
          
          const configData = {
            host: args[1],
            port: args[2],
            user: args[3],
            pass: args[4],
            from: args[5]
          };
          
          fs.writeFileSync(path.join(SKILL_DIR, 'config.json'), JSON.stringify(configData, null, 2));
          console.log('✓ Configuration saved to config.json');
          break;

        default:
          console.error('未知操作:', action);
          process.exit(1);
      }
    } catch (error) {
      console.error('错误:', error.message);
      process.exit(1);
    }
  };

  run();
}

module.exports = {
  buildMdEmail,
  sendSmtpEmail,
  verifyConnection,
  showConfig
};
