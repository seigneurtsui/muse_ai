#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

const SKILL_DIR = path.join(__dirname, '..');
const WATER_TEMPLATE_PATH = path.join(SKILL_DIR, 'templates', 'water.css.html');
const EMAIL_TEMPLATE_PATH = path.join(SKILL_DIR, 'templates', 'email-compatible.html');
const SMTP_DIR = path.join(__dirname, '..', '..', 'smtp-email');

// Use marked from smtp-email skill
const { marked } = require(path.join(SMTP_DIR, 'node_modules', 'marked'));

function slugify(text) {
  return text
    .replace(/[`*_~]/g, '')
    .trim()
    .toLowerCase()
    .replace(/[^\w\u4e00-\u9fff]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

marked.use({
  renderer: {
    heading({text, depth}) {
      const id = slugify(text);
      return `<h${depth} id="${id}">${text}</h${depth}>`;
    }
  }
});

marked.setOptions({
  breaks: true,
  gfm: true
});

function loadTemplate(templatePath) {
  return fs.readFileSync(templatePath, 'utf8');
}

function generateToc(mdContent) {
  const lines = mdContent.split('\n');
  const headings = [];

  for (const line of lines) {
    const match = line.match(/^(#{1,4})\s+(.+)$/);
    if (!match) continue;
    const level = match[1].length;
    if (level > 4) continue;
    const text = match[2].replace(/[`*_~]/g, '').trim();
    const anchor = slugify(text);
    headings.push({level, text, anchor});
  }

  function parseFrom(idx, maxLevel) {
    const result = [];
    while (idx < headings.length && headings[idx].level > maxLevel) {
      const h = headings[idx];
      const {children, nextIdx} = parseFrom(idx + 1, h.level);
      result.push({...h, children});
      idx = nextIdx;
    }
    return {children: result, nextIdx: idx};
  }

  function renderNodes(nodes) {
    if (!nodes || nodes.length === 0) return '';
    let html = '<ul>\n';
    for (const node of nodes) {
      html += `<li><a href="#${node.anchor}">${node.text}</a>`;
      if (node.children && node.children.length > 0) {
        html += '\n' + renderNodes(node.children) + '\n';
      }
      html += '</li>\n';
    }
    html += '</ul>';
    return html;
  }

  const {children} = parseFrom(0, 0);
  return renderNodes(children);
}

function convertMdToHtml(mdContent, style) {
  // Remove org-mode metadata and code blocks
  mdContent = mdContent.replace(/```[\s\S]*?```/g, '');
  mdContent = mdContent.replace(/^\+.*$/gm, '');

  let html = marked.parse(mdContent);

  if (style !== 'email') {
    // Wrap tables for responsive horizontal scroll on mobile
    html = html.replace(/<table/g, '<div class="table-wrapper"><table');
    html = html.replace(/<\/table>/g, '</table></div>');
  }

  if (style === 'email') {
    // Add inline styles for email compatibility
    html = html.replace(/<h2>/g, '<h2 style="margin:32px 0 16px;font-family:Georgia,serif;font-size:22px;font-weight:700;color:#4338ca;border-bottom:2px solid #e2e8f0;padding-bottom:8px;">');
    html = html.replace(/<h3>/g, '<h3 style="margin:24px 0 12px;font-size:18px;font-weight:600;color:#1e293b;padding-left:12px;border-left:3px solid #818cf8;">');
    html = html.replace(/<h4>/g, '<h4 style="margin:16px 0 8px;font-size:16px;font-weight:600;color:#475569;">');
    html = html.replace(/<p>/g, '<p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.8;">');
    html = html.replace(/<strong>/g, '<strong style="color:#1e293b;font-weight:600;">');
    html = html.replace(/<em>/g, '<em style="color:#64748b;font-style:italic;">');
    html = html.replace(/<ul>/g, '<ul style="padding-left:24px;margin:12px 0;">');
    html = html.replace(/<ol>/g, '<ol style="padding-left:24px;margin:12px 0;">');
    html = html.replace(/<li>/g, '<li style="margin:8px 0;color:#475569;line-height:1.7;">');
    html = html.replace(/<blockquote>/g, '<blockquote style="border-left:4px solid #f59e0b;margin:20px 0;padding:16px 20px;background:#fffbeb;border-radius:0 8px 8px 0;font-style:italic;color:#475569;">');
    html = html.replace(/<table>/g, '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:20px 0;border-collapse:collapse;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.06);">');
    html = html.replace(/<thead>/g, '<thead style="background:linear-gradient(135deg,#6366f1,#4338ca);">');
    html = html.replace(/<th>/g, '<th style="padding:12px 16px;color:#ffffff;font-weight:600;font-size:13px;text-align:left;text-transform:uppercase;letter-spacing:0.5px;">');
    html = html.replace(/<td>/g, '<td style="padding:12px 16px;color:#475569;font-size:14px;border-bottom:1px solid #e2e8f0;">');
    html = html.replace(/<tr>/g, '<tr style="border-bottom:1px solid #e2e8f0;">');
    html = html.replace(/<code>/g, '<code style="background:#eef2ff;padding:2px 8px;border-radius:4px;font-family:monospace;font-size:13px;color:#4338ca;">');
    html = html.replace(/<pre><code>/g, '<pre style="background:#1e1b4b;color:#e2e8f0;padding:16px;border-radius:8px;overflow-x:auto;margin:16px 0;font-family:monospace;font-size:13px;"><code style="background:none;padding:0;color:inherit;">');
    html = html.replace(/<\/code><\/pre>/g, '</code></pre>');
    html = html.replace(/<a /g, '<a style="color:#6366f1;text-decoration:none;font-weight:500;" ');
    html = html.replace(/<hr>/g, '<hr style="border:none;height:2px;background:linear-gradient(90deg,transparent,#e2e8f0,transparent);margin:32px 0;">');
  }

  return html;
}

function extractTitle(mdContent, filePath) {
  // Try to get title from #+title: first
  const titleMatch = mdContent.match(/^#\+title:\s*(.+)/m);
  if (titleMatch) {
    return titleMatch[1].trim();
  }

  // Try to extract city name from filename
  if (filePath) {
    const filename = path.basename(filePath, '.md');
    // Try to get city name before "旅行研究" if present
    const cityMatch = filename.match(/([\u4e00-\u9fff]+?)旅行研究/);
    if (cityMatch) {
      return cityMatch[1] + '旅行研究';
    }
    // Fallback: extract any Chinese characters
    const chineseMatch = filename.match(/[\u4e00-\u9fff]+/);
    if (chineseMatch) {
      return chineseMatch[0] + '旅行研究';
    }
  }

  // Try to extract from content
  const cityMatch = mdContent.match(/城市[：:]\s*([^\s\n]+)/m);
  if (cityMatch) {
    return cityMatch[1].trim() + '旅行研究';
  }

  return '旅行研究';
}

function extractTags(mdContent, style) {
  // Extract tags from filetags line (single line only)
  const lines = mdContent.split('\n');
  let tags = ['旅行研究', '深度分析', '文化探索'];

  for (const line of lines) {
    if (line.includes('#+filetags:')) {
      // Extract just the tags part: :tag1:tag2:tag3:
      const match = line.match(/#\+filetags:\s*(:[^:]+(?::[^:]+)*:)/);
      if (match) {
        const tagsStr = match[1];
        // Split by : and filter empty strings
        const rawTags = tagsStr.split(':').filter(t => t.trim());
        if (rawTags.length > 0) {
          tags = rawTags.map(t => t.trim());
        }
      }
      break;
    }
  }

  if (style === 'email') {
    return tags.map(t =>
      `<span style="display:inline-block;background:rgba(255,255,255,0.15);backdrop-filter:blur(10px);padding:6px 16px;border-radius:20px;font-size:13px;font-weight:500;border:1px solid rgba(255,255,255,0.25);margin:4px;color:#ffffff;">${t}</span>`
    ).join('');
  }

  return tags.map(t => `<span class="tag">${t}</span>`).join('');
}

function extractSubtitle(mdContent) {
  // Remove code blocks first
  const cleanContent = mdContent.replace(/```[\s\S]*?```/g, '');

  // Try to extract subtitle from content
  const subtitleMatch = cleanContent.match(/性格标签[：:]\s*(.+)/);
  if (subtitleMatch) {
    return subtitleMatch[1].trim();
  }
  return '深度研究 · 多维分析 · 文化探索';
}

function getCityEmoji(mdContent, filePath) {
  const title = extractTitle(mdContent, filePath);
  if (title.includes('成都')) return '🐼';
  if (title.includes('西安')) return '🏛️';
  if (title.includes('北京')) return '🏯';
  if (title.includes('上海')) return '🌃';
  if (title.includes('深圳')) return '🏙️';
  if (title.includes('广州')) return '🌸';
  if (title.includes('杭州')) return '🍃';
  if (title.includes('南京')) return '📜';
  if (title.includes('重庆')) return '🌶️';
  if (title.includes('武汉')) return '🌉';
  return '🗺️';
}

function buildHtml(mdContent, filePath, style) {
  const isEmailStyle = style === 'email';
  const templatePath = isEmailStyle ? EMAIL_TEMPLATE_PATH : WATER_TEMPLATE_PATH;
  const template = loadTemplate(templatePath);
  const contentHtml = convertMdToHtml(mdContent, style);
  const title = extractTitle(mdContent, filePath);
  const tags = extractTags(mdContent, style);
  const subtitle = extractSubtitle(mdContent);
  const emoji = getCityEmoji(mdContent, filePath);
  const date = new Date().toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  let html = template
    .replace(/\{\{TITLE\}\}/g, title)
    .replace(/\{\{EMOJI\}\}/g, emoji)
    .replace(/\{\{SUBTITLE\}\}/g, subtitle)
    .replace(/\{\{TAGS\}\}/g, tags)
    .replace(/\{\{CONTENT\}\}/g, contentHtml)
    .replace(/\{\{DATE\}\}/g, date);

  if (!isEmailStyle) {
    // Generate TOC from headings
    const tocHtml = generateToc(mdContent);
    html = html.replace(/\{\{TOC\}\}/g, tocHtml);
  }

  return html;
}

async function sendEmail(to, subject, html) {
  const { sendSmtpEmail } = require(path.join(SMTP_DIR, 'index.js'));

  return sendSmtpEmail({
    to,
    subject,
    html,
    style: 'blue'
  });
}

// CLI
if (require.main === module) {
  const args = process.argv.slice(2);
  let style = 'default';
  let mdPath = '';
  let to = '';

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--email') {
      style = 'email';
    } else if (!mdPath) {
      mdPath = args[i].replace(/^~/, process.env.HOME || '');
    } else if (!to) {
      to = args[i];
    }
  }

  if (!mdPath || !to) {
    console.log('用法: node send-report.js [--email] <md文件路径> <收件人邮箱>');
    console.log('');
    console.log('  --email    使用邮件兼容模板（默认使用 water.css 页面模板）');
    console.log('  示例:');
    console.log('    node send-report.js ~/Downloads/rainman-travel/成都旅行研究.md gc40800@gmail.com');
    console.log('    node send-report.js --email ~/Downloads/rainman-travel/成都旅行研究.md gc40800@gmail.com');
    process.exit(1);
  }

  if (!fs.existsSync(mdPath)) {
    console.error('错误: 文件不存在:', mdPath);
    process.exit(1);
  }

  const mdContent = fs.readFileSync(mdPath, 'utf8');
  const title = extractTitle(mdContent, mdPath);

  // Save HTML page
  const html = buildHtml(mdContent, mdPath, style);
  const htmlSuffix = style === 'email' ? '-email' : '';
  const htmlPath = mdPath.replace(/\.md$/, `${htmlSuffix}.html`);
  fs.writeFileSync(htmlPath, html);
  console.log(`✅ HTML: ${htmlPath}`);

  // Send email (always uses email template)
  const emoji = getCityEmoji(mdContent, mdPath);
  const subject = `${emoji} ${title}`;
  const emailHtml = buildHtml(mdContent, mdPath, 'email');

  console.log(`📧 发送邮件...`);
  console.log(`   收件人: ${to}`);
  console.log(`   主题: ${subject}`);

  sendEmail(to, subject, emailHtml)
    .then(result => {
      console.log('✅ 邮件发送成功!');
      console.log(`   Message ID: ${result.messageId}`);
    })
    .catch(error => {
      console.error('❌ 邮件发送失败:', error.message);
      process.exit(1);
    });
}

module.exports = { buildHtml, sendEmail };
