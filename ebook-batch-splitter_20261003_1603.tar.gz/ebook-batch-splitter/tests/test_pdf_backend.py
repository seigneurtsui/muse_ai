"""Synthetic PDFs only. Mock OCR tests are separate from the real English smoke."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(ROOT / "scripts"))
import pdf_backend as backend
from models import SplitError

try:
    import pymupdf as fitz
except ImportError:
    try:
        import fitz
    except ImportError:
        fitz = None

LONG_TEXT = "This synthetic page contains enough English text for the native extraction threshold."
RENDER = {"width": 100, "height": 100, "dpi": 150.0}


class ImportAndValidationTests(unittest.TestCase):
    def test_import_is_lazy_without_pymupdf_or_tesseract(self):
        # A fresh interpreter avoids the test suite's deliberate fixture import.
        code = ("import sys; import pdf_backend; "
                "assert 'pymupdf' not in sys.modules; assert 'fitz' not in sys.modules")
        completed = subprocess.run([sys.executable, "-c", code], cwd=ROOT / "scripts",
                                   capture_output=True, text=True, timeout=20)
        self.assertEqual(completed.returncode, 0, completed.stderr)

    def test_missing_dependency_is_actionable_and_never_installed(self):
        with mock.patch.object(backend.importlib, "import_module", side_effect=ImportError), \
                mock.patch.object(backend.subprocess, "run") as process:
            with self.assertRaisesRegex(SplitError, "locally installed PyMuPDF"):
                backend._load_fitz()
            process.assert_not_called()

    def test_invalid_options_fail_before_dependency_or_file_access(self):
        cases = [
            {"ocr": "yes"}, {"ocr": None}, {"ocr_language": "../eng"},
            {"ocr_language": "eng;touch /tmp/no"}, {"ocr_language": "-l"},
            {"ocr_language": "eng+"}, {"ocr_language": ""}, {"ocr_language": None},
            {"dpi": 0}, {"dpi": 601}, {"dpi": True}, {"dpi": 150.5},
            {"min_page_chars": 0}, {"min_page_chars": -1}, {"min_page_chars": True},
            {"timeout": 0}, {"timeout": float("nan")}, {"timeout": float("inf")},
            {"timeout": 3601}, {"timeout": True},
        ]
        with mock.patch.object(backend, "_load_fitz") as dependency:
            for settings in cases:
                with self.subTest(settings=settings), self.assertRaises(SplitError):
                    backend.extract_pdf(Path("does-not-exist.pdf"), cache_dir=Path("unused"), **settings)
            dependency.assert_not_called()


@unittest.skipUnless(fitz is not None and hasattr(fitz, "VersionBind"), "locally installed PyMuPDF required")
class PDFBackendTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="synthetic-pdf-backend-")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name).resolve()
        self.cache = self.root / "cache"
        self.path = self.root / "synthetic.pdf"

    @staticmethod
    def scan_image():
        with fitz.open() as document:
            page = document.new_page(width=595, height=300)
            page.insert_text((35, 60), "SYNTHETIC ENGLISH SCANNED PAGE", fontsize=20)
            page.insert_text((35, 100), "The quick brown fox jumps over the lazy dog.", fontsize=17)
            page.insert_text((35, 140), "Local optical character recognition smoke test.", fontsize=17)
            return page.get_pixmap(matrix=fitz.Matrix(2, 2)).tobytes("png")

    def make_pdf(self, texts, *, images=(), toc=None, encrypted=False, size=(595, 842)):
        scan = self.scan_image() if images else None
        with fitz.open() as document:
            for index, text in enumerate(texts):
                page = document.new_page(width=size[0], height=size[1])
                if index in images:
                    page.insert_image(page.rect, stream=scan)
                if text:
                    page.insert_text((35, 50), text, fontsize=10)
            if toc:
                document.set_toc(toc)
            options = ({"encryption": fitz.PDF_ENCRYPT_AES_256,
                        "owner_pw": "synthetic-owner", "user_pw": "" if encrypted == "owner-only" else "synthetic-user"} if encrypted else {})
            document.save(self.path, **options)
        return self.path

    def extract(self, **settings):
        return backend.extract_pdf(self.path, cache_dir=self.cache, **settings)

    def page_files(self):
        return sorted(self.cache.glob("pdf-*/page-*.json"))

    def test_preface_all_levels_same_page_no_duplicate_pages_and_bounded_calls(self):
        self.make_pdf(["PREFACE " + LONG_TEXT, "BOOK_ONE " + LONG_TEXT, "BOOK_TWO " + LONG_TEXT],
                      toc=[[1, "First volume", 2], [2, "First chapter", 2],
                           [3, "Subsection", 2], [1, "Second volume", 3]])
        with fitz.open(self.path) as document:
            expected_pages = [page.get_text("text") for page in document]
        original_text = fitz.Page.get_text
        original_textpage = fitz.Page.get_textpage
        with mock.patch.object(fitz, "open", wraps=fitz.open) as opening, \
                mock.patch.object(fitz.Page, "get_text", autospec=True, side_effect=original_text) as text_calls, \
                mock.patch.object(fitz.Page, "get_textpage", autospec=True, side_effect=original_textpage) as parses:
            result = self.extract()
        self.assertEqual(opening.call_count, 1)
        self.assertEqual(text_calls.call_count, 3)
        self.assertEqual(parses.call_count, 3)
        self.assertEqual(result.text, backend.PAGE_SEPARATOR.join(expected_pages))
        self.assertEqual(result.text.count("PREFACE"), 1)
        self.assertEqual(result.text.count("BOOK_ONE"), 1)
        self.assertEqual([entry.level for entry in result.toc], [1, 2, 3, 1])
        self.assertEqual([entry.children for entry in result.toc], [1, 1, 0, 0])
        self.assertEqual(result.toc[0].position, len(expected_pages[0]) + len(backend.PAGE_SEPARATOR))
        self.assertEqual(result.toc[0].position, result.toc[2].position)
        self.assertEqual(result.toc[-1].locator["page"], 3)
        self.assertIn("BOOK_TWO", result.text[result.toc[-1].position:])
        self.assertTrue(any("share page 2" in warning for warning in result.warnings))
        self.assertFalse(result.metadata["incomplete"])
        self.assertEqual(result.method, "pdf_toc")

    def test_out_of_order_and_invalid_bookmark_ranges_are_reported(self):
        self.make_pdf([LONG_TEXT, LONG_TEXT, LONG_TEXT])
        # A real synthetic PDF with deliberately malformed outline metadata injected
        # at the parser boundary; PyMuPDF's writer rejects these invalid ranges.
        raw = [[1, "Later", 3], [2, "Nested earlier", 2], [1, "First", 1],
               [1, "External", -1], [1, "Zero", 0], [1, "Too far", 4],
               [0, "Bad level", 1], [1, "", 1], [True, "Boolean level", 1], [1]]
        with mock.patch.object(fitz.Document, "get_toc", return_value=raw):
            result = self.extract()
        self.assertEqual([item.locator["page"] for item in result.toc], [1, 2, 3])
        self.assertEqual(result.toc[-1].children, 1)
        self.assertTrue(any("out-of-order" in warning for warning in result.warnings))
        self.assertTrue(any("page range" in warning for warning in result.warnings))
        self.assertEqual(result.metadata["page_count"], 3)

    def test_invalid_bookmark_parent_does_not_reparent_children_to_previous_volume(self):
        self.make_pdf([LONG_TEXT, LONG_TEXT])
        raw = [[1, "Valid volume", 1], [1, "Invalid volume", -1], [2, "Orphan chapter", 2]]
        with mock.patch.object(fitz.Document, "get_toc", return_value=raw):
            result = self.extract()
        self.assertEqual([item.children for item in result.toc], [0, 0])
        self.assertEqual([item.level for item in result.toc], [1, 2])

    def test_bookmark_read_error_preserves_full_text(self):
        self.make_pdf(["PREFACE " + LONG_TEXT, "FINAL " + LONG_TEXT])
        with mock.patch.object(fitz.Document, "get_toc", side_effect=RuntimeError("private diagnostic")):
            result = self.extract()
        self.assertEqual(result.toc, [])
        self.assertEqual(result.method, "pdf_text")
        self.assertIn("PREFACE", result.text)
        self.assertIn("FINAL", result.text)
        self.assertTrue(any("bookmarks could not be read" in warning for warning in result.warnings))
        self.assertNotIn("private diagnostic", str(result.warnings))

    def test_textless_image_inside_bookmarked_volume_is_incomplete_with_ocr_off(self):
        self.make_pdf(["PREFACE " + LONG_TEXT, None, "AFTER " + LONG_TEXT], images=(1,),
                      toc=[[1, "Volume", 1], [2, "Scanned chapter", 2]])
        with mock.patch.object(backend, "_run_ocr") as ocr:
            result = self.extract()
        ocr.assert_not_called()
        self.assertTrue(result.metadata["incomplete"])
        self.assertEqual(result.metadata["textless_image_pages"], 1)
        self.assertEqual(result.metadata["image_pages"], 1)
        self.assertEqual(result.metadata["incomplete_pages"], 1)
        self.assertEqual(result.metadata["pages"][1]["ocr_status"], "off")
        self.assertTrue(any("incomplete" in warning for warning in result.warnings))
        self.assertIn("AFTER", result.text)

    def test_blank_and_sparse_text_pages_do_not_automatically_fail(self):
        self.make_pdf([LONG_TEXT, None, "iv"])
        result = self.extract()
        self.assertFalse(result.metadata["incomplete"])
        self.assertEqual(result.metadata["blank_pages"], 1)
        self.assertEqual(result.metadata["sparse_pages"], 2)
        self.assertEqual(len(result.text.split(backend.PAGE_SEPARATOR)), 3)
        self.assertIn("iv", result.text)

    def test_auto_ocr_only_sparse_image_or_short_text_pages(self):
        self.make_pdf([LONG_TEXT, "iv", None, None], images=(2,))
        with mock.patch.object(backend, "_run_ocr", return_value=(LONG_TEXT, RENDER)) as ocr:
            result = self.extract(ocr="auto")
        self.assertEqual(ocr.call_count, 2)
        self.assertEqual([page["ocr_status"] for page in result.metadata["pages"]],
                         ["not_needed", "success", "success", "not_needed"])
        self.assertEqual(result.metadata["ocr_attempted_pages"], 2)
        self.assertEqual(result.metadata["ocr_success_pages"], 2)
        self.assertFalse(result.metadata["incomplete"])
        self.assertEqual(result.metadata["pages"][0]["source"], "native")
        self.assertEqual(result.metadata["pages"][3]["ocr_status"], "not_needed")

    def test_force_ocr_every_page_even_blank_and_cached_success_skipped(self):
        self.make_pdf([LONG_TEXT, None, "iv"])
        with mock.patch.object(backend, "_run_ocr", return_value=(LONG_TEXT, RENDER)) as ocr:
            first = self.extract(ocr="force")
            second = self.extract(ocr="force")
        self.assertEqual(ocr.call_count, 3)
        self.assertEqual(first.metadata["ocr_attempted_pages"], 3)
        self.assertEqual(second.metadata["ocr_attempted_pages"], 0)
        self.assertEqual(second.metadata["ocr_cache_hits"], 3)
        self.assertEqual(second.metadata["cache_hits"], 3)
        self.assertEqual(second.metadata["native_extraction_calls"], 0)
        self.assertEqual(first.text, second.text)

    def test_success_cache_and_failed_sparse_pages_resume_independently(self):
        self.make_pdf([None, "iv", None], images=(0, 1, 2))
        outcomes = [(LONG_TEXT, RENDER), backend._OCRError("ocr_timeout"), ("tiny", RENDER)]
        with mock.patch.object(backend, "_run_ocr", side_effect=outcomes):
            first = self.extract(ocr="auto")
        self.assertTrue(first.metadata["incomplete"])
        self.assertEqual(first.metadata["ocr_failed_pages"], 1)
        self.assertEqual(first.metadata["ocr_sparse_pages"], 1)
        self.assertIn("iv", first.text)
        self.assertIn("tiny", first.text)
        first_page = self.page_files()[0]
        saved = first_page.read_bytes()
        with mock.patch.object(backend, "_run_ocr", return_value=(LONG_TEXT, RENDER)) as ocr:
            second = self.extract(ocr="auto")
        self.assertEqual(ocr.call_count, 2)
        self.assertEqual([page["ocr_cache_hit"] for page in second.metadata["pages"]], [True, False, False])
        self.assertEqual(second.metadata["ocr_cache_hits"], 1)
        self.assertEqual(second.metadata["cache_hits"], 3)
        self.assertFalse(second.metadata["incomplete"])
        self.assertEqual(second.metadata["ocr_success_pages"], 3)
        self.assertEqual(first_page.read_bytes(), saved)

    def test_interruption_retains_finished_ocr_and_current_native_page(self):
        self.make_pdf([None, None, None], images=(0, 1, 2))
        with mock.patch.object(backend, "_run_ocr", side_effect=[(LONG_TEXT, RENDER), KeyboardInterrupt()]):
            with self.assertRaises(KeyboardInterrupt):
                self.extract(ocr="auto")
        self.assertEqual(len(self.page_files()), 2)
        with mock.patch.object(backend, "_run_ocr", return_value=(LONG_TEXT, RENDER)) as ocr:
            result = self.extract(ocr="auto")
        self.assertEqual(ocr.call_count, 2)
        self.assertEqual(result.metadata["cache_hits"], 2)
        self.assertEqual(result.metadata["native_extraction_calls"], 1)
        self.assertEqual(result.metadata["ocr_cache_hits"], 1)
        self.assertFalse(result.metadata["incomplete"])

    def test_corrupt_and_wrong_schema_cache_reextract_only_invalid_page(self):
        self.make_pdf([LONG_TEXT, LONG_TEXT])
        self.extract()
        first, second = self.page_files()
        first.write_text("{broken", encoding="utf-8")
        result = self.extract()
        self.assertEqual(result.metadata["native_extraction_calls"], 1)
        self.assertEqual(result.metadata["cache_hits"], 1)
        self.assertTrue(any("invalid PDF cache" in warning for warning in result.warnings))
        record = json.loads(second.read_text())
        record["native"]["chars"] += 1
        second.write_text(json.dumps(record), encoding="utf-8")
        result = self.extract()
        self.assertEqual(result.metadata["native_extraction_calls"], 1)
        record = json.loads(second.read_text())
        record["page"] = 999
        second.write_text(json.dumps(record), encoding="utf-8")
        self.assertEqual(self.extract().metadata["native_extraction_calls"], 1)

    def test_inconsistent_success_status_cannot_skip_sparse_ocr(self):
        self.make_pdf([None], images=(0,))
        with mock.patch.object(backend, "_run_ocr", return_value=(LONG_TEXT, RENDER)):
            self.extract(ocr="auto")
        file = self.page_files()[0]
        record = json.loads(file.read_text())
        record["ocr"].update(text="tiny", chars=4, status="success")
        file.write_text(json.dumps(record), encoding="utf-8")
        with mock.patch.object(backend, "_run_ocr", return_value=(LONG_TEXT, RENDER)) as ocr:
            result = self.extract(ocr="auto")
        self.assertEqual(ocr.call_count, 1)
        self.assertEqual(result.metadata["cache_hits"], 1)
        self.assertEqual(result.metadata["ocr_cache_hits"], 0)

    def test_cache_invalidates_on_content_not_just_size_mtime(self):
        self.make_pdf(["A" * 50])
        original_stat = self.path.stat()
        first = self.extract()
        self.path.unlink()
        self.make_pdf(["B" * 50])
        self.assertEqual(self.path.stat().st_size, original_stat.st_size)
        os.utime(self.path, ns=(original_stat.st_atime_ns, original_stat.st_mtime_ns))
        second = self.extract()
        self.assertNotEqual(first.metadata["source_sha256"], second.metadata["source_sha256"])
        self.assertNotEqual(first.metadata["cache_key"], second.metadata["cache_key"])
        self.assertEqual(second.metadata["cache_hits"], 0)
        self.assertIn("B" * 50, second.text)

    def test_cache_invalidates_for_all_settings_and_extractor_version(self):
        self.make_pdf([LONG_TEXT])
        variants = [{}, {"ocr": "auto"}, {"ocr": "force"}, {"ocr_language": "chi_sim+eng"},
                    {"dpi": 160}, {"min_page_chars": 41}, {"timeout": 121}]
        keys = []
        with mock.patch.object(backend, "_run_ocr", return_value=(LONG_TEXT, RENDER)):
            for settings in variants:
                result = self.extract(**settings)
                self.assertEqual(result.metadata["cache_hits"], 0)
                keys.append(result.metadata["cache_key"])
        with mock.patch.object(backend, "EXTRACTOR_VERSION", "synthetic-next-version"):
            updated = self.extract()
        keys.append(updated.metadata["cache_key"])
        self.assertEqual(len(keys), len(set(keys)))
        self.assertEqual(len(list(self.cache.glob("pdf-*"))), len(keys))

    def test_private_cache_modes_and_no_temporary_files_remain(self):
        self.make_pdf([LONG_TEXT])
        self.cache.mkdir(mode=0o755)
        self.extract()
        self.assertEqual(stat.S_IMODE(self.cache.stat().st_mode), 0o700)
        self.assertEqual(stat.S_IMODE(self.page_files()[0].parent.stat().st_mode), 0o700)
        self.assertEqual(stat.S_IMODE(self.page_files()[0].stat().st_mode), 0o600)
        self.assertEqual(list(self.cache.rglob("*.tmp")), [])

    def test_cache_root_symlink_rejected_without_touching_target(self):
        self.make_pdf([LONG_TEXT])
        outside = self.root / "outside"
        outside.mkdir()
        self.cache.symlink_to(outside, target_is_directory=True)
        with self.assertRaisesRegex(SplitError, "symlinks"):
            self.extract()
        self.assertEqual(list(outside.iterdir()), [])

    def test_namespace_symlink_rejected(self):
        self.make_pdf([LONG_TEXT])
        self.extract()
        namespace = self.page_files()[0].parent
        shutil.rmtree(namespace)
        outside = self.root / "outside"
        outside.mkdir()
        namespace.symlink_to(outside, target_is_directory=True)
        with self.assertRaisesRegex(SplitError, "symlinks"):
            self.extract()
        self.assertEqual(list(outside.iterdir()), [])

    def test_page_symlink_and_hard_link_are_rejected(self):
        self.make_pdf([LONG_TEXT])
        self.extract()
        page = self.page_files()[0]
        outside = self.root / "outside.json"
        outside.write_text("PRIVATE SENTINEL", encoding="utf-8")
        page.unlink()
        page.symlink_to(outside)
        with self.assertRaisesRegex(SplitError, "Unsafe PDF page cache"):
            self.extract()
        self.assertEqual(outside.read_text(), "PRIVATE SENTINEL")
        page.unlink()
        os.link(outside, page)
        with self.assertRaisesRegex(SplitError, "Unsafe PDF page cache"):
            self.extract()
        self.assertEqual(outside.read_text(), "PRIVATE SENTINEL")

    def test_atomic_write_failure_keeps_previous_page_record(self):
        self.make_pdf([None], images=(0,))
        with mock.patch.object(backend, "_run_ocr", return_value=("tiny", RENDER)):
            self.extract(ocr="auto")
        page = self.page_files()[0]
        previous = page.read_bytes()
        with mock.patch.object(backend, "_run_ocr", return_value=(LONG_TEXT, RENDER)), \
                mock.patch.object(backend.os, "replace", side_effect=OSError("synthetic interruption")):
            with self.assertRaisesRegex(SplitError, "atomically"):
                self.extract(ocr="auto")
        self.assertEqual(page.read_bytes(), previous)
        self.assertEqual(list(self.cache.rglob("*.tmp")), [])
        with mock.patch.object(backend, "_run_ocr", return_value=(LONG_TEXT, RENDER)):
            self.assertFalse(self.extract(ocr="auto").metadata["incomplete"])

    def test_encrypted_pdf_rejected_without_password_attempt_or_cache(self):
        self.make_pdf([LONG_TEXT], encrypted=True)
        with mock.patch.object(fitz.Document, "authenticate") as authentication:
            with self.assertRaisesRegex(SplitError, "Encrypted/authentication-required"):
                self.extract()
        authentication.assert_not_called()
        self.assertFalse(self.cache.exists())

    def test_owner_only_encryption_is_also_rejected_without_blank_password_tricks(self):
        self.make_pdf([LONG_TEXT], encrypted="owner-only")
        with mock.patch.object(fitz.Document, "authenticate") as authentication:
            with self.assertRaisesRegex(SplitError, "Encrypted/authentication-required"):
                self.extract()
        authentication.assert_not_called()
        self.assertFalse(self.cache.exists())

    def test_damaged_pdf_and_missing_file_are_clear_failures(self):
        self.path.write_bytes(b"%PDF-1.7\nnot a real document")
        with self.assertRaisesRegex(SplitError, "Cannot open PDF"):
            self.extract()
        self.path.unlink()
        with self.assertRaisesRegex(SplitError, "Cannot read the PDF source"):
            self.extract()

    def test_missing_tesseract_is_partial_not_silent_success(self):
        self.make_pdf([None], images=(0,))
        with mock.patch.object(backend.shutil, "which", return_value=None), \
                mock.patch.object(backend.subprocess, "run") as process:
            result = self.extract(ocr="auto")
        process.assert_not_called()
        self.assertTrue(result.metadata["incomplete"])
        self.assertEqual(result.metadata["ocr_failed_pages"], 1)
        self.assertIn("tesseract_missing", result.metadata["pages"][0]["errors"])

    def test_ocr_timeout_is_bounded_and_native_fallback_retained(self):
        self.make_pdf(["iv"], images=(0,))
        with mock.patch.object(backend.shutil, "which", return_value="/local/tesseract"), \
                mock.patch.object(backend.subprocess, "run", side_effect=subprocess.TimeoutExpired("tesseract", 1)) as process:
            result = self.extract(ocr="auto", timeout=1)
        self.assertEqual(process.call_count, 1)
        self.assertEqual(process.call_args.kwargs["timeout"], 1)
        self.assertIn("iv", result.text)
        self.assertTrue(result.metadata["incomplete"])
        self.assertIn("ocr_timeout", result.metadata["pages"][0]["errors"])

    def test_render_failure_keeps_native_text_and_partial_metadata(self):
        self.make_pdf(["iv"], images=(0,))
        with mock.patch.object(backend.shutil, "which", return_value="/local/tesseract"), \
                mock.patch.object(fitz.Page, "get_pixmap", side_effect=RuntimeError("private diagnostic")), \
                mock.patch.object(backend.subprocess, "run") as process:
            result = self.extract(ocr="auto")
        process.assert_not_called()
        self.assertIn("iv", result.text)
        self.assertTrue(result.metadata["incomplete"])
        self.assertIn("render_failed", result.metadata["pages"][0]["errors"])
        self.assertNotIn("private diagnostic", str(result.warnings))

    def test_subprocess_failure_does_not_leak_stderr(self):
        self.make_pdf([None], images=(0,))
        failure = subprocess.CompletedProcess([], 1, b"", b"PRIVATE_PAGE_CONTENT")
        with mock.patch.object(backend.shutil, "which", return_value="/local/tesseract"), \
                mock.patch.object(backend.subprocess, "run", return_value=failure):
            result = self.extract(ocr="auto")
        self.assertTrue(result.metadata["incomplete"])
        self.assertNotIn("PRIVATE_PAGE_CONTENT", str(result.warnings) + str(result.metadata))
        self.assertNotIn(b"PRIVATE_PAGE_CONTENT", self.page_files()[0].read_bytes())

    def test_large_page_render_is_pixel_and_dimension_bounded(self):
        self.make_pdf([None], size=(30000, 40000))
        completed = subprocess.CompletedProcess([], 0, LONG_TEXT.encode(), b"")
        with mock.patch.object(backend.shutil, "which", return_value="/local/tesseract"), \
                mock.patch.object(backend.subprocess, "run", return_value=completed) as process:
            result = self.extract(ocr="force", dpi=600, timeout=3)
        self.assertEqual(process.call_count, 1)
        rendering = result.metadata["pages"][0]["render"]
        self.assertLessEqual(rendering["width"] * rendering["height"], backend.MAX_RENDER_PIXELS)
        self.assertLessEqual(max(rendering["width"], rendering["height"]), backend.MAX_RENDER_SIDE)
        self.assertLess(rendering["dpi"], 600)
        self.assertEqual(process.call_args.args[0][1:3], ["stdin", "stdout"])
        self.assertTrue(process.call_args.kwargs["input"].startswith(b"\x89PNG\r\n\x1a\n"))
        self.assertNotIn("shell", process.call_args.kwargs)
        self.assertEqual(process.call_args.kwargs["timeout"], 3)

    def test_native_page_error_retained_and_retry_does_not_duplicate_other_pages(self):
        self.make_pdf(["FIRST " + LONG_TEXT, "SECOND " + LONG_TEXT])
        original = backend._extract_native

        def fail_second(page, library):
            if page.number == 1:
                raise RuntimeError("PRIVATE_PAGE_CONTENT")
            return original(page, library)

        with mock.patch.object(backend, "_extract_native", side_effect=fail_second):
            first = self.extract()
        self.assertTrue(first.metadata["incomplete"])
        self.assertEqual(first.metadata["text_error_pages"], 1)
        self.assertNotIn("PRIVATE_PAGE_CONTENT", str(first.warnings) + str(first.metadata))
        second = self.extract()
        self.assertEqual(second.metadata["cache_hits"], 1)
        self.assertEqual(second.metadata["native_extraction_calls"], 1)
        self.assertFalse(second.metadata["incomplete"])
        self.assertEqual(second.text.count("FIRST"), 1)
        self.assertEqual(second.text.count("SECOND"), 1)

    def test_source_change_during_page_extraction_never_commits_changed_page(self):
        self.make_pdf([LONG_TEXT])
        original = backend._extract_native

        def mutate_source(page, library):
            result = original(page, library)
            with self.path.open("ab") as output:
                output.write(b"\n% changed during synthetic extraction\n")
            return result

        with mock.patch.object(backend, "_extract_native", side_effect=mutate_source):
            with self.assertRaisesRegex(SplitError, "source changed"):
                self.extract()
        self.assertEqual(self.page_files(), [])

    @unittest.skipUnless(shutil.which("tesseract"), "real English OCR smoke: local Tesseract not installed")
    def test_real_english_tesseract_smoke_on_synthetic_image(self):
        """REAL OCR, not mocked. Only an in-memory generated English page."""
        executable = shutil.which("tesseract")
        listed = subprocess.run([executable, "--list-langs"], capture_output=True, text=True, timeout=15)
        if listed.returncode or "eng" not in {line.strip() for line in listed.stdout.splitlines()}:
            self.skipTest("real English OCR smoke: installed eng language data unavailable")
        self.make_pdf([None], images=(0,), size=(595, 300))
        result = self.extract(ocr="auto", ocr_language="eng", dpi=150, timeout=30)
        self.assertFalse(result.metadata["incomplete"], result.warnings)
        self.assertEqual(result.metadata["native_text_pages"], 0)
        self.assertEqual(result.metadata["ocr_success_pages"], 1)
        self.assertIn("quick brown fox", result.text.lower())
        self.assertIn("synthetic", result.text.lower())
        again = self.extract(ocr="auto", ocr_language="eng", dpi=150, timeout=30)
        self.assertEqual(again.metadata["ocr_attempted_pages"], 0)
        self.assertEqual(again.metadata["ocr_cache_hits"], 1)


if __name__ == "__main__":
    unittest.main()
