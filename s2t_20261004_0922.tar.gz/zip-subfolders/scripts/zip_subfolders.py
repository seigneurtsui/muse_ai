#!/usr/bin/env python3
"""Batch archive selected subfolders without following links or overwriting by surprise.

The supplied project used Gradio, py7zr, ditto and a shell-adjacent 7z fallback.
This skill keeps its folder selection/depth/checkpoint/report behavior while using
stdlib ZIP/TAR.GZ by default. 7z is an explicit optional external executable.
"""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tarfile
import tempfile
import time
import unicodedata
import zipfile

VERSION = 1
FORMATS = {"zip": ".zip", "tar.gz": ".tar.gz", "7z": ".7z"}
DEFAULT_EXCLUDES = frozenset({".git", "node_modules", "__pycache__", ".DS_Store"})
MAX_DEPTH = 5
MAX_FILES_PER_FOLDER = 100_000
MAX_FOLDER_BYTES = 8 * 1024**3
MAX_FOLDERS = 10_000
MAX_WORKERS = 8
MAX_REPORT_BYTES = 16 * 1024 * 1024
STATE_NAME = ".zip-subfolders-state.json"
LOCK_NAME = ".zip-subfolders.lock"


class ArchiveError(Exception):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def safe_reason(error: BaseException) -> str:
    code = getattr(error, "code", "")
    if isinstance(code, str) and code.replace("_", "").isalnum() and len(code) < 100:
        return code
    return (
        "permission_denied" if isinstance(error, PermissionError) else "archive_failed"
    )


def packed(value) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def normalize_key(value: str) -> str:
    return unicodedata.normalize("NFC", value).casefold()


def linklike(path: Path) -> bool:
    info = path.lstat()
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, "st_file_attributes", 0)
        & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    )


def private_dir(path: Path, create: bool = False) -> Path:
    path = path.expanduser().absolute()
    if path.exists() or path.is_symlink():
        if linklike(path) or not path.is_dir():
            raise ArchiveError("directory_is_link_or_not_directory")
    elif create:
        path.mkdir(parents=True, mode=0o700)
    else:
        raise ArchiveError("directory_not_found")
    if create:
        path.mkdir(parents=True, exist_ok=True, mode=0o700)
    if os.name == "posix":
        path.chmod(0o700)
    return path.resolve()


def ensure_child_dirs(root: Path, directory: Path) -> None:
    if not directory.absolute().is_relative_to(root.absolute()):
        raise ArchiveError("output_path_outside_target")
    current = root
    for part in directory.relative_to(root).parts:
        current = current / part
        if current.exists() or current.is_symlink():
            if linklike(current) or not current.is_dir():
                raise ArchiveError("output_parent_is_link_or_not_directory")
        else:
            current.mkdir(mode=0o700)


def atomic_write(path: Path, raw: bytes) -> None:
    if path.exists() or path.is_symlink():
        if linklike(path) or not path.is_file() or path.stat().st_nlink > 1:
            raise ArchiveError("state_target_is_link_or_not_regular")
    fd, temp_name = tempfile.mkstemp(prefix=".zip-subfolders-", dir=path.parent)
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
        if os.name != "nt":
            fd = os.open(path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
    finally:
        temp.unlink(missing_ok=True)


def read_json(path: Path):
    try:
        raw = path.read_bytes()
        if len(raw) > MAX_REPORT_BYTES:
            raise ArchiveError("state_over_limit")
        return json.loads(raw)
    except ArchiveError:
        raise
    except (OSError, ValueError, UnicodeError):
        raise ArchiveError("invalid_state") from None


def relative_path(value: str) -> Path:
    path = Path(value)
    if (
        not isinstance(value, str)
        or not value
        or path.is_absolute()
        or any(part in ("", ".", "..") for part in path.parts)
    ):
        raise ArchiveError("unsafe_archive_member")
    return path


def source_tree(path: Path, source_root: Path, excludes: set[str]):
    """Return regular files/empty dirs, skipped links, and a source fingerprint."""
    entries = [("dir", path, Path("."))]
    skipped = []
    total_bytes = 0
    file_count = 0

    def visit(current: Path, relative: Path):
        nonlocal total_bytes, file_count
        try:
            children = sorted(
                current.iterdir(), key=lambda item: normalize_key(item.name)
            )
        except OSError:
            raise ArchiveError("source_directory_unreadable") from None
        if not children and relative != Path("."):
            entries.append(("dir", current, relative))
        for child in children:
            if linklike(child):
                skipped.append(
                    {"path": str(relative / child.name), "reason": "link_not_followed"}
                )
                continue
            if child.name.startswith(".") or child.name in excludes:
                skipped.append(
                    {"path": str(relative / child.name), "reason": "excluded_name"}
                )
                continue
            child_relative = relative / child.name
            info = child.stat()
            if stat.S_ISDIR(info.st_mode):
                visit(child, child_relative)
            elif stat.S_ISREG(info.st_mode):
                file_count += 1
                total_bytes += info.st_size
                if file_count > MAX_FILES_PER_FOLDER:
                    raise ArchiveError("folder_file_limit")
                if total_bytes > MAX_FOLDER_BYTES:
                    raise ArchiveError("folder_size_limit")
                entries.append(("file", child, child_relative))
            else:
                skipped.append(
                    {"path": str(child_relative), "reason": "special_file_not_archived"}
                )

    visit(path, Path("."))
    entries.sort(key=lambda row: normalize_key(str(row[2])))
    fingerprint_rows = []
    for kind, item, relative in entries:
        info = item.stat()
        fingerprint_rows.append(
            [
                kind,
                str(relative),
                info.st_size,
                info.st_mtime_ns,
                stat.S_IMODE(info.st_mode),
            ]
        )
    for item in skipped:
        fingerprint_rows.append(["skipped", item["path"], item["reason"]])
    fingerprint = digest(packed(fingerprint_rows))
    return entries, skipped, fingerprint, total_bytes, file_count


def discover_folders(source: Path, depth: int, excludes: set[str]) -> list[Path]:
    if not 1 <= depth <= MAX_DEPTH:
        raise ArchiveError("invalid_depth")
    found = []

    def walk(current: Path, remaining: int):
        if remaining <= 0:
            return
        try:
            children = sorted(
                current.iterdir(), key=lambda item: normalize_key(item.name)
            )
        except OSError:
            raise ArchiveError("source_directory_unreadable") from None
        for child in children:
            if linklike(child) or child.name.startswith(".") or child.name in excludes:
                continue
            if child.is_dir():
                found.append(child)
                if len(found) > MAX_FOLDERS:
                    raise ArchiveError("folder_count_limit")
                walk(child, remaining - 1)

    walk(source, depth)
    return found


def choose_folders(
    source: Path, depth: int, selected: list[str] | None, excludes: set[str]
) -> list[Path]:
    if not selected:
        result = discover_folders(source, depth, excludes)
    else:
        result = []
        for value in selected:
            candidate = Path(value).expanduser()
            if not candidate.is_absolute():
                candidate = source / candidate
            candidate = candidate.absolute()
            if (
                linklike(candidate)
                or not candidate.is_dir()
                or not candidate.resolve().is_relative_to(source)
            ):
                raise ArchiveError("selected_folder_outside_source")
            relative = candidate.resolve().relative_to(source)
            if len(relative.parts) > depth or any(
                part.startswith(".") or part in excludes for part in relative.parts
            ):
                raise ArchiveError("selected_folder_excluded_or_beyond_depth")
            result.append(candidate.resolve())
    unique = {}
    for folder in result:
        unique[normalize_key(str(folder.relative_to(source)))] = folder
    result = sorted(
        unique.values(), key=lambda item: normalize_key(str(item.relative_to(source)))
    )
    if not result:
        raise ArchiveError("no_subfolders_found")
    if selected:
        for index, folder in enumerate(result):
            for other in result[index + 1 :]:
                if other.is_relative_to(folder):
                    raise ArchiveError("overlapping_selected_folders")
    return result


def output_path(
    source: Path, target: Path, folder: Path, archive_format: str, date_suffix: str
) -> Path:
    relative = folder.relative_to(source)
    parent = target / relative.parent
    filename = f"{folder.name}_{date_suffix}{FORMATS[archive_format]}"
    result = parent / filename
    relative_path(result.relative_to(target).as_posix())
    return result


def _archive_members(folder: Path, entries):
    for kind, item, relative in entries:
        member = (
            Path(folder.name) if relative == Path(".") else Path(folder.name) / relative
        )
        yield kind, item, member


def archive_zip(folder: Path, outfile: Path, entries, compression_level: int):
    with zipfile.ZipFile(
        outfile,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=compression_level,
        allowZip64=True,
    ) as archive:
        for kind, item, member in _archive_members(folder, entries):
            name = member.as_posix()
            if kind == "dir":
                archive.writestr(name.rstrip("/") + "/", b"")
            else:
                archive.write(item, name)


def archive_tar_gz(folder: Path, outfile: Path, entries, compression_level: int):
    with tarfile.open(outfile, "w:gz", compresslevel=compression_level) as archive:
        for kind, item, member in _archive_members(folder, entries):
            archive.add(item, arcname=member.as_posix(), recursive=False)


def archive_7z(folder: Path, outfile: Path, compression_level: int, timeout: int):
    executable = shutil.which("7z") or shutil.which("7zz")
    if executable is None:
        raise ArchiveError("7z_executable_not_found")
    command = [
        executable,
        "a",
        "-t7z",
        f"-mx={compression_level}",
        "-mmt=on",
        str(outfile),
        folder.name,
    ]
    try:
        result = subprocess.run(
            command,
            cwd=folder.parent,
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout,
            shell=False,
        )
    except subprocess.TimeoutExpired:
        raise ArchiveError("archive_timeout") from None
    if result.returncode != 0 or not outfile.exists() or outfile.stat().st_size == 0:
        raise ArchiveError("7z_command_failed")


def verify_archive(outfile: Path, archive_format: str) -> tuple[int, int]:
    if not outfile.is_file() or outfile.stat().st_size == 0:
        raise ArchiveError("archive_empty")
    if archive_format == "zip":
        with zipfile.ZipFile(outfile) as archive:
            names = archive.namelist()
            if len(names) != len(set(names)) or any(
                not relative_path(name.rstrip("/")).parts for name in names
            ):
                raise ArchiveError("archive_member_invalid")
            if archive.testzip() is not None:
                raise ArchiveError("archive_crc_failed")
            return len(names), sum(info.file_size for info in archive.infolist())
    if archive_format == "tar.gz":
        with tarfile.open(outfile, "r:gz") as archive:
            members = archive.getmembers()
            names = [member.name for member in members]
            if len(names) != len(set(names)) or any(
                not relative_path(name).parts for name in names
            ):
                raise ArchiveError("archive_member_invalid")
            # Read regular members to detect truncated gzip/tar data.
            for member in members:
                if member.isfile():
                    stream = archive.extractfile(member)
                    if stream is not None:
                        while stream.read(1024 * 1024):
                            pass
            return len(members), sum(
                member.size for member in members if member.isfile()
            )
    if archive_format == "7z":
        return 0, outfile.stat().st_size
    raise ArchiveError("unsupported_archive_format")


def archive_one(
    folder: Path,
    source: Path,
    target: Path,
    archive_format: str,
    date_suffix: str,
    compression_level: int,
    timeout: int,
    overwrite: bool,
    excludes: set[str],
    existing_fingerprint: str | None = None,
):
    started = time.monotonic()
    entries, skipped, fingerprint, original_bytes, file_count = source_tree(
        folder, source, excludes
    )
    outfile = output_path(source, target, folder, archive_format, date_suffix)
    ensure_child_dirs(target, outfile.parent)
    if outfile.exists() or outfile.is_symlink():
        if linklike(outfile) or not outfile.is_file():
            raise ArchiveError("archive_target_is_link_or_not_regular")
        if not overwrite:
            if existing_fingerprint is not None and existing_fingerprint != fingerprint:
                raise ArchiveError("archive_exists_source_changed_use_overwrite")
            members, archived_bytes = verify_archive(outfile, archive_format)
            return {
                "status": "skipped_existing",
                "folder": str(folder),
                "relative": str(folder.relative_to(source)),
                "output": str(outfile),
                "output_sha256": digest(outfile.read_bytes()),
                "output_bytes": outfile.stat().st_size,
                "members": members,
                "archived_bytes": archived_bytes,
                "original_bytes": original_bytes,
                "file_count": file_count,
                "skipped": skipped,
                "fingerprint": fingerprint,
                "elapsed_seconds": round(time.monotonic() - started, 3),
            }
    fd, temporary_name = tempfile.mkstemp(
        prefix=".building-", suffix=FORMATS[archive_format], dir=outfile.parent
    )
    os.close(fd)
    temporary = Path(temporary_name)
    try:
        if archive_format == "zip":
            archive_zip(folder, temporary, entries, compression_level)
        elif archive_format == "tar.gz":
            archive_tar_gz(folder, temporary, entries, compression_level)
        elif archive_format == "7z":
            archive_7z(folder, temporary, compression_level, timeout)
        else:
            raise ArchiveError("unsupported_archive_format")
        if temporary is not None:
            if not temporary.is_file() or temporary.stat().st_size == 0:
                raise ArchiveError("archive_empty")
            os.replace(temporary, outfile)
        _, _, current_fingerprint, _, _ = source_tree(folder, source, excludes)
        if current_fingerprint != fingerprint:
            raise ArchiveError("source_changed_during_archive")
        members, archived_bytes = verify_archive(outfile, archive_format)
        return {
            "status": "created",
            "folder": str(folder),
            "relative": str(folder.relative_to(source)),
            "output": str(outfile),
            "output_sha256": digest(outfile.read_bytes()),
            "output_bytes": outfile.stat().st_size,
            "members": members,
            "archived_bytes": archived_bytes,
            "original_bytes": original_bytes,
            "file_count": file_count,
            "skipped": skipped,
            "fingerprint": fingerprint,
            "elapsed_seconds": round(time.monotonic() - started, 3),
        }
    except Exception:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
        if archive_format == "7z" and outfile.exists() and not overwrite:
            outfile.unlink(missing_ok=True)
        raise


class RunLock:
    def __init__(self, target: Path):
        self.path = target / LOCK_NAME
        self.identity = None

    def __enter__(self):
        try:
            self.path.mkdir(mode=0o700)
        except FileExistsError:
            raise ArchiveError("target_locked_review_before_removing") from None
        self.identity = self.path.stat()
        atomic_write(
            self.path / "owner.json",
            packed(
                {
                    "pid": os.getpid(),
                    "created_at": datetime.now(timezone.utc).isoformat(),
                }
            ),
        )
        return self

    def __exit__(self, exc_type, exc, tb):
        current = self.path.lstat()
        if linklike(self.path) or (current.st_dev, current.st_ino) != (
            self.identity.st_dev,
            self.identity.st_ino,
        ):
            raise ArchiveError("target_lock_changed")
        (self.path / "owner.json").unlink(missing_ok=True)
        self.path.rmdir()
        return False


def load_state(target: Path):
    path = target / STATE_NAME
    if not path.exists():
        return {"version": VERSION, "tasks": {}}
    data = read_json(path)
    if (
        not isinstance(data, dict)
        or data.get("version") != VERSION
        or not isinstance(data.get("tasks"), dict)
    ):
        raise ArchiveError("invalid_state")
    return data


def save_state(target: Path, state):
    raw = packed(state) + b"\n"
    if len(raw) > MAX_REPORT_BYTES:
        raise ArchiveError("state_over_limit")
    atomic_write(target / STATE_NAME, raw)


def write_report(target: Path, report):
    raw = packed(report) + b"\n"
    if len(raw) > MAX_REPORT_BYTES:
        raise ArchiveError("report_over_limit")
    atomic_write(target / "report.json", raw)
    lines = [
        "批量子文件夹压缩报告",
        f"状态：{report['status']}",
        f"源目录：{report['source']}",
        f"目标目录：{report['target']}",
        f"格式：{report['format']}",
        f"任务：{report['total']}，创建：{report['created']}，跳过：{report['skipped']}，失败：{report['failed']}",
        f"原始大小：{report['original_bytes']} bytes，压缩包大小：{report['archive_bytes']} bytes",
        "",
    ]
    for item in report["results"]:
        lines.append(
            json.dumps(
                {
                    key: item.get(key)
                    for key in (
                        "relative",
                        "status",
                        "output",
                        "output_bytes",
                        "members",
                        "elapsed_seconds",
                        "reason",
                    )
                    if item.get(key) is not None
                },
                ensure_ascii=False,
            )
        )
    atomic_write(target / "report.txt", ("\n".join(lines) + "\n").encode("utf-8"))


def run(
    source_value: str,
    target_value: str,
    depth: int = 1,
    archive_format: str = "zip",
    selected: list[str] | None = None,
    excludes: list[str] | None = None,
    workers: int = 2,
    compression_level: int = 6,
    dry_run: bool = False,
    overwrite: bool = False,
    timeout: int = 300,
):
    source = private_dir(Path(source_value))
    target = Path(target_value).expanduser().absolute().resolve(strict=False)
    if (
        target == source
        or target.is_relative_to(source)
        or source.is_relative_to(target)
    ):
        raise ArchiveError("source_target_must_be_separate")
    if target.exists() or target.is_symlink():
        target = private_dir(target)
    elif not dry_run:
        target = private_dir(target, create=True)
    else:
        target = target.resolve(strict=False)
    if archive_format not in FORMATS or archive_format == "cpgz":
        raise ArchiveError("unsupported_archive_format")
    if (
        not 1 <= workers <= MAX_WORKERS
        or not 0 <= compression_level <= 9
        or timeout < 1
    ):
        raise ArchiveError("invalid_compression_options")
    exclude_names = set(DEFAULT_EXCLUDES) | {
        name for name in (excludes or []) if isinstance(name, str) and name
    }
    folders = choose_folders(source, depth, selected, exclude_names)
    date_suffix = datetime.now().strftime("%Y%m%d")
    tasks = []
    output_keys = set()
    for folder in folders:
        outfile = output_path(source, target, folder, archive_format, date_suffix)
        key = normalize_key(str(outfile.relative_to(target)))
        if key in output_keys:
            raise ArchiveError("archive_output_collision")
        output_keys.add(key)
        tasks.append(
            {
                "relative": str(folder.relative_to(source)),
                "folder": str(folder),
                "output": str(outfile),
            }
        )
    if dry_run:
        return {
            "status": "dry_run",
            "source": str(source),
            "target": str(target),
            "format": archive_format,
            "depth": depth,
            "total": len(tasks),
            "folders": tasks,
            "writes": False,
        }
    started = time.monotonic()
    results = []
    state = load_state(target)
    state_tasks = state["tasks"]
    with RunLock(target):

        def one(task):
            folder = Path(task["folder"])
            try:
                prior = state_tasks.get(task["relative"] + "|" + archive_format, {})
                result = archive_one(
                    folder,
                    source,
                    target,
                    archive_format,
                    date_suffix,
                    compression_level,
                    timeout,
                    overwrite,
                    exclude_names,
                    prior.get("fingerprint"),
                )
                result["task"] = task["relative"]
                state_tasks[task["relative"] + "|" + archive_format] = {
                    "fingerprint": result["fingerprint"],
                    "output_sha256": result["output_sha256"],
                    "output": result["output"],
                    "status": result["status"],
                    "updated_at": datetime.now(timezone.utc).isoformat(),
                }
                return result
            except Exception as error:
                return {
                    "status": "failed",
                    "task": task["relative"],
                    "folder": task["folder"],
                    "output": task["output"],
                    "reason": safe_reason(error),
                    "elapsed_seconds": round(time.monotonic() - started, 3),
                }

        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = [executor.submit(one, task) for task in tasks]
            for future in as_completed(futures):
                results.append(future.result())
        results.sort(key=lambda row: row["task"])
        created = sum(row["status"] == "created" for row in results)
        skipped = sum(row["status"] == "skipped_existing" for row in results)
        failed = sum(row["status"] == "failed" for row in results)
        report = {
            "version": VERSION,
            "status": "complete" if not failed else "partial_failure",
            "source": str(source),
            "target": str(target),
            "format": archive_format,
            "depth": depth,
            "total": len(tasks),
            "created": created,
            "skipped": skipped,
            "failed": failed,
            "original_bytes": sum(row.get("original_bytes", 0) for row in results),
            "archive_bytes": sum(row.get("output_bytes", 0) for row in results),
            "elapsed_seconds": round(time.monotonic() - started, 3),
            "results": results,
        }
        save_state(target, state)
        try:
            write_report(target, report)
        except Exception as error:
            report["status"] = "report_error"
            report["report_error"] = safe_reason(error)
            report["archive_exit_code"] = 2
    return report


def build_parser():
    parser = argparse.ArgumentParser(
        description="批量压缩指定目录中的子文件夹；不跟随链接，不默认覆盖已有压缩包。"
    )
    parser.add_argument(
        "--source", "-s", required=True, type=Path, help="源目录；只处理其子文件夹"
    )
    parser.add_argument(
        "--target",
        "-t",
        required=True,
        type=Path,
        help="独立目标目录，不能位于源目录内",
    )
    parser.add_argument(
        "--depth", type=int, choices=range(1, MAX_DEPTH + 1), default=1, metavar="1-5"
    )
    parser.add_argument(
        "--format", choices=sorted(FORMATS), default="zip", dest="archive_format"
    )
    parser.add_argument(
        "--folder",
        action="append",
        dest="folders",
        help="子目录名或绝对路径，可重复；默认扫描深度内全部子目录",
    )
    parser.add_argument(
        "--exclude", action="append", default=[], help="按目录名排除，可重复"
    )
    parser.add_argument(
        "--workers", type=int, default=2, choices=range(1, MAX_WORKERS + 1)
    )
    parser.add_argument("--compression-level", type=int, default=6, choices=range(10))
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="明确允许替换同名压缩包；默认跳过并校验已有包",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="只列出任务，不创建目标、锁、压缩包或报告",
    )
    parser.add_argument("--json", action="store_true", help="输出单个 JSON 结果")
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        result = run(
            str(args.source),
            str(args.target),
            args.depth,
            args.archive_format,
            args.folders,
            args.exclude,
            args.workers,
            args.compression_level,
            args.dry_run,
            args.overwrite,
            args.timeout,
        )
        print(json.dumps(result, ensure_ascii=False, indent=None if args.json else 2))
        return (
            0
            if result["status"] in ("complete", "dry_run")
            and result.get("failed", 0) == 0
            else 2
        )
    except Exception as error:
        print(
            json.dumps(
                {"status": "error", "reason": safe_reason(error)}, ensure_ascii=False
            )
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
