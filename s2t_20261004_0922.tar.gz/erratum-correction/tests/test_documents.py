"""Synthetic, offline document-core regression tests; no user files are read."""

from difflib import SequenceMatcher
import json
import random
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from document_core import (  # noqa: E402
    DocumentError,
    HomophoneCorrector,
    MAX_DICTIONARY_BYTES,
    TextSegment,
    apply_segments,
    contains_chinese,
    extract_ai_error_terms,
    extract_segments,
    validate_replacement,
)


class DocumentTests(unittest.TestCase):
    def assert_code(self, code, callback, *args):
        with self.assertRaises(DocumentError) as caught:
            callback(*args)
        self.assertEqual(caught.exception.code, code)
        self.assertEqual(str(caught.exception), code)

    def corrected(self, content, ext):
        segments = extract_segments(content, ext)
        self.assertEqual(
            apply_segments(content, segments, [s.text for s in segments]), content
        )
        for segment in segments:
            self.assertEqual(segment.text, content[segment.start : segment.end])
            self.assertEqual(segment.text.strip(), segment.text)
            self.assertNotIn("\n", segment.text)
            self.assertNotIn("\r", segment.text)
            self.assertIsInstance(segment.line, int)
        return apply_segments(
            content, segments, [s.text.replace("神农家", "神农架") for s in segments]
        )

    def test_plain_newline_bom_whitespace_and_no_final_newline(self):
        source = "\ufeff  神农家 \r\n\t神农家\t\r\n\r尾神农家  \n \n神农家"
        self.assertEqual(
            self.corrected(source, ".TXT"), source.replace("神农家", "神农架")
        )
        self.assertEqual(extract_segments(source, ".txt")[0].line, 1)
        self.assertEqual(extract_segments(" \r\n\t", ".txt"), [])
        self.assertEqual(extract_segments("", ".txt"), [])

    def test_plain_protects_tokens_and_controls(self):
        source = '神农家 <span title="神农家 > x">神农家</span> &神农家; &amp; \\N 神农家\u200b神农家 https://example.test/神农家'
        result = self.corrected(source, ".txt")
        self.assertIn('<span title="神农家 > x">神农架</span>', result)
        self.assertIn("&amp; \\N 神农架\u200b神农架", result)
        self.assertTrue(result.endswith("https://example.test/神农家"))

    def test_unknown_extension_and_nul_rejected(self):
        self.assert_code("unsupported_extension", extract_segments, "x", ".html")
        self.assert_code("document_nul", extract_segments, "x\x00", ".txt")

    def test_srt_numeric_and_arrow_dialogue_are_not_discarded(self):
        source = '\ufeff1\r\n00:00:01,000 --> 00:00:03,000\r\n 123 \r\n 神农家 --> 神农家 \r\n\r\n2\r\n00:00:04,000 --> 00:00:05,000\r\n<i title="神农家">神农家</i>'
        segments = extract_segments(source, ".srt")
        self.assertIn("123", [s.text for s in segments])
        result = self.corrected(source, ".srt")
        self.assertIn(" 神农架 --> 神农架 \r\n", result)
        self.assertTrue(result.endswith('<i title="神农家">神农架</i>'))
        self.assertIn("00:00:01,000 --> 00:00:03,000", result)

    def test_srt_malformed_fails(self):
        examples = [
            ("", "subtitle_structure"),
            ("dialogue only", "srt_index"),
            ("00:00:00,000 --> 00:00:01,000\n神农家", "srt_index"),
            ("1\n00:99:01,000 --> 00:00:03,000\n神农家", "subtitle_timing"),
            ("1\n00:00:01.000 --> 00:00:03.000\n神农家", "subtitle_timing"),
            ("1\n00:00:03,000 --> 00:00:03,000\n神农家", "subtitle_time_order"),
            ("1\n00:00:03,000 --> 00:00:02,000\n神农家", "subtitle_time_order"),
            ("1\n00:00:01,000 --> 00:00:03,000", "subtitle_structure"),
            (
                "1\n00:00:01,000 --> 00:00:03,000\n神农家\n2\n00:00:04,000 --> 00:00:05,000\n神农家",
                "subtitle_missing_separator",
            ),
        ]
        for source, code in examples:
            with self.subTest(code=code, source=source):
                self.assert_code(code, extract_segments, source, ".srt")

    def test_vtt_blocks_headers_settings_and_identifiers_preserved(self):
        source = (
            "\ufeffWEBVTT 神农家\r\nLanguage: zh\r\n\r\n"
            "NOTE 神农家\r\n神农家 --> metadata\r\n\r\n"
            "STYLE\r\n::cue { font-family: 神农家; }\r\n\r\n"
            "REGION\r\nid:神农家\r\nwidth:40%\r\n\r\n"
            "神农家\r\n00:01.000 --> 00:03.000 position:50%,center line:90% align:start\r\n"
            "123\r\n<v 神农家> 神农家 <00:02.000>神农家</v>\r\n神农家 --> 神农家\r\n\r\n"
            "00:00:04.000 --> 00:00:05.000 region:神农家 size:40%\r\n神农家"
        )
        result = self.corrected(source, ".vtt")
        self.assertEqual(result[: source.index("123")], source[: source.index("123")])
        self.assertIn("<v 神农家> 神农架 <00:02.000>神农架</v>", result)
        self.assertIn("神农架 --> 神农架", result)
        self.assertIn("region:神农家", result)
        self.assertTrue(result.endswith("神农架"))
        self.assertIn("123", [s.text for s in extract_segments(source, ".vtt")])

    def test_vtt_valid_empty_header(self):
        self.assertEqual(extract_segments("WEBVTT\n\n", ".vtt"), [])

    def test_vtt_malformed_fails(self):
        examples = [
            ("00:01.000 --> 00:03.000\n神农家", "vtt_header"),
            ("\nWEBVTT\n\n", "vtt_header"),
            ("WEBVTT\n00:01.000 --> 00:03.000\n神农家", "vtt_header"),
            ("WEBVTT\n\nid\nnot a timestamp\n神农家", "subtitle_timing"),
            ("WEBVTT\n\n00:01,000 --> 00:03,000\n神农家", "subtitle_timing"),
            ("WEBVTT\n\n00:01.000 --> 00:03.000 size:101%\n神农家", "vtt_settings"),
            (
                "WEBVTT\n\n00:01.000 --> 00:03.000 size:40% size:50%\n神农家",
                "vtt_settings",
            ),
            ("WEBVTT\n\n00:01.000 --> 00:03.000 nonsense:50%\n神农家", "vtt_settings"),
        ]
        for source, code in examples:
            with self.subTest(source=source):
                self.assert_code(code, extract_segments, source, ".vtt")

    def test_ass_format_text_only_overrides_escapes_and_drawing(self):
        source = (
            "[Script Info]\r\nTitle: 神农家\r\n[V4+ Styles]\r\nFormat: Name, Fontname\r\nStyle: 神农家,神农家\r\n"
            "[Events]\r\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\r\n"
            "Dialogue: 0,0:00:01.00,0:00:05.00,神农家,神农家,0,0,0,,  神农家{\\fn神农家\\b1}神农家\\N神农家\\n神农家\\h神农家,神农家  \r\n"
            "Comment: 0,0:00:01.00,0:00:05.00,神农家,,0,0,0,,{\\p1}m 0 0 l 10 10 神农家{\\p0}神农家\r\n"
        )
        result = self.corrected(source, ".ass")
        self.assertEqual(
            result[: source.index("  神农家")], source[: source.index("  神农家")]
        )
        self.assertIn(
            "{\\fn神农家\\b1}神农架\\N神农架\\n神农架\\h神农架,神农架  \r\n", result
        )
        self.assertIn("{\\p1}m 0 0 l 10 10 神农家{\\p0}神农架", result)

    def test_ssa_format_can_reorder_nontext_fields(self):
        source = "[Events]\nFormat: End, Marked, Start, Text\nDialogue: 0:00:05.00,Marked=0,0:00:01.00,神农家,神农家"
        self.assertEqual(
            self.corrected(source, ".ssa"), source.replace("神农家", "神农架")
        )

    def test_ass_drawing_modes_reset_per_event_and_ignore_pbo(self):
        source = "[Events]\nFormat: Start, End, Text\nDialogue: 0:00:01.00,0:00:02.00,{\\p1}神农家\nDialogue: 0:00:01.00,0:00:02.00,{\\pbo3}神农家"
        result = self.corrected(source, ".ass")
        self.assertIn("{\\p1}神农家\n", result)
        self.assertTrue(result.endswith("{\\pbo3}神农架"))

    def test_ass_empty_text_is_valid(self):
        source = "[Events]\nFormat: Start, End, Text\nDialogue: 0:00:01.00,0:00:02.00,"
        self.assertEqual(extract_segments(source, ".ass"), [])

    def test_ass_malformed_fails(self):
        prefix = "[Events]\nFormat: Start, End, Text\n"
        examples = [
            ("[Script Info]\nTitle: demo", "ass_events_missing"),
            ("[Events]\nDialogue: 0,0:00:01.00,0:00:02.00,x", "ass_missing_format"),
            ("[Events]\nFormat: Start, Text, End", "ass_text_position"),
            ("[Events]\nFormat: Start, End, Text, Text", "ass_format"),
            ("[Events]\nFormat: Style, Text", "ass_format"),
            (prefix + "Dialogue: 0:00:01.00,0:00:02.00", "ass_event"),
            (prefix + "Dialogue: nope,0:00:02.00,神农家", "subtitle_timing"),
            (prefix + "Dialogue: 0:00:02.00,0:00:01.00,神农家", "subtitle_time_order"),
            (prefix + "Dialogue: 0:00:01.00,0:00:02.00,{\\b1神农家", "ass_override"),
            (prefix + "Dialogue: 0:00:01.00,0:00:02.00,神农家}", "ass_override"),
            (
                prefix + "Dialogue: 0:00:01.00,0:00:02.00,{\\p}神农家",
                "ass_drawing_mode",
            ),
            (prefix + "Sound: file.wav", "ass_event_type"),
            ("[Script Info]\nDialogue: 0,0:00:01.00,0:00:02.00,x", "ass_event_section"),
        ]
        for source, code in examples:
            with self.subTest(source=source):
                self.assert_code(code, extract_segments, source, ".ass")

    def test_markdown_fences_inline_code_links_and_framing(self):
        source = (
            "# 神农家  \r\n\r\n```python\r\n神农家 = '神农家'\r\n```\r\n"
            "~~~神农家\r\n神农家\r\n~~~\r\n"
            "  - [x] **神农家** `神农家` ``神农家 ` 神农家``\r\n"
            '[神农家](https://example.test/神农家_(x) "神农家") ![神农家](神农家.png)\r\n'
            "    神农家 indented code\r\n<https://example.test/神农家>\r\n"
            "| 神农家 | 神农家 |\r\n| --- | --- |"
        )
        result = self.corrected(source, ".md")
        self.assertIn("# 神农架  \r\n", result)
        self.assertIn("神农家 = '神农家'", result)
        self.assertIn("~~~神农家\r\n神农家\r\n~~~", result)
        self.assertIn("  - [x] **神农架** `神农家` ``神农家 ` 神农家``", result)
        self.assertIn(
            '[神农架](https://example.test/神农家_(x) "神农家") ![神农架](神农家.png)',
            result,
        )
        self.assertIn("    神农家 indented code", result)
        self.assertTrue(result.endswith("| 神农架 | 神农架 |\r\n| --- | --- |"))

    def test_markdown_multiline_inline_code(self):
        source = "神农家 `神农家\n  神农家` 神农家"
        self.assertEqual(
            self.corrected(source, ".markdown"), "神农架 `神农家\n  神农家` 神农架"
        )

    def test_markdown_references(self):
        source = '[神农家]: https://example.test/神农家 "神农家"\n\n[神农家][神农家] [神农家][] [神农家]\n神农家'
        expected = '[神农家]: https://example.test/神农家 "神农家"\n\n[神农架][神农家] [神农家][] [神农家]\n神农架'
        self.assertEqual(self.corrected(source, ".md"), expected)

    def test_markdown_frontmatter_html_comments_and_code(self):
        source = '---\ntitle: 神农家\n---\n神农家 <!-- 神农家 <b>神农家</b> -->\n<pre>神农家\n神农家</pre>\n<span title="神农家 >">神农家</span>'
        expected = '---\ntitle: 神农家\n---\n神农架 <!-- 神农家 <b>神农家</b> -->\n<pre>神农家\n神农家</pre>\n<span title="神农家 >">神农架</span>'
        self.assertEqual(self.corrected(source, ".md"), expected)

    def test_markdown_quoted_and_list_fences(self):
        source = "> ```\n> 神农家\n> ```\n- ~~~\n神农家\n~~~\n神农家"
        self.assertEqual(self.corrected(source, ".md"), source[:-3] + "神农架")

    def test_markdown_unterminated_regions_are_conservatively_protected(self):
        for source in [
            "```\n神农家",
            "神农家 <!-- 神农家",
            "[神农家](神农家",
            "`神农家",
        ]:
            with self.subTest(source=source):
                expected = (
                    source.replace("神农家", "神农架", 1)
                    if source.startswith(("神农家", "["))
                    else source
                )
                self.assertEqual(self.corrected(source, ".md"), expected)

    def test_apply_cardinality_ranges_overlap_order_and_content(self):
        a, b = TextSegment(0, 1, "甲"), TextSegment(1, 2, "乙")
        self.assertEqual(apply_segments("甲乙", [a, b], ["丙丙", "丁"]), "丙丙丁")
        self.assert_code("segment_cardinality", apply_segments, "甲乙", [a], [])
        self.assert_code(
            "segment_range", apply_segments, "甲乙", [TextSegment(-1, 1, "甲")], ["丙"]
        )
        self.assert_code(
            "segment_range", apply_segments, "甲乙", [TextSegment(0, 3, "甲乙")], ["丙"]
        )
        self.assert_code(
            "segment_range", apply_segments, "甲乙", [TextSegment(0, 0, "")], ["丙"]
        )
        self.assert_code(
            "segment_range",
            apply_segments,
            "甲乙",
            [TextSegment(False, 1, "甲")],
            ["丙"],
        )
        self.assert_code(
            "segment_overlap_or_order", apply_segments, "甲乙", [b, a], ["丙", "丁"]
        )
        self.assert_code(
            "segment_overlap_or_order", apply_segments, "甲乙", [a, a], ["丙", "丁"]
        )
        self.assert_code(
            "segment_content", apply_segments, "甲乙", [TextSegment(0, 1, "乙")], ["丙"]
        )
        self.assert_code("segment_type", apply_segments, "甲乙", [(0, 1, "甲")], ["丙"])
        self.assert_code("replacement_newline", apply_segments, "甲乙", [a], ["丙\n"])

    def test_apply_many_segments(self):
        source = "神农家 \r\n" * 10_000
        self.assertEqual(
            self.corrected(source, ".txt"), source.replace("神农家", "神农架")
        )

    def test_synthetic_random_plain_and_markdown_roundtrip(self):
        generator = random.Random(42)
        alphabet = '甲乙 abc123\r\n\t<>[]{}()_`~!#&;"\\' + "神农家\u200b\u2028"
        for _ in range(200):
            source = "".join(
                generator.choice(alphabet) for _ in range(generator.randrange(150))
            )
            for ext in (".txt", ".md"):
                with self.subTest(ext=ext, source=source):
                    segments = extract_segments(source, ext)
                    self.assertEqual(
                        apply_segments(source, segments, [s.text for s in segments]),
                        source,
                    )

    def test_validate_replacement_safe_changes(self):
        for before, after in [
            ("神农家", "神农架"),
            ("甲乙", "甲"),
            (" a  b ", " c  d "),
            ("神农家，神农家。", "神农架，神农架。"),
            ("", ""),
        ]:
            with self.subTest(before=before):
                self.assertIsNone(validate_replacement(before, after))

    def test_validate_replacement_unsafe_changes(self):
        for after in ["\n甲", "甲\r", "甲\u2028", "甲\x85"]:
            self.assert_code("replacement_newline", validate_replacement, "甲", after)
        self.assert_code("replacement_nul", validate_replacement, "甲", "甲\x00")
        for after in ["", " ", "\t"]:
            self.assert_code("replacement_empty", validate_replacement, "甲", after)
        examples = [
            ("甲  乙", "甲 乙"),
            ("甲 乙", "甲乙 "),
            ("甲", " 甲"),
            ("甲", "甲 "),
            ("甲\t乙", "甲 乙"),
            ("甲\u200b乙", "甲乙"),
            ("甲", "<b>乙</b>"),
            ("<i>甲</i>", "<b>乙</b>"),
            (r"甲\N乙", r"甲\n乙"),
            ("&amp;甲", "&lt;乙"),
            ("甲。", "乙！"),
        ]
        for before, after in examples:
            with self.subTest(before=before, after=after):
                self.assert_code(
                    "replacement_structure", validate_replacement, before, after
                )

    def test_errors_never_echo_unsafe_message(self):
        self.assertEqual(
            DocumentError("private document contents!").code, "document_error"
        )

    def test_contains_chinese_legacy_range(self):
        self.assertTrue(contains_chinese("abc神农家"))
        self.assertFalse(contains_chinese("123abc😀"))
        self.assertFalse(contains_chinese("\U00020000"))

    def test_diff_preserves_original_offsets_and_order(self):
        examples = [
            ("神农家", "神农架"),
            ("甲乙甲", "乙甲乙"),
            ("甲", ""),
            ("", "乙"),
            ("甲甲乙甲", "甲乙乙甲"),
            ("abc甲xy乙", "abc丙xy乙丁"),
        ]
        for before, after in examples:
            expected = [
                {
                    "before": before[i:j],
                    "after": after[k:l],
                    "type": tag,
                    "before_start": i,
                    "before_end": j,
                    "after_start": k,
                    "after_end": l,
                }
                for tag, i, j, k, l in SequenceMatcher(
                    None, before, after, autojunk=False
                ).get_opcodes()
                if tag != "equal"
            ]
            self.assertEqual(extract_ai_error_terms(before, after), expected)

    def test_diff_bounds_and_unchanged_fast_path(self):
        self.assert_code(
            "diff_too_large", extract_ai_error_terms, "甲" * 2001, "乙" * 2001
        )
        self.assert_code("diff_too_large", extract_ai_error_terms, "", "乙" * 100001)
        self.assertEqual(extract_ai_error_terms("甲" * 100001, "甲" * 100001), [])


class DictionaryTests(unittest.TestCase):
    def load(self, value, raw=False):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        path = Path(directory.name) / "dictionary.json"
        payload = value if raw else json.dumps(value, ensure_ascii=False)
        path.write_bytes(
            payload.encode("utf-8") if isinstance(payload, str) else payload
        )
        return HomophoneCorrector(path)

    def assert_error(self, code, value, raw=False):
        with self.assertRaises(DocumentError) as caught:
            self.load(value, raw)
        self.assertEqual(caught.exception.code, code)
        self.assertEqual(str(caught.exception), code)

    def test_ordered_cascading_nonoverlapping_counts(self):
        corrector = self.load({"甲甲": "乙", "甲": "丙", "乙": "丁"})
        self.assertEqual(corrector.pairs, [("甲甲", "乙"), ("甲", "丙"), ("乙", "丁")])
        self.assertEqual(
            corrector.correct_with_details("甲甲甲"),
            ("丁丙", 3, [("甲甲", "乙", 1), ("甲", "丙", 1), ("乙", "丁", 1)]),
        )
        self.assertEqual(corrector.correct("甲甲甲"), ("丁丙", 3))
        self.assertEqual(corrector.correct("甲甲\n甲"), ("丁\n丙", 3))
        self.assertEqual(
            self.load({"甲": "丙", "甲甲": "乙"}).correct("甲甲甲"), ("丙丙丙", 3)
        )

    def test_metadata_and_self_maps_are_explicitly_excluded(self):
        corrector = self.load(
            {"_comment": {"any": "metadata"}, "甲": "甲", "神农家": "神农架"}
        )
        self.assertEqual(corrector.metadata_keys, ["_comment"])
        self.assertEqual(corrector.self_maps, ["甲"])
        self.assertEqual(corrector.pairs, [("神农家", "神农架")])
        self.assertEqual(
            corrector.correct("甲 _comment 神农家神农家"),
            ("甲 _comment 神农架神农架", 2),
        )
        self.assertEqual(self.load({}).pairs, [])

    def test_duplicate_and_conflicting_keys_fail_even_under_metadata(self):
        self.assert_error("dictionary_duplicate_key", '{"甲":"乙","甲":"乙"}', True)
        self.assert_error("dictionary_conflicting_key", '{"甲":"乙","甲":"丙"}', True)
        self.assert_error(
            "dictionary_conflicting_key", '{"_meta":{"甲":1,"甲":2}}', True
        )

    def test_malformed_tables_are_not_silently_skipped(self):
        for value in [[], None, "text", 123]:
            self.assert_error("dictionary_table", value)
        for value in [
            {"": "甲"},
            {" ": "甲"},
            {"甲": " "},
            {"甲": ""},
            {"甲": None},
            {"甲": ["乙"]},
            {"甲": {"乙": "丙"}},
            {"甲": 1},
            {"甲": "乙\n"},
            {"甲\x00": "乙"},
        ]:
            self.assert_error("dictionary_rule", value)
        for value in [
            "{",
            b"\xff",
            '{"甲":NaN}',
            '{"_meta":Infinity}',
            '{"甲":' + "9" * 5000 + "}",
        ]:
            self.assert_error("dictionary_json", value, True)

    def test_dictionary_read_failures_are_safe(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "missing-private-name.json"
            with self.assertRaises(DocumentError) as caught:
                HomophoneCorrector(path)
            self.assertEqual(str(caught.exception), "dictionary_read")

    def test_dictionary_size_limit_and_utf8_bom(self):
        self.assertEqual(self.load(b"\xef\xbb\xbf{}", True).pairs, [])
        self.assertEqual(
            self.load(b"{}" + b" " * (MAX_DICTIONARY_BYTES - 2), True).pairs, []
        )
        self.assert_error(
            "dictionary_too_large", b"{}" + b" " * (MAX_DICTIONARY_BYTES - 1), True
        )


if __name__ == "__main__":
    unittest.main()
