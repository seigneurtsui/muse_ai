from __future__ import annotations
import contextlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import build_dictionary as builder
from document_core import HomophoneCorrector, DocumentError
from file_support import packed, sha
import correct_chinese_errata as workflow


class FakeConverter:
    info = {"fixture": True, "profiles": ["t2s", "s2t"]}

    def __init__(self, trad=None, simp=None):
        self.trad = trad or {"汉错": "漢錯", "汉字": "漢字", "全神贯注": "全神貫注"}
        self.simp = simp or {"漢錯": "汉错", "漢字": "汉字", "全神貫注": "全神贯注"}

    def simplify(self, text):
        return self.simp.get(text, text)

    def traditional(self, text):
        return self.trad.get(text, text)


def source(rules=None, **metadata):
    return {
        "_schema": 1,
        "_comment": "synthetic fixture",
        **metadata,
        **(rules or {"汉错": "汉字"}),
    }


class BuilderTests(unittest.TestCase):
    def compile(self, data, converter=None):
        return builder.compile_dictionary(
            data, converter or FakeConverter(), sha(packed(data))
        )

    def test_two_forms_one_maintained_rule_and_provenance(self):
        table, report = self.compile(source())
        self.assertEqual(table["汉错"], "汉字")
        self.assertEqual(table["漢錯"], "漢字")
        self.assertEqual(table["_generated"]["source_rules"], 1)
        self.assertEqual(table["_generated"]["runtime_rules"], 2)
        self.assertEqual(
            report["provenance"]["漢錯"], [{"source": "汉错", "form": "traditional"}]
        )

    def test_shared_spelling_is_deduplicated_not_doubled(self):
        table, _ = self.compile(source({"甲错": "甲正"}))
        self.assertEqual(table["_generated"]["runtime_rules"], 1)
        self.assertEqual(table["_generated"]["duplicate_forms_merged"], 1)

    def test_shared_wrong_string_two_targets_is_ai_only_not_guessed(self):
        table, report = self.compile(source({"全神灌注": "全神贯注"}))
        self.assertNotIn("全神灌注", table)
        self.assertEqual(
            table["_script_sensitive"]["全神灌注"],
            {"simplified": "全神贯注", "traditional": "全神貫注"},
        )
        self.assertEqual(report["metadata"]["script_sensitive_rules"], 1)

    def test_correction_normalized_away_is_not_exported_as_hant_error(self):
        engine = FakeConverter({"误字": "同字", "正字": "同字"})
        table, report = self.compile(source({"误字": "正字"}), engine)
        self.assertEqual(table["误字"], "正字")
        self.assertNotIn("同字", table)
        self.assertEqual(len(report["collapsed_traditional"]), 1)

    def test_collapsed_hant_that_equals_wrong_is_not_corrupted(self):
        engine = FakeConverter({"误字": "误字", "正字": "误字"})
        table, _ = self.compile(source({"误字": "正字"}), engine)
        self.assertNotIn("误字", table)
        self.assertEqual(table["_script_sensitive"]["误字"]["traditional"], "误字")

    def test_ambiguous_language_rules_stay_review_only(self):
        data = source(
            _review_only={"官服": {"right": "官府", "reason": "官服本身是合法词语"}}
        )
        table, _ = self.compile(data)
        self.assertNotIn("官服", table)
        self.assertEqual(table["_generated"]["review_only_rules"], 1)

    def test_review_only_cannot_also_be_active(self):
        data = source(
            {"官服": "官府"},
            _review_only={"官服": {"right": "官府", "reason": "valid word"}},
        )
        with self.assertRaisesRegex(builder.BuildError, "review_only_rule_is_active"):
            self.compile(data)

    def test_non_simplified_source_is_rejected(self):
        with self.assertRaisesRegex(builder.BuildError, "source_rule_not_simplified"):
            self.compile(source({"漢錯": "漢字"}))

    def test_noop_and_invalid_schema_and_whitespace_fail(self):
        for data in (
            {"_schema": 1, "甲": "甲"},
            source({"甲": "乙\n"}),
            {"_schema": 2, "甲": "乙"},
            {"_schema": True, "甲": "乙"},
            source(_unknown=True),
        ):
            with self.subTest(data=data), self.assertRaises(builder.BuildError):
                self.compile(data)

    def test_non_roundtrip_requires_fingerprint_approval(self):
        data = source({"亲呢": "亲昵"})
        engine = FakeConverter(
            {"亲呢": "親呢", "亲昵": "親暱"}, {"親呢": "亲呢", "親暱": "亲暱"}
        )
        with self.assertRaisesRegex(builder.BuildError, "roundtrip_requires_review"):
            self.compile(data, engine)
        data["_approved_non_roundtrip"] = {
            "亲呢": {
                "traditional_sha256": sha(packed(["親呢", "親暱"])),
                "reason": "explicit synthetic review",
            }
        }
        table, report = self.compile(data, engine)
        self.assertEqual(table["親呢"], "親暱")
        self.assertEqual(len(report["approved_non_roundtrip"]), 1)
        engine.trad["亲昵"] = "親昵"
        with self.assertRaisesRegex(builder.BuildError, "roundtrip_requires_review"):
            self.compile(data, engine)

    def test_stale_approval_is_not_silently_kept(self):
        data = source(
            _approved_non_roundtrip={
                "汉错": {"traditional_sha256": "0" * 64, "reason": "stale"}
            }
        )
        with self.assertRaisesRegex(builder.BuildError, "stale_non_roundtrip"):
            self.compile(data)

    def test_conflicting_generated_keys_are_errors(self):
        engine = FakeConverter({"甲": "共字", "乙": "正字", "丙": "共字", "丁": "别字"})
        approvals = {
            w: {
                "traditional_sha256": sha(
                    packed([engine.traditional(w), engine.traditional(r)])
                ),
                "reason": "fixture",
            }
            for w, r in [("甲", "乙"), ("丙", "丁")]
        }
        with self.assertRaisesRegex(builder.BuildError, "generated_key_conflict"):
            self.compile(
                source({"甲": "乙", "丙": "丁"}, _approved_non_roundtrip=approvals),
                engine,
            )

    def test_cascades_and_cycles_fail_without_reordering(self):
        for rules in (
            {"甲错": "乙错", "乙错": "乙正"},
            {"甲错": "乙错", "乙错": "甲错"},
        ):
            with self.subTest(rules=rules), self.assertRaisesRegex(
                builder.BuildError, "target_triggers"
            ):
                self.compile(source(rules))

    def test_output_is_deterministic_and_follows_source_order(self):
        data = source({"甲错": "甲正", "汉错": "汉字"})
        first, report = self.compile(data)
        second, again = self.compile(data)
        self.assertEqual(builder.render(first), builder.render(second))
        self.assertEqual(report, again)
        self.assertEqual(
            [k for k in first if not k.startswith("_")], ["甲错", "汉错", "漢錯"]
        )

    def test_approval_metadata_is_strict(self):
        for value in (
            True,
            {"missing": {}},
            {"汉错": {"traditional_sha256": "bad", "reason": "x"}},
        ):
            with self.assertRaises(builder.BuildError):
                self.compile(source(_approved_non_roundtrip=value))


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()

    def load(self, data):
        path = self.root / "dict.json"
        path.write_bytes(builder.render(data))
        return HomophoneCorrector(path), path

    def test_sensitive_metadata_is_not_replaced_and_reaches_current_model_payload(self):
        data = source({"全神灌注": "全神贯注", "汉错": "汉字"})
        table, _ = builder.compile_dictionary(data, FakeConverter(), sha(packed(data)))
        corrector, dictionary = self.load(table)
        self.assertEqual(corrector.correct("全神灌注 漢錯"), ("全神灌注 漢字", 1))
        doc = self.root / "demo.txt"
        doc.write_text("我們全神灌注。")
        args = workflow.build_arg_parser().parse_args(
            [
                "-i",
                str(doc),
                "--homophone-json",
                str(dictionary),
                "--output-root",
                str(self.root / "out"),
            ]
        )
        work, _ = workflow.work_document(doc, self.root, corrector, args)
        groups, _ = workflow.batch_units(work, 1500)
        proposal = groups[0][0]["context"]["script_sensitive_candidates"][0]
        self.assertEqual(
            proposal,
            {"before": "全神灌注", "simplified": "全神贯注", "traditional": "全神貫注"},
        )
        self.assertEqual(groups[0][0]["text"], "我們全神灌注。")

    def test_legacy_snapshot_payload_does_not_gain_empty_keys(self):
        work = {
            "local_texts": ["中文"],
            "segments": [{"text": "中文"}],
            "local_rule_hits": {},
        }
        groups, _ = workflow.batch_units(work, 1500)
        self.assertEqual(
            set(groups[0][0]["context"]), {"before", "after", "local_substitutions"}
        )

    def test_sensitive_metadata_shape_is_checked(self):
        for item in (
            {"_script_sensitive": []},
            {"_script_sensitive": {"甲": {"simplified": "乙"}}},
            {
                "甲": "乙",
                "_script_sensitive": {"甲": {"simplified": "乙", "traditional": "丙"}},
            },
            {"_script_sensitive": {"甲": {"simplified": "乙", "traditional": "乙"}}},
        ):
            with self.subTest(item=item), self.assertRaisesRegex(
                DocumentError, "dictionary_script_sensitive"
            ):
                self.load(item)

    def test_runtime_no_opencc_import_required(self):
        table, _ = builder.compile_dictionary(
            source(), FakeConverter(), sha(packed(source()))
        )
        _, dictionary = self.load(table)
        doc = self.root / "demo.txt"
        doc.write_text("漢錯\n")
        result = subprocess.run(
            [
                sys.executable,
                "-S",
                "-B",
                str(SCRIPTS / "correct_chinese_errata.py"),
                "-i",
                str(doc),
                "--output-root",
                str(self.root / "out"),
                "--homophone-json",
                str(dictionary),
                "--no-ai",
            ],
            capture_output=True,
            timeout=30,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        status = json.loads(result.stdout)
        self.assertEqual(Path(status["documents"][0]["output"]).read_text(), "漢字\n")

    def test_cli_preview_check_and_safe_write(self):
        src = self.root / "source.json"
        src.write_bytes(builder.render(source()))
        output = self.root / "output.json"
        report = self.root / "report.json"
        args = ["--source", str(src), "--output", str(output), "--report", str(report)]

        def call(extra):
            with patch(
                "build_dictionary.Converter", return_value=FakeConverter()
            ), contextlib.redirect_stdout(io.StringIO()) as stream:
                code = builder.main(args + extra)
            return code, json.loads(stream.getvalue())

        code, result = call([])
        self.assertEqual(code, 0)
        self.assertFalse(output.exists())
        self.assertFalse(report.exists())
        code, _ = call(["--write"])
        self.assertEqual(code, 0)
        self.assertEqual(call(["--check"])[0], 0)
        self.assertEqual(call(["--write"])[0], 2)
        self.assertEqual(call(["--write", "--replace"])[0], 0)
        output.write_text("{}")
        self.assertEqual(call(["--check"])[0], 2)
        self.assertEqual(call(["--write", "--replace"])[0], 0)
        with patch(
            "build_dictionary.Converter", return_value=FakeConverter()
        ), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(
                builder.main(
                    [
                        "--source",
                        str(src),
                        "--output",
                        str(src),
                        "--report",
                        str(report),
                        "--write",
                        "--replace",
                    ]
                ),
                2,
            )

    def test_no_ai_keeps_sensitive_text_and_reports_unresolved_choice(self):
        table, _ = builder.compile_dictionary(
            source({"全神灌注": "全神贯注"}),
            FakeConverter(),
            sha(packed(source({"全神灌注": "全神贯注"}))),
        )
        _, dictionary = self.load(table)
        doc = self.root / "demo.txt"
        doc.write_text("我們全神灌注。")
        args = workflow.build_arg_parser().parse_args(
            [
                "-i",
                str(doc),
                "--homophone-json",
                str(dictionary),
                "--output-root",
                str(self.root / "out"),
                "--no-ai",
            ]
        )
        result, code = workflow.start(args)
        self.assertEqual(code, 0)
        self.assertTrue(
            result["documents"][0]["local_only_script_sensitive_unresolved"]
        )
        self.assertEqual(
            Path(result["documents"][0]["output"]).read_text(), "我們全神灌注。"
        )

    def test_pending_job_uses_snapshot_after_default_dictionary_changes(self):
        corrector, dictionary = self.load({"汉错": "汉字"})
        doc = self.root / "demo.txt"
        doc.write_text("汉错")
        args = workflow.build_arg_parser().parse_args(
            [
                "-i",
                str(doc),
                "--homophone-json",
                str(dictionary),
                "--output-root",
                str(self.root / "out"),
            ]
        )
        result, code = workflow.start(args)
        self.assertEqual(code, 10)
        dictionary.write_text(json.dumps({"汉错": "另外"}, ensure_ascii=False))
        pending = result["pending_requests"][0]
        packet = json.loads(Path(pending["request_path"]).read_text())
        self.assertEqual(packet["payload"]["items"][0]["text"], "汉字")
        self.assertNotIn(
            "script_sensitive_candidates", packet["payload"]["items"][0]["context"]
        )
        Path(pending["response_path"]).write_text(
            json.dumps(
                {
                    "request_id": packet["request_id"],
                    "corrections": [{"id": 0, "text": "汉字"}],
                },
                ensure_ascii=False,
            )
        )
        result, code = workflow.resume(result["job_dir"])
        self.assertEqual(code, 0)
        self.assertEqual(Path(result["documents"][0]["output"]).read_text(), "汉字")

    def test_build_dependency_failure_does_not_copy_raw_table_as_success(self):
        src = self.root / "source.json"
        src.write_bytes(builder.render(source()))
        with patch(
            "build_dictionary.Converter",
            side_effect=builder.BuildError("opencc_required_for_dictionary_build_only"),
        ):
            with self.assertRaisesRegex(builder.BuildError, "opencc_required"):
                builder.build(src)


class InstalledDictionaryTests(unittest.TestCase):
    def test_maintained_source_is_not_accidentally_used_as_runtime_table(self):
        with self.assertRaisesRegex(DocumentError, "dictionary_source_requires_build"):
            HomophoneCorrector(builder.SOURCE)

    def test_every_runtime_rule_and_its_target_is_stable(self):
        corrector = HomophoneCorrector(builder.OUTPUT)
        for wrong, right in corrector.pairs:
            with self.subTest(wrong=wrong):
                self.assertEqual(corrector.correct(wrong)[0], right)
                self.assertEqual(corrector.correct(right)[0], right)
        self.assertEqual(
            corrector.correct("工作按步就班，完成数据备分。")[0],
            "工作按部就班，完成数据备份。",
        )
        self.assertEqual(
            corrector.correct("工作按步就班，完成數據備分。")[0],
            "工作按部就班，完成數據備份。",
        )
        self.assertEqual(
            corrector.correct("老師教了我，這是一項獨創技術。官服圖案很獨特。")[0],
            "老師教了我，這是一項獨創技術。官服圖案很獨特。",
        )

    def test_real_build_matches_delivered_artifacts(self):
        table, report = builder.build(builder.SOURCE)
        self.assertEqual(builder.render(table), builder.OUTPUT.read_bytes())
        report["runtime_sha256"] = sha(builder.render(table))
        self.assertEqual(builder.render(report), builder.REPORT.read_bytes())
        self.assertNotIn("神農家", json.loads(builder.SOURCE.read_text()))
        self.assertEqual(table["神農家"], "神農架")
        self.assertNotIn("独创", table)
        self.assertNotIn("獨創", table)
        corrector = HomophoneCorrector(builder.OUTPUT)
        self.assertEqual(
            corrector.correct("老师教了我，这是一项独创技术。官服图案很独特。")[0],
            "老师教了我，这是一项独创技术。官服图案很独特。",
        )


if __name__ == "__main__":
    unittest.main()
