# 验证

## 自动测试

```bash
cd "$HOME/.config/freebuff/skills/vercel-html-deploy"
python3 -B -m black --config /dev/null scripts/vercel_html_deploy.py tests/test_vercel_html_deploy.py
PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest discover -s tests -v
```

结果：**37 tests, OK**（Python 3.12.10；PyYAML 6.0.2；Vercel CLI 54.9.1；node v22.20.0）。
`black --check` 通过（exit 0，两文件均未改动）。

覆盖范围（`tests/test_vercel_html_deploy.py`）：

- **EnvTests**：`parse_env_file` 处理注释、空行、`export`、单双引号与 `KEY = value` 带空格写法；
  `load_env_files` 不覆盖真实环境变量；`credentials()` 读取 `VERCEL_TOKEN`/`VERCEL_SCOPE`/
  `VERCEL_PROJECT`/`PROD_URL`。
- **ConfigTests**：`defaults` 合并且部署项自身覆盖 defaults；`source_dir` 相对配置目录解析；
  非法 `mode`/项目名报错；缺失配置报 `config_not_found`；`discover_specs` 生成规范项目名；
  CLI `--prod`/`--preview` 覆盖配置项，未指定时保留配置值。
- **CollectionTests**：`scan_items` 同时识别子目录 `index.html` 与平铺 `.html`，跳过过小文件与
  文件名含 `-email` 的文档；`slug_for` 稳定且可配置（algo/len/prefix）；`build_toc_html` 生成含卡片、
  且无 `__PLACEHOLDER__` 的页面；`stage_collection` 生成 `<slug>/index.html` 与 `toc/index.html`；
  空集合报 `collection_found_no_items`；`root_mode=none` 不生成根 `index.html`。
- **StaticTests**：目录模式忽略 `.vercel/.git/__pycache__/node_modules`；单文件复制为 `index.html`；
  非 HTML 单文件报 `source_not_html_file`。
- **FingerprintTests**：static 指纹随内容变化；collection 指纹随新增文件变化。
- **WranglerEquivTests**（Vercel CLI 命令构造等价检查）：`build_deploy_command` 含
  `deploy`/`--project`/`--archive`/`-y`；`--preview`（prod=false）省略 `--prod`；
  `masked_command` 把 `--token` 值显示为 `***`；`find_deployment_url` 能从 JSON 与纯文本中提取 URL。
- **DeployTests**：dry-run 不调用 CLI、不写状态；static 部署成功记录状态与指纹；
  未变更站点 `skipped(unchanged)` 且被 `--force` 覆盖；`--retry-failed` 跳过成功项；
  `create_if_missing=false` 且项目缺失报 `project_missing` 且不调用部署；部署失败报
  `deploy_failed` 并带截断 detail；`--jobs 2` 并行两项目均成功。
- **CliTests**：`--jobs` 值校验；缺凭证报 `credentials_missing`；无输入报 `no_input_specified`；
  `discover --output` 写出可被 `load_config` 回读的配置；`list` 走 CLI 路径；
  `--help` 退出 0，以及真实子进程 `deploy --config … --dry-run --json` 退出 0 且 `status=dry_run`。

## 只读真实集成验证

用 `~/.config/freebuff/.env` 中的真实凭证执行**只读**操作：

```bash
python3 scripts/vercel_html_deploy.py list --json
```

结果（rc 0）：scope `seigneurtsuis-projects` 下 17 个项目被正确列出 ——
`zhongnanshan, shenyang-deploy, toc, folia-musique, rainman-travel, climb-emei, climb-deploy,
mountain-climber, kyushu-trip, todo-list-silo, todolist-silo, nextoasis, bark-relay, waline-vc,
next-js-saas-starter, altsendme-website, nextjs-auth-starter`。

同时以 `vercel project ls --token … --scope … -F json` 直接验证过：`zhongnanshan` 的
`latestProductionUrl` 为 `https://city.allez.cc.cd`，与 `.env` 中 `PROD_URL` 一致。

## 端到端 smoke（无副作用）

```bash
# fixture：父目录下两个含 index.html 的子目录（其一名字带空格）与一个空目录
python3 scripts/vercel_html_deploy.py discover --root <fixture>
# → 生成 deployments: alpha-site, beta（空目录被跳过；含空格路径单行加引号）

python3 scripts/vercel_html_deploy.py discover --root <fixture> --output vercel.yaml
python3 scripts/vercel_html_deploy.py deploy --config vercel.yaml --dry-run --json
```

- `discover` 只识别含 `index.html` 的一级子目录，输出 `mode: static`、`prod: true`、
  `create_if_missing: true`；`"…/Alpha Site"` 因含空格被单行加引号。
- `dry-run` 报告 `status=dry_run, summary={total:2, planned:2, skipped:0, failed:0}`；退出码 0；
  未写入状态文件（fixture 目录内无 `.vercel_html_deploy_state.json`）、未联网、未建项目。

- collection 模式 smoke：临时目录中一个 `YYYYMMDDT…==z--doc-one.html` 平铺文档与一个 `two/index.html`
  子目录文档 + 一份 collection 配置，`deploy --dry-run --json` 报告 `status=planned, items=2`（正确扫描到两条）。
- collection 暂存产物直验（`stage_collection` 到临时目录后检查）：得到
  `['city-51e439/index.html', 'city-b8a9f7/index.html', 'index.html', 'toc/index.html']`；
  `toc/index.html` 含两张卡片、无任何 `__PLACEHOLDER__` 残留；根 `index.html` 为日期最新的一篇
  （带日期文件名者优先于无日期的目录 `index.html`）。`--preview --dry-run --json` 报告
  `production=false`，验证 CLI 覆盖配置生效。

## 未执行

- **真实部署写入**（创建项目 / 上传到生产或预览）未在此环境中执行，因为它是对用户 Vercel 账户的
  外部副作用；相关路径已由上述单元测试以 mock 覆盖，凭证与项目查询已用真实**只读**调用验证。
  首次真实部署建议先 `--dry-run`，再用 `--preview` 试跑，最后 `--prod`。
