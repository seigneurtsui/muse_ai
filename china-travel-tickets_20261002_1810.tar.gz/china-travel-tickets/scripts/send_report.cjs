#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { sendSmtpEmail } = require(path.resolve(__dirname, '..', '..', 'smtp-email', 'index.js'));

function usage() {
  return 'Usage: node send_report.cjs --html report.html --text report.md --subject "主题" [--to recipient@example.com]';
}

function value(argv, index, option) {
  const result = argv[index + 1];
  if (!result || result.startsWith('--')) throw new Error(`${option} requires a value\n${usage()}`);
  return result;
}

function parseArgs(argv) {
  const options = { to: 'gc40800@gmail.com' };
  for (let i = 0; i < argv.length; i += 1) {
    switch (argv[i]) {
      case '--html': options.html = value(argv, ++i, '--html'); break;
      case '--text': options.text = value(argv, ++i, '--text'); break;
      case '--subject': options.subject = value(argv, ++i, '--subject'); break;
      case '--to': options.to = value(argv, ++i, '--to'); break;
      case '--help': case '-h': console.log(usage()); process.exit(0);
      default: throw new Error(`Unknown argument: ${argv[i]}\n${usage()}`);
    }
  }
  for (const key of ['html', 'text', 'subject']) {
    if (!options[key]) throw new Error(`--${key} is required\n${usage()}`);
  }
  return options;
}

(async () => {
  try {
    const options = parseArgs(process.argv.slice(2));
    for (const key of ['html', 'text']) {
      if (!fs.existsSync(options[key])) throw new Error(`File not found: ${options[key]}`);
    }
    const result = await sendSmtpEmail({
      to: options.to,
      subject: options.subject,
      html: fs.readFileSync(options.html, 'utf8'),
      text: fs.readFileSync(options.text, 'utf8'),
    });
    console.log(JSON.stringify({
      success: result.success,
      to: options.to,
      subject: options.subject,
      messageId: result.messageId,
    }, null, 2));
  } catch (error) {
    console.error(`Email send failed: ${error.message}`);
    process.exit(1);
  }
})();
