# Creator Profile Template

This file belongs to one batch or video project's output directory. It is a
template only; never put real creator information into the shared skill.

```markdown
# Creator Profile

## Creator or account name

## Content positioning

## Target audience

## Target publishing platforms

## Writing voice

## Prohibited claims or topics
```

Rules:

- Ask for these fields only when a release package is requested and no profile
  exists for the project.
- Every field is optional and may be left blank or marked `本期不使用`.
- Save only information the user explicitly provides.
- If no profile exists, use a neutral, clear, honest voice and do not invent an
  account identity, audience, platform priority, or brand promise.
