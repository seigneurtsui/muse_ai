#!/bin/bash
# ============================================================
# deploy-subpath.sh — 旅行研究子路径部署 + /toc/ 目录页
#
#   1. 检测所有旅行研究 HTML（子目录 index.html + 根目录 index.html）
#   2. 每个城市存档到 /{slug}/ 子路径
#   3. 生成自包含 /toc/ 目录页（搜索、排序、分页、CSV 导出）
#   4. 部署到 Vercel
#
# 用法:
#   bash deploy-subpath.sh                              # 默认 ~/Downloads/rainman-travel/
#   bash deploy-subpath.sh ~/Downloads/my-travel/       # 指定目录
# ============================================================

set -uo pipefail

# —— 配置 ——
TOKEN_FILE="$HOME/.config/opencode/.env"
[ -f "$TOKEN_FILE" ] && set -a && source "$TOKEN_FILE" && set +a
TOKEN=$(grep -s -o 'VERCEL_TOKEN=[^[:space:]]*' "$TOKEN_FILE" | head -1 | cut -d= -f2-)
SCOPE="seigneurtsuis-projects"
PROJECT="zhongnanshan"
BASE_DIR="${1:-$HOME/Downloads/rainman-travel}"
DEPLOY_DIR="/tmp/rainman-travel-deploy"
PROD_URL="city.allez.cc.cd"

rm -rf "$DEPLOY_DIR"
mkdir -p "$DEPLOY_DIR/toc"

declare -a TRIP_LIST=()
add_trip() {
  local src="$1" slug="$2" name="$3" emoji="$4" tags="$5" date="$6"
  [ -z "$date" ] && date="$TODAY"
  TRIP_LIST+=("$src|$slug|$name|$emoji|$tags|$date")
}

# —— 确保根 index.html 存在 ——
if [ ! -f "$BASE_DIR/index.html" ]; then
  echo "❌ 错误: $BASE_DIR 下缺少 index.html" >&2
  echo "   请先用bash deploy-travel.sh部署" >&2
  exit 1
fi

# —— 标题去重表 ——
declare -A SEEN_TITLES

extract_title() {
  grep -o '<h1[^>]*>[^<]*</h1>' "$1" 2>/dev/null | head -1 | sed 's/<[^>]*>//g' | xargs
}

extract_date() {
  local file="$1"
  local basename="$2"

  # Try filename pattern: YYYYMMDDTHHMMSS==z--...
  if echo "$basename" | grep -qE '^[0-9]{8}T[0-9]{6}==z--'; then
    local raw=$(echo "$basename" | sed -E 's/^([0-9]{4})([0-9]{2})([0-9]{2})T.*/\1-\2-\3/')
    echo "$raw"
    return
  fi

  # Try HTML content: normalize all date formats to YYYY-MM-DD
  local raw=$(grep -oE '(生成日期|📅)[^。<]*' "$file" 2>/dev/null | head -1)
  if [ -n "$raw" ]; then
    # Pattern: YYYY年M月D日 or YYYY年MM月DD日
    local cn=$(echo "$raw" | grep -oE '[0-9]{4}年[0-9]{1,2}月[0-9]{1,2}日')
    if [ -n "$cn" ]; then
      local y=$(echo "$cn" | sed 's/年.*//')
      local rest=$(echo "$cn" | sed 's/^[0-9]\{4\}年//')
      local m=$(echo "$rest" | sed 's/月.*//')
      local d=$(echo "$rest" | sed 's/.*月//; s/日//')
      printf "%04d-%02d-%02d\n" "$y" "$m" "$d"
      return
    fi
    # Pattern: YYYY-MM-DD
    local iso=$(echo "$raw" | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}')
    if [ -n "$iso" ]; then
      echo "$iso"
      return
    fi
  fi

  # Fallback: file modification date (macOS: date -r)
  date -r "$file" +%Y-%m-%d 2>/dev/null || echo "$TODAY"
}

# 1. 从子目录 index.html 自动检测
for dir in "$BASE_DIR"/*/; do
  [ -f "${dir}index.html" ] || continue
  DIRNAME=$(basename "$dir")
  [[ "$DIRNAME" == "toc" || "$DIRNAME" == ".vercel" ]] && continue
  FILESIZE=$(wc -c < "${dir}index.html")
  [ "$FILESIZE" -lt 1000 ] && continue
  SLUG="$DIRNAME"
  TRIP_NAME=$(grep -o '<h1[^>]*>[^<]*</h1>' "${dir}index.html" 2>/dev/null | head -1 | sed 's/<[^>]*>//g' | xargs)
  [ -z "$TRIP_NAME" ] && TRIP_NAME="$DIRNAME"
  EMOJI=$(echo "$TRIP_NAME" | grep -o '[🗺️🏙️🏛️🐼🌶️🍃🏯🌃🌸📜🌉]' | head -1)
  [ -z "$EMOJI" ] && EMOJI="🗺️"
  TAGS=""
  DIR_TITLE=$(extract_title "${dir}index.html")
  if [ -n "$DIR_TITLE" ] && [ -n "${SEEN_TITLES[$DIR_TITLE]:-}" ]; then
    echo "  ⏭️  跳过重复子目录: $DIRNAME"
    continue
  fi
  ALREADY=0
  for entry in "${TRIP_LIST[@]}"; do
    E_SLUG=$(echo "$entry" | cut -d'|' -f2)
    [ "$E_SLUG" == "$SLUG" ] && ALREADY=1 && break
  done
  if [ $ALREADY -eq 0 ]; then
    DIR_DATE=$(extract_date "${dir}index.html" "")
    add_trip "$DIRNAME/index.html" "$SLUG" "$TRIP_NAME" "$EMOJI" "$TAGS" "$DIR_DATE"
    [ -n "$DIR_TITLE" ] && SEEN_TITLES[$DIR_TITLE]="$SLUG"
    echo "📋 /$SLUG/ → $TRIP_NAME ($EMOJI) [dir]"
  fi
done

# 2. 从根目录扁平 HTML 文件自动检测（城市名.html）
for f in "$BASE_DIR"/*.html; do
  [ -f "$f" ] || continue
  BASENAME=$(basename "$f")
  [[ "$BASENAME" == "index.html" ]] && continue
  [[ "$BASENAME" == "index-"* ]] && continue
  [[ "$BASENAME" == *"-email.html" ]] && continue
  [[ "$BASENAME" == *"toc"* ]] && continue

  FILESIZE=$(wc -c < "$f")
  [ "$FILESIZE" -lt 1000 ] && continue

  SLUG="city-$(basename "$f" .html | md5 | head -c 6)"
  TRIP_NAME=$(basename "$f" .html)
  FILE_TITLE=$(extract_title "$f")
  [ -n "$FILE_TITLE" ] && TRIP_NAME="$FILE_TITLE"
  EMOJI=$(echo "$TRIP_NAME" | grep -o '[🗺️🏙️🏛️🐼🌶️🍃🏯🌃🌸📜🌉]' | head -1)
  [ -z "$EMOJI" ] && EMOJI="🗺️"
  TAGS=""

  if [ -n "$FILE_TITLE" ] && [ -n "${SEEN_TITLES[$FILE_TITLE]:-}" ]; then
    echo "  ⏭️  跳过重复: $BASENAME"
    continue
  fi
  ALREADY=0
  for entry in "${TRIP_LIST[@]}"; do
    E_SLUG=$(echo "$entry" | cut -d'|' -f2)
    [ "$E_SLUG" == "$SLUG" ] && ALREADY=1 && break
  done
  if [ $ALREADY -eq 0 ]; then
    FILE_DATE=$(extract_date "$f" "$BASENAME")
    add_trip "$BASENAME" "$SLUG" "$TRIP_NAME" "$EMOJI" "$TAGS" "$FILE_DATE"
    [ -n "$FILE_TITLE" ] && SEEN_TITLES[$FILE_TITLE]="$SLUG"
    echo "📋 /$SLUG/ → $TRIP_NAME ($EMOJI) [file]"
  fi
done

echo ""
echo "📊 共 ${#TRIP_LIST[@]} 个城市研究"

# —— 1. 复制 HTML 到子路径 ——
echo ""
echo "📦 准备子路径..."
for entry in "${TRIP_LIST[@]}"; do
  IFS='|' read -r SRC SLUG TRIP_NAME EMOJI TAGS <<< "$entry"
  mkdir -p "$DEPLOY_DIR/$SLUG"
  cp "$BASE_DIR/$SRC" "$DEPLOY_DIR/$SLUG/index.html"
  echo "  📁 $SLUG/ → $TRIP_NAME"
done

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# —— 2. 生成 /toc/ 目录页（自包含 HTML） ——
echo ""
echo "📄 生成 /toc/ 目录页..."
TODAY=$(date +%Y-%m-%d)

TRIPS_JSON="["
FIRST=1
for entry in "${TRIP_LIST[@]}"; do
  IFS='|' read -r SRC SLUG TRIP_NAME EMOJI TAGS ENTRY_DATE <<< "$entry"
  [ -z "$ENTRY_DATE" ] && ENTRY_DATE="$TODAY"
  [ $FIRST -eq 0 ] && TRIPS_JSON+=","
  FIRST=0
  CLEAN_TITLE=$(echo "$TRIP_NAME" | sed 's/"/\\"/g' | sed "s/'/\\\\'/g")
  CLEAN_TAGS=$(echo "$TAGS" | sed 's/"/\\"/g')
  TRIPS_JSON+="{\"slug\":\"$SLUG\",\"title\":\"$CLEAN_TITLE\",\"date\":\"$ENTRY_DATE\",\"tags\":\"$CLEAN_TAGS\",\"emoji\":\"$EMOJI\",\"title_lower\":\"$(echo "$CLEAN_TITLE" | tr '[:upper:]' '[:lower:]')\"}"
done
TRIPS_JSON+="]"

# 生成卡片 HTML
CARDS_HTML=""
for entry in "${TRIP_LIST[@]}"; do
  IFS='|' read -r SRC SLUG TRIP_NAME EMOJI TAGS ENTRY_DATE <<< "$entry"
  [ -z "$ENTRY_DATE" ] && ENTRY_DATE="$TODAY"
  CLEAN_TITLE=$(echo "$TRIP_NAME" | sed 's/"/\\"/g' | sed "s/'/\\\\'/g")
  CLEAN_TAGS=$(echo "$TAGS" | sed 's/"/\\"/g')
  TAGS_DISP=""
  if [ -n "$TAGS" ]; then
    TAGS_DISP="<div class=\"card-tags\">🏷️ $CLEAN_TAGS</div>"
  fi
  CARDS_HTML+="<a href=\"/$SLUG/\" target=\"_blank\" rel=\"noopener\" class=\"card\" data-title=\"$CLEAN_TITLE\" data-date=\"$ENTRY_DATE\" data-slug=\"$SLUG\" data-tags=\"$CLEAN_TAGS\"><div class=\"card-title\">$EMOJI $CLEAN_TITLE</div>$TAGS_DISP<div class=\"card-meta\">📅 $ENTRY_DATE · 🔗 /$SLUG/</div></a>
"
done

# 从 SKILL 模板目录复制 TOC 页面模板
TOC_SRC="$SKILL_DIR/templates/toc-index.html"
if [ -f "$TOC_SRC" ]; then
  cp "$TOC_SRC" "$DEPLOY_DIR/toc/index.html"
  # 替换模板变量
  python3 -c "
import sys
tpl_path = sys.argv[1]
cards = sys.argv[2]
trips_json = sys.argv[3]
with open(tpl_path, 'r') as f:
    content = f.read()
content = content.replace('{{CARDS}}', cards)
content = content.replace('{{TRIPS_JSON}}', trips_json)
with open(tpl_path, 'w') as f:
    f.write(content)
" "$DEPLOY_DIR/toc/index.html" "$CARDS_HTML" "$TRIPS_JSON"
else
  # 自包含嵌入模板（mountain-climber 模式）
  cat > "$DEPLOY_DIR/toc/index.html" << 'TOCEOF'
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🗺️ 旅行研究目录</title>
<style>
  * { box-sizing: border-box; }
  body {
    margin: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif;
    background: #0a1929; color: #e0e0e0; line-height: 1.6;
    min-height: 100vh; display: flex; flex-direction: column; align-items: center;
    padding: 40px 20px;
  }
  .header { text-align: center; margin-bottom: 32px; }
  .header h1 {
    font-size: 28px; margin: 0 0 8px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  }
  .header p { color: #90a4ae; font-size: 14px; margin: 0; }
  .toolbar {
    display: flex; flex-wrap: wrap; gap: 10px; align-items: center;
    max-width: 960px; width: 100%; margin-bottom: 20px;
  }
  .search-wrapper {
    flex: 1; min-width: 200px; display: flex; align-items: center;
    position: relative;
  }
  .search-box {
    width: 100%; padding: 10px 36px 10px 14px; border-radius: 8px;
    border: 1px solid rgba(255,255,255,0.12); background: rgba(255,255,255,0.05);
    color: #e0e0e0; font-size: 14px; outline: none;
  }
  .search-box:focus { border-color: #667eea; }
  .search-box::placeholder { color: #546e7a; }
  .clear-btn {
    position: absolute; right: 8px; top: 50%; transform: translateY(-50%);
    width: 22px; height: 22px; border-radius: 50%; border: none;
    background: rgba(255,255,255,0.1); color: #90a4ae; font-size: 12px;
    cursor: pointer; display: none; align-items: center; justify-content: center;
    line-height: 1; padding: 0; transition: all .15s;
  }
  .clear-btn:hover { background: rgba(255,255,255,0.2); color: #e0e0e0; }
  .clear-btn.visible { display: flex; }
  .sort-btn {
    padding: 8px 14px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.12);
    background: rgba(255,255,255,0.05); color: #b0bec5; font-size: 13px;
    cursor: pointer; transition: all .2s; white-space: nowrap;
  }
  .sort-btn:hover { background: rgba(255,255,255,0.08); color: #e0e0e0; }
  .sort-btn.active { background: rgba(102,126,234,0.15); color: #a5b4fc; border-color: rgba(102,126,234,0.3); }
  .export-btn {
    padding: 8px 14px; border-radius: 8px; border: 1px solid rgba(245,158,11,0.25);
    background: rgba(245,158,11,0.08); color: #fbbf24; font-size: 13px; font-weight: 600;
    cursor: pointer; transition: all .2s; white-space: nowrap;
  }
  .export-btn:hover { background: rgba(245,158,11,0.18); }
  .result-info { color: #546e7a; font-size: 12px; margin-bottom: 8px; max-width: 960px; width: 100%; }
  .grid {
    display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 16px; max-width: 960px; width: 100%;
  }
  .card {
    display: block; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08);
    border-radius: 12px; padding: 20px; text-decoration: none; color: inherit;
    transition: all .2s;
  }
  .card:hover {
    background: rgba(102,126,234,0.08); border-color: rgba(102,126,234,0.3);
    transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,0.3);
  }
  .card.hidden { display: none; }
  .card-title { font-size: 16px; font-weight: 600; color: #c7d2fe; margin-bottom: 6px; }
  .card-tags { font-size: 12px; color: #78909c; margin-bottom: 4px; }
  .card-meta { font-size: 12px; color: #546e7a; }
  .empty { color: #546e7a; font-size: 14px; text-align: center; padding: 40px; grid-column: 1/-1; display: none; }
  .empty.show { display: block; }
  .pagination {
    display: flex; justify-content: center; align-items: center; gap: 6px;
    margin-top: 24px; max-width: 960px; width: 100%; flex-wrap: wrap;
  }
  .page-btn {
    padding: 8px 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.12);
    background: rgba(255,255,255,0.05); color: #b0bec5; font-size: 13px;
    cursor: pointer; transition: all .2s; min-width: 36px; text-align: center;
  }
  .page-btn:hover { background: rgba(255,255,255,0.08); color: #e0e0e0; }
  .page-btn.active { background: rgba(102,126,234,0.15); color: #a5b4fc; border-color: rgba(102,126,234,0.3); }
  .page-btn:disabled { opacity: 0.3; cursor: not-allowed; }
  .page-info { color: #546e7a; font-size: 13px; padding: 0 2px; letter-spacing: 2px; }
  .footer { margin-top: 48px; text-align: center; color: #455a64; font-size: 12px; }
  .footer a { color: #667eea; text-decoration: none; }
  .footer a:hover { text-decoration: underline; }
  @media (max-width: 640px) {
    body { padding: 20px 12px; }
    .header h1 { font-size: 22px; }
    .grid { grid-template-columns: 1fr; gap: 12px; }
    .card { padding: 16px; }
    .card-title { font-size: 15px; }
    .search-wrapper { min-width: 100%; }
    .search-box { font-size: 16px; }
    .pagination { gap: 4px; }
    .page-btn { padding: 8px; min-width: 34px; font-size: 13px; }
  }
</style>
</head>
<body>
  <div class="header">
    <h1>🗺️ 旅行研究目录</h1>
    <p>城市画像 · 动态维度研究 · 深度知识文档</p>
  </div>
  <div class="toolbar">
    <div class="search-wrapper">
      <input type="text" class="search-box" id="searchBox" placeholder="🔍 搜索城市...">
      <button class="clear-btn" id="clearBtn">✕</button>
    </div>
    <button class="sort-btn active" data-sort="date-desc">最新优先</button>
    <button class="sort-btn" data-sort="date-asc">最早优先</button>
    <button class="sort-btn" data-sort="name-asc">名称 A→Z</button>
    <button class="export-btn" id="exportBtn">📊 导出CSV</button>
  </div>
  <div class="result-info" id="resultInfo"></div>
  <div class="grid" id="grid">
    __CARDS_PLACEHOLDER__
    <div class="empty" id="emptyMsg">未找到匹配的城市</div>
  </div>
  <div class="pagination" id="pagination"></div>
  <div class="footer">
    <p>rainman-travel · 城市画像 · 动态维度研究 · 深度知识文档</p>
    <p style="margin-top:8px;"><a href="/">返回最新研究</a></p>
  </div>

<script>
const PAGE_SIZE = 12;
let currentSort = 'date-desc';
let currentPage = 1;
let filteredCards = [];
const grid = document.getElementById('grid');
const searchBox = document.getElementById('searchBox');
const clearBtn = document.getElementById('clearBtn');
const pagination = document.getElementById('pagination');
const resultInfo = document.getElementById('resultInfo');
const emptyMsg = document.getElementById('emptyMsg');
const allCards = Array.from(grid.querySelectorAll('.card'));

function getCards() {
  const q = searchBox.value.trim().toLowerCase();
  let cards = allCards.filter(c => true);
  if (q) {
    cards = cards.filter(c => {
      const title = (c.getAttribute('data-title') || '').toLowerCase();
      const tags = (c.getAttribute('data-tags') || '').toLowerCase();
      const slug = (c.getAttribute('data-slug') || '').toLowerCase();
      return title.includes(q) || tags.includes(q) || slug.includes(q);
    });
  }
  cards.sort((a, b) => {
    switch (currentSort) {
      case 'date-desc': return (b.dataset.date || '').localeCompare(a.dataset.date || '');
      case 'date-asc': return (a.dataset.date || '').localeCompare(b.dataset.date || '');
      case 'name-asc': return (a.dataset.title || '').localeCompare(b.dataset.title || '');
      default: return 0;
    }
  });
  return cards;
}

function render() {
  filteredCards = getCards();
  const total = filteredCards.length;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  if (currentPage > totalPages) currentPage = totalPages;
  const start = (currentPage - 1) * PAGE_SIZE;
  const end = start + PAGE_SIZE;
  // 模仿 mountain-climber 修复：先隐藏所有卡片，再显示匹配的
  allCards.forEach(c => { c.style.display = 'none'; });
  filteredCards.slice(start, end).forEach(c => { c.style.display = ''; grid.appendChild(c); });
  filteredCards.slice(0, start).forEach(c => grid.appendChild(c));
  filteredCards.slice(end).forEach(c => grid.appendChild(c));
  grid.appendChild(emptyMsg);
  emptyMsg.classList.toggle('show', total === 0);
  if (total > 0) {
    resultInfo.textContent = `显示 ${start + 1}-${Math.min(end, total)} / 共 ${total} 个城市`;
  } else {
    resultInfo.textContent = '';
  }
  renderPagination(totalPages);
}

function renderPagination(totalPages) {
  if (totalPages <= 1) { pagination.innerHTML = ''; return; }
  let html = '';
  const p = currentPage;
  html += `<button class="page-btn" data-page="prev" ${p === 1 ? 'disabled' : ''}>‹</button>`;
  for (let i = 1; i <= totalPages; i++) {
    const isEdge = i === 1 || i === totalPages;
    const near = Math.abs(i - p) <= 1;
    if (isEdge || near) {
      html += `<button class="page-btn${i === p ? ' active' : ''}" data-page="${i}">${i}</button>`;
    } else if (i < p && !(i+1 < p)) {
      html += `<span class="page-info">…</span>`;
    }
  }
  html += `<button class="page-btn" data-page="next" ${p === totalPages ? 'disabled' : ''}>›</button>`;
  pagination.innerHTML = html;
}

function exportCSV() {
  const rows = [['序号', '城市', '性格标签', '日期', '链接']];
  allCards.forEach((c, i) => {
    rows.push([
      i + 1,
      c.dataset.title || '',
      c.dataset.tags || '',
      c.dataset.date || '',
      'https://city.allez.cc.cd/' + (c.dataset.slug || '') + '/'
    ]);
  });
  const csv = rows.map(r => r.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(',')).join('\n');
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = '旅行研究目录.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(a.href);
}

let searchTimer;
function toggleClearBtn() {
  clearBtn.classList.toggle('visible', searchBox.value.length > 0);
}

searchBox.addEventListener('input', () => {
  toggleClearBtn();
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { currentPage = 1; render(); }, 200);
});

clearBtn.addEventListener('click', () => {
  searchBox.value = '';
  toggleClearBtn();
  currentPage = 1;
  render();
  searchBox.focus();
});

document.querySelectorAll('.sort-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentSort = btn.dataset.sort;
    currentPage = 1;
    render();
  });
});

document.getElementById('exportBtn').addEventListener('click', exportCSV);

pagination.addEventListener('click', e => {
  const btn = e.target.closest('.page-btn');
  if (!btn || btn.disabled) return;
  if (btn.dataset.page === 'prev') currentPage--;
  else if (btn.dataset.page === 'next') currentPage++;
  else currentPage = parseInt(btn.dataset.page);
  render();
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

render();
</script>
</body>
</html>
TOCEOF
  echo "  ✅ 已生成自包含 toc/index.html"
fi

# —— 3. 同步根页面到部署目录 ——
if [ -f "$BASE_DIR/index.html" ]; then
  cp "$BASE_DIR/index.html" "$DEPLOY_DIR/index.html"
  echo "  ✅ 根页面 index.html 已同步到部署目录"
else
  echo "  ⚠️  根 index.html 不存在，跳过"
fi

# —— 4. 替换卡片占位符 ——
python3 << PYEOF
import re
with open('$DEPLOY_DIR/toc/index.html', 'r') as f:
    content = f.read()
cards = """$CARDS_HTML"""
if '__CARDS_PLACEHOLDER__' in content:
    content = content.replace('__CARDS_PLACEHOLDER__', cards.strip() + '\n    ')
else:
    content = re.sub(
        r'(<div class="grid" id="grid">)\s*(.*?)\s*(<div class="empty")',
        lambda m: m.group(1) + '\n    ' + cards.strip() + '\n    ' + m.group(3),
        content,
        flags=re.DOTALL
    )
with open('$DEPLOY_DIR/toc/index.html', 'w') as f:
    f.write(content)
print('✅ cards updated')
PYEOF

# —— 5. 部署到 Vercel ——
echo ""
echo "📤 部署到 Vercel..."
cd "$DEPLOY_DIR"
vercel deploy . --prod --token "$TOKEN" --scope "$SCOPE" --project "$PROJECT" -y 2>&1

# —— 6. 清理 ——
cd /
rm -rf "$DEPLOY_DIR"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🎉 全部完成！"
echo "  🌐 https://$PROD_URL"
echo "  📂 目录页: https://$PROD_URL/toc/"
echo "  📊 共 ${#TRIP_LIST[@]} 个城市研究存档"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
