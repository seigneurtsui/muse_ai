"""Release tests only touch private, synthetic temporary dictionaries."""

from __future__ import annotations

import json
import os
from pathlib import Path
import stat
import sys
import tempfile
import unittest
from unittest.mock import patch

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import build_dictionary as builder
import dictionary_releases as releases
from file_support import ErratumError, loads, packed, sha


class FakeConverter:
    info = {"fixture": "release", "profiles": ["t2s", "s2t"]}

    def __init__(self, traditional=None, simplified=None):
        self.trad = {
            "汉错": "漢錯",
            "汉字": "漢字",
            "全神贯注": "全神貫注",
            **(traditional or {}),
        }
        self.simp = {
            "漢錯": "汉错",
            "漢字": "汉字",
            "全神貫注": "全神贯注",
            **(simplified or {}),
        }

    def traditional(self, value):
        return self.trad.get(value, value)

    def simplify(self, value):
        return self.simp.get(value, value)


class ReleaseTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="erratum-release-test-")
        self.addCleanup(self.temp.cleanup)
        # macOS's system temporary path can contain an ancestor symlink.
        self.root = Path(self.temp.name).resolve()
        self.source = self.root / "source.json"
        self.runtime = self.root / "runtime.json"
        self.report = self.root / "report.json"
        self.paths = {
            "source": self.source,
            "runtime": self.runtime,
            "report": self.report,
        }
        self.archive = self.root / "releases"
        self.converter = FakeConverter()
        self.write_fixture()

    def write_fixture(self, data=None, converter=None):
        if converter is not None:
            self.converter = converter
        self.data = (
            data
            if data is not None
            else {"_schema": 1, "_comment": "synthetic", "汉错": "汉字"}
        )
        raw = builder.render(self.data)
        table, report = builder.compile_dictionary(self.data, self.converter, sha(raw))
        runtime = builder.render(table)
        report["runtime_sha256"] = sha(runtime)
        self.original = {
            "source": raw,
            "runtime": runtime,
            "report": builder.render(report),
        }
        for name, path in self.paths.items():
            path.write_bytes(self.original[name])

    def stage(self, pairs=None):
        return releases.stage_release(
            [{"wrong": "乙错", "right": "乙正"}] if pairs is None else pairs,
            self.source,
            self.runtime,
            self.report,
            self.archive,
            converter=self.converter,
        )

    def contents(self):
        return {name: path.read_bytes() for name, path in self.paths.items()}

    def status(self, plan):
        return loads((Path(plan["release_dir"]) / "state.json").read_bytes())["status"]

    def invoke(self, action, plan):
        return action(plan["release_dir"], plan["plan_id"])

    def assert_targets_original(self):
        self.assertEqual(self.contents(), self.original)

    def test_stage_archives_immutable_preview_and_does_not_write_targets(self):
        infos = {name: path.stat() for name, path in self.paths.items()}
        plan = self.stage()
        self.assert_targets_original()
        for name, path in self.paths.items():
            self.assertEqual(path.stat().st_ino, infos[name].st_ino)
            self.assertEqual(path.stat().st_mtime_ns, infos[name].st_mtime_ns)
        self.assertEqual(json.loads(json.dumps(plan, ensure_ascii=False)), plan)
        self.assertEqual(plan["status"], "staged")
        self.assertEqual(plan["preview"]["selected_pairs"], 1)
        self.assertEqual(plan["preview"]["source_rules_added"], 1)
        self.assertEqual(plan["preview"]["runtime_rules_added"], 1)
        self.assertEqual(plan["pairs"], [{"wrong": "乙错", "right": "乙正"}])
        folder = Path(plan["release_dir"])
        self.assertEqual(stat.S_IMODE(folder.stat().st_mode), 0o700)
        self.assertEqual(stat.S_IMODE(self.archive.stat().st_mode), 0o700)
        for phase in ("before", "after"):
            for name in self.paths:
                snapshot = folder / phase / (name + ".json")
                self.assertEqual(sha(snapshot.read_bytes()), plan[phase][name])
                self.assertEqual(stat.S_IMODE(snapshot.stat().st_mode), 0o400)
        self.assertEqual(self.status(plan), "staged")
        self.assertFalse((self.root / ".dictionary-write.lock").exists())

    def test_nested_new_archive_roots_are_fsynced(self):
        self.archive = self.root / "new-parent" / "nested" / "releases"
        with patch.object(releases, "_sync", wraps=releases._sync) as sync:
            plan = self.stage()
        synced = {call.args[0] for call in sync.call_args_list}
        self.assertTrue(
            {
                self.root,
                self.archive.parent.parent,
                self.archive.parent,
                self.archive,
            }.issubset(synced)
        )
        self.invoke(releases.publish_release, plan)
        self.invoke(releases.rollback_release, plan)
        self.assert_targets_original()

    def test_publish_and_rollback_exact_original_bytes_without_converter(self):
        # Deliberately noncanonical formatting is part of the original snapshot.
        data = self.source.read_bytes().rstrip() + b"  \n"
        self.source.write_bytes(data)
        table, report = builder.compile_dictionary(self.data, self.converter, sha(data))
        self.runtime.write_bytes(builder.render(table))
        report["runtime_sha256"] = sha(builder.render(table))
        self.report.write_bytes(builder.render(report))
        self.original = self.contents()
        plan = self.stage()
        with patch.object(
            builder,
            "Converter",
            side_effect=AssertionError("no converter in publication"),
        ):
            published = self.invoke(releases.publish_release, plan)
            self.assertEqual(published["status"], "published")
            self.assertEqual(self.status(plan), "published")
            self.assertEqual(
                {k: sha(v) for k, v in self.contents().items()}, plan["after"]
            )
            self.assertEqual(loads(self.source.read_bytes())["乙错"], "乙正")
            self.assertEqual(loads(self.runtime.read_bytes())["乙错"], "乙正")
            report = loads(self.report.read_bytes())
            self.assertEqual(report["runtime_sha256"], sha(self.runtime.read_bytes()))
            self.assertEqual(
                report["metadata"]["source_sha256"], sha(self.source.read_bytes())
            )
            rolled_back = self.invoke(releases.rollback_release, plan)
        self.assertEqual(rolled_back["status"], "rolled_back")
        self.assertEqual(self.status(plan), "rolled_back")
        self.assert_targets_original()

    def test_pairs_preserve_order_and_unicode_without_normalization(self):
        pairs = [
            {"wrong": "e\u0301误", "right": "é正"},
            {"wrong": "丙错", "right": "丙正"},
        ]
        plan = self.stage(pairs)
        after = loads((Path(plan["release_dir"]) / "after/source.json").read_bytes())
        self.assertEqual(list(after)[-2:], ["e\u0301误", "丙错"])
        self.assertNotIn("é误", after)
        self.assertEqual(plan["pairs"], pairs)

    def test_invalid_duplicate_conflicting_and_noop_pairs_are_rejected(self):
        cases = [
            [],
            {},
            [None],
            [{"wrong": "乙错"}],
            [{"wrong": "乙错", "right": "乙正", "extra": 1}],
            [{"wrong": "", "right": "乙正"}],
            [{"wrong": 1, "right": "乙正"}],
            [{"wrong": "_metadata", "right": "乙正"}],
            [{"wrong": "错" * 101, "right": "正"}],
            [{"wrong": "甲 乙", "right": "正"}],
            [{"wrong": "甲", "right": "正\n"}],
            [{"wrong": "乙错", "right": "乙错"}],
            [{"wrong": "甲\u200b", "right": "乙"}],
            [{"wrong": "甲\ud800", "right": "乙"}],
            [{"wrong": "甲\x7f", "right": "乙"}],
            [{"wrong": "乙错", "right": "乙正"}] * 2,
            [{"wrong": "乙错", "right": "乙正"}, {"wrong": "乙错", "right": "丙正"}],
        ]
        for pairs in cases:
            with self.subTest(pairs=repr(pairs)), self.assertRaises(ErratumError):
                self.stage(pairs)
            self.assert_targets_original()
        self.assertFalse(self.archive.exists())

    def test_already_known_source_runtime_and_conflicting_keys_are_not_releases(self):
        for wrong, right in (("汉错", "汉字"), ("漢錯", "漢字"), ("汉错", "乙正")):
            with self.subTest(wrong=wrong, right=right), self.assertRaisesRegex(
                ErratumError, "already_known|conflicts"
            ):
                self.stage([{"wrong": wrong, "right": right}])
        with self.assertRaisesRegex(ErratumError, "already_known"):
            self.stage(
                [{"wrong": "乙错", "right": "乙正"}, {"wrong": "汉错", "right": "汉字"}]
            )
        self.assert_targets_original()
        self.assertFalse(self.archive.exists())

    def test_review_only_and_existing_script_sensitive_keys_are_rejected(self):
        self.write_fixture(
            {
                "_schema": 1,
                "汉错": "汉字",
                "全神灌注": "全神贯注",
                "_review_only": {
                    "官服": {"right": "官府", "reason": "valid phrase"},
                },
            }
        )
        for wrong, right, code in (
            ("官服", "官府", "review_only"),
            ("全神灌注", "全神贯注", "already_known"),
        ):
            with self.subTest(wrong=wrong), self.assertRaisesRegex(ErratumError, code):
                self.stage([{"wrong": wrong, "right": right}])
        self.assert_targets_original()

    def test_new_script_sensitive_pair_is_preserved_as_ai_only(self):
        plan = self.stage([{"wrong": "全神灌注", "right": "全神贯注"}])
        self.assertEqual(plan["preview"]["runtime_rules_added"], 0)
        self.assertEqual(plan["preview"]["script_sensitive_rules_added"], 1)
        self.invoke(releases.publish_release, plan)
        runtime = loads(self.runtime.read_bytes())
        self.assertNotIn("全神灌注", runtime)
        self.assertEqual(
            runtime["_script_sensitive"]["全神灌注"]["traditional"], "全神貫注"
        )

    def test_compiler_rejects_non_simplified_non_roundtrip_and_cascade_pairs(self):
        engine = FakeConverter({"亲呢": "親呢", "亲昵": "親暱"}, {"親呢": "亲呢"})
        self.write_fixture(converter=engine)
        cases = [
            ("新错", "漢字", "not_simplified"),
            ("亲呢", "亲昵", "roundtrip_requires_review"),
            ("乙错", "前汉错后", "target_triggers"),
        ]
        for wrong, right, error in cases:
            with self.subTest(wrong=wrong), self.assertRaisesRegex(ErratumError, error):
                self.stage([{"wrong": wrong, "right": right}])
        self.assert_targets_original()

    def test_stage_rejects_outdated_source_runtime_and_report(self):
        for name, path in self.paths.items():
            with self.subTest(name=name):
                path.write_bytes(self.original[name] + b" ")
                with self.assertRaisesRegex(ErratumError, "outdated"):
                    self.stage()
                path.write_bytes(self.original[name])
        self.assertFalse(self.archive.exists())

    def test_publish_rejects_any_stale_target_before_writing(self):
        plan = self.stage()
        for name, path in self.paths.items():
            with self.subTest(name=name):
                path.write_bytes(self.original[name] + b"human edit")
                current = self.contents()
                with self.assertRaisesRegex(ErratumError, "target_hash_mismatch"):
                    self.invoke(releases.publish_release, plan)
                self.assertEqual(self.contents(), current)
                self.assertEqual(self.status(plan), "staged")
                path.write_bytes(self.original[name])

    def test_rollback_rejects_newer_edits_and_newer_release(self):
        first = self.stage()
        self.invoke(releases.publish_release, first)
        second = self.stage([{"wrong": "丙错", "right": "丙正"}])
        self.invoke(releases.publish_release, second)
        current = self.contents()
        with self.assertRaisesRegex(ErratumError, "target_hash_mismatch"):
            self.invoke(releases.rollback_release, first)
        self.assertEqual(self.contents(), current)
        self.invoke(releases.rollback_release, second)
        self.runtime.write_bytes(self.runtime.read_bytes() + b"human edit")
        current = self.contents()
        with self.assertRaisesRegex(ErratumError, "target_hash_mismatch"):
            self.invoke(releases.rollback_release, first)
        self.assertEqual(self.contents(), current)

    def fail_target_write(self, plan, action, fail_name):
        write = releases.atomic_write

        def injected(path, raw, replace=False):
            if path == self.paths[fail_name]:
                self.assertIn(
                    self.status(plan), {"publishing", "rolling_back", "recovering"}
                )
                raise OSError("synthetic target write failure")
            return write(path, raw, replace)

        with patch.object(releases, "atomic_write", side_effect=injected):
            with self.assertRaisesRegex(ErratumError, "transition_incomplete"):
                self.invoke(action, plan)

    def test_partial_publish_leaves_durable_intent_and_recovers(self):
        plan = self.stage()
        self.fail_target_write(plan, releases.publish_release, "runtime")
        self.assertEqual(self.status(plan), "publishing")
        self.assertEqual(sha(self.source.read_bytes()), plan["after"]["source"])
        self.assertEqual(self.runtime.read_bytes(), self.original["runtime"])
        self.assertEqual(self.report.read_bytes(), self.original["report"])
        self.assertFalse((self.root / ".dictionary-write.lock").exists())
        result = self.invoke(releases.recover_release, plan)
        self.assertEqual(result["status"], "recovered")
        self.assert_targets_original()
        with self.assertRaisesRegex(ErratumError, "not_staged"):
            self.invoke(releases.publish_release, plan)

    def test_failure_before_first_target_write_can_recover_without_overwriting(self):
        plan = self.stage()
        self.fail_target_write(plan, releases.publish_release, "source")
        self.assert_targets_original()
        self.invoke(releases.recover_release, plan)
        self.assert_targets_original()

    def test_failure_after_replace_before_return_uses_actual_hashes_for_recovery(self):
        plan = self.stage()
        write = releases.atomic_write

        def injected(path, raw, replace=False):
            result = write(path, raw, replace)
            if path == self.runtime:
                raise OSError("synthetic post-replace failure")
            return result

        with patch.object(
            releases, "atomic_write", side_effect=injected
        ), self.assertRaisesRegex(ErratumError, "transition_incomplete"):
            self.invoke(releases.publish_release, plan)
        self.assertEqual(self.status(plan), "publishing")
        self.assertEqual(sha(self.runtime.read_bytes()), plan["after"]["runtime"])
        self.assertEqual(self.report.read_bytes(), self.original["report"])
        self.invoke(releases.recover_release, plan)
        self.assert_targets_original()

    def test_intent_failure_never_changes_dictionary(self):
        plan = self.stage()
        write = releases.atomic_write

        def injected(path, raw, replace=False):
            if path.name == "state.json":
                raise OSError("synthetic intent failure")
            return write(path, raw, replace)

        with patch.object(
            releases, "atomic_write", side_effect=injected
        ), self.assertRaises(OSError):
            self.invoke(releases.publish_release, plan)
        self.assert_targets_original()
        self.assertEqual(self.status(plan), "staged")

    def test_completion_status_failure_still_allows_recovery(self):
        plan = self.stage()
        write = releases.atomic_write

        def injected(path, raw, replace=False):
            if path.name == "state.json" and loads(raw)["status"] == "published":
                raise OSError("synthetic status failure")
            return write(path, raw, replace)

        with patch.object(
            releases, "atomic_write", side_effect=injected
        ), self.assertRaisesRegex(ErratumError, "transition_incomplete"):
            self.invoke(releases.publish_release, plan)
        self.assertEqual(self.status(plan), "publishing")
        self.assertEqual({k: sha(v) for k, v in self.contents().items()}, plan["after"])
        self.invoke(releases.recover_release, plan)
        self.assert_targets_original()

    def test_interrupted_rollback_and_interrupted_recovery_are_recoverable(self):
        plan = self.stage()
        self.invoke(releases.publish_release, plan)
        self.fail_target_write(plan, releases.rollback_release, "runtime")
        self.assertEqual(self.status(plan), "rolling_back")
        self.assertEqual(self.source.read_bytes(), self.original["source"])
        self.fail_target_write(plan, releases.recover_release, "report")
        self.assertEqual(self.status(plan), "recovering")
        self.assertEqual(self.runtime.read_bytes(), self.original["runtime"])
        self.invoke(releases.recover_release, plan)
        self.assert_targets_original()

    def test_recovery_preflights_all_targets_and_does_not_erase_unknown_edit(self):
        plan = self.stage()
        self.fail_target_write(plan, releases.publish_release, "runtime")
        self.report.write_bytes(b"a newer human report edit")
        current = self.contents()
        with self.assertRaisesRegex(ErratumError, "recovery_unknown_target"):
            self.invoke(releases.recover_release, plan)
        self.assertEqual(self.contents(), current)
        self.assertEqual(self.status(plan), "publishing")

    def test_edit_during_publish_is_not_blindly_overwritten_or_rolled_back(self):
        plan = self.stage()
        write = releases.atomic_write

        def injected(path, raw, replace=False):
            result = write(path, raw, replace)
            if path == self.source:
                self.runtime.write_bytes(b"concurrent human bytes")
            return result

        with patch.object(
            releases, "atomic_write", side_effect=injected
        ), self.assertRaisesRegex(ErratumError, "transition_incomplete"):
            self.invoke(releases.publish_release, plan)
        self.assertEqual(self.runtime.read_bytes(), b"concurrent human bytes")
        self.assertEqual(sha(self.source.read_bytes()), plan["after"]["source"])
        self.assertEqual(self.report.read_bytes(), self.original["report"])
        current = self.contents()
        with self.assertRaisesRegex(ErratumError, "unknown_target"):
            self.invoke(releases.recover_release, plan)
        self.assertEqual(self.contents(), current)

    def test_readback_rejects_silent_corruption_and_keeps_recoverable_intent(self):
        plan = self.stage()
        write = releases.atomic_write

        def injected(path, raw, replace=False):
            return write(path, b"corruption" if path == self.source else raw, replace)

        with patch.object(
            releases, "atomic_write", side_effect=injected
        ), self.assertRaisesRegex(ErratumError, "transition_incomplete"):
            self.invoke(releases.publish_release, plan)
        self.assertEqual(self.status(plan), "publishing")
        self.assertEqual(self.runtime.read_bytes(), self.original["runtime"])
        with self.assertRaisesRegex(ErratumError, "unknown_target"):
            self.invoke(releases.recover_release, plan)

    def test_wrong_expected_plan_or_tampered_manifest_and_snapshots_fail_closed(self):
        plan = self.stage()
        folder = Path(plan["release_dir"])
        for expected in (None, "invalid", "0" * 64):
            with self.subTest(expected=expected), self.assertRaises(ErratumError):
                releases.publish_release(folder, expected)
        manifest = folder / "plan.json"
        original = manifest.read_bytes()
        manifest.chmod(0o600)
        data = loads(original)
        data["pairs"][0]["right"] = "不同"
        manifest.write_bytes(packed(data))
        with self.assertRaisesRegex(ErratumError, "plan_hash_mismatch"):
            self.invoke(releases.publish_release, plan)
        manifest.write_bytes(original)
        snapshot = folder / "after/runtime.json"
        snapshot.chmod(0o600)
        snapshot.write_bytes(snapshot.read_bytes() + b" ")
        with self.assertRaisesRegex(ErratumError, "snapshot_hash_mismatch"):
            self.invoke(releases.publish_release, plan)
        self.assert_targets_original()

    def test_lock_is_exclusive_shared_with_stage_publish_and_no_stale_removal(self):
        plan = self.stage()
        lock = self.root / ".dictionary-write.lock"
        with releases.dictionary_lock(self.source):
            self.assertTrue(lock.is_dir())
            with self.assertRaisesRegex(ErratumError, "writer_locked"):
                self.stage()
            with self.assertRaisesRegex(ErratumError, "writer_locked"):
                self.invoke(releases.publish_release, plan)
        self.assertFalse(lock.exists())
        lock.mkdir()
        with self.assertRaisesRegex(ErratumError, "writer_locked"):
            self.invoke(releases.publish_release, plan)
        self.assertTrue(lock.is_dir())
        self.assert_targets_original()

    def test_symlink_lock_is_not_removed(self):
        target = self.root / "elsewhere"
        target.mkdir()
        lock = self.root / ".dictionary-write.lock"
        lock.symlink_to(target, target_is_directory=True)
        with self.assertRaisesRegex(ErratumError, "writer_locked"):
            self.stage()
        self.assertTrue(lock.is_symlink())
        self.assertTrue(target.is_dir())

    def test_target_aliases_links_hardlinks_and_linked_ancestors_rejected(self):
        with self.assertRaisesRegex(ErratumError, "distinct"):
            releases.stage_release(
                [{"wrong": "乙错", "right": "乙正"}],
                self.source,
                self.source,
                self.report,
                self.archive,
                self.converter,
            )
        self.runtime.unlink()
        self.runtime.symlink_to(self.source)
        with self.assertRaisesRegex(ErratumError, "link_or_not_regular"):
            self.stage()
        self.runtime.unlink()
        self.runtime.write_bytes(self.original["runtime"])
        alias = self.root / "hardlinked-source.json"
        os.link(self.source, alias)
        with self.assertRaisesRegex(ErratumError, "link_or_not_regular"):
            self.stage()
        alias.unlink()
        parent_alias = self.root / "alias"
        parent_alias.symlink_to(self.root, target_is_directory=True)
        with self.assertRaisesRegex(ErratumError, "parent_is_link"):
            releases.stage_release(
                [{"wrong": "乙错", "right": "乙正"}],
                parent_alias / self.source.name,
                self.runtime,
                self.report,
                self.archive,
                self.converter,
            )
        self.assert_targets_original()

    def test_archive_must_be_private_separate_and_not_linked(self):
        self.archive.mkdir(mode=0o755)
        self.archive.chmod(0o755)
        with self.assertRaisesRegex(ErratumError, "not_private"):
            self.stage()
        self.archive.rmdir()
        private = self.root / "private"
        private.mkdir(mode=0o700)
        self.archive.symlink_to(private, target_is_directory=True)
        with self.assertRaisesRegex(ErratumError, "parent_is_link"):
            self.stage()
        with self.assertRaisesRegex(ErratumError, "overlaps_targets"):
            releases.stage_release(
                [{"wrong": "乙错", "right": "乙正"}],
                self.source,
                self.runtime,
                self.report,
                self.root,
                self.converter,
            )
        self.assert_targets_original()

    def test_publish_rechecks_target_and_snapshot_links(self):
        plan = self.stage()
        snapshot = Path(plan["release_dir"]) / "after/source.json"
        alias = self.root / "snapshot-alias.json"
        os.link(snapshot, alias)
        with self.assertRaisesRegex(ErratumError, "link_or_not_regular"):
            self.invoke(releases.publish_release, plan)
        alias.unlink()
        self.runtime.unlink()
        self.runtime.symlink_to(self.source)
        with self.assertRaisesRegex(ErratumError, "link_or_not_regular"):
            self.invoke(releases.publish_release, plan)
        self.assertEqual(self.status(plan), "staged")

    def test_bounded_artifacts_and_malformed_json_are_rejected(self):
        self.source.write_bytes(b" " * (builder.LIMIT + 1))
        with self.assertRaisesRegex(ErratumError, "over_limit"):
            self.stage()
        self.source.write_bytes(b'{"_schema":1,"a":"b","a":"c"}')
        with self.assertRaisesRegex(ErratumError, "duplicate_json_key"):
            self.stage()
        self.source.write_bytes(self.original["source"])
        plan = self.stage()
        snapshot = Path(plan["release_dir"]) / "after/source.json"
        snapshot.chmod(0o600)
        snapshot.write_bytes(b" " * (builder.LIMIT + 1))
        with self.assertRaisesRegex(ErratumError, "over_limit"):
            self.invoke(releases.publish_release, plan)
        self.assert_targets_original()

    def test_invalid_state_and_inappropriate_transitions_rejected(self):
        plan = self.stage()
        with self.assertRaisesRegex(ErratumError, "not_published"):
            self.invoke(releases.rollback_release, plan)
        with self.assertRaisesRegex(ErratumError, "not_interrupted"):
            self.invoke(releases.recover_release, plan)
        self.invoke(releases.publish_release, plan)
        with self.assertRaisesRegex(ErratumError, "not_staged"):
            self.invoke(releases.publish_release, plan)
        state = Path(plan["release_dir"]) / "state.json"
        state.write_bytes(
            packed({"version": True, "plan_id": plan["plan_id"], "status": "published"})
        )
        current = self.contents()
        with self.assertRaisesRegex(ErratumError, "invalid_release_status"):
            self.invoke(releases.rollback_release, plan)
        self.assertEqual(self.contents(), current)

    def test_real_opencc_on_synthetic_dictionary_when_installed(self):
        try:
            converter = builder.Converter()
        except builder.BuildError as error:
            self.skipTest(str(error))
        self.write_fixture({"_schema": 1, "汉错": "汉字"}, converter)
        plan = self.stage([{"wrong": "数据备分", "right": "数据备份"}])
        self.invoke(releases.publish_release, plan)
        runtime = loads(self.runtime.read_bytes())
        self.assertEqual(runtime["数据备分"], "数据备份")
        self.assertEqual(runtime["數據備分"], "數據備份")
        self.invoke(releases.rollback_release, plan)
        self.assert_targets_original()


if __name__ == "__main__":
    unittest.main()
