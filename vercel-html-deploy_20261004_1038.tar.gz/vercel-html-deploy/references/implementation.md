# 实现与安全边界

## 架构

1. **输入解析** `specs_from_args` → `DeploymentSpec` 列表：来自 YAML（`load_config`）、
   `discover_specs` 或单目标（`--dir`）。`--only` 按名字过滤。
2. **凭证** `load_env_files` 顺序读取 `--env-file` 与 `~/.config/freebuff/.env`，
   仅在环境变量未设置时写入（真实环境变量优先）；`credentials()` 读取
   `VERCEL_TOKEN`/`VERCEL_API_TOKEN`、`VERCEL_SCOPE`、`VERCEL_PROJECT`、`PROD_URL`。
   Token 只注入 Vercel 子进程命令行，日志用 `masked_command` 掩码，绝不写入报告/状态。
3. **指纹** `input_fingerprint`：
   - static：源文件/目录内容的流式 SHA-256（分块 1 MiB，内存有界），再混入 `prod`；
   - collection：collection 配置字段 + 每个候选文件的相对路径、大小、`mtime_ns`（便宜、稳定）。
4. **跳过决策** `decide_skip`：
   - `--force` → 不跳过；
   - 无历史或上次非成功 → 部署（即失败自动重试）；
   - 上次成功且 `--retry-failed` → `retry_failed_skip`；
   - 上次成功且指纹未变 → `unchanged`。
5. **项目确保** `project_exists` 用 `vercel project ls --filter NAME -F json` 轻量判定，
   缺失且 `create_if_missing` 时 `vercel project add NAME` 创建。
6. **暂存** 在临时目录里组装上传内容，再交给 Vercel：
   - `stage_static`：目录用 `shutil.copytree` 复制（忽略 `.vercel/.git/__pycache__/node_modules`）；
     单文件复制为 `index.html`。
   - `stage_collection`：每个文档复制到 `<staging>/<slug>/index.html`；生成 `<staging>/toc/index.html`
     （`build_toc_html`，卡片 + 搜索/排序/分页/CSV）；`root_mode=latest` 时把日期/标题最大的一篇
     复制为 `<staging>/index.html`。
7. **部署** `vercel deploy <staging> --token … [--scope …] -y [--prod] --project NAME [--archive tgz]`；
   从 stdout/stderr 用 `find_deployment_url`（先尝试 JSON，再正则）提取部署 URL。
8. **并发** `ThreadPoolExecutor(max_workers=jobs)`；`as_completed` 中在主线程合并状态并原子写盘，
   保证崩溃可恢复且无写竞争。单个项目异常被转换为 `failed` 结果，不中断整批。
9. **报告/状态** `_finalize` 汇总；状态文件原子写（临时文件 + `fsync` + `os.replace`）。

## 性能设计

- **内容指纹跳过**：未变更站点完全不走网络，省去整站上传。
- **单项目查询**：`project ls --filter NAME` 避免每次全量列举项目。
- **有界并行**：`--jobs`（默认 auto=min(4,n)，上限 6）让多站点部署重叠进行。
- **流式哈希**：1 MiB 分块，避免大站点占用内存。
- **上传压缩**：默认 `--archive tgz`，减少传输体积；如需可关。
- **collection 轻量指纹**：用 `mtime_ns` 而非内容哈希，避免每次扫描读取全部文档。

## 安全边界

- 只读取用户明确指定的 `--config` / `--dir` / `--discover-root`，不扫描家目录或 Downloads。
- Token 只进子进程命令行，日志掩码为 `***`，绝不写入报告/状态。
- 网络仅限 Vercel CLI 的上传端点与 `vercel project ls/add`。
- 不自动安装依赖、不执行 `vercel login`、不删除项目/域名、不改 DNS 或自定义域名。
- `failed` 的 `detail` 只保留 CLI 输出尾部并截断（600 字符），避免日志爆炸。
- `--dry-run` 不联网、不建项目、不写状态或报告。
- 部署与项目创建属于外部副作用；对生产执行前建议先 `--dry-run`。

## 与源项目的差异

| 方面 | `/tmp/deploy_rainmain_2vercel.py` | 本技能 |
|---|---|---|
| 范围 | rainman-travel 单次部署（写死城市/项目/令牌） | 通用批量，static + collection 两种模式 |
| 凭证 | 脚本内硬编码 token 与 `.env` 路径 | 从 `~/.config/freebuff/.env` 读取，绝不打印 |
| 输入 | 硬编码目录与逻辑 | YAML 配置 + `discover` + 单目标 |
| 跳过 | 无 | 输入指纹跳过 + `--retry-failed` + `--force` |
| 项目存在性 | 无检查 | `project ls --filter` 判定，缺失可自动创建 |
| 并发 | 串行 | `--jobs` 有界并行 |
| 状态写入 | 无/直接覆盖 | 原子写，skip 不降级成功记录 |
| 报告 | 无 | `--json` / `--report` |
| 失败处理 | 抛异常中断 | 单项目隔离为 failed，可断点重试 |

## 尚未实现

- 自定义域名绑定（`vercel domains add`）：需要域名所有权校验，与源项目一致，仅作占位。
- 多 scope 混部：单次运行使用同一 scope（配置文件里可逐项覆盖）。
- 回滚/别名切换（`vercel alias`）：目前依赖 Vercel 生产部署的自动替换。
