# Review Package and Approval Gate

The pipeline uses evidence before irreversible editing decisions. `ffprobe`
derives resolution, orientation, duration, streams, and frame behavior; do not
ask the user for facts that can be measured.

## Review contents

When a review is requested, present one consolidated review containing:

1. source facts and detected VFR/CFR behavior;
2. subtitle corrections and uncertain terms;
3. candidate highlights with source ranges, transcript evidence, and intended
   placement;
4. speed and trim alternatives, including why a silent interval is or is not a
   40x candidate;
5. subtitle languages, style, highlighted terms, badge settings, and output
   canvas;
6. target platforms and any creator-profile constraints when a release package
   is requested.

The user-named moment outranks heuristic scoring, but every cut still obeys
phrase boundaries and final QA.

## Current CLI gate

For a subtitle/badge/render review after the ASS has been generated:

```bash
python3 "$PIPE" <input> --stop-for-review --resume
# inspect each video's review.md, then:
python3 "$PIPE" --resume-batch <batch> --approve-review --resume
```

For `--edit-mode --stop-for-review`, the pipeline instead pauses before encoding
and writes `edit-review.md` plus `edit-plan.json`. The user can edit its `ranges`
to override the selected highlight and per-range speeds. `--approve-review`
reuses this file; saved options are restored from `state.json`.

Without `--stop-for-review`, explicit `--edit-mode` executes the automatic plan;
it records an automatic choice, not a user-approved score. A normal subtitle-only
request does not require an added review gate. Waiting reviews return exit 11
and defer merging, release packaging, and completion notifications.

## Complete preview approval (separate gate)

```bash
python3 "$PIPE" <input> --stop-for-preview --resume
# After AI correction/strategy gates, exit 11 / awaiting_preview means:
# inspect every full preview.mp4 and qa/preview/boundaries/review.md, then approve:
python3 "$PIPE" --resume-batch <batch> --approve-preview
```

This renders the entire output timeline at 720p (vertical 720×1280 or landscape
1280×720; smaller canvases are not enlarged), including subtitles, badges and any
explicitly scripted voiceover. Technical preview QA must pass before approval is
possible. It does not generate this revision's final until approved.

`--approve-review` approves the edit/subtitle strategy only, never the preview.
Both gates may be enabled together. Review approval is retained for unchanged
editing content so resuming at the preview gate does not repeat the strategy gate.
`--approve-preview` accepts all current, valid per-video previews in the batch;
consolidate their paths/checks for one review. Missing, changed or corrupted
previews are regenerated and remain pending, even if approval was on that command.

Approval binds the preview bytes, source, EDL, captions/ASS, output geometry and
mix. Cache-hit bookkeeping alone does not invalidate narration approval. Changes
or `--force-render` need a new approval. Approval flags are transient and never
replayed from saved options. `--no-stop-for-preview` explicitly disables the gate;
`--preview` alone creates evidence but does not wait. Old files may remain on disk
as prior-revision artifacts, but pending state never exposes them as this final.

Full decode and evidence extraction do not prove subjective visual/audio quality.
Review every cut in ±1.5s materials plus start/end/mid samples for flashes, pops,
sync, subtitle safety and intelligibility. Record actual observations in project.md.
After approval, final-file QA and separate boundary materials are still mandatory.
At most three evidence-led fixes are an agent workflow limit, not an automatic
retry loop. See [edit-evidence.md](edit-evidence.md) and [voiceover.md](voiceover.md).

Record the decision in `project.md`, including high-light ranges, speed, body
retention/deletion, subtitle languages, and remaining risks.
