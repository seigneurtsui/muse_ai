# 安装与验证记录

## 当前实测

环境：macOS x86_64、Python 3.12.10。

- macOS 原生后端：Homebrew OpenCC 1.2.0。
- Python 后端：已安装的 `OpenCC` 1.4.1，兼容 `from opencc import OpenCC`。
- 未安装新包，未执行源项目的 Mach-O 程序。

实际执行：

```bash
cd ~/.config/omnirush/skills/s2t
python3 -m unittest discover -s tests -v
python3 -m py_compile scripts/*.py tests/*.py
python3 scripts/chinese_converter_cli.py --doctor
```

**85 项测试通过，0 失败，0 跳过。**
全部脚本与测试通过编译检查及 Python 3.10 语法解析。
Doctor 确认两套本地后端的 s2t/t2s 合成短句转换、CRLF、空白及 emoji 检查均通过。

OmniRush 当前运行时原生 `loadSkillsFromDir` 已识别 `s2t`，没有诊断警告。已有技能目录注册可直接使用，无须更改全局设置。

## 实际合成文件流程

使用技能 `assets/` 下三个合成文档，分别执行：

- `s2t --engine auto`：实际选中 native；3 篇处理，2 篇字节改变、1 篇原样保持。
- `t2s --engine opencc`：实际使用 Python API；3 篇处理，2 篇字节改变、1 篇原样保持。

结果均通过字形/结构检查，无失败或待复核。输出文件读回后的 SHA-256 与报告一致。SRT 的 CRLF 数量、数字台词 `123` 和时间轴原样保留。
合成输出及报告在本机临时目录：
`/var/folders/7v/zvv6rv994qq1fhy6yn2sdkb40000gn/T/s2t-validation-5gghuons/`。
单元测试另含超过通常命令行参数长度限制的大文件实际转换，没有把正文传入子进程参数。

## 覆盖的关键边界

- macOS 原生初始化/运行失败后的 Python fallback；强制选择的后端不静默切换。
- Linux/Windows 不查找或加载 macOS 动态库；Apple Silicon 路径优先级。
- ctypes 参数/指针类型、无效句柄、输出内存释放、关闭异常和重复关闭。
- 首尾空白、混合换行、UTF-8 BOM、UTF-16 BOM、Big5、GB18030、无法编码的字符。
- SRT 数字台词、箭头台词、多行字幕、空字幕、错误序号、错误/倒置时间轴。
- 特征字无证据、按需二次转换、严格拒绝、非严格待复核、切换后端后整篇重跑。
- 单文件、递归布局、隐藏项、嵌套输出排除、原文件保护、符号链接及硬链接。
- 无后端时失败而非复制原文；纯 dry-run 不加载后端、不写入；组合预览真正转换。
- 已有输出和锁、原子写入失败清理、转换中源文件变化、报告写入失败时保留真实逐文件结果。

## 未实测与限制

没有实际 Linux、Windows 或 Apple Silicon 主机运行记录；这些平台的分派逻辑通过 mock 验证，不等同于真实系统文件系统和安装环境验证。
没有安装/单独运行 `opencc-python-reimplemented`；实测的是同 API 的 `OpenCC` 1.4.1。部署到其他平台时仍需可用的 Python 后端，并用 `--doctor` 检查。
Python 3.10 是语法兼容检查，不是该版本解释器的实际全套测试。不同词典版本之间不保证逐短语相同。
原生进程内 C 调用没有子进程超时/崩溃隔离；字形特征计数不是语义正确性的证明；Markdown 不做 AST 或引用资源保护。

源目录 `/tmp/s2t/` 的三个文件哈希核验未变。本任务未转换用户真实文档、读取 `.env`、更改账户设置、联网提交文档或发送通知。

## 安全扫描与源码复核

SkillSpector 2.12.0 使用 `--no-llm` 静态扫描；无额外模型服务。
初次扫描指出未声明文件写入能力（LP1/HIGH）；已在元数据补充实际需要的 `file_write`，并明确限定为用户选择的输出/报告。此声明不是操作系统级权限隔离。

最终扫描：**21/100、MEDIUM、CAUTION、分析完整性 partial**，4 条发现，最高 MEDIUM。不是零发现或完整安全证明。报告保存在 `/tmp/s2t-skill-check.YALBHf/final-scan.json`，未添加抑制规则或基线隐藏发现。

逐项源码判断：

1. **RA2 × 2（MEDIUM）**：普通文本和规范化视图各一次。扫描器把前置信息里的 `file_write` 与下一段安装路径 `~/.config` 跨行匹配为“持久化”。实际是能力声明和既定安装位置，没有 cron、启动脚本、自动加载钩子或全局设置写入代码。运行中落盘的是选定输出目录下的转换结果、报告及临时锁。
2. **AST4（MEDIUM）**：`tests/test_documents.py` 的真实 CLI 集成测试通过 `subprocess.run` 启动当前 Python 解释器及固定的本技能入口。无 shell；参数来自合成测试，文档正文通过 stdin 或临时文件传递。生产转换引擎没有 subprocess 调用。
3. **AST7（LOW）**：`conversion_engines.py` 中 `getattr(library, name)` 用于 ctypes C API 绑定，`name` 只来自固定 OpenCC 函数签名表，不受文档文本、CLI 参数或外部配置控制。

`partial` 的三项原因是说明中的带 `$HOME` 的脚本路径、示例 `article.md` 文件名和运行期 `.s2t.lock` 目录未被解析为静态随包文件；实际 CLI 已在安装目录，后两者分别是命名示例和运行时才建立的锁。复核没有发现隐藏联网、秘密读取、任意 shell 执行或原项目二进制执行。保留 CAUTION 结果及原生库/文件系统边界说明，不将其改称“扫描干净”。
