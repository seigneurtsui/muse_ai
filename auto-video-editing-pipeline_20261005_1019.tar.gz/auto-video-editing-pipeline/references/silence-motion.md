# Silence and Motion Audit

Long silence is not automatically dead footage. A useful UI operation, readable
text, gameplay result, or visible state change must remain at base speed even if
the audio is quiet.

## Run the audit

```bash
python3 "$PIPE" <video-or-directory> --silence-motion --resume
```

Or audit one file directly:

```bash
python3 <skill>/scripts/silence_motion.py \
  --video <video> \
  --out <batch>/videos/<video-id>/qa/silence-motion-report.md
```

The script combines:

- `silencedetect=noise=-35dB:d=10`;
- `freezedetect=n=-50dB:d=8`;
- silent/frozen overlap ratio.

An interval is only marked `eligible_40x` when it is longer than 10 seconds and
at least 80% of the silent interval overlaps a freeze interval. The report is
evidence, not approval. The final 40x decision belongs in the review package.

## Outputs

```text
videos/<video-id>/qa/silence-motion-report.md
videos/<video-id>/qa/silence-motion-report.json
```

Intervals shorter than 10 seconds remain continuous at base speed by default.
Never use 40x inside speech or across an approved subtitle/phrase boundary.
