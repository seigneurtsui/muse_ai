# edge-tts 使用说明

以下命令在本目录运行；也可以把 `tts.py` 替换为技能中 `scripts/tts.py` 的绝对路径。

## 语音合成与 AI 文本处理是两条独立路径

- `sentence`（默认）和 `edge` 仍调用 Microsoft Edge 云端 TTS。`azure` 仍是可选的 Azure Speech 备用方案，使用原有 `AZURE_SPEECH_KEY` / `AZURE_SPEECH_REGION`；这些是**语音服务**配置，不是 LLM 配置。
- 所有 AI 文本任务（语义断句、高亮关键字、字幕翻译、AI 标点）使用**当前 OmniRush 会话的内嵌模型**，通过文件交接完成；脚本本身不调用外部 CLI / API，不读取任何 API Key 或登录凭据。
- 正音表、同音异体替换、OpenCC、字幕样式、动态订阅提示和 TTS 重试保持原有本地处理逻辑。

```bash
pip install edge-tts opencc-python-reimplemented
# 可选：音频拼接
pip install pydub
```

## 已知现有边界

运行时请明确提供 `-o /path/to/output.mp3`。原脚本省略 `-o` 时的关键字输出路径初始化
可能触发 `Path(None)`；此问题早于本次 AI 服务迁移，未在本次改造中修改。
AI 回归与视频配音适配层均显式提供输出路径；离线测试不代表 Edge 云端语音质量已验证。

## AI 文件交接接口与隐私

AI 文本任务不启动任何子进程或网络 API。`_ai_call` 把请求包（`protocol` / `provider` / `request_id` / `system_prompt` / `messages` / `instruction`）写入 AI 工作目录下的 `<request_id>.request.json`，然后抛出 `AIRequestPending` 中断本次运行；调用方（agent）用当前会话的内嵌模型生成回复，写成 `{"text": "..."}` 到同 id 的 `.response.json`，再重跑同一命令，脚本读到响应后继续。

`AIRequestPending` 继承 `BaseException`（而非 `Exception`），所以脚本内部各处 `except Exception` 兜底不会吞掉它，不会静默回退成不完整的 AI 结果。以命令行方式运行时，顶层会打印 request/response 路径并以**退出码 `3`** 结束。

`request_id` 由消息内容哈希得出，相同的请求在重跑时命中同一批文件。请求文件包含提示文本，处理完可自行清理。内嵌模型仍会按当前会话的正常通道联网，发送启用 AI 功能所需的文本并计入同一账户用量；不是离线 LLM。

支持的非密钥配置：

| 环境变量 | 含义 |
|---|---|
| `EDGE_TTS_AI_WORK_DIR` | AI 交接文件目录；缺省为 `<cwd>/.work/ai` |

失败时：语义分段回退本地规则，高亮跳过，AI 标点使用 `--punctuation-fallback`，真正的字幕翻译失败则明确报错，不使用原文冒充译文。中文到简/繁中文仍可由 OpenCC 直接转换，不必调用 LLM。

## 基础语音与双语字幕

```bash
python3 tts.py "你好，欢迎使用语音合成" -o speech.mp3
python3 tts.py -v zh-CN-YunxiNeural -r "+20%" -V "+50%" "调节语音" -o speech.mp3
python3 tts.py -f input.txt --srt --ass --languages zh-Hant,fr -o output.mp3
python3 tts.py -f input.txt --semantic --srt --ass -o output.mp3
```

当前脚本在没有手动关键字输入时会自动尝试 AI 关键字提取，即使不输出 ASS；字幕标点模式默认 `ai`。只做云端 TTS、完全关闭 LLM 调用时使用空关键字文件，不加 `--semantic`，选择本地标点模式及无需 AI 翻译的语言：

```bash
: > empty-keywords.txt
python3 tts.py -f input.txt --highlight-keyword-file empty-keywords.txt \
  --punctuation-mode keep --languages zh-Hant -o output.mp3
```

`zh-Hant` 不需 AI 翻译的前提是输入为中文；非中文转中文仍需要翻译。纯音频不加 `--srt` / `--ass` 时不做字幕翻译。

## 动态订阅提示（ASS）

```bash
# 默认开启，每 5 分钟显示一次“歡迎訂閱”
python3 tts.py -f input.txt --ass -o output.mp3
# 关闭动态提示
python3 tts.py -f input.txt --ass --no-subscribe-overlay -o output.mp3
# 每 3 分钟显示一次
python3 tts.py -f input.txt --ass --subscribe-interval 180 -o output.mp3
# 自定义文字（仍按长度调整位置）
python3 tts.py -f input.txt --ass --subscribe-text "請訂閱我的頻道" -o output.mp3
```

## 语音重试

每个片段默认总共尝试 3 次，间隔 1.5 秒；始终使用同一 TTS provider，保持音色一致。失败的音频会先删除，非空音频文件才算成功。此重试独立于 AI 交接。

```bash
python3 tts.py -f input.txt --tts-retries 5 --tts-retry-delay 3 -o output.mp3
# 仅尝试一次，不重试
python3 tts.py -f input.txt --tts-retries 1 -o output.mp3
```

## 本地正音与字幕保护

```bash
# 默认：现有同音异体正音表
python3 tts.py -f input.txt --pron-fix-mode homophone -o output.mp3
# 原有 normal 正音模式
python3 tts.py -f input.txt --pron-fix-mode normal -o output.mp3
```

正音表不调用 AI。字幕的成对标点保护、中文 OpenCC 字形确认、关键字高亮字体/颜色和双语折行逻辑均保留。手动高亮可用 `--highlight` 或 `--highlight-keyword-file`。

## 离线回归测试

```bash
python3 -B -m unittest discover -s ../tests -v
python3 -B tts.py --help
```

测试只覆盖 AI 文件交接契约与本地逻辑，不发起模型请求或语音合成网络请求，也不读取任何凭据。真实 AI 功能由调用方在当前会话中提供回复。
