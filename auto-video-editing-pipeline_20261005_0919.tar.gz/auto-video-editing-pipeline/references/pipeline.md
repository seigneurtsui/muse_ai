# 批量 Pipeline Contract

## 阶段与幂等性

每个源视频拥有稳定的 `video-id`。状态文件只在输出目录内更新，并记录源文件
SHA-256；源文件发生变化时，旧产物不会被静默复用。

1. `ffprobe`：保存 streams、duration、resolution、fps、audio 和 source hash。
2. `stt`：共享一个 faster-whisper 模型实例处理当前待处理视频，分片结果落到稳定
   job 目录；成功的 chunk 在 `--resume` 时跳过。
3. `erratum`：把原始 SRT 复制到私有 correction input，使用成熟勘误技能；退出码 10
   时暂停，保留 pending request。
4. `s2t`：只对明确的字形目标执行，输出独立的 converted SRT。
5. `ass`：用成熟 srt-ass-studio 生成 ASS，不把字幕正文上传；翻译/AI 高亮只有显式
   参数才开启。
6. `render`：裁切、变速、缩放、音频处理后，最后追加 ASS filter。
7. `qa`：对 preview 和 final 分别做 decode、媒体规格、字幕范围、抽帧和哈希记录。

## 状态原则

- 只读取当前批次中的状态和指定源文件；不扫描用户家目录。
- 原始 SRT/TXT 永不被纠错结果覆盖；纠错结果永远是独立文件。
- 失败视频报告失败，其他视频继续；批次退出码反映失败数量。
- `awaiting_ai` 是可恢复状态，不是失败；恢复必须使用同一 `--resume-batch`。
- 通知失败不会删除或回滚视频产物。

## 输出时间轴

裁切和变速时，字幕 cue 按下式重算：

```text
output_start = (max(cue_start, trim_start) - trim_start) / speed
output_end   = (min(cue_end, trim_end) - trim_start) / speed
```

由于默认 STT 是 phrase-level，自动裁切不应落在 cue 内部。用户指定的 trim 仍需在
预览中检查首尾 ±1.5 秒。
