#!/usr/bin/env node
/**
 * text2video.mjs — Generate a video from a text prompt via Agnes AI (async + poll)
 *
 * Usage:
 *   node text2video.mjs --prompt "A cinematic drone shot of waves at dusk"
 *
 * Options:
 *   --prompt          Text description (required)
 *   --model           Model name (default: agnes-video-v2.0)
 *   --width           Video width (default: 1920)
 *   --height          Video height (default: 1080)
 *   --num-frames      Frame count, 8n+1, ≤441 (default: 241)
 *   --frame-rate      FPS 1–60 (default: 24)
 *   --negative-prompt What to avoid
 *   --image           Image URL for image-to-video
 *   --poll-interval   Seconds between polls (default: 5)
 *   --max-wait        Max seconds to wait (default: 900)
 *   --output          Output filename (auto-generated if omitted)
 *   --dir             Output directory (default: ~/Downloads/text2video)
 *   --no-save         Print the URL but don't download
 */

import { createVideoTask, pollVideoByVideoId, pollVideoByTaskId } from './agnes.mjs';
import { mkdirSync, writeFileSync, statSync } from 'fs';
import { resolve } from 'path';
import { homedir } from 'os';

const DEFAULT_DIR = resolve(homedir(), 'Downloads', 'text2video');

function parseArgs() {
  const args = {};
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i++) {
    if (argv[i].startsWith('--')) {
      const key = argv[i].slice(2).replace(/-/g, '_');
      if (i + 1 < argv.length && !argv[i + 1].startsWith('--')) {
        args[key] = argv[i + 1];
        i++;
      } else {
        args[key] = true;
      }
    }
  }
  return args;
}

function slugify(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 60);
}

async function download(url, dest) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Download failed: ${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  writeFileSync(dest, buf);
  return dest;
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

async function main() {
  const opts = parseArgs();

  if (!opts.prompt && !opts.image) {
    console.error('Usage: node text2video.mjs --prompt "your description" [options]');
    process.exit(1);
  }

  const prompt = opts.prompt || '';
  const model = opts.model || 'agnes-video-v2.0';
  const width = parseInt(opts.width || '3840', 10);
  const height = parseInt(opts.height || '2160', 10);
  const numFrames = parseInt(opts.num_frames || '241', 10);
  const frameRate = parseInt(opts.frame_rate || '24', 10);
  const negativePrompt = opts.negative_prompt || undefined;
  const image = opts.image || undefined;
  const pollInterval = parseInt(opts.poll_interval || '5', 10);
  const maxWait = parseInt(opts.max_wait || '900', 10);
  const outDir = resolve(opts.dir || DEFAULT_DIR);
  const noSave = opts['no_save'] === true;

  // Validate num_frames
  if ((numFrames - 1) % 8 !== 0) {
    console.error(`Error: num_frames must satisfy 8n+1. Got ${numFrames}. Allowed: 81, 121, 161, 241, 441`);
    process.exit(1);
  }

  console.log(`Creating video task...`);
  console.log(`  Model: ${model}`);
  console.log(`  Prompt: ${prompt}`);
  console.log(`  Resolution: ${width}x${height}`);
  console.log(`  Frames: ${numFrames} @ ${frameRate}fps (≈${(numFrames / frameRate).toFixed(1)}s)`);

  const task = await createVideoTask({
    prompt,
    model,
    width,
    height,
    numFrames,
    frameRate,
    negativePrompt,
    image,
  });

  const videoId = task.video_id || task.id;
  const taskId = task.task_id || task.id;
  console.log(`\n  Task created: ${taskId}`);
  console.log(`  Video ID: ${videoId}`);
  console.log(`  Initial status: ${task.status}`);

  // Poll loop — prefer task_id endpoint
  const deadline = Date.now() + maxWait * 1000;
  let result = null;

  while (Date.now() < deadline) {
    await sleep(pollInterval * 1000);

    try {
      if (taskId) {
        result = await pollVideoByTaskId(taskId);
      } else {
        result = await pollVideoByVideoId(videoId);
      }
    } catch (err) {
      console.error(`  Poll error: ${err.message}`);
      continue;
    }

    const status = result.status;
    const progress = result.progress ?? '?';
    process.stdout.write(`  \rStatus: ${status}  [${progress}%]`);

    if (status === 'completed') break;
    if (status === 'failed') {
      console.error(`\n  Failed: ${result.error || 'unknown error'}`);
      process.exit(1);
    }
  }

  if (!result || result.status !== 'completed') {
    console.error(`\n  Timeout after ${maxWait}s. Video ID: ${videoId}`);
    process.exit(1);
  }

  console.log(`\n`);

  // The video URL is in remixed_from_video_id
  const videoUrl = result.remixed_from_video_id || result.video_url;
  if (!videoUrl) {
    console.error('No video URL in response:', JSON.stringify(result, null, 2));
    process.exit(1);
  }

  if (noSave) {
    console.log(`Video URL: ${videoUrl}`);
    return;
  }

  mkdirSync(outDir, { recursive: true });

  const filename = opts.output
    ? (opts.output.endsWith('.mp4') ? opts.output : `${opts.output}.mp4`)
    : `${slugify(prompt || 'video')}-${Date.now()}.mp4`;

  const dest = resolve(outDir, filename);
  await download(videoUrl, dest);

  const mb = statSync(dest).size / (1024 * 1024);
  console.log(`✓ Saved: ${dest} (${mb.toFixed(1)} MB)`);
  console.log(`  Duration: ${result.seconds || '?'}s`);
  console.log(`  Size: ${result.size || '?'}`);
  console.log(`  URL: ${videoUrl}`);
}

main().catch(err => {
  console.error(err.message);
  process.exit(1);
});
