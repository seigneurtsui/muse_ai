#!/bin/bash
# ============================================================
# deploy-travel.sh — 一键部署旅行研究页面到 city.allez.cc.cd
#
# 用法:
#   bash deploy-travel.sh                              # 部署默认目录 ~/Downloads/rainman-travel/
#   bash deploy-travel.sh ~/Downloads/my-travel/       # 部署指定目录
#
# 流程:
#   1. 部署 HTML → Vercel (zhongnanshan 项目)
#   2. city.allez.cc.cd 自动指向最新旅行研究
# ============================================================

set -uo pipefail
export LANG=${LANG:-en_US.UTF-8}
export LC_ALL=${LC_ALL:-en_US.UTF-8}

# —— 配置 ——
VERCEL_TOKEN_FILE="$HOME/.config/opencode/.env"

# —— 如果 .env 不存在则尝试 source ——
[ -f "$VERCEL_TOKEN_FILE" ] && set -a && source "$VERCEL_TOKEN_FILE" && set +a
BASE_DIR="$HOME/Downloads/rainman-travel"
VERCEL_PROJECT="zhongnanshan"
VERCEL_SCOPE="seigneurtsuis-projects"

# —— 从 .env 读取配置 ——
load_env() {
  local key="$1"
  grep -s -o "$key=[^[:space:]]*" "$VERCEL_TOKEN_FILE" | head -1 | cut -d= -f2- || echo ""
}
TOKEN=$(load_env "VERCEL_TOKEN")

# —— 目标目录 ——
TARGET="${1:-$BASE_DIR}"
TARGET="$(cd "$TARGET" 2>/dev/null && pwd || echo "")"

if [ -z "$TARGET" ]; then
  echo "❌ 错误: 目标目录不存在" >&2
  echo "用法: $0 [包含 HTML 文件的目录]" >&2
  echo "  默认: $BASE_DIR" >&2
  exit 1
fi

# —— 查找最新的 HTML 文件 ——
HTML_FILE=""
for f in "$TARGET"/*.html; do
  [ -f "$f" ] && HTML_FILE="$f" && break
done

if [ -z "$HTML_FILE" ]; then
  echo "❌ 错误: 目标目录中没有找到 HTML 文件" >&2
  exit 1
fi

# —— 提取标题 ——
TRIP_TITLE="旅行研究"
H1=$(grep -o '<h1[^>]*>[^<]*</h1>' "$HTML_FILE" 2>/dev/null | head -1 | sed 's/<[^>]*>//g' | xargs)
[ -n "$H1" ] && TRIP_TITLE="$H1"

# —— 创建临时部署目录 ——
DEPLOY_DIR="/tmp/rainman-travel-deploy"
rm -rf "$DEPLOY_DIR"
mkdir -p "$DEPLOY_DIR"

# —— 复制 HTML 到部署目录（重命名为 index.html）——
cp "$HTML_FILE" "$DEPLOY_DIR/index.html"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🗺️  行程: $TRIP_TITLE"
echo "  📂  目录: $TARGET"
echo "  🌐  域名: https://city.allez.cc.cd"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# —— 1. 部署到 Vercel ——
echo ""
echo "📤 部署中..."
vercel deploy "$DEPLOY_DIR" \
  --prod \
  --token "$TOKEN" \
  --scope "$VERCEL_SCOPE" \
  --project "$VERCEL_PROJECT" \
  -y 2>&1 || {
    echo "❌ 部署失败" >&2
    rm -rf "$DEPLOY_DIR"
    exit 1
  }

echo ""
echo "✅ 部署完成 → https://city.allez.cc.cd"

# —— 2. 清理 ——
rm -rf "$DEPLOY_DIR"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🎉 全部完成！"
echo "  🌐 https://city.allez.cc.cd"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
