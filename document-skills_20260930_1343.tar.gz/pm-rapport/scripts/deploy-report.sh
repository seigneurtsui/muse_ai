#!/bin/bash
# deploy-report.sh — 一键部署项目调研页面到 pm.allez.cc.cd
#
# 用法:
#   bash deploy-report.sh                              # 部署默认目录 ~/Downloads/pm-rapport/
#   bash deploy-report.sh ~/Downloads/my-report/       # 部署指定目录

set -uo pipefail
export LANG=${LANG:-en_US.UTF-8}
export LC_ALL=${LC_ALL:-en_US.UTF-8}

TOKEN_FILE="$HOME/.config/opencode/.env"
[ -f "$TOKEN_FILE" ] && set -a && source "$TOKEN_FILE" && set +a
BASE_DIR="$HOME/Downloads/pm-rapport"
VERCEL_PROJECT="shenyang-deploy"
VERCEL_SCOPE="seigneurtsuis-projects"

load_env() {
  local key="$1"
  grep -s -o "$key=[^[:space:]]*" "$TOKEN_FILE" | head -1 | cut -d= -f2- || echo ""
}
TOKEN=$(load_env "VERCEL_TOKEN")

TARGET="${1:-$BASE_DIR}"
TARGET="$(cd "$TARGET" 2>/dev/null && pwd || echo "")"

if [ -z "$TARGET" ]; then
  echo "❌ 错误: 目标目录不存在" >&2
  exit 1
fi

HTML_FILE=""
for f in "$TARGET"/*.html; do
  [ -f "$f" ] && HTML_FILE="$f" && break
done

if [ -z "$HTML_FILE" ]; then
  echo "❌ 错误: 目标目录中没有找到 HTML 文件" >&2
  exit 1
fi

REPORT_TITLE="项目调研"
H1=$(grep -o '<h1[^>]*>[^<]*</h1>' "$HTML_FILE" 2>/dev/null | head -1 | sed 's/<[^>]*>//g' | xargs)
[ -n "$H1" ] && REPORT_TITLE="$H1"

DEPLOY_DIR="/tmp/pm-rapport-deploy"
rm -rf "$DEPLOY_DIR"
mkdir -p "$DEPLOY_DIR"
cp "$HTML_FILE" "$DEPLOY_DIR/index.html"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  📋  项目: $REPORT_TITLE"
echo "  📂  目录: $TARGET"
echo "  🌐  域名: https://pm.allez.cc.cd"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo ""
echo "📤 部署中..."
vercel deploy "$DEPLOY_DIR" \
  --prod \
  --token "$TOKEN" \
  --scope "$VERCEL_SCOPE" \
  --project "$VERCEL_PROJECT" \
  -y 2>&1 || {
    echo "❌ 部署失败" >&2
    rm -rf "$DEPLOY_DIR"
    exit 1
  }

echo ""
echo "✅ 部署完成 → https://pm.allez.cc.cd"
rm -rf "$DEPLOY_DIR"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🎉 全部完成！"
echo "  🌐 https://pm.allez.cc.cd"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
