"""Merge the two Markdown outputs and reuse the sibling inkstone-md MCP client.

No credential discovery, dotenv import, external AI, directory upload or auto retry.
A persisted mutation intent makes an interrupted/ambiguous write require review.
"""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
import uuid

CLIENT = Path(__file__).resolve().parents[2] / "inkstone-md/scripts/inkstone_client_optimized.py"
EBOOK_FOLDER_ID = "01m407exy0s1sa80y44e567ym7"  # User-selected Ebooks folder; generic Inkstone defaults stay unchanged.
MERGED_NAME = "reading_notes.md"
RESULT_NAME = "inkstone_result.json"
RECEIPT_NAME = ".inkstone-submit.json"
DONE = {"submitted", "updated", "already_submitted"}
STATUSES = (*sorted(DONE), "blocked", "uncertain", "local_only", "not_generated")
NOTE_ID = re.compile(r"[A-Za-z0-9_-]{1,128}\Z")


def fingerprint(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def atomic_text(path, text):
    if path.is_symlink():
        raise ValueError("refusing a symlinked output/state file")
    fd, name = tempfile.mkstemp(prefix=".inkstone-write-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        Path(name).unlink(missing_ok=True)


def save_json(path, value):
    atomic_text(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def read_json(path):
    if path.is_symlink():
        raise ValueError("refusing a symlinked state file")
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None


def merge_markdown(book_dir, book_name):
    """Keep source sections intact; never mix in summary.txt or narration."""
    sections = []
    for filename in ("summary.md", "modern_insights.md"):
        path = book_dir / filename
        if path.is_symlink() or not path.is_file():
            raise ValueError("both regular Markdown source files are required")
        text = path.read_text(encoding="utf-8-sig")
        if not text.strip():
            raise ValueError("empty Markdown source")
        if "---summary.txt---" in text or "---summary.md---" in text:
            raise ValueError("unsplit summary response is not a Markdown section")
        sections.append(text)
    title = " ".join(book_name.split()) + "｜摘要与现代启示"
    content = (f"# {title}\n\n## 内容摘要\n\n" + sections[0]
               + "\n\n---\n\n## 现代启示与行动建议\n\n" + sections[1] + "\n")
    target = book_dir / MERGED_NAME
    if target.is_symlink():
        raise ValueError("refusing a symlinked merged document")
    if not target.exists() or target.read_text(encoding="utf-8") != content:
        atomic_text(target, content)
    return target, title, content


def load_client():
    # Importing the installed client reads only INKSTONE_API_KEY from this process.
    # It does not source .env, scan old scripts, or make a network request.
    spec = importlib.util.spec_from_file_location("ebook_inkstone_client", CLIENT)
    if spec is None or spec.loader is None:
        raise ValueError("inkstone-md client unavailable")
    client = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(client)
    return client


def tool(client, name, arguments):
    # Reuse the actual client's MCP transport; inspect MCP errors before decoding
    # (the legacy tool_call helper can treat isError text as ordinary output).
    response = client.mcp_call("tools/call", {"name": name, "arguments": arguments}, request_id=30)
    if not isinstance(response, dict) or response.get("error"):
        raise ValueError("MCP call failed")
    result = response.get("result")
    if not isinstance(result, dict) or result.get("isError"):
        raise ValueError("MCP tool failed")
    value = result.get("structuredContent")
    if value is None:
        for item in result.get("content", []):
            if isinstance(item, dict) and item.get("type") == "text":
                value = json.loads(item.get("text", ""))
                break
    if not isinstance(value, dict):
        raise ValueError("MCP response lacks structured acknowledgement")
    for _ in range(3):
        if value.get("error") or value.get("ok") is False or value.get("success") is False or value.get("status") in ("error", "failed"):
            raise ValueError("MCP operation rejected")
        nested = value.get("data", value.get("note"))
        if not isinstance(nested, dict):
            return value
        value = nested
    raise ValueError("unexpected MCP response nesting")


def note_id(value):
    candidate = value.get("note_id", value.get("id"))
    return candidate if isinstance(candidate, str) and NOTE_ID.fullmatch(candidate) else None


def submit_document(book_dir, title, content):
    """Called under the book lock. Never retry a persisted uncertain mutation."""
    receipt_path = book_dir / RECEIPT_NAME
    client = load_client()
    target = {"service_url": client.BASE_URL, "folder_id": EBOOK_FOLDER_ID, "folder_name": "Ebooks"}
    if not isinstance(target["service_url"], str) or not target["service_url"].startswith("https://") or not target["folder_id"]:
        return {"status": "blocked", "reason": "invalid_default_target"}
    digest = fingerprint(content)
    old = read_json(receipt_path)
    if old is not None:
        if not isinstance(old, dict) or old.get("version") != 1:
            return {**target, "status": "blocked", "reason": "invalid_receipt"}
        if any(old.get(key) != value for key, value in target.items()):
            return {**target, "status": "blocked", "reason": "target_changed_review_required"}
        if old.get("status") != "success":
            return {**target, "status": "uncertain", "reason": "previous_write_requires_review"}
        if not note_id(old) or not isinstance(old.get("content_sha256"), str) or not re.fullmatch(r"[0-9a-f]{64}", old["content_sha256"]):
            return {**target, "status": "blocked", "reason": "invalid_receipt_identity"}
        if old.get("content_sha256") == digest:
            return {**target, "status": "already_submitted", "note_id": old["note_id"]}
    if not client.API_KEY:
        return {**target, "status": "blocked", "reason": "INKSTONE_API_KEY_not_set"}
    if shutil.which("curl") is None:
        return {**target, "status": "blocked", "reason": "curl_unavailable"}

    operation_id = str(uuid.uuid4())
    if old:
        try:
            remote = tool(client, "fetch", {"id": old["note_id"]})
            remote_text = remote.get("text", remote.get("content"))
            rev = remote.get("rev", remote.get("revision"))
            if note_id(remote) not in (None, old["note_id"]):
                raise ValueError("remote identity mismatch")
            if (not isinstance(remote_text, str) or fingerprint(remote_text) != old["content_sha256"]
                    or remote.get("title") != old.get("title")):
                return {**target, "status": "blocked", "reason": "remote_content_changed", "note_id": old["note_id"]}
            if remote.get("folder_id", remote.get("folderId")) not in (None, target["folder_id"]):
                return {**target, "status": "blocked", "reason": "remote_folder_changed", "note_id": old["note_id"]}
            if type(rev) is str and re.fullmatch(r"[0-9]+", rev):
                rev = int(rev)
            if type(rev) is not int or rev < 0:
                raise ValueError("missing remote revision")
        except Exception:
            return {**target, "status": "blocked", "reason": "cannot_verify_remote_revision", "note_id": old["note_id"]}
        operation = "edit_note"
        arguments = {"operation_id": operation_id, "note_id": old["note_id"], "expected_rev": rev,
                     "operation": "replace_all", "text": content, "title": title}
    else:
        operation = "create_note"
        arguments = {"operation_id": operation_id, "title": title, "content": content,
                     "folder_id": target["folder_id"]}
    intent = {"version": 1, **target, "title": title, "content_sha256": digest, "operation_id": operation_id,
              "operation": operation, "status": "in_flight", "note_id": old["note_id"] if old else None}
    if old:
        intent["previous"] = old
    save_json(receipt_path, intent)  # Durable before a possibly non-idempotent write.
    try:
        response = tool(client, operation, arguments)
        acknowledged_id = note_id(response)
        if not acknowledged_id or (old and acknowledged_id != old["note_id"]):
            raise ValueError("missing or mismatched note acknowledgement")
        intent.update(status="success", note_id=acknowledged_id)
        intent.pop("previous", None)
        save_json(receipt_path, intent)
        return {**target, "status": "updated" if old else "submitted", "note_id": acknowledged_id}
    except Exception:
        # The durable in_flight receipt remains, even if reporting fails. A server
        # may have committed before a timeout, invalid response, or local failure.
        return {**target, "status": "uncertain", "reason": "write_outcome_requires_review"}


def process_notes(book_dir, book_name, source_signature, *, submit=True, trusted=True):
    book_dir = Path(book_dir)
    outcome = {"status": "blocked", "reason": "local_preparation_failed", "source_signature": source_signature}
    lock_fd = None
    acquired = False
    try:
        lock_fd = os.open(book_dir / ".inkstone.lock", os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
        fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        acquired = True
        if not trusted:
            outcome["reason"] = "legacy_outputs_need_source_verification"
        else:
            path, title, content = merge_markdown(book_dir, book_name)
            outcome.update(merged_path=str(path), content_sha256=fingerprint(content))
            outcome.pop("reason", None)
            if submit:
                outcome.update(submit_document(book_dir, title, content))
            else:
                outcome.update(status="local_only", reason="explicit_local_only")
    except BlockingIOError:
        return {**outcome, "reason": "another_submission_in_progress"}
    except Exception:
        # Never expose OAuth/HTTP errors, remote response text, or book payloads.
        outcome.update(status="blocked", reason="local_or_client_unavailable")
    finally:
        if lock_fd is not None:
            try:
                if acquired:
                    try:
                        save_json(book_dir / RESULT_NAME, outcome)
                    except (OSError, ValueError):
                        outcome["report_warning"] = "result_file_unavailable"
            finally:
                os.close(lock_fd)
    return outcome


def saved_result(book_dir, source_signature):
    try:
        value = read_json(Path(book_dir) / RESULT_NAME)
        if isinstance(value, dict) and value.get("source_signature") == source_signature and value.get("status") in STATUSES:
            return value
    except (OSError, ValueError):
        pass
    return {"status": "not_generated", "reason": "Markdown_stages_not_completed"}


def submission_counts(results):
    counts = {status: 0 for status in STATUSES}
    for item in results:
        status = item.get("inkstone", {}).get("status", "not_generated")
        counts[status if status in counts else "blocked"] += 1
    counts["complete"] = sum(counts[status] for status in DONE)
    counts["incomplete"] = counts["blocked"] + counts["uncertain"] + counts["not_generated"]
    return counts
