#!/usr/bin/env python3
"""Optional completed-batch notifications via the multiple-channel-notifier CLI.

Default: local preview only. No provider config/secrets are read by this module.
The ebook pipeline stays independent; this command never edits batch_result.json.
"""
import argparse
import fcntl
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

from batch_sumup_ebook import write_json, write_text

NOTIFIER = Path(__file__).resolve().parents[2] / "multiple-channel-notifier/scripts/notify.py"
STATUSES = {"success": "成功", "skipped": "跳过（已有合格稿）", "failed": "失败", "needs_update": "待更新"}
MESSAGE_LIMIT = 3600  # UTF-16 units, including title; leaves room below Telegram's 4096.


def units(text):
    return len(text.encode("utf-16-le")) // 2


def clip(text, limit):
    if units(text) <= limit:
        return text
    kept = text.encode("utf-16-le")[:max(0, limit - 1) * 2].decode("utf-16-le", errors="ignore")
    return kept + "…"


def display(value, limit=180):
    # Book names/paths are data. Neutralize newlines, HTML delimiters and
    # notifier templates ({{...}}), but preserve ordinary path punctuation.
    text = " ".join(str(value).split())
    text = "".join(c for c in text if c.isprintable())
    for char, replacement in zip("{}<>", "｛｝＜＞"):
        text = text.replace(char, replacement)
    return clip(text, limit)


def location(value, limit=300):
    text = str(value)
    home = str(Path.home())
    if text == home or text.startswith(home + os.sep):
        text = "~" + text[len(home):]
    return display(text, limit)


def load_report(path):
    report = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(report, dict) or report.get("status") != "complete":
        raise ValueError("只接受 status=complete 的最终批次结果；等待 AI 或未完成时不可通知")
    results = report.get("results")
    if not isinstance(results, list) or type(report.get("total")) is not int or report["total"] != len(results):
        raise ValueError("批次结果数量不一致")
    for result in results:
        if not isinstance(result, dict) or result.get("status") not in STATUSES:
            raise ValueError("批次包含未完成或未知状态")
        if not isinstance(result.get("book_name"), str):
            raise ValueError("缺少书名")
    for status in STATUSES:
        if type(report.get(status)) is not int or report[status] != sum(r["status"] == status for r in results):
            raise ValueError("批次统计不一致")
    for key in ("source_dir", "output_dir"):
        if not isinstance(report.get(key), str) or not report[key]:
            raise ValueError("批次缺少输入或输出目录")
    return report


def failure_reason(result):
    if result["status"] == "needs_update":
        return "文稿字数、时长或文本质量未达标；详见本地 validation.json"
    error = str(result.get("error", "")).lower()
    for words, reason in (
        (("drm", "加密"), "电子书带 DRM 加密，需可读取的无加密版本"),
        (("ocr", "tesseract"), "扫描 PDF/OCR 提取失败，请检查工具和语言包"),
        (("calibre", "ebook-convert"), "Calibre 缺失或格式转换失败"),
        (("timeout", "超时", "timed out"), "本地处理超时"),
        (("为空", "没有可摘要"), "未提取到可摘要的正文"),
        (("编码", "unicode"), "文本编码无法读取"),
    ):
        if any(word in error for word in words):
            return reason
    return "转换或生成异常；详细错误仅保留在本地 batch_result.json"


def metric(value):
    return str(value) if type(value) in (int, float) and 0 <= value < 1e12 else "未记录"


def book_details(result, index):
    status = result["status"]
    lines = [f"{index}. [{STATUSES[status]}] {display(result['book_name'], 100)}"]
    duration = result.get("duration")
    if isinstance(duration, dict):
        lines.append(f"文稿：{metric(duration.get('char_count'))} 字符；预估 {metric(duration.get('duration_minutes'))} 分钟")
        quality = duration.get("quality")
        quality = quality if isinstance(quality, dict) else {}
        paragraphs = quality.get("paragraph_stats")
        paragraphs = paragraphs if isinstance(paragraphs, dict) else {}
        lines.append(f"中文：{metric(quality.get('chinese_chars'))} 字；段落：{metric(paragraphs.get('paragraph_count'))}；高相似段落对：{metric(quality.get('repeat_pairs'))}")
        valid = duration.get("valid")
        lines.append("校验：" + ("通过" if valid is True else "未通过" if valid is False else "未记录"))
    if status in ("failed", "needs_update"):
        lines.append("原因：" + failure_reason(result))
    if isinstance(result.get("summary_path"), str) and result["summary_path"]:
        lines.append("文稿：" + location(result["summary_path"], 220))
    return "\n".join(lines)


def build_message(report, report_path):
    problem = report["failed"] + report["needs_update"]
    title = "电子书处理结束" + ("｜有失败或待更新项" if problem else "｜完成")
    header = [
        "OmniRush 电子书批次报告",
        f"总计 {report['total']} 本｜成功 {report['success']}｜跳过 {report['skipped']}｜待更新 {report['needs_update']}｜失败 {report['failed']}",
        "范围：转换、摘要、现代启示、播报稿与最终校验已结束；失败项见下文。",
        "输入：" + location(report["source_dir"]),
        "输出：" + location(report["output_dir"]),
    ]
    if not report["total"]:
        header.append("未发现支持的电子书，没有生成文稿。")
    elif report["skipped"] == report["total"]:
        header.append("全部为已有合格稿，本次未重新生成。")
    ending = ("\n\n成功书籍产物：summary.txt、summary.md、modern_insights.md、summary_voice.txt、validation.json。"
              "\n时长按每秒 5.27 字估算；未合成音频。"
              "\n未包含书籍正文、摘要全文、原始日志或密钥。"
              "\n完整报告（本机路径）：" + location(report_path))
    # Failures first. Truncate only the detail list, never hide aggregate failures.
    ordered = sorted(report["results"], key=lambda r: r["status"] not in ("failed", "needs_update"))
    body = "\n".join(header)
    shown = 0
    for index, result in enumerate(ordered, 1):
        detail = "\n\n" + book_details(result, index)
        if units(title + "\n" + body + detail + ending) + 100 > MESSAGE_LIMIT:
            break
        body += detail
        shown += 1
    omitted = len(ordered) - shown
    if omitted:
        body += f"\n\n为适配通知长度，另有 {omitted} 本未逐项展开；统计包含全部书籍，详情见本地报告。"
    body += ending
    if units(title + "\n" + body) > MESSAGE_LIMIT:
        raise ValueError("通知过长；请检查报告路径和统计字段")
    return title, body


def invoke_notifier(title, content_file, channels=None, profile=None, all_enabled=False,
                    config=None, env_file=None, dry_run=True):
    if not NOTIFIER.is_file():
        return {"ok": False, "status": "unavailable", "message": "multiple-channel-notifier 技能未安装"}
    command = [sys.executable, str(NOTIFIER)]
    for flag, value in (("--config", config), ("--env-file", env_file)):
        if value is not None:
            command.extend([flag, str(Path(value).expanduser())])
    command.append("send")
    if channels is not None:
        command.append("--channels=" + channels)
    elif profile is not None:
        command.append("--profile=" + profile)
    elif not all_enabled:
        raise ValueError("必须明确选择通知渠道、分组或全部已启用渠道")
    command.extend(["--title", title, "--content-file", str(content_file)])
    if dry_run:
        command.append("--dry-run")
    try:
        process = subprocess.run(command, capture_output=True, text=True, timeout=600)
        response = json.loads(process.stdout)
        if not isinstance(response, dict) or type(response.get("ok")) is not bool:
            raise ValueError("invalid notifier response")
        if process.returncode and response["ok"]:
            raise ValueError("inconsistent notifier exit code")
        return response  # Mature notifier returns privacy-safe structured diagnostics.
    except subprocess.TimeoutExpired:
        return {"ok": False, "status": "unknown", "message": "通知进程超时；投递状态未知，不自动重发"}
    except (OSError, ValueError, UnicodeError):
        return {"ok": False, "status": "unknown", "message": "通知进程不可用或响应异常；不输出原始日志，不自动重发"}


def notify_report(report_path, mode="preview", channels=None, profile=None, all_enabled=False,
                  config=None, env_file=None):
    if mode not in ("preview", "dry_run", "send"):
        raise ValueError("未知通知模式")
    selections = sum((channels is not None, profile is not None, all_enabled))
    if selections > 1 or (mode != "preview" and selections != 1):
        raise ValueError("演练或发送必须明确选择 --channels、--profile 或 --all-enabled 之一")
    if channels is not None and not re.fullmatch(r"[A-Za-z0-9_-]+(?:,[A-Za-z0-9_-]+)*", channels):
        raise ValueError("渠道参数必须是逗号分隔的实例名")
    report_path = Path(report_path).expanduser().resolve()
    report = load_report(report_path)
    title, content = build_message(report, report_path)
    snapshot = json.dumps(report, ensure_ascii=False, sort_keys=True, allow_nan=False)
    digest = hashlib.sha256(snapshot.encode()).hexdigest()
    directory = report_path.parent / ".ebook-notifications" / digest
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    content_file = directory / "message.txt"
    base = {"ebook_status": "complete", "event_id": digest, "title": title,
            "content_file": str(content_file), "report_path": str(report_path)}
    with (directory / "lock").open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        write_text(content_file, content)
        write_json(directory / "message.json", {"title": title, "content_file": str(content_file), "report_path": str(report_path)})
        if mode == "preview":
            return {**base, "ok": True, "status": "preview", "accepted": 0}
        # Always preflight the exact message through the existing notifier.
        options = dict(config=config, env_file=env_file)
        preflight = invoke_notifier(title, content_file, channels, profile, all_enabled, **options)
        if not preflight["ok"] or preflight.get("status") != "dry_run":
            return {**base, **preflight}
        if mode == "dry_run":
            return {**base, **preflight}
        names = [r["channel"] for r in preflight.get("results", []) if r.get("status") == "ready"]
        if not names:
            raise ValueError("演练没有返回可发送渠道")
        # Scope receipts by config location, not secrets or recipients. Selection
        # changes may add new channels but cannot repeat any previously attempted
        # channel automatically, including failures and uncertain deliveries.
        config_path = str(Path(config or os.environ.get("OMNIRUSH_NOTIFY_CONFIG", str(NOTIFIER.parent.parent / "config.json"))).expanduser().resolve())
        scope = hashlib.sha256(config_path.encode()).hexdigest()
        receipt_path = directory / (scope + ".delivery.json")
        receipt = json.loads(receipt_path.read_text()) if receipt_path.exists() else {"attempted": {}}
        attempted = receipt["attempted"]
        pending = [name for name in names if name not in attempted]
        skipped = [name for name in names if name in attempted]
        if not pending:
            return {**base, "ok": True, "status": "already_attempted", "accepted": 0,
                    "skipped_channels": skipped, "receipt_file": str(receipt_path),
                    "message": "本报告的这些渠道已尝试过；不代表已送达，不自动重发"}
        for name in pending:
            attempted[name] = {"status": "attempting", "message": "attempt recorded before network; delivery may be unknown"}
        write_json(receipt_path, receipt)
        sent = invoke_notifier(title, content_file, channels=",".join(pending), dry_run=False, **options)
        by_name = {r["channel"]: r for r in sent.get("results", [])}
        for name in pending:
            attempted[name] = by_name.get(name, {"status": "unknown", "message": "没有获得逐渠道投递结果；不自动重发"})
        write_json(receipt_path, receipt)
        return {**base, **sent, "skipped_channels": skipped, "receipt_file": str(receipt_path)}


def main(argv=None):
    parser = argparse.ArgumentParser(description="电子书批次完成通知：默认只保存本地预览，不发送")
    parser.add_argument("report", type=Path, help="当前批次 status=complete 的 batch_result.json")
    selection = parser.add_mutually_exclusive_group()
    selection.add_argument("--channels", help="通知技能中的渠道实例名，逗号分隔")
    selection.add_argument("--profile", help="通知技能中已有的分组名")
    selection.add_argument("--all-enabled", action="store_true", help="仅用户明确要求所有已启用渠道时使用")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--dry-run", action="store_true", help="使用现有通知技能离线校验，不联网")
    mode.add_argument("--send", action="store_true", help="明确授权发送；内部先执行同消息演练")
    parser.add_argument("--config", type=Path, help="通知配置覆盖；不修改该文件")
    parser.add_argument("--env-file", type=Path, help="通知密钥文件覆盖；不修改或展示该文件")
    args = parser.parse_args(argv)
    try:
        report = notify_report(args.report, "send" if args.send else "dry_run" if args.dry_run else "preview",
                               args.channels, args.profile, args.all_enabled, args.config, args.env_file)
    except (OSError, ValueError, KeyError, TypeError, UnicodeError):
        report = {"ok": False, "status": "notification_error", "accepted": 0,
                  "message": "通知输入、状态或本地文件异常；仅接受完整批次报告并明确选择渠道。电子书结果未修改。"}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
