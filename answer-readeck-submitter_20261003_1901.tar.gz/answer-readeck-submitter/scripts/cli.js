#!/usr/bin/env node
'use strict';
const { parseArgs } = require('node:util');
const path = require('node:path');
const os = require('node:os');
const { normalizeServiceUrl, PublishError } = require('../lib/transport');
const { run, safeReason } = require('../lib/workflow');
const { resolveEnvironment, DEFAULT_ENV_FILE } = require('../lib/environment');
const HELP = `批量 Markdown → Apache Answer / Readeck（Node.js 22+，无 npm 运行依赖）

用法：
  node scripts/cli.js plan DIRECTORY --platform answer|readeck [选项]
  node scripts/cli.js submit DIRECTORY --platform answer|readeck [选项]
  node scripts/cli.js submit DIRECTORY --platform answer|readeck [选项] --execute --expect-plan PLAN_ID

plan 和未带 --execute 的 submit 都只做本地预览，不登录、不发请求、不启动回抓服务。
实际执行必须使用相同参数重新计算出已审阅的 planId。空目录不会调用平台。

选项：
  --url URL                 实例基础地址（也可用对应平台的环境变量）
  --title-rule heading|filename  前十行首标题或文件名；默认 heading
  --tag TAG                 可重复，覆盖环境变量默认标签
  --no-tags                 明确不附加标签
  --no-recursive            只处理目录第一层；默认递归
  --limit N                 排序后最多处理 N 个文档（1..1000）
  --allow-truncate          明确允许 Answer 正文超过 65000 字符时截断
  --allow-http              明确允许非回环 HTTP（凭据与文档将不加密）
  --state-dir DIR           私有断点目录，必须在输入目录以外
  --env-file FILE           只读配置文件，默认 ~/.config/omnirush/.env
  --no-env-file             只使用进程环境，不读取配置文件
  --continue-on-error       明确拒绝的单篇错误后继续；认证失败/未知写入仍停止
  --timeout-ms N            单次请求上限，默认 30000（100..120000）
  --dry-run                 明确预览，不能与 --execute 同用

Readeck 回抓选项（plan 时也应给全，必须与 execute 一致）：
  --callback-url URL        Readeck 服务端可访问的临时页面源站地址（不含路径前缀）
  --bind ADDRESS            临时服务器监听地址，默认 127.0.0.1
  --port N                  本地监听端口，默认 8900（1..65535）
  --capture-timeout-ms N    等待抓取上限，默认 120000（100..300000）
  --poll-ms N               只读轮询间隔，默认 1000（20..10000）

进程环境优先，缺失值只读所选平台在私有 .env 中的对应变量；从不写回、执行或显示凭据。
没有密码/Token 命令行参数；不自动导入源码中的硬编码值：
  Answer: APACHE_ANSWER_URL, APACHE_ANSWER_EMAIL, APACHE_ANSWER_PASSWORD,
          APACHE_ANSWER_TOKEN（可选，优先于登录）, APACHE_ANSWER_TAG
  Readeck: READECK_URL, READECK_TOKEN, READECK_TAGS, READECK_CALLBACK_URL

只接收 UTF-8 的 .md/.markdown（大小写均可）；不跟随符号链接；跳过隐藏项及 node_modules。
限制：每文件 2 MiB，Readeck 正文 1 MiB / HTML 2 MiB，每批 32 MiB，最多 1000 文件。
串行提交，不自动重试写请求。
断点不更新旧文章；内容变化、未知写入或未完成抓取须人工核对，不盲目再创建。
退出码：0 预览/全部确认完成；1 批次有未完成项；2 参数、配置或本地运行错误。
`;
function integer(value, fallback, min, max) {
  if (value === undefined) return fallback;
  if (!/^\d+$/.test(value) || !Number.isSafeInteger(Number(value)) || Number(value) < min || Number(value) > max) throw new PublishError('invalid_numeric_option');
  return Number(value);
}
function parse(argv, env = process.env) {
  const { values: v, positionals: p } = parseArgs({ args: argv, strict: true, allowPositionals: true, options: {
    help: { type: 'boolean', short: 'h' }, version: { type: 'boolean' }, platform: { type: 'string' }, url: { type: 'string' },
    'title-rule': { type: 'string' }, tag: { type: 'string', multiple: true }, 'no-tags': { type: 'boolean' },
    recursive: { type: 'boolean' }, 'no-recursive': { type: 'boolean' }, limit: { type: 'string' },
    'allow-truncate': { type: 'boolean' }, 'allow-http': { type: 'boolean' }, 'state-dir': { type: 'string' },
    'env-file': { type: 'string' }, 'no-env-file': { type: 'boolean' },
    'continue-on-error': { type: 'boolean' }, 'timeout-ms': { type: 'string' },
    execute: { type: 'boolean' }, 'dry-run': { type: 'boolean' }, 'expect-plan': { type: 'string' },
    'callback-url': { type: 'string' }, bind: { type: 'string' }, port: { type: 'string' },
    'capture-timeout-ms': { type: 'string' }, 'poll-ms': { type: 'string' },
  } });
  if (v.help) return { help: true };
  if (v.version) return { version: true };
  if (p.length !== 2 || !['plan','submit'].includes(p[0]) || !['answer','readeck'].includes(v.platform)) throw new PublishError('command_directory_and_platform_required');
  if ((v.execute && v['dry-run']) || (p[0] === 'plan' && v.execute) || (v.recursive && v['no-recursive']) || (v['no-tags'] && v.tag) || (v['env-file'] && v['no-env-file'])) throw new PublishError('conflicting_options');
  const envFile = path.resolve(v['env-file'] || DEFAULT_ENV_FILE), useEnvFile = !v['no-env-file'];
  const publicNames = v.platform === 'answer' ? ['APACHE_ANSWER_URL','APACHE_ANSWER_TAG'] : ['READECK_URL','READECK_TAGS','READECK_CALLBACK_URL'];
  const publicEnv = resolveEnvironment(publicNames, env, envFile, useEnvFile);
  const titleRule = v['title-rule'] || 'heading';
  if (!['heading','filename'].includes(titleRule)) throw new PublishError('invalid_title_rule');
  const tags = v['no-tags'] ? [] : v.tag || (v.platform === 'answer' ? publicEnv.APACHE_ANSWER_TAG || 'autoNotes' : publicEnv.READECK_TAGS || 'autoNotes').split(',');
  const normalizedTags = [...new Set(tags.map(x => x.trim()))];
  if (normalizedTags.length > 50 || normalizedTags.some(x => !x || x.length > 100 || /[\x00-\x1f\x7f]/.test(x))) throw new PublishError('invalid_tags');
  const callbackUrl = v['callback-url'] || publicEnv.READECK_CALLBACK_URL;
  const allowHttp = !!v['allow-http'];
  // Callback pages contain document content too: non-loopback cleartext is explicit.
  const callback = v.platform === 'readeck' && callbackUrl ? normalizeServiceUrl(callbackUrl, allowHttp) : undefined;
  if (callback && (new URL(callback).pathname !== '/' || ['0.0.0.0','[::]'].includes(new URL(callback).hostname))) throw new PublishError('callback_must_be_reachable_origin_without_prefix');
  if (v.bind && v.bind !== 'localhost' && !require('node:net').isIP(v.bind)) throw new PublishError('invalid_bind_address');
  const stateDir = path.resolve(v['state-dir'] || path.join(env.XDG_STATE_HOME || path.join(os.homedir(), '.local/state'), 'omnirush/answer-readeck-submitter'));
  return {
    command: p[0], directory: p[1], platform: v.platform,
    url: normalizeServiceUrl(v.url || (v.platform === 'answer' ? publicEnv.APACHE_ANSWER_URL : publicEnv.READECK_URL), allowHttp),
    envFile, useEnvFile,
    titleRule, tags: normalizedTags, recursive: !v['no-recursive'], limit: integer(v.limit, undefined, 1, 1000),
    allowTruncate: !!v['allow-truncate'], allowHttp, stateDir, continueOnError: !!v['continue-on-error'],
    execute: !!v.execute, expectPlan: v['expect-plan'], timeoutMs: integer(v['timeout-ms'], 30000, 100, 120000),
    callbackUrl: callback, bind: v.bind || '127.0.0.1', port: integer(v.port, 8900, 1, 65535),
    captureTimeoutMs: integer(v['capture-timeout-ms'], 120000, 100, 300000), pollIntervalMs: integer(v['poll-ms'], 1000, 20, 10000),
  };
}
async function main(argv = process.argv.slice(2)) {
  try {
    const config = parse(argv);
    if (config.help) { console.log(HELP); return 0; }
    if (config.version) { console.log('answer-readeck-submitter 1.0.0'); return 0; }
    const result = await run(config); console.log(JSON.stringify(result.output, null, 2)); return result.exitCode;
  } catch (error) {
    console.log(JSON.stringify({ status: 'error', reason: safeReason(error), message: '未显示凭据或远端原始响应；请检查参数及本地私有报告。' }));
    return 2;
  }
}
if (require.main === module) main().then(code => { process.exitCode = code; });
module.exports = { parse, main };
