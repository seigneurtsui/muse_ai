# AGENTS.md for upload-post

## Workflow

1. Determine target platform(s) and content type (video/photo/text/document).
2. Ask user for Upload-Post API key and profile name if not configured.
3. Select the right endpoint and construct the curl command.
4. Execute and return the result.

## Supported Platforms

| Platform | Videos | Photos | Text | Documents |
|----------|--------|--------|------|-----------|
| TikTok | ✓ | ✓ | - | - |
| Instagram | ✓ | ✓ | - | - |
| YouTube | ✓ | - | - | - |
| LinkedIn | ✓ | ✓ | ✓ | ✓ |
| Facebook | ✓ | ✓ | ✓ | - |
| X (Twitter) | ✓ | ✓ | ✓ | - |
| Threads | ✓ | ✓ | ✓ | - |
| Pinterest | ✓ | ✓ | - | - |
| Reddit | - | ✓ | ✓ | - |
| Bluesky | ✓ | ✓ | ✓ | - |

## References

- `references/platforms.md` — detailed platform parameters
- `references/requirements.md` — media format specs
