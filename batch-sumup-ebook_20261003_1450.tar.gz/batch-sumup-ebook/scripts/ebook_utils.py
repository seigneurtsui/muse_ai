"""Text processing extracted from batch_sumup_ebook.py (default workflow only)."""
import json
import os
import re

CHUNK_SIZE = 6000
TTS_CHARS_PER_SECOND = 5.27
MIN_DURATION_SECONDS = 900
MIN_CHAR_COUNT = int(MIN_DURATION_SECONDS * TTS_CHARS_PER_SECOND)
CHINESE_CHARS = 3500
PARAGRAPH_COUNT = 8
MAX_PARAGRAPH_LEN = 500

def clean_for_tts(text):
    text = re.sub(r"\[chunk_\d+\.txt\]\s*", "", text)
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
    text = re.sub(r"\*(.+?)\*", r"\1", text)
    text = re.sub(r"_(.+?)_", r"\1", text)
    text = re.sub(r"`(.+?)`", r"\1", text)
    text = re.sub(r"~(.+?)~", r"\1", text)
    text = re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", text)
    text = re.sub(r"\{([^}]+)\}", r"\1", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = text.replace("#", "")
    text = text.replace("|", "")
    text = text.replace("•", "，")
    text = text.replace("→", "到")
    text = re.sub(r" {2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = text.replace("语音播报稿", "")
    text = text.replace("各位听众朋友", "")
    text = text.replace("【语音播报版】", "")
    text = re.sub(r"——语音播报稿", "", text)
    text = re.sub(r"本书摘要", "", text)
    text = re.sub(r"内容提要", "", text)
    text = re.sub(r"(\d+)%", lambda m: f"百分之{m.group(1)}", text)
    return text.strip()

def sanitize_voice_output(text):
    text = text.replace("\r\n", "\n").replace("\r", "\n")

    bad_prefixes = [
        "Thinking Process:",
        "Analyze the Request:",
        "Prompt Structure:",
        "Constraint:",
        "Critical Check:",
        "System Instruction:",
        "Plan:",
        "Review against constraints:",
        "Word Count Check",
        "Structure:",
        "Outline:",
        "Let's draft",
        "Now please",
        "Task:",
        "Current Length:",
        "Input Text Analysis:",
        "Safety Check:",
        "Persona:",
        "Critical:",
    ]
    cleaned_lines = []
    for line in text.split("\n"):
        stripped = line.strip()
        if not stripped:
            cleaned_lines.append("")
            continue
        lower = stripped.lower()
        if any(lower.startswith(prefix.lower()) for prefix in bad_prefixes):
            continue
        if stripped.startswith("- ") or stripped.startswith("* "):
            continue
        if re.match(r'^\d+[.)、]\s+', stripped):
            continue
        cleaned_lines.append(line)

    text = "\n".join(cleaned_lines)

    bad_phrases = [
        "Thinking Process:",
        "Analyze the Request:",
        "Prompt Structure:",
        "Review against constraints:",
        "System Instruction:",
    ]
    for phrase in bad_phrases:
        idx = text.lower().find(phrase.lower())
        if idx != -1:
            text = text[:idx]

    text = re.sub(r'```.*?```', '', text, flags=re.S)
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'\[/?[A-Za-z0-9:_-]+\]', '', text)
    text = re.sub(r'(?m)^---.*?---$', '', text)
    text = re.sub(r'(?m)^===.*?===$', '', text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = re.sub(r'[ \t]{2,}', ' ', text)
    return text.strip()

def normalize_for_similarity(text: str) -> str:
    return re.sub('[，。！？；：、""''（）()《》〈〉【】\\s]+', '', text)

def similarity_ratio(a, b):
    a_norm = normalize_for_similarity(a)
    b_norm = normalize_for_similarity(b)
    if not a_norm or not b_norm:
        return 0.0

    a_set = set(a_norm[i:i+3] for i in range(len(a_norm) - 2)) if len(a_norm) >= 3 else {a_norm}
    b_set = set(b_norm[i:i+3] for i in range(len(b_norm) - 2)) if len(b_norm) >= 3 else {b_norm}
    if not a_set or not b_set:
        return 0.0

    inter = len(a_set & b_set)
    union = len(a_set | b_set)
    return inter / union if union else 0.0

def dedupe_paragraphs(text, threshold=0.72):
    paragraphs = [p.strip() for p in text.split("\n") if p.strip()]
    kept = []

    for para in paragraphs:
        duplicated = False
        for old in kept:
            if similarity_ratio(para, old) >= threshold:
                duplicated = True
                break
        if not duplicated:
            kept.append(para)

    return "\n\n".join(kept)

def count_similar_paragraph_pairs(text, threshold=0.78):
    paragraphs = [p.strip() for p in text.split("\n") if p.strip()]
    count = 0
    for i in range(len(paragraphs)):
        for j in range(i + 1, len(paragraphs)):
            if similarity_ratio(paragraphs[i], paragraphs[j]) >= threshold:
                count += 1
    return count

def split_long_paragraph(paragraph, min_len=80, max_len=180):
    paragraph = paragraph.strip()
    if len(paragraph) <= max_len:
        return [paragraph] if paragraph else []

    parts = []
    remaining = paragraph
    cut_marks = "。！？；"

    while len(remaining) > max_len:
        window = remaining[:max_len]
        cut_pos = max(window.rfind(mark) for mark in cut_marks)
        if cut_pos < min_len:
            comma_pos = max(window.rfind(","), window.rfind("："))
            cut_pos = comma_pos if comma_pos >= min_len else max_len - 1
        part = remaining[:cut_pos + 1].strip()
        if part:
            parts.append(part)
        remaining = remaining[cut_pos + 1:].strip()

    if remaining:
        parts.append(remaining)
    return parts

def reflow_voice_paragraphs(text, min_len=80, max_len=180):
    raw_paragraphs = [p.strip() for p in re.split(r'\n\s*\n+', text) if p.strip()]
    normalized = []

    for para in raw_paragraphs:
        para = re.sub(r'\s+', '', para)
        normalized.extend(split_long_paragraph(para, min_len=min_len, max_len=max_len))

    normalized = [p.strip() for p in normalized if p.strip()]
    return "\n\n".join(normalized)

def paragraph_stats(text):
    paragraphs = [p.strip() for p in re.split(r'\n\s*\n+', text) if p.strip()]
    lengths = [len(p) for p in paragraphs]
    return {
        "paragraph_count": len(paragraphs),
        "max_paragraph_len": max(lengths) if lengths else 0,
        "min_paragraph_len": min(lengths) if lengths else 0,
        "avg_paragraph_len": round(sum(lengths) / len(lengths), 1) if lengths else 0,
    }

def validate_voice_text_content(text):
    issues = []
    if re.search(r'Thinking Process|Analyze the Request|Prompt Structure|Requirements?|System Instruction|Review against constraints', text, re.I):
        issues.append("包含模型推理或提示词回声")
    english_blocks = re.findall(r'[A-Za-z]{3,}', text)
    if len(english_blocks) > 20:
        issues.append("英文内容过多")
    if re.search(r'^\s*#|^\s*[-*]\s+|^\s*\d+[.)、]\s+', text, re.M):
        issues.append("仍含标题或列表结构")
    chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', text))
    if chinese_chars < CHINESE_CHARS:
        issues.append("中文正文疑似不足")
    repeat_pairs = count_similar_paragraph_pairs(text, threshold=0.78)
    if repeat_pairs >= 3:
        issues.append(f"存在较明显段落重复：{repeat_pairs} 组")
    pstats = paragraph_stats(text)
    if pstats["paragraph_count"] < PARAGRAPH_COUNT:
        issues.append(f"段落数量偏少：{pstats['paragraph_count']} 段")
    if pstats["max_paragraph_len"] > MAX_PARAGRAPH_LEN:
        issues.append(f"存在过长段落：最长 {pstats['max_paragraph_len']} 字")
    return {
        "valid": len(issues) == 0,
        "issues": issues,
        "chinese_chars": chinese_chars,
        "repeat_pairs": repeat_pairs,
        "paragraph_stats": pstats,
    }

def estimate_duration(text):
    clean = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
    clean = re.sub(r"\*(.+?)\*", r"\1", clean)
    clean = re.sub(r"`(.+?)`", r"\1", clean)
    clean = re.sub(r"#+ ", "", clean)
    clean = re.sub(r"\n{2,}", "\n", clean)
    char_count = len(clean.replace("\n", "").replace(" ", ""))
    duration_seconds = char_count / TTS_CHARS_PER_SECOND
    duration_minutes = duration_seconds / 60
    return {
        "char_count": char_count,
        "duration_seconds": round(duration_seconds, 1),
        "duration_minutes": round(duration_minutes, 1),
        "meets_requirement": duration_seconds >= MIN_DURATION_SECONDS,
    }

def split_by_chapters(text):
    patterns = [
        r"^(第\s*[一二三四五六七八九十百千零〇两\d]+\s*[章节篇部])\s*(.*)",
        r"^(Chapter\s+\d+[.:：]?\s*.*)",
        r"^(CHAPTER\s+\d+[.:：]?\s*.*)",
        r"^(\d+[.:：]\s*.+)",
        r"^(Part\s+\d+[.:：]?\s*.*)",
    ]
    combined = "|".join(f"({p})" for p in patterns)
    lines = text.split("\n")
    chapters = []
    current_title = "前言/引言"
    current_content = []
    for line in lines:
        stripped = line.strip()
        if stripped and re.match(combined, stripped, re.MULTILINE):
            if current_content:
                chapters.append(
                    {"title": current_title, "content": "\n".join(current_content)}
                )
            current_title = stripped
            current_content = []
        else:
            if stripped:
                current_content.append(line)
    if current_content:
        chapters.append(
            {"title": current_title, "content": "\n".join(current_content)}
        )
    return chapters

def split_long_chapter(chapter, chunk_size):
    """Keep line boundaries where possible, but also split very long single lines."""
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    content = chapter["content"]
    if len(content) <= chunk_size:
        return [chapter]
    chunks = []
    while content:
        end = min(len(content), chunk_size)
        if end < len(content):
            boundary = content.rfind("\n", 0, end + 1)
            if boundary > chunk_size // 2:
                end = boundary
        chunks.append({
            "title": f"{chapter['title']} (第{len(chunks) + 1}部分)",
            "content": content[:end],
        })
        content = content[end:]
        if content.startswith("\n"):
            content = content[1:]
    return chunks


def build_chunks(txt_path, book_name, output_dir, chunk_size=CHUNK_SIZE):
    with open(txt_path, "r", encoding="utf-8") as f:
        full_text = f.read()
    total_chars = len(full_text)
    chapters = split_by_chapters(full_text)
    if len(chapters) <= 1:
        chapters = [{"title": "全文", "content": full_text}]
    all_chunks = []
    for ch in chapters:
        all_chunks.extend(split_long_chapter(ch, chunk_size))
    chunk_dir = os.path.join(output_dir, "chunks")
    os.makedirs(chunk_dir, exist_ok=True)
    chunk_files = []
    for i, ch in enumerate(all_chunks, 1):
        chunk_path = os.path.join(chunk_dir, f"chunk_{i:03d}.txt")
        with open(chunk_path, "w", encoding="utf-8") as f:
            f.write(f"===== {book_name} — {ch['title']} =====\n\n")
            f.write(ch["content"])
        chunk_files.append(
            {
                "id": i,
                "title": ch["title"],
                "path": chunk_path,
                "chars": len(ch["content"]),
            }
        )
    manifest = {
        "book_name": book_name,
        "total_chars": total_chars,
        "total_chapters": len(chapters),
        "total_chunks": len(all_chunks),
        "chunk_size": chunk_size,
        "chunks": chunk_files,
    }
    manifest_path = os.path.join(output_dir, "manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    return manifest
