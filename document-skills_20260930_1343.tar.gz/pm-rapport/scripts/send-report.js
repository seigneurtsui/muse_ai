#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const SKILL_DIR = path.join(__dirname, '..');
const WATER_TEMPLATE_PATH = path.join(SKILL_DIR, 'templates', 'water.css.html');

// Try to load marked from various locations
let marked;
try {
  marked = require('marked');
} catch {
  // Install marked on the fly
  const installDir = path.join(SKILL_DIR, 'node_modules');
  if (!fs.existsSync(installDir)) {
    fs.mkdirSync(installDir, { recursive: true });
    execSync('npm install marked', { cwd: SKILL_DIR, stdio: 'pipe' });
  }
  marked = require('marked');
}

function slugify(text) {
  return text
    .replace(/[`*_~]/g, '')
    .trim()
    .toLowerCase()
    .replace(/[^\w\u4e00-\u9fff]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

marked.use({
  renderer: {
    heading({text, depth}) {
      const id = slugify(text);
      return `<h${depth} id="${id}">${text}</h${depth}>`;
    }
  }
});

marked.setOptions({ breaks: true, gfm: true });

function loadTemplate(templatePath) {
  return fs.readFileSync(templatePath, 'utf8');
}

function generateToc(mdContent) {
  const lines = mdContent.split('\n');
  const headings = [];

  for (const line of lines) {
    const match = line.match(/^(#{1,4})\s+(.+)$/);
    if (!match) continue;
    const level = match[1].length;
    if (level > 4) continue;
    const text = match[2].replace(/[`*_~]/g, '').trim();
    const anchor = slugify(text);
    headings.push({level, text, anchor});
  }

  function parseFrom(idx, maxLevel) {
    const result = [];
    while (idx < headings.length && headings[idx].level > maxLevel) {
      const h = headings[idx];
      const {children, nextIdx} = parseFrom(idx + 1, h.level);
      result.push({...h, children});
      idx = nextIdx;
    }
    return {children: result, nextIdx: idx};
  }

  function renderNodes(nodes) {
    if (!nodes || nodes.length === 0) return '';
    let html = '<ul>\n';
    for (const node of nodes) {
      html += `<li><a href="#${node.anchor}">${node.text}</a>`;
      if (node.children && node.children.length > 0) {
        html += '\n' + renderNodes(node.children) + '\n';
      }
      html += '</li>\n';
    }
    html += '</ul>';
    return html;
  }

  const {children} = parseFrom(0, 0);
  return renderNodes(children);
}

function convertMdToHtml(mdContent) {
  mdContent = mdContent.replace(/```[\s\S]*?```/g, '');
  mdContent = mdContent.replace(/^\+.*$/gm, '');

  let html = marked.parse(mdContent);

  html = html.replace(/<table/g, '<div class="table-wrapper"><table');
  html = html.replace(/<\/table>/g, '</table></div>');

  return html;
}

function extractTitle(mdContent, filePath) {
  const titleMatch = mdContent.match(/^#\s+(.+)/m);
  if (titleMatch) return titleMatch[1].trim();

  const subtitleMatch = mdContent.match(/^##\s+([^\n]+)/m);
  if (subtitleMatch) return subtitleMatch[1].trim();

  if (filePath) {
    const fn = path.basename(filePath, '.md');
    const project = fn.replace(/^[\dTZ==]+--?/, '').replace(/-调研报告$/, '').replace(/-/g, '');
    return project || '项目调研报告';
  }
  return '项目调研报告';
}

function extractTags(mdContent) {
  const lines = mdContent.split('\n');
  let tags = ['项目调研', '市场分析', '商业研究'];

  for (const line of lines) {
    if (line.includes('#+filetags:')) {
      const match = line.match(/#\+filetags:\s*(:[^:]+(?::[^:]+)*:)/);
      if (match) {
        const rawTags = match[1].split(':').filter(t => t.trim());
        if (rawTags.length > 0) {
          tags = rawTags.map(t => t.trim());
        }
      }
      break;
    }
  }

  return tags.map(t => `<span class="tag">${t}</span>`).join('');
}

function extractSubtitle(mdContent) {
  const cleanContent = mdContent.replace(/```[\s\S]*?```/g, '');
  const match = cleanContent.match(/^##\s+([^\n]+)/m);
  if (match) return match[1].trim();
  return '系统化市场调研与商业分析';
}

function getProjectEmoji(mdContent) {
  return '📋';
}

function buildHtml(mdContent, filePath) {
  const template = loadTemplate(WATER_TEMPLATE_PATH);
  const contentHtml = convertMdToHtml(mdContent);
  const title = extractTitle(mdContent, filePath);
  const tags = extractTags(mdContent);
  const subtitle = extractSubtitle(mdContent);
  const emoji = getProjectEmoji(mdContent);
  const date = new Date().toLocaleDateString('zh-CN', {
    year: 'numeric', month: 'long', day: 'numeric'
  });

  const tocHtml = generateToc(mdContent);

  let html = template
    .replace(/\{\{TITLE\}\}/g, title)
    .replace(/\{\{EMOJI\}\}/g, emoji)
    .replace(/\{\{SUBTITLE\}\}/g, subtitle)
    .replace(/\{\{TAGS\}\}/g, tags)
    .replace(/\{\{CONTENT\}\}/g, contentHtml)
    .replace(/\{\{DATE\}\}/g, date)
    .replace(/\{\{TOC\}\}/g, tocHtml);

  return html;
}

// CLI
if (require.main === module) {
  const args = process.argv.slice(2);
  let mdPath = '';

  for (const arg of args) {
    if (!mdPath && !arg.startsWith('--')) {
      mdPath = arg.replace(/^~/, process.env.HOME || '');
    }
  }

  if (!mdPath) {
    console.log('用法: node send-report.js <md文件路径>');
    console.log('');
    console.log('  示例:');
    console.log('    node send-report.js ~/Downloads/pm-rapport/my-report.md');
    process.exit(1);
  }

  if (!fs.existsSync(mdPath)) {
    console.error('错误: 文件不存在:', mdPath);
    process.exit(1);
  }

  const mdContent = fs.readFileSync(mdPath, 'utf8');
  const html = buildHtml(mdContent, mdPath);
  const htmlPath = mdPath.replace(/\.md$/, '.html');
  fs.writeFileSync(htmlPath, html);
  console.log(`✅ HTML: ${htmlPath}`);
}

module.exports = { buildHtml };
