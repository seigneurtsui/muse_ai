#!/usr/bin/env python3
"""Render one immutable source video and burn ASS subtitles as the last visual step."""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path


def probe(path: Path) -> dict:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)],
        capture_output=True, text=True, check=True,
    )
    return json.loads(result.stdout)


def atempo_chain(speed: float) -> str:
    if speed <= 0:
        raise ValueError("speed must be greater than zero")
    factors: list[str] = []
    remaining = speed
    while remaining > 2.0:
        factors.append("atempo=2")
        remaining /= 2.0
    while remaining < 0.5:
        factors.append("atempo=0.5")
        remaining /= 0.5
    factors.append(f"atempo={remaining:.7f}")
    return ",".join(factors)


def ff_filter_path(path: Path) -> str:
    return str(path.resolve()).replace("\\", "\\\\").replace(":", r"\:").replace("'", r"\'").replace(",", r"\,")


def even(value: int) -> int:
    return max(2, value if value % 2 == 0 else value - 1)


def render(args: argparse.Namespace) -> dict:
    source = args.source.expanduser().resolve()
    subtitle = args.subtitle.expanduser().resolve() if args.subtitle else None
    output = args.output.expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(source)
    if output == source:
        raise ValueError("output must not overwrite source")
    media = probe(source)
    stream = next((s for s in media.get("streams", []) if s.get("codec_type") == "video"), None)
    if not stream:
        raise ValueError("source has no video stream")
    source_width, source_height = int(stream["width"]), int(stream["height"])
    width = args.width or source_width
    height = args.height or source_height
    if args.preview:
        scale = min(1.0, 720 / max(width, height))
        width, height = even(round(width * scale)), even(round(height * scale))
    width, height = even(width), even(height)
    speed = float(args.speed)
    trim_start = max(0.0, float(args.trim_start))
    trim_duration = None
    if args.trim_end is not None:
        trim_duration = float(args.trim_end) - trim_start
        if trim_duration <= 0:
            raise ValueError("trim-end must be greater than trim-start")

    video_filter = (
        f"fps={args.fps},scale={width}:{height}:force_original_aspect_ratio=decrease:flags=lanczos,"
        f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,setpts=(PTS-STARTPTS)/{speed:.8f}"
    )
    if subtitle:
        if not subtitle.is_file():
            raise FileNotFoundError(subtitle)
        video_filter += f",ass={ff_filter_path(subtitle)}"

    audio_stream = next((s for s in media.get("streams", []) if s.get("codec_type") == "audio"), None)
    command = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error"]
    if trim_start:
        command += ["-ss", f"{trim_start:.6f}"]
    if trim_duration is not None:
        # Input-side duration keeps slow-motion output from being truncated.
        command += ["-t", f"{trim_duration:.6f}"]
    command += ["-i", str(source)]
    command += ["-map", "0:v:0", "-vf", video_filter]
    if audio_stream:
        audio_filter = f"asetpts=PTS-STARTPTS,{atempo_chain(speed)}"
        if args.loudnorm:
            audio_filter += ",loudnorm=I=-16:LRA=11:TP=-1.5"
        command += ["-map", "0:a:0?", "-af", audio_filter, "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2"]
    else:
        command += ["-an"]
    command += [
        "-c:v", "libx264", "-preset", args.preset,
        "-crf", str(args.preview_crf if args.preview else args.crf),
        "-pix_fmt", "yuv420p", "-movflags", "+faststart",
    ]
    output.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".render-", suffix=".mp4", dir=str(output.parent))
    os.close(fd)
    temporary_path = Path(temporary)
    try:
        completed = subprocess.run(command + [str(temporary_path)], capture_output=True, text=True)
        if completed.returncode != 0:
            raise RuntimeError(completed.stderr[-4000:] or "ffmpeg render failed")
        if not temporary_path.is_file() or temporary_path.stat().st_size == 0:
            raise RuntimeError("ffmpeg produced an empty output")
        os.replace(temporary_path, output)
    finally:
        temporary_path.unlink(missing_ok=True)
    return {
        "source": str(source), "output": str(output), "subtitle": str(subtitle) if subtitle else None,
        "width": width, "height": height, "fps": args.fps, "speed": speed,
        "trim_start": trim_start, "trim_end": args.trim_end, "preview": bool(args.preview),
        "loudnorm": bool(args.loudnorm), "bytes": output.stat().st_size,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--subtitle", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--width", type=int)
    parser.add_argument("--height", type=int)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--speed", type=float, default=1.0)
    parser.add_argument("--trim-start", type=float, default=0.0)
    parser.add_argument("--trim-end", type=float)
    parser.add_argument("--crf", type=int, default=18)
    parser.add_argument("--preview-crf", type=int, default=23)
    parser.add_argument("--preset", default="medium", choices=("ultrafast", "superfast", "veryfast", "faster", "fast", "medium", "slow", "slower"))
    parser.add_argument("--loudnorm", action="store_true")
    parser.add_argument("--preview", action="store_true")
    args = parser.parse_args()
    print(json.dumps(render(args), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
