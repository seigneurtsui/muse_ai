# Document formats and structural guarantees

`translation_documents.py` uses only the Python standard library. It does not
read files, call a model, access a network, inspect credentials, or detect a
language. The caller supplies decoded text and handles encoding/BOM, permissions,
immutable plan storage, model requests, and atomic output writes.

## API

```python
from translation_documents import prepare_document, render_document, DocumentError

plan = prepare_document("Hello {name}!\r\n", ".txt", max_chars=1500)
# Send only each unit's id, text, and optional context to the invoking session.
# Example response after protocol validation:
translations = {unit["id"]: "Bonjour" for unit in plan["units"]}
output = render_document(plan, translations)
# output == "Bonjour {name}!\r\n"
```

- `prepare_document(text: str, ext: str, max_chars: int = 1500) -> dict` returns a
  JSON-serializable plan with `version`, normalized `extension`, original `text`,
  `max_chars`, sequential `units` (`id`, `text`, `context`), and private
  reconstruction fields. Do not edit the plan or send the entire plan to a model.
  Extension names are case-insensitive; a leading dot is optional.
- `render_document(plan, translations: dict[int, str]) -> str` requires exactly
  the planned IDs. String IDs, Boolean IDs, missing IDs, extra IDs, non-string
  replacements, and altered reconstruction plans fail. JSON object response keys
  must be converted/validated by the caller's protocol before this function.
  Plans survive a JSON save/load round trip. Rendering reconstructs the expected
  plan from its source rather than trusting caller-provided offsets.
- `validate_translation(before: str, after: str) -> None` validates protected
  tokens, edge whitespace, output size, and the presence of alphabetic text when
  the source has it. It is a structural guard, **not a language or semantic
  correctness check**. Rendering also applies format-specific checks.
- `DocumentError` exposes only a safe `.code` (also the exception message); it
  never embeds source text or paths. Codes such as `translation_ids`,
  `translation_structure`, `csv_formula`, `json_duplicate_key`, and
  `document_complexity` are actionable categories, not user data.

## Shared behavior and limits

Only `.txt`, `.md`, `.markdown`, `.srt`, `.vtt`, `.csv`, and `.json` are supported.
PDF, DOCX, HTML/XML **files**, ASS/SSA, YAML, spreadsheets, and binary/archive
formats are out of scope. Recognizing inline markup in supported text formats
does not add support for those other document formats.

- Input: at most **4,000,000 Unicode characters**; output: at most **16,000,000**.
  Invalid surrogate characters and NUL are rejected. JSON decoded strings also
  have the input-character bound, including during final validation.
- Unit size: `1..65,536` characters, default **1,500**. At most **100,000 units**
  and **100,000 containers/JSON value nodes**. JSON/placeholder nesting is bounded
  at **64**; protection scanning is limited to **200,000 tokens/lines** per
  container. Exceeding a bound is an error, not silent truncation.
- Each replacement is limited to `max(256, 8 * len(original_unit))` characters,
  in addition to total-output limits. CSV/JSON quoting expansion counts toward
  the total output bound. These are character limits, not token or byte estimates.
- Text in any alphabetic script is eligible. Whitespace-only, punctuation-only,
  emoji-only, and numeric-only material is left unchanged; no fake translation
  unit is created for a numeric-only line or value. No target-language detection
  is attempted, and an unchanged replacement is allowed for names and other
  legitimate cases.
- Physical newlines (including CRLF, CR, LF and Unicode line separators), tabs,
  control characters, and each fragment's exterior whitespace remain outside
  editable units. Long prose prefers sentence then whitespace boundaries, with a
  hard character split for long unbroken words. Original source is never globally
  stripped or newline-normalized. Source spaces between fragments stay exact;
  spaces **inside** a unit may change.
- Decimal digit tokens (including Unicode decimal digits, signs, decimal/grouping
  punctuation, exponents, and a trailing percent sign), currency symbols, URLs
  with a scheme or `www.`, autolinks, entities, backslash escapes, recognized
  placeholders, tags, comments, and inline backtick code are immutable. Numeric
  spelling is preserved exactly, not converted between locale conventions.
  Written-out numbers are ordinary language, not semantically interpreted.
- Supported placeholders include `{name}`, `{{name}}`, `${name}`, nested braced
  templates, `%(name)s`, `%s`, and bounded printf-like directives. Named printf
  keys are limited to 256 characters; flags to 16; width/precision to 10 digits.
  Braced groups are conservatively opaque, even if they contain prose.
- Raw `<pre>`, `<code>`, `<script>`, and `<style>` bodies, XML processing
  instructions and CDATA are preserved, not translated. Tag recognition uses a
  quote-aware bounded scan, not a complete HTML/XML validator. Unsupported or
  unclosed markup fails rather than exposing it as editable prose.
- Structural punctuation such as brackets, braces, backticks, `*`, `_`, `#`, `~`,
  and `|` is conservatively protected even in plain text and structured string
  values. Ordinary punctuation may change. This intentionally rejects some
  linguistically valid translations that would add structural tokens or digits.
- Rendering uses forward span joins, validates replacements before returning
  output, checks complete reconstructed containers to catch tokens formed across
  fragment boundaries, and reparses CSV, JSON, and subtitles. These protections
  prevent structural changes; they do not establish translation quality, factual
  accuracy, or safety of pre-existing document content.

## Plain text: `.txt`

Translate eligible prose while keeping shared protected spans and exact physical
line framing. Inline backtick code and markup are protected; this is not a parser
for every programming language or arbitrary ASCII-art convention. Plain prose
containing unmatched template/code syntax may be rejected conservatively.

## Markdown: `.md`, `.markdown`

A finite conservative parser protects headings, simple list/blockquote/task
prefixes, emphasis delimiters, table pipes, setext/rule lines, link/image syntax,
link destinations and titles, code spans, fenced/indented code, and YAML/TOML-style
frontmatter. Image alt text and explicit link labels may translate; URLs and
reference identifiers may not. Markdown structural signatures are rechecked on
the complete reconstructed document, including new list/image markers.

Deliberate limitations:

- Not a CommonMark/GFM implementation. Extensions such as MDX, arbitrary embedded
  languages, or custom directives have no semantic support.
- Nested bracket labels, multiline inline-link destinations, nested same-line
  list/heading prefixes, and unclosed fences/frontmatter/code are rejected.
- Shortcut and collapsed reference labels stay unchanged. Bare bracketed text is
  treated conservatively as a reference, not ordinary translatable prose.
- Reference definitions and following nonblank continuation lines remain wholly
  unchanged until a blank line. This may preserve adjacent prose unnecessarily.
- Lines beginning with four spaces or a tab stay wholly unchanged as code, even
  when another Markdown implementation might treat them as a nested list.
- Metadata is deliberately not translated. Frontmatter delimiters must be on
  their own lines; caller-side BOM handling is required before parsing.
- Delimiters are preserved exactly, but there is no promise to reproduce every
  Markdown renderer's context-sensitive interpretation after prose changes.

## Subtitles: `.srt`, `.vtt`

Only cue text is eligible. SRT index lines and timestamps stay exact. VTT header
metadata, optional cue identifiers, timing/settings, NOTE blocks, and STYLE/REGION
blocks stay exact. STYLE/REGION blocks after the first cue are rejected.

Timing syntax is strict: SRT uses `HH:MM:SS,mmm`; VTT uses `MM:SS.mmm` or
`HH:MM:SS.mmm`. End must be later than start. Supported VTT settings are `vertical`,
`line`, `position`, `size`, `align`, and `region`; unknown or duplicate settings and
out-of-range percentages fail. Cross-cue overlap is not forbidden.

Dialogue can contain numbers and `-->`; these tokens stay exact and do not alone
make a dialogue line a timing line. A **complete valid timing line** inside a cue
payload is rejected as an ambiguous/missing separator. Blank lines delimit
blocks. Extensions such as SRT coordinate suffixes and ASS dialogue grammar are
not guessed. Tags and line count remain unchanged; no cue reflow is performed.

## CSV: `.csv`

Translate textual **cell values**, including the **first row/header**. The module
has no schema and does not assume header cells are application identifiers. Use
this only when translating headers is intended; schema-aware header exclusion is
not a supported option in this version. Unit context includes zero-based row,
column, and a `header` flag (`row == 0`). Numbers remain unchanged.

- Supported delimiters: comma, semicolon, tab, pipe. A dialect is accepted only
  when exactly one candidate produces a strict rectangular multi-column table.
  Single-column comma-style CSV is supported when no unquoted alternate delimiter
  occurs. Ambiguous dialects, ragged rows, malformed quotes, and junk after a
  quoted field are rejected. No permissive dialect/quote guessing occurs.
- Double-quote quoting and doubled-quote escapes are supported. Empty fields,
  trailing empty columns, CRLF/LF/CR record endings, and quoted embedded newlines
  are preserved. Blank records count as one empty column and therefore reject
  an otherwise multi-column rectangular table.
- Unmodified fields retain their exact original spelling. Changed fields preserve
  existing quotes; previously unquoted fields are quoted only when required by a
  new delimiter or quote. Literal quotes are doubled. Quoted embedded physical
  newlines cannot be added or removed.
- Cells already beginning with `=`, `+`, `-`, `@`, or tab (after other leading
  whitespace/BOM) are opaque and **never sent for translation**. Any new such
  prefix is rejected, including prefixes formed across fragments or after
  existing whitespace. Existing dangerous formulas are not sanitized or made
  safe to open in a spreadsheet; their original bytes are preserved.
- CSV is reparsed with its original detected delimiter, not redetected from the
  translated prose. Row/column counts are verified after encoding.

## JSON: `.json`

A bounded span-aware JSON parser exposes only **string values**. Object keys,
number spellings (including exponent notation), Boolean/null values, whitespace,
and punctuation outside a changed string remain exact. An unchanged string also
retains its original escapes; a changed string is encoded with `json.dumps` and
may acquire different but equivalent escaping. Its decoded newlines and protected
tokens remain exact. Context contains the value's key/index path.

Duplicate keys (including escape-equivalent spellings), trailing data/commas,
invalid escapes, unpaired surrogates, NUL, malformed numbers, nonfinite numeric
values, and overly deep/complex payloads are rejected. For a conservative finite
number check, numeric literals that overflow Python's finite float range are also
rejected even when arbitrary-precision JSON software could represent them.
Root strings, arrays, and scalar JSON values are supported. Changed values cannot
introduce object keys or syntax because replacements are string-encoded and the
whole result is parsed again with the same strict parser.

## Synthetic verification

From this skill directory:

```sh
python3 -B -m unittest discover -s tests -p test_documents.py
black --config /dev/null --check scripts/translation_documents.py tests/test_documents.py
```

Tests cover all supported extensions, identity/persistence, any-script eligibility,
long fragments, whitespace/newline framing, shared protected tokens, Markdown
metadata/code/links, subtitle dialogue containing numbers/arrows, CSV quoting and
formula injection, JSON raw spelling/duplicate/malformed/deep payloads, and missing,
extra, empty, oversized, or structure-changing model replacements. Fixtures are
synthetic and require no model, network, installation, or source-project execution.
