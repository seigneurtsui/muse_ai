from __future__ import annotations

import json
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import batch_add_toc as app

DOC = (
    "<!doctype html><html><head><title>T</title><style>.x{color:red}</style></head>"
    "<body><h1>大标题</h1><h2>第一节</h2><p>hello</p>"
    "<table><tr><td>x</td></tr></table>"
    "<h2>第二节</h2><h3>子节</h3></body></html>"
)


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        self.input = self.root / "in"
        self.output = self.root / "out"
        self.input.mkdir()

    def write(self, name: str, content: str) -> Path:
        path = self.input / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return path

    def args(self, *extra: str):
        argv = app._normalize_argv([str(self.input), str(self.output), *extra])
        return app.build_parser().parse_args(argv)

    def run_tool(self, *extra: str):
        return app.run(self.args(*extra))


class StripTests(unittest.TestCase):
    def test_strip_removes_our_block_and_css(self):
        processed, _ = app.process_html(DOC)
        stripped = app.strip_injections(processed)
        self.assertNotIn("data-rainman-toc=", stripped)
        self.assertNotIn("rainman-toc-embed:start", stripped)
        self.assertNotIn("data-rainman-table=", stripped)
        self.assertIn("<table", stripped)

    def test_strip_removes_legacy_injections(self):
        legacy = (
            "<html><body>"
            '<aside class="rainman-toc" data-rainman-toc="1"><nav></nav></aside>'
            "<script>\n(function(){\n const toc=document.querySelector('[data-rainman-toc=\"1\"]');\n})();\n</script>"
            "</body></html>"
        )
        stripped = app.strip_injections(legacy)
        self.assertNotIn("data-rainman-toc=", stripped)
        self.assertNotIn("document.querySelector", stripped)

    def test_strip_removes_legacy_css_layer(self):
        layered = "<html><head><style>/* Rainman TOC fixed layer */\n.foo{}\n</style></head><body></body></html>"
        stripped = app.strip_injections(layered)
        self.assertNotIn("Rainman TOC fixed layer", stripped)


class ProcessTests(unittest.TestCase):
    def test_process_is_idempotent(self):
        once, meta1 = app.process_html(DOC)
        twice, meta2 = app.process_html(once)
        self.assertEqual(once, twice)
        self.assertEqual(meta1["toc_items"], meta2["toc_items"])

    def test_process_is_idempotent_without_style_or_head(self):
        src = "<html><body><h2>A</h2><h3>B</h3></body></html>"
        once, _ = app.process_html(src)
        twice, _ = app.process_html(once)
        self.assertEqual(once, twice)

    def test_adds_viewport(self):
        out, _ = app.process_html("<html><head></head><body><h2>x</h2></body></html>")
        self.assertIn('name="viewport"', out)

    def test_viewport_not_duplicated(self):
        src = '<html><head><meta name="viewport" content="width=device-width"></head><body></body></html>'
        out, _ = app.process_html(src)
        self.assertEqual(out.count('name="viewport"'), 1)

    def test_heading_ids_and_links(self):
        out, meta = app.process_html(DOC)
        ids = re.findall(r'id="(rainman-section-\d+)"', out)
        self.assertEqual(
            ids, ["rainman-section-1", "rainman-section-2", "rainman-section-3"]
        )
        self.assertEqual(meta["toc_items"], 3)
        links = re.findall(r'data-target="(rainman-section-\d+)"', out)
        self.assertEqual(links, ids)

    def test_existing_ids_preserved_and_deduped(self):
        src = '<html><body><h2 id="keep">A</h2><h2>B</h2></body></html>'
        out, meta = app.process_html(src)
        self.assertIn('id="keep"', out)
        self.assertIn('data-target="keep"', out)
        self.assertEqual(meta["toc_items"], 2)

    def test_levels_filter(self):
        src = "<html><body><h2>A</h2><h3>B</h3><h4>C</h4></body></html>"
        out, meta = app.process_html(src, levels=(2, 3))
        self.assertEqual(meta["toc_items"], 2)
        self.assertNotIn('data-target="rainman-section-3"', out)

    def test_min_headings_skips_toc_but_keeps_css(self):
        src = "<html><body><h2>only</h2></body></html>"
        out, meta = app.process_html(src, min_headings=2)
        self.assertEqual(meta["toc_items"], 0)
        self.assertNotIn("data-rainman-toc=", out)
        self.assertIn("rainman-toc-embed:start", out)

    def test_no_headings_still_transforms(self):
        out, meta = app.process_html("<html><body><p>none</p></body></html>")
        self.assertEqual(meta["toc_items"], 0)
        self.assertIn("rainman-toc-embed:start", out)

    def test_table_wrapping_and_opt_out(self):
        wrapped, meta = app.process_html(DOC)
        self.assertEqual(meta["tables"], 1)
        self.assertIn('class="rainman-table"', wrapped)
        plain, meta2 = app.process_html(DOC, wrap_tables=False)
        self.assertEqual(meta2["tables"], 0)
        self.assertNotIn('data-rainman-table="1"', plain)

    def test_toc_title_escaped(self):
        out, _ = app.process_html(DOC, toc_title="<目录>")
        self.assertIn("&lt;目录&gt;", out)

    def test_heading_text_escaped_in_link(self):
        out, _ = app.process_html("<html><body><h2>A &amp; B</h2></body></html>")
        self.assertIn("A &amp; B", out)

    def test_missing_body_appends_tail(self):
        out, meta = app.process_html("<h2>solo</h2>")
        self.assertEqual(meta["toc_items"], 1)
        self.assertIn("data-rainman-toc=", out)


class HelperTests(unittest.TestCase):
    def test_normalize_heading_levels(self):
        self.assertEqual(app.normalize_heading_levels("2,3"), (2, 3))
        self.assertEqual(app.normalize_heading_levels([3, 2, 2]), (2, 3))
        self.assertEqual(app.normalize_heading_levels(None), app.DEFAULT_LEVELS)
        with self.assertRaisesRegex(app.TocError, "invalid_levels"):
            app.normalize_heading_levels("2,x")
        with self.assertRaisesRegex(app.TocError, "invalid_levels"):
            app.normalize_heading_levels("7")

    def test_resolve_jobs(self):
        self.assertEqual(app.resolve_jobs("auto", 100), app.DEFAULT_JOBS_CAP)
        self.assertEqual(app.resolve_jobs("3", 10), 3)
        self.assertEqual(app.resolve_jobs("99", 2), 2)
        self.assertEqual(app.resolve_jobs(None, 0), 1)
        with self.assertRaisesRegex(app.TocError, "invalid_jobs_value"):
            app.resolve_jobs("lots", 5)

    def test_normalize_argv_keeps_dash_values(self):
        normalized = app._normalize_argv(
            ["in", "--levels", "2,3", "--exclude-pattern", "-draft"]
        )
        self.assertEqual(normalized, ["in", "--levels=2,3", "--exclude-pattern=-draft"])
        args = app.build_parser().parse_args(normalized)
        self.assertEqual(args.levels, "2,3")
        self.assertEqual(args.exclude_pattern, ["-draft"])

    def test_write_atomic(self):
        target = Path(tempfile.mkdtemp()) / "deep" / "f.html"
        app.write_atomic(target, "one")
        self.assertEqual(target.read_text(encoding="utf-8"), "one")
        app.write_atomic(target, "two")
        self.assertEqual(target.read_text(encoding="utf-8"), "two")


class BatchTests(Base):
    def test_run_outputs_transformed_files(self):
        self.write("a.html", DOC)
        report, code = self.run_tool("--json")
        self.assertEqual(code, 0)
        self.assertEqual(report["status"], "complete")
        self.assertEqual(report["summary"]["toc_documents"], 1)
        out = (self.output / "a.html").read_text(encoding="utf-8")
        self.assertIn("data-rainman-toc=", out)

    def test_recursive_keeps_structure_vs_flat(self):
        self.write("top.html", DOC)
        self.write("sub/nested.html", DOC)
        # Non-recursive: only top-level files, flattened into the output dir.
        self.run_tool()
        self.assertTrue((self.output / "top.html").is_file())
        self.assertFalse((self.output / "nested.html").exists())
        self.assertFalse((self.output / "sub").exists())
        # Recursive: nested structure preserved.
        output2 = self.root / "out2"
        app.run(app.build_parser().parse_args([str(self.input), str(output2), "-r"]))
        self.assertTrue((output2 / "top.html").is_file())
        self.assertTrue((output2 / "sub" / "nested.html").is_file())

    def test_exclude_pattern(self):
        self.write("keep.html", DOC)
        self.write("drop-draft.html", DOC)
        report, _ = self.run_tool("--exclude-pattern", "-draft", "--json")
        self.assertEqual(report["summary"]["total"], 1)
        self.assertFalse((self.output / "drop-draft.html").exists())

    def test_dry_run_writes_nothing(self):
        self.write("a.html", DOC)
        report, code = self.run_tool("--dry-run", "--json")
        self.assertEqual(code, 0)
        self.assertEqual(report["status"], "dry_run")
        self.assertFalse(self.output.exists())
        self.assertEqual(report["files"][0]["status"], "planned")

    def test_incremental_skips_unchanged(self):
        self.write("a.html", DOC)
        self.run_tool()
        report, code = self.run_tool("--incremental", "--json")
        self.assertEqual(code, 0)
        self.assertEqual(report["summary"]["skipped"], 1)

    def test_force_rewrites_unchanged(self):
        self.write("a.html", DOC)
        self.run_tool()
        report, _ = self.run_tool("--incremental", "--force", "--json")
        self.assertEqual(report["summary"]["skipped"], 0)
        self.assertEqual(report["summary"]["success"], 1)

    def test_in_place_rewrites_source(self):
        path = self.write("a.html", DOC)
        report, code = app.run(
            app.build_parser().parse_args([str(self.input), "--in-place"])
        )
        self.assertEqual(code, 0)
        self.assertIn("data-rainman-toc=", path.read_text(encoding="utf-8"))
        self.assertFalse(self.output.exists())

    def test_output_within_input_rejected(self):
        with self.assertRaisesRegex(app.TocError, "output_within_input"):
            app.run(
                app.build_parser().parse_args(
                    [str(self.input), str(self.input / "out")]
                )
            )

    def test_output_equals_input_rejected(self):
        with self.assertRaisesRegex(app.TocError, "output_equals_input"):
            app.run(app.build_parser().parse_args([str(self.input), str(self.input)]))

    def test_input_not_found_rejected(self):
        with self.assertRaisesRegex(app.TocError, "input_not_found"):
            app.run(
                app.build_parser().parse_args(
                    [str(self.root / "nope"), str(self.output)]
                )
            )

    def test_process_one_read_failure(self):
        record = app.process_one(
            self.root / "missing.html",
            self.input,
            self.output,
            False,
            False,
            app.Options(),
        )
        self.assertEqual(record["status"], "failed")
        self.assertEqual(record["reason"], "read_failed")

    def test_partial_failure_exit_code(self):
        self.write("a.html", DOC)
        self.write("b.html", DOC)
        original = app.process_one

        def flaky(source_file, *args, **kwargs):
            record = original(source_file, *args, **kwargs)
            if source_file.name == "b.html":
                record.update(status="failed", reason="write_failed")
            return record

        with patch.object(app, "process_one", side_effect=flaky):
            report, code = self.run_tool("--json")
        self.assertEqual(code, 2)
        self.assertEqual(report["status"], "partial_failure")
        self.assertEqual(report["summary"]["failed"], 1)

    def test_report_written(self):
        self.write("a.html", DOC)
        report_path = self.root / "report.json"
        code = app.main(
            [str(self.input), str(self.output), "--report", str(report_path)]
        )
        self.assertEqual(code, 0)
        payload = json.loads(report_path.read_text(encoding="utf-8"))
        self.assertEqual(payload["summary"]["total"], 1)


class CliTests(Base):
    def test_help_and_version(self):
        script = Path(app.__file__)
        for flag in ("--help", "--version"):
            result = subprocess.run(
                [sys.executable, "-B", str(script), flag],
                capture_output=True,
                text=True,
                timeout=30,
            )
            self.assertEqual(result.returncode, 0, result.stderr)

    def test_real_subprocess_dry_run_and_run(self):
        script = Path(app.__file__)
        source = self.root / "src"
        source.mkdir()
        (source / "a.html").write_text(DOC, encoding="utf-8")
        out = self.root / "site"
        dry = subprocess.run(
            [
                sys.executable,
                "-B",
                str(script),
                str(source),
                str(out),
                "--dry-run",
                "--json",
            ],
            capture_output=True,
            text=True,
            timeout=60,
        )
        self.assertEqual(dry.returncode, 0, dry.stderr)
        self.assertEqual(json.loads(dry.stdout)["status"], "dry_run")
        self.assertFalse(out.exists())
        real = subprocess.run(
            [sys.executable, "-B", str(script), str(source), "-o", str(out), "--json"],
            capture_output=True,
            text=True,
            timeout=60,
        )
        self.assertEqual(real.returncode, 0, real.stderr)
        self.assertEqual(json.loads(real.stdout)["status"], "complete")
        self.assertTrue((out / "a.html").is_file())

    def test_real_subprocess_bad_input_json_error(self):
        script = Path(app.__file__)
        result = subprocess.run(
            [
                sys.executable,
                "-B",
                str(script),
                str(self.root / "nope"),
                str(self.root / "site"),
                "--json",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stdout)["status"], "error")


if __name__ == "__main__":
    unittest.main()
