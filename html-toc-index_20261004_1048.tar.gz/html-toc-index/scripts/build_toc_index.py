#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Batch-build a searchable table-of-contents index over HTML documents.

Adapted from the supplied ``/tmp/build_toc_index.py`` (the rainman-travel TOC
builder). It keeps that script's core behaviour — scan a directory of HTML
documents, derive metadata (title, summary, size, date, word count, tags),
archive each document into its own ``doc-<hash>/index.html`` folder, and emit a
single self-contained ``index.html`` with live search / sort / pagination /
tag-filter / keyword highlight — but hardens and generalises it:

* dependency-free (standard library only, no third-party imports);
* the index page is assembled with explicit ``__TOKEN__`` replacement instead
  of ``str.format`` so CSS/JS braces can never be mis-escaped;
* atomic file writes (temp file + ``os.replace``), so a crashed run never
  leaves a half-written document or index;
* bounded parallelism (``--jobs``) and a deterministic record order;
* ``--incremental`` skips unchanged documents and prunes stale folders;
* non-incremental runs clean only the artifacts this tool owns (``doc-*``
  folders and the four generated files), never unrelated files;
* the output directory may not equal or live inside the input directory;
* JSON report (``--json`` / ``--report``), ``--dry-run``, and JSON / Markdown /
  plain-text exports;
* optional per-document table-of-contents injection (``--inject-doc-toc``),
  which adds stable heading anchors and a collapsible TOC to every document.

Examples:
    build_toc_index.py ~/docs -o ~/site
    build_toc_index.py ~/docs -o ~/site --incremental
    build_toc_index.py ~/docs -o ~/site --recursive --inject-doc-toc
    build_toc_index.py ~/docs -o ~/site --dry-run --json
    build_toc_index.py ~/docs -o ~/site --export-json --export-markdown
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import html
import json
import logging
import os
import re
import shutil
import sys
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

VERSION = "1.0.0"

DEFAULT_INPUT = "~/Downloads/rainman-travel"
DEFAULT_OUTPUT = "~/Downloads/rainman-travel_toc"
DEFAULT_JOBS_CAP = 8
PARALLEL_THRESHOLD = 5
MAX_SUMMARY_CHARS = 220

GENERATED_FILES = ("index.html", "data.json", "INDEX.md", "file_list.txt")

FULLWIDTH_SPACE = "\u3000"

TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)
BODY_RE = re.compile(r"<body[^>]*>", re.IGNORECASE)
TAG_RE = re.compile(r"<[^>]+>")
SCRIPT_STYLE_RE = re.compile(
    r"<(script|style)[^>]*>.*?</\1>", re.IGNORECASE | re.DOTALL
)
WHITESPACE_RE = re.compile(r"\s+")
DATE_PATTERN = re.compile(r"(\d{4})[年\-/.]([0-1]?\d)[月\-/.]([0-3]?\d)[日]?")

# Filename timestamp prefixes: 20240101_120000_rest  or  20240101T120000==z--rest
TS_PATTERN_1 = re.compile(r"^(?P<ts>\d{8}_\d{6})_(?P<rest>.+)$")
TS_PATTERN_2 = re.compile(r"^(?P<ts>\d{8}T\d{6})==z--(?P<rest>.+)$")

HEADING_RE = re.compile(
    r"<h([1-6])((?:\s[^>]*)?)>(.*?)</h\1>", re.IGNORECASE | re.DOTALL
)
DOC_TOC_MARKER = 'data-doc-toc="1"'

# Built-in place dictionary (100+ cities / regions). Overridable with
# --places-file.
KNOWN_PLACES = [
    # 一线/省会/直辖市
    "南京",
    "上海",
    "成都",
    "乌鲁木齐",
    "拉萨",
    "常州",
    "喀什",
    "昆明",
    "商丘",
    "沈阳",
    "南宁",
    "运城",
    "西安",
    "柳州",
    "伊犁",
    "开封",
    "日本",
    "洛阳",
    "杭州",
    "贵州",
    "无锡",
    "黑龙江",
    "重庆",
    "西宁",
    "山西",
    "苏州",
    "山东",
    "宁夏",
    "青海",
    "和田",
    "云南",
    "天津",
    "北京",
    "广州",
    "深圳",
    "武汉",
    "长沙",
    "西藏",
    "新疆",
    "内蒙古",
    # 热门旅游城市
    "大理",
    "厦门",
    "青岛",
    "三亚",
    "桂林",
    "张家界",
    "九寨沟",
    "黄山",
    "泰山",
    "峨眉山",
    "哈尔滨",
    "长春",
    "大连",
    "济南",
    "福州",
    "南昌",
    "合肥",
    "郑州",
    "石家庄",
    "太原",
    "海口",
    "兰州",
    "银川",
    "呼和浩特",
    "贵阳",
    "珠海",
    "汕头",
    "佛山",
    "东莞",
    "温州",
    "宁波",
    "绍兴",
    "嘉兴",
    "湖州",
    "台州",
    "丽水",
    "金华",
    "衢州",
    "舟山",
    "镇江",
    "扬州",
    "泰州",
    "南通",
    "盐城",
    "淮安",
    "宿迁",
    "徐州",
    "连云港",
    "漳州",
    "泉州",
    # 区域/地理概念
    "江南",
    "塞北",
    "中原",
    "岭南",
    "河西走廊",
    "香格里拉",
]

log = logging.getLogger("html-toc-index")


class BuildError(Exception):
    """Error carrying a short, log-safe reason code."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def reason(error: BaseException) -> str:
    code = getattr(error, "code", "")
    if isinstance(code, str) and re.fullmatch(r"[a-z][a-z0-9_]{0,79}", code):
        return code
    return "unexpected_error"


# --------------------------------------------------------------------------
# Text helpers
# --------------------------------------------------------------------------


def clean_text(value: str) -> str:
    if not value:
        return ""
    value = value.replace(FULLWIDTH_SPACE, " ")
    return WHITESPACE_RE.sub(" ", value).strip()


def parse_filename_timestamp(stem: str) -> tuple[Optional[datetime], str]:
    """Return (datetime, remainder) parsed from a timestamp filename prefix."""
    for pattern, fmt in (
        (TS_PATTERN_1, "%Y%m%d_%H%M%S"),
        (TS_PATTERN_2, "%Y%m%dT%H%M%S"),
    ):
        match = pattern.match(stem)
        if not match:
            continue
        try:
            return datetime.strptime(match.group("ts"), fmt), match.group("rest")
        except ValueError:
            continue
    return None, stem


def extract_date_from_content(html_text: str) -> Optional[datetime]:
    match = DATE_PATTERN.search(html_text)
    if not match:
        return None
    try:
        return datetime(int(match.group(1)), int(match.group(2)), int(match.group(3)))
    except ValueError:
        return None


def guess_title_from_filename(filename: str) -> str:
    _, rest = parse_filename_timestamp(Path(filename).stem)
    return clean_text(rest)


def strip_timestamp_prefix(text: str) -> str:
    for pattern in (TS_PATTERN_1, TS_PATTERN_2):
        match = pattern.match(text)
        if match:
            return clean_text(match.group("rest"))
    return text


def extract_title(html_text: str, filename: str) -> str:
    match = TITLE_RE.search(html_text)
    if match:
        title = strip_timestamp_prefix(clean_text(html.unescape(match.group(1))))
        if title and title.lower() not in ("untitled", "document", "新文档"):
            return title
    return guess_title_from_filename(filename)


def _body_fragment(html_text: str) -> str:
    match = re.search(r"<body[^>]*>(.*?)</body>", html_text, re.IGNORECASE | re.DOTALL)
    fragment = match.group(1) if match else html_text
    return SCRIPT_STYLE_RE.sub(" ", fragment)


def extract_summary(html_text: str, max_len: int = MAX_SUMMARY_CHARS) -> str:
    text = clean_text(html.unescape(TAG_RE.sub(" ", _body_fragment(html_text))))
    if len(text) > max_len:
        return text[:max_len].rstrip() + "…"
    return text


def count_words(html_text: str) -> int:
    return len(clean_text(html.unescape(TAG_RE.sub(" ", _body_fragment(html_text)))))


def extract_candidate_keywords(text: str) -> list[str]:
    segments = re.split(r"[^\u4e00-\u9fff]+", text)
    candidates = {seg for seg in segments if 2 <= len(seg) <= 4}
    return sorted(candidates)


def guess_tags(title: str, filename: str, places: list[str]) -> list[str]:
    tags: set[str] = set()
    haystack = f"{title} {filename}"
    for place in places:
        if place in haystack:
            tags.add(place)
    lower_name = filename.lower()
    if "-email" in filename or "邮件" in title or "email" in lower_name:
        tags.add("email 版")
    if not tags:
        stop_words = {
            "旅行",
            "研究",
            "报告",
            "文档",
            "笔记",
            "攻略",
            "行程",
            "计划",
            "游记",
            "总结",
        }
        meaningful = [
            c for c in extract_candidate_keywords(title) if c not in stop_words
        ]
        tags.update(meaningful[:3])
    if not tags:
        tags.add("未分类")
    return sorted(tags)


def compute_doc_id(filename: str, content: str) -> str:
    data = f"{filename}|||{content}".encode("utf-8")
    return hashlib.sha256(data).hexdigest()[:6]


def load_places_file(path: Optional[Path]) -> list[str]:
    if path is None:
        return list(KNOWN_PLACES)
    if not path.is_file():
        log.warning("places file not found, using built-in dictionary: %s", path)
        return list(KNOWN_PLACES)
    places = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            places.append(line)
    return places or list(KNOWN_PLACES)


# --------------------------------------------------------------------------
# Optional per-document TOC injection
# --------------------------------------------------------------------------


def _slugify(text: str) -> str:
    text = html.unescape(TAG_RE.sub("", text))
    text = clean_text(text).lower()
    slug = re.sub(r"[^\w\u4e00-\u9fff]+", "-", text, flags=re.UNICODE).strip("-")
    return slug or "section"


def _render_doc_toc(entries: list[tuple[int, str, str]]) -> str:
    min_level = min(level for level, _, _ in entries)
    items = []
    for level, anchor, text in entries:
        depth = max(0, level - min_level)
        items.append(
            f'<li class="doc-toc-l{depth}">'
            f'<a href="#{html.escape(anchor, quote=True)}">{html.escape(text)}</a></li>'
        )
    return DOC_TOC_TEMPLATE.replace("__ITEMS__", "\n".join(items))


def inject_doc_toc(
    raw: str, *, min_headings: int = 2, max_level: int = 3
) -> tuple[str, int]:
    """Inject a collapsible heading TOC into a document.

    Returns ``(html, entries)``. If the document has fewer than ``min_headings``
    headings (or was already injected), the original text is returned unchanged.
    Idempotent: a re-run detects the ``data-doc-toc`` marker and does nothing.
    """
    if DOC_TOC_MARKER in raw:
        return raw, 0

    entries: list[tuple[int, str, str]] = []
    seen: dict[str, int] = {}

    def repl(match: re.Match) -> str:
        level = int(match.group(1))
        attrs = match.group(2) or ""
        inner = match.group(3)
        text = clean_text(html.unescape(TAG_RE.sub("", inner)))
        id_match = re.search(r'\bid\s*=\s*"([^"]*)"', attrs) or re.search(
            r"\bid\s*=\s*'([^']*)'", attrs
        )
        if id_match and id_match.group(1):
            anchor = id_match.group(1)
        else:
            base = _slugify(text)
            anchor = base
            while anchor in seen:
                seen[base] += 1
                anchor = f"{base}-{seen[base]}"
            seen[anchor] = 0
        if level <= max_level:
            entries.append((level, anchor, text))
        if id_match:
            return match.group(0)
        return f'<h{level}{attrs} id="{html.escape(anchor, quote=True)}">{inner}</h{level}>'

    rewritten = HEADING_RE.sub(repl, raw)
    if len(entries) < min_headings:
        return raw, 0

    block = _render_doc_toc(entries)
    body = BODY_RE.search(rewritten)
    if body:
        position = body.end()
        rewritten = f"{rewritten[:position]}\n{block}\n{rewritten[position:]}"
    else:
        rewritten = f"{block}\n{rewritten}"
    return rewritten, len(entries)


# --------------------------------------------------------------------------
# File processing
# --------------------------------------------------------------------------


@dataclass
class Options:
    recursive: bool = False
    exclude_patterns: list[str] = None  # type: ignore[assignment]
    inject_doc_toc: bool = False
    jobs: int = 1

    def __post_init__(self) -> None:
        if self.exclude_patterns is None:
            self.exclude_patterns = []


def process_file(
    path: Path, places: list[str], *, inject_toc: bool = False
) -> dict[str, Any]:
    try:
        raw = path.read_text(encoding="utf-8", errors="ignore")
    except OSError as error:
        raise BuildError("read_failed") from error

    stat = path.stat()
    title = extract_title(raw, path.name)
    summary = extract_summary(raw)
    word_count = count_words(raw)

    ts_from_name, _ = parse_filename_timestamp(path.stem)
    if ts_from_name:
        date_val, date_source = ts_from_name, "filename"
    else:
        from_content = extract_date_from_content(raw)
        if from_content:
            date_val, date_source = from_content, "content"
        else:
            date_val = datetime.fromtimestamp(stat.st_mtime)
            date_source = "mtime"

    content = raw
    toc_items = 0
    if inject_toc:
        content, toc_items = inject_doc_toc(raw)

    return {
        "title": title,
        "filename": path.name,
        "source": str(path),
        "doc_id": compute_doc_id(path.name, raw),
        "size": stat.st_size,
        "word_count": word_count,
        "date": date_val.strftime("%Y-%m-%d %H:%M:%S"),
        "date_sort": date_val.strftime("%Y%m%d%H%M%S"),
        "date_source": date_source,
        "summary": summary,
        "tags": guess_tags(title, path.name, places),
        "toc_items": toc_items,
        "content": content,
    }


def scan_files(
    input_dir: Path, recursive: bool, exclude_patterns: list[str]
) -> list[Path]:
    pattern = "**/*.html" if recursive else "*.html"
    files = [f for f in input_dir.glob(pattern) if f.is_file() and not f.is_symlink()]
    files = [f for f in files if f.name.lower() != "index.html"]
    if exclude_patterns:
        compiled = [re.compile(p) for p in exclude_patterns]
        files = [f for f in files if not any(r.search(f.name) for r in compiled)]
    return sorted(files, key=lambda p: p.name.casefold())


def build_records(
    files: list[Path], places: list[str], opts: Options
) -> tuple[list[dict[str, Any]], list[str]]:
    if not files:
        return [], []
    log.info("scanned %d HTML file(s)", len(files))

    records: list[dict[str, Any]] = []
    warnings: list[str] = []

    def collect(path: Path) -> None:
        try:
            records.append(process_file(path, places, inject_toc=opts.inject_doc_toc))
        except BuildError as error:
            warnings.append(f"{path.name}:{error.code}")
        except Exception as error:  # noqa: BLE001
            warnings.append(f"{path.name}:{reason(error)}")

    if opts.jobs > 1 and len(files) > PARALLEL_THRESHOLD:
        with concurrent.futures.ThreadPoolExecutor(max_workers=opts.jobs) as pool:
            list(pool.map(collect, files))
    else:
        for path in files:
            collect(path)

    records.sort(key=lambda r: (r["date_sort"], r["title"].casefold()), reverse=True)
    log.info("processed %d document(s), %d warning(s)", len(records), len(warnings))
    return records, warnings


# --------------------------------------------------------------------------
# Writing
# --------------------------------------------------------------------------


def write_atomic(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle_fd, temp_name = tempfile.mkstemp(
        prefix=".toc-", suffix=".tmp", dir=path.parent
    )
    temp_path = Path(temp_name)
    try:
        with os.fdopen(handle_fd, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
    finally:
        temp_path.unlink(missing_ok=True)


def clean_output(output_dir: Path) -> int:
    """Remove only artifacts this tool owns. Returns the number removed."""
    removed = 0
    for child in output_dir.iterdir():
        if child.is_dir() and child.name.startswith("doc-"):
            shutil.rmtree(child, ignore_errors=True)
            removed += 1
        elif child.is_file() and child.name in GENERATED_FILES:
            child.unlink(missing_ok=True)
            removed += 1
    return removed


def full_update(output_dir: Path, records: list[dict[str, Any]]) -> list[str]:
    written: list[str] = []
    for record in records:
        path = output_dir / f"doc-{record['doc_id']}" / "index.html"
        write_atomic(path, record["content"])
        written.append(record["doc_id"])
    return written


def incremental_update(
    output_dir: Path, records: list[dict[str, Any]]
) -> tuple[list[str], list[str], list[str]]:
    """Write new/changed docs, skip unchanged, prune stale folders."""
    output_dir.mkdir(parents=True, exist_ok=True)
    existing = {
        d.name[len("doc-") :]: d
        for d in output_dir.iterdir()
        if d.is_dir() and d.name.startswith("doc-")
    }
    needed = {record["doc_id"] for record in records}

    deleted: list[str] = []
    for doc_id, directory in existing.items():
        if doc_id not in needed:
            shutil.rmtree(directory, ignore_errors=True)
            deleted.append(doc_id)

    written: list[str] = []
    skipped: list[str] = []
    for record in records:
        path = output_dir / f"doc-{record['doc_id']}" / "index.html"
        if (
            path.is_file()
            and path.read_text(encoding="utf-8", errors="ignore") == record["content"]
        ):
            skipped.append(record["doc_id"])
            continue
        write_atomic(path, record["content"])
        written.append(record["doc_id"])
    return written, skipped, deleted


# --------------------------------------------------------------------------
# Exports
# --------------------------------------------------------------------------


def _public(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "title": record["title"],
        "filename": record["filename"],
        "doc_id": record["doc_id"],
        "size": record["size"],
        "word_count": record["word_count"],
        "date": record["date"],
        "date_sort": record["date_sort"],
        "date_source": record["date_source"],
        "summary": record["summary"],
        "tags": record["tags"],
        "toc_items": record["toc_items"],
        "output": f"doc-{record['doc_id']}/index.html",
    }


def export_json(output_dir: Path, records: list[dict[str, Any]]) -> Path:
    payload = [_public(r) for r in records]
    path = output_dir / "data.json"
    write_atomic(path, json.dumps(payload, ensure_ascii=False, indent=2))
    return path


def export_markdown(output_dir: Path, records: list[dict[str, Any]]) -> Path:
    lines = [
        "# 文档索引",
        "",
        f"共收录 {len(records)} 篇文档",
        "",
        "## 目录",
        "",
    ]
    for record in records:
        tags = ", ".join(record["tags"])
        lines.append(
            f"- [{record['title']}](doc-{record['doc_id']}/index.html) "
            f"({record['date']}, {record['word_count']} 字，标签：{tags})"
        )
    lines.extend(
        [
            "",
            "## 说明",
            "",
            "每个文档位于独立的 `doc-<hash>/index.html` 子目录中。",
            "",
            f"生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        ]
    )
    path = output_dir / "INDEX.md"
    write_atomic(path, "\n".join(lines))
    return path


def export_txt(output_dir: Path, records: list[dict[str, Any]]) -> Path:
    lines = [r["filename"] for r in sorted(records, key=lambda r: r["title"])]
    path = output_dir / "file_list.txt"
    write_atomic(path, "\n".join(lines))
    return path


def render_index(title: str, records: list[dict[str, Any]], generated_at: str) -> str:
    columns = [
        {
            "doc_id": r["doc_id"],
            "title": r["title"],
            "summary": r["summary"],
            "filename": r["filename"],
            "size": r["size"],
            "word_count": r["word_count"],
            "date": r["date"],
            "date_sort": r["date_sort"],
            "date_source": r["date_source"],
            "tags": r["tags"],
        }
        for r in records
    ]
    data_json = json.dumps(columns, ensure_ascii=False, separators=(",", ":"))
    stamps = {
        "__PAGE_TITLE__": html.escape(title),
        "__TOTAL__": str(len(records)),
        "__GENERATED_AT__": html.escape(generated_at),
        "__DATA_JSON__": data_json,
    }
    rendered = INDEX_TEMPLATE
    for token, value in stamps.items():
        rendered = rendered.replace(token, value)
    return rendered


# --------------------------------------------------------------------------
# Templates
# --------------------------------------------------------------------------

INDEX_TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="color-scheme" content="light dark">
<base href="./">
<title>__PAGE_TITLE__</title>
<style>
  :root {
    --bg: #f5f6f8; --card-bg: #ffffff; --primary: #2f6fed; --text: #1f2430;
    --muted: #6b7280; --border: #e3e6eb; --tag-bg: #eef2ff; --tag-text: #3b4b8c;
  }
  @media (prefers-color-scheme: dark) {
    :root {
      --bg: #0f1115; --card-bg: #1a1d26; --primary: #4a8aff; --text: #e8eaed;
      --muted: #9aa0a6; --border: #2f333d; --tag-bg: #1e2536; --tag-text: #8ab4f8;
    }
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; background: var(--bg); color: var(--text);
    font-family: -apple-system, "PingFang SC", "Microsoft YaHei", "Segoe UI", Helvetica, Arial, sans-serif;
  }
  header { background: linear-gradient(135deg, #2f6fed, #6a5cf5); color: #fff; padding: 28px 24px 22px; }
  header h1 { margin: 0 0 6px; font-size: 22px; }
  header p { margin: 0; font-size: 13px; opacity: 0.85; }
  .container { max-width: 1080px; margin: 0 auto; padding: 20px 16px 60px; }
  .toolbar {
    display: flex; flex-wrap: wrap; gap: 10px; align-items: center;
    background: var(--card-bg); border: 1px solid var(--border); border-radius: 10px;
    padding: 14px; margin: -30px 0 20px; position: relative; box-shadow: 0 4px 14px rgba(0,0,0,0.06);
  }
  .toolbar input[type="text"], .toolbar select {
    padding: 9px 12px; border: 1px solid var(--border); border-radius: 8px;
    font-size: 14px; background: var(--card-bg); color: var(--text);
  }
  .toolbar input[type="text"] { flex: 1 1 260px; }
  .toolbar select { font-size: 13px; }
  .toolbar button {
    padding: 8px 12px; border: 1px solid var(--border); border-radius: 8px;
    background: var(--card-bg); color: var(--text); cursor: pointer; font-size: 13px;
  }
  .toolbar button.active { background: var(--primary); color: #fff; border-color: var(--primary); }
  .meta-row {
    display: flex; justify-content: space-between; align-items: center;
    font-size: 13px; color: var(--muted); margin-bottom: 12px;
  }
  .tag-filter { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 16px; }
  .tag-filter span {
    padding: 4px 10px; background: var(--tag-bg); color: var(--tag-text);
    border-radius: 14px; font-size: 12px; cursor: pointer; border: 1px solid transparent;
  }
  .tag-filter span.active { border-color: var(--primary); font-weight: 600; }
  .list { display: grid; gap: 12px; }
  .card {
    background: var(--card-bg); border: 1px solid var(--border); border-radius: 10px;
    padding: 14px 16px; transition: box-shadow 0.15s ease, transform 0.15s ease;
  }
  .card:hover { box-shadow: 0 6px 18px rgba(0,0,0,0.08); transform: translateY(-1px); }
  .card a.title-link { font-size: 16px; font-weight: 600; color: var(--primary); text-decoration: none; }
  .card a.title-link:hover { text-decoration: underline; }
  .card .summary { margin: 6px 0 8px; font-size: 13px; line-height: 1.5; }
  .card .info { display: flex; flex-wrap: wrap; gap: 12px; font-size: 12px; color: var(--muted); align-items: center; }
  .card .tags span {
    display: inline-block; margin-right: 6px; padding: 2px 8px;
    background: var(--tag-bg); color: var(--tag-text); border-radius: 10px; font-size: 11px;
  }
  .pagination { display: flex; justify-content: center; align-items: center; gap: 6px; margin-top: 24px; flex-wrap: wrap; }
  .pagination button {
    min-width: 34px; padding: 6px 10px; border: 1px solid var(--border);
    background: var(--card-bg); color: var(--text); border-radius: 6px; cursor: pointer; font-size: 13px;
  }
  .pagination button.active { background: var(--primary); color: #fff; border-color: var(--primary); }
  .pagination button:disabled { opacity: 0.4; cursor: not-allowed; }
  .empty-state { text-align: center; color: var(--muted); padding: 60px 0; font-size: 14px; }
  mark { background: #fff2a8; color: #1f2430; padding: 0 1px; border-radius: 2px; }
  footer { text-align: center; font-size: 12px; color: var(--muted); padding: 20px 0 40px; }
  @media print { .toolbar, .tag-filter, .pagination, footer { display: none; } .card { break-inside: avoid; } }
</style>
</head>
<body>
<header>
  <h1>__PAGE_TITLE__</h1>
  <p>共收录 __TOTAL__ 篇 HTML 文档 · 索引生成时间：__GENERATED_AT__</p>
</header>
<div class="container">
  <div class="toolbar">
    <input type="text" id="searchInput" placeholder="搜索标题 / 摘要 / 文件名 / 标签 … (按 / 聚焦)" autocomplete="off">
    <select id="sortField">
      <option value="date_sort">按日期</option>
      <option value="title">按标题</option>
      <option value="word_count">按字数</option>
      <option value="size">按大小</option>
      <option value="filename">按文件名</option>
    </select>
    <button id="sortDirBtn">降序 ↓</button>
    <select id="pageSizeSelect">
      <option value="10">每页 10</option>
      <option value="20" selected>每页 20</option>
      <option value="50">每页 50</option>
      <option value="100">每页 100</option>
    </select>
  </div>
  <div class="tag-filter" id="tagFilter"></div>
  <div class="meta-row"><span id="resultCount"></span><span id="pageInfo"></span></div>
  <div class="list" id="list"></div>
  <div class="pagination" id="pagination"></div>
</div>
<footer>Generated by build_toc_index.py · 按 / 搜索 · 按 G 回到顶部</footer>
<script>
const DATA = __DATA_JSON__;
const state = { keyword: "", sortField: "date_sort", sortDir: "desc", activeTag: null, page: 1, pageSize: 20 };

function parseHash() {
  const params = new URLSearchParams(window.location.hash.slice(1));
  if (params.get("search")) state.keyword = params.get("search");
  if (params.get("sort")) state.sortField = params.get("sort");
  if (params.get("dir")) state.sortDir = params.get("dir");
  if (params.get("tag")) state.activeTag = params.get("tag");
  if (params.get("page")) state.page = parseInt(params.get("page"), 10) || 1;
  if (params.get("size")) state.pageSize = parseInt(params.get("size"), 10) || 20;
}

function updateHash() {
  const params = new URLSearchParams();
  if (state.keyword) params.set("search", state.keyword);
  if (state.sortField !== "date_sort") params.set("sort", state.sortField);
  if (state.sortDir !== "desc") params.set("dir", state.sortDir);
  if (state.activeTag) params.set("tag", state.activeTag);
  if (state.page > 1) params.set("page", state.page);
  if (state.pageSize !== 20) params.set("size", state.pageSize);
  window.location.hash = params.toString();
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function highlight(text, keyword) {
  if (!keyword) return escapeHtml(text);
  const escaped = escapeHtml(text);
  const escapedKeyword = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  try {
    return escaped.replace(new RegExp(escapedKeyword, "ig"), (m) => `<mark>${m}</mark>`);
  } catch (error) {
    return escaped;
  }
}

function allTags() {
  const set = new Set();
  DATA.forEach((doc) => doc.tags.forEach((tag) => set.add(tag)));
  return Array.from(set).sort();
}

function getFiltered() {
  const keyword = state.keyword.trim().toLowerCase();
  const filtered = DATA.filter((doc) => {
    if (state.activeTag && !doc.tags.includes(state.activeTag)) return false;
    if (!keyword) return true;
    return doc.title.toLowerCase().includes(keyword)
      || doc.summary.toLowerCase().includes(keyword)
      || doc.filename.toLowerCase().includes(keyword)
      || doc.tags.some((tag) => tag.toLowerCase().includes(keyword));
  });
  filtered.sort((a, b) => {
    let va = a[state.sortField];
    let vb = b[state.sortField];
    if (typeof va === "string") {
      va = va.toLowerCase();
      vb = vb.toLowerCase();
      return state.sortDir === "asc" ? va.localeCompare(vb, "zh") : vb.localeCompare(va, "zh");
    }
    return state.sortDir === "asc" ? va - vb : vb - va;
  });
  return filtered;
}

function formatSize(n) {
  const units = ["B", "KB", "MB", "GB"];
  let size = n;
  let i = 0;
  while (size >= 1024 && i < units.length - 1) { size /= 1024; i++; }
  return (i === 0 ? size.toFixed(0) : size.toFixed(1)) + units[i];
}

function renderList(items) {
  const listEl = document.getElementById("list");
  if (items.length === 0) {
    listEl.innerHTML = '<div class="empty-state">没有匹配的文档</div>';
    return;
  }
  const keyword = state.keyword.trim();
  listEl.innerHTML = items.map((doc) => `
    <div class="card">
      <a class="title-link" href="doc-${doc.doc_id}/index.html" target="_blank" rel="noopener">${highlight(doc.title, keyword)}</a>
      <div class="summary">${highlight(doc.summary, keyword)}</div>
      <div class="info">
        <span>📅 ${doc.date} (${doc.date_source})</span>
        <span>📦 ${formatSize(doc.size)}</span>
        <span>📝 ${doc.word_count} 字</span>
        <span>📄 ${escapeHtml(doc.filename)}</span>
        <span class="tags">${doc.tags.map((tag) => `<span>${escapeHtml(tag)}</span>`).join("")}</span>
      </div>
    </div>
  `).join("");
}

function renderTagFilter() {
  const el = document.getElementById("tagFilter");
  el.innerHTML = allTags().map((tag) =>
    `<span data-tag="${escapeHtml(tag)}" class="${state.activeTag === tag ? "active" : ""}">${escapeHtml(tag)}</span>`
  ).join("");
  el.querySelectorAll("span").forEach((span) => {
    span.addEventListener("click", () => {
      const tag = span.getAttribute("data-tag");
      state.activeTag = state.activeTag === tag ? null : tag;
      state.page = 1;
      updateHash();
      render();
    });
  });
}

function renderPagination(totalItems) {
  const pag = document.getElementById("pagination");
  const totalPages = Math.max(1, Math.ceil(totalItems / state.pageSize));
  if (state.page > totalPages) state.page = totalPages;
  let html = `<button ${state.page <= 1 ? "disabled" : ""} data-page="${state.page - 1}">‹</button>`;
  const radius = 2;
  for (let p = 1; p <= totalPages; p++) {
    if (p === 1 || p === totalPages || Math.abs(p - state.page) <= radius) {
      html += `<button data-page="${p}" class="${p === state.page ? "active" : ""}">${p}</button>`;
    } else if (Math.abs(p - state.page) === radius + 1) {
      html += `<span style="padding:0 4px;color:#999;">…</span>`;
    }
  }
  html += `<button ${state.page >= totalPages ? "disabled" : ""} data-page="${state.page + 1}">›</button>`;
  pag.innerHTML = html;
  pag.querySelectorAll("button[data-page]").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.page = parseInt(btn.getAttribute("data-page"), 10);
      updateHash();
      render();
    });
  });
  document.getElementById("pageInfo").textContent = `第 ${state.page} / ${totalPages} 页`;
}

function render() {
  const filtered = getFiltered();
  document.getElementById("resultCount").textContent = `共找到 ${filtered.length} 篇（总计 ${DATA.length} 篇）`;
  const start = (state.page - 1) * state.pageSize;
  renderList(filtered.slice(start, start + state.pageSize));
  renderPagination(filtered.length);
  renderTagFilter();
}

document.getElementById("searchInput").addEventListener("input", (event) => {
  state.keyword = event.target.value;
  state.page = 1;
  updateHash();
  render();
});
document.getElementById("sortField").addEventListener("change", (event) => {
  state.sortField = event.target.value;
  updateHash();
  render();
});
document.getElementById("sortDirBtn").addEventListener("click", (event) => {
  state.sortDir = state.sortDir === "asc" ? "desc" : "asc";
  event.target.textContent = state.sortDir === "asc" ? "升序 ↑" : "降序 ↓";
  updateHash();
  render();
});
document.getElementById("pageSizeSelect").addEventListener("change", (event) => {
  state.pageSize = parseInt(event.target.value, 10);
  state.page = 1;
  updateHash();
  render();
});
document.addEventListener("keydown", (event) => {
  if (event.key === "/" && document.activeElement.tagName !== "INPUT") {
    event.preventDefault();
    document.getElementById("searchInput").focus();
  }
  if (event.key === "Escape" && document.activeElement.id === "searchInput") {
    document.getElementById("searchInput").value = "";
    state.keyword = "";
    updateHash();
    render();
  }
  if (event.key.toLowerCase() === "g" && document.activeElement.tagName !== "INPUT") {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
});

parseHash();
document.getElementById("searchInput").value = state.keyword;
document.getElementById("sortField").value = state.sortField;
document.getElementById("sortDirBtn").textContent = state.sortDir === "asc" ? "升序 ↑" : "降序 ↓";
document.getElementById("pageSizeSelect").value = state.pageSize;
render();
</script>
</body>
</html>
"""

DOC_TOC_TEMPLATE = r"""<nav class="doc-toc" data-doc-toc="1" aria-label="文档目录">
  <button class="doc-toc-toggle" type="button" aria-expanded="true">☰ 目录</button>
  <ul class="doc-toc-list">
__ITEMS__
  </ul>
</nav>
<style>
  .doc-toc { position: fixed; top: 16px; right: 16px; z-index: 9999; max-width: 260px;
    max-height: 80vh; overflow: auto; background: rgba(255,255,255,.96); color: #1f2430;
    border: 1px solid #e3e6eb; border-radius: 10px; padding: 10px 12px; font-size: 13px;
    box-shadow: 0 6px 20px rgba(0,0,0,.12); font-family: -apple-system,"PingFang SC",sans-serif; }
  .doc-toc.collapsed .doc-toc-list { display: none; }
  .doc-toc-toggle { cursor: pointer; border: none; background: none; font-size: 13px;
    font-weight: 600; color: #2f6fed; padding: 0 0 6px; }
  .doc-toc-list { list-style: none; margin: 0; padding: 0; }
  .doc-toc-list li { margin: 3px 0; }
  .doc-toc-l1 { padding-left: 12px; } .doc-toc-l2 { padding-left: 24px; } .doc-toc-l3 { padding-left: 36px; }
  .doc-toc-list a { color: #1f2430; text-decoration: none; }
  .doc-toc-list a:hover { color: #2f6fed; text-decoration: underline; }
  @media (prefers-color-scheme: dark) {
    .doc-toc { background: rgba(26,29,38,.96); color: #e8eaed; border-color: #2f333d; }
    .doc-toc-list a { color: #e8eaed; }
  }
  @media print { .doc-toc { display: none; } }
</style>
<script>
(function () {
  const nav = document.querySelector('.doc-toc[data-doc-toc="1"]');
  if (!nav) return;
  const toggle = nav.querySelector(".doc-toc-toggle");
  toggle.addEventListener("click", () => {
    const collapsed = nav.classList.toggle("collapsed");
    toggle.setAttribute("aria-expanded", String(!collapsed));
  });
  nav.querySelectorAll("a[href^='#']").forEach((link) => {
    link.addEventListener("click", (event) => {
      const target = document.getElementById(decodeURIComponent(link.getAttribute("href").slice(1)));
      if (target) {
        event.preventDefault();
        target.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    });
  });
})();
</script>
"""


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------


def resolve_jobs(requested: Optional[str], count: int) -> int:
    if count <= 0:
        return 1
    if requested in (None, "", "auto"):
        return max(1, min(DEFAULT_JOBS_CAP, count))
    try:
        value = int(requested)
    except (TypeError, ValueError):
        raise BuildError("invalid_jobs_value") from None
    return max(1, min(DEFAULT_JOBS_CAP, value, count))


def _setup_logging(verbose: bool, log_file: Optional[str]) -> None:
    log.setLevel(logging.DEBUG if verbose else logging.INFO)
    log.handlers.clear()
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(message)s", "%H:%M:%S"
    )
    console = logging.StreamHandler(sys.stderr)
    console.setLevel(logging.DEBUG if verbose else logging.INFO)
    console.setFormatter(formatter)
    log.addHandler(console)
    if log_file:
        path = Path(log_file).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        handler = logging.FileHandler(path, encoding="utf-8")
        handler.setLevel(logging.DEBUG)
        handler.setFormatter(formatter)
        log.addHandler(handler)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="build_toc_index.py",
        description="Batch-build a searchable TOC index over a directory of HTML documents.",
    )
    parser.add_argument(
        "input_dir", nargs="?", default=DEFAULT_INPUT, help="input directory"
    )
    parser.add_argument(
        "-o", "--output", default=DEFAULT_OUTPUT, help="output directory"
    )
    parser.add_argument("--title", default="文档索引", help="index page title")
    parser.add_argument(
        "-r", "--recursive", action="store_true", help="scan sub-directories"
    )
    parser.add_argument(
        "--exclude-pattern",
        action="append",
        default=[],
        help="regex on filename to skip",
    )
    parser.add_argument(
        "--places-file", type=Path, help="custom place dictionary (one per line)"
    )
    parser.add_argument(
        "--incremental", action="store_true", help="skip unchanged documents"
    )
    parser.add_argument(
        "--inject-doc-toc",
        action="store_true",
        help="inject a heading TOC into each document",
    )
    parser.add_argument("--export-json", action="store_true")
    parser.add_argument("--export-markdown", action="store_true")
    parser.add_argument("--export-txt", action="store_true")
    parser.add_argument(
        "--jobs", default="auto", help="parallel workers (default: auto, cap 8)"
    )
    parser.add_argument(
        "--no-parallel", action="store_true", help="disable parallelism"
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="plan only, write nothing"
    )
    parser.add_argument(
        "--json", action="store_true", help="print a JSON report to stdout"
    )
    parser.add_argument("--report", help="also write the JSON report to this file")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--log-file")
    parser.add_argument(
        "-v", "--version", action="version", version=f"%(prog)s {VERSION}"
    )
    return parser


def _validate_paths(input_dir: Path, output_dir: Path) -> None:
    if not input_dir.is_dir():
        raise BuildError("input_not_found")
    resolved_in = input_dir.resolve()
    resolved_out = output_dir.resolve()
    if resolved_out == resolved_in:
        raise BuildError("output_equals_input")
    if resolved_in in resolved_out.parents:
        raise BuildError("output_within_input")


def run(args: argparse.Namespace) -> tuple[dict[str, Any], int]:
    input_dir = Path(args.input_dir).expanduser()
    output_dir = Path(args.output).expanduser()
    _validate_paths(input_dir, output_dir)
    input_dir = input_dir.resolve()
    output_dir = output_dir.resolve()

    places = load_places_file(args.places_file)
    opts = Options(
        recursive=args.recursive,
        exclude_patterns=list(args.exclude_pattern or []),
        inject_doc_toc=args.inject_doc_toc,
        jobs=1,
    )

    started = time.perf_counter()
    files = scan_files(input_dir, opts.recursive, opts.exclude_patterns)
    opts.jobs = 1 if args.no_parallel else resolve_jobs(args.jobs, len(files))
    records, warnings = build_records(files, places, opts)

    summary = {
        "scanned": len(files),
        "total": len(records),
        "written": 0,
        "skipped": 0,
        "deleted": 0,
        "failed": len(warnings),
    }
    report: dict[str, Any] = {
        "version": VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "input_dir": str(input_dir),
        "output_dir": str(output_dir),
        "recursive": bool(args.recursive),
        "incremental": bool(args.incremental),
        "inject_doc_toc": bool(args.inject_doc_toc),
        "dry_run": bool(args.dry_run),
        "docs": [_public(r) for r in records],
        "warnings": warnings,
        "summary": summary,
    }

    if args.dry_run:
        report["status"] = "dry_run"
        report["elapsed_seconds"] = round(time.perf_counter() - started, 3)
        return report, 0

    output_dir.mkdir(parents=True, exist_ok=True)

    if args.incremental:
        written, skipped, deleted = incremental_update(output_dir, records)
        summary["written"] = len(written)
        summary["skipped"] = len(skipped)
        summary["deleted"] = len(deleted)
    else:
        clean_output(output_dir)
        written = full_update(output_dir, records)
        summary["written"] = len(written)

    index_html = render_index(
        args.title, records, datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    )
    write_atomic(output_dir / "index.html", index_html)

    if args.export_json:
        export_json(output_dir, records)
    if args.export_markdown:
        export_markdown(output_dir, records)
    if args.export_txt:
        export_txt(output_dir, records)

    report["status"] = "partial_failure" if warnings else "complete"
    report["elapsed_seconds"] = round(time.perf_counter() - started, 3)
    return report, (2 if warnings else 0)


def _emit(args: argparse.Namespace, report: dict[str, Any]) -> None:
    if args.report:
        path = Path(args.report).expanduser()
        write_atomic(path, json.dumps(report, ensure_ascii=False, indent=2))
        report["report_path"] = str(path)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))


def _print_summary(report: dict[str, Any]) -> None:
    summary = report["summary"]
    log.info(
        "done: status=%s total=%d written=%d skipped=%d deleted=%d failed=%d (%.2fs)",
        report["status"],
        summary["total"],
        summary["written"],
        summary["skipped"],
        summary["deleted"],
        summary["failed"],
        report["elapsed_seconds"],
    )
    if not summary["total"]:
        log.warning("no HTML documents found under %s", report["input_dir"])


# Long options that take a value; used to keep values starting with '-' (e.g.
# ``--exclude-pattern '-email'``) from being mistaken for options by argparse.
_VALUE_OPTIONS = frozenset(
    {
        "--output",
        "--title",
        "--exclude-pattern",
        "--places-file",
        "--jobs",
        "--report",
        "--log-file",
    }
)


def _normalize_argv(argv: Optional[list[str]]) -> list[str]:
    if argv is None:
        argv = sys.argv[1:]
    normalized: list[str] = []
    index = 0
    while index < len(argv):
        token = argv[index]
        if token in _VALUE_OPTIONS and index + 1 < len(argv):
            normalized.append(f"{token}={argv[index + 1]}")
            index += 2
            continue
        normalized.append(token)
        index += 1
    return normalized


def main(argv: Optional[list[str]] = None) -> int:
    args = build_parser().parse_args(_normalize_argv(argv))
    _setup_logging(args.verbose, args.log_file)
    try:
        report, code = run(args)
    except BuildError as error:
        if args.json:
            print(json.dumps({"status": "error", "reason": error.code}))
        else:
            log.error("error: %s", error.code)
        return 1
    except Exception as error:  # noqa: BLE001
        code = reason(error)
        if args.json:
            print(json.dumps({"status": "error", "reason": code}))
        else:
            log.error("error: %s", code)
        return 1
    _emit(args, report)
    if not args.json:
        _print_summary(report)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
