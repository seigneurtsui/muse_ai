#!/usr/bin/env python3
"""Cross-platform adaptation of /tmp/s2t/scripts/chinese_converter_cli.py.

Retains its s2t/t2s modes, batch paths, recursive layout, suffix and preview
interface. Uses OpenCC APIs rather than passing whole documents in argv to a
macOS-only binary. No network, model, credential or package-install operations.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from batch_files import MAX_FILE_BYTES, reason, run_batch
from conversion_core import SUPPORTED_ENCODINGS, ConversionError, decode_document, normalize_document

DEFAULT_INPUT_DIR = Path.home() / "Downloads" / "chinois_input"
DEFAULT_OUTPUT_DIR = Path.home() / "Downloads" / "chinois_output"
MODE_OPTIONS = {"s2t": "简体 → 繁体", "t2s": "繁体 → 简体"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="批量简繁体转换：macOS 原生 OpenCC + Python OpenCC 跨平台备用", formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""示例：
  python chinese_converter_cli.py --doctor
  python chinese_converter_cli.py -m s2t -i /path/to/input -o /path/to/output -r
  python chinese_converter_cli.py -m t2s -i /path/to/file.md --engine opencc
  python chinese_converter_cli.py -m s2t -i /path/to/input --dry-run --preview
  python chinese_converter_cli.py -m s2t --text '简体中文示例'

默认不覆盖输入或已有输出。--overwrite 仅沿用旧接口的“输出同名”，
不允许写回源文件；--replace 才明确允许替换已有输出。--preview 单用仍会写入，
要仅预览请同时使用 --dry-run。无可用 OpenCC 时失败，不复制原文冒充转换。
可选安装（不会自动执行）：python -m pip install opencc-python-reimplemented
""")
    parser.add_argument("-m", "--mode", choices=MODE_OPTIONS, help="s2t 简→繁；t2s 繁→简")
    parser.add_argument("-i", "--input", type=Path, default=DEFAULT_INPUT_DIR, help="输入目录或单文件")
    parser.add_argument("-o", "--output", type=Path, default=DEFAULT_OUTPUT_DIR, help="独立输出目录")
    parser.add_argument("-r", "--recursive", action="store_true", help="递归，保留子目录结构")
    parser.add_argument("--suffix", default="_converted", help="输出文件名后缀，默认 _converted")
    parser.add_argument("--overwrite", "--keep-name", action="store_true", help="输出同名文件，不代表可覆盖源文件或已有输出")
    parser.add_argument("--replace", action="store_true", help="明确允许替换已有输出；仍禁止覆盖任何输入文件")
    parser.add_argument("--engine", choices=("auto", "native", "opencc"), default="auto")
    parser.add_argument("--encoding", choices=SUPPORTED_ENCODINGS, default="auto", help="输入编码；auto 检查 BOM，再尝试 UTF-8 / GB18030")
    parser.add_argument("--output-encoding", choices=("utf-8", "same"), default="utf-8", help="默认 UTF-8；same 严格保留输入编码与 BOM")
    parser.add_argument("--dry-run", action="store_true", help="不创建输出、锁或报告文件")
    parser.add_argument("--preview", action="store_true", help="显示每篇前 200 字转换对比，须允许在本地输出正文片段")
    parser.add_argument("--strict", action=argparse.BooleanOptionalAction, default=True, help="默认字形二次确认仍失败时不写正文；--no-strict 可写为 needs_review")
    parser.add_argument("--doctor", action="store_true", help="检查本机引擎和合成短句转换，不读取文档")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--text", help="直接转换短文本；私密或长文本建议使用 --stdin")
    group.add_argument("--stdin", action="store_true", help="从标准输入读取 UTF-8 / 所选编码的纯文本")
    parser.add_argument("--json", action="store_true", help="文本模式也输出 JSON；批量模式始终输出 JSON")
    return parser


def print_json(value):
    print(json.dumps(value, ensure_ascii=False, indent=2))


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.doctor:
            from conversion_engines import doctor
            result = doctor()
            print_json(result)
            return 0 if result.get("auto_backend") else 1
        if args.mode is None:
            parser.error("转换需要 -m s2t 或 -m t2s")
        if args.text is not None or args.stdin:
            if args.stdin:
                raw = sys.stdin.buffer.read(MAX_FILE_BYTES + 1)
                if len(raw) > MAX_FILE_BYTES:
                    raise ConversionError("stdin_over_16_mib")
                text = decode_document(raw, args.encoding).text
            else:
                text = args.text
                if len(text.encode("utf-8")) > MAX_FILE_BYTES:
                    raise ConversionError("text_over_16_mib")
            if args.dry_run and not args.preview:
                print_json({"status": "dry_run", "mode": args.mode, "chars": len(text), "conversion_performed": False})
                return 0
            from conversion_engines import get_engine
            engine = get_engine(args.mode, args.engine)
            try:
                converted, checks = normalize_document(text, engine, args.mode)
                failed = checks["passed"] is False
                result = {"status": "failed" if failed and args.strict else "needs_review" if failed else "previewed" if args.dry_run else "converted",
                          "mode": args.mode, "engine": engine.metadata(), "checks": checks}
                if not (failed and args.strict):
                    result["text"] = converted
                if args.json or args.dry_run or failed:
                    print_json(result)
                else:
                    sys.stdout.write(converted)
                return 1 if failed else 0
            finally:
                engine.close()
        # Lazy import keeps listing-only dry runs usable without any backend.
        def factory(mode, backend):
            from conversion_engines import get_engine
            return get_engine(mode, backend)
        result, exit_code = run_batch(args, factory)
        print_json(result)
        return exit_code
    except Exception as error:
        code = reason(error)
        hint = ("请查看 --doctor。缺少跨平台引擎时可自行安装 opencc-python-reimplemented；程序不会自动安装或把原文当作已转换结果。"
                if code == "engine_error" else "请核对输入输出路径、文件权限、编码及 --help。输入文件不会被覆盖；批次中已成功生成的输出予以保留。")
        print_json({"status": "error", "reason": code, "hint": hint})
        return 2


if __name__ == "__main__":
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", newline="")
    raise SystemExit(main())
