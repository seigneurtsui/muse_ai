# Markdown 提交演示

这是一份合成示例，用于本地预览。安装不会自动提交此文件。

## 支持的常见结构

- 普通段落和标题
- 简单列表与表格
- 引用和代码

| 项目 | 说明 |
| --- | --- |
| Answer | 创建问题并保留 Markdown 正文 |
| Readeck | 临时 HTML 由服务端抓取 |

> 预览不登录、不提交，也不启动回抓服务器。

```javascript
const example = 'synthetic demonstration';
```
