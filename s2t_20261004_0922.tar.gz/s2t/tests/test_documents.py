from __future__ import annotations

import codecs
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))
from conversion_core import (ConversionError, SIMPLIFIED_MARKERS, TRADITIONAL_MARKERS,
    check_glyphs, decode_document, encode_document, normalize_document, convert_document, srt_dialogue_ranges)
from batch_files import run_batch, atomic_write
from chinese_converter_cli import build_parser
from conversion_engines import get_engine, EngineError


class FakeEngine:
    name = 'fixture'
    def __init__(self, fn=lambda s: s):
        self.fn, self.closed, self.calls = fn, False, []
    def convert(self, text):
        self.calls.append(text)
        return self.fn(text)
    def metadata(self):
        return {'selected_backend': self.name, 'synthetic': True}
    def close(self):
        self.closed = True


class CoreTests(unittest.TestCase):
    def test_markers_are_disjoint_and_shared_glyphs_not_proof(self):
        self.assertFalse(SIMPLIFIED_MARKERS & TRADITIONAL_MARKERS)
        self.assertIsNone(check_glyphs('你我他，后里台干余著 ABC 123', 's2t')['passed'])
        self.assertFalse(check_glyphs('漢語漢語汉', 's2t')['passed'])
        self.assertTrue(check_glyphs('漢語', 's2t')['passed'])
        self.assertTrue(check_glyphs('汉语', 't2s')['passed'])

    def test_optional_second_pass_uses_original_structure(self):
        engine = FakeEngine(lambda text: '汉语' if len(engine.calls) == 1 else '漢語')
        text, checks = normalize_document('汉语', engine, 's2t')
        self.assertEqual(text, '漢語')
        self.assertTrue(checks['second_conversion_applied'])
        self.assertFalse(checks['first_check']['passed'])
        self.assertTrue(checks['final_check']['passed'])
        self.assertEqual(len(engine.calls), 2)

    def test_failed_confirmation_is_not_success(self):
        text, checks = normalize_document('汉语', FakeEngine(), 's2t')
        self.assertEqual(text, '汉语')
        self.assertFalse(checks['passed'])
        self.assertTrue(checks['second_conversion_applied'])

    def test_no_marker_evidence_is_explicit(self):
        text, checks = normalize_document('  ABC\r\n\t123\n', FakeEngine(), 's2t')
        self.assertEqual(text, '  ABC\r\n\t123\n')
        self.assertIsNone(checks['passed'])
        self.assertEqual(checks['final_check']['status'], 'insufficient_evidence')

    def test_srt_keeps_numeric_arrow_dialogue_and_exact_metadata(self):
        source = '\r\n  1 \r\n00:00:01,100 --> 00:00:02,200 X1:10\r\n汉语\r\n123\r\n--> 台词汉字\r\n\r\n2\n00:00:03.000 --> 00:00:04.000\n<i>汉语</i>'
        converted, count = convert_document(source, lambda s: s.replace('汉', '漢').replace('语', '語'), 'srt')
        self.assertEqual(count, 2)
        self.assertEqual(converted, source.replace('汉', '漢').replace('语', '語'))
        self.assertIn('\r\n123\r\n', converted)
        self.assertIn('--> 台词漢字', converted)
        self.assertEqual(srt_dialogue_ranges(source)[1], srt_dialogue_ranges(converted)[1])

    def test_empty_srt_cues_and_numeric_only_dialogues_survive(self):
        source = '1\n00:00:00,000 --> 00:00:01,000\n\n2\n00:00:01,000 --> 00:00:02,000\n20261003\n'
        self.assertEqual(convert_document(source, lambda s: s, 'srt'), (source, 2))
        self.assertEqual(convert_document('', lambda s: s, 'srt'), ('', 0))

    def test_malformed_srt_fails_instead_of_guessing(self):
        for source in ['汉语', 'one\n00:00:00,000 --> 00:00:01,000\n汉语', '1\n00:99:00,000 --> 00:00:01,000\n汉语', '1\n00:00:02,000 --> 00:00:01,000\n汉语']:
            with self.subTest(source=source), self.assertRaises(ConversionError):
                convert_document(source, lambda s: s, 'srt')

    def test_whitespace_strip_and_line_loss_are_rejected(self):
        for fn in [lambda s: s.strip(), lambda s: s.replace('\r\n', '\n'), lambda s: '']:
            with self.assertRaises(ConversionError):
                convert_document('  汉语\r\n\r\n', fn, 'text')
        with self.assertRaises(ConversionError):
            convert_document('1\n00:00:00,000 --> 00:00:01,000\n汉\n语\n', lambda s: s.replace('\n', ''), 'srt')

    def test_backend_switch_restarts_whole_srt_not_only_current_cue(self):
        class Switching(FakeEngine):
            name = 'native'
            def convert(self, text):
                self.calls.append(text)
                if len(self.calls) == 2:
                    self.name = 'opencc'
                return text.replace('x', 'n' if self.name == 'native' else 'p')
        engine = Switching()
        source = '1\n00:00:00,000 --> 00:00:01,000\nx\n\n2\n00:00:01,000 --> 00:00:02,000\nx\n'
        output, checks = normalize_document(source, engine, 's2t', 'srt')
        self.assertEqual(output, source.replace('x', 'p'))
        self.assertTrue(checks['backend_restart_applied'])

    def test_encoding_auto_bom_and_same_encoding_roundtrip(self):
        text = '汉语\r\n\tABC\n'
        samples = [(text.encode('utf-8'), 'utf-8'), (codecs.BOM_UTF8 + text.encode('utf-8'), 'utf-8'),
                   (codecs.BOM_UTF16_LE + text.encode('utf-16-le'), 'utf-16-le'),
                   (codecs.BOM_UTF16_BE + text.encode('utf-16-be'), 'utf-16-be'), (text.encode('gb18030'), 'gb18030')]
        for raw, expected in samples:
            with self.subTest(expected=expected, raw=raw):
                document = decode_document(raw)
                self.assertEqual(document.text, text)
                self.assertEqual(document.encoding, expected)
                self.assertEqual(encode_document(text, document, 'same'), raw)
                utf8 = encode_document(text, document)
                self.assertEqual(utf8.decode('utf-8-sig'), text)
                self.assertEqual(utf8.startswith(codecs.BOM_UTF8), raw.startswith(codecs.BOM_UTF8))

    def test_explicit_big5_and_bomless_utf16(self):
        text = '漢語\r\n'
        for encoding in ('big5', 'utf-16-le', 'utf-16-be'):
            doc = decode_document(text.encode(encoding), encoding)
            self.assertEqual(doc.text, text)
            self.assertEqual(encode_document(text, doc, 'same'), text.encode(encoding))

    def test_encoding_failures_do_not_replace_characters(self):
        for raw in (b'\xff', b'hello\0world', codecs.BOM_UTF32_LE + b'\0' * 8):
            with self.assertRaises(ConversionError): decode_document(raw)
        with self.assertRaises(ConversionError): decode_document(codecs.BOM_UTF16_LE + '汉'.encode('utf-16-le'), 'utf-8')
        doc = decode_document(b'ASCII', 'gbk')
        with self.assertRaises(ConversionError): encode_document('😀', doc, 'same')


class BatchTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source, self.output = self.root / 'input', self.root / 'output'
        self.source.mkdir()

    def put(self, name='doc.txt', data='汉语\n'):
        p = self.source / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data.encode('utf-8') if isinstance(data, str) else data)
        return p

    def args(self, *extra):
        return build_parser().parse_args(['-m','s2t','-i',str(self.source),'-o',str(self.output),*extra])

    def engine(self, mode, backend):
        return FakeEngine(lambda s: s.replace('汉','漢').replace('语','語'))

    def test_single_file_works_and_source_bytes_unchanged(self):
        source = self.put(data=codecs.BOM_UTF8 + ' \t汉语\r\n\r\n'.encode())
        original = source.read_bytes()
        report, code = run_batch(self.args('-i',str(source)), self.engine)
        self.assertEqual(code, 0)
        self.assertEqual(source.read_bytes(), original)
        self.assertEqual((self.output/'doc_converted.txt').read_bytes(), codecs.BOM_UTF8+' \t漢語\r\n\r\n'.encode())
        persisted = json.loads(Path(report['report_path']).read_text())
        self.assertEqual(persisted['converted'], 1)
        self.assertFalse((self.output/'.s2t.lock').exists())

    def test_recursive_formats_layout_and_hidden_exclusion(self):
        self.put('sub/a.MD'); self.put('b.markdown'); self.put('.hidden.txt'); self.put('node_modules/a.md')
        self.put('cue.srt','1\r\n00:00:00,000 --> 00:00:01,000\r\n汉语\r\n123\r\n')
        self.put('ignored.pdf',b'not a text format')
        report, code = run_batch(self.args('-r'), self.engine)
        self.assertEqual(code, 0); self.assertEqual(report['total'], 3)
        self.assertTrue((self.output/'sub/a_converted.MD').exists())
        self.assertIn(b'\r\n123\r\n', (self.output/'cue_converted.srt').read_bytes())

    def test_non_recursive_and_empty_directory(self):
        self.put('sub/a.txt')
        report, code = run_batch(self.args(), self.engine)
        self.assertEqual(code,0); self.assertEqual(report['total'],0)
        self.assertEqual(report['reason'],'no_supported_files'); self.assertFalse(self.output.exists())

    def test_dry_run_needs_no_engine_and_creates_nothing(self):
        self.put()
        def forbidden(*args): raise AssertionError('must not load engine')
        report, code = run_batch(self.args('--dry-run'), forbidden)
        self.assertEqual(code,0); self.assertEqual(report['planned'],1); self.assertFalse(self.output.exists())
        self.assertNotIn('preview',report['results'][0])

    def test_preview_dry_run_really_converts_but_does_not_write(self):
        self.put(); report, code = run_batch(self.args('--dry-run','--preview'), self.engine)
        self.assertEqual(code,0); self.assertEqual(report['previewed'],1)
        self.assertEqual(report['results'][0]['preview']['after'],'漢語\n')
        self.assertFalse(self.output.exists())

    def test_default_no_overwrite_and_explicit_replace(self):
        self.put(); self.output.mkdir(); target=self.output/'doc_converted.txt';target.write_text('user-edited')
        report, code=run_batch(self.args(),self.engine)
        self.assertEqual(code,1);self.assertEqual(report['failed'],1);self.assertEqual(target.read_text(),'user-edited')
        report, code=run_batch(self.args('--replace'),self.engine)
        self.assertEqual(code,0);self.assertEqual(target.read_text(),'漢語\n')

    def test_original_overwrite_flag_only_keeps_name(self):
        self.put();report,code=run_batch(self.args('--overwrite'),self.engine)
        self.assertEqual(code,0);self.assertTrue((self.output/'doc.txt').exists())
        self.assertEqual((self.source/'doc.txt').read_text(),'汉语\n')

    def test_source_file_never_overwritten_even_with_replace(self):
        source=self.put()
        report,code=run_batch(self.args('-i',str(source),'-o',str(self.source),'--overwrite','--replace'),self.engine)
        self.assertEqual(code,1);self.assertEqual(report['results'][0]['reason'],'refusing_to_overwrite_input')
        self.assertEqual(source.read_text(),'汉语\n')

    def test_same_input_output_directory_rejected(self):
        self.put()
        with self.assertRaisesRegex(ConversionError,'equals_input'):run_batch(self.args('-o',str(self.source)),self.engine)

    def test_nested_output_is_excluded_from_recursive_input(self):
        self.put(); output=self.source/'converted';output.mkdir();(output/'old.md').write_text('already converted')
        report,code=run_batch(self.args('-r','-o',str(output)),self.engine)
        self.assertEqual(code,0);self.assertEqual(report['total'],1)
        self.assertEqual(report['excluded'][0]['reason'],'output_directory_excluded')

    def test_missing_backend_fails_before_creating_output(self):
        self.put()
        def missing(*args): raise EngineError('synthetic unavailable engine')
        with self.assertRaises(EngineError):run_batch(self.args(),missing)
        self.assertFalse(self.output.exists())

    def test_strict_failed_check_does_not_write_original_as_success(self):
        self.put();report,code=run_batch(self.args(),lambda *a:FakeEngine())
        self.assertEqual(code,1);self.assertEqual(report['failed'],1)
        self.assertFalse((self.output/'doc_converted.txt').exists())
        self.assertFalse((self.output/'.s2t.lock').exists())

    def test_non_strict_saves_but_marks_needs_review(self):
        self.put();report,code=run_batch(self.args('--no-strict'),lambda *a:FakeEngine())
        self.assertEqual(code,1);self.assertEqual(report['needs_review'],1)
        self.assertEqual((self.output/'doc_converted.txt').read_text(),'汉语\n')

    def test_symlink_inputs_and_output_escape_are_blocked(self):
        src=self.put();outside=self.root/'outside.txt';outside.write_text('private')
        try:(self.source/'link.txt').symlink_to(outside)
        except (OSError,NotImplementedError):self.skipTest('OS does not allow symlink fixtures')
        report,code=run_batch(self.args('--dry-run'),self.engine)
        self.assertEqual(code,0);self.assertEqual(report['total'],1)
        self.assertEqual(report['excluded'][0]['reason'],'link_not_followed')
        self.output.mkdir();(self.output/'doc_converted.txt').symlink_to(outside)
        report,code=run_batch(self.args('--replace'),self.engine)
        self.assertEqual(code,1);self.assertEqual(outside.read_text(),'private')

    def test_output_parent_symlink_cannot_write_elsewhere(self):
        self.put('sub/a.txt');self.output.mkdir();outside=self.root/'outside';outside.mkdir()
        try:(self.output/'sub').symlink_to(outside,target_is_directory=True)
        except (OSError,NotImplementedError):self.skipTest('OS does not allow symlink fixtures')
        report,code=run_batch(self.args('-r'),self.engine)
        self.assertEqual(code,1);self.assertFalse((outside/'a_converted.txt').exists())

    def test_hardlinked_destination_does_not_modify_input(self):
        src=self.put();self.output.mkdir()
        try:os.link(src,self.output/'doc_converted.txt')
        except OSError:self.skipTest('filesystem lacks hardlinks')
        report,code=run_batch(self.args('--replace'),self.engine)
        self.assertEqual(code,1);self.assertEqual(src.read_text(),'汉语\n')

    def test_output_lock_is_not_silently_removed(self):
        self.put();self.output.mkdir();lock=self.output/'.s2t.lock';lock.mkdir();(lock/'owner.json').write_text('{}')
        with self.assertRaisesRegex(ConversionError,'locked'):run_batch(self.args(),self.engine)
        self.assertTrue(lock.exists())

    def test_atomic_failure_removes_reserved_output_and_temp(self):
        target=self.root/'result.txt'
        with patch('batch_files.os.replace',side_effect=OSError('synthetic failure')):
            with self.assertRaises(OSError):atomic_write(target,b'content')
        self.assertFalse(target.exists());self.assertFalse(list(self.root.glob('.s2t-*.tmp')))
        target.write_bytes(b'existing')
        with self.assertRaises(FileExistsError):atomic_write(target,b'other')
        self.assertEqual(target.read_bytes(),b'existing')

    def test_source_change_mid_conversion_is_detected(self):
        src=self.put()
        def mutate(text):src.write_text('new user content');return text.replace('汉','漢').replace('语','語')
        report,code=run_batch(self.args(),lambda *a:FakeEngine(mutate))
        self.assertEqual(code,1);self.assertEqual(report['results'][0]['reason'],'source_changed_during_conversion')
        self.assertFalse((self.output/'doc_converted.txt').exists())

    def test_bad_encoding_or_srt_does_not_prevent_other_file(self):
        self.put('a.txt',b'\xff');self.put('bad.srt','not subtitles');self.put('good.md')
        report,code=run_batch(self.args(),self.engine)
        self.assertEqual(code,1);self.assertEqual(report['failed'],2);self.assertEqual(report['converted'],1)

    def test_report_failure_keeps_actual_results_and_does_not_hide_written_outputs(self):
        self.put();self.output.mkdir();(self.output/'.s2t-reports').write_text('user file')
        report,code=run_batch(self.args(),self.engine)
        self.assertEqual(code,2);self.assertEqual(report['status'],'report_error')
        self.assertEqual(report['converted'],1);self.assertNotIn('report_path',report)
        self.assertEqual((self.output/'doc_converted.txt').read_text(),'漢語\n')
        self.assertEqual((self.output/'.s2t-reports').read_text(),'user file')
        self.assertFalse((self.output/'.s2t.lock').exists())

    def test_size_limits_and_invalid_suffix(self):
        self.put(data='汉语')
        with patch('batch_files.MAX_FILE_BYTES',2):
            report,code=run_batch(self.args(),self.engine)
        self.assertEqual(code,1);self.assertEqual(report['failed'],1)
        with self.assertRaisesRegex(ConversionError,'invalid_suffix'):run_batch(self.args('--suffix','/escape'),self.engine)
        with patch('batch_files.MAX_BATCH_BYTES',2):
            report,code=run_batch(self.args('--dry-run'),self.engine)
        self.assertEqual(code,1);self.assertEqual(report['failed'],1)


class RealCliTests(unittest.TestCase):
    def setUp(self):
        try:
            engine=get_engine('s2t','opencc');engine.close()
        except EngineError:self.skipTest('Python OpenCC optional backend not installed')
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)

    def cli(self,*args,input=None):
        return subprocess.run([sys.executable,str(SCRIPTS/'chinese_converter_cli.py'),*args],input=input,capture_output=True,timeout=60)

    def test_actual_python_s2t_t2s_and_exact_stdin(self):
        for mode,source,expected in [('s2t',' \t汉语转换，头发与发展。😀\r\n\r\n',' \t漢語轉換，頭髮與發展。😀\r\n\r\n'),('t2s','漢語轉換\n','汉语转换\n')]:
            with self.subTest(mode=mode):
                result=self.cli('-m',mode,'--engine','opencc','--stdin',input=source.encode())
                self.assertEqual(result.returncode,0,result.stdout+result.stderr)
                self.assertEqual(result.stdout,expected.encode())

    def test_actual_batch_utf16_srt_output_and_report(self):
        source=self.root/'input';source.mkdir();output=self.root/'out'
        text='1\r\n00:00:00,000 --> 00:00:01,000\r\n汉语转换\r\n123\r\n'
        raw=codecs.BOM_UTF16_LE+text.encode('utf-16-le');(source/'a.srt').write_bytes(raw)
        result=self.cli('-m','s2t','--engine','opencc','-i',str(source),'-o',str(output),'--output-encoding','same')
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        report=json.loads(result.stdout);self.assertEqual(report['converted'],1)
        self.assertEqual((source/'a.srt').read_bytes(),raw)
        expected=codecs.BOM_UTF16_LE+text.replace('汉语转换','漢語轉換').encode('utf-16-le')
        self.assertEqual((output/'a_converted.srt').read_bytes(),expected)
        self.assertEqual(report['results'][0]['checks']['srt_cues'],1)

    def test_actual_large_document_not_limited_by_command_line_arguments(self):
        source=self.root/'large.txt';text=('汉语转换，头发与发展。\n'*30000);source.write_bytes(text.encode())
        result=self.cli('-m','s2t','--engine','opencc','-i',str(source),'-o',str(self.root/'out'))
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        output=(self.root/'out/large_converted.txt').read_text()
        self.assertEqual(output,'漢語轉換，頭髮與發展。\n'*30000)
        self.assertEqual(source.read_text(),text)

    def test_cli_help_and_empty_text(self):
        result=self.cli('--help');self.assertEqual(result.returncode,0);self.assertIn(b'--engine',result.stdout)
        result=self.cli('-m','s2t','--engine','opencc','--text','');self.assertEqual(result.returncode,0);self.assertEqual(result.stdout,b'')


if __name__ == '__main__':
    unittest.main()
