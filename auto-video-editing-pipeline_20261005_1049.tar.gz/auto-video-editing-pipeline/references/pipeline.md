# 批量 Pipeline Contract

## 阶段与幂等性

每个源视频拥有稳定的 `video-id`。状态文件只在输出目录内更新，并记录源文件
SHA-256；源文件发生变化时，旧产物不会被静默复用。

1. `ffprobe`：保存 streams、duration、resolution、fps、audio 和 source hash。
2. `stt`：共享一个 faster-whisper 模型实例处理当前待处理视频，分片结果落到稳定
   job 目录；成功的 chunk 在 `--resume` 时跳过。
3. `erratum`：把原始 SRT 复制到私有 correction input，使用成熟勘误技能；退出码 10
   时暂停，保留 pending request。
4. `s2t`：只对明确的字形目标执行，输出独立的 converted SRT。
5. `ass`：用成熟 srt-ass-studio 生成 ASS，不把字幕正文上传；翻译/AI 高亮只有显式
   参数才开启。
6. `render`：裁切、变速、缩放、音频处理后，最后追加 ASS filter。
7. `qa`：对 preview 和 final 分别做 decode、媒体规格、字幕范围、抽帧和哈希记录，
   并生成每个 EDL 边界 ±1.5s 视频/WAV 视听材料，标记人工复核 pending。
   EDL 在普通模式和 edit-mode 都记录源哈希、区间、留白、速度、引用/理由、STT 引擎与偏移。
   只有 `--stop-for-preview` 显式开启时，完整预览 QA 后等待 `--approve-preview` 再定稿。
   `--preview` 只生成完整预览，不暂停。
   可选 `--voiceover-script` 调用已安装 Edge 云端 TTS，逐句缓存/验证后按输出时间轴放置；
   发声区间压低原声，字幕仍为最后视觉操作，不调用 AI 翻译/语义或自动高亮功能。

可选扩展阶段：

8. `silence_motion`：以 `silencedetect` + `freezedetect` 生成证据报告；只标记
   40x 候选，不修改速度，也不替代人工审核。
9. `edit_mode`：仅在 `--edit-mode` 下运行五轴候选分析、片头高光前置和分区间变速；
   生成 `edit-plan.json` 与 `edit-review.md`，正文默认完整保留。
10. `merge`：默认按输入文件名顺序合并各视频的 `final.mp4`，输出批次根目录
   `final.mp4`；`--no-merge` 时跳过。
11. `release_package`：final QA 通过后读取真实字幕、时间轴和 creator profile，生成
   平台适配物料；只写入 `发布包/`，不执行上传或发布。

## 状态原则

- 只读取当前批次中的状态和指定源文件；不扫描用户家目录。
- 原始 SRT/TXT 永不被纠错结果覆盖；纠错结果永远是独立文件。
- 失败视频报告失败，其他视频继续；退出码 1 表示失败，10 等待会话 AI，11 等待审稿或预览审批。
- `awaiting_review` 与 `awaiting_preview` 单独计数；两种审批独立，绑定不变内容。
  `--approve-review` 不批准预览；`--approve-preview` 不批准同一次命令新渲染的预览。
- `awaiting_ai` 是可恢复状态，不是失败；恢复必须使用同一 `--resume-batch`。
- 通知失败不会删除或回滚视频产物。
- 静音/冻结报告失败不会阻塞普通字幕渲染，但必须写入 warning；不能把缺少证据的
  区间标记为已批准 40x。
- `--edit-mode` 的片头高光是正文片段的前置副本，不会静默删除正文；速度切换只落在
  SRT phrase 边界，并在最终时间轴重新计算字幕。
- 合并失败不会删除任何 per-video `final.mp4`；批次会记录 merge failure 并返回非零状态。
- `summary.failed` 只统计视频失败数；合并/发布包的失败计入 `stage_failures`。
- 恢复批次沿用已保存参数，显式 CLI 参数覆盖它们。审批、force-render、通知发送等
  单次动作不自动继承。改动 edit-mode/渲染配置会使新版本生成的单片缓存失效。

## 输出时间轴

裁切和变速时，字幕 cue 按下式重算：

```text
output_start = (max(cue_start, trim_start) - trim_start) / speed
output_end   = (min(cue_end, trim_end) - trim_start) / speed
```

由于默认 STT 是 phrase-level，自动/用户裁切都拒绝落在 cue 内部。普通模式也在
短语安全验证后向字幕间隙增加留白；上式的 trim 使用实际留白后的范围。
连续源区间接缝不重叠，默认每段约 30ms 音频淡化；首尾/所有接缝还需视听复核。
详见 [edit-evidence.md](edit-evidence.md)。

## Merge contract

默认开启：

```bash
python3 "$PIPE" <videos> --merge --resume
```

关闭：

```bash
python3 "$PIPE" <videos> --no-merge --resume
```

输入顺序按文件名排序并在 `state.json` 中固定；恢复批次不会重新扫描目录改变顺序。
采用忽略大小写的文件名字典序，同名再按完整路径排序（建议数字前缀补零）。
所有单片 QA 通过后再合并；尚在审核或失败时记录 blocked，不产出缺片的“最终版”。
相同规格优先 stream-copy，并核对实际帧率与时长；不兼容或时间轴漂移时重编码。
不同尺寸以排序首片为画布，等比缩放加黑边；帧率使用 `--fps`，音频为 AAC 48kHz
双声道，缺少音轨补静音。分段偏移基于视频帧时长，不以 AAC 尾部填充长度累加。
同时生成 `final.srt` 和带源引用的合并 `edl.json`。合并结果单独写入 `qa/merged/` 做 decode、规格、字幕范围、
总时长、拼接点前后抽帧和哈希 QA。只有候选通过 QA 后才替换批次 `final.mp4`。
成功合并按输入成片哈希和参数复用；仅生成发布包时不会重复编码。

## 审核和交付边界

显式 `--edit-mode` 允许自动选择片头并完整保留正文。需要预先检查时用
`--stop-for-review`：编辑模式在编码前生成 `edit-review.md`/`edit-plan.json` 并暂停；
普通字幕模式在 ASS/badge 后生成 `review.md` 并暂停。审核一次后 `--approve-review`
继续，读取用户修改的计划。详细 schema 见 [edit-mode.md](edit-mode.md)。
完整预览审批是另一道可选门：`--stop-for-preview` → `awaiting_preview` →
同批次 `--approve-preview`。技术 QA 与视听材料生成不代替人工观看/试听；详细见
[review.md](review.md)。未提供配音脚本不调用 TTS；提供脚本需知悉 Edge 云端文本传输，
详见 [voiceover.md](voiceover.md)。

完成 final QA 后，可按需创建：

```text
creator-profile.md       # 用户明确提供的账号/受众/口吻/禁区
发布包/<target>/<fingerprint>/  # request/response、平台文案、封面提示词、发布计划
```

这些文件属于当前批次，不得写入共享 skill 或自动发布。
