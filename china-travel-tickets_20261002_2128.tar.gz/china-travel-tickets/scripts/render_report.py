#!/usr/bin/env python3
"""Render a ticket-query JSON result as Markdown and email-friendly HTML."""
from __future__ import annotations

import argparse
import html
import json
import re
import math
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo


def unique_prices(row):
    seen = set()
    prices = []
    for item in row.get("prices", []):
        key = (item.get("seat"), item.get("price"), item.get("availability"))
        if key not in seen:
            seen.add(key)
            prices.append(item)
    return prices


def get_price(row, seat):
    return next((item for item in unique_prices(row) if item.get("seat") == seat), None)


def price_text(row, seat):
    item = get_price(row, seat)
    if not item:
        return "—"
    return f"¥{item['price']:g} / {item['availability']}"


def duration_minutes(value):
    hours, minutes = map(int, value.split(":"))
    return hours * 60 + minutes


def safe_slug(value):
    value = re.sub(r"[^A-Za-z0-9._-]+", "-", value).strip("-._")
    return value or "ticket-report"


def local_timestamp(value):
    try:
        stamp = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=ZoneInfo('Asia/Shanghai'))
        return stamp.astimezone(ZoneInfo('Asia/Shanghai')).strftime('%Y-%m-%d %H:%M:%S')
    except (TypeError, ValueError):
        return '未提供'


def rule_details(raw, journey, segments, keys):
    scopes = [('方案', raw), ('行程', journey)] + [(f'第{i}段', s) for i, s in enumerate(segments, 1)]
    return [f'{label}.{key}: {_value_text(mapping[key])}' for label, mapping in scopes
            for key in keys if mapping.get(key) not in (None, '', [], {})]


def connection_text(segments):
    details = []
    for i, (left, right) in enumerate(zip(segments, segments[1:]), 1):
        if left.get('arrStationCode') and right.get('depStationCode'):
            a, b = left['arrStationCode'], right['depStationCode']
        else:
            a, b = left.get('arrStationName'), right.get('depStationName')
        ta, tb = left.get('arrTerm'), right.get('depTerm')
        location = '机场信息未提供' if not a or not b else ('同机场' if a == b else '需更换机场')
        terminal = '航站楼未提供' if not ta or not tb else ('同航站楼' if ta == tb and a == b else '需更换航站楼/机场')
        details.append(f'换乘{i}: {a or "未提供"} {ta or "?"} → {b or "未提供"} {tb or "?"}；{location}，{terminal}')
    return '；'.join(details) if details else '无需换乘'


def _first_present(mapping, keys):
    for key in keys:
        value = mapping.get(key) if isinstance(mapping, dict) else None
        if value not in (None, "", [], {}):
            return value
    return None


def _value_text(value):
    if value in (None, "", [], {}):
        return None
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return str(value).strip()


def _segment_flight_details(segment):
    airline = _first_present(segment, (
        "marketingTransportName", "marketingAirlineName", "marketingCarrierName", "airlineName", "carrierName",
        "companyName", "airline", "carrier", "marketingAirline", "marketingCarrier",
        "airlineCode", "carrierCode", "marketingAirlineCode", "iataAirlineCode",
    ))
    flight_number = _first_present(segment, (
        "marketingTransportNo", "flightNumber", "flightNo", "flightCode", "transportNo",
        "airlineFlightNo",
    ))
    baggage = _first_present(segment, (
        "baggage", "baggageInfo", "luggage", "baggageAllowance", "checkedBaggage",
        "freeBaggage", "baggageRule",
    ))
    refund_change = _first_present(segment, (
        "refundChange", "refundAndChange", "changeRefund", "refundRule", "changeRule",
        "rescheduleRule", "ticketRule", "fareRule",
    ))
    taxes = _first_present(segment, (
        "tax", "taxes", "taxFee", "taxAmount", "airportTax", "fuelSurcharge", "totalTax", "totalTaxes",
    ))
    return {
        "airline": _value_text(airline),
        "flight_number": _value_text(flight_number),
        "baggage": _value_text(baggage),
        "refund_change": _value_text(refund_change),
        "taxes": _value_text(taxes),
    }


def _unique_values(values):
    return list(dict.fromkeys(value for value in values if value))


def _flight_record(raw):
    journey = (raw.get("journeys") or [{}])[0]
    segments = journey.get("segments") or []
    if not segments:
        return None
    first, last = segments[0], segments[-1]
    segment_details = [_segment_flight_details(segment) for segment in segments]
    price_raw = raw.get("ticketPrice") if raw.get("ticketPrice") is not None else raw.get("adultPrice")
    price_text_value = str(price_raw).strip() if price_raw not in (None, "") else None
    try:
        price = float(str(price_raw).replace("¥", "").replace("￥", "").replace(",", "").strip())
    except (TypeError, ValueError):
        price = None
    if price is not None and (not math.isfinite(price) or price < 0):
        price = None
    if price is None:
        price_text_value = None
    try:
        duration = int(raw.get("totalDuration") or journey.get("totalDuration"))
    except (TypeError, ValueError):
        duration = None
    transfer_raw = raw.get("transferDuration") or journey.get("transferDuration")
    try:
        transfer = int(transfer_raw) if transfer_raw is not None else None
    except (TypeError, ValueError):
        transfer = None
    if transfer is None and len(segments) > 1:
        gaps = []
        for previous, following in zip(segments, segments[1:]):
            try:
                arrived = datetime.fromisoformat(previous["arrDateTime"])
                departed = datetime.fromisoformat(following["depDateTime"])
                gaps.append(max(0, int((departed - arrived).total_seconds() // 60)))
            except (KeyError, TypeError, ValueError):
                pass
        transfer = sum(gaps) if len(gaps) == len(segments) - 1 else None
    stops = max(0, len(segments) - 1)
    if stops == 0:
        transfer = 0
    record_airline = _value_text(_first_present(raw, (
        "marketingTransportName", "marketingAirlineName", "marketingCarrierName", "airlineName", "carrierName",
        "companyName", "airline", "carrier", "marketingAirline", "marketingCarrier",
        "airlineCode", "carrierCode", "marketingAirlineCode", "iataAirlineCode",
    )))
    record_flight_number = _value_text(_first_present(raw, (
        "marketingTransportNo", "flightNumber", "flightNo", "flightCode", "transportNo",
        "airlineFlightNo",
    )))
    return {
        "segments": segments,
        "segment_details": segment_details,
        "airlines": _unique_values(([record_airline] if record_airline else []) + [item["airline"] for item in segment_details]),
        "from": first.get("depCityName") or first.get("depStationName") or "出发地",
        "to": last.get("arrCityName") or last.get("arrStationName") or "目的地",
        "departure": first.get("depDateTime") or "",
        "arrival": last.get("arrDateTime") or "",
        "duration": duration,
        "transfer": transfer,
        "stops": stops,
        "direct": stops == 0 and not any(s.get('stopInfos') for s in segments),
        "connections_text": connection_text(segments),
        "protection": rule_details(raw, journey, segments, ('transferGuarantee', 'connectionProtection', 'isProtected', 'throughTicket', 'baggageThrough', 'selfTransfer')),
        "price": price,
        "price_text": price_text_value,
        "flight_numbers": [item["flight_number"] or record_flight_number for item in segment_details],
        "baggage": rule_details(raw, journey, segments, ('baggage', 'baggageInfo', 'luggage', 'baggageAllowance', 'checkedBaggage', 'freeBaggage', 'baggageRule')),
        "refund_change": rule_details(raw, journey, segments, ('refundChange', 'refundAndChange', 'changeRefund', 'refundRule', 'changeRule', 'rescheduleRule', 'ticketRule', 'fareRule')),
        "taxes": rule_details(raw, journey, segments, ('tax', 'taxes', 'taxFee', 'taxAmount', 'airportTax', 'fuelSurcharge', 'totalTax', 'totalTaxes')),
        "airports": [
            f"{segment.get('depStationName', '—')} → {segment.get('arrStationName', '—')}"
            for segment in segments
        ],
    }


def _details_text(item, key):
    values = item.get(key, [])
    if not isinstance(values, list):
        values = [values]
    values = _unique_values(values)
    return "；".join(values) if values else "未提供"


def _duration_text(minutes):
    if minutes is None:
        return "—"
    return f"{minutes // 60}小时{minutes % 60:02d}分"


def _flight_time(value):
    return value.replace("T", " ")[:16] if value else "—"


def render_flight(input_path: Path, output_dir: Path, slug: str | None, data: dict):
    flights = [item for raw in data.get("results", []) if (item := _flight_record(raw))]
    if not flights:
        raise SystemExit("航班查询结果为空，无法生成报告")
    first = flights[0]
    date = first["departure"][:10] or "未注明日期"
    origin, destination = first["from"], first["to"]
    query_time = local_timestamp(data.get("timestamp"))
    slug = safe_slug(slug or f"{origin}-{destination}-{date}-flight")
    md_path = output_dir / f"{slug}.md"
    html_path = output_dir / f"{slug}.html"
    cheapest = min((item for item in flights if item["price"] is not None), key=lambda item: item["price"], default=None)
    fastest = min((item for item in flights if item["duration"] is not None), key=lambda item: item["duration"], default=None)
    earliest = min(flights, key=lambda item: item["arrival"] or "9999")

    def flight_line(item):
        return ", ".join(number or "未提供" for number in item["flight_numbers"])

    def airline_line(item):
        return ", ".join(item["airlines"]) if item["airlines"] else "未提供"

    def price_text(item):
        if item["price_text"]:
            return item["price_text"] if item["price_text"].startswith("¥") else f"¥{item['price_text']}"
        return "未提供"

    direct_count = sum(1 for item in flights if item["direct"])
    transfer_count = sum(1 for item in flights if item['stops'] > 0)
    stopover_count = len(flights) - direct_count - transfer_count
    route_summary = f"直飞 {direct_count} 条 / 中转 {transfer_count} 条" + (f" / 经停 {stopover_count} 条" if stopover_count else '')
    preference = ((data.get("query") or {}).get("filters") or {}).get("preferredAirlines") or []
    preference_note = "；航空公司偏好：" + ", ".join(preference) if preference else ""
    lines = [
        f"# {origin} → {destination} 机票出行报告", "",
        f"> 查询日期：**{date}**  · 数据源：{data.get('source', '航班查询')}  · 共 {len(flights)} 条方案{preference_note}", "",
        "## 结论速览", "",
        '所有最低价/最快建议仅在本次上游返回并通过筛选的结果内比较，不代表全市场。',
        f'筛选条件：`{json.dumps((data.get("query") or {}).get("filters", {}), ensure_ascii=False)}`',
        f"- **查询结果**：{len(flights)} 条（{route_summary}）。",
        f"- **最早抵达**：{flight_line(earliest)}，{_flight_time(earliest['departure'])} → {_flight_time(earliest['arrival'])}，票价 {price_text(earliest)}。",
    ]
    if fastest:
        lines.append(f"- **总耗时最短**：{flight_line(fastest)}，总耗时 {_duration_text(fastest['duration'])}，票价 {price_text(fastest)}。")
    if cheapest:
        lines.append(f"- **价格最低**：{flight_line(cheapest)}，票价 {price_text(cheapest)}，总耗时 {_duration_text(cheapest['duration'])}。")
    lines += ["", "## 推荐选择", "", "| 适合场景 | 航空公司 | 航班 | 时间 | 中转 | 总耗时 | 价格 |", "|---|---|---|---|---:|---:|---:|"]
    for label, item in [("最早抵达", earliest), ("总耗时最短", fastest), ("价格优先", cheapest)]:
        if item:
            transfer = "直飞" if item["direct"] else " → ".join(item["airports"])
            lines.append(f"| {label} | {airline_line(item)} | {flight_line(item)} | {_flight_time(item['departure'])} → {_flight_time(item['arrival'])} | {transfer} | {_duration_text(item['duration'])} | {price_text(item)} |")
    lines += ["", "## 全部查询结果", "", "| # | 航空公司 | 航班 | 出发 → 到达 | 航线 | 停留/中转 | 总耗时 | 中转等待 | 行李 | 退改 | 税费 | 价格 |", "|---:|---|---|---|---|---:|---:|---:|---|---|---|---:|"]
    for index, item in enumerate(flights, 1):
        route = "直飞" if item["direct"] else " / ".join(item["airports"])
        lines.append(f"| {index} | {airline_line(item)} | {flight_line(item)} | {_flight_time(item['departure'])} → {_flight_time(item['arrival'])} | {route} | {item['stops']} 次 | {_duration_text(item['duration'])} | {_duration_text(item['transfer']) if not item['direct'] else '—'} | {_details_text(item, 'baggage')} | {_details_text(item, 'refund_change')} | {_details_text(item, 'taxes')} | {price_text(item)} |")
    lines += ['', '## 换乘与联程保障', '']
    for i, item in enumerate(flights, 1):
        lines.append(f'- 方案{i}：{item["connections_text"]}。联程/行李直挂字段：{_details_text(item, "protection")}。')
    lines += ['', '换乘时间筛选仅是用户指定阈值，不代表机场官方最短转机时间（MCT）或可保证衔接。上游未确认的联程、行李直挂、退改或税费包含关系不得推断。']
    availability_note = "本次结果含直飞航班。" if direct_count else "本次结果未返回直飞航班。"
    lines += ["", "## 说明", "", f"- 查询时间：`{query_time}`（中国标准时间）", "- 结果中的价格、航班计划、机场和中转信息会动态变化；行李、退改和税费仅在上游提供时展示，未提供字段不会推断。", f"- {availability_note}购买前请在官方航空公司或正规平台再次核对。", "- 本报告仅提供查询信息，不执行登录、下单或支付。"]
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    def esc(value):
        return html.escape(str(value), quote=True)

    cards = []
    for title, item, accent in [("最早抵达", earliest, "#0f766e"), ("总耗时最短", fastest, "#2563eb"), ("价格最低", cheapest, "#b45309")]:
        if item:
            cards.append(f'<div class="card" style="border-top-color:{accent}"><div class="label">{title}</div><div class="big">{esc(flight_line(item))}</div><div>{esc(airline_line(item))}</div><div>{esc(_flight_time(item["departure"]))} → {esc(_flight_time(item["arrival"]))}</div><div class="small">{esc(_duration_text(item["duration"]))} · <strong>{esc(price_text(item))}</strong></div></div>')
    rows = []
    for index, item in enumerate(flights, 1):
        route = "直飞" if item["direct"] else " / ".join(item["airports"])
        transfer = "—" if item["direct"] else _duration_text(item["transfer"])
        rows.append(f'<tr><td>{index}</td><td>{esc(airline_line(item))}</td><td><strong>{esc(flight_line(item))}</strong></td><td>{esc(_flight_time(item["departure"]))}<br>→ {esc(_flight_time(item["arrival"]))}</td><td>{esc(route)}</td><td>{item["stops"]} 次</td><td>{esc(_duration_text(item["duration"]))}</td><td>{esc(transfer)}</td><td>{esc(_details_text(item, "baggage"))}</td><td>{esc(_details_text(item, "refund_change"))}</td><td>{esc(_details_text(item, "taxes"))}</td><td class="fare">{esc(price_text(item))}</td></tr>')
    connection_html = '<h2>换乘与联程保障</h2>' + ''.join(f'<p>方案{i}：{esc(item["connections_text"])}。保障字段：{esc(_details_text(item, "protection"))}</p>' for i, item in enumerate(flights, 1)) + '<p>等待下限不是官方 MCT；联程、行李直挂与税费是否包含均以购票页为准。</p>'
    route_note = "航班结果" if direct_count else "未返回直飞结果"
    html_doc = f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(origin)} → {esc(destination)} 机票报告</title><style>body{{margin:0;background:#f3f6fb;color:#172033;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",Arial,sans-serif;line-height:1.6}}.wrap{{max-width:920px;margin:0 auto;background:#fff}}.hero{{padding:36px 42px;background:linear-gradient(135deg,#172554,#2563eb);color:#fff}}.eyebrow{{font-size:12px;letter-spacing:2px;opacity:.78}}h1{{margin:10px 0 6px;font-size:30px}}.subtitle{{opacity:.88}}.content{{padding:28px 42px 40px}}.meta{{padding:12px 14px;background:#eff6ff;border-left:4px solid #2563eb;border-radius:6px;font-size:13px;color:#425466}}.cards{{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0 24px}}.card{{flex:1 1 210px;min-width:190px;border:1px solid #e5eaf1;border-top:4px solid #2563eb;border-radius:10px;padding:14px 16px;background:#fbfcfe}}.label,.small{{font-size:12px;color:#64748b}}.big{{font-size:17px;font-weight:700;color:#172554;margin:4px 0}}h2{{margin:28px 0 14px;font-size:20px;color:#172554}}table{{width:100%;border-collapse:collapse;font-size:12px}}th{{background:#172554;color:#fff;text-align:left;padding:10px 8px}}td{{padding:9px 8px;border-bottom:1px solid #e8edf3;vertical-align:middle}}tr:nth-child(even){{background:#f8fafc}}td:first-child{{color:#94a3b8;text-align:center}}.fare{{font-weight:700;color:#172554}}.note{{font-size:12px;color:#64748b;margin-top:22px;padding-top:15px;border-top:1px solid #e8edf3}}.footer{{padding:18px 42px;background:#f8fafc;color:#94a3b8;font-size:11px}}@media(max-width:680px){{.hero,.content,.footer{{padding-left:20px;padding-right:20px}}h1{{font-size:25px}}th,td{{padding:7px 5px}}}}</style></head><body><div class="wrap"><div class="hero"><div class="eyebrow">FLIGHT SEARCH · LIVE QUERY</div><h1>{esc(origin)} → {esc(destination)}</h1><div class="subtitle">{esc(date)} · {len(flights)} 条{route_note}</div></div><div class="content"><div class="meta"><strong>查询时间：</strong>{esc(query_time)}（中国标准时间）<br><strong>数据源：</strong>{esc(data.get('source', '航班查询'))}{'<br><strong>航空公司偏好：</strong>' + esc(', '.join(preference)) if preference else ''}</div><div class="cards">{"".join(cards)}</div><h2>全部查询结果</h2><table><thead><tr><th>#</th><th>航空公司</th><th>航班</th><th>起降时间</th><th>航线</th><th>停留/中转</th><th>总耗时</th><th>中转等待</th><th>行李</th><th>退改</th><th>税费</th><th>票价</th></tr></thead><tbody>{"".join(rows)}</tbody></table>{connection_html}<div class="note">价格、税费、行李和退改规则请以购票页面为准；未提供字段未作推断。{route_note}；报告不执行登录、下单或支付。</div></div><div class="footer">Omnirush 中国票务查询技能 · 仅供出行决策参考</div></div></body></html>'''
    html_path.write_text(html_doc, encoding="utf-8")
    return md_path, html_path


def render_train_transfers(input_path: Path, output_dir: Path, slug: str | None, data: dict):
    results = [item for item in data.get("results", []) if isinstance(item, dict)]
    direct = [item for item in data.get("direct_results", []) if isinstance(item, dict)]
    first = (results or direct or [{}])[0]
    if not results:
        date = first.get("date") or "未注明日期"
        origin = first.get("from", "出发地")
        destination = first.get("to", "目的地")
        query_time = str(data.get("queried_at", "")).replace("T", " ")[:19]
        slug = safe_slug(slug or f"{origin}-{destination}-{date}-train-transfer")
        md_path = output_dir / f"{slug}.md"
        html_path = output_dir / f"{slug}.html"
        md_path.write_text("\n".join([
            f"# {origin} → {destination} 高铁中转换乘报告", "",
            f"> 查询日期：**{date}** · 数据源：12306", "",
            "## 查询结论", "",
            "本次没有找到满足换乘等待、总历时和车站约束的中转方案。",
            f"- 查询时间：`{query_time}`（中国标准时间）",
            "- 可尝试指定其他 `--transfer-stations`、放宽等待限制，或直接查询官方 12306。",
            "- 本报告仅提供查询信息，不执行登录、购票或支付。",
            "",
        ]) + "\n", encoding="utf-8")
        html_path.write_text(f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>{html.escape(origin)} → {html.escape(destination)} 中转报告</title></head><body><h1>{html.escape(origin)} → {html.escape(destination)} 高铁中转换乘报告</h1><p>本次没有找到满足约束的中转方案。</p><p>查询时间：{html.escape(query_time)}（中国标准时间）</p><p>可指定其他中转站或放宽换乘限制后重试。</p></body></html>''', encoding="utf-8")
        return md_path, html_path
    results = [dict(row, departure=row.get('departure_datetime') or row.get('departure'), arrival=row.get('arrival_datetime') or row.get('arrival')) for row in results]
    first = results[0]
    date = first.get("date") or "未注明日期"
    origin = first.get("from", "出发地")
    destination = first.get("to", "目的地")
    query_time = str(data.get("queried_at", "")).replace("T", " ")[:19]
    slug = safe_slug(slug or f"{origin}-{destination}-{date}-train-transfer")
    md_path = output_dir / f"{slug}.md"
    html_path = output_dir / f"{slug}.html"

    def wait_text(row):
        value = row.get("transfer_wait")
        return str(value) if value else "—"

    def fare(row):
        return price_text(row, "二等座")

    fastest = min(results, key=lambda row: row.get("total_duration", 10**9))
    cheapest = min(
        (row for row in results if get_price(row, "二等座") and get_price(row, "二等座").get('availability') == '分段均有票'),
        key=lambda row: get_price(row, "二等座")["price"],
        default=None,
    )
    direct_count = len(data.get("direct_results") or [])
    lines = [
        f"# {origin} → {destination} 高铁中转换乘报告", "",
        f"> 查询日期：**{date}** · 数据源：12306 · 共 {len(results)} 条中转方案", "",
        "## 结论速览", "",
        f"- **中转方案**：{len(results)} 条；此前直达查询返回 {direct_count} 条。",
        f"- **总历时最短**：{fastest.get('train', '未提供')}，经 {fastest.get('transfer_station', '未提供')}，总历时 {fastest.get('duration', '未提供')}，换乘等待 {wait_text(fastest)}。",
    ]
    if cheapest:
        lines.append(f"- **二等座分段合计最低**：{cheapest.get('train', '未提供')}，票价 {fare(cheapest)}。")
    lines += [
        "", "## 推荐选择", "",
        "| 适合场景 | 车次 | 中转站 | 时间 | 换乘等待 | 总历时 | 二等座分段合计 |",
        "|---|---|---|---|---:|---:|---:|",
    ]
    for label, row in (("总历时最短", fastest), ("价格优先", cheapest)):
        if row:
            lines.append(f"| {label} | {row.get('train', '—')} | {row.get('transfer_station', '—')} | {row.get('departure', '—')} → {row.get('arrival', '—')} | {wait_text(row)} | {row.get('duration', '—')} | {fare(row)} |")
    lines += [
        "", "## 全部中转方案", "",
        "| # | 车次 | 出发 → 到达 | 中转站 | 换乘等待 | 总历时 | 二等座分段合计 |",
        "|---:|---|---|---|---:|---:|---:|",
    ]
    for index, row in enumerate(results, 1):
        lines.append(f"| {index} | {row.get('train', '—')} | {row.get('departure', '—')} → {row.get('arrival', '—')} | {row.get('transfer_station', '—')} | {wait_text(row)} | {row.get('duration', '—')} | {fare(row)} |")
    leg_details = []
    for i, row in enumerate(results, 1):
        for j, leg in enumerate(row.get('legs', []), 1):
            seats = '；'.join(f'{p["seat"]} ¥{p["price"]:g}/{p["availability"]}' for p in unique_prices(leg)) or '票价/余票未提供'
            leg_details.append(f'方案{i} 第{j}段：{leg.get("train")} {leg.get("from")} → {leg.get("to")}，{leg.get("date")} {leg.get("departure")}，历时 {leg.get("duration")}；{seats}')
    lines += ['', '## 分段车次与余票', ''] + ['- ' + detail for detail in leg_details]
    constraints = data.get("transfer_constraints") or {}
    lines += [
        "", "## 说明", "",
        f"- 查询时间：`{query_time}`（中国标准时间）",
        f"- 换乘约束：等待 {constraints.get('min_wait_minutes', '—')}–{constraints.get('max_wait_minutes', '—')} 分钟；总历时最多 {constraints.get('max_total_minutes', '—')} 分钟。",
        "- 票价为各分段同一座席类型的查询价格合计，不代表一定存在可一次购买的联程票；两段车票需分别核对和购买。",
        "- 换乘站、车次、票价和余票会动态变化；购票前请在 12306 再次核对车站、换乘距离、余票及退改规则。",
        "- 本报告仅提供查询信息，不执行登录、购票或支付。",
    ]
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    def esc(value):
        return html.escape(str(value), quote=True)

    cards = []
    for title, row, accent in (("总历时最短", fastest, "#2563eb"), ("二等座低价", cheapest, "#b45309")):
        if row:
            cards.append(f'<div class="card" style="border-top-color:{accent}"><div class="label">{title}</div><div class="big">{esc(row.get("train", "—"))}</div><div>{esc(row.get("transfer_station", "—"))} · {esc(row.get("duration", "—"))}</div><div class="small">等待 {esc(wait_text(row))} · <strong>{esc(fare(row))}</strong></div></div>')
    rows = []
    for index, row in enumerate(results, 1):
        rows.append(f'<tr><td>{index}</td><td><strong>{esc(row.get("train", "—"))}</strong></td><td>{esc(row.get("departure", "—"))}<br>→ {esc(row.get("arrival", "—"))}</td><td>{esc(row.get("transfer_station", "—"))}</td><td>{esc(wait_text(row))}</td><td>{esc(row.get("duration", "—"))}</td><td class="fare">{esc(fare(row))}</td></tr>')
    html_doc = f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(origin)} → {esc(destination)} 高铁中转换乘报告</title><style>body{{margin:0;background:#f3f6fb;color:#172033;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",Arial,sans-serif;line-height:1.6}}.wrap{{max-width:920px;margin:0 auto;background:#fff}}.hero{{padding:36px 42px;background:linear-gradient(135deg,#0f3d56,#2563eb);color:#fff}}.eyebrow{{font-size:12px;letter-spacing:2px;opacity:.78}}h1{{margin:10px 0 6px;font-size:30px}}.subtitle{{opacity:.88}}.content{{padding:28px 42px 40px}}.meta{{padding:12px 14px;background:#eff6ff;border-left:4px solid #2563eb;border-radius:6px;font-size:13px;color:#425466}}.cards{{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0 24px}}.card{{flex:1 1 210px;min-width:190px;border:1px solid #e5eaf1;border-top:4px solid #2563eb;border-radius:10px;padding:14px 16px;background:#fbfcfe}}.label,.small{{font-size:12px;color:#64748b}}.big{{font-size:17px;font-weight:700;color:#172554;margin:4px 0}}h2{{margin:28px 0 14px;font-size:20px;color:#172554}}table{{width:100%;border-collapse:collapse;font-size:12px}}th{{background:#172554;color:#fff;text-align:left;padding:10px 8px}}td{{padding:9px 8px;border-bottom:1px solid #e8edf3;vertical-align:middle}}tr:nth-child(even){{background:#f8fafc}}td:first-child{{color:#94a3b8;text-align:center}}.fare{{font-weight:700;color:#172554}}.note{{font-size:12px;color:#64748b;margin-top:22px;padding-top:15px;border-top:1px solid #e8edf3}}.footer{{padding:18px 42px;background:#f8fafc;color:#94a3b8;font-size:11px}}@media(max-width:680px){{.hero,.content,.footer{{padding-left:20px;padding-right:20px}}h1{{font-size:25px}}th,td{{padding:7px 5px}}}}</style></head><body><div class="wrap"><div class="hero"><div class="eyebrow">12306 · TRANSFER QUERY REPORT</div><h1>{esc(origin)} → {esc(destination)}</h1><div class="subtitle">{esc(date)} · {len(results)} 条中转换乘方案</div></div><div class="content"><div class="meta"><strong>查询时间：</strong>{esc(query_time)}（中国标准时间）<br><strong>数据源：</strong>12306 公开查询接口</div><div class="cards">{"".join(cards)}</div><h2>全部中转方案</h2><table><thead><tr><th>#</th><th>车次</th><th>出发/到达时间</th><th>中转站</th><th>等待</th><th>总历时</th><th>二等座合计</th></tr></thead><tbody>{"".join(rows)}</tbody></table><h2>分段车次与余票</h2>{''.join('<p>' + esc(detail) + '</p>' for detail in leg_details)}<div class="note">票价为分段查询价格合计，不代表一定存在可一次购买的联程票。购票前请在 12306 核对车站、换乘距离、余票、票价及退改规则。</div></div><div class="footer">Omnirush 中国票务查询技能 · 仅供出行决策参考</div></div></body></html>'''
    html_path.write_text(html_doc, encoding="utf-8")
    return md_path, html_path


def render(input_path: Path, output_dir: Path, slug: str | None):
    output_dir.mkdir(parents=True, exist_ok=True)
    data = json.loads(input_path.read_text(encoding="utf-8"))
    results = data.get("results", [])
    if not results:
        query = data.get('query') or {}
        origin, destination, date = query.get('from', '出发地'), query.get('to', '目的地'), query.get('date', '未提供')
        name = safe_slug(slug or f'ticket-empty-{date}')
        md_path, html_path = output_dir / f'{name}.md', output_dir / f'{name}.html'
        message = '没有找到满足本次查询/筛选约束的结果；不代表所有渠道均无票。'
        text = f'# {origin} → {destination} 查询报告\n\n日期：{date}\n\n{message}\n\n来源：{data.get("source", "未提供")}\n\n查询时间：{local_timestamp(data.get("timestamp") or data.get("queried_at"))}（中国标准时间）\n\n上游查询范围可能受试用额度限制；查询失败不会生成无票结论。\n'
        md_path.write_text(text, encoding='utf-8')
        html_path.write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><body><pre>' + html.escape(text) + '</pre></body></html>', encoding='utf-8')
        return md_path, html_path
    if data.get("mode") == "transfers":
        return render_train_transfers(input_path, output_dir, slug, data)
    if results and isinstance(results[0], dict) and results[0].get("journeys"):
        return render_flight(input_path, output_dir, slug, data)
    if not results:
        raise SystemExit("查询结果为空，无法生成报告")

    first = results[0]
    date = first.get("date") or "未注明日期"
    origin = first.get("from", "出发地")
    destinations = sorted({row.get("to", "目的地") for row in results})
    destination = " / ".join(destinations)
    queried_at = data.get("queried_at", "")
    query_time = queried_at.replace("T", " ")[:19]
    slug = safe_slug(slug or f"{origin}-{destination}-{date}")
    md_path = output_dir / f"{slug}.md"
    html_path = output_dir / f"{slug}.html"

    fastest = min(results, key=lambda row: duration_minutes(row["duration"]))
    earliest = min(results, key=lambda row: row["arrival"])
    available_second_class = [
        (get_price(row, "二等座")["price"], row)
        for row in results
        if get_price(row, "二等座")
        and get_price(row, "二等座").get("availability") not in {"无票", "候补"}
    ]
    cheap = min(available_second_class, default=(None, None), key=lambda pair: pair[0])

    def recommendation(label, row):
        if not row:
            return
        lines.append(
            f"| {label} | {row['train']} | {row['to']} | "
            f"{row['departure']} → {row['arrival']} | {row['duration']} | "
            f"{price_text(row, '二等座')} | {price_text(row, '一等座')} |"
        )

    lines = [
        f"# {origin} → {destination} 高铁出行报告",
        "",
        f"> 查询日期：**{date}**  · 查询范围：直达高铁/城际（G/C）  · 数据源：12306",
        "",
        "## 结论速览",
        "",
        f"- **直达方案**：{len(results)} 条（包含不同到站车站）",
        f"- **最早抵达**：{earliest['train']}，{earliest['departure']} → {earliest['arrival']}，抵达{earliest['to']}，历时 {earliest['duration']}，二等座 {price_text(earliest, '二等座')}。",
        f"- **历时最短**：{fastest['train']}，{fastest['departure']} → {fastest['arrival']}，历时 {fastest['duration']}，二等座 {price_text(fastest, '二等座')}。",
    ]
    if cheap[1]:
        lines.append(f"- **当前二等座最低价**：{cheap[1]['train']} 到 {cheap[1]['to']}，二等座 {price_text(cheap[1], '二等座')}。")
    lines += ["", "## 推荐选择", "", "| 适合场景 | 车次 | 到达站 | 时间 | 历时 | 二等座 | 一等座 |", "|---|---:|---|---|---:|---:|---:|"]
    recommendation("尽早抵达", earliest)
    recommendation("历时最短", fastest)
    recommendation("价格优先", cheap[1])
    lines += ["", "## 全部直达车次", "", "| # | 车次 | 到达站 | 出发 | 到达 | 历时 | 二等座 | 一等座 | 商务座 |", "|---:|---:|---|---:|---:|---:|---:|---:|---:|"]
    for index, row in enumerate(results, 1):
        lines.append(
            f"| {index} | {row['train']} | {row['to']} | {row['departure']} | {row['arrival']} | {row['duration']} | "
            f"{price_text(row, '二等座')} | {price_text(row, '一等座')} | {price_text(row, '商务座')} |"
        )
    lines += [
        "",
        "## 说明",
        "",
        f"- 查询时间：`{query_time}`（中国标准时间）",
        "- “有票”“余 N 张”“无票”“候补”按查询时返回状态整理；票价和余票会动态变化。",
        "- 购买前请在官方平台再次核对出发日期、车站、余票、票价和退改规则。",
        "- 本报告仅提供查询信息，不执行登录、购票或支付。",
    ]
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    def esc(value):
        return html.escape(str(value), quote=True)

    def html_price(row, seat):
        item = get_price(row, seat)
        if not item:
            return '<span class="muted">—</span>'
        availability = item["availability"]
        cls = "available" if availability in {"有票", "充足"} or availability.startswith("余") else ("wait" if availability == "候补" else "sold")
        return f'<span class="fare">¥{item["price"]:g}</span><br><span class="{cls}">{esc(availability)}</span>'

    cards = []
    for title, row, accent in [("最早抵达", earliest, "#0f766e"), ("历时最短", fastest, "#2563eb"), ("二等座低价", cheap[1], "#b45309")]:
        if row:
            cards.append(
                f'<div class="card" style="border-top-color:{accent}"><div class="card-label">{title}</div>'
                f'<div class="card-train">{esc(row["train"])}</div><div class="card-main">{esc(row["departure"])} → {esc(row["arrival"])}</div>'
                f'<div class="card-sub">{esc(row["to"])} · {esc(row["duration"])} · 二等座 {html_price(row, "二等座")}</div></div>'
            )

    table_rows = []
    for index, row in enumerate(results, 1):
        table_rows.append(
            f'<tr><td>{index}</td><td><strong>{esc(row["train"])}</strong></td><td>{esc(row["to"])}</td>'
            f'<td>{esc(row["departure"])}</td><td>{esc(row["arrival"])}</td><td>{esc(row["duration"])}</td>'
            f'<td>{html_price(row, "二等座")}</td><td>{html_price(row, "一等座")}</td><td>{html_price(row, "商务座")}</td></tr>'
        )

    html_doc = f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(origin)} → {esc(destination)} 出行报告</title><style>
body{{margin:0;background:#f3f6fb;color:#172033;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",Arial,sans-serif;line-height:1.6}}.wrap{{max-width:920px;margin:0 auto;background:#fff}}.hero{{padding:36px 42px;background:linear-gradient(135deg,#0f3d56,#0f766e);color:#fff}}.eyebrow{{font-size:12px;letter-spacing:2px;text-transform:uppercase;opacity:.78}}h1{{margin:10px 0 6px;font-size:30px;line-height:1.2}}.subtitle{{font-size:15px;opacity:.88}}.content{{padding:28px 42px 40px}}.meta{{padding:12px 14px;background:#f0f7f8;border-left:4px solid #0f766e;border-radius:6px;font-size:13px;color:#425466}}h2{{margin:28px 0 14px;font-size:20px;color:#123b52}}.cards{{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0 24px}}.card{{flex:1 1 210px;min-width:190px;border:1px solid #e5eaf1;border-top:4px solid #2563eb;border-radius:10px;padding:14px 16px;background:#fbfcfe}}.card-label{{font-size:12px;color:#64748b}}.card-train{{font-size:22px;font-weight:700;color:#0f3d56}}.card-main{{font-size:16px;font-weight:600;margin-top:2px}}.card-sub{{font-size:12px;color:#64748b;margin-top:5px}}table{{width:100%;border-collapse:collapse;font-size:12px;margin-top:10px}}th{{background:#123b52;color:#fff;text-align:left;padding:10px 8px;white-space:nowrap}}td{{padding:9px 8px;border-bottom:1px solid #e8edf3;vertical-align:middle}}tr:nth-child(even){{background:#f8fafc}}td:first-child{{color:#94a3b8;text-align:center}}.fare{{font-weight:700;color:#172033}}.available{{color:#0f766e;font-size:11px}}.wait{{color:#b45309;font-size:11px}}.sold,.muted{{color:#94a3b8;font-size:11px}}.note{{font-size:12px;color:#64748b;margin-top:22px;padding-top:15px;border-top:1px solid #e8edf3}}.footer{{padding:18px 42px;background:#f8fafc;color:#94a3b8;font-size:11px}}@media(max-width:680px){{.hero,.content,.footer{{padding-left:20px;padding-right:20px}}h1{{font-size:25px}}table{{font-size:11px}}th,td{{padding:7px 5px}}}}
</style></head><body><div class="wrap"><div class="hero"><div class="eyebrow">12306 · LIVE QUERY REPORT</div><h1>{esc(origin)} → {esc(destination)}</h1><div class="subtitle">{esc(date)} · 直达高铁/城际 · 共 {len(results)} 条方案</div></div><div class="content"><div class="meta"><strong>查询时间：</strong>{esc(query_time)}（中国标准时间）<br><strong>数据源：</strong>12306 公开查询接口</div><div class="cards">{"".join(cards)}</div><h2>全部直达车次</h2><table><thead><tr><th>#</th><th>车次</th><th>到达站</th><th>出发</th><th>到达</th><th>历时</th><th>二等座</th><th>一等座</th><th>商务座</th></tr></thead><tbody>{"".join(table_rows)}</tbody></table><div class="note">“有票”“余 N 张”“无票”“候补”按查询时返回状态整理。票价和余票会动态变化；购票前请在官方 12306 页面再次核对日期、车站、余票、票价及退改规则。本报告不执行登录、购票或支付。</div></div><div class="footer">Omnirush 中国票务查询技能 · 仅供出行决策参考</div></div></body></html>'''
    html_path.write_text(html_doc, encoding="utf-8")
    return md_path, html_path


def main():
    parser = argparse.ArgumentParser(description="把票务 JSON 查询结果渲染为 Markdown 和 HTML 报告")
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path.home() / "Downloads")
    parser.add_argument("--slug")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    md_path, html_path = render(args.input, args.output_dir, args.slug)
    print(json.dumps({"markdown": str(md_path), "html": str(html_path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
