#!/usr/bin/env python3
"""批量获取 YouTube 字幕并生成 AI 摘要报告（多 AI Provider 自动回退）。"""
from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
import re
import sys
import ssl
import urllib.error
import urllib.request
from datetime import date
from pathlib import Path
from typing import Any

try:
    import yt_dlp
except ImportError:
    print("错误：请先安装 yt-dlp：python3 -m pip install -U yt-dlp", file=sys.stderr)
    raise SystemExit(2)

DEFAULT_OUTPUT = Path.home() / "Downloads" / "youtube_video_sumup"
URL_RE = re.compile(r"https?://(?:www\.)?(?:youtube\.com|youtu\.be)/\S+", re.I)


AI_SERVICES = [
    {
        "name": "Xkiro1 qwen/qwen3.8-max:free",
        "apiKey": "sk-xt-2c8e0cd0f60b988c1e3ac7c4fdb861d9ad469a9b2b8c463a",
        "apiUrl": "https://api.xkiro.com/v1/chat/completions",
        "modelName": "qwen/qwen3.8-max:free"
    },
    {
        "name": "AgnesAI agnes-2.0-flash",
        "apiKey": "sk-40tGLaeHdZkWPHjbpR4K5xY1aURbC8mPrTcye714ovu3s03q",
        "apiUrl": "https://apihub.agnes-ai.com/v1/chat/completions",
        "modelName": "agnes-2.0-flash",
    }
]


def clean_name(value: str) -> str:
    value = re.sub(r"[\\/:*?\"<>|\x00-\x1f]", "_", value).strip(" .")
    return value[:180] or "untitled"


def read_urls(args: argparse.Namespace) -> list[str]:
    if args.file:
        values = Path(args.file).expanduser().read_text(encoding="utf-8").splitlines()
    elif args.urls:
        values = args.urls
    elif args.stdin:
        values = sys.stdin.read().splitlines()
    else:
        values = [args.url]
    urls, seen = [], set()
    for line in values:
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        match = URL_RE.search(line)
        if match:
            url = match.group(0).rstrip(".,;，。；")
            if url not in seen:
                seen.add(url)
                urls.append(url)
        else:
            print(f"警告：忽略无效 URL：{line}", file=sys.stderr)
    return urls


def parse_vtt(text: str) -> list[dict[str, Any]]:
    def seconds(value: str) -> float:
        value = value.replace(",", ".").strip()
        parts = value.split(":")
        if len(parts) == 3:
            return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
        return int(parts[0]) * 60 + float(parts[1])

    items = []
    for block in re.split(r"\n\s*\n", text.replace("\r", "")):
        lines = block.splitlines()
        timestamp = next((line for line in lines if "-->" in line), None)
        if not timestamp:
            continue
        try:
            left, right = timestamp.split("-->", 1)
            start, end = seconds(left), seconds(right.split()[0])
            index = lines.index(timestamp)
            content = " ".join(lines[index + 1:])
            content = re.sub(r"<[^>]+>", "", content)
            content = re.sub(r"\s+", " ", content).strip()
            if content:
                items.append({"start": start, "end": end, "text": content})
        except (ValueError, IndexError):
            continue
    return items


def timestamp(value: float) -> str:
    total = int(value)
    hours, remainder = divmod(total, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}" if hours else f"{minutes:02d}:{seconds:02d}"



def get_video(url: str, work_dir: Path, cookies: bool) -> tuple[dict, str]:
    options = {
        "skip_download": True,
        "writesubtitles": True,
        "writeautomaticsub": True,
        "subtitleslangs": ["zh-Hans", "zh-CN", "zh", "en", "en-US", "en-GB"],
        "subtitlesformat": "vtt",
        "outtmpl": str(work_dir / "%(id)s.%(ext)s"),
        "quiet": True,
        "no_warnings": True,
    }

    if cookies:
        for browser in ("chrome", "firefox", "safari", "edge", "brave", "chromium"):
            try:
                trial = dict(options, cookiesfrombrowser=(browser,))
                with yt_dlp.YoutubeDL(trial) as ydl:
                    info = ydl.extract_info(url, download=True)
                break
            except Exception as exc:
                if "Video unavailable" in str(exc):
                    raise RuntimeError(f"目标视频不存在或不可用：{url}") from exc
                info = None
        else:
            try:
                with yt_dlp.YoutubeDL(options) as ydl:
                    info = ydl.extract_info(url, download=True)
            except Exception as exc:
                if "Video unavailable" in str(exc):
                    raise RuntimeError(f"目标视频不存在或不可用：{url}") from exc
                raise
    else:
        try:
            with yt_dlp.YoutubeDL(options) as ydl:
                info = ydl.extract_info(url, download=True)
        except Exception as exc:
            if "Video unavailable" in str(exc):
                raise RuntimeError(f"目标视频不存在或不可用：{url}") from exc
            raise

    if not info:
        raise RuntimeError("无法获取视频信息")

    video_id = info.get("id", "")
    files = list(work_dir.glob(f"{video_id}*.vtt"))
    preferred = next(
        (p for p in files if any(x in p.name.lower() for x in ("zh", "en"))),
        None,
    )
    subtitle = preferred or (files[0] if files else None)

    if not subtitle:
        raise RuntimeError("视频没有可用字幕")

    return info, subtitle.read_text(encoding="utf-8-sig")
    
    
    
    
def get_video_vieux(url: str, work_dir: Path, cookies: bool) -> tuple[dict, str]:
    options = {
        "skip_download": True, "writesubtitles": True, "writeautomaticsub": True,
        "subtitleslangs": ["zh-Hans", "zh-CN", "zh", "en", "en-US", "en-GB"],
        "subtitlesformat": "vtt", "outtmpl": str(work_dir / "%(id)s.%(ext)s"),
        "quiet": True, "no_warnings": True,
    }
    if cookies:
        for browser in ("chrome", "firefox", "safari", "edge", "brave", "chromium"):
            try:
                trial = dict(options, cookiesfrombrowser=(browser,))
                with yt_dlp.YoutubeDL(trial) as ydl:
                    info = ydl.extract_info(url, download=True)
                break
            except Exception:
                info = None
        else:
            with yt_dlp.YoutubeDL(options) as ydl:
                info = ydl.extract_info(url, download=True)
    else:
        with yt_dlp.YoutubeDL(options) as ydl:
            info = ydl.extract_info(url, download=True)
    if not info:
        raise RuntimeError("无法获取视频信息")
    video_id = info.get("id", "")
    files = list(work_dir.glob(f"{video_id}*.vtt"))
    preferred = next((p for p in files if any(x in p.name.lower() for x in ("zh", "en"))), None)
    subtitle = preferred or (files[0] if files else None)
    if not subtitle:
        raise RuntimeError("视频没有可用字幕")
    return info, subtitle.read_text(encoding="utf-8-sig")


def chunks(items: list[dict], size: int) -> list[list[dict]]:
    return [items[i:i + size] for i in range(0, len(items), size)]



def call_ai(service: dict, prompt: str) -> str:
    payload = json.dumps(
        {"model": service["modelName"], "messages": [{"role": "user", "content": prompt}], "temperature": 0.3}
    ).encode()
    
    # 创建 SSL 上下文，禁用证书验证（生产环境建议配置正确证书）
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    
    request = urllib.request.Request(
        service["apiUrl"].rstrip("/"),
        data=payload,
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {service['apiKey']}"},
    )
    
    with urllib.request.urlopen(request, context=ctx, timeout=300) as response:
        data = json.loads(response.read().decode("utf-8"))
    return data["choices"][0]["message"]["content"]
    
    

def summarize_with_fallback(transcript: str, title: str) -> str:
    prompt = f"""请用中文分析下面 YouTube 视频字幕，生成 Markdown 报告。必须包含：视频概述、2-5 分钟粒度章节摘要、关键要点、3-8 个关键词、小红书文案、抖音文案、微信公众号文案。不要编造字幕中没有的事实。

标题：{title}

字幕：
{transcript}
"""
    errors: list[str] = []
    for service in AI_SERVICES:
        if service["apiKey"].startswith("你的") or not service["apiKey"]:
            errors.append(f"[跳过] {service['name']} 未配置 API Key")
            continue
        try:
            print(f"  尝试 AI 服务：{service['name']} ...", file=sys.stderr)
            content = call_ai(service, prompt)
            print(f"  成功使用：{service['name']}", file=sys.stderr)
            return content
        except Exception as exc:
            errors.append(f"[失败] {service['name']}: {exc}")
            print(f"  失败：{service['name']} - {exc}", file=sys.stderr)
            continue
    print(f"所有 AI 服务均失败，将生成字幕提取报告。\n错误详情：\n" + "\n".join(errors), file=sys.stderr)
    return ""


def fallback_report(info: dict, subs: list[dict]) -> str:
    text = " ".join(x["text"] for x in subs)
    return f"# {info.get('title', 'Untitled')}\n\n> 未配置 AI API 或所有 AI 服务不可用，以下为字幕提取报告。\n\n## 视频概述\n{text[:1500]}\n\n## 字幕统计\n- 字幕条数：{len(subs)}\n- 字幕时长：{timestamp(subs[-1]['end']) if subs else '未知'}\n\n## 原始字幕摘录\n{text[:5000]}\n"


def summarize(url: str, output: Path, args: argparse.Namespace) -> tuple[bool, str]:
    work = output / ".cache"
    work.mkdir(parents=True, exist_ok=True)
    try:
        info, raw = get_video(url, work, not args.no_cookies)
        subs = parse_vtt(raw)
        if not subs:
            raise RuntimeError("字幕解析后没有有效内容")
        title, video_id = info.get("title", "untitled"), info.get("id", "")
        transcript = "\n".join(f"[{timestamp(x['start'])}] {x['text']}" for x in subs)
        report = summarize_with_fallback(transcript, title)
        if not report:
            report = fallback_report(info, subs)
        header = f"# {title}\n\n## 基本信息\n- 来源：YouTube\n- URL：{url}\n- 视频 ID：{video_id}\n- 生成日期：{date.today().isoformat()}\n\n"
        path = output / f"{clean_name(title)} [{video_id}].md"
        path.write_text(header + report.lstrip("# "), encoding="utf-8")
        return True, str(path)
    except Exception as exc:
        return False, f"{url}: {exc}"


def main() -> int:
    parser = argparse.ArgumentParser(
        description="批量获取 YouTube 字幕并生成结构化摘要 Markdown 报告（多 AI Provider 自动回退）。",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
输入方式：
  %(prog)s URL
  %(prog)s --file urls.txt
  %(prog)s --urls URL1 URL2 URL3
  cat urls.txt | %(prog)s --stdin

示例：
  %(prog)s URL
  %(prog)s --file urls.txt --output ~/Documents/summaries
  %(prog)s --urls URL1 URL2 --workers 2 --no-cookies
  %(prog)s --file urls.txt --dry-run

AI 服务配置：
  脚本内置 AI_SERVICES 数组，按顺序尝试：
  1. Google gemini-3.6-flash
  2. AgnesAI agnes-2.0-flash
  3. Openrouter free

  请在脚本顶部 AI_SERVICES 中填写你的 API Key，或保持默认值跳过该服务。
  脚本会自动回退到下一个可用服务；全部失败时生成字幕提取报告。
""",
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument("url", nargs="?", help="单个 YouTube URL")
    group.add_argument("--file", "-f", help="URL 列表文本文件，每行一个 URL")
    group.add_argument("--urls", "-u", nargs="+", help="命令行 URL 列表")
    group.add_argument("--stdin", action="store_true", help="从标准输入读取 URL")
    parser.add_argument("-o", "--output", default=str(DEFAULT_OUTPUT), help=f"报告输出目录（默认：{DEFAULT_OUTPUT}）")
    parser.add_argument("-w", "--workers", type=int, default=2, help="并发处理数，建议 1-3（默认：2）")
    parser.add_argument("--no-cookies", action="store_true", help="不尝试读取浏览器 Cookie")
    parser.add_argument("--dry-run", action="store_true", help="只检查 URL，不下载字幕")
    args = parser.parse_args()
    if not (args.url or args.file or args.urls or args.stdin):
        parser.error("请提供 URL、--file、--urls 或 --stdin")
    if not 1 <= args.workers <= 10:
        parser.error("--workers 必须在 1 到 10 之间")
    urls = read_urls(args)
    if not urls:
        parser.error("没有找到有效 URL")
    if args.dry_run:
        print("有效 URL：\n" + "\n".join(urls))
        return 0
    output = Path(args.output).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    print(f"开始处理 {len(urls)} 个视频 → {output}")
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(args.workers, len(urls))) as pool:
        futures = [pool.submit(summarize, url, output, args) for url in urls]
        results = [future.result() for future in concurrent.futures.as_completed(futures)]
    success = 0
    for ok, message in results:
        print(("成功：" if ok else "失败：") + message, file=sys.stdout if ok else sys.stderr)
        success += int(ok)
    print(f"完成：成功 {success}，失败 {len(results) - success}，共 {len(results)}")
    return 0 if success == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
