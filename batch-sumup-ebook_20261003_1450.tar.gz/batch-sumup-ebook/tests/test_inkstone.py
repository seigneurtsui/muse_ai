"""Synthetic Markdown/MCP tests. No real books, API keys or remote service calls."""
import contextlib
import copy
import fcntl
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import batch_sumup_ebook as pipeline
import ebook_inkstone as inkstone
from test_pipeline import fake_valid_voice


class FakeClient:
    BASE_URL = "https://inkstone.invalid/mcp"
    DEFAULT_IMPORT_FOLDER_ID = "fixture-notes"
    API_KEY = "FAKE_KEY"

    def __init__(self):
        self.calls = []
        self.notes = {}
        self.before_write = None
        self.fail_write = False

    def mcp_call(self, method, params, request_id=30):
        self.calls.append(copy.deepcopy(params))
        name, args = params["name"], params["arguments"]
        if name == "fetch":
            result = self.notes[args["id"]]
        else:
            if self.before_write:
                self.before_write()
            if name == "create_note":
                note_id = f"fixture-note-{len(self.notes)+1}"
                result = {"id": note_id, "text": args["content"], "title": args["title"], "rev": 1, "folder_id": args["folder_id"]}
                self.notes[note_id] = result
            elif name == "edit_note":
                result = self.notes[args["note_id"]]
                assert result["rev"] == args["expected_rev"]
                result.update(text=args["text"], title=args["title"], rev=result["rev"] + 1)
            else:
                raise AssertionError("unexpected MCP operation")
            if self.fail_write:
                raise TimeoutError("PRIVATE_SERVER_RESPONSE_AND_KEY")
        return {"jsonrpc": "2.0", "result": {"structuredContent": {"data": copy.deepcopy(result)}}}


class InkstoneTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.book = self.root / "book"
        self.book.mkdir()
        self.summary = "# 摘要\n\n只用于离线测试。\n"
        self.insights = "# 现代启示\n\n- 行动建议\n- 开放性问题？\n"
        (self.book / "summary.md").write_text(self.summary)
        (self.book / "modern_insights.md").write_text(self.insights)
        (self.book / "summary.txt").write_text("PLAIN_TEXT_NOT_FOR_UPLOAD")
        (self.book / "summary_voice.txt").write_text("VOICE_NOT_FOR_UPLOAD")
        self.actual_loader = inkstone.load_client
        self.real_curl = shutil.which("curl")
        self.client = FakeClient()
        patcher = patch.object(inkstone, "load_client", return_value=self.client)
        self.loader = patcher.start()
        self.addCleanup(patcher.stop)
        which = patch.object(inkstone.shutil, "which", return_value="curl")
        which.start()
        self.addCleanup(which.stop)

    def process(self, **kwargs):
        return inkstone.process_notes(self.book, "离线测试书", "source-fixture", **kwargs)

    def test_merge_preserves_sections_and_excludes_plaintext_voice_and_source(self):
        before = {path.name: path.read_bytes() for path in self.book.iterdir()}
        result = self.process(submit=False)
        content = (self.book / inkstone.MERGED_NAME).read_text()
        self.assertEqual(result["status"], "local_only")
        self.assertIn(self.summary, content)
        self.assertIn(self.insights, content)
        self.assertLess(content.index(self.summary), content.index("\n\n---\n\n"))
        self.assertIn("## 现代启示与行动建议", content)
        self.assertNotIn("NOT_FOR_UPLOAD", content)
        self.assertEqual(before, {name: (self.book / name).read_bytes() for name in before})
        self.loader.assert_not_called()
        self.assertEqual(json.loads((self.book / inkstone.RESULT_NAME).read_text())["status"], "local_only")
        self.assertEqual((self.book / inkstone.MERGED_NAME).stat().st_mode & 0o777, 0o600)

    def test_default_submit_uses_sibling_target_and_persists_intent_before_write(self):
        def intent_exists():
            saved = json.loads((self.book / inkstone.RECEIPT_NAME).read_text())
            self.assertEqual(saved["status"], "in_flight")
            self.assertTrue(saved["operation_id"])
        self.client.before_write = intent_exists
        result = self.process()
        self.assertEqual(result["status"], "submitted")
        self.assertNotIn("reason", result)
        self.assertEqual(result["service_url"], self.client.BASE_URL)
        args = self.client.calls[0]["arguments"]
        self.assertEqual(args["folder_id"], "01m407exy0s1sa80y44e567ym7")
        self.assertEqual(result["folder_name"], "Ebooks")
        self.assertEqual(self.client.DEFAULT_IMPORT_FOLDER_ID, "fixture-notes", "generic default must not be changed")
        self.assertEqual(args["content"], (self.book / inkstone.MERGED_NAME).read_text())
        self.assertEqual(args["title"], "离线测试书｜摘要与现代启示")
        self.assertEqual((self.book / inkstone.RECEIPT_NAME).stat().st_mode & 0o777, 0o600)
        again = self.process()
        self.assertEqual(again["status"], "already_submitted")
        self.assertEqual(len(self.client.calls), 1)
        self.assertEqual(again["note_id"], result["note_id"])

    def test_modified_content_updates_existing_note_with_revision_guard(self):
        first = self.process()
        (self.book / "modern_insights.md").write_text("# 更新的启示\n真实输入仍然只在临时测试目录。")
        changed = self.process()
        self.assertEqual(changed["status"], "updated")
        self.assertEqual(changed["note_id"], first["note_id"])
        self.assertEqual([call["name"] for call in self.client.calls], ["create_note", "fetch", "edit_note"])
        self.assertEqual(self.client.calls[-1]["arguments"]["expected_rev"], 1)
        self.assertEqual(self.client.calls[-1]["arguments"]["operation"], "replace_all")
        self.assertEqual(self.process()["status"], "already_submitted")
        self.assertEqual(len(self.client.notes), 1)

    def test_remote_edit_is_not_overwritten(self):
        first = self.process()
        self.client.notes[first["note_id"]]["text"] = "REMOTE_USER_EDIT"
        (self.book / "summary.md").write_text("new local content")
        result = self.process()
        self.assertEqual(result["status"], "blocked")
        self.assertEqual(result["reason"], "remote_content_changed")
        self.assertEqual([call["name"] for call in self.client.calls], ["create_note", "fetch"])
        self.assertEqual(self.client.notes[first["note_id"]]["text"], "REMOTE_USER_EDIT")

    def test_timeout_after_remote_commit_does_not_blindly_create_again(self):
        self.client.fail_write = True
        first = self.process()
        self.assertEqual(first["status"], "uncertain")
        self.assertEqual(len(self.client.notes), 1)
        self.client.fail_write = False
        again = self.process()
        self.assertEqual(again["status"], "uncertain")
        (self.book / "summary.md").write_text("changed after uncertainty")
        self.assertEqual(self.process()["status"], "uncertain")
        self.assertEqual(len(self.client.calls), 1)
        self.assertNotIn("PRIVATE", json.dumps(first) + (self.book / inkstone.RESULT_NAME).read_text())

    def test_mcp_error_or_missing_id_never_counts_as_submitted(self):
        for reply in ({"result": {"isError": True, "structuredContent": {"id": "misleading-id"}}},
                      {"result": {"structuredContent": {"success": True}}},
                      {"result": {"structuredContent": {"error": "PRIVATE_ERROR", "id": "fake"}}}):
            with self.subTest(reply=reply):
                (self.book / inkstone.RECEIPT_NAME).unlink(missing_ok=True)
                with patch.object(self.client, "mcp_call", return_value=reply):
                    result = self.process()
                self.assertEqual(result["status"], "uncertain")
                self.assertNotIn("PRIVATE", json.dumps(result))

    def test_missing_key_preserves_local_markdown_without_network(self):
        self.client.API_KEY = ""
        result = self.process()
        self.assertEqual(result["status"], "blocked")
        self.assertEqual(result["reason"], "INKSTONE_API_KEY_not_set")
        self.assertTrue((self.book / inkstone.MERGED_NAME).is_file())
        self.assertEqual(self.client.calls, [])
        self.assertFalse((self.book / inkstone.RECEIPT_NAME).exists())

    def test_missing_empty_or_symlinked_section_never_submits(self):
        path = self.book / "modern_insights.md"
        for kind in ("missing", "empty", "symlink"):
            path.unlink(missing_ok=True)
            if kind == "empty": path.write_text(" \n")
            if kind == "symlink": path.symlink_to(self.book / "summary.md")
            self.assertEqual(self.process()["status"], "blocked")
            self.assertEqual(self.client.calls, [])

    def test_corrupt_receipt_changed_target_and_untrusted_legacy_fail_closed(self):
        path = self.book / inkstone.RECEIPT_NAME
        path.write_text("not JSON")
        self.assertEqual(self.process()["status"], "blocked")
        self.assertEqual(self.client.calls, [])
        path.unlink()
        self.process()
        self.client.BASE_URL = "https://another.invalid/mcp"
        self.assertEqual(self.process()["reason"], "target_changed_review_required")
        self.assertEqual(len(self.client.calls), 1)
        self.assertEqual(self.process(trusted=False)["reason"], "legacy_outputs_need_source_verification")
        self.assertEqual(len(self.client.calls), 1)

    def test_strict_summary_split_prevents_uploading_plaintext_response(self):
        for text in ("unstructured", "---summary.md---\nmd\n---summary.txt---\nplain",
                     "---summary.txt---\n\n---summary.md---\nmd"):
            with self.assertRaises(ValueError): pipeline.parse_summary(text, "fixture")
        self.assertEqual(pipeline.parse_summary("---summary.txt---\nplain\n---summary.md---\n# md", "fixture"), ("plain", "# md"))

    def run_pipeline(self, missing_key=False, local_only=False, book_names=("合成测试",)):
        source = self.root / "input"
        source.mkdir(exist_ok=True)
        for name in book_names:
            (source / f"{name}.txt").write_text("这是离线测试素材，不是用户的真实书籍。")
        output = self.root / "output"
        if missing_key: self.client.API_KEY = ""
        stages = []
        for _ in range(8 * len(book_names) + 4):
            report, code = pipeline.batch_process(source, output, submit_notes=not local_only)
            if code != 10: return report, code, stages, source, output
            request = report["request"]
            stage = request["stage"]
            stages.append(stage)
            if stage.startswith("chunk_"): text = "合成测试摘要。"
            elif stage == "summary": text = "---summary.txt---\n纯文本测试摘要\n---summary.md---\n# Markdown 测试摘要"
            elif stage == "insights": text = "# 现代启示\n这是测试内容。"
            else:
                self.assertTrue((output / request["book_name"] / inkstone.MERGED_NAME).exists())
                if not missing_key and not local_only:
                    self.assertIn(request["book_name"] + "｜摘要与现代启示", [n["title"] for n in self.client.notes.values()], "submission must precede voice")
                text = fake_valid_voice()
            Path(request["response_path"]).write_text(text)
        self.fail("unbounded handoff")

    def test_default_pipeline_submits_once_before_voice_and_skips_without_duplicates(self):
        report, code, stages, source, output = self.run_pipeline()
        self.assertEqual(code, 0)
        self.assertEqual(stages, ["chunk_001", "summary", "insights", "voice"])
        self.assertEqual(report["success"], 1)
        self.assertEqual(report["inkstone"]["incomplete"], 0)
        self.assertEqual(len(self.client.calls), 1)
        again, code = pipeline.batch_process(source, output)
        self.assertEqual(code, 0)
        self.assertEqual(again["skipped"], 1)
        self.assertEqual(again["results"][0]["inkstone"]["status"], "already_submitted")
        self.assertEqual(len(self.client.calls), 1)

    def test_missing_key_finishes_voice_but_reports_submission_incomplete(self):
        report, code, stages, source, output = self.run_pipeline(missing_key=True)
        self.assertEqual(code, 1)
        self.assertEqual(report["success"], 1)
        self.assertEqual(report["inkstone"]["blocked"], 1)
        self.assertIn("voice", stages)
        self.assertEqual(self.client.calls, [])
        import notify_result
        title, body = notify_result.build_message(report, self.root / "batch_result.json")
        self.assertIn("有失败", title)
        self.assertIn("Inkstone：未提交", body)
        self.assertIn("未完成 1", body)
        self.client.API_KEY = "FAKE_READY_AFTER_LOCAL_SETUP"
        resumed, code = pipeline.batch_process(source, output)
        self.assertEqual(code, 0)
        self.assertEqual(resumed["skipped"], 1)
        self.assertEqual(resumed["inkstone"]["complete"], 1)
        self.assertEqual(resumed["results"][0]["inkstone"]["status"], "submitted")

    def test_local_only_pipeline_never_loads_client_and_can_later_submit(self):
        report, code, _, source, output = self.run_pipeline(local_only=True)
        self.assertEqual(code, 0)
        self.assertEqual(report["inkstone"]["local_only"], 1)
        self.loader.assert_not_called()
        later, code = pipeline.batch_process(source, output)
        self.assertEqual(code, 0)
        self.assertEqual(later["skipped"], 1)
        self.assertEqual(later["results"][0]["inkstone"]["status"], "submitted")
        self.assertEqual(len(self.client.calls), 1)

    def test_each_book_gets_one_separate_combined_note(self):
        report, code, stages, _, output = self.run_pipeline(book_names=("甲书", "乙书"))
        self.assertEqual(code, 0)
        self.assertEqual(report["success"], 2)
        self.assertEqual(len(self.client.notes), 2)
        self.assertEqual(len(self.client.calls), 2)
        self.assertEqual(set(n["title"] for n in self.client.notes.values()), {"甲书｜摘要与现代启示", "乙书｜摘要与现代启示"})
        self.assertTrue(all((output / name / inkstone.MERGED_NAME).exists() for name in ("甲书", "乙书")))

    def test_remote_title_or_folder_change_is_not_overwritten(self):
        first = self.process()
        (self.book / "summary.md").write_text("new content")
        remote = self.client.notes[first["note_id"]]
        title = remote["title"]
        remote["title"] = "USER_TITLE_EDIT"
        self.assertEqual(self.process()["reason"], "remote_content_changed")
        remote["title"] = title
        remote["folder_id"] = "another-folder"
        self.assertEqual(self.process()["reason"], "remote_folder_changed")
        self.assertNotIn("edit_note", [c["name"] for c in self.client.calls])

    def test_concurrent_or_unpersisted_write_never_starts_network(self):
        fd = os.open(self.book / ".inkstone.lock", os.O_RDWR | os.O_CREAT, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.assertEqual(self.process()["reason"], "another_submission_in_progress")
        finally:
            os.close(fd)
        original = inkstone.save_json
        def fail_receipt(path, value):
            if path.name == inkstone.RECEIPT_NAME: raise OSError("synthetic disk failure")
            return original(path, value)
        with patch.object(inkstone, "save_json", side_effect=fail_receipt):
            self.assertEqual(self.process()["status"], "blocked")
        self.assertEqual(self.client.calls, [])

    def test_cli_local_only_is_forwarded_without_running_pipeline(self):
        with patch.object(sys, "argv", ["batch_sumup_ebook.py", str(self.root), "--local-only"]), \
             patch.object(pipeline, "batch_process", return_value=({"status": "complete"}, 0)) as run, \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(pipeline.main(), 0)
        run.assert_called_once_with(str(self.root), submit_notes=False)

    def test_key_never_appears_in_curl_arguments(self):
        with patch.dict(os.environ, {"INKSTONE_API_KEY": "FAKE_STDIN_KEY"}):
            client = self.actual_loader()
        self.assertEqual(client.DEFAULT_IMPORT_FOLDER_ID, "01m2mrk9wth9y55961cxxmfarm")
        reply = subprocess.CompletedProcess([], 0, b'{"result":{}}\n200', b'')
        with patch.object(client.subprocess, "run", return_value=reply) as run:
            client.mcp_call("tools/call", {"name": "create_note", "arguments": {"content": "SYNTHETIC"}})
        self.assertNotIn("FAKE_STDIN_KEY", str(run.call_args.args))
        self.assertEqual(run.call_args.kwargs["input"], b"Authorization: Bearer FAKE_STDIN_KEY\n")
        self.assertIn("@-", run.call_args.args[0])
        client.API_KEY = "bad\nheader"
        with patch.object(client.subprocess, "run") as run:
            with self.assertRaises(RuntimeError): client.mcp_call("tools/call")
            run.assert_not_called()

    def test_actual_curl_sends_stdin_header_and_synthetic_mcp_only_to_loopback(self):
        if not self.real_curl: self.skipTest("curl unavailable")
        seen = []
        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                seen.append((self.headers.get("Authorization"), json.loads(self.rfile.read(int(self.headers["Content-Length"])))))
                body = b'data: {"jsonrpc":"2.0","result":{"structuredContent":{"id":"fixture-wire-id"}}}\n\n'
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            def log_message(self, *args): pass
        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            (self.root / ".curlrc").write_text('noproxy = "*"\n')
            with patch.dict(os.environ, {"INKSTONE_API_KEY": "FAKE_WIRE_KEY", "CURL_HOME": str(self.root), "NO_PROXY": "*"}):
                client = self.actual_loader()
                client.BASE_URL = f"http://127.0.0.1:{server.server_port}/mcp"
                answer = inkstone.tool(client, "create_note", {"content": "SYNTHETIC_WIRE_CONTENT"})
            self.assertEqual(answer["id"], "fixture-wire-id")
            self.assertEqual(seen, [("Bearer FAKE_WIRE_KEY", {"jsonrpc": "2.0", "id": 30, "method": "tools/call", "params": {"name": "create_note", "arguments": {"content": "SYNTHETIC_WIRE_CONTENT"}}})])
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)


if __name__ == "__main__":
    unittest.main()
