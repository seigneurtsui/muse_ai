"""Notification tests: synthetic reports + loopback HTTP only, no real channels."""
import hashlib
import json
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import notify_result as notify


class NotificationsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.report_path = self.root / "batch_result.json"
        self.config = self.root / "notify.json"
        self.env = self.root / "absent.env"
        self.received = []
        self.server = None
        self.write_report()

    def write_report(self, results=None):
        if results is None:
            results = [{"book_name": "测试书", "status": "success", "error": None,
                        "summary_path": str(self.root / "测试书/summary_voice.txt"),
                        "duration": {"valid": True, "char_count": 6184, "duration_minutes": 19.6,
                                     "quality": {"chinese_chars": 5654, "repeat_pairs": 0,
                                                 "paragraph_stats": {"paragraph_count": 50}}}}]
        report = {"status": "complete", "total": len(results), "results": results,
                  "source_dir": str(self.root / "books"), "output_dir": str(self.root)}
        report.update({s: sum(r["status"] == s for r in results) for s in notify.STATUSES})
        self.report_path.write_text(json.dumps(report, ensure_ascii=False))
        return report

    def start_server(self):
        received = self.received
        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                body = self.rfile.read(int(self.headers["Content-Length"]))
                received.append((self.path, json.loads(body)))
                self.send_response(500 if self.path == "/fail" else 200)
                self.end_headers()
                self.wfile.write(b'{"ok":true}')
            def log_message(self, *args):
                pass
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        thread.start()
        def close():
            self.server.shutdown()
            self.server.server_close()
            thread.join(timeout=5)
        self.addCleanup(close)
        return f"http://127.0.0.1:{self.server.server_port}"

    def set_config(self, channels, enabled=True):
        self.config.write_text(json.dumps({"enabled": enabled, "retries": 0, "timeout": 2,
                                           "channels": channels, "profiles": {"local": list(channels)}}))
        self.config.chmod(0o600)

    def send(self, mode="send", channels="local", **kwargs):
        return notify.notify_report(self.report_path, mode, channels=channels,
                                    config=self.config, env_file=self.env, **kwargs)

    def test_preview_never_launches_notifier(self):
        with patch.object(notify, "invoke_notifier", side_effect=AssertionError("unexpected notifier")):
            report = notify.notify_report(self.report_path)
        self.assertEqual(report["status"], "preview")
        self.assertEqual(report["accepted"], 0)
        content = Path(report["content_file"]).read_text()
        for expected in ("测试书", "6184", "5654", "19.6", "50", "成功 1", "校验：通过", "summary_voice.txt"):
            self.assertIn(expected, content)
        self.assertEqual(Path(report["content_file"]).stat().st_mode & 0o777, 0o600)
        self.assertEqual(list(Path(report["content_file"]).parent.glob("*.delivery.json")), [])

    def test_requires_explicit_selection_and_completed_report(self):
        for mode in ("send", "dry_run"):
            with self.assertRaises(ValueError):
                notify.notify_report(self.report_path, mode)
        for status in ("awaiting_ai", "error", "running"):
            self.report_path.write_text(json.dumps({"status": status}))
            with patch.object(notify, "invoke_notifier") as service:
                with self.assertRaises(ValueError):
                    self.send()
                service.assert_not_called()

    def test_rejects_pending_books_or_inconsistent_counts(self):
        data = self.write_report()
        data["results"][0]["status"] = "pending"
        self.report_path.write_text(json.dumps(data))
        with self.assertRaises(ValueError):
            notify.load_report(self.report_path)
        data = self.write_report()
        data["success"] = 10
        self.report_path.write_text(json.dumps(data))
        with self.assertRaises(ValueError):
            notify.load_report(self.report_path)

    def test_message_empty_and_all_skipped(self):
        report = self.write_report([])
        self.assertIn("未发现支持的电子书", notify.build_message(report, self.report_path)[1])
        report = self.write_report([{"book_name": "旧书", "status": "skipped"}])
        self.assertIn("本次未重新生成", notify.build_message(report, self.report_path)[1])

    def test_failures_first_and_raw_errors_not_sent(self):
        report = self.write_report([
            {"book_name": "成功书", "status": "success"},
            {"book_name": "加密书", "status": "failed", "error": "DRMError Secret-Do-Not-Send"},
            {"book_name": "短稿", "status": "needs_update", "error": "Private-Log-Do-Not-Send"},
        ])
        title, content = notify.build_message(report, self.report_path)
        self.assertIn("有失败", title)
        self.assertIn("DRM 加密", content)
        self.assertLess(content.index("加密书"), content.index("成功书"))
        self.assertNotIn("Secret-Do-Not-Send", content)
        self.assertNotIn("Private-Log-Do-Not-Send", content)
        self.assertIn("待更新 1", content)

    def test_no_reading_summary_or_ebook_content(self):
        # Paths to nonexistent book/summary files are still sufficient: only the
        # structured report may be used to construct operational notifications.
        data = self.write_report()
        data["results"][0]["summary_path"] = str(self.root / "not-present/summary_voice.txt")
        title, content = notify.build_message(data, self.report_path)
        self.assertIn("not-present", content)

    def test_paths_keep_underscores_and_normal_punctuation(self):
        path = self.root / "summary_voice/book_1/summary_voice.txt"
        data = self.write_report()
        data["results"][0]["summary_path"] = str(path)
        _, content = notify.build_message(data, self.report_path)
        self.assertIn(str(path), content)
        self.assertIn(str(self.report_path), content)

    def test_unicode_length_limit_and_explicit_omission(self):
        report = self.write_report([{"book_name": "很长的书名😀" * 100, "status": "success"} for _ in range(500)])
        title, content = notify.build_message(report, self.report_path)
        self.assertLessEqual(notify.units(title + "\n" + content), notify.MESSAGE_LIMIT)
        self.assertIn("500 本", content)
        self.assertIn("未逐项展开", content)
        self.assertIn("完整报告", content)

    def test_template_and_control_characters_are_data(self):
        report = self.write_report([{"book_name": "{{SECRET}}\n<script>\x00", "status": "success"}])
        _, content = notify.build_message(report, self.report_path)
        self.assertNotIn("{{SECRET}}", content)
        self.assertNotIn("<script>", content)
        self.assertNotIn("\x00", content)

    def test_real_notifier_dry_run_has_no_http(self):
        url = self.start_server()
        self.set_config({"local": {"type": "webhook", "enabled": True, "url": url + "/ok"}})
        result = self.send(mode="dry_run")
        self.assertEqual(result["status"], "dry_run")
        self.assertEqual(result["results"][0]["status"], "ready")
        self.assertEqual(self.received, [])

    def test_loopback_send_preflight_and_deduplication(self):
        url = self.start_server()
        self.set_config({"local": {"type": "webhook", "enabled": True, "url": url + "/ok"}})
        before = self.report_path.read_bytes()
        config_before = self.config.read_bytes()
        result = self.send()
        self.assertEqual(result["accepted"], 1)
        self.assertEqual(len(self.received), 1)
        self.assertIn("6184", self.received[0][1]["content"])
        self.assertEqual(self.received[0][1]["title"], result["title"])
        duplicate = self.send()
        self.assertEqual(duplicate["status"], "already_attempted")
        self.assertEqual(duplicate["accepted"], 0)
        self.assertEqual(len(self.received), 1)
        self.assertEqual(self.report_path.read_bytes(), before)
        self.assertEqual(self.config.read_bytes(), config_before)
        receipt = json.loads(Path(result["receipt_file"]).read_text())
        self.assertEqual(receipt["attempted"]["local"]["status"], "accepted")

    def test_partial_failure_never_retries_entire_batch(self):
        url = self.start_server()
        self.set_config({"good": {"type": "webhook", "enabled": True, "url": url + "/ok"},
                         "bad": {"type": "webhook", "enabled": True, "url": url + "/fail"}})
        before = self.report_path.read_bytes()
        result = self.send(channels="good,bad")
        self.assertFalse(result["ok"])
        self.assertEqual(result["accepted"], 1)
        self.assertEqual(len(self.received), 2)
        self.assertEqual(self.report_path.read_bytes(), before)
        duplicate = self.send(channels="good,bad")
        self.assertEqual(duplicate["status"], "already_attempted")
        self.assertEqual(len(self.received), 2)

    def test_new_selection_sends_only_new_channel(self):
        url = self.start_server()
        self.set_config({"one": {"type": "webhook", "enabled": True, "url": url + "/one"},
                         "two": {"type": "webhook", "enabled": True, "url": url + "/two"}})
        self.send(channels="one")
        second = self.send(channels="one,two")
        self.assertEqual(second["accepted"], 1)
        self.assertEqual(second["skipped_channels"], ["one"])
        self.assertEqual([p for p, _ in self.received], ["/one", "/two"])

    def test_profile_and_explicit_all_enabled(self):
        url = self.start_server()
        self.set_config({"one": {"type": "webhook", "enabled": True, "url": url + "/one"}})
        profile = self.send(mode="dry_run", channels=None, profile="local")
        all_enabled = self.send(mode="dry_run", channels=None, all_enabled=True)
        self.assertEqual(profile["results"], all_enabled["results"])
        self.assertEqual(profile["results"][0]["channel"], "one")
        self.assertEqual(self.received, [])

    def test_disabled_service_not_reported_as_delivery(self):
        url = self.start_server()
        self.set_config({"local": {"type": "webhook", "enabled": True, "url": url + "/ok"}}, enabled=False)
        result = self.send()
        self.assertEqual(result["status"], "disabled")
        self.assertEqual(result["accepted"], 0)
        self.assertEqual(self.received, [])
        self.assertNotIn("receipt_file", result)

    def test_failed_preflight_prevents_all_network(self):
        url = self.start_server()
        self.set_config({"good": {"type": "webhook", "enabled": True, "url": url + "/ok"},
                         "bad": {"type": "webhook", "enabled": True, "url": "${MISSING_TEST_NOTIFY_URL}"}})
        with patch.dict("os.environ", {}, clear=True):
            result = self.send(channels="good,bad")
        self.assertFalse(result["ok"])
        self.assertEqual(result["status"], "configuration_error")
        self.assertEqual(self.received, [])
        self.assertNotIn("receipt_file", result)

    def test_timeout_marks_unknown_and_prevents_retry(self):
        preflight = {"ok": True, "status": "dry_run", "accepted": 0,
                     "results": [{"channel": "local", "status": "ready"}]}
        timeout = {"ok": False, "status": "unknown", "message": "delivery unknown"}
        with patch.object(notify, "invoke_notifier", side_effect=[preflight, timeout]):
            result = self.send()
        self.assertFalse(result["ok"])
        receipt = json.loads(Path(result["receipt_file"]).read_text())
        self.assertEqual(receipt["attempted"]["local"]["status"], "unknown")
        with patch.object(notify, "invoke_notifier", return_value=preflight) as service:
            repeat = self.send()
            self.assertEqual(service.call_count, 1)
        self.assertEqual(repeat["status"], "already_attempted")

    def test_interruption_keeps_pre_send_marker(self):
        preflight = {"ok": True, "status": "dry_run", "results": [{"channel": "local", "status": "ready"}]}
        with patch.object(notify, "invoke_notifier", side_effect=[preflight, KeyboardInterrupt]):
            with self.assertRaises(KeyboardInterrupt):
                self.send()
        with patch.object(notify, "invoke_notifier", return_value=preflight):
            repeat = self.send()
        self.assertEqual(repeat["status"], "already_attempted")
        receipt = json.loads(Path(repeat["receipt_file"]).read_text())
        self.assertEqual(receipt["attempted"]["local"]["status"], "attempting")

    def test_cli_send_without_selection_rejects_safely(self):
        before = hashlib.sha256(self.report_path.read_bytes()).digest()
        process = subprocess.run([sys.executable, str(Path(notify.__file__)), str(self.report_path), "--send"],
                                 capture_output=True, text=True)
        self.assertEqual(process.returncode, 1)
        self.assertEqual(json.loads(process.stdout)["status"], "notification_error")
        self.assertEqual(hashlib.sha256(self.report_path.read_bytes()).digest(), before)

    def test_subprocess_timeout_and_bad_json_are_safe(self):
        for error in (subprocess.TimeoutExpired(["notifier"], 600), ValueError("secret detail")):
            with patch.object(notify.subprocess, "run", side_effect=error):
                result = notify.invoke_notifier("title", self.report_path, channels="local")
            self.assertEqual(result["status"], "unknown")
            self.assertNotIn("secret detail", json.dumps(result))


if __name__ == "__main__":
    unittest.main()
