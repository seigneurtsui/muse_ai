#!/usr/bin/env python3
"""Compile a maintained Simplified-Chinese errata source into a flat runtime table.

OpenCC is a BUILD dependency only. Never convert an input document to simplify
matching. Ambiguous generation fails closed; the runtime needs only stdlib.
"""

from __future__ import annotations
import argparse
from importlib import metadata
import json
from pathlib import Path
import sys

from file_support import ErratumError, atomic_write, loads, packed, read_regular, sha

VERSION = 1
ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "assets/chinese_homophone_errors.source.json"
OUTPUT = ROOT / "assets/chinese_homophone_errors.json"
REPORT = ROOT / "references/dictionary-build.json"
LIMIT = 2 * 1024 * 1024


class BuildError(ErratumError):
    def __init__(self, code, details=None):
        super().__init__(code)
        self.details = details or []


class Converter:
    def __init__(self):
        try:
            from opencc import OpenCC

            self.simplify = OpenCC("t2s").convert
            self.traditional = OpenCC("s2t").convert
        except Exception:
            raise BuildError("opencc_required_for_dictionary_build_only") from None
        self.info = {
            "api": "opencc.OpenCC",
            "profiles": ["t2s", "s2t"],
            "distributions": {},
        }
        for name in ("OpenCC", "opencc-python-reimplemented"):
            try:
                self.info["distributions"][name] = metadata.version(name)
            except metadata.PackageNotFoundError:
                pass
        try:
            if self.traditional("汉语") != "漢語" or self.simplify("漢語") != "汉语":
                raise ValueError()
        except Exception:
            raise BuildError("opencc_probe_failed") from None


def text_pair(wrong, right):
    if (
        not isinstance(wrong, str)
        or not isinstance(right, str)
        or not wrong
        or not right
    ):
        raise BuildError("invalid_rule_pair")
    if wrong.startswith("_") or len(wrong) > 100 or len(right) > 100:
        raise BuildError("invalid_rule_pair")
    if any(ch.isspace() or ord(ch) < 32 for ch in wrong + right):
        raise BuildError("whitespace_or_control_in_rule")
    if wrong == right:
        raise BuildError("source_contains_noop_rule", [wrong])


def compile_dictionary(source, converter, source_hash):
    if (
        not isinstance(source, dict)
        or type(source.get("_schema")) is not int
        or source["_schema"] != VERSION
    ):
        raise BuildError("unsupported_source_schema")
    if set(k for k in source if k.startswith("_")) - {
        "_schema",
        "_comment",
        "_review_only",
        "_approved_non_roundtrip",
    }:
        raise BuildError("unknown_source_metadata")
    review = source.get("_review_only", {})
    approved = source.get("_approved_non_roundtrip", {})
    if not isinstance(review, dict) or not isinstance(approved, dict):
        raise BuildError("invalid_source_metadata")
    rules = [(w, r) for w, r in source.items() if not w.startswith("_")]
    if not rules or len(rules) > 10000:
        raise BuildError("invalid_source_rule_count")
    active = dict(rules)
    for wrong, entry in review.items():
        if (
            not isinstance(entry, dict)
            or set(entry) != {"right", "reason"}
            or not isinstance(entry["reason"], str)
            or not entry["reason"].strip()
        ):
            raise BuildError("invalid_review_only_entry")
        text_pair(wrong, entry["right"])
        if wrong in active:
            raise BuildError("review_only_rule_is_active", [wrong])
        if (
            converter.simplify(wrong) != wrong
            or converter.simplify(entry["right"]) != entry["right"]
        ):
            raise BuildError("review_only_not_simplified", [wrong])
    for wrong, entry in approved.items():
        if (
            wrong not in active
            or not isinstance(entry, dict)
            or set(entry) != {"traditional_sha256", "reason"}
        ):
            raise BuildError("invalid_non_roundtrip_approval")
        if not isinstance(entry["reason"], str) or not entry["reason"].strip():
            raise BuildError("invalid_non_roundtrip_approval")
        digest = entry["traditional_sha256"]
        if (
            not isinstance(digest, str)
            or len(digest) != 64
            or any(ch not in "0123456789abcdef" for ch in digest)
        ):
            raise BuildError("invalid_non_roundtrip_approval")
    compiled = {}
    provenance = {}
    duplicate_forms = 0
    generated = 0
    script_sensitive = {}
    collapsed = []
    non_roundtrip = []
    consumed_approvals = set()

    def add(wrong, right, origin, form):
        nonlocal duplicate_forms
        if wrong in script_sensitive:
            raise BuildError("script_sensitive_key_reintroduced", [wrong])
        if wrong in compiled:
            if compiled[wrong] != right:
                raise BuildError(
                    "generated_key_conflict",
                    [
                        {
                            "key": wrong,
                            "existing": compiled[wrong],
                            "candidate": right,
                            "source": origin,
                        }
                    ],
                )
            duplicate_forms += 1
            provenance[wrong].append({"source": origin, "form": form})
        else:
            compiled[wrong] = right
            provenance[wrong] = [{"source": origin, "form": form}]

    for wrong, right in rules:
        text_pair(wrong, right)
        if converter.simplify(wrong) != wrong or converter.simplify(right) != right:
            raise BuildError("source_rule_not_simplified", [wrong, right])
        tw, tr = converter.traditional(wrong), converter.traditional(right)
        if not isinstance(tw, str) or not isinstance(tr, str) or not tw or not tr:
            raise BuildError("invalid_opencc_generation")
        if tw == tr:
            # The converter normalized away the typo. Keep the Hans rule but
            # publish no fictional Hant error; this skip is explicit in metadata.
            collapsed.append({"source": wrong, "correct": right, "traditional": tw})
            if tw == wrong:
                if wrong in compiled:
                    raise BuildError("generated_key_conflict", [wrong])
                script_sensitive[wrong] = {"simplified": right, "traditional": tr}
            else:
                add(wrong, right, wrong, "simplified")
            continue
        text_pair(tw, tr)
        back = (converter.simplify(tw), converter.simplify(tr))
        if back != (wrong, right):
            digest = sha(packed([tw, tr]))
            entry = approved.get(wrong)
            if entry is None or entry["traditional_sha256"] != digest:
                raise BuildError(
                    "traditional_roundtrip_requires_review",
                    [
                        {
                            "wrong": wrong,
                            "right": right,
                            "traditional_wrong": tw,
                            "traditional_right": tr,
                            "roundtrip": list(back),
                            "approval_sha256": digest,
                        }
                    ],
                )
            consumed_approvals.add(wrong)
            non_roundtrip.append(
                {
                    "source": wrong,
                    "traditional_wrong": tw,
                    "traditional_right": tr,
                    "reason": entry["reason"],
                    "approval_sha256": digest,
                }
            )
        if tw == wrong and tr != right:
            if wrong in compiled:
                raise BuildError("generated_key_conflict", [wrong])
            script_sensitive[wrong] = {"simplified": right, "traditional": tr}
            continue
        add(wrong, right, wrong, "simplified")
        count = len(compiled)
        add(tw, tr, wrong, "traditional")
        generated += len(compiled) - count
    if set(approved) != consumed_approvals:
        raise BuildError(
            "stale_non_roundtrip_approval", sorted(set(approved) - consumed_approvals)
        )
    # Never restore a quarantined key indirectly through another rule's variant.
    for wrong in review:
        for form in (wrong, converter.traditional(wrong)):
            if form in compiled or form in script_sensitive:
                raise BuildError("review_only_form_reintroduced", [wrong, form])
    # Ordered replacement semantics stay in the runtime. The bundled compiler
    # rejects non-terminal correction values instead of silently reordering rules.
    chains = []
    keys = list(compiled)
    for wrong, right in compiled.items():
        for other in keys:
            if other in right:
                chains.append({"wrong": wrong, "right": right, "triggers": other})
                if len(chains) >= 20:
                    break
        if len(chains) >= 20:
            break
    if chains:
        raise BuildError("correction_target_triggers_another_rule", chains)
    meta = {
        "generator_version": VERSION,
        "source_sha256": source_hash,
        "converter": converter.info,
        "source_rules": len(rules),
        "traditional_added": generated,
        "runtime_rules": len(compiled),
        "duplicate_forms_merged": duplicate_forms,
        "review_only_rules": len(review),
        "script_sensitive_rules": len(script_sensitive),
        "collapsed_traditional_rules": len(collapsed),
    }
    output = {
        "_comment": "自动生成的简繁运行词表，请修改 chinese_homophone_errors.source.json 后运行 build_dictionary.py；不要手改本文件。",
        "_generated": meta,
        "_script_sensitive": script_sensitive,
        **compiled,
    }
    report = {
        "metadata": meta,
        "collapsed_traditional": collapsed,
        "approved_non_roundtrip": non_roundtrip,
        "provenance": provenance,
        "script_sensitive": script_sensitive,
        "notes": [
            "只生成标准 s2t 字形，不穷举港台异体写法。",
            "简繁形式相同则合并；所有输出仍按顺序精确替换，不转换整篇文档。",
            "词表不是语义正确性的证明，语境歧义由当前会话 AI 复核。",
            "同一原串有不同简繁目标时，不进行静态猜测；_script_sensitive 仅提供给 AI 复核。",
        ],
    }
    return output, report


def render(value):
    return (
        json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    ).encode("utf-8")


def build(source_path, converter=None):
    raw = read_regular(source_path, LIMIT)
    converter = converter if converter is not None else Converter()
    return compile_dictionary(loads(raw), converter, sha(raw))


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="仅维护简体源规则，生成并检查简繁运行词表；OpenCC 仅构建时需要。"
    )
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    parser.add_argument("--report", type=Path, default=REPORT)
    action = parser.add_mutually_exclusive_group()
    action.add_argument(
        "--write", action="store_true", help="校验全部通过后写入编译词表及构建报告"
    )
    action.add_argument(
        "--check",
        action="store_true",
        help="确认已生成词表和报告与当前源/引擎一致，不写文件",
    )
    parser.add_argument(
        "--replace",
        action="store_true",
        help="明确允许替换现有编译产物，不允许覆盖源词表",
    )
    args = parser.parse_args(argv)
    try:
        if args.replace and not args.write:
            raise BuildError("replace_requires_write")
        source = args.source.expanduser().absolute()
        output = args.output.expanduser().absolute()
        report_path = args.report.expanduser().absolute()
        paths = (source, output, report_path)
        if len({str(p.resolve()).casefold() for p in paths}) != 3:
            raise BuildError("source_output_report_must_be_distinct")
        for left, right in (
            (source, output),
            (source, report_path),
            (output, report_path),
        ):
            if left.exists() and right.exists() and left.samefile(right):
                raise BuildError("source_output_report_alias")
        table, report = build(source)
        table_raw = render(table)
        report["runtime_sha256"] = sha(table_raw)
        report_raw = render(report)
        if len(table_raw) > LIMIT or len(report_raw) > LIMIT:
            raise BuildError("generated_artifact_over_limit")
        if args.check:
            if (
                read_regular(output, LIMIT) != table_raw
                or read_regular(report_path, LIMIT) != report_raw
            ):
                raise BuildError("generated_artifact_outdated")
            status = "up_to_date"
        elif args.write:
            from file_support import linklike

            from dictionary_releases import dictionary_lock

            with dictionary_lock(source):
                if (
                    sha(read_regular(source, LIMIT))
                    != report["metadata"]["source_sha256"]
                ):
                    raise BuildError("source_changed_during_dictionary_build")
                for target in (output, report_path):
                    if not target.parent.is_dir() or linklike(target.parent):
                        raise BuildError("target_parent_missing_or_link")
                    if target.exists() or target.is_symlink():
                        if (
                            linklike(target)
                            or not target.is_file()
                            or target.stat().st_nlink > 1
                        ):
                            raise BuildError("target_is_link_or_not_regular")
                        if not args.replace:
                            raise BuildError("target_exists_use_replace")
                # Each write is atomic, not a multi-file transaction. The same
                # cooperative lock also protects reviewed dictionary releases.
                atomic_write(output, table_raw, replace=args.replace)
                try:
                    atomic_write(report_path, report_raw, replace=args.replace)
                except Exception:
                    raise BuildError(
                        "runtime_written_report_failed",
                        [
                            {
                                "runtime_sha256": sha(table_raw),
                                "recovery": "rerun same --write --replace; or verify using --check",
                            }
                        ],
                    ) from None
            status = "written"
        else:
            status = "preview"
        result = {
            "status": status,
            **report["metadata"],
            "runtime_sha256": sha(table_raw),
            "collapsed_traditional": report["collapsed_traditional"],
            "approved_non_roundtrip": report["approved_non_roundtrip"],
        }
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as error:
        from file_support import reason

        print(
            json.dumps(
                {
                    "status": "error",
                    "reason": reason(error),
                    "details": getattr(error, "details", []),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
