#!/bin/bash
# deploy-subpath.sh — 子路径部署 + /toc/ 目录页
#
#   1. 检测所有调研 HTML（子目录 index.html + 根目录 index.html）
#   2. 每个报告存档到 /{slug}/ 子路径
#   3. 生成自包含 /toc/ 目录页（搜索、排序、分页、CSV 导出）
#   4. 部署到 Vercel
#
# 用法:
#   bash deploy-subpath.sh                              # 默认 ~/Downloads/pm-rapport/
#   bash deploy-subpath.sh ~/Downloads/my-report/       # 指定目录

set -uo pipefail

TOKEN_FILE="$HOME/.config/opencode/.env"
[ -f "$TOKEN_FILE" ] && set -a && source "$TOKEN_FILE" && set +a
TOKEN=$(grep -s -o 'VERCEL_TOKEN=[^[:space:]]*' "$TOKEN_FILE" | head -1 | cut -d= -f2-)
SCOPE="seigneurtsuis-projects"
PROJECT="shenyang-deploy"
BASE_DIR="${1:-$HOME/Downloads/pm-rapport}"
DEPLOY_DIR="/tmp/pm-rapport-deploy"
PROD_URL="pm.allez.cc.cd"

rm -rf "$DEPLOY_DIR"
mkdir -p "$DEPLOY_DIR/toc"

declare -a REPORT_LIST=()
add_report() {
  local src="$1" slug="$2" name="$3" emoji="$4" tags="$5" date="$6"
  [ -z "$date" ] && date="$TODAY"
  REPORT_LIST+=("$src|$slug|$name|$emoji|$tags|$date")
}

if [ ! -f "$BASE_DIR/index.html" ]; then
  echo "❌ 错误: $BASE_DIR 下缺少 index.html" >&2
  echo "   请先用 bash deploy-report.sh 部署最新报告" >&2
  exit 1
fi

declare -A SEEN_TITLES
TODAY=$(date +%Y-%m-%d)

extract_title() {
  grep -o '<h1[^>]*>[^<]*</h1>' "$1" 2>/dev/null | head -1 | sed 's/<[^>]*>//g' | xargs
}

extract_date() {
  local file="$1"
  local raw=$(grep -oE '(生成日期|📅)[^。<]*' "$file" 2>/dev/null | head -1)
  if [ -n "$raw" ]; then
    local iso=$(echo "$raw" | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}')
    [ -n "$iso" ] && echo "$iso" && return
  fi
  date -r "$file" +%Y-%m-%d 2>/dev/null || echo "$TODAY"
}

# 1. 从子目录检测
for dir in "$BASE_DIR"/*/; do
  [ -f "${dir}index.html" ] || continue
  DIRNAME=$(basename "$dir")
  [[ "$DIRNAME" == "toc" || "$DIRNAME" == ".vercel" ]] && continue
  FILESIZE=$(wc -c < "${dir}index.html")
  [ "$FILESIZE" -lt 1000 ] && continue
  SLUG="$DIRNAME"
  TRIP_NAME=$(grep -o '<h1[^>]*>[^<]*</h1>' "${dir}index.html" 2>/dev/null | head -1 | sed 's/<[^>]*>//g' | xargs)
  [ -z "$TRIP_NAME" ] && TRIP_NAME="$DIRNAME"
  EMOJI=$(echo "$TRIP_NAME" | grep -o '[📋🏢💰🚀📊🔬🎯📈🌍]' | head -1)
  [ -z "$EMOJI" ] && EMOJI="📋"
  DIR_TITLE=$(extract_title "${dir}index.html")
  [ -n "$DIR_TITLE" ] && [ -n "${SEEN_TITLES[$DIR_TITLE]:-}" ] && echo "  ⏭️  跳过重复: $DIRNAME" && continue
  ALREADY=0
  for entry in "${REPORT_LIST[@]}"; do
    E_SLUG=$(echo "$entry" | cut -d'|' -f2)
    [ "$E_SLUG" == "$SLUG" ] && ALREADY=1 && break
  done
  [ $ALREADY -eq 1 ] && continue
  DIR_DATE=$(extract_date "${dir}index.html")
  add_report "$DIRNAME/index.html" "$SLUG" "$TRIP_NAME" "$EMOJI" "" "$DIR_DATE"
  [ -n "$DIR_TITLE" ] && SEEN_TITLES[$DIR_TITLE]="$SLUG"
  echo "📋 /$SLUG/ → $TRIP_NAME ($EMOJI) [dir]"
done

# 2. 从根目录扁平 HTML 检测
for f in "$BASE_DIR"/*.html; do
  [ -f "$f" ] || continue
  BASENAME=$(basename "$f")
  [[ "$BASENAME" == "index.html" ]] && continue
  [[ "$BASENAME" == "index-"* ]] && continue
  FILESIZE=$(wc -c < "$f")
  [ "$FILESIZE" -lt 1000 ] && continue

  SLUG="report-$(basename "$f" .html | md5 | head -c 6)"
  TRIP_NAME=$(basename "$f" .html)
  FILE_TITLE=$(extract_title "$f")
  [ -n "$FILE_TITLE" ] && TRIP_NAME="$FILE_TITLE"
  EMOJI=$(echo "$TRIP_NAME" | grep -o '[📋🏢💰🚀📊🔬🎯📈🌍]' | head -1)
  [ -z "$EMOJI" ] && EMOJI="📋"

  [ -n "$FILE_TITLE" ] && [ -n "${SEEN_TITLES[$FILE_TITLE]:-}" ] && echo "  ⏭️  跳过重复: $BASENAME" && continue
  ALREADY=0
  for entry in "${REPORT_LIST[@]}"; do
    E_SLUG=$(echo "$entry" | cut -d'|' -f2)
    [ "$E_SLUG" == "$SLUG" ] && ALREADY=1 && break
  done
  [ $ALREADY -eq 1 ] && continue
  FILE_DATE=$(extract_date "$f")
  add_report "$BASENAME" "$SLUG" "$TRIP_NAME" "$EMOJI" "" "$FILE_DATE"
  [ -n "$FILE_TITLE" ] && SEEN_TITLES[$FILE_TITLE]="$SLUG"
  echo "📋 /$SLUG/ → $TRIP_NAME ($EMOJI) [file]"
done

echo ""
echo "📊 共 ${#REPORT_LIST[@]} 个项目调研"

# 3. 复制到子路径
echo ""
echo "📦 准备子路径..."
for entry in "${REPORT_LIST[@]}"; do
  IFS='|' read -r SRC SLUG TRIP_NAME EMOJI TAGS <<< "$entry"
  mkdir -p "$DEPLOY_DIR/$SLUG"
  cp "$BASE_DIR/$SRC" "$DEPLOY_DIR/$SLUG/index.html"
  echo "  📁 $SLUG/ → $TRIP_NAME"
done

# 4. 生成 /toc/ 目录页
echo ""
echo "📄 生成 /toc/ 目录页..."
TODAY=$(date +%Y-%m-%d)

REPORTS_JSON="["
FIRST=1
for entry in "${REPORT_LIST[@]}"; do
  IFS='|' read -r SRC SLUG TRIP_NAME EMOJI TAGS ENTRY_DATE <<< "$entry"
  [ -z "$ENTRY_DATE" ] && ENTRY_DATE="$TODAY"
  [ $FIRST -eq 0 ] && REPORTS_JSON+=","
  FIRST=0
  CLEAN_TITLE=$(echo "$TRIP_NAME" | sed 's/"/\\"/g' | sed "s/'/\\\\'/g")
  REPORTS_JSON+="{\"slug\":\"$SLUG\",\"title\":\"$CLEAN_TITLE\",\"date\":\"$ENTRY_DATE\",\"tags\":\"$TAGS\",\"emoji\":\"$EMOJI\",\"title_lower\":\"$(echo "$CLEAN_TITLE" | tr '[:upper:]' '[:lower:]')\"}"
done
REPORTS_JSON+="]"

# 生成 toc/index.html
cat > "$DEPLOY_DIR/toc/index.html" << 'TOCEOF'
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>📋 项目调研目录</title>
<style>
  * { box-sizing: border-box; }
  body {
    margin: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif;
    background: #0a1929; color: #e0e0e0; line-height: 1.6;
    min-height: 100vh; display: flex; flex-direction: column; align-items: center;
    padding: 40px 20px;
  }
  .header { text-align: center; margin-bottom: 32px; }
  .header h1 {
    font-size: 28px; margin: 0 0 8px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  }
  .header p { color: #90a4ae; font-size: 14px; margin: 0; }
  .toolbar {
    display: flex; flex-wrap: wrap; gap: 10px; align-items: center;
    max-width: 960px; width: 100%; margin-bottom: 20px;
  }
  .search-wrapper {
    flex: 1; min-width: 200px; display: flex; align-items: center; position: relative;
  }
  .search-box {
    width: 100%; padding: 10px 36px 10px 14px; border-radius: 8px;
    border: 1px solid rgba(255,255,255,0.12); background: rgba(255,255,255,0.05);
    color: #e0e0e0; font-size: 14px; outline: none;
  }
  .search-box:focus { border-color: #667eea; }
  .search-box::placeholder { color: #546e7a; }
  .clear-btn {
    position: absolute; right: 8px; top: 50%; transform: translateY(-50%);
    width: 22px; height: 22px; border-radius: 50%; border: none;
    background: rgba(255,255,255,0.1); color: #90a4ae; font-size: 12px;
    cursor: pointer; display: none; align-items: center; justify-content: center;
    line-height: 1; padding: 0; transition: all .15s;
  }
  .clear-btn:hover { background: rgba(255,255,255,0.2); color: #e0e0e0; }
  .clear-btn.visible { display: flex; }
  .sort-btn {
    padding: 8px 14px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.12);
    background: rgba(255,255,255,0.05); color: #b0bec5; font-size: 13px;
    cursor: pointer; transition: all .2s; white-space: nowrap;
  }
  .sort-btn:hover { background: rgba(255,255,255,0.08); color: #e0e0e0; }
  .sort-btn.active { background: rgba(102,126,234,0.15); color: #a5b4fc; border-color: rgba(102,126,234,0.3); }
  .export-btn {
    padding: 8px 14px; border-radius: 8px; border: 1px solid rgba(245,158,11,0.25);
    background: rgba(245,158,11,0.08); color: #fbbf24; font-size: 13px; font-weight: 600;
    cursor: pointer; transition: all .2s; white-space: nowrap;
  }
  .export-btn:hover { background: rgba(245,158,11,0.18); }
  .result-info { color: #546e7a; font-size: 12px; margin-bottom: 8px; max-width: 960px; width: 100%; }
  .grid {
    display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 16px; max-width: 960px; width: 100%;
  }
  .card {
    display: block; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08);
    border-radius: 12px; padding: 20px; text-decoration: none; color: inherit;
    transition: all .2s;
  }
  .card:hover {
    background: rgba(102,126,234,0.08); border-color: rgba(102,126,234,0.3);
    transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,0.3);
  }
  .card.hidden { display: none; }
  .card-title { font-size: 16px; font-weight: 600; color: #c7d2fe; margin-bottom: 6px; }
  .card-meta { font-size: 12px; color: #546e7a; }
  .empty { color: #546e7a; font-size: 14px; text-align: center; padding: 40px; grid-column: 1/-1; display: none; }
  .empty.show { display: block; }
  .pagination {
    display: flex; justify-content: center; align-items: center; gap: 6px;
    margin-top: 24px; max-width: 960px; width: 100%; flex-wrap: wrap;
  }
  .page-btn {
    padding: 8px 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.12);
    background: rgba(255,255,255,0.05); color: #b0bec5; font-size: 13px;
    cursor: pointer; transition: all .2s; min-width: 36px; text-align: center;
  }
  .page-btn:hover { background: rgba(255,255,255,0.08); color: #e0e0e0; }
  .page-btn.active { background: rgba(102,126,234,0.15); color: #a5b4fc; border-color: rgba(102,126,234,0.3); }
  .page-btn:disabled { opacity: 0.3; cursor: not-allowed; }
  .page-info { color: #546e7a; font-size: 13px; padding: 0 2px; letter-spacing: 2px; }
  .footer { margin-top: 48px; text-align: center; color: #455a64; font-size: 12px; }
  .footer a { color: #667eea; text-decoration: none; }
  .footer a:hover { text-decoration: underline; }
  @media (max-width: 640px) {
    body { padding: 20px 12px; }
    .header h1 { font-size: 22px; }
    .grid { grid-template-columns: 1fr; gap: 12px; }
    .card { padding: 16px; }
    .card-title { font-size: 15px; }
    .search-wrapper { min-width: 100%; }
    .search-box { font-size: 16px; }
    .pagination { gap: 4px; }
    .page-btn { padding: 8px; min-width: 34px; font-size: 13px; }
  }
</style>
</head>
<body>
  <div class="header">
    <h1>📋 项目调研目录</h1>
    <p>系统化市场调研 · 商业分析 · pm-rapport</p>
  </div>
  <div class="toolbar">
    <div class="search-wrapper">
      <input type="text" class="search-box" id="searchBox" placeholder="🔍 搜索项目...">
      <button class="clear-btn" id="clearBtn">✕</button>
    </div>
    <button class="sort-btn active" data-sort="date-desc">最新优先</button>
    <button class="sort-btn" data-sort="date-asc">最早优先</button>
    <button class="sort-btn" data-sort="name-asc">名称 A→Z</button>
    <button class="export-btn" id="exportBtn">📊 导出CSV</button>
  </div>
  <div class="result-info" id="resultInfo"></div>
  <div class="grid" id="grid">
    <div class="empty" id="emptyMsg">未找到匹配的项目</div>
  </div>
  <div class="pagination" id="pagination"></div>
  <div class="footer">
    <p>pm-rapport · 系统化市场调研 · 商业分析</p>
    <p style="margin-top:8px;"><a href="/">返回最新报告</a></p>
  </div>

<script>
const REPORTS_DATA = __REPORTS_JSON__;
const PAGE_SIZE = 12;
let currentSort = 'date-desc';
let currentPage = 1;
let allCards = [];

const grid = document.getElementById('grid');
const searchBox = document.getElementById('searchBox');
const clearBtn = document.getElementById('clearBtn');
const pagination = document.getElementById('pagination');
const resultInfo = document.getElementById('resultInfo');
const emptyMsg = document.getElementById('emptyMsg');
const emptyMsgEl = emptyMsg;

function createCards() {
  const fragment = document.createDocumentFragment();
  REPORTS_DATA.forEach(r => {
    const a = document.createElement('a');
    a.href = '/' + r.slug + '/';
    a.target = '_blank';
    a.rel = 'noopener';
    a.className = 'card';
    a.dataset.title = r.title;
    a.dataset.date = r.date;
    a.dataset.slug = r.slug;
    a.dataset.tags = r.tags || '';
    a.innerHTML = '<div class="card-title">' + (r.emoji || '📋') + ' ' + escapeHtml(r.title) + '</div><div class="card-meta">📅 ' + r.date + ' · 🔗 /' + r.slug + '/</div>';
    fragment.appendChild(a);
  });
  grid.insertBefore(fragment, emptyMsgEl);
  allCards = Array.from(grid.querySelectorAll('.card'));
}

function escapeHtml(s) {
  const d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
}

function getCards() {
  const q = searchBox.value.trim().toLowerCase();
  let cards = allCards;
  if (q) {
    cards = cards.filter(c => {
      const title = c.dataset.title || '';
      const slug = c.dataset.slug || '';
      return title.toLowerCase().includes(q) || slug.includes(q);
    });
  }
  cards.sort((a, b) => {
    switch (currentSort) {
      case 'date-desc': return (b.dataset.date || '').localeCompare(a.dataset.date || '');
      case 'date-asc': return (a.dataset.date || '').localeCompare(b.dataset.date || '');
      case 'name-asc': return (a.dataset.title || '').localeCompare(b.dataset.title || '');
      default: return 0;
    }
  });
  return cards;
}

function render() {
  const q = searchBox.value.trim();
  clearBtn.classList.toggle('visible', q.length > 0);
  const filtered = getCards();
  const total = filtered.length;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  if (currentPage > totalPages) currentPage = totalPages;
  const start = (currentPage - 1) * PAGE_SIZE;
  const end = start + PAGE_SIZE;
  // Reorder DOM to match the sorted/filtered order
  grid.removeChild(emptyMsgEl);
  filtered.forEach(function(c) { grid.appendChild(c); });
  grid.appendChild(emptyMsgEl);
  // Show/hide based on current page
  allCards.forEach(c => c.classList.add('hidden'));
  filtered.slice(start, end).forEach(c => c.classList.remove('hidden'));
  emptyMsgEl.classList.toggle('show', total === 0);
  resultInfo.textContent = total > 0 ? '显示 ' + (start + 1) + '-' + Math.min(end, total) + ' / 共 ' + total + ' 个项目' : '';
  renderPagination(totalPages);
}

function renderPagination(totalPages) {
  if (totalPages <= 1) { pagination.innerHTML = ''; return; }
  let html = '';
  const p = currentPage;
  html += '<button class="page-btn" data-page="prev"' + (p === 1 ? ' disabled' : '') + '>‹</button>';
  for (let i = 1; i <= totalPages; i++) {
    const isEdge = i === 1 || i === totalPages;
    const near = Math.abs(i - p) <= 1;
    if (isEdge || near) {
      html += '<button class="page-btn' + (i === p ? ' active' : '') + '" data-page="' + i + '">' + i + '</button>';
    } else if (i < p && !(i+1 < p)) {
      html += '<span class="page-info">…</span>';
    }
  }
  html += '<button class="page-btn" data-page="next"' + (p === totalPages ? ' disabled' : '') + '>›</button>';
  pagination.innerHTML = html;
}

document.getElementById('exportBtn').addEventListener('click', function() {
  var headers = ['序号', '项目', '日期', '链接'];
  var rows = REPORTS_DATA.map(function(t, i) {
    return [i + 1, t.title, t.date, 'https://pm.allez.cc.cd/' + t.slug + '/'];
  });
  var csv = headers.join(',') + '\n';
  rows.forEach(function(r) { csv += r.map(function(v) { return '"' + String(v).replace(/"/g, '""') + '"'; }).join(',') + '\n'; });
  var blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
  var a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = '项目调研目录.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(a.href);
});

var searchTimer;
searchBox.addEventListener('input', function() {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(function() { currentPage = 1; render(); }, 200);
});

clearBtn.addEventListener('click', function() {
  searchBox.value = '';
  clearBtn.classList.remove('visible');
  currentPage = 1;
  render();
  searchBox.focus();
});

document.querySelectorAll('.sort-btn').forEach(function(btn) {
  btn.addEventListener('click', function() {
    document.querySelectorAll('.sort-btn').forEach(function(b) { b.classList.remove('active'); });
    btn.classList.add('active');
    currentSort = btn.dataset.sort;
    currentPage = 1;
    render();
  });
});

pagination.addEventListener('click', function(e) {
  var btn = e.target.closest('.page-btn');
  if (!btn || btn.disabled) return;
  if (btn.dataset.page === 'prev') currentPage--;
  else if (btn.dataset.page === 'next') currentPage++;
  else currentPage = parseInt(btn.dataset.page, 10);
  render();
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

createCards();
render();
</script>
</body>
</html>
TOCEOF

# 5. 替换 JSON 数据
python3 << PYEOF
with open('$DEPLOY_DIR/toc/index.html', 'r') as f:
    content = f.read()
json_data = '$REPORTS_JSON'
content = content.replace('__REPORTS_JSON__', json_data)
with open('$DEPLOY_DIR/toc/index.html', 'w') as f:
    f.write(content)
print('✅ /toc/index.html generated')
PYEOF

# 6. 同步根页面
if [ -f "$BASE_DIR/index.html" ]; then
  cp "$BASE_DIR/index.html" "$DEPLOY_DIR/index.html"
  echo "  ✅ 根页面 index.html 已同步"
else
  echo "  ⚠️  根 index.html 不存在"
fi

# 7. 部署到 Vercel
echo ""
echo "📤 部署到 Vercel..."
cd "$DEPLOY_DIR"
vercel deploy . --prod --token "$TOKEN" --scope "$SCOPE" --project "$PROJECT" -y 2>&1

cd /
rm -rf "$DEPLOY_DIR"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🎉 全部完成！"
echo "  🌐 https://$PROD_URL"
echo "  📂 目录页: https://$PROD_URL/toc/"
echo "  📊 共 ${#REPORT_LIST[@]} 个项目调研存档"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
