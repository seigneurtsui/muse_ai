#!/usr/bin/env node
/**
 * chat.mjs — Text chat / prompt expansion via Agnes AI
 *
 * Useful for expanding a brief idea into a detailed prompt for image/video generation.
 *
 * Usage:
 *   node chat.mjs --prompt "a cat walking on a beach at sunset, cinematic"
 *
 * Options:
 *   --prompt   Input text (required)
 *   --model    Model name (default: agnes-2.0-flash)
 *   --system   System prompt (optional)
 */

import { chat } from './agnes.mjs';

function parseArgs() {
  const args = {};
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i++) {
    if (argv[i].startsWith('--')) {
      const key = argv[i].slice(2);
      if (i + 1 < argv.length && !argv[i + 1].startsWith('--')) {
        args[key] = argv[i + 1];
        i++;
      } else {
        args[key] = true;
      }
    }
  }
  return args;
}

async function main() {
  const opts = parseArgs();

  if (!opts.prompt) {
    console.error('Usage: node chat.mjs --prompt "your message"');
    process.exit(1);
  }

  const model = opts.model || 'agnes-2.0-flash';
  const result = await chat({ prompt: opts.prompt, model });

  const msg = result.choices?.[0]?.message?.content;
  if (!msg) {
    console.error('Empty response:', JSON.stringify(result, null, 2));
    process.exit(1);
  }

  console.log(msg);
}

main().catch(err => {
  console.error(err.message);
  process.exit(1);
});
