# 使用与配置参考

## 1. 输入、输出与兼容性

```bash
STUDIO="$HOME/.config/omnirush/skills/srt-ass-studio/scripts/srt_ass.py"
python3 "$STUDIO" /path/a.srt /path/b.SRT
python3 "$STUDIO" /path/subtitles --recursive
python3 "$STUDIO" '/path/subtitles/*.srt' --output-root /path/results
```

- `.srt` 扩展名大小写不敏感；文件路径去重；递归默认关闭；生成目录自动排除，避免重复处理上次输出。
- 支持 UTF-8/BOM、带 BOM 的 UTF-16、GB18030。无法解码时报错，不用替代字符静默损坏字幕。
- 严格解析 `HH:MM:SS,mmm` 或小数点形式，保留原序号、原始顺序、毫秒起止与内部多行；缺省序号时才补顺序号。
- 非法块、重复序号、空文本、时间倒置会令该源文件失败，不默默跳过。重叠时间允许但计入报告。带坐标扩展的非标准 SRT 时间行需先规范化。
- `--offset-ms` 可整体平移时间轴；任何负起点都报错。不会自动改语速或重新对齐。
- 不改变原输入。每批目录、每个源文件的子目录均唯一；产物先在私有临时目录生成，所有语言完成后再提交。
- 原文 SRT 保留文本，ASS 统一样式时去掉常见 `<b>/<i>/<u>/<font>` 等格式标签并解码实体。不保留原 HTML 的逐词格式。
- 为阻止 ASS 指令注入，正文里的 ASCII `{ } \\` 显示为对应全角字符；只有生成器能产生 ASS 覆盖标签。未知 HTML 样式不作为代码执行。
- 单输入文件上限 32 MiB。大量/超长文件可降低 `--workers`，减小内存峰值。

默认目录：

```text
~/Downloads/srt_ass_studio/<时间戳_唯一后缀>/
├── report.json
└── <源文件名_路径指纹>/
    ├── source.en.srt
    ├── source.en.ass
    ├── en.srt
    ├── en.ass
    └── highlight_keywords.txt   # 有高亮词时才生成
```

这里的 `source.en` 表示两种语言合并；没有翻译时输出 `source.srt` / `source.ass`。只指定 `--separate-languages` 时只输出对应单语文件。报告含路径、计数、错误类别、模型元数据与缓存统计，不记录原始提示词、服务响应或密钥。

## 2. 样式预设和特效

| `--preset` | 风格 |
|---|---|
| `clean` | 简洁静态字幕，细描边 |
| `cinematic`（默认） | 暖白主字幕、浅灰蓝次字幕、渐入渐出 |
| `pop` | 加粗大字、从 75% 缩放弹入、金色关键词 |
| `neon` | 青色主字、模糊渐显、双层柔光描边 |
| `karaoke` | 按字幕时长估算逐词/字颜色填充 |
| `vertical` | 1080×1920、窄行折叠、安全底边、向上滑入 |

`--effect` 覆盖预设的动画：

| 效果 | ASS 实现 |
|---|---|
| `static` | 固定位置，无淡入淡出 |
| `fade` | `\\fad` |
| `slide-up` / `slide-down` | 从下/上方移动到目标位置 |
| `slide-left` / `slide-right` | 从右/左侧移动到目标位置 |
| `pop` | 缩放变换 `\\t` |
| `blur` | 从模糊到清晰的 `\\blur` 变换 |
| `karaoke` | `\\kf`，分配总时长恰好等于量化后字幕时长 |
| `typewriter` | 为词/字附加透明度变换；每条字幕仍是单事件，不膨胀成数百事件 |

原脚本 `slide-bottom`、`slide-top` 作为 `slide-up`、`slide-down` 别名保留。方向与 `--position` 独立，不再因为放在顶部而反向滑动。

**卡拉 OK 和打字机没有读取音频，不能承诺逐词与语音同步。** 卡拉 OK 的填充前颜色由 `karaoke_color` 控制，与双语次字幕颜色独立。

### 常用样式选项

```bash
python3 "$STUDIO" /path/a.srt --preset cinematic \
  --font-name 'PingFang SC' --font-size 70 \
  --secondary-font Arial --secondary-size 44 \
  --primary-color FFF4DC --secondary-color DCE6F0 \
  --outline 3 --shadow 1 --position bottom \
  --margin-x 90 --margin-y 70 --wrap 24
```

- 第一种语言使用 `font_name/font_size/primary_color`，第二种使用 `secondary_font/secondary_size/secondary_color`。按指定语言顺序排版，不基于汉字检测交换上下行。
- `--width` / `--height`：ASS PlayRes；这不是自动检测视频分辨率。按目标视频画幅选择。
- `--position bottom|top|center`：底部/顶部/居中。`margin_y` 为从边缘到字幕锚点的距离。
- `--wrap`：以中文字宽为参考的软折行阈值，拉丁文本尽量按空格折行；`0` 关闭此额外阈值，但仍按画面安全宽度折行。
- 多行过高会缩小字号至 `--min-font-size`（默认 16），还装不下则报错，不截断文字。
- `--animation-ms`、`--fade-in-ms`、`--fade-out-ms`：动画时长（毫秒），会限制在当前字幕有效时间内。
- `--bold` / `--no-bold`；`--outline`、`--shadow`、`--glow` 可自定义。
- 字宽使用 Unicode/CJK 宽度近似，不是精确字体测量。合字、阿拉伯文、复杂表情、特殊字体仍需视觉检查。
- 不嵌入/安装字体，也不复制用户的字体文件。默认 Arial，中文依赖渲染器字体回退；macOS 可显式用 `PingFang SC`，Linux 常用已安装的 `Noto Sans CJK SC`。字体名称不允许逗号/反斜杠/控制字符，防止 ASS 格式注入。

### 自定义样式 JSON

参数优先级：**内置基础值 → 预设 → `--style-json` → 命令行样式选项**。未知字段拒绝，避免拼错仍假装生效。

```json
{
  "width": 1920,
  "height": 1080,
  "font_name": "PingFang SC",
  "font_size": 72,
  "secondary_font": "Arial",
  "secondary_size": 46,
  "effect": "pop",
  "primary_color": "FFFFFF",
  "secondary_color": "DCE6F0",
  "karaoke_color": "687080",
  "outline_color": "101018",
  "back_color": "80000000",
  "outline": 3,
  "shadow": 1,
  "glow": 0,
  "bold": true,
  "position": "bottom",
  "margin_x": 90,
  "margin_y": 80,
  "wrap": 24,
  "min_font_size": 16,
  "animation_ms": 260,
  "fade_in_ms": 180,
  "fade_out_ms": 140,
  "highlight_color": "FFD166",
  "highlight_scale": 1.15,
  "highlight_font": "",
  "overlay_text": "",
  "overlay_interval": 300,
  "overlay_duration": 6
}
```

```bash
python3 "$STUDIO" /path/subtitles --style-json /path/my-style.json
```

颜色接受 `RRGGBB`、`AARRGGBB` 或原生 `&HAABBGGRR`。RGB 输入正确转换成 ASS 的 BGR；8 位前缀 AA 是 **ASS 透明度**，`00` 不透明、`FF` 全透明，与 CSS alpha 意义相反。

## 3. 关键词与订阅提示

```bash
python3 "$STUDIO" /path/a.srt \
  --highlight '关键概念' --highlight 'New York' \
  --highlight-keyword-file /path/keywords.txt \
  --highlight-color FFA500 --highlight-scale 1.15 \
  --highlight-font 'PingFang SC' --highlight-ignore-case
```

词文件每行一词，空行和 `#` 注释忽略，支持与字幕相同编码。字面匹配，不把关键词当正则表达式。去重后长词优先，在每条渲染行内找非重叠匹配；跨自动折行边界的短语可能无法作为整体高亮。每个渲染任务只编译一次关键词表达式。高亮结束只恢复局部字体/字号/颜色，不用 `\\r` 重置位置和动画。

`--ai-highlight` 显式启用 OmniRush 提词。对最终各语言的可见字幕提词，而非只对翻译前原文提词；超过 12000 字符会均匀抽样。只接受真的出现在字幕中的关键词。默认最多 40 个，`--max-keywords 80` 可调整，最终人工+AI 总词数最多 1000。

叠加提示默认关闭：

```bash
python3 "$STUDIO" /path/a.srt \
  --overlay-text '欢迎订阅' --overlay-interval 300 --overlay-duration 6
```

右上角位置基于当前画布和边距，不硬编码 1920。首次出现在一个间隔之后；尾部按字幕总时长裁剪。`--subscribe-overlay` 是使用默认“欢迎订阅”文本的兼容开关；`--no-subscribe-overlay` 可强制关闭。

## 4. AI 翻译与质量校验

详见 [ai.md](ai.md)。使用当前 CLI 内置服务，零额外 AI Key；默认继承 `OMNIRUSH_MODEL` 和现有登录。不会加载原脚本的 `Provider` 列表，不存在跨服务 fallback，也没有 `--insecure-ssl`。

```bash
python3 "$STUDIO" /path/subtitles --languages source,en --separate-languages en
python3 "$STUDIO" /path/subtitles --languages zh-Hant,fr --separate-languages en,ja
```

- `--languages`：1–2 种合并语言。`source` 保留原文；任意 BCP-47 风格目标代码可交给模型，质量取决于模型。
- `--separate-languages`：1–16 种独立语言。
- 同一语言同时用于合并/独立输出，只翻译一次；完整相同的请求可在多个文件之间复用。
- `--source-language` 只在确知原文语言时设置。不根据“多数行是中文”猜测并把英文漏过翻译。
- 必须返回完整条数、显式整数索引、非空文本；允许响应顺序不同但按索引恢复。缺行/重复/越界/明显未翻译等失败时，不输出半套双语。
- 清除模型无依据添加的末尾省略号，保留原文已有的省略号；数字字幕不会因为看起来像序号被丢弃。
- `--normalize-chinese auto`：中文译文有 OpenCC 时再转换并验证转换稳定；缺少时报告未验证。`strict` 缺 OpenCC 即失败；`off` 关闭后处理。字形稳定不等于语义质量认证。
- 已明确 `--source-language zh-Hans` 且安装 OpenCC 时，转 `zh-Hant` 可完全本地完成；这只做字形转换，不冒充翻译其他语言。

资源控制：

| 参数 | 默认 | 范围/用途 |
|---|---:|---|
| `--workers` | 4 | 1–16 个文件任务 |
| `--ai-workers` | 1 | 1–4 个模型请求并发；独立客户端，避免共享会话状态 |
| `--batch-size` | 32 | 每次最多 1–200 条字幕 |
| `--batch-chars` | 6000 | 每批文本字符预算，100–30000；超长单条需明确增大或手动拆分 |
| `--ai-timeout` | 180 | 每次调用总时限，1–3600 秒 |
| `--ai-attempts` | 1 | 1–3 次显式尝试；可能增加计费，仍使用同一服务/模型 |
| `--cache-dir` | 关闭 | 显式开启私有持久缓存，目录需 700，文件 600 |

持久缓存键包含模型、提示词版本/指令、语言及来源文本，不把不同语言/模型混用。缓存读取后仍校验结构；文件损坏可重新生成。模型身份未知时拒绝开启持久缓存。缓存是本地敏感翻译文本，应由用户决定保留时间；没有全局共享缓存或自动上传。

## 5. 可选通知

```bash
python3 "$STUDIO" /path/subtitles --notify-channels bark,telegram --notify-when always
python3 "$STUDIO" /path/subtitles --notify-channels qq_email --notify-when failure
python3 "$STUDIO" /path/subtitles --notify-all --notify-dry-run
```

仅显式启用后，转换结束才调用兄弟技能的 `scripts/notify.py`。先执行通知 `dry-run`，通过后才发送；总开关关闭时保持关闭。通知只含数量统计，不含文件名、路径和字幕正文。凭据仍由 `multiple-channel-notifier` 的 `config.json` 与 `~/.config/omnirush/.env` 管理。

`--notify-dry-run` 只关闭真实通知，**不关闭转换和 AI**；要对整项任务演练应使用 `--dry-run`。通知超时可能已投递，不自动重发。`accepted` 只代表通知服务接受，非最终送达。

## 6. 播放与 FFmpeg 预览

VLC/mpv 等支持 ASS 的播放器可加载输出字幕。安装了 FFmpeg 且包含 libass 时，可将**合成背景**渲染为预览，不修改任何视频：

```bash
# 在生成的源文件子目录运行；文件名不含路径转义，便于 FFmpeg filter 解析
ffmpeg -hide_banner -f lavfi -i 'color=c=0x182432:s=1920x1080:d=4' \
  -vf 'ass=source.en.ass' -ss 1.5 -frames:v 1 preview.png
```

预览时间必须落在某条字幕时间内。实际烧录视频需要用户另行授权，输出新文件并保留原视频。Web 播放器/移动端若不支持 ASS，不能保证所有动画效果。

## 7. 与原脚本的重要差异

- 移除全局关闭 TLS 验证、第三方 HTTP provider、`curl_cffi` 和外置 AI 服务密钥。
- 默认原文转换就能工作，不强制提供目标语言或 AI 配置。
- 修复 RGB/ASS 颜色通道、浮点时间截断、第一种语言不是中文时的双语逻辑、多行丢弃，以及 `\\r` 误清动画的问题。
- 用结构化 cue 和语言矩阵直接生成 ASS，不把已合并多语 SRT 再按前两行猜语言。
- 合并/独立语言共用结果，文件并发、受限 AI 并发、请求去重、可选持久缓存。
- 订阅提示和 AI 提词不再默认开启；未知输入/模型失败不静默忽略。
- 动态显示仍是字幕级/估算逐词效果，没有增加音频识别、精准卡拉 OK 对齐或视频重编码依赖。
