#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { sendSmtpEmail } = require(path.resolve(__dirname, '..', '..', 'smtp-email', 'index.js'));

const DEFAULT_RETRIES = 2;
const MAX_RETRIES = 4;
const DEFAULT_RETRY_DELAY_MS = 1_000;
const MAX_RETRY_DELAY_MS = 10 * 60 * 1_000;

function usage() {
  return 'Usage: node send_report.cjs --html report.html --text report.md --subject "主题" [--to recipient@example.com] [--retries n] [--retry-delay-ms n] [--status-file path]';
}

function value(argv, index, option) {
  const result = argv[index + 1];
  if (!result || result.startsWith('--')) throw new Error(`${option} requires a value\n${usage()}`);
  return result;
}

function nonNegativeInteger(raw, option, maximum = Number.MAX_SAFE_INTEGER) {
  if (!/^\d+$/.test(raw)) throw new Error(`${option} must be a non-negative integer\n${usage()}`);
  const parsed = Number(raw);
  if (!Number.isSafeInteger(parsed) || parsed > maximum) {
    throw new Error(`${option} is out of range\n${usage()}`);
  }
  return parsed;
}

function parseArgs(argv) {
  const options = {
    to: process.env.TICKET_REPORT_TO || 'gc40800@gmail.com',
    retries: DEFAULT_RETRIES,
    retryDelayMs: DEFAULT_RETRY_DELAY_MS,
  };
  for (let i = 0; i < argv.length; i += 1) {
    switch (argv[i]) {
      case '--html': options.html = value(argv, i, '--html'); i += 1; break;
      case '--text': options.text = value(argv, i, '--text'); i += 1; break;
      case '--subject': options.subject = value(argv, i, '--subject'); i += 1; break;
      case '--to': options.to = value(argv, i, '--to'); i += 1; break;
      case '--retries': options.retries = nonNegativeInteger(value(argv, i, '--retries'), '--retries', MAX_RETRIES); i += 1; break;
      case '--retry-delay-ms': options.retryDelayMs = nonNegativeInteger(value(argv, i, '--retry-delay-ms'), '--retry-delay-ms', MAX_RETRY_DELAY_MS); i += 1; break;
      case '--status-file': options.statusFile = value(argv, i, '--status-file'); i += 1; break;
      case '--help': case '-h': options.help = true; break;
      default: throw new Error(`Unknown argument: ${argv[i]}\n${usage()}`);
    }
  }
  if (options.help) return options;
  for (const key of ['html', 'text', 'subject']) {
    if (!options[key]) throw new Error(`--${key} is required\n${usage()}`);
  }
  return options;
}

function safeErrorMessage(error) {
  // SMTP responses can echo addresses, hosts or auth data. Keep only bounded
  // protocol codes, not free-form messages, in persistent delivery records.
  const allowed = ['EAUTH', 'ECONNECTION', 'ETIMEDOUT', 'ECONNRESET', 'ECONNREFUSED', 'EAI_AGAIN', 'EPARTIAL'];
  const code = allowed.includes(error?.code) ? error.code : 'EMAIL_ERROR';
  const response = Number(error?.responseCode);
  return `${code}${Number.isInteger(response) && response >= 400 && response < 600 ? ` SMTP ${response}` : ''}`;
}

function defaultStatusFile(htmlPath) {
  return `${htmlPath}.send-status.json`;
}

function writeSendRecord(statusFile, record) {
  const directory = path.dirname(statusFile);
  fs.mkdirSync(directory, { recursive: true });
  const temporary = `${statusFile}.tmp-${process.pid}`;
  fs.writeFileSync(temporary, `${JSON.stringify(record, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 });
  fs.renameSync(temporary, statusFile);
  try { fs.chmodSync(statusFile, 0o600); } catch (_) { /* best effort on non-POSIX filesystems */ }
  return statusFile;
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function sendWithRetry({ send = sendSmtpEmail, payload, retries = DEFAULT_RETRIES, retryDelayMs = DEFAULT_RETRY_DELAY_MS, now = () => new Date(), sleep = wait }) {
  const attempts = [];
  const totalAttempts = retries + 1;
  for (let attempt = 1; attempt <= totalAttempts; attempt += 1) {
    const startedAt = now().toISOString();
    try {
      const result = await send(payload);
      if (result?.success === false) throw Object.assign(new Error('Not sent'), { retrySafe: false });
      attempts.push({ attempt, startedAt, status: 'sent', messageId: result?.messageId || null });
      return { success: true, result, attempts };
    } catch (error) {
      const uncertain = !!error.deliveryUncertain;
      const retryable = !uncertain && (error.retrySafe === true || error.responseCode >= 400 && error.responseCode < 500);
      attempts.push({ attempt, startedAt, status: uncertain ? 'unknown' : 'failed', retryable, error: safeErrorMessage(error) });
      if (!retryable) break;
      if (attempt < totalAttempts) {
        const delay = Math.min(retryDelayMs * (2 ** (attempt - 1)), MAX_RETRY_DELAY_MS);
        if (delay > 0) await sleep(delay);
      }
    }
  }
  return { success: false, attempts, error: attempts.at(-1)?.error || 'Email send failed' };
}

async function main(argv = process.argv.slice(2), dependencies = {}) {
  let options;
  try {
    options = parseArgs(argv);
    if (options.help) {
      console.log(usage());
      return 0;
    }
    for (const key of ['html', 'text']) {
      if (!fs.existsSync(options[key])) throw new Error(`File not found: ${options[key]}`);
    }

    const statusFile = options.statusFile || defaultStatusFile(options.html);
    const payload = {
      to: options.to,
      subject: options.subject,
      html: fs.readFileSync(options.html, 'utf8'),
      text: fs.readFileSync(options.text, 'utf8'),
    };
    // Fail before SMTP if the log cannot be persisted. A crash after this
    // marker needs manual verification rather than an unconditional resend.
    writeSendRecord(statusFile, { version: 1, status: 'sending', to: options.to, subject: options.subject });
    const outcome = await sendWithRetry({
      send: dependencies.send || sendSmtpEmail,
      payload,
      retries: options.retries,
      retryDelayMs: options.retryDelayMs,
      now: dependencies.now || (() => new Date()),
      sleep: dependencies.sleep || wait,
    });
    const record = {
      version: 1,
      status: outcome.success ? 'sent' : (outcome.attempts.at(-1)?.status === 'unknown' ? 'unknown' : 'failed'),
      success: outcome.success,
      recordedAt: (dependencies.now || (() => new Date()))().toISOString(),
      to: options.to,
      subject: options.subject,
      attempts: outcome.attempts,
      messageId: outcome.success ? (outcome.result?.messageId || null) : null,
    };
    writeSendRecord(statusFile, record);
    const output = {
      success: record.success,
      status: record.status,
      to: options.to,
      subject: options.subject,
      messageId: record.messageId,
      attempts: record.attempts.length,
      statusFile,
    };
    if (!outcome.success) output.error = outcome.error;
    console.log(JSON.stringify(output, null, 2));
    if (!outcome.success) console.error(`Email send failed after ${record.attempts.length} attempt(s): ${outcome.error}`);
    return outcome.success ? 0 : 1;
  } catch (error) {
    const message = safeErrorMessage(error);
    console.error(`Email send failed: ${message}`);
    console.log(JSON.stringify({ success: false, status: 'unknown', error: message,
      statusFile: options?.statusFile || (options?.html ? defaultStatusFile(options.html) : null) }));
    return 1;
  }
}

if (require.main === module) {
  main().then((code) => { process.exitCode = code; });
}

module.exports = {
  DEFAULT_RETRIES,
  defaultStatusFile,
  main,
  parseArgs,
  safeErrorMessage,
  sendWithRetry,
  writeSendRecord,
};
