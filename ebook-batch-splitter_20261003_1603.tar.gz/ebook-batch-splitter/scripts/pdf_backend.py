"""Local PDF text/OCR extraction. Importing this module performs no I/O.

One canonical page-ordered text stream is independent of the PDF's bookmarks.
No dependency installation, password authentication, or network access is used.
"""
from __future__ import annotations

import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import re
import secrets
import shutil
import stat
import subprocess

if __package__:
    from .models import Boundary, Extracted, SplitError
else:  # The installed CLI executes scripts/split_ebooks.py directly.
    from models import Boundary, Extracted, SplitError

EXTRACTOR_VERSION = "pdf-local-1"
CACHE_SCHEMA = 1
PAGE_SEPARATOR = "\n\f\n"
MAX_RENDER_PIXELS = 12_000_000
MAX_RENDER_SIDE = 6000
MAX_CACHE_PAGE_BYTES = 32 * 1024 * 1024
_LANGUAGE = re.compile(r"[A-Za-z][A-Za-z0-9_]{0,31}(?:\+[A-Za-z][A-Za-z0-9_]{0,31}){0,7}\Z")
_OCR_ERRORS = {"tesseract_missing", "render_failed", "ocr_timeout", "tesseract_failed"}


def _load_fitz():
    for name in ("pymupdf", "fitz"):
        try:
            module = importlib.import_module(name)
            if hasattr(module, "VersionBind") and hasattr(module, "open"):
                return module
        except ImportError:
            pass
    raise SplitError("PDF extraction requires locally installed PyMuPDF; nothing was installed automatically.")


def _chars(text: str) -> int:
    return sum(not char.isspace() for char in text)


def _validate_options(ocr, language, dpi, minimum, timeout):
    if ocr not in ("off", "auto", "force"):
        raise SplitError("PDF OCR mode must be off, auto, or force.")
    if not isinstance(language, str) or not _LANGUAGE.fullmatch(language):
        raise SplitError("OCR language must be installed language codes such as eng or chi_sim+eng (no paths).")
    if type(dpi) is not int or not 72 <= dpi <= 600:
        raise SplitError("PDF OCR DPI must be an integer between 72 and 600.")
    if type(minimum) is not int or not 1 <= minimum <= 100_000:
        raise SplitError("min_page_chars must be an integer between 1 and 100000.")
    if type(timeout) not in (int, float) or not math.isfinite(timeout) or not 0 < timeout <= 3600:
        raise SplitError("PDF OCR timeout must be a finite number in (0, 3600] seconds per page.")


def _signature(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def _fingerprint(path: Path):
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
        with os.fdopen(fd, "rb") as source:
            before = os.fstat(source.fileno())
            if not stat.S_ISREG(before.st_mode):
                raise SplitError("PDF input must be a regular local file.")
            digest = hashlib.sha256()
            for chunk in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(chunk)
            after = os.fstat(source.fileno())
        if _signature(before) != _signature(after):
            raise SplitError("PDF source changed while hashing; retry with an unchanged source.")
        _assert_unchanged(path, _signature(after))
        return digest.hexdigest(), _signature(after)
    except OSError as exc:
        raise SplitError("Cannot read the PDF source file.") from exc


def _assert_unchanged(path: Path, signature):
    try:
        if _signature(path.stat()) != signature:
            raise SplitError("PDF source changed during extraction; retry with an unchanged source.")
    except OSError as exc:
        raise SplitError("PDF source became unavailable during extraction.") from exc


class _PageCache:
    """Private directory-FD based storage: never follow cache symlinks.

    The parent of cache_dir is caller-controlled; symlinks outside cache_dir
    (e.g. macOS /tmp) are allowed. Within the root, all traversal is no-follow.
    """

    def __init__(self, root: Path, key: str, page_count: int):
        self.key = key
        self.page_count = page_count
        self.fd = None
        root_fd = None
        try:
            root = root.absolute()
            root.parent.mkdir(parents=True, exist_ok=True)
            root.mkdir(mode=0o700, exist_ok=True)
            root_fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            self._private_dir(root_fd)
            name = "pdf-" + key
            try:
                os.mkdir(name, mode=0o700, dir_fd=root_fd)
            except FileExistsError:
                pass
            self.fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=root_fd)
            self._private_dir(self.fd)
        except (OSError, ValueError) as exc:
            self.close()
            raise SplitError("PDF cache must be a private writable directory without cache symlinks.") from exc
        finally:
            if root_fd is not None:
                os.close(root_fd)

    @staticmethod
    def _private_dir(fd):
        info = os.fstat(fd)
        if info.st_uid != os.getuid():
            raise ValueError("cache is not owned by the current user")
        os.fchmod(fd, 0o700)

    def close(self):
        if self.fd is not None:
            os.close(self.fd)
            self.fd = None

    def _check_target(self, name):
        try:
            info = os.stat(name, dir_fd=self.fd, follow_symlinks=False)
        except FileNotFoundError:
            return
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.getuid():
            raise SplitError("Unsafe PDF page cache entry (symlink, hard link, or non-private file).")

    def read(self, index, warnings):
        name = f"page-{index:08d}.json"
        self._check_target(name)
        try:
            fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=self.fd)
        except FileNotFoundError:
            return None
        except OSError as exc:
            raise SplitError("Cannot safely read PDF page cache.") from exc
        try:
            with os.fdopen(fd, "rb") as source:
                info = os.fstat(source.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.getuid():
                    raise SplitError("Unsafe PDF page cache entry.")
                os.fchmod(source.fileno(), 0o600)
                payload = source.read(MAX_CACHE_PAGE_BYTES + 1)
            record = json.loads(payload) if len(payload) <= MAX_CACHE_PAGE_BYTES else None
            if not _valid_record(record, self.key, index, self.page_count):
                raise ValueError("invalid cache schema")
            return record
        except SplitError:
            raise
        except (ValueError, UnicodeError, RecursionError):
            warnings.append(f"Ignoring invalid PDF cache for page {index + 1}; extracting it again.")
            return None
        except OSError as exc:
            raise SplitError("Cannot read PDF page cache.") from exc

    def write(self, index, record):
        name = f"page-{index:08d}.json"
        temporary = f".page-{index:08d}-{secrets.token_hex(8)}.tmp"
        self._check_target(name)
        try:
            fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                         0o600, dir_fd=self.fd)
            with os.fdopen(fd, "w", encoding="utf-8") as target:
                json.dump(record, target, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
                target.flush()
                os.fsync(target.fileno())
            self._check_target(name)
            os.replace(temporary, name, src_dir_fd=self.fd, dst_dir_fd=self.fd)
            os.fsync(self.fd)
        except OSError as exc:
            raise SplitError("Cannot atomically write private PDF page cache.") from exc
        finally:
            try:
                os.unlink(temporary, dir_fd=self.fd)
            except FileNotFoundError:
                pass


def _valid_record(record, key, index, page_count):
    if not isinstance(record, dict) or set(record) != {"schema", "key", "page", "page_count", "native", "ocr"}:
        return False
    if (type(record["schema"]) is not int or record["schema"] != CACHE_SCHEMA
            or record["key"] != key or type(record["page"]) is not int or record["page"] != index
            or type(record["page_count"]) is not int or record["page_count"] != page_count):
        return False
    native = record["native"]
    if not isinstance(native, dict) or set(native) != {"text", "chars", "images", "error"}:
        return False
    if (not isinstance(native["text"], str) or type(native["chars"]) is not int
            or native["chars"] != _chars(native["text"])
            or type(native["images"]) is not int or native["images"] < 0
            or native["error"] not in (None, "text_extraction_failed")):
        return False
    if native["error"] and (native["text"] or native["images"]):
        return False
    ocr = record["ocr"]
    if ocr is None:
        return True
    if not isinstance(ocr, dict) or set(ocr) != {"text", "chars", "status", "error", "render"}:
        return False
    if (not isinstance(ocr["text"], str) or type(ocr["chars"]) is not int
            or ocr["chars"] != _chars(ocr["text"]) or ocr["status"] not in ("success", "sparse", "error")):
        return False
    if ocr["status"] == "error":
        return (not ocr["text"] and isinstance(ocr["error"], str)
                and ocr["error"] in _OCR_ERRORS and ocr["render"] is None)
    if ocr["error"] is not None or (ocr["status"] == "success" and ocr["chars"] == 0):
        return False
    render = ocr["render"]
    return (isinstance(render, dict) and set(render) == {"width", "height", "dpi"}
            and type(render["width"]) is int and 0 < render["width"] <= MAX_RENDER_SIDE
            and type(render["height"]) is int and 0 < render["height"] <= MAX_RENDER_SIDE
            and render["width"] * render["height"] <= MAX_RENDER_PIXELS
            and type(render["dpi"]) in (int, float) and math.isfinite(render["dpi"])
            and 0 < render["dpi"] <= 600)


def _extract_native(page, fitz):
    # Share a single parsed TextPage for plain text and *displayed* image info,
    # including inline images. Do not extract image payloads or scan bookmarks.
    textpage = page.get_textpage(flags=fitz.TEXTFLAGS_TEXT | fitz.TEXT_PRESERVE_IMAGES)
    text = page.get_text("text", textpage=textpage)
    images = len(textpage.extractIMGINFO())
    return {"text": text, "chars": _chars(text), "images": images, "error": None}


class _OCRError(Exception):
    pass


def _render_scale(width, height, dpi):
    if not all(math.isfinite(value) and value > 0 for value in (width, height)):
        raise _OCRError("render_failed")
    scale = min(dpi / 72, (MAX_RENDER_SIDE - 3) / max(width, height),
                math.sqrt(MAX_RENDER_PIXELS / width / height))
    # Account for rounded/translated page rectangles before allocating a pixmap.
    while ((math.ceil(width * scale) + 2) * (math.ceil(height * scale) + 2) > MAX_RENDER_PIXELS
           or max(math.ceil(width * scale), math.ceil(height * scale)) + 2 > MAX_RENDER_SIDE):
        scale *= 0.99
    if not math.isfinite(scale) or scale <= 0:
        raise _OCRError("render_failed")
    return scale


def _run_ocr(page, fitz, executable, language, dpi, timeout):
    if not executable:
        raise _OCRError("tesseract_missing")
    try:
        scale = _render_scale(page.rect.width, page.rect.height, dpi)
        pixmap = page.get_pixmap(matrix=fitz.Matrix(scale, scale), colorspace=fitz.csGRAY, alpha=False)
        if (pixmap.width > MAX_RENDER_SIDE or pixmap.height > MAX_RENDER_SIDE
                or pixmap.width * pixmap.height > MAX_RENDER_PIXELS):
            raise _OCRError("render_failed")
        rendering = {"width": pixmap.width, "height": pixmap.height, "dpi": scale * 72}
        image = pixmap.tobytes("png")
        del pixmap
    except _OCRError:
        raise
    except Exception as exc:
        raise _OCRError("render_failed") from exc
    try:
        completed = subprocess.run(
            [executable, "stdin", "stdout", "-l", language, "--dpi", str(max(1, round(scale * 72)))],
            input=image, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout, check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise _OCRError("ocr_timeout") from exc
    except OSError as exc:
        raise _OCRError("tesseract_failed") from exc
    if completed.returncode:
        # stderr can contain private page content; never copy it to warnings/logs.
        raise _OCRError("tesseract_failed")
    return completed.stdout.decode("utf-8", errors="replace"), rendering


def _bookmarks(doc, starts, warnings, information=None):
    information = {} if information is None else information
    information.update(toc_present=False, structure_uncertain=False)
    try:
        raw = doc.get_toc()
        if not isinstance(raw, (list, tuple)):
            raise ValueError("invalid outline")
        information["toc_present"] = bool(raw)
    except Exception:
        information.update(toc_present=True, structure_uncertain=True)
        warnings.append("PDF bookmarks could not be read; full page-ordered text was retained.")
        return []
    boundaries = []
    ancestors = []
    pages_seen = set()
    previous_page = 0
    for toc_index, item in enumerate(raw):
        if not isinstance(item, (list, tuple)) or len(item) < 3:
            information["structure_uncertain"] = True
            warnings.append(f"Ignoring malformed PDF bookmark {toc_index + 1}.")
            continue
        level, title, page = item[:3]
        if type(level) is not int or level < 1:
            information["structure_uncertain"] = True
            warnings.append(f"Ignoring PDF bookmark {toc_index + 1}: invalid level, title, or page range.")
            continue
        while ancestors and ancestors[-1][0] >= level:
            ancestors.pop()
        if (not isinstance(title, str) or not title.strip()
                or type(page) is not int or not 1 <= page <= len(starts)):
            # An invalid destination still starts an outline branch. Do not
            # incorrectly attach its children to the preceding valid volume.
            ancestors.append((level, None))
            information["structure_uncertain"] = True
            warnings.append(f"Ignoring PDF bookmark {toc_index + 1}: invalid level, title, or page range.")
            continue
        if page < previous_page:
            information["structure_uncertain"] = True
            warnings.append(f"PDF bookmark {toc_index + 1} has an out-of-order page position; boundaries are sorted by page.")
        if page in pages_seen:
            warnings.append(f"Multiple PDF bookmarks share page {page}; page-level extraction cannot separate them (no text duplicated).")
        previous_page = page
        pages_seen.add(page)
        boundary = Boundary(position=starts[page - 1], title=title.strip(), level=level,
                            locator={"page": page, "page_index": page - 1, "toc_index": toc_index})
        if ancestors and ancestors[-1][1] is not None:
            ancestors[-1][1].children += 1
        if level > (ancestors[-1][0] + 1 if ancestors else 1):
            information["structure_uncertain"] = True
            warnings.append(f"PDF bookmark {toc_index + 1} skips a hierarchy level; its original level was retained.")
        ancestors.append((level, boundary))
        boundaries.append(boundary)
    return sorted(boundaries, key=lambda boundary: boundary.position)


def extract_pdf(path: Path, *, cache_dir: Path, ocr="off", ocr_language="eng", dpi=150,
                min_page_chars=40, timeout=120) -> Extracted:
    """Extract text exactly once per uncached page; OCR only when explicitly enabled.

    Bookmarks are page-start character offsets, all levels, sorted in page order;
    `children` counts immediate children in the original outline hierarchy.
    Failed/sparse OCR retains best available page text and is retried next run.
    See references/pdf.md for metadata, cache/privacy rules, and limitations.
    """
    _validate_options(ocr, ocr_language, dpi, min_page_chars, timeout)
    path, cache_dir = Path(path), Path(cache_dir)
    fitz = _load_fitz()
    source_hash, signature = _fingerprint(path)
    settings = {"mode": ocr, "language": ocr_language, "dpi": dpi,
                "min_page_chars": min_page_chars, "timeout": timeout, "engine": "local-tesseract-cli"}
    identity = {"source_sha256": source_hash, "extractor": EXTRACTOR_VERSION,
                "pymupdf": fitz.VersionBind, "ocr": settings}
    key = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    try:
        doc = fitz.open(str(path))
    except Exception as exc:
        raise SplitError("Cannot open PDF; it may be invalid, damaged, or unsupported.") from exc
    cache = None
    try:
        _assert_unchanged(path, signature)
        if doc.needs_pass or doc.is_encrypted or (doc.metadata or {}).get("encryption"):
            raise SplitError("Encrypted/authentication-required PDF is unsupported; no password or DRM bypass was attempted.")
        if not doc.is_pdf:
            raise SplitError("The selected source is not a PDF document.")
        cache = _PageCache(cache_dir, key, doc.page_count)
        executable = shutil.which("tesseract") if ocr != "off" else None
        warnings: list[str] = []
        texts, starts, pages = [], [], []
        counts = dict.fromkeys(("cache_hits", "ocr_cache_hits", "native_extraction_calls", "ocr_attempted_pages",
                               "native_text_pages", "ocr_text_pages", "pages_with_text", "sparse_pages",
                               "image_pages", "textless_image_pages", "blank_pages", "text_error_pages",
                               "ocr_success_pages", "ocr_sparse_pages", "ocr_failed_pages", "incomplete_pages"), 0)
        offset = 0
        for index in range(doc.page_count):
            _assert_unchanged(path, signature)
            record = cache.read(index, warnings)
            # Threshold validation is separate from schema validation to prevent
            # a corrupted 'success' label from skipping sparse OCR forever.
            if record and record["ocr"] and record["ocr"]["status"] != "error":
                expected = "success" if record["ocr"]["chars"] >= min_page_chars else "sparse"
                if record["ocr"]["status"] != expected:
                    warnings.append(f"Ignoring inconsistent OCR cache status for PDF page {index + 1}.")
                    record["ocr"] = None
            native_hit = record is not None and record["native"]["error"] is None
            counts["cache_hits"] += int(native_hit)
            page = None
            if not native_hit:
                counts["native_extraction_calls"] += 1
                try:
                    page = doc.load_page(index)
                    native = _extract_native(page, fitz)
                except Exception:
                    native = {"text": "", "chars": 0, "images": 0, "error": "text_extraction_failed"}
                if record is None:
                    record = {"schema": CACHE_SCHEMA, "key": key, "page": index, "page_count": doc.page_count,
                              "native": native, "ocr": None}
                else:
                    record["native"] = native
                _assert_unchanged(path, signature)
                cache.write(index, record)  # Resume even if the next OCR call is interrupted.
            native = record["native"]
            sparse = native["chars"] < min_page_chars
            needs_ocr = ocr == "force" or (ocr == "auto" and
                        (native["error"] is not None or (sparse and (native["chars"] > 0 or native["images"] > 0))))
            result = record["ocr"] if needs_ocr else None
            ocr_hit = result is not None and result["status"] == "success"
            counts["ocr_cache_hits"] += int(ocr_hit)
            if needs_ocr and not ocr_hit:
                counts["ocr_attempted_pages"] += 1
                try:
                    if page is None:
                        page = doc.load_page(index)
                    text, rendering = _run_ocr(page, fitz, executable, ocr_language, dpi, timeout)
                    chars = _chars(text)
                    result = {"text": text, "chars": chars, "status": "success" if chars >= min_page_chars else "sparse",
                              "error": None, "render": rendering}
                except _OCRError as exc:
                    result = {"text": "", "chars": 0, "status": "error", "error": str(exc), "render": None}
                except Exception:
                    result = {"text": "", "chars": 0, "status": "error", "error": "render_failed", "render": None}
                record["ocr"] = result
                _assert_unchanged(path, signature)
                cache.write(index, record)
            chosen, source = native["text"], "native"
            if result and (result["status"] == "success" or result["chars"] > native["chars"]):
                chosen, source = result["text"], "ocr"
            characters = _chars(chosen)
            resolved = result is not None and result["status"] == "success"
            incomplete = bool((native["error"] and not resolved)
                              or (native["images"] and sparse and not resolved)
                              or (result and result["status"] == "error"))
            # Blank pages, small textual ornaments, and successful but sparse
            # OCR without an image are not by themselves extraction failures.
            errors = [error for error in (native["error"], result["error"] if result else None) if error]
            starts.append(offset)
            texts.append(chosen)
            pages.append({"page": index + 1, "start": offset, "characters": characters,
                          "native_characters": native["chars"], "images": native["images"], "source": source,
                          "ocr_status": result["status"] if result else ("off" if ocr == "off" else "not_needed"),
                          "cache_hit": native_hit, "ocr_cache_hit": ocr_hit, "incomplete": incomplete,
                          "errors": errors, "render": result["render"] if result else None})
            offset += len(chosen) + (len(PAGE_SEPARATOR) if index < doc.page_count - 1 else 0)
            counts["native_text_pages"] += int(native["chars"] > 0)
            counts["ocr_text_pages"] += int(source == "ocr" and characters > 0)
            counts["pages_with_text"] += int(characters > 0)
            counts["sparse_pages"] += int(sparse)
            counts["image_pages"] += int(native["images"] > 0)
            counts["textless_image_pages"] += int(native["images"] > 0 and native["chars"] == 0)
            counts["blank_pages"] += int(not native["error"] and not native["images"] and not native["chars"])
            counts["text_error_pages"] += int(native["error"] is not None)
            counts["incomplete_pages"] += int(incomplete)
            if result:
                counts[{"success": "ocr_success_pages", "sparse": "ocr_sparse_pages", "error": "ocr_failed_pages"}[result["status"]]] += 1
        toc_information = {}
        toc = _bookmarks(doc, starts, warnings, toc_information)
        if counts["text_error_pages"]:
            warnings.append(f"Native text extraction failed on {counts['text_error_pages']} PDF page(s); see page metadata for OCR recovery.")
        if counts["ocr_failed_pages"]:
            warnings.append(f"OCR failed on {counts['ocr_failed_pages']} PDF page(s); existing native text was retained. Check local Tesseract/language data and page timeouts.")
        if counts["ocr_sparse_pages"]:
            warnings.append(f"OCR returned sparse text on {counts['ocr_sparse_pages']} PDF page(s); best available text was retained and these pages will be retried.")
        if counts["incomplete_pages"]:
            warnings.append(f"PDF extraction is incomplete or uncertain on {counts['incomplete_pages']} page(s); sparse image pages may be scans or decorative images. Review page metadata; OCR is never enabled implicitly.")
        _assert_unchanged(path, signature)
        text = PAGE_SEPARATOR.join(texts)
        return Extracted(text=text, toc=toc, method="pdf_toc" if toc else "pdf_text", warnings=warnings,
                         metadata={"incomplete": bool(counts["incomplete_pages"]), "page_count": doc.page_count,
                                   "characters": _chars(text), "source_sha256": source_hash, "cache_key": key,
                                   "extractor_version": EXTRACTOR_VERSION, "pymupdf_version": fitz.VersionBind,
                                   "ocr_settings": settings, "pages": pages, **counts, **toc_information})
    finally:
        if cache is not None:
            cache.close()
        doc.close()
