#!/usr/bin/env python3
"""Batch translator adapted from the supplied AI Batch Translator 1.2.0.

Provider HTTP code is replaced by a current-session file handoff. No API keys,
external model SDKs, subprocess model calls, or implicit untranslated fallback.
"""

from __future__ import annotations
import argparse
from datetime import datetime, timezone
from pathlib import Path
import re
import sys
import time
import uuid
from file_support import (
    TranslationError,
    MAX_FILE,
    MAX_BATCH,
    MAX_FILES,
    MAX_OUTPUT,
    SUPPORTED,
    ENCODINGS,
    Document,
    read_regular,
    read_json,
    loads,
    packed,
    sha,
    reason,
    root_path,
    relative_path,
    key,
    linklike,
    mkdir,
    atomic_write,
    write_json,
    job_lock,
    decode,
    encode,
    snapshot_bom,
    collect,
)
from translation_documents import prepare_document, render_document
from current_session_ai import (
    CurrentSessionAI,
    AIRequestPending,
    AIResponseInvalid,
    PROVIDER,
    PROTOCOL_VERSION,
    GUARD,
    translate_with_fallback,
    payload_for,
    request_identity,
    validate_response,
)

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = Path.home() / "Downloads/translator_i18n"
WORKFLOW_VERSION = 1
MAX_TASKS = 2000
MAX_UNITS = 100000
MAX_TOTAL_UNITS = 200000
MAX_SNAPSHOTS = 256 * 1024 * 1024
SNAPSHOT_LIMIT = 128 * 1024 * 1024
DEFAULT_CHUNK_CHARS = 1500
DEFAULT_BATCH_CHARS = 4000
COMPLETED = {"translated", "checked_unchanged", "no_translatable_text"}


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def language_data():
    return read_json(ROOT / "assets/languages.json", 65536)


def canonical_language(value):
    if (
        not isinstance(value, str)
        or not 1 <= len(value.strip()) <= 80
        or any(ord(c) < 32 for c in value)
    ):
        raise TranslationError("invalid_language_name")
    value = value.strip()
    data = language_data()
    aliases = {k.casefold(): v for k, v in data["LANGUAGE_ALIASES"].items()}
    for group in data["LANGUAGE_GROUPS"].values():
        aliases.update({name.casefold(): name for name in group})
    aliases.update(
        {
            "auto": "Auto",
            "自动": "Auto",
            "自动检测": "Auto",
            "zh-hans": "Simplified Chinese",
            "zh-hant": "Traditional Chinese",
            "zh-tw": "Traditional Chinese",
            "zh-hk": "Traditional Chinese",
        }
    )
    if value.casefold() in aliases:
        return aliases[value.casefold()]
    if not all(c.isalpha() or c in " -()" for c in value):
        raise TranslationError("invalid_language_name")
    return value


def slug(value):
    result = re.sub(r"[^a-z0-9_-]+", "_", value.lower().replace(" ", "_")).strip("_")
    if not result:
        result = "language-" + sha(value.encode())[:10]
    if result in {
        "con",
        "prn",
        "aux",
        "nul",
        *(f"com{i}" for i in range(1, 10)),
        *(f"lpt{i}" for i in range(1, 10)),
    }:
        result += "-language"
    return result


def target_languages(values, source):
    targets = []
    for value in values or []:
        for part in value.split(","):
            if not part.strip():
                raise TranslationError("empty_target_language")
            target = canonical_language(part)
            if target == "Auto":
                raise TranslationError("auto_is_source_only")
            if target.casefold() == source.casefold():
                raise TranslationError("target_equals_source_language")
            if target.casefold() not in {x.casefold() for x in targets}:
                targets.append(target)
    if not 1 <= len(targets) <= 12:
        raise TranslationError("require_1_to_12_target_languages")
    if len({slug(t) for t in targets}) != len(targets):
        raise TranslationError("target_language_slug_collision")
    return targets


def output_name(source_name, target):
    p = relative_path(source_name)
    return (
        Path(slug(target))
        / p.parent
        / (p.stem + "." + slug(target) + (p.suffix or ".txt"))
    ).as_posix()


def batch_units(work, max_chars):
    groups = []
    current = []
    chars = 0
    for unit in work["document"]["units"]:
        row = {"id": unit["id"], "text": unit["text"]}
        if unit.get("context") is not None:
            row["context"] = unit["context"]
        size = len(row["text"])
        if current and (chars + size > max_chars or len(current) >= 64):
            groups.append(current)
            current = []
            chars = 0
        current.append(row)
        chars += size
    if current:
        groups.append(current)
    return groups


def collect_inputs(args, output, stdin_raw=None):
    if args.file or args.directory:
        requested = Path(args.file or args.directory).expanduser().absolute()
        if args.file and not requested.is_file():
            raise TranslationError("file_input_not_regular_file")
        if args.directory and not requested.is_dir():
            raise TranslationError("directory_input_not_directory")
        extensions = (
            [("." + e.lstrip(".")).lower() for e in args.extensions]
            if args.extensions
            else None
        )
        files, input_root, excluded = collect(
            requested, output, not args.no_recursive, extensions
        )
        rows = []
        size = 0
        for path in files:
            raw = read_regular(path, MAX_FILE, input_root)
            size += len(raw)
            if size > MAX_BATCH:
                raise TranslationError("batch_over_64_mib")
            rows.append((str(path), path.relative_to(input_root).as_posix(), raw))
        return rows, str(input_root), excluded
    if args.extensions:
        raise TranslationError("extensions_only_for_file_or_directory")
    if args.stdin:
        if stdin_raw is None:
            stdin_raw = sys.stdin.buffer.read(MAX_FILE + 1)
        raw = stdin_raw
        name = "stdin.txt"
    else:
        if args.encoding not in (None, "auto", "utf-8", "utf-8-sig"):
            raise TranslationError("inline_text_is_already_unicode_use_utf8")
        raw = args.text.encode("utf-8")
        name = "inline_text.txt"
    if len(raw) > MAX_FILE:
        raise TranslationError("inline_input_over_16_mib")
    return [(None, name, raw)], None, []


def start(args, stdin_raw=None):
    source = canonical_language(args.source_language or "Chinese")
    targets = target_languages(args.target_language, source)
    output = root_path(args.output or DEFAULT_OUTPUT)
    inputs, input_root, excluded = collect_inputs(args, output, stdin_raw)
    if not inputs:
        return {
            "status": "no_supported_files",
            "total_tasks": 0,
            "excluded": excluded,
        }, 1
    if len(inputs) * len(targets) > MAX_TASKS:
        raise TranslationError("task_count_limit")
    options = {
        "source_language": source,
        "target_languages": targets,
        "encoding": args.encoding or "auto",
        "output_encoding": args.output_encoding or "utf-8",
        "chunk_chars": args.chunk_chars or DEFAULT_CHUNK_CHARS,
        "batch_chars": args.batch_chars or DEFAULT_BATCH_CHARS,
        "recursive": not args.no_recursive,
    }
    prepared = []
    outputs = set()
    total_units = 0
    snapshot_bytes = 0
    # Parse every document before writing a batch or making any AI request.
    for path, name, raw in inputs:
        relative_path(name)
        document = decode(raw, options["encoding"])
        plan = prepare_document(
            document.text, Path(name).suffix.lower(), options["chunk_chars"]
        )
        units = plan["units"]
        if len(units) > MAX_UNITS or any(
            type(u["id"]) is not int
            or u["id"] != i
            or len(u["text"]) > options["chunk_chars"]
            for i, u in enumerate(units)
        ):
            raise TranslationError("document_unit_limit_or_invalid_plan")
        total_units += len(units)
        if total_units > MAX_TOTAL_UNITS:
            raise TranslationError("batch_unit_limit")
        work = {
            "version": WORKFLOW_VERSION,
            "source": path,
            "relative": name,
            "source_sha256": sha(raw),
            "source_bytes": len(raw),
            "source_chars": len(document.text),
            "encoding": document.encoding,
            "bom": document.bom.hex(),
            "document": plan,
        }
        work_raw = packed(work) + b"\n"
        snapshot_bytes += len(work_raw)
        if len(work_raw) > SNAPSHOT_LIMIT or snapshot_bytes > MAX_SNAPSHOTS:
            raise TranslationError("snapshot_size_limit")
        prepared.append((work, work_raw))
        for target in targets:
            destination = output_name(name, target)
            portable = key(destination)
            if portable in outputs:
                raise TranslationError("portable_output_name_collision")
            outputs.add(portable)
    if args.dry_run:
        return {
            "status": "dry_run",
            "source_language": source,
            "target_languages": targets,
            "documents": len(prepared),
            "total_tasks": len(prepared) * len(targets),
            "translatable_units": total_units,
            "source_bytes": sum(len(row[2]) for row in inputs),
            "excluded": excluded,
            "ai": "not_called",
            "writes": False,
            "tasks": [
                {
                    "source": w["source"] or w["relative"],
                    "target_language": target,
                    "relative_output": output_name(w["relative"], target),
                }
                for w, _ in prepared
                for target in targets
            ],
        }, 0
    mkdir(output, output)
    job = output / (
        datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:10]
    )
    job.mkdir(mode=0o700)
    for part in (
        ".work/docs",
        ".work/ai",
        ".work/accepted",
        ".work/progress",
        ".work/intents",
        ".work/completed",
        "files",
    ):
        mkdir(job, job / part)
    manifest = {
        "kind": "omnirush-translation-job",
        "version": WORKFLOW_VERSION,
        "created_at": now(),
        "input_root": input_root,
        "options": options,
        "excluded": excluded,
        "documents": [],
        "tasks": [],
    }
    for i, (work, raw) in enumerate(prepared):
        identity = f"{i:06d}"
        atomic_write(job / ".work/docs" / (identity + ".json"), raw)
        manifest["documents"].append(
            {
                "id": identity,
                "source": work["source"],
                "relative": work["relative"],
                "source_sha256": work["source_sha256"],
                "work_sha256": sha(raw),
            }
        )
        for target in targets:
            manifest["tasks"].append(
                {
                    "id": f'{len(manifest["tasks"]):06d}',
                    "document_id": identity,
                    "target_language": target,
                    "output": output_name(work["relative"], target),
                }
            )
    manifest["plan_id"] = sha(packed(manifest))
    write_json(job / "manifest.json", manifest)
    try:
        return resume(job, args.request_window)
    except Exception as error:
        return {
            "status": "error",
            "reason": reason(error),
            "job_dir": str(job),
            "partial_state_preserved": True,
        }, 2


def load_job(path):
    job = Path(path).expanduser().absolute()
    if not job.is_dir() or linklike(job):
        raise TranslationError("resume_job_missing_or_link")
    job = job.resolve()
    manifest = read_json(job / "manifest.json", 4 * 1024 * 1024, job)
    if (
        not isinstance(manifest, dict)
        or manifest.get("kind") != "omnirush-translation-job"
        or type(manifest.get("version")) is not int
        or manifest["version"] != WORKFLOW_VERSION
    ):
        raise TranslationError("unsupported_job_manifest")
    body = dict(manifest)
    identity = body.pop("plan_id", None)
    if identity != sha(packed(body)):
        raise TranslationError("manifest_changed")
    docs = manifest.get("documents")
    tasks = manifest.get("tasks")
    options = manifest["options"]
    if (
        not isinstance(docs, list)
        or not 1 <= len(docs) <= MAX_FILES
        or not isinstance(tasks, list)
        or not 1 <= len(tasks) <= MAX_TASKS
    ):
        raise TranslationError("invalid_manifest_counts")
    if not (
        128 <= options["chunk_chars"] <= 4000
        and options["chunk_chars"] <= options["batch_chars"] <= 12000
    ):
        raise TranslationError("invalid_manifest_options")
    root = Path(manifest["input_root"]) if manifest["input_root"] else None
    if root is not None and (
        not root.is_absolute() or not root.is_dir() or linklike(root)
    ):
        raise TranslationError("input_root_changed")
    works = {}
    total = 0
    total_snapshots = 0
    total_units = 0
    for index, item in enumerate(docs):
        if item["id"] != f"{index:06d}":
            raise TranslationError("invalid_document_identity")
        relative_path(item["relative"])
        raw = read_regular(
            job / ".work/docs" / (item["id"] + ".json"), SNAPSHOT_LIMIT, job
        )
        total_snapshots += len(raw)
        if total_snapshots > MAX_SNAPSHOTS:
            raise TranslationError("snapshot_size_limit")
        if sha(raw) != item["work_sha256"]:
            raise TranslationError("document_snapshot_changed")
        work = loads(raw)
        if any(work[k] != item[k] for k in ("source", "source_sha256", "relative")):
            raise TranslationError("snapshot_source_mismatch")
        if item["source"] is not None:
            source = Path(item["source"])
            if root is None or not source.is_absolute():
                raise TranslationError("invalid_source_path")
            original = read_regular(source, MAX_FILE, root)
        else:
            original = encode(
                work["document"]["text"],
                Document("", work["encoding"], snapshot_bom(work["bom"])),
                "same",
            )
        if sha(original) != item["source_sha256"]:
            raise TranslationError("source_changed_start_new_job")
        total += len(original)
        if total > MAX_BATCH:
            raise TranslationError("batch_over_64_mib")
        total_units += len(work["document"]["units"])
        if len(work["document"]["units"]) > MAX_UNITS or total_units > MAX_TOTAL_UNITS:
            raise TranslationError("batch_unit_limit")
        works[item["id"]] = work
    seen = set()
    pairs = set()
    for index, task in enumerate(tasks):
        if task["id"] != f"{index:06d}" or task["document_id"] not in works:
            raise TranslationError("invalid_task_identity")
        relative_path(task["output"])
        portable = key(task["output"])
        pair = (task["document_id"], task["target_language"])
        if (
            portable in seen
            or pair in pairs
            or task["target_language"] not in options["target_languages"]
        ):
            raise TranslationError("invalid_task_targets")
        if task["output"] != output_name(
            works[task["document_id"]]["relative"], task["target_language"]
        ):
            raise TranslationError("task_output_changed")
        seen.add(portable)
        pairs.add(pair)
    if len(tasks) != len(docs) * len(options["target_languages"]):
        raise TranslationError("missing_manifest_tasks")
    return job, manifest, works


def process_task(job, task, item, work, manifest, ai, window):
    signature = sha(
        packed(
            [manifest["plan_id"], task, item["work_sha256"], PROTOCOL_VERSION, GUARD]
        )
    )
    final_path = job / "files" / relative_path(task["output"])
    receipt_path = job / ".work/completed" / (task["id"] + ".json")
    if receipt_path.exists():
        receipt = read_json(receipt_path, 65536, job)
        if (
            receipt.get("signature") != signature
            or receipt.get("status") not in COMPLETED
            or sha(read_regular(final_path, MAX_OUTPUT, job))
            != receipt.get("output_sha256")
        ):
            raise TranslationError("completed_output_or_receipt_changed")
        return receipt, []
    row = {
        "id": task["id"],
        "source": work["source"] or work["relative"],
        "relative": work["relative"],
        "target_language": task["target_language"],
        "source_sha256": work["source_sha256"],
        "input_chars": work["source_chars"],
        "signature": signature,
        "ai_checked_units": 0,
        "ai_changed_units": 0,
        "status": "deferred",
    }
    options = manifest["options"]
    groups = batch_units(work, options["batch_chars"])
    pending = []
    accepted_dir = job / ".work/accepted" / task["id"]
    mkdir(job, accepted_dir)
    progress_path = job / ".work/progress" / (task["id"] + ".json")
    progress = (
        read_json(progress_path, 4096, job)
        if progress_path.exists()
        else {"signature": signature, "next_group": 0}
    )
    if (
        progress.get("signature") != signature
        or type(progress.get("next_group")) is not int
        or not 0 <= progress["next_group"] <= len(groups)
    ):
        raise TranslationError("ai_progress_changed")
    for number in range(progress["next_group"], len(groups)):
        group = groups[number]
        payload = payload_for(
            group,
            options["source_language"],
            task["target_language"],
            item["work_sha256"],
            task["id"],
            number,
        )
        identity = request_identity(payload)
        accepted_path = accepted_dir / (f"{number:06d}.json")
        try:
            if accepted_path.exists():
                data = read_json(accepted_path, 1024 * 1024, job)
                validate_response(data, identity, group)
            else:
                if len(pending) >= window:
                    break
                translated, provider = translate_with_fallback(
                    group,
                    options["source_language"],
                    task["target_language"],
                    ai,
                    document_sha256=item["work_sha256"],
                    task_id=task["id"],
                    group=number,
                )
                data = {
                    "request_id": identity,
                    "translations": [
                        {"id": u["id"], "text": translated[u["id"]]} for u in group
                    ],
                }
                write_json(accepted_path, data)
            if number == progress["next_group"]:
                progress["next_group"] += 1
                write_json(progress_path, progress, replace=True)
        except AIRequestPending as error:
            if row["status"] != "invalid_ai_response":
                row["status"] = "awaiting_ai"
            pending.append(error.request)
        except AIResponseInvalid as error:
            row.update(status="invalid_ai_response", reason=error.code)
            pending.append(error.request)
    row["ai_checked_units"] = sum(len(g) for g in groups[: progress["next_group"]])
    if pending or progress["next_group"] != len(groups):
        return row, pending
    translated = {}
    for number, group in enumerate(groups):
        payload = payload_for(
            group,
            options["source_language"],
            task["target_language"],
            item["work_sha256"],
            task["id"],
            number,
        )
        translated.update(
            validate_response(
                read_json(accepted_dir / (f"{number:06d}.json"), 1024 * 1024, job),
                request_identity(payload),
                group,
            )
        )
    result = render_document(work["document"], translated)
    raw = encode(
        result,
        Document(work["document"]["text"], work["encoding"], snapshot_bom(work["bom"])),
        options["output_encoding"],
    )
    if len(raw) > MAX_OUTPUT:
        raise TranslationError("translated_output_over_64_mib")
    if (
        work["source"] is not None
        and sha(
            read_regular(Path(work["source"]), MAX_FILE, Path(manifest["input_root"]))
        )
        != item["source_sha256"]
    ):
        raise TranslationError("source_changed_before_output")
    mkdir(job, final_path.parent)
    intent_path = job / ".work/intents" / (task["id"] + ".json")
    intent = {
        "signature": signature,
        "output": task["output"],
        "output_sha256": sha(raw),
    }
    if intent_path.exists():
        if read_json(intent_path, 4096, job) != intent:
            raise TranslationError("output_intent_changed")
    else:
        if final_path.exists() or final_path.is_symlink():
            raise TranslationError("unowned_output_exists")
        write_json(intent_path, intent)
    if final_path.exists() or final_path.is_symlink():
        if read_regular(final_path, MAX_OUTPUT, job) != raw:
            raise TranslationError("existing_output_does_not_match_intent")
    else:
        atomic_write(final_path, raw)
    changed = sum(
        unit["text"] != translated[unit["id"]] for unit in work["document"]["units"]
    )
    row.update(
        status=(
            "translated"
            if changed
            else "checked_unchanged" if translated else "no_translatable_text"
        ),
        ai_checked_units=len(translated),
        ai_changed_units=changed,
        output=str(final_path),
        output_sha256=sha(raw),
        output_chars=len(result),
        output_bytes=len(raw),
        completed_at=now(),
        provider=PROVIDER if groups else None,
        model="invoking-session (not independently attested)" if groups else None,
        needs_review=bool(groups and not changed),
    )
    if row["needs_review"]:
        row["warning"] = (
            "unchanged_text_verify_target_language_not_automatic_translation_success"
        )
    write_json(receipt_path, row)
    return row, []


def write_reports(job, report):
    write_json(job / "report.json", report, replace=True)
    lines = [
        "AI 批量翻译统计报告",
        f"源语言：{report['source_language']}",
        f"目标语言：{', '.join(report['target_languages'])}",
        f"任务总数：{report['total_tasks']}，完成：{report['completed']}，失败：{report['failed']}，待处理：{report['pending']}，需复核：{report['needs_review']}",
        "完成包含 translated / checked_unchanged / no_translatable_text；后二者不等于完成了语言转换。",
        "结构校验不是语义或语言识别证明；重要材料仍需人工复核。",
        "",
    ]
    for row in report["results"]:
        # JSON quoting preserves report layout even for hostile filenames.
        lines.append(
            packed(
                {
                    k: row.get(k)
                    for k in (
                        "source",
                        "target_language",
                        "status",
                        "output",
                        "ai_checked_units",
                        "ai_changed_units",
                        "reason",
                        "warning",
                    )
                    if row.get(k) is not None
                }
            ).decode()
        )
    atomic_write(job / "report.txt", ("\n".join(lines) + "\n").encode(), replace=True)


def resume(path, window=4):
    job = Path(path).expanduser().absolute()
    if not job.is_dir() or linklike(job):
        raise TranslationError("resume_job_missing_or_link")
    job = job.resolve()
    with job_lock(job):
        job, manifest, works = load_job(job)
        ai = CurrentSessionAI(job)
        rows = []
        pending = []
        began = time.monotonic()
        docs = {d["id"]: d for d in manifest["documents"]}
        for task in manifest["tasks"]:
            work = works[task["document_id"]]
            item = docs[task["document_id"]]
            try:
                row, task_pending = process_task(
                    job, task, item, work, manifest, ai, max(0, window - len(pending))
                )
                pending.extend(task_pending)
            except Exception as error:
                row = {
                    "id": task["id"],
                    "source": work["source"] or work["relative"],
                    "target_language": task["target_language"],
                    "status": "failed",
                    "reason": reason(error),
                }
            rows.append(row)
        completed = sum(r["status"] in COMPLETED for r in rows)
        failed = sum(r["status"] in ("failed", "invalid_ai_response") for r in rows)
        needs_review = sum(bool(r.get("needs_review")) for r in rows)
        state = (
            "failed"
            if failed
            else (
                "awaiting_ai"
                if completed < len(rows)
                else "needs_review" if needs_review else "complete"
            )
        )
        report = {
            "kind": "omnirush-translation-report",
            "version": WORKFLOW_VERSION,
            "plan_id": manifest["plan_id"],
            "created_at": manifest["created_at"],
            "updated_at": now(),
            "status": state,
            "job_dir": str(job),
            "source_language": manifest["options"]["source_language"],
            "target_languages": manifest["options"]["target_languages"],
            "total_tasks": len(rows),
            "completed": completed,
            "failed": failed,
            "pending": len(rows) - completed - failed,
            "needs_review": needs_review,
            "translated": sum(r["status"] == "translated" for r in rows),
            "no_translatable_text": sum(
                r["status"] == "no_translatable_text" for r in rows
            ),
            "elapsed_this_resume_seconds": round(time.monotonic() - began, 3),
            "pending_requests": pending,
            "results": rows,
            "excluded": manifest["excluded"],
        }
        code = (
            1 if failed else 10 if completed < len(rows) else 1 if needs_review else 0
        )
        try:
            write_reports(job, report)
        except Exception as error:
            report.update(
                status="report_error",
                report_error=reason(error),
                translation_exit_code=code,
            )
            code = 2
        return report, code


def language_help():
    data = language_data()
    lines = [
        "源语言默认 Chinese；Auto 为自动识别，仅用于源语言。目标语言支持重复参数或逗号分隔。"
    ]
    lines.extend(
        group + ": " + ", ".join(names)
        for group, names in data["LANGUAGE_GROUPS"].items()
    )
    lines.append(
        "别名示例：中文/zh、英语/en、德语/de、法语/fr、繁体中文/zh-Hant；也可输入清晰的其他语言名称。"
    )
    return "\n".join(lines)


def build_parser():
    p = argparse.ArgumentParser(
        description="批量文档翻译：当前 OmniRush 会话模型，格式保护、分段和断点续跑，无外部 AI 配置。"
    )
    g = p.add_mutually_exclusive_group()
    g.add_argument("--directory", "-d", type=Path)
    g.add_argument("--file", "-f", type=Path)
    g.add_argument(
        "--text",
        "-t",
        help="兼容原脚本；私密正文请改用文件或 --stdin，避免 shell 历史/进程参数",
    )
    g.add_argument("--stdin", action="store_true")
    g.add_argument("--resume", type=Path)
    p.add_argument("--source-language", default=None, help="默认 Chinese；支持 Auto")
    p.add_argument(
        "--target-language", action="append", help="可重复，也可逗号分隔多个语言"
    )
    p.add_argument(
        "--output", type=Path, default=None, help="默认 ~/Downloads/translator_i18n"
    )
    p.add_argument(
        "--extensions", nargs="+", help="筛选 .txt .md .markdown .srt .vtt .csv .json"
    )
    p.add_argument("--no-recursive", action="store_true")
    p.add_argument("--encoding", choices=ENCODINGS, default=None)
    p.add_argument(
        "--output-encoding",
        choices=("utf-8", "same"),
        default=None,
        help="默认 UTF-8，避免目标语言无法用原编码表示",
    )
    p.add_argument(
        "--chunk-chars",
        type=int,
        default=None,
        help="每个翻译单元最大字符，128–4000，默认 1500",
    )
    p.add_argument(
        "--batch-chars",
        type=int,
        default=None,
        help="请求正文字符预算，至少 chunk-chars、最多12000，默认4000",
    )
    p.add_argument(
        "--request-window", type=int, default=4, help="同时暴露的待处理请求数，1–32"
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="解析预检，不生成批次、不写文件、不请求模型",
    )
    p.add_argument("--language-help", action="store_true")
    p.add_argument(
        "--version",
        action="version",
        version="AI Batch Translator — OmniRush session adapter 1.0",
    )
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.language_help:
        print(language_help())
        return 0
    try:
        if not 1 <= args.request_window <= 32:
            raise TranslationError("request_window_must_be_1_to_32")
        chunk = (
            args.chunk_chars if args.chunk_chars is not None else DEFAULT_CHUNK_CHARS
        )
        batch = (
            args.batch_chars if args.batch_chars is not None else DEFAULT_BATCH_CHARS
        )
        if not 128 <= chunk <= 4000 or not chunk <= batch <= 12000:
            raise TranslationError("invalid_chunk_or_batch_chars")
        if args.resume:
            if any(
                (
                    args.source_language is not None,
                    args.target_language is not None,
                    args.output is not None,
                    args.extensions is not None,
                    args.no_recursive,
                    args.encoding is not None,
                    args.output_encoding is not None,
                    args.chunk_chars is not None,
                    args.batch_chars is not None,
                    args.dry_run,
                )
            ):
                raise TranslationError(
                    "resume_uses_saved_options_start_new_job_to_change"
                )
            result, code = resume(args.resume, args.request_window)
        else:
            if not any(
                (
                    args.file is not None,
                    args.directory is not None,
                    args.text is not None,
                    args.stdin,
                )
            ):
                raise TranslationError("explicit_file_directory_text_or_stdin_required")
            result, code = start(args)
    except Exception as error:
        result = {"status": "error", "reason": reason(error)}
        code = 2
    print(packed(result).decode("utf-8"))
    return code


if __name__ == "__main__":
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", newline="")
    raise SystemExit(main())
