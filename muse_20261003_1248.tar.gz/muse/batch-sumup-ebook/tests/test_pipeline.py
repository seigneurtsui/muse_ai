"""Offline regression tests. All book/model content here is synthetic test data."""
import contextlib
import io
import json
import random
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import batch_sumup_ebook as pipeline
import ebook_convert as convert
import ebook_utils as utils


def fake_valid_voice():
    # Deliberately non-literary, diverse characters to exercise mechanical QC.
    # Never used outside temporary test directories or as a real model response.
    rng = random.Random(1234)
    return "\n\n".join("".join(chr(rng.randrange(0x4e00, 0x9fa0)) for _ in range(130)) + "。"
                       for _ in range(40))


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.source = self.root / "books"
        self.source.mkdir()
        self.output = self.root / "output"
        self.voice = fake_valid_voice()

    def book(self, name="测试书.txt", text="第一章 出发\n这是一份测试材料，讲述学习与选择。"):
        path = self.source / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        return path

    def run_batch(self):
        with contextlib.redirect_stdout(io.StringIO()):
            return pipeline.batch_process(self.source, self.output)

    def answer(self, report, voice=None):
        request = report["request"]
        stage = request["stage"]
        if stage.startswith("chunk_"):
            text = "这是离线测试用的分块摘要。"
        elif stage == "summary":
            text = "---summary.txt---\n测试书摘要\n---summary.md---\n# 测试书摘要"
        elif stage == "insights":
            text = "# 测试启示\n这是测试数据，不是真实书评。"
        else:
            text = voice if voice is not None else self.voice
        Path(request["response_path"]).write_text(text, encoding="utf-8")

    def finish(self, voice=None):
        stages = []
        for _ in range(20):
            report, code = self.run_batch()
            if code != 10:
                return report, code, stages
            stages.append(report["request"]["stage"])
            self.answer(report, voice=voice)
        self.fail("Unexpected unbounded AI request loop")

    def test_end_to_end_handoff_files_and_skip(self):
        self.book()
        report, code, stages = self.finish()
        self.assertEqual(stages, ["chunk_001", "summary", "insights", "voice"])
        self.assertEqual(code, 0)
        self.assertEqual(report["success"], 1)
        folder = self.output / "测试书"
        for filename in ("manifest.json", "chunk_summaries.txt", "summary.txt", "summary.md",
                         "modern_insights.md", "summary_voice.txt", "validation.json"):
            self.assertTrue((folder / filename).is_file(), filename)
        self.assertEqual((folder / "summary.txt").read_text(), "测试书摘要")
        self.assertTrue(json.loads((folder / "validation.json").read_text())["valid"])
        again, code = self.run_batch()
        self.assertEqual(code, 0)
        self.assertEqual(again["skipped"], 1)

    def test_request_cache_and_empty_response(self):
        self.book()
        first, code = self.run_batch()
        self.assertEqual(code, 10)
        request = first["request"]
        self.assertIn("这是一份测试材料", Path(request["prompt_path"]).read_text())
        Path(request["response_path"]).write_text("  \n")
        same, code = self.run_batch()
        self.assertEqual(code, 10)
        self.assertEqual(request["id"], same["request"]["id"])
        self.answer(same)
        next_request, code = self.run_batch()
        self.assertEqual(next_request["request"]["stage"], "summary")

    def test_conversion_not_repeated_during_handoff(self):
        self.book()
        with patch.object(pipeline, "convert_to_txt", wraps=convert.convert_to_txt) as converter:
            self.finish()
            self.assertEqual(converter.call_count, 1)

    def test_short_voice_bounded_retries_and_needs_update(self):
        self.book()
        report, code, stages = self.finish(voice="正文过短，不能达到播报要求。")
        self.assertEqual(stages[-3:], ["voice", "rewrite", "expand"])
        self.assertEqual(code, 1)
        self.assertEqual(report["needs_update"], 1)
        self.assertEqual(report["success"], 0)

    def test_rewrite_can_recover(self):
        self.book()
        while True:
            report, code = self.run_batch()
            self.assertEqual(code, 10)
            stage = report["request"]["stage"]
            self.answer(report, voice="不够长。" if stage == "voice" else self.voice)
            if stage == "rewrite":
                break
        report, code = self.run_batch()
        self.assertEqual(code, 0)
        self.assertEqual(report["success"], 1)

    def test_expansion_can_recover_duration(self):
        self.book()
        while True:
            report, code = self.run_batch()
            self.assertEqual(code, 10)
            stage = report["request"]["stage"]
            self.answer(report, voice=self.voice[:4100] if stage == "voice" else self.voice)
            if stage == "expand":
                break
        report, code = self.run_batch()
        self.assertEqual(code, 0)
        self.assertEqual(report["success"], 1)

    def test_multiple_books_count_success_across_handoffs(self):
        self.book("一.txt")
        self.book("二.txt")
        report, code, stages = self.finish()
        self.assertEqual(code, 0)
        self.assertEqual(report["success"], 2)
        self.assertEqual(len(stages), 8)

    def test_duplicate_names_get_distinct_outputs(self):
        self.book("a/同名.txt")
        self.book("b/同名.txt", "第二本不同的正文。")
        report, code, _ = self.finish()
        self.assertEqual(code, 0)
        paths = [r["summary_path"] for r in report["results"]]
        self.assertEqual(len(set(paths)), 2)
        self.assertTrue(all(Path(p).exists() for p in paths))

    def test_source_change_invalidates_response_cache(self):
        path = self.book()
        first, _ = self.run_batch()
        self.answer(first)
        path.write_text("原始文件已经发生修改，不能复用原摘要。")
        changed, code = self.run_batch()
        self.assertEqual(code, 10)
        self.assertNotEqual(first["request"]["response_path"], changed["request"]["response_path"])
        self.assertEqual(changed["request"]["stage"], "chunk_001")

    def test_changed_source_does_not_skip_old_valid_voice(self):
        path = self.book()
        self.finish()
        path.write_text("这是新版本的正文，应当更新已有的摘要。")
        request, code = self.run_batch()
        self.assertEqual(code, 10)
        self.answer(request)
        request, code = self.run_batch()
        self.assertEqual(code, 10)
        self.assertEqual(request["request"]["stage"], "summary")

    def test_failed_book_does_not_abort_batch(self):
        self.book("a.txt", "")
        self.book("b.txt")
        report, code, _ = self.finish()
        self.assertEqual(code, 1)
        self.assertEqual(report["failed"], 1)
        self.assertEqual(report["success"], 1)

    def test_empty_directory_writes_zero_result(self):
        report, code = self.run_batch()
        self.assertEqual(code, 0)
        self.assertEqual(report["total"], 0)
        self.assertTrue((self.output / "batch_result.json").exists())

    def test_invalid_directory_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "有效目录"):
            pipeline.batch_process(self.root / "missing", self.output)

    def test_scan_uppercase_and_exclude_nested_output(self):
        book = self.book("BOOK.TXT")
        output = self.source / "summaries"
        output.mkdir()
        (output / "summary.txt").write_text("not input")
        self.assertEqual(convert.find_ebooks(self.source, output), [book])
        with self.assertRaises(ValueError):
            convert.find_ebooks(output, output)

    def test_txt_without_calibre_and_supported_encodings(self):
        path = self.book()
        for encoding in ("utf-8-sig", "utf-16", "gb18030"):
            path.write_bytes("中文测试正文".encode(encoding))
            result = convert.convert_to_txt(path, self.root / "converted", None)
            self.assertEqual(result.read_text(), "中文测试正文")

    def test_pdf_uses_pdftotext_without_calibre(self):
        path = self.source / "book.pdf"
        path.write_bytes(b"fake pdf")
        def fake_run(command, timeout):
            Path(command[-1]).write_text("这是从文本 PDF 提取的内容。")
        with patch.object(convert, "find_tool", return_value="/usr/bin/pdftotext"), \
             patch.object(convert, "run_converter", side_effect=fake_run), \
             patch.object(convert, "ocr_pdf") as ocr:
            target = convert.convert_to_txt(path, self.root / "converted")
            self.assertTrue(target.exists())
            ocr.assert_not_called()

    def test_drm_error_is_actionable_and_no_fake_summary(self):
        path = self.source / "encrypted.epub"
        path.write_bytes(b"synthetic encrypted fixture")
        failure = subprocess.CompletedProcess(["ebook-convert"], 1, "", "calibre.ebooks.DRMError: encrypted.epub")
        with patch.object(convert.subprocess, "run", return_value=failure), \
             patch.object(pipeline, "find_calibre", return_value="ebook-convert"):
            report, code = self.run_batch()
        self.assertEqual(code, 1)
        self.assertEqual(report["failed"], 1)
        self.assertIn("DRM 加密", report["results"][0]["error"])
        self.assertFalse((self.output / "encrypted/summary_voice.txt").exists())

    def test_missing_converter_is_actionable(self):
        path = self.source / "book.epub"
        path.write_bytes(b"fake epub")
        with self.assertRaisesRegex(RuntimeError, "Calibre"):
            convert.convert_to_txt(path, self.root / "converted", None)

    def test_chinese_chapters_and_hard_chunk_limit(self):
        chapters = utils.split_by_chapters("第一章 开始\n正文\n第 二 章 后续\n更多内容")
        self.assertEqual(len(chapters), 2)
        text = "中" * 15001
        chunks = utils.split_long_chapter({"title": "全文", "content": text}, 6000)
        self.assertEqual([len(c["content"]) for c in chunks], [6000, 6000, 3001])
        self.assertEqual("".join(c["content"] for c in chunks), text)

    def test_voice_quality_and_cleanup(self):
        self.assertTrue(pipeline.validate_summary_voice(self.voice)["valid"])
        self.assertFalse(pipeline.validate_summary_voice("Thinking Process: short")["valid"])
        self.assertEqual(utils.dedupe_paragraphs("完全相同的一段文字。\n\n完全相同的一段文字。"), "完全相同的一段文字。")
        self.assertNotIn("**", pipeline.clean_voice("**测试正文**"))

    def test_templates_have_expected_placeholders(self):
        values = dict(chunk_text="块", all_summaries_text="摘要", summary_txt="摘要", insights="启示",
                      voice_text="正文", char_count=10)
        for name in ("chunk", "summary", "insights", "voice", "rewrite", "expand"):
            self.assertTrue(pipeline.prompt(name, **values))

    def test_only_directory_cli_argument(self):
        result = subprocess.run([sys.executable, str(SCRIPTS / "batch_sumup_ebook.py"),
                                 str(self.source), "--force"], capture_output=True, text=True)
        self.assertEqual(result.returncode, 2)
        self.assertIn("unrecognized arguments", result.stderr)

    def test_skill_frontmatter_and_no_legacy_services(self):
        root = SCRIPTS.parent
        skill = (root / "SKILL.md").read_text()
        self.assertTrue(skill.startswith("---\nname: batch-sumup-ebook\ndescription:"))
        sources = "\n".join(p.read_text() for p in SCRIPTS.glob("*.py"))
        for forbidden in ("import requests", "curl_cffi", "AI_SERVICES", "apiKey", "smtplib",
                          "book2youtube", "requests.post"):
            self.assertNotIn(forbidden, sources)


if __name__ == "__main__":
    unittest.main()
