# GitHub Repo Metadata

- Repository name: `sunzi-bingfa-skill`
- URL: https://github.com/qbdx-hub/sunzi-bingfa-skill
- Source package: `E:\project\cangjie-sunzi-bingfa\books\sunzi-bingfa`
- Description: `AI skill pack distilled from Sunzi Bingfa for strategy and decision making.`
- Topics:
  - ai-skills
  - book-to-skill
  - cangjie-skill
  - strategy
  - sunzi