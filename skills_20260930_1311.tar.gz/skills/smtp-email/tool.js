const { sendSmtpEmail } = require('./index.js');

async function smtp_email_tool(params) {
  try {
    const result = await sendSmtpEmail({
      to: params.to,
      subject: params.subject,
      html: params.html,
      text: params.text,
      from: params.from
    });
    return result;
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

module.exports = {
  smtp_email_tool
};
