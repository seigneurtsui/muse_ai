#!/usr/bin/env python3
"""Render one immutable source video and burn ASS subtitles as the last visual step."""
from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import subprocess
import tempfile
from pathlib import Path


def probe(path: Path) -> dict:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)],
        capture_output=True, text=True, check=True,
    )
    return json.loads(result.stdout)


def atempo_chain(speed: float) -> str:
    if not math.isfinite(speed) or speed <= 0:
        raise ValueError("speed must be greater than zero")
    factors: list[str] = []
    remaining = speed
    while remaining > 2.0:
        factors.append("atempo=2")
        remaining /= 2.0
    while remaining < 0.5:
        factors.append("atempo=0.5")
        remaining /= 0.5
    factors.append(f"atempo={remaining:.7f}")
    return ",".join(factors)


def ff_filter_path(path: Path) -> str:
    return str(path.resolve()).replace("\\", "\\\\").replace(":", r"\:").replace("'", r"\'").replace(",", r"\,")


def even(value: int) -> int:
    return max(2, value if value % 2 == 0 else value - 1)


def preview_dimensions(width: int, height: int) -> tuple[int, int]:
    # 720p means a 720px short edge: vertical 720x1280, landscape 1280x720.
    scale = min(1.0, 720 / min(width, height))
    return even(round(width * scale)), even(round(height * scale))


def duck_expression(intervals: list[dict], duck_db: float, ramp: float = 0.03) -> str:
    if not math.isfinite(duck_db) or not -60 <= duck_db <= 0:
        raise ValueError("duck dB must be between -60 and 0")
    strength = []
    for item in intervals:
        start, end = float(item["start"]), float(item["end"])
        strength.append(f"max(0,min(1,min((t-{start-ramp:.6f})/{ramp},({end+ramp:.6f}-t)/{ramp})))")
    envelope = "0"
    for value in strength:
        envelope = f"max({envelope},{value})"
    return f"1-(1-{10 ** (duck_db / 20):.8f})*({envelope})"


def render(args: argparse.Namespace) -> dict:
    source = args.source.expanduser().resolve()
    subtitle = args.subtitle.expanduser().resolve() if args.subtitle else None
    output = args.output.expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(source)
    if output == source:
        raise ValueError("output must not overwrite source")
    media = probe(source)
    stream = next((s for s in media.get("streams", []) if s.get("codec_type") == "video"), None)
    if not stream:
        raise ValueError("source has no video stream")
    source_width, source_height = int(stream["width"]), int(stream["height"])
    width = args.width or source_width
    height = args.height or source_height
    if args.preview:
        width, height = preview_dimensions(width, height)
    width, height = even(width), even(height)
    speed = float(args.speed)
    if not math.isfinite(speed) or speed <= 0:
        raise ValueError("speed must be finite and positive")
    trim_start = max(0.0, float(args.trim_start))
    trim_duration = None
    if args.trim_end is not None:
        trim_duration = float(args.trim_end) - trim_start
        if trim_duration <= 0:
            raise ValueError("trim-end must be greater than trim-start")

    source_duration = float(media.get("format", {}).get("duration") or 0)
    output_duration = ((min(source_duration, float(args.trim_end)) if args.trim_end is not None else source_duration) - trim_start) / speed
    fade_ms = float(getattr(args, "audio_fade_ms", 0))
    if not math.isfinite(fade_ms) or not 0 <= fade_ms <= 200 or output_duration <= 0:
        raise ValueError("invalid duration or audio fade (0-200 ms)")
    fade = min(fade_ms / 1000, output_duration / 2)
    voiceover = getattr(args, "voiceover_audio", None)
    manifest_path = getattr(args, "voiceover_manifest", None)
    if bool(voiceover) != bool(manifest_path):
        raise ValueError("voiceover audio and manifest must be supplied together")

    video_filter = (
        f"setpts=(PTS-STARTPTS)/{speed:.8f},fps={args.fps},scale={width}:{height}:force_original_aspect_ratio=decrease:flags=lanczos,"
        f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1"
    )
    if subtitle:
        if not subtitle.is_file():
            raise FileNotFoundError(subtitle)
        video_filter += f",ass={ff_filter_path(subtitle)}"

    audio_stream = next((s for s in media.get("streams", []) if s.get("codec_type") == "audio"), None)
    command = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error"]
    if trim_start:
        command += ["-ss", f"{trim_start:.6f}"]
    if trim_duration is not None:
        # Input-side duration keeps slow-motion output from being truncated.
        command += ["-t", f"{trim_duration:.6f}"]
    command += ["-i", str(source)]
    if voiceover:
        command += ["-i", str(Path(voiceover).expanduser().resolve())]
    command += ["-map", "0:v:0", "-vf", video_filter]
    audio_filter = f"asetpts=PTS-STARTPTS,{atempo_chain(speed)}"
    if args.loudnorm:
        audio_filter += ",loudnorm=I=-16:LRA=11:TP=-1.5"
    audio_filter += f",apad,atrim=duration={output_duration:.6f}"
    if fade:
        audio_filter += f",afade=t=in:d={fade:.6f},afade=t=out:st={output_duration-fade:.6f}:d={fade:.6f}"
    if voiceover:
        manifest = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
        expression = duck_expression(manifest["intervals"], float(manifest["duck_db"]))
        base = f"[0:a:0]{audio_filter}" if audio_stream else f"anullsrc=r=48000:cl=stereo,atrim=duration={output_duration:.6f}"
        graph = (f"{base},volume='{expression}':eval=frame[base];"
                 f"[1:a:0]asetpts=PTS-STARTPTS,apad,atrim=duration={output_duration:.6f}[voice];"
                 f"[base][voice]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95:latency=1[mix]")
        # A filter script keeps large batch narration timelines off the argv limit.
        output.parent.mkdir(parents=True, exist_ok=True)
        graph_path = output.parent / (output.stem + "-audio-filter.txt")
        graph_path.write_text(graph, encoding="utf-8")
        command += ["-filter_complex_script", str(graph_path), "-map", "[mix]"]
    elif audio_stream:
        command += ["-map", "0:a:0?", "-af", audio_filter]
    else:
        command += ["-an"]
    if audio_stream or voiceover:
        command += ["-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2"]
    command += [
        "-c:v", "libx264", "-threads", "2", "-preset", args.preset, "-fps_mode", "cfr",
        "-crf", str(args.preview_crf if args.preview else args.crf),
        "-pix_fmt", "yuv420p", "-movflags", "+faststart",
    ]
    output.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".render-", suffix=".mp4", dir=str(output.parent))
    os.close(fd)
    temporary_path = Path(temporary)
    try:
        completed = subprocess.run(command + [str(temporary_path)], capture_output=True, text=True)
        if completed.returncode != 0:
            raise RuntimeError(completed.stderr[-4000:] or "ffmpeg render failed")
        if not temporary_path.is_file() or temporary_path.stat().st_size == 0:
            raise RuntimeError("ffmpeg produced an empty output")
        os.replace(temporary_path, output)
    finally:
        temporary_path.unlink(missing_ok=True)
    return {
        "source": str(source), "output": str(output), "subtitle": str(subtitle) if subtitle else None,
        "width": width, "height": height, "fps": args.fps, "speed": speed,
        "trim_start": trim_start, "trim_end": args.trim_end, "preview": bool(args.preview),
        "loudnorm": bool(args.loudnorm), "audio_fade_ms": fade_ms,
        "voiceover": str(voiceover) if voiceover else None, "bytes": output.stat().st_size,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--subtitle", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--width", type=int)
    parser.add_argument("--height", type=int)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--speed", type=float, default=1.0)
    parser.add_argument("--trim-start", type=float, default=0.0)
    parser.add_argument("--trim-end", type=float)
    parser.add_argument("--crf", type=int, default=18)
    parser.add_argument("--preview-crf", type=int, default=23)
    parser.add_argument("--preset", default="medium", choices=("ultrafast", "superfast", "veryfast", "faster", "fast", "medium", "slow", "slower"))
    parser.add_argument("--loudnorm", action="store_true")
    parser.add_argument("--preview", action="store_true")
    parser.add_argument("--audio-fade-ms", type=float, default=0)
    parser.add_argument("--voiceover-audio", type=Path)
    parser.add_argument("--voiceover-manifest", type=Path)
    args = parser.parse_args()
    print(json.dumps(render(args), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
