# 实现与安全边界

## 架构

1. **输入解析** `specs_from_args` → `PageSpec` 列表：来自 YAML、`discover` 或单目标。
2. **凭证** `load_env_files` 顺序读取 `--env-file` 与 `~/.config/freebuff/.env`，
   仅在环境变量未设置时写入（真实环境变量优先），令牌不落日志。
3. **哈希** `source_digest`：文件直接流式哈希；目录按相对路径排序后逐个流式哈希
   （路径 + 内容，分块读取，内存有界），得到稳定的 `content_sha256`。
4. **跳过决策** `decide_skip`：
   - `--force` → 不跳过；
   - 无历史或上次非成功 → 部署（即失败自动重试）；
   - 上次成功且 `--retry-failed` → `retry_failed_skip`；
   - 上次成功且哈希与分支都未变 → `unchanged`。
5. **项目确保**：先按项目名做单条 `GET …/pages/projects/<name>`（404=不存在），
   仅在缺失且 `create_if_missing` 时 `POST` 创建。相比「列出全部项目再比对」，
   每个项目只多一次轻量请求。
6. **部署**：`wrangler pages deploy <src> --project-name <n> --branch <b> --commit-dirty=true`
   （可选 `--commit-message` / `--skip-caching`）；`CLOUDFLARE_API_TOKEN` 与
   `CLOUDFLARE_ACCOUNT_ID` 注入子进程环境。stdout/stderr 用正则提取 `.pages.dev` URL。
7. **并发**：`ThreadPoolExecutor(max_workers=jobs)`；`as_completed` 中在主线程合并状态并
   原子写盘，保证崩溃可恢复且无写竞争。单个项目异常被转换为 `failed` 结果，不中断整批。
8. **报告/状态**：`_finalize` 汇总；状态文件原子写（临时文件 + `os.replace`）。

## 性能设计

- **内容哈希跳过**：未变更站点完全不走网络，省去整站上传。
- **单项目查询**：避免每次全量列举项目。
- **有界并行**：`--jobs`（默认 auto，上限 8）让多站点部署重叠进行。
- **流式哈希**：1 MiB 分块，避免大站点占用内存。
- **连接复用**：`requests.Session` 复用连接；`wrangler --skip-caching` 可进一步加速上传。

## 安全边界

- 只读取用户明确指定的 `--config` / `--dir` / `--discover-root`，不扫描家目录或 Downloads。
- Token 只进子进程环境，绝不打印或写入报告/状态。
- 网络仅限 `api.cloudflare.com`（项目查询/创建）与 wrangler 的上传端点。
- 不自动安装依赖、不执行 `wrangler login`、不删除项目/Worker、不改 DNS/自定义域名。
- `failed` 的 `detail` 只保留 wrangler 输出尾部并截断，避免日志爆炸。
- `--dry-run` 不联网、不建项目、不写状态或报告。
- 部署与项目创建属于外部副作用；对生产分支执行前建议先 `--dry-run`。

## 与源项目的差异

| 方面 | /tmp/deploy `cf_factory.py` | 本技能 |
|---|---|---|
| 范围 | Workers + Pages 统一 | 仅 Pages 静态 HTML |
| 输入 | YAML（相对 cwd 解析） | YAML（相对配置目录）+ `discover` + 单目标 |
| 跳过 | `--retry-failed` 跳过成功项 | 内容哈希跳过 + `--retry-failed` + `--force` |
| 项目存在性 | 列出全部项目比对 | 单项目 `GET`（404 判定） |
| 并发 | 串行 | `--jobs` 有界并行 |
| 状态写入 | 直接覆盖写 | 原子写，skip 不降级成功记录 |
| 报告 | 无 | `--json` / `--report` |

## 尚未实现

- 自定义域名绑定（`custom_domain`）：需要 DNS 校验，源项目也仅作占位。
- Workers 批量部署：本技能聚焦 Pages；如需可从 `workers/workers_factory.py` 另建技能。
