# 《孙子兵法》Skill Index

## 产物概览

本目录按仓颉 RIA-TV++ 流程，从本地扫描版《孙子兵法》PDF 确认书籍来源，并以维基文库公版十三篇原文作为规范底稿，蒸馏为 8 个可执行 skill。

本地 PDF：`E:\project\孙子兵法 (孙武) (z-library.sk, 1lib.sk, z-lib.sk).pdf`

规范底稿：`E:\project\cangjie-sunzi-bingfa\books\sunzi-bingfa\source\sunzi-original.txt`

重要限制：本地 PDF 是扫描版，正文文字层不可用；OCR 抽样存在明显错字。本包不使用 OCR 错字做方法论依据，也不提供现实暴力、违法攻击、窃密、操纵或伤害性用途。

## Skills

| skill | 何时调用 | 核心动作 |
|---|---|---|
| `temple-calculation` | 高代价行动前，需要判断值不值得进入 | 用五事七计做胜算审计 |
| `win-without-fighting` | 想低成本达成目标，避免硬碰硬 | 用全胜、伐谋、伐交设计低损路径 |
| `short-war-resource-control` | 项目、竞争、谈判拖太久，资源失控 | 计算日成本、补给、止损线和短战方案 |
| `deception-and-shaping` | 需要合法信息呈现、节奏、奇正组合和造势 | 设计正面动作、侧翼动作和势能 |
| `know-self-know-enemy` | 信息不足，靠猜做决策 | 建立合法情报、敌我分析和不确定性清单 |
| `void-solid-flexibility` | 对手太强，正面打不过 | 识别实处、寻找虚处、设计错位突破 |
| `terrain-context-diagnosis` | 判断策略是否适合当前环境 | 用地形/九地检查市场、渠道、退路和深入程度 |
| `command-discipline-control` | 团队执行混乱、赏罚不信、授权失衡 | 检查将、法、令、赏罚和组织修复动作 |

## 调用图

```mermaid
flowchart TD
  A["temple-calculation"] --> B["know-self-know-enemy"]
  A --> C["terrain-context-diagnosis"]
  A --> D["command-discipline-control"]
  B --> E["void-solid-flexibility"]
  C --> E
  E --> F["deception-and-shaping"]
  F --> G["win-without-fighting"]
  A --> H["short-war-resource-control"]
  D --> H
  G --> H
```

## 推荐使用路径

1. 行动前先用 `temple-calculation` 做五事七计。
2. 信息不足时，调用 `know-self-know-enemy` 补情报。
3. 场景复杂时，调用 `terrain-context-diagnosis` 防止照搬。
4. 如果对手强，调用 `void-solid-flexibility` 找虚处。
5. 如果需要设计节奏和势能，调用 `deception-and-shaping`，但必须守合法边界。
6. 如果冲突能降级，优先 `win-without-fighting`。
7. 如果拖久烧钱，调用 `short-war-resource-control`。
8. 如果执行不动，调用 `command-discipline-control`。

## 审计文件

- `BOOK_OVERVIEW.md`: Stage 0 整书理解。
- `CANGJIE_ADAPTATION.md`: 本地 PDF、OCR 与公版底稿的适配说明。
- `candidates/`: Stage 1 候选池。
- `verified.md`: Stage 1.5 三重验证记录。
- `rejected/`: 拒绝或降级候选。
- 各 skill 目录下 `test-prompts.json`: Stage 4 压力测试用例。
