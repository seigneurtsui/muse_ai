#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""batch_image_merge.py (核心脚本：merge_images.py)

批量图片处理与合并工具（基于原 merge_images.py 适配为 skill 版本）。

在原脚本的基础上完善功能、优化性能：

功能
- 竖向合并 / 横向合并 / 任意列数 x 行数矩阵合并
- GIF 动图导出（统一或逐图片显示时长）
- PDF 汇总导出（每张图片一页）
- 文件名 / 类型 / 修改时间 / 创建时间 / EXIF 时间 / 大小排序，支持随机与自定义清单
- 去重、抽样、限制数量、标签、水印、输出尺寸限制
- 自动创建带日期/代码/输入目录名的独立输出子目录

性能与正确性改进（相对原脚本）
- 并行解码/缩放（--workers，默认取 CPU 核数，上限 8），显著缩短大批量处理时间
- 每张图片只打开一次（原脚本会为取尺寸重复打开），并复用已解码对象
- 使用 EXIF 方向校正后的真实尺寸计算画布（修正原脚本纵向/横向合并的宽高错位）
- 去重哈希并行计算
- 输出 manifest.json 运行清单，便于追溯批次产物

安装：
    python -m pip install Pillow

示例：
    python merge_images.py /path/to/fotos --mode all --grid 3x6
    python merge_images.py /path/to/fotos --mode gif --gif-duration 0.8 --gif-width 640
    python merge_images.py /path/to/fotos --mode pdf --pdf-name album
    python merge_images.py /path/to/fotos --mode grid --grid 3x6 --workers 8

默认输出：
    ~/Downloads/matrix_pix/YYYYMMDD_HHMM_<输入文件夹名>/
"""

from __future__ import annotations

import argparse
import datetime as datetime_module
import hashlib
import json
import os
import random
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Callable, Optional, Sequence, TypeVar

from PIL import Image, ImageDraw, ImageFont, ImageOps

__version__ = "2.0.0"

DEFAULT_OUTPUT_ROOT = Path("~/Downloads/matrix_pix").expanduser()
SUPPORTED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}
EXIF_DATE_TAGS = (36867, 306, 36868)
# EXIF Orientation 值 5-8 表示需要旋转 90/270 度，宽高互换。
_EXIF_SWAP_ORIENTATIONS = {5, 6, 7, 8}
DEFAULT_MAX_WORKERS = max(1, min(8, os.cpu_count() or 1))

T = TypeVar("T")
R = TypeVar("R")


# --------------------------------------------------------------------------- #
# 基础工具
# --------------------------------------------------------------------------- #
def natural_key(path: Path):
    return [
        int(part) if part.isdigit() else part.lower()
        for part in re.split(r"(\d+)", path.name)
    ]


def parse_xy(value: str, label: str) -> tuple[int, int]:
    match = re.fullmatch(r"\s*(\d+)\s*[xX*]\s*(\d+)\s*", value)
    if not match:
        raise argparse.ArgumentTypeError(f"{label}格式错误，应为例如 3x6")
    first, second = int(match.group(1)), int(match.group(2))
    if first < 1 or second < 1:
        raise argparse.ArgumentTypeError(f"{label}必须为正整数")
    return first, second


def _emit_progress(label: str, done: int, total: int) -> None:
    end = "\n" if done >= total else "\r"
    print(f"[{label}] {done}/{total}", end=end, file=sys.stderr, flush=True)


def parallel_map(
    func: Callable[[T], R],
    items: Sequence[T],
    workers: int,
    label: Optional[str] = None,
) -> list[R]:
    """按输入顺序返回结果；workers<=1 时退化为串行。"""
    items = list(items)
    total = len(items)
    results: list[Optional[R]] = [None] * total
    if total == 0:
        return []
    if workers <= 1 or total == 1:
        for index, item in enumerate(items):
            results[index] = func(item)
            if label:
                _emit_progress(label, index + 1, total)
        return results  # type: ignore[return-value]

    with ThreadPoolExecutor(max_workers=workers) as executor:
        future_to_index = {
            executor.submit(func, item): index for index, item in enumerate(items)
        }
        done = 0
        for future in as_completed(future_to_index):
            index = future_to_index[future]
            results[index] = future.result()
            done += 1
            if label:
                _emit_progress(label, done, total)
    return results  # type: ignore[return-value]


def build_output_dir(
    input_dir: Path,
    output_root: Path,
    output_subdir: Optional[str] = None,
    output_date: Optional[str] = None,
    output_code: Optional[str] = None,
    create: bool = True,
) -> Path:
    """计算本次任务的独立输出目录；create=False 时只计算路径不建目录（供 --dry-run）。

    默认：YYYYMMDD_HHMM_输入文件夹名。
    --output-subdir 优先级最高，可直接指定完整子目录名。
    --output-code 用于自定义示例中的四位代码，如 2628。
    """
    input_dir = input_dir.expanduser().resolve()
    output_root = output_root.expanduser().resolve()

    if output_subdir:
        subdir = Path(output_subdir).name
        if subdir in {"", ".", ".."}:
            raise ValueError("--output-subdir 不能为空")
    else:
        now = datetime_module.datetime.now()
        date_part = output_date or now.strftime("%Y%m%d")
        code_part = output_code or now.strftime("%H%M")
        if not re.fullmatch(r"\d{8}", date_part):
            raise ValueError("--output-date 必须是 YYYYMMDD，例如 20260708")
        if not re.fullmatch(r"\d{4}", code_part):
            raise ValueError("--output-code 必须是4位数字，例如 2628")
        folder_name = input_dir.name or "images"
        subdir = f"{date_part}_{code_part}_{folder_name}"

    result = output_root / subdir
    if create:
        result.mkdir(parents=True, exist_ok=True)
    return result


def list_images(folder: Path, recursive: bool, extensions: set[str]) -> list[Path]:
    if not folder.is_dir():
        raise FileNotFoundError(f"输入目录不存在：{folder}")
    iterator = folder.rglob("*") if recursive else folder.iterdir()
    paths = sorted(
        [p for p in iterator if p.is_file() and p.suffix.lower() in extensions],
        key=natural_key,
    )
    if not paths:
        raise ValueError(f"目录中没有找到支持的图片：{folder}")
    return paths


def image_size(path: Path) -> tuple[int, int]:
    """仅读取头部即返回 EXIF 方向校正后的尺寸，不做像素解码。"""
    with Image.open(path) as image:
        width, height = image.size
        try:
            orientation = image.getexif().get(274)
        except Exception:
            orientation = None
    if orientation in _EXIF_SWAP_ORIENTATIONS:
        return height, width
    return width, height


def load_rgb(path: Path) -> Image.Image:
    """打开并按 EXIF 方向校正为 RGB；每张图片只解码一次。"""
    with Image.open(path) as source:
        return ImageOps.exif_transpose(source).convert("RGB")


def exif_timestamp(path: Path) -> Optional[float]:
    try:
        with Image.open(path) as image:
            exif = image.getexif()
            for tag in EXIF_DATE_TAGS:
                value = exif.get(tag)
                if value:
                    try:
                        return datetime_module.datetime.strptime(
                            str(value), "%Y:%m:%d %H:%M:%S"
                        ).timestamp()
                    except ValueError:
                        continue
    except Exception:
        pass
    return None


def sort_images(
    paths: list[Path],
    mode: str,
    reverse: bool,
    order_file: Optional[Path],
    seed: Optional[int],
) -> list[Path]:
    if mode == "name":
        result = sorted(paths, key=natural_key)
    elif mode == "type":
        result = sorted(paths, key=lambda p: (p.suffix.lower(), natural_key(p)))
    elif mode == "mtime":
        result = sorted(paths, key=lambda p: (p.stat().st_mtime, natural_key(p)))
    elif mode == "ctime":
        result = sorted(paths, key=lambda p: (p.stat().st_ctime, natural_key(p)))
    elif mode == "size":
        result = sorted(paths, key=lambda p: (p.stat().st_size, natural_key(p)))
    elif mode == "exif":
        result = sorted(
            paths,
            key=lambda p: (exif_timestamp(p) or p.stat().st_mtime, natural_key(p)),
        )
    elif mode == "random":
        result = list(paths)
        random.Random(seed).shuffle(result)
    elif mode == "list":
        if not order_file:
            raise ValueError("--sort list 必须同时指定 --order-file")
        names = [
            line.strip()
            for line in order_file.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        ]
        by_name = {path.name: path for path in paths}
        result = [by_name[name] for name in names if name in by_name]
        selected = {path.name for path in result}
        result.extend(sorted((p for p in paths if p.name not in selected), key=natural_key))
    else:
        raise ValueError(f"未知排序方式：{mode}")

    if reverse and mode != "random":
        result.reverse()
    return result


def file_hash(path: Path) -> str:
    digest = hashlib.md5()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def deduplicate(paths: list[Path], workers: int = 1) -> list[Path]:
    hashes = parallel_map(file_hash, paths, workers, "去重")
    seen: dict[str, Path] = {}
    result = []
    for path, key in zip(paths, hashes):
        if key in seen:
            print(f"[去重] 跳过 {path.name}，与 {seen[key].name} 内容相同")
        else:
            seen[key] = path
            result.append(path)
    return result


# --------------------------------------------------------------------------- #
# 绘制 / 合成
# --------------------------------------------------------------------------- #
_FONT_CACHE: dict[int, ImageFont.FreeTypeFont | ImageFont.ImageFont] = {}


def get_font(size: int):
    cached = _FONT_CACHE.get(size)
    if cached is not None:
        return cached
    candidates = [
        "DejaVuSans.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
        "C:/Windows/Fonts/arial.ttf",
    ]
    font = None
    for candidate in candidates:
        try:
            font = ImageFont.truetype(candidate, size)
            break
        except Exception:
            continue
    if font is None:
        font = ImageFont.load_default()
    _FONT_CACHE[size] = font
    return font


def fit_image_object(source: Image.Image, size: tuple[int, int], background: str) -> Image.Image:
    """把已解码图片按 contain 方式放入固定尺寸画布（居中，不放大）。"""
    fitted = ImageOps.contain(source, size, Image.Resampling.LANCZOS)
    result = Image.new("RGB", size, background)
    result.paste(fitted, ((size[0] - fitted.width) // 2, (size[1] - fitted.height) // 2))
    return result


def fit_image(path: Path, size: tuple[int, int], background: str) -> Image.Image:
    return fit_image_object(load_rgb(path), size, background)


def resize_maximum(image: Image.Image, maximum: Optional[int]) -> Image.Image:
    if not maximum or max(image.size) <= maximum:
        return image
    ratio = maximum / max(image.size)
    return image.resize(
        (max(1, round(image.width * ratio)), max(1, round(image.height * ratio))),
        Image.Resampling.LANCZOS,
    )


def add_watermark(
    image: Image.Image,
    logo: Optional[Path],
    text: Optional[str],
    opacity: float,
    position: str,
) -> Image.Image:
    if not logo and not text:
        return image

    opacity = max(0.0, min(1.0, opacity))
    base = image.convert("RGBA")
    layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    margin = 16
    elements = []

    if logo:
        with Image.open(logo) as source:
            mark = source.convert("RGBA")
        if mark.width > max(1, base.width // 5):
            target_width = max(1, base.width // 5)
            ratio = target_width / mark.width
            mark = mark.resize(
                (target_width, max(1, round(mark.height * ratio))),
                Image.Resampling.LANCZOS,
            )
        alpha = mark.getchannel("A").point(lambda value: round(value * opacity))
        mark.putalpha(alpha)
        elements.append((mark.width, mark.height, mark))

    if text:
        text_font = get_font(max(16, base.width // 60))
        box = draw.textbbox((0, 0), text, font=text_font)
        elements.append((box[2] - box[0], box[3] - box[1], (text, text_font)))

    total_width = max(item[0] for item in elements)
    total_height = sum(item[1] for item in elements) + 4 * (len(elements) - 1)
    positions = {
        "top-left": (margin, margin),
        "top-right": (base.width - total_width - margin, margin),
        "bottom-left": (margin, base.height - total_height - margin),
        "bottom-right": (base.width - total_width - margin, base.height - total_height - margin),
        "center": ((base.width - total_width) // 2, (base.height - total_height) // 2),
    }
    x, y = positions[position]

    for width, height, item in elements:
        if isinstance(item, Image.Image):
            layer.alpha_composite(item, (x, y))
        else:
            value, text_font = item
            draw.text(
                (x, y), value, font=text_font,
                fill=(255, 255, 255, round(255 * opacity)),
                stroke_width=2,
                stroke_fill=(0, 0, 0, round(180 * opacity)),
            )
        y += height + 4

    return Image.alpha_composite(base, layer).convert("RGB")


def make_linear(paths, direction, gap, background, labels, label_mode, workers):
    label_extra = 24 if labels else 0
    if direction == "vertical":
        sizes = parallel_map(image_size, paths, workers, "读取尺寸")
        target_width = max(width for width, _ in sizes)

        def prepare(path: Path) -> Image.Image:
            image = load_rgb(path)
            if image.width != target_width:
                image = image.resize(
                    (target_width, max(1, round(image.height * target_width / image.width))),
                    Image.Resampling.LANCZOS,
                )
            return image

        images = parallel_map(prepare, paths, workers, "解码图片")
        canvas = Image.new(
            "RGB",
            (target_width, sum(i.height + label_extra for i in images) + gap * (len(images) - 1)),
            background,
        )
        draw = ImageDraw.Draw(canvas)
        y = 0
        for index, (image, path) in enumerate(zip(images, paths)):
            canvas.paste(image, (0, y))
            if labels:
                caption = path.name if label_mode == "filename" else str(index + 1)
                draw.text((4, y + image.height + 3), caption, fill="black", font=get_font(14))
            y += image.height + label_extra + gap
    else:
        sizes = parallel_map(image_size, paths, workers, "读取尺寸")
        target_height = max(height for _, height in sizes)

        def prepare(path: Path) -> Image.Image:
            image = load_rgb(path)
            if image.height != target_height:
                image = image.resize(
                    (max(1, round(image.width * target_height / image.height)), target_height),
                    Image.Resampling.LANCZOS,
                )
            return image

        images = parallel_map(prepare, paths, workers, "解码图片")
        canvas = Image.new(
            "RGB",
            (sum(i.width for i in images) + gap * (len(images) - 1), target_height + label_extra),
            background,
        )
        draw = ImageDraw.Draw(canvas)
        x = 0
        for index, (image, path) in enumerate(zip(images, paths)):
            canvas.paste(image, (x, 0))
            if labels:
                caption = path.name if label_mode == "filename" else str(index + 1)
                draw.text((x + 4, target_height + 3), caption, fill="black", font=get_font(14))
            x += image.width + gap
    return canvas


def make_grid(paths, columns, rows, cell, gap, background, labels, label_mode, workers):
    cell_width, cell_height = cell
    label_height = 22 if labels else 0
    canvas = Image.new(
        "RGB",
        (columns * cell_width + (columns - 1) * gap,
         rows * (cell_height + label_height) + (rows - 1) * gap),
        background,
    )
    draw = ImageDraw.Draw(canvas)
    text_font = get_font(13)
    real_paths = [path for path in paths if path is not None]
    fitted = parallel_map(
        lambda p: fit_image_object(load_rgb(p), cell, background),
        real_paths,
        workers,
        "解码图片",
    )
    iterator = iter(fitted)
    for index, path in enumerate(paths):
        if path is None:
            continue
        row, column = divmod(index, columns)
        x = column * (cell_width + gap)
        y = row * (cell_height + label_height + gap)
        canvas.paste(next(iterator), (x, y))
        if labels:
            caption = path.name if label_mode == "filename" else str(index + 1)
            box = draw.textbbox((0, 0), caption, font=text_font)
            text_x = x + max(0, (cell_width - (box[2] - box[0])) // 2)
            draw.text((text_x, y + cell_height + 2), caption, fill="black", font=text_font)
    return canvas


def gif_target_size(paths, width, height, workers) -> tuple[int, int]:
    if width and height:
        return width, height
    first_width, first_height = image_size(paths[0])
    if width:
        return width, max(1, round(first_height * width / first_width))
    if height:
        return max(1, round(first_width * height / first_height)), height
    sizes = parallel_map(image_size, paths, workers, "读取尺寸")
    return max(w for w, _ in sizes), max(h for _, h in sizes)


def make_gif_frames(paths, width, height, background, labels, label_mode, workers):
    target = gif_target_size(paths, width, height, workers)
    label_height = 24 if labels else 0
    text_font = get_font(14)

    def prepare(path: Path) -> Image.Image:
        image = fit_image_object(load_rgb(path), target, background)
        if not labels:
            return image
        frame = Image.new("RGB", (image.width, image.height + label_height), background)
        frame.paste(image, (0, 0))
        caption = path.name if label_mode == "filename" else ""
        if caption:
            ImageDraw.Draw(frame).text((4, image.height + 3), caption, fill="black", font=text_font)
        return frame

    frames = parallel_map(prepare, paths, workers, "解码图片")
    if labels and label_mode == "index":
        for index, frame in enumerate(frames, 1):
            ImageDraw.Draw(frame).text(
                (4, frame.height - label_height + 3), str(index), fill="black", font=text_font
            )
    return frames


def read_durations(path: Path, images: list[Path], default: float) -> list[float]:
    values: dict[str, float] = {}
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.rsplit(maxsplit=1)
        if len(parts) != 2:
            raise ValueError(f"时长文件第 {line_number} 行格式错误，应为：文件名 秒数")
        try:
            seconds = float(parts[1])
        except ValueError as exc:
            raise ValueError(f"时长文件第 {line_number} 行的秒数无效") from exc
        if seconds <= 0:
            raise ValueError(f"时长文件第 {line_number} 行的秒数必须大于0")
        values[parts[0]] = seconds
    return [values.get(path.name, default) for path in images]


def export_gif(frames, durations, output, loop, maximum, logo, watermark_text, opacity, position, optimize=False):
    processed = []
    for frame in frames:
        frame = resize_maximum(frame, maximum)
        frame = add_watermark(frame, logo, watermark_text, opacity, position)
        processed.append(frame.convert("P", palette=Image.Palette.ADAPTIVE, colors=256))
    milliseconds = [max(20, round(value * 1000)) for value in durations]
    output.parent.mkdir(parents=True, exist_ok=True)
    processed[0].save(
        output,
        save_all=True,
        append_images=processed[1:],
        duration=milliseconds,
        loop=loop,
        disposal=2,
        optimize=optimize,
    )


def export_pdf(images, output, maximum, logo, watermark_text, opacity, position, quality=90):
    pages = []
    for image in images:
        page = resize_maximum(image, maximum)
        page = add_watermark(page, logo, watermark_text, opacity, position)
        pages.append(page.convert("RGB"))
    output.parent.mkdir(parents=True, exist_ok=True)
    pages[0].save(
        output,
        "PDF",
        save_all=True,
        append_images=pages[1:],
        resolution=quality,
    )


def save_static(image, stem, output_format, quality, maximum, logo, watermark_text, opacity, position):
    image = resize_maximum(image, maximum)
    image = add_watermark(image, logo, watermark_text, opacity, position)
    output = stem.with_suffix("." + output_format)
    if output_format in {"jpg", "webp"}:
        image.save(output, quality=quality)
    else:
        image.save(output)
    return output


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def build_parser():
    parser = argparse.ArgumentParser(description="图片合并与 GIF/PDF 导出工具")
    parser.add_argument("input_dir", type=Path, help="输入图片目录")
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT, help="输出根目录")
    parser.add_argument("--output-subdir", help="完整自定义子目录名，例如 20260708_2628_fotos")
    parser.add_argument("--output-date", help="输出目录日期，格式 YYYYMMDD")
    parser.add_argument("--output-code", help="输出目录四位代码，例如 2628")
    parser.add_argument("--mode", choices=["vertical", "horizontal", "grid", "gif", "pdf", "all"], default="all")
    parser.add_argument("--grid", nargs="+", default=[], metavar="COLSxROWS")
    parser.add_argument("--cell-size", metavar="WIDTHxHEIGHT")
    parser.add_argument("--gap", type=int, default=0)
    parser.add_argument("--bg", default="white")
    parser.add_argument("--recursive", action="store_true")
    parser.add_argument("--ext", help="扩展名列表，例如 .jpg,.png")
    parser.add_argument("--quality", type=int, default=90)
    parser.add_argument("--sort", choices=["name", "type", "mtime", "ctime", "exif", "size", "random", "list"], default="name")
    parser.add_argument("--reverse", action="store_true")
    parser.add_argument("--order-file", type=Path)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--dedup", action="store_true")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--sample", type=int)
    parser.add_argument("--label", action="store_true")
    parser.add_argument("--label-mode", choices=["filename", "index"], default="filename")
    parser.add_argument("--watermark", type=Path)
    parser.add_argument("--watermark-text")
    parser.add_argument("--watermark-opacity", type=float, default=0.6)
    parser.add_argument("--watermark-position", choices=["top-left", "top-right", "bottom-left", "bottom-right", "center"], default="bottom-right")
    parser.add_argument("--max-dimension", type=int)
    parser.add_argument("--output-format", choices=["jpg", "png", "webp"], default="jpg")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--gif-duration", type=float, default=0.5, help="每张 GIF 图片默认显示秒数")
    parser.add_argument("--durations-file", type=Path, help="逐图片时长清单：文件名 秒数")
    parser.add_argument("--gif-width", type=int)
    parser.add_argument("--gif-height", type=int)
    parser.add_argument("--gif-loop", type=int, default=0, help="0表示无限循环")
    parser.add_argument("--gif-name", default="images.gif")
    parser.add_argument("--gif-optimize", action="store_true", help="启用 GIF 调色板优化（更小体积，略慢）")
    parser.add_argument("--pdf-name", default="album.pdf")
    parser.add_argument("--pdf-resolution", type=int, default=90, help="PDF 每英寸像素（DPI）")
    parser.add_argument("--workers", type=int, default=DEFAULT_MAX_WORKERS, help=f"并行解码线程数（默认 {DEFAULT_MAX_WORKERS}）")
    parser.add_argument("--no-parallel", action="store_true", help="禁用并行，等价于 --workers 1")
    parser.add_argument("--no-manifest", action="store_true", help="不写入 manifest.json")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return parser


def _write_manifest(output_dir: Path, payload: dict) -> Path:
    manifest_path = output_dir / "manifest.json"
    manifest_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return manifest_path


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    if args.gif_duration <= 0 or args.gif_loop < 0:
        print("[错误] GIF 时长必须大于0，循环次数不能小于0", file=sys.stderr)
        return 1

    workers = 1 if args.no_parallel else max(1, args.workers)
    started = time.monotonic()

    folder = args.input_dir.expanduser().resolve()
    extensions = (
        {item.strip().lower() if item.strip().startswith(".") else "." + item.strip().lower()
         for item in args.ext.split(",")}
        if args.ext else SUPPORTED_EXTENSIONS
    )

    try:
        images = list_images(folder, args.recursive, extensions)
        images = sort_images(images, args.sort, args.reverse, args.order_file, args.seed)
        if args.dedup:
            images = deduplicate(images, workers)
        if args.sample is not None:
            images = random.Random(args.seed).sample(images, min(args.sample, len(images)))
        elif args.limit is not None:
            images = images[:max(0, args.limit)]
        if not images:
            raise ValueError("没有可处理的图片")
        output_dir = build_output_dir(
            folder,
            args.output_root,
            args.output_subdir,
            args.output_date,
            args.output_code,
            create=not args.dry_run,
        )
    except (OSError, ValueError) as exc:
        print(f"[错误] {exc}", file=sys.stderr)
        return 1

    print(f"输入目录：{folder}")
    print(f"输出目录：{output_dir}")
    print(f"排序方式：{args.sort}{'（倒序）' if args.reverse else ''}")
    print(f"图片数量：{len(images)}")
    print(f"并行线程：{workers}")

    if args.dry_run:
        for index, image in enumerate(images, 1):
            print(f"{index:>4}. {image.name}")
        return 0

    if args.watermark and not args.watermark.is_file():
        print(f"[错误] 水印文件不存在：{args.watermark}", file=sys.stderr)
        return 1

    modes = {"vertical", "horizontal", "grid", "gif", "pdf"} if args.mode == "all" else {args.mode}
    outputs: list[str] = []

    try:
        if "gif" in modes:
            durations = (
                read_durations(args.durations_file, images, args.gif_duration)
                if args.durations_file else [args.gif_duration] * len(images)
            )
            frames = make_gif_frames(
                images, args.gif_width, args.gif_height, args.bg,
                args.label, args.label_mode, workers,
            )
            gif_path = output_dir / args.gif_name
            export_gif(
                frames, durations, gif_path, args.gif_loop, args.max_dimension,
                args.watermark, args.watermark_text, args.watermark_opacity,
                args.watermark_position, args.gif_optimize,
            )
            outputs.append(str(gif_path))
            print(f"[完成] GIF：{gif_path}")

        for mode in ("vertical", "horizontal"):
            if mode in modes:
                image = make_linear(images, mode, args.gap, args.bg, args.label, args.label_mode, workers)
                output = save_static(
                    image, output_dir / f"{mode}_merged", args.output_format,
                    args.quality, args.max_dimension, args.watermark,
                    args.watermark_text, args.watermark_opacity,
                    args.watermark_position,
                )
                outputs.append(str(output))
                print(f"[完成] {output}")

        if "grid" in modes:
            if not args.grid:
                print("[提示] grid 模式需要 --grid，例如 --grid 3x6", file=sys.stderr)
            else:
                if args.cell_size:
                    cell = parse_xy(args.cell_size, "格子尺寸")
                else:
                    sizes = parallel_map(image_size, images, workers, "读取尺寸")
                    cell = (max(w for w, _ in sizes), max(h for _, h in sizes))
                for columns, rows in [parse_xy(value, "矩阵规格") for value in args.grid]:
                    capacity = columns * rows
                    for page_number, start in enumerate(range(0, len(images), capacity), 1):
                        current = images[start:start + capacity]
                        padded = current + [None] * (capacity - len(current))
                        suffix = "" if len(images) <= capacity else f"_p{page_number:02d}"
                        image = make_grid(
                            padded, columns, rows, cell, args.gap, args.bg,
                            args.label, args.label_mode, workers,
                        )
                        output = save_static(
                            image, output_dir / f"grid_{columns}x{rows}{suffix}",
                            args.output_format, args.quality, args.max_dimension,
                            args.watermark, args.watermark_text,
                            args.watermark_opacity, args.watermark_position,
                        )
                        outputs.append(str(output))
                        print(f"[完成] {output}")

        if "pdf" in modes:
            loaded = parallel_map(load_rgb, images, workers, "解码图片")
            pdf_path = output_dir / args.pdf_name
            export_pdf(
                loaded, pdf_path, args.max_dimension, args.watermark,
                args.watermark_text, args.watermark_opacity,
                args.watermark_position, args.pdf_resolution,
            )
            outputs.append(str(pdf_path))
            print(f"[完成] PDF：{pdf_path}")
    except (OSError, ValueError) as exc:
        print(f"[处理错误] {exc}", file=sys.stderr)
        return 1

    elapsed = time.monotonic() - started
    if not args.no_manifest:
        manifest_path = _write_manifest(
            output_dir,
            {
                "tool": "batch-image-merge",
                "version": __version__,
                "generated_at": datetime_module.datetime.now().isoformat(timespec="seconds"),
                "input_dir": str(folder),
                "output_dir": str(output_dir),
                "image_count": len(images),
                "images": [str(p) for p in images],
                "mode": args.mode,
                "sort": args.sort,
                "workers": workers,
                "elapsed_seconds": round(elapsed, 3),
                "outputs": outputs,
            },
        )
        print(f"[清单] {manifest_path}")

    print(f"全部完成，用时 {elapsed:.2f}s。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
