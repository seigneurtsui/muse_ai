"""Default ebook discovery/conversion, adapted from the supplied script.

No Python dependencies. External converters are required only for their formats.
"""
import hashlib
import re
import shutil
import subprocess
from pathlib import Path

SUPPORTED_FORMATS = {".epub", ".pdf", ".mobi", ".azw3", ".docx", ".txt"}


def find_tool(name, extra_paths=()):
    return shutil.which(name) or next((p for p in extra_paths if Path(p).is_file()), None)


def find_calibre():
    calibre_home = str(Path.home() / "workspace" / "tools" / "calibre" / "ebook-convert")
    return find_tool("ebook-convert", ("/Applications/calibre.app/Contents/MacOS/ebook-convert", calibre_home))


def find_ebooks(source_dir, output_dir):
    source, output = Path(source_dir).resolve(), Path(output_dir).resolve()
    if source == output or output in source.parents:
        raise ValueError("源目录不能位于输出目录内，以免把摘要当作电子书")
    return sorted(
        p for p in source.rglob("*")
        if p.is_file() and p.suffix.lower() in SUPPORTED_FORMATS
        and output not in p.resolve().parents
        and (p.resolve() == source or source in p.resolve().parents)
    )


def get_epub_title(path):
    """Prefer the EPUB's embedded dc:title over the filename.

    Falls back to None when the package metadata is missing or unreadable.
    Parenthetical marketing suffixes (common in Chinese EPUBs) are stripped
    so the note title stays short and meaningful.
    """
    try:
        import zipfile
        import xml.etree.ElementTree as ET
        with zipfile.ZipFile(path) as zf:
            try:
                container = zf.read("META-INF/container.xml")
            except KeyError:
                return None
            root = ET.fromstring(container)
            ns = {"c": "urn:oasis:names:tc:opendocument:xmlns:container"}
            rootfile = root.find(".//c:rootfile", ns)
            if rootfile is None:
                return None
            opf = ET.fromstring(zf.read(rootfile.get("full-path")))
            for elem in opf.iter("{http://purl.org/dc/elements/1.1/}title"):
                text = (elem.text or "").strip()
                if not text:
                    continue
                main = re.split(r"[（(]", text, maxsplit=1)[0].strip()
                return main or text
    except Exception:
        return None
    return None


def get_book_name(path):
    name = None
    if str(path).lower().endswith(".epub"):
        name = get_epub_title(path)
    if not name:
        name = Path(path).stem
    name = re.sub(r'[<>:"/\\|?*]', "", name).strip().strip(".")
    return name or "untitled"


def source_signature(path):
    path = Path(path).resolve()
    stat = path.stat()
    identity = f"{path}\0{stat.st_size}\0{stat.st_mtime_ns}"
    return hashlib.sha256(identity.encode()).hexdigest()


def is_scanned_pdf(txt_path):
    with Path(txt_path).open(encoding="utf-8", errors="ignore") as stream:
        text = stream.read(50000)
    return not text.strip() or sum(c.isalnum() for c in text) / len(text) < 0.3


def run_converter(command, timeout):
    result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    if result.returncode:
        if "DRMError" in result.stderr:
            raise RuntimeError("电子书带 DRM 加密，Calibre 无法提取正文；请提供可正常导出的无加密 EPUB、PDF 或 TXT")
        raise RuntimeError(f"{Path(command[0]).name} 转换失败：{result.stderr.strip()[-1500:]}")


def ocr_pdf(input_path, output_dir):
    venv_ocr = str(Path.home() / "workspace" / "venvs" / "ebook-tools" / "bin" / "ocrmypdf")
    ocr = find_tool("ocrmypdf", (venv_ocr,))
    pdftotext = find_tool("pdftotext")
    if not ocr or not pdftotext:
        raise RuntimeError("扫描 PDF 需要 ocrmypdf、Tesseract 的 chi_sim/eng 语言包及 pdftotext")
    searchable = Path(output_dir) / "searchable.pdf"
    target = Path(output_dir) / "source.txt"
    # Blank scans give no reliable language evidence: retain Chinese + English.
    run_converter([ocr, "--language", "chi_sim+eng", "--force-ocr", "--output-type", "pdf",
                   str(input_path), str(searchable)], 600)
    run_converter([pdftotext, str(searchable), str(target)], 60)
    searchable.unlink(missing_ok=True)
    if is_scanned_pdf(target):
        raise RuntimeError("OCR 未能提取可用正文")
    return target


def convert_to_txt(input_path, output_dir, calibre_path=None):
    source = Path(input_path)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    target = output / "source.txt"
    if source.suffix.lower() == ".txt":
        raw = source.read_bytes()
        for encoding in ("utf-8-sig", "utf-16" if raw.startswith((b'\xff\xfe', b'\xfe\xff')) else "gb18030"):
            try:
                text = raw.decode(encoding)
                break
            except UnicodeError:
                continue
        else:
            raise RuntimeError("TXT 编码无法识别，请先转换为 UTF-8")
        target.write_text(text, encoding="utf-8")
        return target

    errors = []
    if source.suffix.lower() == ".pdf":
        pdftotext = find_tool("pdftotext")
        if pdftotext:
            try:
                run_converter([pdftotext, str(source), str(target)], 60)
                if target.exists() and not is_scanned_pdf(target):
                    return target
            except (OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
                errors.append(str(exc))
        try:
            return ocr_pdf(source, output)
        except (OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
            errors.append(str(exc))

    if calibre_path:
        try:
            run_converter([calibre_path, str(source), str(target), "--txt-output-encoding=utf-8"], 300)
            if target.exists() and not is_scanned_pdf(target):
                return target
            errors.append("Calibre 未能提取可用正文")
        except (OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
            errors.append(str(exc))
    else:
        errors.append("未找到 Calibre (ebook-convert)")
    raise RuntimeError("；".join(errors))
