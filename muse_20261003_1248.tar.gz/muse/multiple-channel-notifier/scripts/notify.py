#!/usr/bin/env python3
"""Configurable notifications, based on multiple_channel_notifier.py; stdlib only."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from email.message import EmailMessage
from email.utils import formataddr, formatdate, make_msgid
from html import escape
import ipaddress
import json
import os
from pathlib import Path
import random
import re
import smtplib
import socket
import ssl
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlsplit
from urllib.request import HTTPRedirectHandler, HTTPSHandler, ProxyHandler, Request, build_opener

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG = ROOT / "config.json"
DEFAULT_ENV = Path.home() / ".config/omnirush/.env"
TYPES = {"qq_email", "smtp", "bark", "wxpusher", "pushplus", "resend", "telegram", "webhook"}
NAME = re.compile(r"[a-zA-Z0-9_-]{1,64}\Z")
ENV = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")
VARIABLE = re.compile(r"\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}")
MAX_RESPONSE = 1024 * 1024


class ConfigError(Exception):
    """Only locally generated, non-sensitive diagnostic messages belong here."""


class SendError(Exception):
    def __init__(self, message, retryable=False, retry_after=None):
        super().__init__(message)
        self.retryable = retryable
        self.retry_after = retry_after


@dataclass
class Delivery:
    name: str
    kind: str
    cfg: dict
    payload: object
    url: str = ""
    headers: dict | None = None
    timeout: float = 10
    retries: int = 0


def number(value, label, low, high, integer=False):
    expected = (int,) if integer else (int, float)
    if isinstance(value, bool) or not isinstance(value, expected) or not low <= value <= high:
        raise ConfigError(f"{label} must be {'an integer' if integer else 'a number'} in [{low}, {high}]")
    return value


def flag(obj, key, default=False):
    value = obj.get(key, default)
    if type(value) is not bool:
        raise ConfigError(f"{key} must be true or false")
    return value


def text(value, label, required=True):
    if not isinstance(value, str) or (required and not value.strip()):
        raise ConfigError(f"{label} must be a {'non-empty ' if required else ''}string")
    return value


def header(value, label):
    value = text(value, label)
    if any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise ConfigError(f"{label} contains invalid control characters")
    return value


def referenced_env(value):
    if isinstance(value, str):
        return set(ENV.findall(value))
    if isinstance(value, (dict, list)):
        children = value.values() if isinstance(value, dict) else value
        return set().union(*(referenced_env(v) for v in children))
    return set()


def parse_dotenv(source, wanted):
    """Read only requested keys. Never source/eval/expand shell expressions."""
    values = {}
    for line in source.splitlines():
        stripped = line.strip()
        if stripped.startswith("export "):
            stripped = stripped[7:].lstrip()
        key, sep, raw = stripped.partition("=")
        key = key.strip()
        if key not in wanted or not sep:
            continue
        if key in values:
            raise ConfigError(f"duplicate .env variable {key}")
        raw = raw.strip()
        if raw.startswith('"'):
            try:
                value, end = json.JSONDecoder().raw_decode(raw)
                trailing = raw[end:].strip()
                if not isinstance(value, str) or (trailing and not trailing.startswith("#")):
                    raise ValueError
            except ValueError:
                raise ConfigError(f"invalid double-quoted .env value for {key}; use JSON string escapes") from None
        elif raw.startswith("'"):
            end = raw.find("'", 1)
            if end < 0 or (raw[end + 1:].strip() and not raw[end + 1:].strip().startswith("#")):
                raise ConfigError(f"invalid single-quoted .env value for {key}")
            value = raw[1:end]
        else:
            value = "" if raw.startswith("#") else re.split(r"\s+#", raw, maxsplit=1)[0].strip()
        values[key] = value
    return values


def resolve_environment(wanted, path):
    values = {}
    needed = wanted - os.environ.keys()
    if needed and path.exists():
        if path.stat().st_mode & 0o077:
            raise ConfigError(".env permissions are too broad; use chmod 600 on the configured .env file")
        values = parse_dotenv(path.read_text(encoding="utf-8"), needed)
    values.update({key: os.environ[key] for key in wanted if key in os.environ})
    return values


def expand_env(value, environ=None):
    environ = os.environ if environ is None else environ
    if isinstance(value, str):
        def replace(match):
            result = environ.get(match[1])
            if not result:
                raise ConfigError(f"environment variable {match[1]} is missing or empty")
            return result
        return ENV.sub(replace, value)
    if isinstance(value, list):
        return [expand_env(v, environ) for v in value]
    if isinstance(value, dict):
        return {k: expand_env(v, environ) for k, v in value.items()}
    return value


def render(value, variables):
    if isinstance(value, str):
        def replace(match):
            if match[1] not in variables:
                raise ConfigError(f"template variable {match[1]} is missing")
            return str(variables[match[1]])
        return VARIABLE.sub(replace, value)
    if isinstance(value, dict):
        return {k: render(v, variables) for k, v in value.items()}
    if isinstance(value, list):
        return [render(v, variables) for v in value]
    return value


def recipients(value, label):
    if isinstance(value, str):
        value = [v for v in re.split(r"[,，;；\s]+", value.strip()) if v]
    if not isinstance(value, list) or not value:
        raise ConfigError(f"{label} needs at least one recipient")
    result = []
    for item in value:
        item = header(item, label)
        if item not in result:
            result.append(item)
    return result


def load_config(path):
    try:
        config = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, UnicodeError):
        raise ConfigError("cannot read configuration; use init or repair the JSON file") from None
    if not isinstance(config, dict) or not isinstance(config.get("channels"), dict):
        raise ConfigError("configuration must contain a channels object")
    flag(config, "enabled")
    number(config.get("workers", 4), "workers", 1, 16, True)
    number(config.get("timeout", 10), "timeout", 0.1, 120)
    number(config.get("retries", 0), "retries", 0, 3, True)
    for name, cfg in config["channels"].items():
        if not NAME.fullmatch(name) or not isinstance(cfg, dict):
            raise ConfigError("channel names must be 1-64 letters, digits, underscores or hyphens; values must be objects")
        flag(cfg, "enabled")
        if not isinstance(cfg.get("type", name), str) or cfg.get("type", name) not in TYPES:
            raise ConfigError(f"channel {name} needs a supported type")
    profiles = config.get("profiles", {})
    if not isinstance(profiles, dict):
        raise ConfigError("profiles must be an object")
    for name, members in profiles.items():
        if not NAME.fullmatch(name) or not isinstance(members, list) or any(not isinstance(m, str) or m not in config["channels"] for m in members):
            raise ConfigError("profiles need valid names and arrays of existing channel names")
    return config


def csv_names(value):
    return list(dict.fromkeys(v.strip() for v in (value or "").split(",") if v.strip()))


def select_channels(config, channels=None, profile=None, skip=None):
    available = config["channels"]
    if profile is not None:
        if profile not in config.get("profiles", {}):
            raise ConfigError("unknown profile")
        selected = list(dict.fromkeys(config["profiles"][profile]))
    elif channels is not None:
        selected = csv_names(channels)
    else:
        selected = [name for name, cfg in available.items() if cfg.get("enabled", False)]
    excluded = csv_names(skip)
    if any(name not in available for name in selected + excluded):
        raise ConfigError("unknown channel in selection or skip list")
    selected = [name for name in selected if name not in excluded]
    if any(not available[name].get("enabled", False) for name in selected):
        raise ConfigError("explicit selection includes a disabled channel; enable it in configuration first")
    return selected


def validate_url(url):
    url = text(url, "URL")
    try:
        parsed = urlsplit(url)
        port = parsed.port
    except ValueError:
        raise ConfigError("invalid URL") from None
    if not parsed.hostname or parsed.username is not None or parsed.password is not None or parsed.fragment or any(c.isspace() or ord(c) < 32 for c in url):
        raise ConfigError("URL needs a host and must not contain userinfo, fragments or whitespace")
    if port == 0:
        raise ConfigError("invalid URL port")
    local = parsed.hostname == "localhost"
    try:
        local = local or ipaddress.ip_address(parsed.hostname).is_loopback
    except ValueError:
        pass
    if parsed.scheme != "https" and not (parsed.scheme == "http" and local):
        raise ConfigError("URLs require HTTPS (HTTP is allowed only for loopback tests)")
    return url


def merge_options(cfg, payload):
    options = cfg.get("options", {})
    if not isinstance(options, dict):
        raise ConfigError("options must be an object")
    # Authoritative message, credentials and recipient fields cannot be overwritten.
    return {**options, **payload}


def prepare(name, cfg, config, title, content, variables, environ=None):
    kind = cfg.get("type", name)
    cfg = expand_env(cfg, environ)
    timeout = number(cfg.get("timeout", config.get("timeout", 10)), "timeout", 0.1, 120)
    retries = number(cfg.get("retries", config.get("retries", 0)), "retries", 0, 3, True)
    headers = {"Content-Type": "application/json", "User-Agent": "omnirush-multiple-channel-notifier/1.0"}
    url = ""
    if kind in {"qq_email", "smtp"}:
        user = header(cfg.get("user"), "user")
        text(cfg.get("password"), "password")
        to = recipients(cfg.get("recipients"), "recipients")
        sender = header(cfg.get("from_email", user), "from_email")
        from_name = header(cfg.get("from_name", "OmniRush"), "from_name")
        header(title, "email title")
        cfg["host"] = header(cfg.get("host", "smtp.qq.com" if kind == "qq_email" else ""), "host")
        cfg["security"] = cfg.get("security", "ssl")
        if not isinstance(cfg["security"], str) or cfg["security"] not in {"ssl", "starttls"}:
            raise ConfigError("SMTP security must be ssl or starttls")
        cfg["port"] = number(cfg.get("port", 465 if cfg["security"] == "ssl" else 587), "port", 1, 65535, True)
        cfg["recipients"] = to
        cfg["from_email"] = sender
        msg = EmailMessage()
        msg["Subject"] = title
        msg["From"] = formataddr((from_name, sender))
        msg["To"] = ", ".join(to)
        msg["Date"] = formatdate(localtime=True)
        msg["Message-ID"] = make_msgid()
        msg.set_content(content)
        msg.add_alternative(escape(content).replace("\n", "<br>\n"), subtype="html")
        return Delivery(name, kind, cfg, msg, timeout=timeout, retries=0)
    if kind == "bark":
        keys = recipients(cfg.get("device_keys", cfg.get("device_key")), "device_keys")
        url = text(cfg.get("url", "https://api.day.app"), "url").rstrip("/") + "/push"
        payload = merge_options(cfg, {"title": title, "body": content, "device_keys": keys})
    elif kind == "wxpusher":
        token = text(cfg.get("token"), "token")
        uids = recipients(cfg.get("uids", cfg.get("uid")), "uids")
        url = cfg.get("endpoint", "https://wxpusher.zjiecode.com/api/send/message")
        payload = merge_options(cfg, {"appToken": token, "content": content, "summary": title, "uids": uids})
        payload.setdefault("contentType", 3)
    elif kind == "pushplus":
        url = cfg.get("endpoint", "https://www.pushplus.plus/send")
        payload = merge_options(cfg, {"token": text(cfg.get("token"), "token"), "title": title, "content": content})
        payload.setdefault("template", "markdown")
    elif kind == "resend":
        url = cfg.get("endpoint", "https://api.resend.com/emails")
        headers["Authorization"] = "Bearer " + header(cfg.get("api_key"), "api_key")
        payload = merge_options(cfg, {
            "from": header(cfg.get("from_email", "onboarding@resend.dev"), "from_email"),
            "to": recipients(cfg.get("to_email", cfg.get("recipients")), "to_email"),
            "subject": title, "text": content, "html": escape(content).replace("\n", "<br>\n"),
        })
    elif kind == "telegram":
        token = text(cfg.get("bot_token"), "bot_token")
        chat_id = cfg.get("chat_id")
        if type(chat_id) is int:
            chat_id = str(chat_id)
        text(chat_id, "chat_id")
        combined = title + "\n" + content
        if len(combined.encode("utf-16-le")) // 2 > 4096:
            raise ConfigError("Telegram message exceeds 4096 UTF-16 units; shorten or split it explicitly")
        url = cfg.get("api_base", "https://api.telegram.org").rstrip("/") + "/bot" + quote(token, safe=":") + "/sendMessage"
        payload = merge_options(cfg, {"chat_id": chat_id, "text": escape(combined), "parse_mode": "HTML"})
    elif kind == "webhook":
        url = cfg.get("url")
        payload = render(cfg.get("payload", {"title": "{{title}}", "content": "{{content}}"}), {**variables, "title": title, "content": content})
        if not isinstance(payload, (dict, list)):
            raise ConfigError("webhook payload must be a JSON object or array")
        extra_headers = cfg.get("headers", {})
        if not isinstance(extra_headers, dict):
            raise ConfigError("headers must be an object")
        for key, value in extra_headers.items():
            if not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", key) or key.lower() in {"host", "content-length", "transfer-encoding"}:
                raise ConfigError("invalid or reserved webhook header name")
            headers[key] = header(value, "header value")
        success = cfg.get("success")
        if success is not None and (not isinstance(success, dict) or not isinstance(success.get("path"), str) or not success["path"] or "equals" not in success):
            raise ConfigError("webhook success needs path and equals")
    else:
        raise ConfigError("unsupported channel type")
    validate_url(url)
    try:
        encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (ValueError, TypeError, UnicodeError):
        raise ConfigError("payload cannot be encoded as JSON") from None
    return Delivery(name, kind, cfg, encoded, url, headers, timeout, retries)


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def check_response(kind, data, cfg):
    if not isinstance(data, dict):
        raise SendError("provider returned invalid JSON structure")
    if kind == "telegram":
        ok = data.get("ok") is True
    elif kind == "resend":
        ok = isinstance(data.get("id"), str) and bool(data["id"])
    else:
        expected = 1000 if kind == "wxpusher" else 200
        ok = type(data.get("code")) is int and data["code"] == expected
        if ok and kind == "wxpusher":
            entries = data.get("data")
            ok = isinstance(entries, list) and bool(entries) and all(
                isinstance(item, dict) and type(item.get("code")) is int and item["code"] == 1000 for item in entries
            )
    if not ok:
        raise SendError("provider rejected the request (possibly a partial recipient failure); response withheld for privacy")


def create_tls_context():
    """Use verified system trust when a standalone Python has no default CA store."""
    context = ssl.create_default_context()
    if not (os.environ.get("SSL_CERT_FILE") or os.environ.get("SSL_CERT_DIR")) and context.cert_store_stats()["x509_ca"] == 0:
        for candidate in ("/etc/ssl/cert.pem", "/etc/ssl/certs/ca-certificates.crt", "/etc/pki/tls/certs/ca-bundle.crt"):
            if Path(candidate).is_file():
                context.load_verify_locations(cafile=candidate)
                break
    return context


def send_http(delivery):
    request = Request(delivery.url, data=delivery.payload, headers=delivery.headers, method="POST")
    # Do not forward token-bearing requests to a redirected endpoint.
    handlers = [NoRedirect()]
    if urlsplit(delivery.url).scheme == "https":
        handlers.append(HTTPSHandler(context=create_tls_context()))
    if urlsplit(delivery.url).scheme == "http":
        handlers.append(ProxyHandler({}))  # loopback testing never goes through an external proxy
    opener = build_opener(*handlers)
    try:
        with opener.open(request, timeout=delivery.timeout) as response:
            if not 200 <= response.status < 300:
                raise SendError(f"HTTP {response.status}")
            body = response.read(MAX_RESPONSE + 1)
    except HTTPError as exc:
        retry_after = None
        value = exc.headers.get("Retry-After", "") if exc.headers else ""
        if value.isdigit() and len(value) < 10:
            retry_after = int(value)
        status = exc.code
        exc.close()
        raise SendError(f"HTTP {status}; response withheld for privacy", status in {429, 500, 502, 503, 504}, retry_after) from None
    if len(body) > MAX_RESPONSE:
        raise SendError("response exceeded 1 MiB limit")
    if delivery.kind == "webhook" and delivery.cfg.get("success") is None:
        return
    try:
        data = json.loads(body)
    except (ValueError, UnicodeError):
        raise SendError("provider returned invalid JSON") from None
    if delivery.kind == "webhook":
        rule = delivery.cfg["success"]
        current = data
        for key in rule["path"].split("."):
            if not isinstance(current, dict) or key not in current:
                raise SendError("webhook success field is missing")
            current = current[key]
        if type(current) is not type(rule["equals"]) or current != rule["equals"]:
            raise SendError("webhook success condition failed")
    else:
        check_response(delivery.kind, data, delivery.cfg)


def send_smtp(delivery):
    cfg = delivery.cfg
    context = create_tls_context()
    if cfg["security"] == "ssl":
        client = smtplib.SMTP_SSL(cfg["host"], cfg["port"], timeout=delivery.timeout, context=context)
    else:
        client = smtplib.SMTP(cfg["host"], cfg["port"], timeout=delivery.timeout)
    with client:
        if cfg["security"] == "starttls":
            client.ehlo()
            client.starttls(context=context)
            client.ehlo()
        client.login(cfg["user"], cfg["password"])
        refused = client.send_message(delivery.payload, from_addr=cfg["from_email"], to_addrs=cfg["recipients"])
        if refused:
            raise SendError("SMTP accepted only some recipients; do not resend to the entire list")


def deliver(delivery):
    start = time.monotonic()
    result = {"channel": delivery.name, "type": delivery.kind, "status": "failed", "attempts": 0}
    for attempt in range(delivery.retries + 1):
        result["attempts"] = attempt + 1
        try:
            if delivery.kind in {"qq_email", "smtp"}:
                send_smtp(delivery)
            else:
                send_http(delivery)
            result.update(status="accepted", message="provider accepted request; final delivery not verified")
            break
        except SendError as exc:
            result["message"] = str(exc)
            if exc.retryable and attempt < delivery.retries:
                delay = max(exc.retry_after or 0, 0.5 * 2 ** attempt + random.uniform(0, 0.2))
                if delay <= 30:
                    time.sleep(delay)
                    continue
            break
        except smtplib.SMTPAuthenticationError:
            result["message"] = "SMTP authentication failed"
            break
        except (TimeoutError, socket.timeout):
            result["message"] = "network timeout; delivery unknown, not automatically retried"
            break
        except (URLError, OSError, smtplib.SMTPException) as exc:
            reason = exc.reason if isinstance(exc, URLError) else exc
            if isinstance(reason, ssl.SSLCertVerificationError):
                result["message"] = "TLS certificate verification failed before message submission; check the CA trust store"
            else:
                result["message"] = "network/TLS/SMTP failure; delivery unknown, raw error withheld"
            break
        except Exception:
            # Providers can echo secrets in errors; never expose exception text or a traceback.
            result["message"] = "unexpected send failure; details withheld for privacy"
            break
    result["elapsed_ms"] = round((time.monotonic() - start) * 1000)
    return result


def dispatch(config, names, title, content, variables=None, dry_run=False, env_file=DEFAULT_ENV):
    if not config.get("enabled", False):
        return {"ok": True, "status": "disabled", "accepted": 0, "results": [], "message": "global switch is off; nothing sent"}
    if not names:
        raise ConfigError("no enabled channels selected")
    # Build every request before starting any network IO: configuration errors cannot cause partial sends.
    deliveries = []
    wanted = referenced_env([config["channels"][name] for name in names])
    environ = resolve_environment(wanted, env_file)
    for name in names:
        try:
            deliveries.append(prepare(name, config["channels"][name], config, title, content, variables or {}, environ))
        except ConfigError as exc:
            raise ConfigError(f"{name}: {exc}") from None
        except (TypeError, ValueError, AttributeError, KeyError, UnicodeError):
            raise ConfigError(f"{name}: invalid channel configuration") from None
    if dry_run:
        results = [{"channel": d.name, "type": d.kind, "status": "ready", "attempts": 0} for d in deliveries]
    else:
        with ThreadPoolExecutor(max_workers=min(config.get("workers", 4), len(deliveries))) as pool:
            results = list(pool.map(deliver, deliveries))
    return {"ok": all(r["status"] != "failed" for r in results), "status": "dry_run" if dry_run else "complete",
            "accepted": sum(r["status"] == "accepted" for r in results), "results": results}


def emit(report):
    print(json.dumps(report, ensure_ascii=False, indent=2))


def init_config(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (ROOT / "assets/config.example.json").read_text(encoding="utf-8")
    # O_EXCL refuses to overwrite existing files, including symlinks; secrets get mode 0600.
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        raise ConfigError("configuration already exists; init will not overwrite it") from None
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        stream.write(data)
    return {"ok": True, "status": "initialized", "message": "created disabled configuration with permissions 0600"}


def parser():
    result = argparse.ArgumentParser(description="Multi-channel notifications (Python standard library only)")
    result.add_argument("--config", type=Path, default=None, help="config JSON path (put before subcommand)")
    result.add_argument("--env-file", type=Path, default=None, help="shared .env path (put before subcommand)")
    sub = result.add_subparsers(dest="command", required=True)
    sub.add_parser("init", help="create a disabled example config; never overwrite")
    sub.add_parser("list", help="list channel names/types/switches without revealing secrets")
    for name in ("check", "send"):
        command = sub.add_parser(name, help="offline validation" if name == "check" else "send a notification")
        targets = command.add_mutually_exclusive_group()
        targets.add_argument("--channels", help="comma-separated channel instance names")
        targets.add_argument("--profile", help="named channel group")
        command.add_argument("--skip", help="comma-separated channel names to exclude")
        command.add_argument("--title")
        body = command.add_mutually_exclusive_group()
        body.add_argument("--content")
        body.add_argument("--content-file", type=Path, help="UTF-8 text file; '-' reads stdin")
        command.add_argument("--var", action="append", default=[], metavar="NAME=VALUE")
        if name == "send":
            command.add_argument("--dry-run", action="store_true", help="validate without network or message/credential output")
    return result


def main(argv=None):
    args = parser().parse_args(argv)
    path = (args.config or Path(os.environ.get("OMNIRUSH_NOTIFY_CONFIG", str(DEFAULT_CONFIG)))).expanduser()
    env_file = (args.env_file or Path(os.environ.get("OMNIRUSH_NOTIFY_ENV_FILE", str(DEFAULT_ENV)))).expanduser()
    try:
        if args.command == "init":
            report = init_config(path)
        else:
            config = load_config(path)
            if args.command == "list":
                report = {"ok": True, "enabled": config.get("enabled", False),
                          "channels": [{"name": name, "type": cfg.get("type", name), "enabled": cfg.get("enabled", False)} for name, cfg in config["channels"].items()],
                          "profiles": config.get("profiles", {})}
            else:
                names = select_channels(config, args.channels, args.profile, args.skip)
                variables = {}
                for value in args.var:
                    key, sep, val = value.partition("=")
                    if not sep or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key) or key in {"title", "content"}:
                        raise ConfigError("--var requires NAME=VALUE; title/content are reserved")
                    variables[key] = val
                message = config.get("message", {})
                if not isinstance(message, dict):
                    raise ConfigError("message must be an object")
                title = args.title if args.title is not None else message.get("title")
                content = args.content if args.content is not None else message.get("content")
                if args.content_file is not None:
                    content = sys.stdin.read() if str(args.content_file) == "-" else args.content_file.expanduser().read_text(encoding="utf-8")
                if args.command == "check":
                    title = "Configuration check" if title is None else title
                    content = "No message is sent." if content is None else content
                title = render(text(title, "title"), variables)
                content = render(text(content, "content"), variables)
                text(title, "rendered title")
                text(content, "rendered content")
                report = dispatch(config, names, title, content, variables, args.command == "check" or args.dry_run, env_file)
        emit(report)
        return 0 if report["ok"] else 1
    except ConfigError as exc:
        emit({"ok": False, "status": "configuration_error", "message": str(exc)})
        return 2
    except (OSError, UnicodeError):
        emit({"ok": False, "status": "local_error", "message": "cannot read/write the local configuration or content file"})
        return 2
    except KeyboardInterrupt:
        emit({"ok": False, "status": "interrupted", "message": "interrupted; some requests may already have been accepted"})
        return 130


if __name__ == "__main__":
    sys.exit(main())
