# Skill: mountain-climber

## Description
登山路线规划与可视化工具。基于 OpenStreetMap + Leaflet 生成交互式登山路线 HTML 页面，支持动态路线演示（启动/停止动画）、途经景点标记、海拔/难度/距离信息展示。

当用户提到「爬山路线」「登山规划」「徒步路线」「登山地图」「登山路线图」「怎么爬XX山」「XX山登山攻略」时触发。

## Defaults
- **Output path**: `~/Downloads/mountain-climber/`
- **Color theme**: Dark background (`#0a1929`), orange accent (`#ff9800`), green trail (`#4caf50`)
- **Tiles**: OpenStreetMap (default)
- **Animation style**: Smooth hiker marker moving along route polyline

## Workflow

### Step 1: 收集需求
Ask user for:
1. Mountain name (e.g., 峨眉山, 泰山, 黄山, 华山)
2. Starting trailhead (default: main/classic route)
3. Trip type: 一日登山 / 多日露营
4. Any specific scenic spots they want to include

### Step 2: 联网调研登山路线
Use `websearch` to research the mountain's climbing routes:

Search for:
- `{mountain} 登山路线 攻略`
- `{mountain} 徒步路线 轨迹`
- `{mountain} 景点 沿途`
- `{mountain} 海拔 距离 难度`

Extract:
- Main climbing route coordinates (trailhead → summit via key waypoints)
- Key scenic spots along the route (name, description, approximate location)
- Total distance, elevation gain, estimated hiking time
- Difficulty level, best season, gear recommendations
- Fee/ticket info, opening hours

Use known landmark coordinates (or query OSM nominatim via `https://nominatim.openstreetmap.org/search?q={mountain}+{scenic_spot}+china&format=json`) to build the coordinate arrays for each scenic spot.

### Step 3: 构建路线数据
Build the route as a sequence of waypoints:
```json
{
  "mountain": "峨眉山",
  "elevation": "3099m",
  "totalDistance": "~50km（纯徒步）",
  "totalElevationGain": "~2500m",
  "estimatedTime": "2天（全程徒步）",
  "difficulty": "★★★★☆",
  "bestSeason": "春秋（4-6月, 9-11月）",
  "fee": "门票160元",
  "routeSegments": [
    {
      "from": "报国寺",
      "to": "伏虎寺",
      "distance": "1km",
      "elevationGain": "100m",
      "time": "30min",
      "lat": 29.567, "lng": 103.485,
      "scenicSpots": ["报国寺", "凤凰亭"]
    },
    ...
  ],
  "scenicSpots": [
    { "name": "报国寺", "lat": 29.567, "lng": 103.485, "desc": "...", "type": "temple" }
  ],
  "trailCoords": [
    [29.567, 103.485],
    [29.570, 103.488],
    ...
  ]
}
```

Ensure at least 30-50 `trailCoords` points along the route for smooth animation. Interpolate waypoints between known scenic spots using linear interpolation every ~200m.

### Step 4: 生成交互式 HTML 页面
Use `{skillDir}/references/templates/climb-skeleton.html` as template.

**Template variables** to replace:

| Variable | Description | Example |
|----------|-------------|---------|
| `{{MOUNTAIN_NAME}}` | Mountain name | 峨眉山 |
| `{{MOUNTAIN_EMOJI}}` | Emoji | 🏔️ |
| `{{ELEVATION}}` | Summit elevation | 3099m |
| `{{TOTAL_DISTANCE}}` | Total route distance | ~50km |
| `{{ELEVATION_GAIN}}` | Total elevation gain | ~2500m |
| `{{ESTIMATED_TIME}}` | Estimated hiking time | 2天 |
| `{{DIFFICULTY}}` | Difficulty stars | ★★★★☆ |
| `{{BEST_SEASON}}` | Best season | 春秋 |
| `{{FEE_INFO}}` | Ticket/fee info | 门票160元 |
| `{{MAP_CENTER_LAT}}` | Map center lat | 29.567 |
| `{{MAP_CENTER_LNG}}` | Map center lng | 103.485 |
| `{{MAP_ZOOM}}` | Initial zoom | 13 |
| `{{TRAIL_COORDS}}` | `[{lat, lng}, ...]` JS array | — |
| `{{SCENIC_SPOTS}}` | `[{name, lat, lng, desc, type}, ...]` | — |
| `{{SEGMENTS_DATA}}` | `[{from, to, dist, gain, time}, ...]` for legend | — |
| `{{HIKER_ICON_URL}}` | Hiker marker emoji using Leaflet divIcon | — |
| `{{ROUTE_COLOR}}` | Trail polyline color | `#4caf50` |
| `{{ANIMATION_SPEED}}` | Hiker speed (ms per segment) | `50` |
| `{{GEAR_LIST}}` | HTML gear checklist items | — |

**Required features (standard format):**

| Feature | Implementation |
|---------|---------------|
| 🗺️ **Map** | Leaflet + OpenStreetMap tiles, zoom controls |
| 🟢 **Route trail** | Thick green polyline (weight 4, opacity 0.8) |
| 🚶 **Animated hiker** | Circular marker moving along trailCoords; Start/Stop button |
| 📍 **Scenic spot markers** | Custom divIcon with numbered colored markers |
| 🖱️ **Marker click → popup** | Shows name, description, type icon |
| 📊 **Route legend/segments** | Sidebar or bottom panel showing segment breakdown |
| 📈 **Progress indicator** | Shows "当前：3/15 段 总进度 20%" during animation |
| ▶️/⏹️ **Animation controls** | Start / Stop / Reset buttons with clean styling |
| 🏔️ **Mountain info header** | Name, elevation, difficulty, distance, time, fee |
| 🎒 **Gear checklist** | Mountain-specific packing list |
| 🖤 **Dark theme** | `#0a1929` background, orange accent `#ff9800` |

**Animation logic (JavaScript in template):**

```js
let animating = false;
let currentIdx = 0;
let animTimer = null;

function startAnimation() {
  if (animating) return;
  animating = true;
  hikerMarker.setLatLng([trailCoords[0].lat, trailCoords[0].lng]);
  currentIdx = 0;
  animateStep();
}

function animateStep() {
  if (!animating || currentIdx >= trailCoords.length - 1) {
    animating = false;
    updateControls();
    return;
  }
  currentIdx++;
  const pt = trailCoords[currentIdx];
  hikerMarker.setLatLng([pt.lat, pt.lng]);
  map.panTo([pt.lat, pt.lng], { animate: true, duration: 0.1 });
  updateProgress(currentIdx, trailCoords.length);
  animTimer = setTimeout(animateStep, ANIMATION_SPEED);
}

function stopAnimation() {
  animating = false;
  clearTimeout(animTimer);
  updateControls();
}

function resetAnimation() {
  stopAnimation();
  currentIdx = 0;
  hikerMarker.setLatLng([trailCoords[0].lat, trailCoords[0].lng]);
  map.setView([trailCoords[0].lat, trailCoords[0].lng], MAP_ZOOM);
  updateProgress(0, trailCoords.length);
}
```

**Scenic spot marker types (use colored icons):**
| Type | Color | Icon |
|------|-------|------|
| 🏛️ Temple/历史建筑 | `#e65100` | 1, 2, 3... |
| 🏔️ 观景台/峰顶 | `#2e7d32` | — |
| 💧 瀑布/溪流 | `#0277bd` | — |
| 🚪 山门/入口 | `#607d8b` | — |
| 🛤️ 险要地段 | `#c62828` | — |

### Step 5: 生成待办清单
Generate a `todo-climb-{slug}.md` file with gear prep items:
```markdown
### 🎒 装备准备
- [ ] 登山鞋（防滑）
- [ ] 登山杖 × 2
- [ ] 冲锋衣/防风外套
- [ ] 头灯/手电
- [ ] 防晒霜 SPF50
- [ ] 2L+ 水/运动饮料
- [ ] 路餐/能量棒
- [ ] ...

### 📌 行前准备
- [ ] 查看天气预报
- [ ] 预订门票
- [ ] 下载离线地图
- [ ] 告知亲友行程
```

### Step 6: 交付
1. Save HTML to `~/Downloads/mountain-climber/`
2. Save gear todo to same directory as `todo-climb-{slug}.md`

**Directory structure generated:**
```
~/Downloads/mountain-climber/
├── index.html              # Interactive climb map (overwrite latest)
├── index-🏔️-峨眉山登山路线-20260623.html  # Backup (auto after deploy)
└── todo-climb-emei.md      # Gear checklist
```

### Step 7: 自动部署到 Vercel — 方案1（先执行）

⚠️ **MANDATORY DEFAULT**: After Step 6 is done, Steps 7→8 run **automatically in sequence without asking** — this is the default delivery pipeline. Every climb plan MUST include both deployments.

**执行顺序（不可颠倒）：**
1. **先** bash deploy-climb.sh（方案1 — 部署到根路径）
2. **再** bash deploy-subpath.sh（方案2 — 自动存档到 /toc/）

> 方案2 依赖方案1 产生的 `index-*.html` 备份文件来构建存档目录页。

```bash
bash {skillDir}/references/templates/deploy-climb.sh
```

This script:
1. Deploys `~/Downloads/mountain-climber/index.html` → Vercel `toc` project → `https://line.allez.cc.cd`
2. Auto-renames local `index.html` → `index-{slug}-{date}.html` to preserve history

### Step 8: 自动存档到 /toc/ — 方案2（后执行）

必须先执行方案1，再执行方案2。方案2自动检测 `index-*.html` 备份文件，将每条登山路线以子路径形式永久存档到 `/toc/` 目录页。

```bash
bash {skillDir}/references/templates/deploy-subpath.sh
```

This script:
1. Scans `~/Downloads/mountain-climber/` for all `index-*.html` backup files + subdirectory `index.html`
2. Archives each climb route to `/{slug}/` subpath
3. Updates/creates `/toc/` directory page with search, sort, and pagination
4. Root page fallback fix (restores `index.html` if missing after 方案1 rename)

**Deployment info:**
| Item | Value |
|------|-------|
| Vercel Project | `toc` (`prj_RvCYoRy7PeZy5br9uHRGQS1r73Fm`) |
| Production URL | `https://line.allez.cc.cd` |
| Archive Index | `https://line.allez.cc.cd/toc/` |
| Vercel Scope | `seigneurtsuis-projects` |
| Output path | `~/Downloads/mountain-climber/` |
| Deploy script | `{skillDir}/references/templates/deploy-subpath.sh` |
| Toc template | `{skillDir}/references/templates/toc-index.html` |

**Confirmation output:**
```bash
echo "[$(date)] 部署完成 — $MOUNTAIN_NAME — https://line.allez.cc.cd" >> ~/Downloads/mountain-climber/delivery.log
echo "[$(date)] 存档完成 — $MOUNTAIN_NAME — https://line.allez.cc.cd/toc/" >> ~/Downloads/mountain-climber/delivery.log
```

## Bug Records

### NaN段 — 点击景点位置显示「第 NaN 段」

**Root Cause:** 生成 `scenicSpots` JSON 时，每个景点对象缺少 `segmentIdx` 字段。模板 `climb-skeleton.html:234` 执行 `parseInt(s.segmentIdx) + 1`，当字段缺失时返回 `NaN`。

**受影响代码:**
- `generate-all-mountains.py` — 循环构建 `all_spots` 时未传入 `segmentIdx`
- `generate-moganshan.py` — 同上

**修复方案（双保险）:**

1. **生成脚本** — 为每个景点添加 `segmentIdx`：
   ```python
   for i, w in enumerate(waypoints):
       seg_idx = min(i, len(segments) - 1)
       all_spots.append({
           "name": w[0], ..., "segmentIdx": seg_idx,
       })
   ```
   - 主 waypoints：直接用其在数组中的索引（取 min 防止越界）
   - 额外 spots_extra：按坐标找最近的 waypoint 来继承 segmentIdx

2. **模板层** — 添加 null 防护（兜底）：
   ```javascript
   '⛰️ 位置：第 ' + (s.segmentIdx != null ? parseInt(s.segmentIdx) + 1 : '?') + ' 段'
   ```

**预防措施:** 以后所有新增的生成脚本，`all_spots` 中每个元素必须包含 `segmentIdx` 字段。模板层已有 `null` 防护会显示 `?` 而非 `NaN`。

### 搜索无效 — toc 目录页搜索框无响应

**Root Cause:** deploy-subpath.sh 中 toc 模板的 `render()` 函数在搜索过滤时，只对 `filteredCards`（匹配的卡片）进行隐藏/显示操作：

```javascript
// 错误代码 — 只隐藏匹配的卡片，不匹配的仍保持可见
filteredCards.forEach(c => { c.style.display = 'none'; });
```

由于分页初始渲染后大量不匹配卡片保持可见，搜索看起来像没反应。

**受影响代码:** `deploy-subpath.sh` — toc 模板内联 JavaScript 的 `render()` 函数

**修复方案:**

```javascript
// 正确做法 — 先隐藏所有卡片，再显示匹配的
allCards.forEach(c => { c.style.display = 'none'; });
```

**预防措施:** 所有涉及卡片列表搜索/过滤的模板，`render()` 函数中必须用 `allCards.forEach(...)` 而非 `filteredCards.forEach(...)` 来隐藏元素。非匹配卡片也需要被隐藏。
