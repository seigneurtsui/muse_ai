from __future__ import annotations
import json
from pathlib import Path
import os
import stat
import tarfile
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import zip_subfolders as z


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        self.source = self.root / "source"
        self.source.mkdir()
        self.target = self.root / "archives"
        (self.source / "alpha" / "nested").mkdir(parents=True)
        (self.source / "alpha" / "hello.txt").write_text("hello α\n")
        (self.source / "alpha" / "nested" / "data.bin").write_bytes(b"1234")
        (self.source / "beta").mkdir()
        (self.source / "beta" / "world.md").write_text("# world\n")
        (self.source / ".hidden").mkdir()
        (self.source / ".hidden" / "private_fixture.txt").write_text(
            "not selected fixture"
        )
        (self.source / "alpha" / "node_modules").mkdir()
        (self.source / "alpha" / "node_modules" / "ignored.js").write_text("ignored")

    def test_discovery_depth_exclusions_and_links(self):
        (self.source / "alpha" / "nested" / "deep").mkdir()
        (self.source / "alpha" / "nested" / "deep" / "x").write_text("x")
        (self.source / "alpha" / "link.txt").symlink_to(
            self.source / "beta" / "world.md"
        )
        folders = z.discover_folders(self.source, 2, set(z.DEFAULT_EXCLUDES))
        self.assertEqual(
            [str(p.relative_to(self.source)) for p in folders],
            ["alpha", "alpha/nested", "beta"],
        )
        entries, skipped, fingerprint, size, count = z.source_tree(
            self.source / "alpha", self.source, set(z.DEFAULT_EXCLUDES)
        )
        names = [
            member.as_posix()
            for _, _, member in z._archive_members(self.source / "alpha", entries)
        ]
        self.assertIn("alpha/hello.txt", names)
        self.assertNotIn("alpha/node_modules/ignored.js", names)
        self.assertTrue(any(row["reason"] == "link_not_followed" for row in skipped))
        self.assertGreater(size, 0)
        self.assertGreater(count, 0)
        self.assertEqual(len(fingerprint), 64)

    def test_dry_run_does_not_create_target_or_archives(self):
        result = z.run(str(self.source), str(self.target), dry_run=True)
        self.assertEqual(result["status"], "dry_run")
        self.assertEqual(result["total"], 2)
        self.assertFalse(self.target.exists())

    def test_zip_creates_safe_archive_and_report(self):
        result = z.run(
            str(self.source), str(self.target), archive_format="zip", workers=2
        )
        self.assertEqual(result["status"], "complete")
        self.assertEqual(result["created"], 2)
        archives = sorted(self.target.rglob("*.zip"))
        self.assertEqual(len(archives), 2)
        with zipfile.ZipFile(next(p for p in archives if "alpha" in p.name)) as archive:
            names = archive.namelist()
            self.assertIn("alpha/", names)
            self.assertIn("alpha/hello.txt", names)
            self.assertIn("alpha/nested/data.bin", names)
            self.assertNotIn("alpha/node_modules/ignored.js", names)
            self.assertEqual(archive.testzip(), None)
        self.assertTrue((self.target / z.STATE_NAME).is_file())
        report = json.loads((self.target / "report.json").read_text())
        self.assertEqual(report["created"], 2)
        self.assertEqual(report["failed"], 0)
        self.assertTrue((self.target / "report.txt").is_file())

    def test_tar_gz_round_trip(self):
        result = z.run(
            str(self.source), str(self.target), archive_format="tar.gz", workers=1
        )
        self.assertEqual(result["status"], "complete")
        archive = next(self.target.rglob("*.tar.gz"))
        with tarfile.open(archive, "r:gz") as tar:
            names = tar.getnames()
            self.assertIn("alpha", names)
            self.assertIn("alpha/hello.txt", names)
            self.assertEqual(
                tar.extractfile("alpha/hello.txt").read(), "hello α\n".encode()
            )

    def test_nested_output_layout_avoids_same_basename_collision(self):
        (self.source / "one").mkdir()
        (self.source / "one" / "same").mkdir()
        (self.source / "two").mkdir()
        (self.source / "two" / "same").mkdir()
        result = z.run(
            str(self.source), str(self.target), depth=2, archive_format="zip"
        )
        self.assertEqual(result["status"], "complete")
        self.assertEqual(result["created"], 7)
        self.assertEqual(len(list(self.target.rglob("same_*.zip"))), 2)
        self.assertEqual(
            len(
                {
                    p.relative_to(self.target).parent.as_posix()
                    for p in self.target.rglob("same_*.zip")
                }
            ),
            2,
        )

    def test_repeat_run_skips_and_does_not_rewrite(self):
        first = z.run(str(self.source), str(self.target), archive_format="zip")
        archive = next(self.target.rglob("alpha_*.zip"))
        mtime = archive.stat().st_mtime_ns
        second = z.run(str(self.source), str(self.target), archive_format="zip")
        self.assertEqual(first["created"], 2)
        self.assertEqual(second["skipped"], 2)
        self.assertEqual(archive.stat().st_mtime_ns, mtime)

    def test_changed_source_requires_explicit_overwrite(self):
        z.run(str(self.source), str(self.target), archive_format="zip")
        (self.source / "alpha" / "hello.txt").write_text("changed")
        result = z.run(str(self.source), str(self.target), archive_format="zip")
        self.assertEqual(result["status"], "partial_failure")
        self.assertEqual(result["failed"], 1)
        self.assertEqual(result["skipped"], 1)
        self.assertIn(
            "archive_exists_source_changed_use_overwrite",
            {row.get("reason") for row in result["results"]},
        )
        overwritten = z.run(
            str(self.source), str(self.target), archive_format="zip", overwrite=True
        )
        self.assertEqual(overwritten["status"], "complete")
        self.assertEqual(overwritten["created"], 2)
        with zipfile.ZipFile(next(self.target.rglob("alpha_*.zip"))) as archive:
            self.assertEqual(archive.read("alpha/hello.txt"), b"changed")

    def test_corrupted_existing_archive_is_failure_not_overwritten(self):
        z.run(str(self.source), str(self.target), archive_format="zip")
        archive = next(self.target.rglob("alpha_*.zip"))
        original = archive.read_bytes()
        archive.write_bytes(b"corrupt")
        result = z.run(str(self.source), str(self.target), archive_format="zip")
        self.assertEqual(result["failed"], 1)
        self.assertEqual(archive.read_bytes(), b"corrupt")
        self.assertNotEqual(original, archive.read_bytes())

    def test_selected_relative_and_absolute_folders_and_overlap_rejection(self):
        result = z.run(
            str(self.source),
            str(self.target),
            selected=["alpha", str(self.source / "beta")],
            archive_format="zip",
        )
        self.assertEqual(result["created"], 2)
        with self.assertRaisesRegex(z.ArchiveError, "overlapping"):
            z.run(
                str(self.source),
                str(self.root / "other"),
                depth=2,
                selected=["alpha", "alpha/nested"],
            )
        with self.assertRaisesRegex(z.ArchiveError, "outside_source"):
            z.run(
                str(self.source), str(self.root / "other2"), selected=[str(self.root)]
            )

    def test_source_and_target_must_be_separate_before_target_creation(self):
        nested = self.source / "new-output"
        with self.assertRaisesRegex(z.ArchiveError, "source_target"):
            z.run(str(self.source), str(nested))
        self.assertFalse(nested.exists())
        with self.assertRaisesRegex(z.ArchiveError, "source_target"):
            z.run(str(self.source), str(self.root))

    def test_lock_is_exclusive_and_not_auto_removed(self):
        self.target.mkdir()
        lock = self.target / z.LOCK_NAME
        lock.mkdir()
        with self.assertRaisesRegex(z.ArchiveError, "locked"):
            z.run(str(self.source), str(self.target))
        self.assertTrue(lock.exists())

    def test_target_parent_link_is_rejected(self):
        self.target.mkdir()
        (self.target / "alpha").symlink_to(self.root)
        result = z.run(
            str(self.source), str(self.target), depth=2, selected=["alpha/nested"]
        )
        self.assertEqual(result["status"], "partial_failure")
        self.assertEqual(
            result["results"][0]["reason"], "output_parent_is_link_or_not_directory"
        )

    def test_7z_requires_explicit_available_external_tool(self):
        with patch("zip_subfolders.shutil.which", return_value=None):
            result = z.run(str(self.source), str(self.target), archive_format="7z")
        self.assertEqual(result["status"], "partial_failure")
        self.assertEqual(result["failed"], 2)
        self.assertFalse(list(self.target.rglob("*.7z")))

    def test_limits_and_unknown_formats_fail_closed(self):
        with patch("zip_subfolders.MAX_FOLDERS", 1), self.assertRaisesRegex(
            z.ArchiveError, "folder_count"
        ):
            z.run(str(self.source), str(self.target))
        with self.assertRaisesRegex(z.ArchiveError, "unsupported"):
            z.run(str(self.source), str(self.target), archive_format="cpgz")
        with self.assertRaisesRegex(z.ArchiveError, "invalid_depth"):
            z.discover_folders(self.source, 9, set())

    def test_special_files_are_not_followed_or_executed(self):
        if hasattr(os, "mkfifo"):
            os.mkfifo(self.source / "alpha" / "pipe")
        result = z.run(str(self.source), str(self.target))
        self.assertEqual(result["status"], "complete")
        with zipfile.ZipFile(next(self.target.rglob("alpha_*.zip"))) as archive:
            self.assertNotIn("alpha/pipe", archive.namelist())

    def test_state_and_report_do_not_contain_file_payloads(self):
        z.run(str(self.source), str(self.target))
        for name in (z.STATE_NAME, "report.json", "report.txt"):
            text = (self.target / name).read_text()
            self.assertNotIn("hello α", text)
            self.assertNotIn("1234", text)


if __name__ == "__main__":
    unittest.main()
