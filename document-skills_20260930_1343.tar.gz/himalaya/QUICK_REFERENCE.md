# 📧 Himalaya 发送邮件快速参考

## ⭐ 默认方式: HTML 富文本邮件 (推荐)

所有邮件默认通过 `send-html.js` 发送美观的 HTML 卡片式邮件，同时附带纯文本版本。

```bash
# 基础用法
node ~/.hermes/skills/email/himalaya/scripts/send-html.js \
  --to "recipient@example.com" \
  --subject "邮件主题" \
  --body "邮件正文内容"

# 从文件读取内容
node scripts/send-html.js --to "recipient@example.com" --subject "报告" --body-file /path/to/content.txt

# 从管道读取
echo "邮件内容" | node scripts/send-html.js --to "recipient@example.com" --subject "通知"
```

### 颜色主题

```bash
HIMALAYA_STYLE=red    node scripts/send-html.js ...   # 🔴 红色渐变 (默认)
HIMALAYA_STYLE=blue   node scripts/send-html.js ...   # 🔵 蓝色渐变
HIMALAYA_STYLE=green  node scripts/send-html.js ...   # 🟢 绿色渐变
HIMALAYA_STYLE=purple node scripts/send-html.js ...   # 🟣 紫色渐变
```

### 默认配置

| 项目 | 默认值 | 覆盖方式 |
|------|--------|----------|
| 发件人 | `Seigneur Tsui <2826824650@qq.com>` | `HIMALAYA_FROM` 环境变量 |
| 收件人 | `gc40800@gmail.com` | `--to` 参数 或 `HIMALAYA_TO` |
| 颜色主题 | red | `HIMALAYA_STYLE` 环境变量 |
| 格式 | HTML + 纯文本 (MML multipart/alternative) | — |

### 从 Node.js 调用

```javascript
const { execFileSync } = require('child_process');
execFileSync('node', [
  '/Users/seigneur/.hermes/skills/email/himalaya/scripts/send-html.js',
  '--to', 'gc40800@gmail.com',
  '--subject', '自动通知',
  '--body', '邮件正文内容'
], { timeout: 15000 });
```

---

## 📝 纯文本邮件 (简单场景)

```bash
himalaya message send <<EOF
From: Seigneur Tsui <2826824650@qq.com>
To: gc40800@gmail.com
Subject: 邮件主题

邮件正文内容
EOF
```

**注意**: 邮件头和正文之间**必须有一个空行**。

---

## 🔧 手写 HTML 邮件 (MML)

```bash
# ⚠️ MML 必须用 template send，不能用 message send！
himalaya template send <<'EOF'
From: Seigneur Tsui <2826824650@qq.com>
To: gc40800@gmail.com
Subject: 自定义 HTML 邮件

<#multipart type=alternative>
<#part type=text/plain>
纯文本版本
<#part type=text/html>
<html><body><h1>HTML 版本</h1></body></html>
<#/multipart>
EOF
```

---

## ⚠️ 关键规则

1. **默认发邮件 → 用 `send-html.js`**，不要手动拼 himalaya 命令
2. **MML 标签 → 必须用 `himalaya template send`**（管道传入），`message send` 会把标签原样输出
3. **纯文本 heredoc → 用 `himalaya message send`**
4. **邮件头和正文之间必须有一个空行**
5. **From 头可以包含显示名称**: `From: 显示名称 <email@example.com>`

---

## 🔧 故障排除

| 错误 | 原因 | 解决 |
|------|------|------|
| MML 标签出现在邮件正文 | 用了 `message send` 而非 `template send` | 改用 `himalaya template send` 管道 |
| "index out of bounds" | 缺少邮件头与正文间的空行 | 确保空行分隔 |
| "cannot send message without a recipient" | 缺少 To 头 | 添加 `To: recipient@example.com` |
| HTML 未渲染 | 收件端不支持 HTML | 正常 — 会自动降级到纯文本版本 |

---

## 📚 更多信息

- himalaya 官方文档: https://github.com/pimalaya/himalaya
- send-html.js 脚本: `~/.hermes/skills/email/himalaya/scripts/send-html.js`
- MML 语法参考: `references/message-composition.md`
- 配置指南: `himalaya account configure`

---
*最后更新: 2026-04-18*
