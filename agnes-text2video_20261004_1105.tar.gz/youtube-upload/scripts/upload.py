#!/usr/bin/env python3
"""YouTube Upload - multi-channel video upload via OAuth2."""

import argparse
import json
import os
import socket
import stat
import subprocess
import sys
import threading
import webbrowser
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

REQUIRED_PACKAGES = [
    ("googleapiclient", "google-api-python-client"),
    ("google_auth_oauthlib", "google-auth-oauthlib"),
    ("google.auth.transport.requests", "google-auth-httplib2"),
]

VENV_DIR = Path.home() / ".config" / "opencode" / "skills" / "youtube-upload" / ".venv"

def _in_venv():
    return any(str(VENV_DIR) in p for p in sys.path)

def ensure_dependencies():
    venv_python = VENV_DIR / "bin" / "python3"
    if venv_python.exists() and not _in_venv():
        os.execv(str(venv_python), [str(venv_python), *sys.argv])
    missing = []
    for module_name, pip_name in REQUIRED_PACKAGES:
        try:
            __import__(module_name)
        except ImportError:
            missing.append(pip_name)
    if not missing:
        return
    if not venv_python.exists():
        print("Creating virtual environment...", file=sys.stderr)
        subprocess.check_call([sys.executable, "-m", "venv", str(VENV_DIR)])
    print(f"Installing: {', '.join(missing)}", file=sys.stderr)
    subprocess.check_call([str(venv_python), "-m", "pip", "install", "--quiet", *missing])
    os.execv(str(venv_python), [str(venv_python), *sys.argv])

ensure_dependencies()

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

SCOPES = [
    "https://www.googleapis.com/auth/youtube",
    "https://www.googleapis.com/auth/youtube.upload",
    "https://www.googleapis.com/auth/youtube.force-ssl",
]

DEFAULT_DIR = Path.home() / ".config" / "youtube"
CHANNELS_FILE = "channels.json"
DEFAULT_CLIENT_SECRET = DEFAULT_DIR / "client_secret.json"

VALID_PRIVACY = ("private", "unlisted", "public")
THUMBNAIL_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".gif"}
THUMBNAIL_MAX_BYTES = 2 * 1024 * 1024
CAPTION_EXTENSIONS = {".srt", ".vtt", ".ttml", ".sbv"}

def get_storage_dir():
    d = DEFAULT_DIR
    d.mkdir(parents=True, exist_ok=True)
    return d

def load_channels():
    path = get_storage_dir() / CHANNELS_FILE
    if not path.exists():
        return {}
    with open(path) as f:
        return json.load(f)

def save_channels(channels):
    path = get_storage_dir() / CHANNELS_FILE
    with open(path, "w") as f:
        json.dump(channels, f, indent=2)
    os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)

def get_credentials(channel_id, channels):
    if not channels:
        print("Error: No authenticated channels. Run 'auth' first.", file=sys.stderr)
        sys.exit(1)
    if channel_id:
        if channel_id not in channels:
            print(f"Error: Channel {channel_id} not found.", file=sys.stderr)
            sys.exit(1)
        entry = channels[channel_id]
    else:
        channel_id = next(iter(channels))
        entry = channels[channel_id]
        print(f"Using channel: {entry.get('title', channel_id)} ({channel_id})", file=sys.stderr)
    creds = Credentials(
        token=entry["token"],
        refresh_token=entry["refresh_token"],
        token_uri=entry["token_uri"],
        client_id=entry["client_id"],
        client_secret=entry["client_secret"],
        scopes=SCOPES,
    )
    if creds.expired and creds.refresh_token:
        print("Token expired, refreshing...", file=sys.stderr)
        creds.refresh(Request())
        entry["token"] = creds.token
        entry["expiry"] = creds.expiry.isoformat() if creds.expiry else None
        save_channels(channels)
    return creds, channel_id

class OAuthCallbackHandler(BaseHTTPRequestHandler):
    auth_code = None
    def do_GET(self):
        query = parse_qs(urlparse(self.path).query)
        code = query.get("code")
        if code:
            OAuthCallbackHandler.auth_code = code[0]
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(b"<html><body><h2>Auth OK</h2><p>Close this tab.</p></body></html>")
        else:
            self.send_response(400)
            self.end_headers()
    def log_message(self, format, *args):
        pass

def cmd_auth(args):
    client_secret_path = Path(args.client_secret).expanduser()
    if not client_secret_path.exists():
        print(f"Error: {client_secret_path} not found", file=sys.stderr)
        sys.exit(1)
    stored_secret = get_storage_dir() / "client_secret.json"
    if client_secret_path.resolve() != stored_secret.resolve():
        import shutil
        shutil.copy2(client_secret_path, stored_secret)
        os.chmod(stored_secret, stat.S_IRUSR | stat.S_IWUSR)
    port = 3000
    redirect_uri = f"http://localhost:{port}/oauth2callback"
    flow = InstalledAppFlow.from_client_secrets_file(str(client_secret_path), scopes=SCOPES, redirect_uri=redirect_uri)
    if args.code:
        flow.fetch_token(code=args.code)
    else:
        auth_url, _ = flow.authorization_url(access_type="offline", prompt="consent")
        server = HTTPServer(("localhost", port), OAuthCallbackHandler)
        t = threading.Thread(target=server.handle_request, daemon=True)
        t.start()
        print(f"Opening browser...", file=sys.stderr)
        print(f"Or visit: {auth_url}", file=sys.stderr)
        webbrowser.open(auth_url)
        t.join(timeout=120)
        server.server_close()
        if not OAuthCallbackHandler.auth_code:
            print("Error: No auth code received.", file=sys.stderr)
            sys.exit(1)
        flow.fetch_token(code=OAuthCallbackHandler.auth_code)
    creds = flow.credentials
    youtube = build("youtube", "v3", credentials=creds)
    resp = youtube.channels().list(part="snippet", mine=True).execute()
    if not resp.get("items"):
        print("Error: No channel found.", file=sys.stderr)
        sys.exit(1)
    ch = resp["items"][0]
    channels = load_channels()
    channels[ch["id"]] = {
        "title": ch["snippet"]["title"],
        "token": creds.token,
        "refresh_token": creds.refresh_token,
        "token_uri": creds.token_uri,
        "client_id": creds.client_id,
        "client_secret": creds.client_secret,
        "expiry": creds.expiry.isoformat() if creds.expiry else None,
        "authenticated_at": datetime.now(timezone.utc).isoformat(),
    }
    save_channels(channels)
    print(json.dumps({"channelId": ch["id"], "title": ch["snippet"]["title"], "status": "authenticated"}, indent=2))

def cmd_channels(args):
    channels = load_channels()
    if not channels:
        print("No channels. Run 'auth' first.", file=sys.stderr)
        sys.exit(1)
    result = [{"channelId": cid, "title": e.get("title", "?"), "authenticatedAt": e.get("authenticated_at", "?")} for cid, e in channels.items()]
    print(json.dumps(result, indent=2))

def cmd_upload(args):
    video_path = Path(args.file).expanduser()
    if not video_path.exists():
        print(f"Error: {video_path} not found", file=sys.stderr)
        sys.exit(1)
    if args.privacy not in VALID_PRIVACY:
        print(f"Error: Invalid privacy '{args.privacy}'", file=sys.stderr)
        sys.exit(1)
    channels = load_channels()
    creds, channel_id = get_credentials(args.channel_id, channels)
    youtube = build("youtube", "v3", credentials=creds)
    body = {
        "snippet": {
            "title": args.title,
            "description": args.description or "",
            "tags": [t.strip() for t in args.tags.split(",")] if args.tags else [],
            "categoryId": str(args.category),
        },
        "status": {
            "privacyStatus": args.privacy,
            "selfDeclaredMadeForKids": args.made_for_kids,
        },
    }
    if args.publish_at:
        body["status"]["publishAt"] = args.publish_at
    ext = video_path.suffix.lower()
    mime_map = {".mp4": "video/mp4", ".mov": "video/quicktime", ".avi": "video/x-msvideo", ".webm": "video/webm", ".mkv": "video/x-matroska"}
    media = MediaFileUpload(str(video_path), mimetype=mime_map.get(ext, "video/*"), resumable=True, chunksize=10*1024*1024)
    print(f"Uploading {video_path.name}...", file=sys.stderr)
    req = youtube.videos().insert(part="snippet,status", body=body, media_body=media)
    response = None
    while response is None:
        status, response = req.next_chunk()
        if status:
            print(f"Progress: {int(status.progress()*100)}%", file=sys.stderr)
    vid = response["id"]
    print(json.dumps({"videoId": vid, "url": f"https://www.youtube.com/watch?v={vid}", "channelId": channel_id, "title": args.title, "privacy": args.privacy}, indent=2))

def cmd_thumbnail(args):
    thumb_path = Path(args.file).expanduser()
    if not thumb_path.exists():
        print(f"Error: {thumb_path} not found", file=sys.stderr)
        sys.exit(1)
    ext = thumb_path.suffix.lower()
    if ext not in THUMBNAIL_EXTENSIONS:
        print(f"Error: Unsupported format '{ext}'", file=sys.stderr)
        sys.exit(1)
    if thumb_path.stat().st_size > THUMBNAIL_MAX_BYTES:
        print("Error: Thumbnail > 2MB", file=sys.stderr)
        sys.exit(1)
    mime_map = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".bmp": "image/bmp", ".gif": "image/gif"}
    channels = load_channels()
    creds, channel_id = get_credentials(args.channel_id, channels)
    youtube = build("youtube", "v3", credentials=creds)
    media = MediaFileUpload(str(thumb_path), mimetype=mime_map[ext])
    resp = youtube.thumbnails().set(videoId=args.video_id, media_body=media).execute()
    print(json.dumps({"videoId": args.video_id, "channelId": channel_id, "status": "set"}, indent=2))

def cmd_refresh(args):
    channels = load_channels()
    creds, channel_id = get_credentials(args.channel_id, channels)
    if creds.refresh_token:
        creds.refresh(Request())
        channels[channel_id]["token"] = creds.token
        channels[channel_id]["expiry"] = creds.expiry.isoformat() if creds.expiry else None
        save_channels(channels)
        print(json.dumps({"channelId": channel_id, "status": "refreshed"}, indent=2))
    else:
        print("Error: No refresh token.", file=sys.stderr)
        sys.exit(1)

def cmd_caption(args):
    caption_path = Path(args.file).expanduser()
    if not caption_path.exists():
        print(f"Error: {caption_path} not found", file=sys.stderr)
        sys.exit(1)
    ext = caption_path.suffix.lower()
    if ext not in CAPTION_EXTENSIONS:
        print(f"Error: Unsupported format '{ext}'", file=sys.stderr)
        sys.exit(1)
    channels = load_channels()
    creds, channel_id = get_credentials(args.channel_id, channels)
    youtube = build("youtube", "v3", credentials=creds)
    media = MediaFileUpload(str(caption_path), mimetype="text/plain")
    body = {
        "snippet": {
            "videoId": args.video_id,
            "language": args.language,
            "name": args.name or caption_path.stem,
            "isDraft": False,
        }
    }
    resp = youtube.captions().insert(part="snippet", body=body, media_body=media).execute()
    print(json.dumps({"videoId": args.video_id, "captionId": resp["id"], "language": args.language, "status": "uploaded"}, indent=2))

def main():
    parser = argparse.ArgumentParser(description="YouTube Upload (multi-channel)")
    sub = parser.add_subparsers(dest="command", required=True)
    p_auth = sub.add_parser("auth", help="Authenticate a channel")
    p_auth.add_argument("--client-secret", default=str(DEFAULT_CLIENT_SECRET), help="OAuth client_secret.json path")
    p_auth.add_argument("--code", default=None, help="Auth code (skip browser)")
    p_auth.set_defaults(func=cmd_auth)
    p_ch = sub.add_parser("channels", help="List channels")
    p_ch.set_defaults(func=cmd_channels)
    p_up = sub.add_parser("upload", help="Upload video")
    p_up.add_argument("--file", required=True)
    p_up.add_argument("--title", required=True)
    p_up.add_argument("--description", default="")
    p_up.add_argument("--tags", default="")
    p_up.add_argument("--category", type=int, default=22)
    p_up.add_argument("--privacy", default="private", choices=VALID_PRIVACY)
    p_up.add_argument("--publish-at", default=None)
    p_up.add_argument("--made-for-kids", action="store_true")
    p_up.add_argument("--channel-id", default=None)
    p_up.set_defaults(func=cmd_upload)
    p_th = sub.add_parser("thumbnail", help="Upload thumbnail")
    p_th.add_argument("--video-id", required=True)
    p_th.add_argument("--file", required=True)
    p_th.add_argument("--channel-id", default=None)
    p_th.set_defaults(func=cmd_thumbnail)
    p_re = sub.add_parser("refresh", help="Refresh token")
    p_re.add_argument("--channel-id", default=None)
    p_re.set_defaults(func=cmd_refresh)
    p_cap = sub.add_parser("caption", help="Upload caption/subtitle")
    p_cap.add_argument("--video-id", required=True)
    p_cap.add_argument("--file", required=True)
    p_cap.add_argument("--language", required=True, help="Language code (e.g., zh-Hans, zh-Hant, en)")
    p_cap.add_argument("--name", default=None, help="Caption track name")
    p_cap.add_argument("--channel-id", default=None)
    p_cap.set_defaults(func=cmd_caption)
    args = parser.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
