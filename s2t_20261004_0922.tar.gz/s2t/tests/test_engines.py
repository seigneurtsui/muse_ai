"""Standalone engine tests: python3 -m unittest discover -s tests -p test_engines.py -v."""
from __future__ import annotations

import ctypes
import importlib.util
import json
import platform
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

# Load only our module, without depending on the caller's PYTHONPATH or other
# test modules. No global/shared converter is created.
_SPEC = importlib.util.spec_from_file_location(
    "s2t_engines_under_test", Path(__file__).resolve().parents[1] / "scripts" / "conversion_engines.py"
)
assert _SPEC is not None and _SPEC.loader is not None
e = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(e)


def fake_backend(name: str, result: str = "converted") -> Mock:
    backend = Mock()
    backend.name = name
    backend.convert.return_value = result
    backend.metadata.return_value = {"version": "test"}
    return backend


def fake_library(output: bytes = "漢語😀\r\n".encode()) -> Mock:
    library = Mock()
    library.buffer = ctypes.create_string_buffer(output)
    library.opencc_open.return_value = 123
    library.opencc_convert_utf8.return_value = ctypes.addressof(library.buffer)
    library.opencc_close.return_value = 0
    return library


def native(library: Mock) -> e._NativeEngine:
    e._bind_native(library)
    return e._NativeEngine("s2t", library, Path("/synthetic/libopencc.1.2.dylib"), Path("/synthetic/s2t.json"))


class SelectionTests(unittest.TestCase):
    def test_auto_darwin_prefers_native(self):
        backend = fake_backend("native")
        with patch.object(e.platform, "system", return_value="Darwin"), \
             patch.object(e, "_make_native", return_value=backend) as make, \
             patch.object(e, "_PythonEngine") as python:
            engine = e.get_engine("s2t")
            self.addCleanup(engine.close)
            self.assertEqual(engine.name, "native")
            self.assertEqual(engine.mode, "s2t")
            self.assertIsNone(engine.metadata()["fallback_reason"])
            make.assert_called_once_with("s2t")
            python.assert_not_called()

    def test_auto_linux_and_windows_never_load_native(self):
        for system in ("Linux", "Windows"):
            with self.subTest(system=system), \
                 patch.object(e.platform, "system", return_value=system), \
                 patch.object(e, "_make_native") as make, \
                 patch.object(e.ctypes, "CDLL") as loader, \
                 patch.object(e, "_PythonEngine", return_value=fake_backend("opencc")) as python:
                engine = e.get_engine("t2s")
                self.assertEqual(engine.name, "opencc")
                self.assertIsNone(engine.metadata()["fallback_reason"])
                engine.close()
                python.assert_called_once_with("t2s")
                make.assert_not_called()
                loader.assert_not_called()

    def test_auto_native_init_failure_records_fallback(self):
        with patch.object(e.platform, "system", return_value="Darwin"), \
             patch.object(e, "_make_native", side_effect=e.EngineError("Native unavailable.")), \
             patch.object(e, "_PythonEngine", return_value=fake_backend("opencc")):
            engine = e.get_engine("s2t")
            self.addCleanup(engine.close)
            metadata = engine.metadata()
            self.assertEqual(metadata["requested_backend"], "auto")
            self.assertEqual(metadata["selected_backend"], "opencc")
            self.assertEqual(metadata["fallback_reason"], "Native unavailable.")
            json.dumps(metadata)

    def test_auto_runtime_failure_retries_whole_text_once(self):
        source = " 头发😀\r\n" * 10000 + "尾\r"
        native_backend = fake_backend("native")
        native_backend.convert.side_effect = e.EngineError("Native conversion failed.")
        python_backend = fake_backend("opencc", "complete-python-output")
        with patch.object(e.platform, "system", return_value="Darwin"), \
             patch.object(e, "_make_native", return_value=native_backend), \
             patch.object(e, "_PythonEngine", return_value=python_backend) as python:
            engine = e.get_engine("s2t")
            self.addCleanup(engine.close)
            self.assertEqual(engine.convert(source), "complete-python-output")
            python_backend.convert.assert_called_once_with(source)
            native_backend.close.assert_called_once()
            self.assertEqual(engine.name, "opencc")
            self.assertIn("Native conversion failed", engine.metadata()["fallback_reason"])
            self.assertNotIn(source, json.dumps(engine.metadata()))
            engine.convert("second call")
            native_backend.convert.assert_called_once_with(source)
            python.assert_called_once_with("s2t")

    def test_auto_runtime_cleanup_failure_still_uses_python(self):
        backend = fake_backend("native")
        backend.convert.side_effect = e.EngineError("Native failed.")
        backend.close.side_effect = e.EngineError("Cleanup failed.")
        with patch.object(e, "_PythonEngine", return_value=fake_backend("opencc", "漢")):
            engine = e._Engine("s2t", "auto", backend)
            self.addCleanup(engine.close)
            self.assertEqual(engine.convert("汉"), "漢")
            self.assertIn("cleanup also failed", engine.metadata()["fallback_reason"])

    def test_auto_runtime_unavailable_python_is_error_and_closes(self):
        backend = fake_backend("native")
        backend.convert.side_effect = e.EngineError("Native failed.")
        with patch.object(e, "_PythonEngine", side_effect=e.EngineError("Python missing.")):
            engine = e._Engine("s2t", "auto", backend)
            with self.assertRaisesRegex(e.EngineError, "fallback is unavailable"):
                engine.convert("汉")
            self.assertTrue(engine.metadata()["closed"])
            engine.close()
            backend.close.assert_called_once()
            with self.assertRaisesRegex(e.EngineError, "closed"):
                engine.convert("汉")

    def test_auto_python_conversion_failure_is_error_not_original_text(self):
        backend = fake_backend("native")
        backend.convert.side_effect = e.EngineError("Native failed.")
        fallback = fake_backend("opencc")
        fallback.convert.side_effect = e.EngineError("Python conversion failed.")
        with patch.object(e, "_PythonEngine", return_value=fallback):
            engine = e._Engine("s2t", "auto", backend)
            self.addCleanup(engine.close)
            with self.assertRaisesRegex(e.EngineError, "Python conversion failed"):
                engine.convert("汉语")
            fallback.convert.assert_called_once_with("汉语")
            self.assertEqual(engine.name, "opencc")
            self.assertIn("Native failed", engine.metadata()["fallback_reason"])

    def test_auto_both_initializers_fail(self):
        with patch.object(e.platform, "system", return_value="Darwin"), \
             patch.object(e, "_make_native", side_effect=e.EngineError("Native missing.")), \
             patch.object(e, "_PythonEngine", side_effect=e.EngineError("Python missing.")):
            with self.assertRaisesRegex(e.EngineError, "No usable OpenCC converter") as raised:
                e.get_engine("s2t")
            self.assertEqual(raised.exception.code, "engine_error")

    def test_forced_native_initialization_never_falls_back(self):
        with patch.object(e, "_make_native", side_effect=e.EngineError("Broken native.")), \
             patch.object(e, "_PythonEngine") as python:
            with self.assertRaisesRegex(e.EngineError, "Broken native"):
                e.get_engine("s2t", "native")
            python.assert_not_called()

    def test_forced_native_conversion_never_falls_back(self):
        backend = fake_backend("native")
        backend.convert.side_effect = e.EngineError("Broken native.")
        with patch.object(e, "_make_native", return_value=backend), \
             patch.object(e, "_PythonEngine") as python:
            engine = e.get_engine("s2t", "native")
            self.addCleanup(engine.close)
            with self.assertRaisesRegex(e.EngineError, "Broken native"):
                engine.convert("汉")
            python.assert_not_called()

    def test_forced_native_rejected_outside_darwin_without_loading(self):
        for system in ("Linux", "Windows"):
            with self.subTest(system=system), \
                 patch.object(e.platform, "system", return_value=system), \
                 patch.object(e, "_native_candidates") as candidates, \
                 patch.object(e.ctypes, "CDLL") as loader:
                with self.assertRaisesRegex(e.EngineError, "only on macOS"):
                    e.get_engine("s2t", "native")
                candidates.assert_not_called()
                loader.assert_not_called()

    def test_forced_opencc_never_tries_native_even_on_failure(self):
        with patch.object(e.platform, "system", return_value="Darwin"), \
             patch.object(e, "_make_native") as make, \
             patch.object(e, "_PythonEngine", side_effect=e.EngineError("Python missing.")):
            with self.assertRaisesRegex(e.EngineError, "Python missing"):
                e.get_engine("s2t", "opencc")
            make.assert_not_called()

    def test_invalid_options_fail_before_any_engine_initialization(self):
        with patch.object(e, "_make_native") as make, patch.object(e, "_PythonEngine") as python:
            for mode, backend in (("s2tw", "auto"), ("", "native"), ("s2t", "swift"), (None, "auto")):
                with self.subTest(mode=mode, backend=backend), self.assertRaises(e.EngineError):
                    e.get_engine(mode, backend)
            make.assert_not_called()
            python.assert_not_called()

    def test_engines_are_independent_and_close_is_idempotent(self):
        first, second = fake_backend("opencc"), fake_backend("opencc")
        with patch.object(e, "_PythonEngine", side_effect=[first, second]):
            one, two = e.get_engine("s2t", "opencc"), e.get_engine("s2t", "opencc")
            self.addCleanup(two.close)
            one.close()
            one.close()
            first.close.assert_called_once()
            second.close.assert_not_called()
            self.assertEqual(two.convert("汉"), "converted")
            with self.assertRaisesRegex(e.EngineError, "closed"):
                one.convert("汉")

    def test_invalid_input_does_not_trigger_fallback(self):
        backend = fake_backend("native")
        with patch.object(e, "_PythonEngine") as python:
            engine = e._Engine("s2t", "auto", backend)
            self.addCleanup(engine.close)
            with self.assertRaisesRegex(e.EngineError, "must be a string"):
                engine.convert(b"not text")
            python.assert_not_called()
            backend.convert.assert_not_called()


class PythonEngineTests(unittest.TestCase):
    def test_missing_import_is_actionable_error_not_identity(self):
        with patch.dict(sys.modules, {"opencc": None}):
            with self.assertRaisesRegex(e.EngineError, "opencc-python-reimplemented") as raised:
                e.get_engine("s2t", "opencc")
            self.assertEqual(raised.exception.code, "engine_error")

    def test_broken_configuration_is_engine_error(self):
        module = types.SimpleNamespace(OpenCC=Mock(side_effect=ValueError("configuration broken")))
        with patch.dict(sys.modules, {"opencc": module}):
            with self.assertRaisesRegex(e.EngineError, "could not initialize"):
                e.get_engine("t2s", "opencc")
            module.OpenCC.assert_called_once_with("t2s")

    def test_full_input_and_output_are_preserved(self):
        source = " \t汉语😀\r\n尾\n\r\t\u200b"
        expected = " \t漢語😀\r\n尾\n\r\t\u200b"
        converter = Mock()
        converter.convert.return_value = expected
        module = types.SimpleNamespace(OpenCC=Mock(return_value=converter))
        with patch.dict(sys.modules, {"opencc": module}):
            engine = e.get_engine("s2t", "opencc")
            self.addCleanup(engine.close)
            self.assertEqual(engine.convert(source), expected)
            converter.convert.assert_called_once_with(source)
            self.assertNotIn(source, json.dumps(engine.metadata()))

    def test_metadata_is_independent_of_caller_mutation(self):
        module = types.SimpleNamespace(OpenCC=Mock(return_value=Mock()))
        with patch.dict(sys.modules, {"opencc": module}), \
             patch.object(e, "_python_package_info", return_value={"version": "1.0", "distributions": {"provider": "1.0"}}):
            engine = e.get_engine("s2t", "opencc")
            self.addCleanup(engine.close)
            details = engine.metadata()
            details["distributions"]["provider"] = "changed"
            details["backend"] = "changed"
            self.assertEqual(engine.metadata()["distributions"], {"provider": "1.0"})
            self.assertEqual(engine.metadata()["backend"], "opencc")

    def test_conversion_failure_does_not_echo_document_text(self):
        secret = "synthetic-sensitive-input-汉"
        converter = Mock()
        converter.convert.side_effect = ValueError(secret)
        module = types.SimpleNamespace(OpenCC=Mock(return_value=converter))
        with patch.dict(sys.modules, {"opencc": module}):
            engine = e.get_engine("s2t", "opencc")
            self.addCleanup(engine.close)
            with self.assertRaises(e.EngineError) as raised:
                engine.convert(secret)
            self.assertNotIn(secret, str(raised.exception))
            self.assertNotIn(secret, json.dumps(engine.metadata()))
            self.assertTrue(raised.exception.__suppress_context__)

    def test_non_string_result_is_an_error(self):
        for result in (None, b"bytes", 42):
            with self.subTest(result=result):
                converter = Mock()
                converter.convert.return_value = result
                module = types.SimpleNamespace(OpenCC=Mock(return_value=converter))
                with patch.dict(sys.modules, {"opencc": module}):
                    engine = e.get_engine("s2t", "opencc")
                    self.addCleanup(engine.close)
                    with self.assertRaisesRegex(e.EngineError, "non-text"):
                        engine.convert("汉")


class NativeResourceTests(unittest.TestCase):
    def test_c_signatures_keep_allocated_output_pointer(self):
        library = fake_library()
        e._bind_native(library)
        self.assertIs(library.opencc_open.restype, ctypes.c_void_p)
        self.assertIs(library.opencc_convert_utf8.restype, ctypes.c_void_p)
        self.assertEqual(library.opencc_convert_utf8.argtypes, [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t])
        self.assertEqual(library.opencc_convert_utf8_free.argtypes, [ctypes.c_void_p])
        self.assertIsNone(library.opencc_convert_utf8_free.restype)
        self.assertIs(library.opencc_close.restype, ctypes.c_int)

    def test_open_rejects_null_and_minus_one_without_closing_invalid_handles(self):
        for pointer in (None, 0, -1, ctypes.c_void_p(-1).value):
            with self.subTest(pointer=pointer):
                library = fake_library()
                library.opencc_open.return_value = pointer
                with self.assertRaisesRegex(e.EngineError, "rejected"):
                    native(library)
                library.opencc_close.assert_not_called()

    def test_open_exception_is_sanitized(self):
        library = fake_library()
        library.opencc_open.side_effect = OSError("loader detail")
        with self.assertRaisesRegex(e.EngineError, "could not open"):
            native(library)
        library.opencc_close.assert_not_called()

    def test_conversion_preserves_text_passes_byte_length_and_frees_exact_pointer(self):
        expected = " \t漢語😀\r\n\r\t"
        library = fake_library(expected.encode("utf-8"))
        engine = native(library)
        self.addCleanup(engine.close)
        source = " \t汉语😀\r\n\r\t"
        self.assertEqual(engine.convert(source), expected)
        library.opencc_open.assert_called_once_with(b"/synthetic/s2t.json")
        library.opencc_convert_utf8.assert_called_once_with(123, source.encode(), len(source.encode()))
        library.opencc_convert_utf8_free.assert_called_once_with(ctypes.addressof(library.buffer))

    def test_empty_output_pointer_is_still_freed(self):
        library = fake_library(b"")
        engine = native(library)
        self.addCleanup(engine.close)
        self.assertEqual(engine.convert(""), "")
        library.opencc_convert_utf8_free.assert_called_once()

    def test_conversion_rejects_invalid_pointer_without_freeing_it(self):
        for pointer in (None, 0, -1, ctypes.c_void_p(-1).value):
            with self.subTest(pointer=pointer):
                library = fake_library()
                library.opencc_convert_utf8.return_value = pointer
                engine = native(library)
                self.addCleanup(engine.close)
                with self.assertRaisesRegex(e.EngineError, "no valid output"):
                    engine.convert("汉")
                library.opencc_convert_utf8_free.assert_not_called()

    def test_conversion_exception_does_not_free_unallocated_output(self):
        library = fake_library()
        library.opencc_convert_utf8.side_effect = RuntimeError("synthetic-input")
        engine = native(library)
        self.addCleanup(engine.close)
        with self.assertRaisesRegex(e.EngineError, "conversion failed"):
            engine.convert("synthetic-input")
        library.opencc_convert_utf8_free.assert_not_called()

    def test_invalid_utf8_output_is_freed_even_on_decode_failure(self):
        library = fake_library(b"\xff")
        engine = native(library)
        self.addCleanup(engine.close)
        with self.assertRaisesRegex(e.EngineError, "decode or release"):
            engine.convert("汉")
        library.opencc_convert_utf8_free.assert_called_once_with(ctypes.addressof(library.buffer))

    def test_output_copy_failure_still_frees_buffer(self):
        library = fake_library()
        engine = native(library)
        self.addCleanup(engine.close)
        with patch.object(e.ctypes, "string_at", side_effect=ValueError("copy failed")):
            with self.assertRaises(e.EngineError):
                engine.convert("汉")
        library.opencc_convert_utf8_free.assert_called_once()

    def test_free_failure_is_not_reported_as_conversion_success(self):
        library = fake_library()
        library.opencc_convert_utf8_free.side_effect = RuntimeError("free failed")
        engine = native(library)
        with self.assertRaisesRegex(e.EngineError, "decode or release"):
            engine.convert("汉")
        engine.close()
        library.opencc_close.assert_called_once_with(123)
        library.opencc_convert_utf8_free.assert_called_once()

    def test_close_releases_handle_exactly_once_and_forbids_conversion(self):
        library = fake_library()
        engine = native(library)
        engine.close()
        engine.close()
        engine.__del__()
        library.opencc_close.assert_called_once_with(123)
        with self.assertRaisesRegex(e.EngineError, "closed"):
            engine.convert("汉")

    def test_failed_close_is_not_retried(self):
        for failure in (7, RuntimeError("close failed")):
            with self.subTest(failure=failure):
                library = fake_library()
                if isinstance(failure, Exception):
                    library.opencc_close.side_effect = failure
                else:
                    library.opencc_close.return_value = failure
                engine = native(library)
                with self.assertRaises(e.EngineError):
                    engine.close()
                engine.close()
                engine.__del__()
                library.opencc_close.assert_called_once_with(123)

    def test_nul_is_rejected_not_truncated_and_auto_retries_entire_input(self):
        library = fake_library()
        engine = native(library)
        with self.assertRaisesRegex(e.EngineError, "embedded NUL"):
            engine.convert("汉\0龙")
        library.opencc_convert_utf8.assert_not_called()
        python_backend = fake_backend("opencc", "漢\0龍")
        with patch.object(e, "_PythonEngine", return_value=python_backend):
            wrapper = e._Engine("s2t", "auto", engine)
            self.addCleanup(wrapper.close)
            self.assertEqual(wrapper.convert("汉\0龙"), "漢\0龍")
            python_backend.convert.assert_called_once_with("汉\0龙")
            library.opencc_close.assert_called_once_with(123)

    def test_unpaired_surrogate_fails_cleanly_without_entering_c(self):
        library = fake_library()
        engine = native(library)
        self.addCleanup(engine.close)
        with self.assertRaises(e.EngineError):
            engine.convert("\ud800")
        library.opencc_convert_utf8.assert_not_called()


class NativeDiscoveryTests(unittest.TestCase):
    def test_known_prefix_precedence_matches_process_architecture(self):
        for machine, prefix in (("arm64", "/opt/homebrew/opt/opencc"), ("x86_64", "/usr/local/opt/opencc")):
            with self.subTest(machine=machine), patch.object(e.platform, "machine", return_value=machine):
                candidates = e._native_candidates()
                self.assertEqual(str(candidates[0][0]), prefix + "/lib/libopencc.1.2.dylib")
                for library, configs in candidates:
                    self.assertEqual(library.parent.parent, configs.parent.parent)

    def test_missing_libraries_or_configs_do_not_load(self):
        with patch.object(e.platform, "system", return_value="Darwin"), \
             patch.object(e.Path, "is_file", return_value=False), \
             patch.object(e.ctypes, "CDLL") as loader:
            with self.assertRaisesRegex(e.EngineError, "No matching Homebrew"):
                e.get_engine("s2t", "native")
            loader.assert_not_called()

    def test_library_without_config_is_not_loaded(self):
        candidates = [(Path("/synthetic/lib/libopencc.dylib"), Path("/synthetic/share/opencc"))]
        with patch.object(e.platform, "system", return_value="Darwin"), \
             patch.object(e, "_native_candidates", return_value=candidates), \
             patch.object(e.Path, "is_file", side_effect=[True, False]), \
             patch.object(e.ctypes, "CDLL") as loader:
            with self.assertRaises(e.EngineError):
                e.get_engine("s2t", "native")
            loader.assert_not_called()

    def test_broken_library_can_try_next_known_installation(self):
        library = fake_library()
        candidates = [
            (Path("/one/lib/libopencc.dylib"), Path("/one/share/opencc")),
            (Path("/two/lib/libopencc.dylib"), Path("/two/share/opencc")),
        ]
        with patch.object(e.platform, "system", return_value="Darwin"), \
             patch.object(e, "_native_candidates", return_value=candidates), \
             patch.object(e.Path, "is_file", return_value=True), \
             patch.object(e.ctypes, "CDLL", side_effect=[OSError("wrong architecture"), library]) as loader:
            engine = e.get_engine("t2s", "native")
            self.addCleanup(engine.close)
            self.assertEqual(loader.call_count, 2)
            library.opencc_open.assert_called_once_with(b"/two/share/opencc/t2s.json")
            self.assertIsNone(engine.metadata()["fallback_reason"])

    def test_missing_c_symbols_is_engine_error(self):
        with patch.object(e.platform, "system", return_value="Darwin"), \
             patch.object(e.Path, "is_file", return_value=True), \
             patch.object(e.ctypes, "CDLL", return_value=object()):
            with self.assertRaisesRegex(e.EngineError, "required C API"):
                e.get_engine("s2t", "native")


class DoctorTests(unittest.TestCase):
    def test_non_darwin_doctor_probes_python_only_and_is_json_safe(self):
        for system in ("Linux", "Windows"):
            engines = []

            def create(mode, backend):
                engine = fake_backend(backend, " \t漢語龍😀\r\n" if mode == "s2t" else " \t汉语龙😀\r\n")
                engines.append(engine)
                return engine

            with self.subTest(system=system), \
                 patch.object(e.platform, "system", return_value=system), \
                 patch.object(e, "get_engine", side_effect=create) as get, \
                 patch.object(e, "_native_candidates") as candidates, \
                 patch.object(e.ctypes, "CDLL") as loader:
                report = e.doctor()
                self.assertEqual(report["platform"]["system"], system)
                self.assertFalse(report["engines"]["native"]["supported"])
                self.assertTrue(report["engines"]["opencc"]["available"])
                self.assertEqual(report["auto_backend"], "opencc")
                self.assertEqual([call.args for call in get.call_args_list], [("s2t", "opencc"), ("t2s", "opencc")])
                for engine in engines:
                    engine.close.assert_called_once()
                json.dumps(report)
                candidates.assert_not_called()
                loader.assert_not_called()

    def test_failed_probes_do_not_claim_availability(self):
        with patch.object(e.platform, "system", return_value="Linux"), \
             patch.object(e, "get_engine", side_effect=e.EngineError("Missing converter.")):
            report = e.doctor()
            self.assertIsNone(report["auto_backend"])
            self.assertFalse(report["engines"]["opencc"]["available"])
            self.assertEqual(report["engines"]["opencc"]["probes"]["s2t"]["code"], "engine_error")
            json.dumps(report)

    def test_wrong_result_and_cleanup_failure_mark_probe_failed(self):
        for result, close_error in (("wrong", None), (" \t漢語龍😀\r\n", e.EngineError("Close failed."))):
            with self.subTest(result=result, close_error=close_error):
                backend = fake_backend("opencc", result)
                backend.close.side_effect = close_error
                with patch.object(e.platform, "system", return_value="Linux"), \
                     patch.object(e, "get_engine", side_effect=lambda *args: backend):
                    report = e.doctor()
                    self.assertFalse(report["engines"]["opencc"]["available"])
                    self.assertFalse(report["engines"]["opencc"]["probes"]["s2t"]["ok"])
                    self.assertEqual(backend.close.call_count, 2)


class RealPythonTests(unittest.TestCase):
    def setUp(self):
        try:
            import opencc
        except ImportError:
            self.skipTest("Optional Python OpenCC package is not installed.")
        self.assertTrue(callable(opencc.OpenCC))

    def test_both_directions_whitespace_non_bmp_and_phrase_context(self):
        for mode, source, expected in (
            ("s2t", " \t头发 汉语 龙 😀𠀀\r\n\n\r\u200b", " \t頭髮 漢語 龍 😀𠀀\r\n\n\r\u200b"),
            ("t2s", " \t頭髮 漢語 龍 😀𠀀\r\n\n\r\u200b", " \t头发 汉语 龙 😀𠀀\r\n\n\r\u200b"),
        ):
            with self.subTest(mode=mode):
                engine = e.get_engine(mode, "opencc")
                self.addCleanup(engine.close)
                self.assertEqual(engine.convert(source), expected)
                self.assertEqual(engine.convert(""), "")
                self.assertEqual(engine.convert(" \t\r\n\n\r"), " \t\r\n\n\r")
                json.dumps(engine.metadata())

    def test_long_phrase_input_and_embedded_nul_are_not_lost(self):
        engine = e.get_engine("s2t", "opencc")
        self.addCleanup(engine.close)
        self.assertEqual(engine.convert("头发" * 10000 + "\r\n"), "頭髮" * 10000 + "\r\n")
        self.assertEqual(engine.convert("汉\0龙"), "漢\0龍")


@unittest.skipUnless(platform.system() == "Darwin", "Real native OpenCC tests require macOS.")
class RealNativeTests(unittest.TestCase):
    def setUp(self):
        if not any(library.is_file() and (configs / "s2t.json").is_file() and (configs / "t2s.json").is_file()
                   for library, configs in e._native_candidates()):
            self.skipTest("No native Homebrew OpenCC library/config installation is available.")

    def test_both_directions_and_resource_reuse(self):
        for mode, source, expected in (
            ("s2t", " \t头发 汉语 龙 😀𠀀\r\n\n\r\u200b", " \t頭髮 漢語 龍 😀𠀀\r\n\n\r\u200b"),
            ("t2s", " \t頭髮 漢語 龍 😀𠀀\r\n\n\r\u200b", " \t头发 汉语 龙 😀𠀀\r\n\n\r\u200b"),
        ):
            with self.subTest(mode=mode):
                engine = e.get_engine(mode, "native")
                self.addCleanup(engine.close)
                for _ in range(8):
                    self.assertEqual(engine.convert(source), expected)
                self.assertEqual(engine.convert(""), "")
                self.assertEqual(engine.convert(" \t\r\n\n\r"), " \t\r\n\n\r")
                self.assertEqual(engine.name, "native")
                engine.close()
                engine.close()

    def test_real_doctor_probes_native_both_directions(self):
        report = e.doctor()
        self.assertTrue(report["engines"]["native"]["available"])
        self.assertTrue(report["engines"]["native"]["probes"]["s2t"]["ok"])
        self.assertTrue(report["engines"]["native"]["probes"]["t2s"]["ok"])
        json.dumps(report)


if __name__ == "__main__":
    unittest.main()
