from __future__ import annotations
import contextlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import learning_store as learning
import learn_dictionary as commands
import correct_chinese_errata as workflow
import build_dictionary as builder
import dictionary_releases as releases
from file_support import ErratumError, packed, sha, read_json


class FakeConverter:
    info = {"fixture": True}

    def simplify(self, text):
        return text.translate(
            str.maketrans("數據統記計項獨創體們學習", "数据统记计项独创体们学习")
        )

    def traditional(self, text):
        return text.translate(
            str.maketrans("数据统记计项独创体们学习", "數據統記計項獨創體們學習")
        )


class LearningTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.store = self.root / "private-learning"
        self.engine = FakeConverter()
        self.dictionary = self.root / "job-dictionary.json"
        self.dictionary.write_text("{}")
        self.counter = 0

    def args(self, document, **extra):
        args = workflow.build_arg_parser().parse_args(
            [
                "-i",
                str(document),
                "--output-root",
                str(self.root / "jobs"),
                "--homophone-json",
                str(self.dictionary),
            ]
        )
        for key, value in extra.items():
            setattr(args, key, value)
        return args

    def answer(self, result, fn):
        for request in result["pending_requests"]:
            packet = json.loads(Path(request["request_path"]).read_text())
            rows = [
                {"id": u["id"], "text": fn(u["text"])}
                for u in packet["payload"]["items"]
            ]
            Path(request["response_path"]).write_text(
                json.dumps(
                    {"request_id": packet["request_id"], "corrections": rows},
                    ensure_ascii=False,
                )
            )

    def job(
        self,
        text="数据统记。",
        fn=lambda s: s.replace("统记", "统计").replace("統記", "統計"),
        no_ai=False,
        encoding="utf-8",
    ):
        self.counter += 1
        document = self.root / f"input-{self.counter}.txt"
        document.write_bytes(text.encode(encoding))
        result, code = workflow.start(self.args(document, no_ai=no_ai))
        while code == 10:
            self.answer(result, fn)
            result, code = workflow.resume(result["job_dir"])
        self.assertEqual(code, 0, result)
        return Path(result["job_dir"])

    def collect(self, job):
        return learning.collect_job(job, self.store, self.engine)

    def candidate(self):
        rows = learning.list_candidates(self.store)["candidates"]
        self.assertEqual(len(rows), 1)
        return learning.inspect_candidate(rows[0]["id"], self.store)["candidate"]

    def decision(self, item, action="approve", **extra):
        return {
            "candidate_id": item["id"],
            "expect_revision": item["revision"],
            "decision": action,
            "reason": "Synthetic human-review fixture, not a real user approval.",
            "confirmed_by_user": True,
            **extra,
        }

    def approve(self, item=None):
        item = item or self.candidate()
        learning.review_candidates([self.decision(item)], self.store, self.engine)
        return self.candidate()

    def targets(self):
        root = self.root / "dictionary"
        root.mkdir(exist_ok=True)
        source = root / "source.json"
        runtime = root / "runtime.json"
        report = root / "report.json"
        data = {
            "_schema": 1,
            "_review_only": {},
            "_approved_non_roundtrip": {},
            "测试错字": "测试正字",
        }
        source.write_bytes(builder.render(data))
        table, details = builder.compile_dictionary(
            data, self.engine, sha(source.read_bytes())
        )
        runtime.write_bytes(builder.render(table))
        details["runtime_sha256"] = sha(runtime.read_bytes())
        report.write_bytes(builder.render(details))
        return source, runtime, report

    def stage(self, item=None):
        item = item or self.candidate()
        targets = self.targets()
        result = commands.stage_candidates(
            [item["id"]], self.store, *targets, converter=self.engine
        )
        return result, targets

    def test_collect_is_pending_and_never_changes_dictionary(self):
        original = self.dictionary.read_bytes()
        job = self.job()
        result = self.collect(job)
        self.assertEqual(result["new_candidates"], 1)
        self.assertEqual(result["automatically_approved"], 0)
        self.assertFalse(result["dictionary_changed"])
        self.assertEqual(self.dictionary.read_bytes(), original)
        item = self.candidate()
        self.assertEqual((item["wrong"], item["right"]), ("数据统记", "数据统计"))
        self.assertEqual(item["status"], "pending")
        self.assertEqual(len(item["evidence"]), 1)
        self.assertNotIn(
            "before_context",
            json.dumps(learning.list_candidates(self.store), ensure_ascii=False),
        )

    def test_identical_content_does_not_gain_votes_across_paths_encodings_scripts(self):
        a = self.job("数据统记。\n")
        b = self.job("数据统记。\r\n", encoding="utf-16")
        c = self.job("數據統記。\n")
        self.collect(a)
        again = self.collect(a)
        self.collect(b)
        self.collect(c)
        self.assertEqual(again["new_content_evidence"], 0)
        self.assertEqual(len(self.candidate()["evidence"]), 1)

    def test_different_contents_accumulate_but_never_auto_approve(self):
        for suffix in ("甲段", "乙段", "丙段"):
            self.collect(self.job("数据统记。" + suffix + "。"))
        item = self.candidate()
        self.assertEqual(len(item["evidence"]), 3)
        self.assertEqual(item["status"], "pending")

    def test_no_local_only_or_local_stage_feedback_loop(self):
        result = self.collect(self.job(no_ai=True))
        self.assertEqual(result["new_candidates"], 0)
        self.assertEqual(result["skipped"]["local_only_not_ai_evidence"], 1)
        self.dictionary.write_text(
            json.dumps({"数据统计": "数据统记"}, ensure_ascii=False)
        )
        result = self.collect(self.job("数据统计。"))
        self.assertEqual(result["new_candidates"], 0)
        self.assertEqual(
            result["skipped"]["local_stage_modified_segment_not_learned"], 1
        )

    def test_script_only_numeric_sensitive_and_teaching_examples_are_not_learned(self):
        cases = [
            (
                "数据统计。",
                lambda s: s.replace("数据统计", "數據統計"),
                "script_only_or_normalized_noop",
            ),
            (
                "营收一亿元。",
                lambda s: s.replace("一亿", "一万"),
                "numeric_or_quantity_change_not_learned",
            ),
            (
                "账户数据统记。",
                lambda s: s.replace("统记", "统计"),
                "sensitive_context_not_collected",
            ),
            (
                "错误写法数据统记。",
                lambda s: s.replace("统记", "统计"),
                "instructional_example_not_collected",
            ),
        ]
        for text, fn, reason in cases:
            with self.subTest(reason=reason):
                result = self.collect(self.job(text, fn))
                self.assertEqual(result["new_candidates"], 0)
                self.assertIn(reason, result["skipped"])

    def test_existing_script_sensitive_rule_is_not_new_experience(self):
        self.dictionary.write_text(
            json.dumps(
                {
                    "_script_sensitive": {
                        "全神灌注": {
                            "simplified": "全神贯注",
                            "traditional": "全神貫注",
                        }
                    }
                },
                ensure_ascii=False,
            )
        )
        result = self.collect(self.job("全神灌注。", lambda s: s.replace("灌", "贯")))
        self.assertEqual(result["new_candidates"], 0)
        self.assertIn("already_known_rule_not_new_experience", result["skipped"])

    def test_one_character_never_learned_and_short_rule_cannot_be_approved(self):
        result = self.collect(self.job("记。", lambda s: s.replace("记", "计")))
        self.assertEqual(result["new_candidates"], 0)
        self.collect(self.job("统记。"))
        item = self.candidate()
        with self.assertRaisesRegex(ErratumError, "4_to_24"):
            learning.review_candidates([self.decision(item)], self.store, self.engine)

    def test_incomplete_or_tampered_evidence_does_not_write_candidates(self):
        path = self.root / "input.txt"
        path.write_text("数据统记。")
        result, code = workflow.start(self.args(path))
        self.assertEqual(code, 10)
        with self.assertRaisesRegex(ErratumError, "incomplete"):
            self.collect(result["job_dir"])
        self.assertFalse(self.store.exists())
        self.answer(result, lambda s: s.replace("统记", "统计"))
        result, code = workflow.resume(result["job_dir"])
        receipt = Path(result["job_dir"]) / ".work/completed/000000.json"
        r = json.loads(receipt.read_text())
        r["changes"][-1]["after"] = "伪造记录"
        receipt.write_text(json.dumps(r, ensure_ascii=False))
        with self.assertRaisesRegex(ErratumError, "not_supported_by_output"):
            self.collect(result["job_dir"])
        self.assertFalse(self.store.exists())

    def test_source_or_final_or_accepted_record_tampering_rejected(self):
        for target in ("source", "output", "accepted"):
            job = self.job()
            receipt = json.loads((job / ".work/completed/000000.json").read_text())
            if target == "source":
                path = Path(receipt["source"])
            elif target == "output":
                path = Path(receipt["output"])
            else:
                path = job / ".work/accepted/000000/000000.json"
            path.write_text("tampered")
            with self.subTest(target=target), self.assertRaises(Exception):
                self.collect(job)
        self.assertFalse(self.store.exists())

    def test_explicit_review_and_compare_and_swap_required(self):
        self.collect(self.job())
        item = self.candidate()
        invalid = self.decision(item)
        invalid["confirmed_by_user"] = False
        with self.assertRaisesRegex(ErratumError, "explicit_human"):
            learning.review_candidates([invalid], self.store, self.engine)
        invalid = self.decision(item)
        invalid["expect_revision"] = "0" * 64
        with self.assertRaisesRegex(ErratumError, "revision_changed"):
            learning.review_candidates([invalid], self.store, self.engine)
        self.assertEqual(self.candidate()["status"], "pending")
        self.approve()
        self.assertEqual(self.candidate()["status"], "approved")

    def test_rule_refinement_must_explain_observed_change(self):
        self.collect(self.job("数据统记需要更新。"))
        item = self.candidate()
        invalid = self.decision(item, wrong="其他错误", right="其他正确")
        with self.assertRaisesRegex(ErratumError, "not_supported"):
            learning.review_candidates([invalid], self.store, self.engine)
        learning.review_candidates(
            [self.decision(item, wrong="数据统记", right="数据统计")],
            self.store,
            self.engine,
        )
        self.assertEqual(
            self.candidate()["approved_rule"],
            {"wrong": "数据统记", "right": "数据统计"},
        )

    def test_rejection_is_sticky_and_new_evidence_invalidates_approval(self):
        self.collect(self.job("数据统记。甲段。"))
        item = self.candidate()
        learning.review_candidates(
            [self.decision(item, "reject")], self.store, self.engine
        )
        self.collect(self.job("数据统记。乙段。"))
        self.assertEqual(self.candidate()["status"], "rejected")
        self.approve()
        self.collect(self.job("数据统记。丙段。"))
        self.assertEqual(self.candidate()["status"], "pending")

    def test_alternative_targets_block_automatic_choice(self):
        self.collect(self.job())
        self.collect(
            self.job("数据统记。乙段。", lambda s: s.replace("统记", "统计学"))
        )
        items = learning.list_candidates(self.store)["candidates"]
        self.assertEqual(len(items), 2)
        item = learning.inspect_candidate(items[0]["id"], self.store)["candidate"]
        with self.assertRaisesRegex(ErratumError, "alternative_targets"):
            learning.review_candidates([self.decision(item)], self.store, self.engine)

    def test_stage_requires_approval_and_publish_requires_execute(self):
        self.collect(self.job())
        item = self.candidate()
        targets = self.targets()
        before = [p.read_bytes() for p in targets]
        with self.assertRaisesRegex(ErratumError, "not_human_approved"):
            commands.stage_candidates(
                [item["id"]], self.store, *targets, converter=self.engine
            )
        self.approve()
        item = self.candidate()
        plan = commands.stage_candidates(
            [item["id"]], self.store, *targets, converter=self.engine
        )
        self.assertEqual([p.read_bytes() for p in targets], before)
        with self.assertRaisesRegex(ErratumError, "explicit_execute"):
            commands.transition_release(plan["plan_id"], "publish", self.store)
        self.assertEqual([p.read_bytes() for p in targets], before)

    def test_publish_then_rollback_changes_only_fixture_dictionary(self):
        self.collect(self.job())
        self.approve()
        plan, targets = self.stage()
        before = [p.read_bytes() for p in targets]
        result = commands.transition_release(
            plan["plan_id"], "publish", self.store, True
        )
        self.assertEqual(result["status"], "published")
        self.assertEqual(json.loads(targets[0].read_text())["数据统记"], "数据统计")
        self.assertEqual(self.candidate()["status"], "published")
        with self.assertRaisesRegex(ErratumError, "requires_rollback"):
            learning.review_candidates(
                [self.decision(self.candidate(), "reject")], self.store, self.engine
            )
        result = commands.transition_release(
            plan["plan_id"], "rollback", self.store, True
        )
        self.assertEqual(result["status"], "rolled_back")
        self.assertEqual([p.read_bytes() for p in targets], before)
        self.assertEqual(self.candidate()["status"], "rejected")
        commands.transition_release(plan["plan_id"], "rollback", self.store, True)
        self.assertEqual([p.read_bytes() for p in targets], before)

    def test_changed_approval_or_target_invalidates_plan(self):
        self.collect(self.job())
        self.approve()
        plan, targets = self.stage()
        before = [p.read_bytes() for p in targets]
        learning.review_candidates(
            [self.decision(self.candidate(), "reject")], self.store, self.engine
        )
        with self.assertRaisesRegex(ErratumError, "approval_changed"):
            commands.transition_release(plan["plan_id"], "publish", self.store, True)
        self.assertEqual([p.read_bytes() for p in targets], before)
        self.approve()
        plan = commands.stage_candidates(
            [self.candidate()["id"]], self.store, *targets, converter=self.engine
        )
        targets[0].write_bytes(targets[0].read_bytes() + b" ")
        with self.assertRaisesRegex(ErratumError, "hash_mismatch"):
            commands.transition_release(plan["plan_id"], "publish", self.store, True)

    def test_commit_receipt_failure_reconciles_without_rewriting_dictionary(self):
        self.collect(self.job())
        self.approve()
        plan, targets = self.stage()
        with patch(
            "learn_dictionary.save_store",
            side_effect=OSError("synthetic ledger failure"),
        ):
            with self.assertRaises(OSError):
                commands.transition_release(
                    plan["plan_id"], "publish", self.store, True
                )
        modified = [p.stat().st_mtime_ns for p in targets]
        result = commands.transition_release(
            plan["plan_id"], "publish", self.store, True
        )
        self.assertEqual(result["status"], "published")
        self.assertEqual([p.stat().st_mtime_ns for p in targets], modified)
        self.assertEqual(self.candidate()["status"], "published")

    def test_existing_compiler_obeys_shared_dictionary_lock(self):
        targets = self.targets()
        args = [
            "--source",
            str(targets[0]),
            "--output",
            str(targets[1]),
            "--report",
            str(targets[2]),
            "--write",
            "--replace",
        ]
        with releases.dictionary_lock(targets[0]), patch(
            "build_dictionary.Converter", return_value=self.engine
        ), contextlib.redirect_stdout(io.StringIO()) as out:
            code = builder.main(args)
        self.assertEqual(code, 2)
        self.assertIn("dictionary_writer_locked", out.getvalue())

    def test_collection_hook_is_opt_in_and_inherited_by_resume(self):
        self.counter += 1
        doc = self.root / "hook.txt"
        doc.write_text("数据统记。")
        args = self.args(doc, learn=True, learning_store=self.store)
        result, code = workflow.start(args)
        self.assertEqual(code, 10)
        self.assertTrue(
            json.loads((Path(result["job_dir"]) / "manifest.json").read_text())[
                "options"
            ]["learn"]
        )
        self.answer(result, lambda s: s.replace("统记", "统计"))
        resume_args = workflow.build_arg_parser().parse_args(
            ["--resume", result["job_dir"]]
        )
        result, code = workflow.resume(result["job_dir"])
        with patch("learning_store.Converter", return_value=self.engine):
            result, code = workflow.collect_requested_experience(
                result, code, resume_args
            )
        self.assertEqual(code, 0)
        self.assertEqual(result["learning"]["new_candidates"], 1)
        self.assertEqual(self.candidate()["status"], "pending")

    def test_learning_failure_does_not_erase_successful_corrections(self):
        job = self.job()
        result, code = workflow.resume(job)
        args = workflow.build_arg_parser().parse_args(
            ["--resume", str(job), "--learn", "--learning-store", str(self.store)]
        )
        with patch(
            "learning_store.collect_job",
            side_effect=ErratumError("synthetic_learning_failure"),
        ):
            result, code = workflow.collect_requested_experience(result, code, args)
        self.assertEqual(code, 1)
        self.assertEqual(result["completed"], 1)
        self.assertEqual(result["correction_exit_code"], 0)
        self.assertEqual(result["learning"]["reason"], "synthetic_learning_failure")
        self.assertTrue(Path(result["documents"][0]["output"]).exists())

    def test_review_batch_is_all_or_nothing_and_store_lock_is_retained(self):
        self.collect(self.job())
        item = self.candidate()
        before = (self.store / "candidates.json").read_bytes()
        invalid = self.decision(item)
        invalid["candidate_id"] = "0" * 64
        with self.assertRaises(ErratumError):
            learning.review_candidates(
                [self.decision(item), invalid], self.store, self.engine
            )
        self.assertEqual((self.store / "candidates.json").read_bytes(), before)
        (self.store / ".lock").mkdir()
        with self.assertRaisesRegex(ErratumError, "locked"):
            learning.list_candidates(self.store)
        self.assertTrue((self.store / ".lock").exists())

    def test_privacy_and_listing_page(self):
        self.assertEqual(learning.list_candidates(self.store)["total"], 0)
        self.assertFalse(self.store.exists())
        self.collect(self.job())
        listing = learning.list_candidates(self.store)
        self.assertNotIn("数据", json.dumps(listing, ensure_ascii=False))
        self.assertEqual(listing["total"], 1)
        self.assertIn(
            "数据统记",
            json.dumps(learning.list_candidates(self.store, True), ensure_ascii=False),
        )
        self.assertEqual(
            learning.list_candidates(self.store, offset=1)["candidates"], []
        )
        self.assertEqual((self.store / "candidates.json").stat().st_mode & 0o077, 0)

    def test_terminal_retry_preserves_later_explicit_review(self):
        self.collect(self.job())
        self.approve()
        plan, targets = self.stage()
        commands.transition_release(plan["plan_id"], "publish", self.store, True)
        commands.transition_release(plan["plan_id"], "rollback", self.store, True)
        approved = self.approve()
        result = commands.transition_release(
            plan["plan_id"], "rollback", self.store, True
        )
        self.assertTrue(result["already_completed"])
        self.assertEqual(self.candidate()["revision"], approved["revision"])

    def test_release_stdout_contains_no_candidate_text(self):
        self.collect(self.job())
        self.approve()
        plan, targets = self.stage()
        result = commands.transition_release(
            plan["plan_id"], "publish", self.store, True
        )
        self.assertNotIn("数据", json.dumps(result, ensure_ascii=False))
        self.assertEqual(
            commands.release_status(plan["plan_id"], self.store)["status"], "published"
        )

    def test_partial_release_recovery_rejects_candidates_without_republishing(self):
        self.collect(self.job())
        self.approve()
        plan, targets = self.stage()
        before = [p.read_bytes() for p in targets]
        original = releases._store

        def fail(path, raw, *args, **kwargs):
            if Path(path) == targets[1]:
                raise OSError("fixture interruption")
            return original(path, raw, *args, **kwargs)

        with patch("dictionary_releases._store", side_effect=fail):
            with self.assertRaisesRegex(ErratumError, "release_transition_incomplete"):
                commands.transition_release(
                    plan["plan_id"], "publish", self.store, True
                )
        self.assertEqual(
            commands.release_status(plan["plan_id"], self.store)["status"], "publishing"
        )
        result = commands.transition_release(
            plan["plan_id"], "recover", self.store, True
        )
        self.assertEqual(result["status"], "recovered")
        self.assertEqual([p.read_bytes() for p in targets], before)
        self.assertEqual(self.candidate()["status"], "rejected")

    def test_no_learn_can_override_saved_opt_in_without_reading_store(self):
        args = workflow.build_arg_parser().parse_args(
            ["--resume", "/unused", "--no-learn"]
        )
        result = {"job_dir": "/unused", "completed": 1, "status": "complete"}
        with patch(
            "correct_chinese_errata.read_json",
            side_effect=AssertionError("must not read"),
        ):
            result, code = workflow.collect_requested_experience(result, 0, args)
        self.assertEqual(code, 0)
        self.assertEqual(result["learning"]["status"], "disabled_for_this_invocation")

    def test_default_dry_run_and_local_only_do_not_collect(self):
        job = self.job()
        result, code = workflow.resume(job)
        args = workflow.build_arg_parser().parse_args(["--resume", str(job)])
        with patch(
            "learning_store.collect_job", side_effect=AssertionError("must not collect")
        ):
            unchanged, code = workflow.collect_requested_experience(result, code, args)
            self.assertNotIn("learning", unchanged)
            args.learn = True
            dry, code = workflow.collect_requested_experience(
                {"status": "dry_run"}, 0, args
            )
            self.assertEqual(dry["learning"]["status"], "deferred_until_complete")
            local, code = workflow.collect_requested_experience(
                {"status": "complete", "job_dir": str(job), "use_ai": False}, 0, args
            )
            self.assertEqual(local["learning"]["status"], "not_applicable")
        self.assertFalse(self.store.exists())

    def test_postprocessing_manifest_failure_keeps_completion(self):
        args = workflow.build_arg_parser().parse_args(
            ["--resume", "/unused", "--learn"]
        )
        with patch(
            "correct_chinese_errata.read_json",
            side_effect=ErratumError("fixture_manifest_failure"),
        ):
            result, code = workflow.collect_requested_experience(
                {"status": "complete", "completed": 1, "job_dir": "/unused"}, 0, args
            )
        self.assertEqual(code, 1)
        self.assertEqual(result["completed"], 1)
        self.assertEqual(result["correction_exit_code"], 0)

    def test_known_script_sensitive_rule_inside_larger_phrase_is_not_relearned(self):
        self.dictionary.write_text(
            json.dumps(
                {
                    "_script_sensitive": {
                        "全神灌注": {
                            "simplified": "全神贯注",
                            "traditional": "全神貫注",
                        }
                    }
                },
                ensure_ascii=False,
            )
        )
        result = self.collect(
            self.job("我们全神灌注地学习。", lambda s: s.replace("灌", "贯"))
        )
        self.assertEqual(result["new_candidates"], 0)
        self.assertIn("already_known_rule_not_new_experience", result["skipped"])

    def test_private_store_and_malformed_store_fail_closed(self):
        with self.assertRaisesRegex(ErratumError, "outside_skill_source"):
            with learning.store_session(
                SCRIPTS.parent / "forbidden-learning", create=True
            ):
                self.fail("private data must not be written into the skill")
        self.assertFalse((SCRIPTS.parent / "forbidden-learning").exists())
        self.collect(self.job())
        original = json.loads((self.store / "candidates.json").read_text())
        malformed = json.loads(json.dumps(original))
        malformed["version"] = True
        with self.assertRaisesRegex(ErratumError, "invalid_learning_store"):
            learning.validate_store(malformed)
        item = next(iter(original["candidates"].values()))
        item["flags"] = None
        learning.refresh(item)
        with self.assertRaisesRegex(ErratumError, "invalid_learning_flags"):
            learning.validate_store(original)
        import os

        if os.name == "posix":
            self.store.chmod(0o755)
            with self.assertRaisesRegex(ErratumError, "private_and_owned"):
                learning.list_candidates(self.store)


if __name__ == "__main__":
    unittest.main()
