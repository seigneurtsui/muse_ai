---
name: smtp-email
description: 使用 SMTP 协议发送邮件。支持配置各种 SMTP 服务器，包括 QQ 邮箱、Gmail 等。
version: 1.0.0
metadata:
  hermes:
    tags: [邮件, SMTP, 发送, 邮箱, QQ邮箱, Gmail]
    related_skills: [amap-route]
---

# SMTP 邮件发送技能

使用 SMTP 协议发送邮件。

## 功能特性

- 通过 SMTP 服务器发送邮件
- 支持 HTML 和纯文本内容
- 支持多个 SMTP 提供商（QQ 邮箱、Gmail、自建服务器等）
- 可配置的邮件发送功能
- 集成到其他技能（如 amap-route）

## 配置

### 方法 1: 使用环境变量

配置文件位于 `~/.config/omnirush/.env`，技能会自动读取其中的以下变量：

```bash
SMTP_HOST=<your-smtp-host>
SMTP_PORT=<your-smtp-port>
SMTP_USER=<your-smtp-user>
SMTP_PASS=<your-smtp-app-password>
SMTP_FROM=<your-from-address>
```

### 方法 2: 使用配置文件

运行配置命令：

```bash
cd ~/.config/omnirush/skills/smtp-email
node index.js setup <host> <port> <user> <app-password> <from>
```

## 使用方法

### CLI 用法

```bash
# 发送邮件
node index.js send --to recipient@example.com --subject "Hello" --html "<p>Content</p>"

# 验证 SMTP 连接
node index.js verify

# 查看配置状态
node index.js config
```

### Node.js 用法

```javascript
const { sendSmtpEmail } = require('./index.js');

// 发送邮件
await sendSmtpEmail({
  to: "recipient@example.com",
  subject: "Hello from SMTP",
  html: "<p>This is an email sent via SMTP</p>",
  text: "This is an email sent via SMTP"
});
```

### 集成到其他技能

在其他技能中调用 SMTP 邮件发送：

```javascript
const path = require('path');
const { sendSmtpEmail } = require(path.join(__dirname, '..', 'email', 'smtp-email', 'index.js'));

await sendSmtpEmail({
  to: "gc40800@gmail.com",
  subject: "自驾路线: 南阳 → 武当山",
  html: "<h1>路线详情</h1><p>距离: 1415.01 公里</p>"
});
```

**集成案例**：amap-route 技能自动调用此技能发送路线邮件

## 常见问题

### Q: 如何获取 QQ 邮箱 SMTP 授权码？
A: 登录 QQ 邮箱 → 设置 → 账户 → 开启 POP3/SMTP 服务 → 获取授权码

### Q: Gmail 需要应用密码吗？
A: 是的，Gmail 需要使用应用密码而非登录密码

### Q: 端口 465 和 587 有什么区别？
A: 465 使用 SSL/TLS 加密（secure: true），587 使用 STARTTLS（secure: false）

### Q: 如何验证配置是否正确？
A: 运行 `node index.js verify` 检查 SMTP 连接

## 当前配置状态

- **SMTP 配置来源**: `~/.config/omnirush/.env`
- **SMTP 服务器、端口、用户和发件人**: 由 `SMTP_*` 环境变量提供
- **默认收件人**: 由调用方的 `--to` 参数提供

## 依赖项

- Node.js
- nodemailer: `npm install nodemailer`
## 踩坑记录 (Pitfalls)

### ❌ 邮件内容为空 — `--file` 参数未实现

**现象**：使用 `--file` 参数发送邮件，但收到的邮件内容为空。

**原因**：
1. `--html` 参数期望读取值作为 HTML 内容，而不是作为开关
2. `--file` 参数未实现
3. 代码逻辑：`if (!opts.html)` 检查导致需要 `--html` 参数

**修复**（2026-04-22）：
```javascript
// 添加 --file 支持
if (args[i] === '--file' && args[i + 1]) {
  const filePath = args[++i];
  opts.text = fs.readFileSync(filePath, 'utf8');
}

// 自动将纯文本转换为精美 HTML
if (!opts.html && opts.text) {
  opts.html = buildHtmlEmail(opts.subject, opts.text, opts.style || 'red');
  delete opts.text;
}
```

**正确用法**：
```bash
node index.js send --to receiver@example.com --subject "标题" --file /path/to/content.txt
```

### ❌ 邮件格式太丑 — 纯文本直接发送

**现象**：直接发送文件内容作为 HTML，导致格式混乱，显示效果差。

**原因**：文件内容是纯文本格式（带 emoji、特殊字符），直接作为 HTML 发送未被渲染。

**修复**（2026-04-22）：
添加 `buildHtmlEmail()` 函数，自动将纯文本转换为精美的 HTML 邮件：

- 渐变 Header 主题色
- 圆角卡片布局
- 精美的 Footer 签名
- 支持主题样式：red / blue / green / purple

```javascript
// 自动美化
opts.html = buildHtmlEmail(opts.subject, opts.text, opts.style || 'red');
```

---

*此技能已适配 OpenCode，最后更新: 2026-04-22*