#!/usr/bin/env python3
"""YouTube / 本地媒体统一总结编排器 v7。

v7 保留 v4 的 YouTube 完整流程，并加入 v6 的本地媒体流程：
- YouTube 有字幕：youtube_video_summarizer.py
- YouTube 无字幕：youtube_audio_downloader.py -> STT -> AI 总结
- 本地音频：直接 STT -> AI 总结
- 本地视频：ffmpeg 提取音频 -> STT -> AI 总结

STT 方案（通过 --stt-provider 切换，默认 elevenlabs）：
- elevenlabs（默认）：elevenlabs_stt_fallback_keys.py 外部脚本方案
- crispasr（备用方案 1）：本地 CRISP_ASR
- vibeasr（备用方案 2）：本地 VibeASR
- whisper（备用方案 3）：本地 Whisper.cpp

历史日志：
- YOUTUBE_LOG_FILE: ~/Downloads/youtube_video_scoops/video_list_history.csv
- MEDIA_LOG_FILE:   ~/Downloads/youtube_video_scoops/media_list_history.csv
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import ssl
import shlex
import shutil
import smtplib
import subprocess
import sys
import threading
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from typing import Any

try:
    import requests
except ImportError:
    requests = None

SCRIPT_DIR = Path(__file__).resolve().parent
SUMMARIZER_SCRIPT = SCRIPT_DIR / "youtube_video_summarizer.py"
DOWNLOADER_SCRIPT = SCRIPT_DIR / "youtube_audio_downloader.py"
STT_SCRIPT = SCRIPT_DIR / "elevenlabs_stt_fallback_keys.py"
FASTERWHISPER_STT_SCRIPT = SCRIPT_DIR / "stt_fasterwhisper_batch.py"  # ← 新增


# ============================================
# 本地化 STT 方案配置（新增，最小改动，不影响原有 ElevenLabs 外部脚本方案）
# ============================================
# 默认 STT 方案：elevenlabs（原有 elevenlabs_stt_fallback_keys.py 外部脚本方案）
# 可选备用方案：crispasr / vibeasr / whisper（均为本地进程内直接调用，不依赖外部脚本）
# ~ DEFAULT_STT_PROVIDER = "elevenlabs"
#DEFAULT_STT_PROVIDER = "azurestt"
DEFAULT_STT_PROVIDER = "crispasr"
#DEFAULT_STT_PROVIDER = "fasterwhisper"
#DEFAULT_STT_PROVIDER = "vibeasr"
# ~ DEFAULT_STT_PROVIDER = "whisper"

		
# --- 备用方案 1：CRISP_ASR（crispasr） ---
# 涉及 /Users/seigneur 路径已替换为 ~，方便跨环境迁移
# ~ CRISPASR_BIN = os.path.expanduser("~/lavoro/translate/crispASR/crispasr")  # 如系统已装到 /usr/local/bin/crispasr 可直接改为该路径
CRISPASR_BIN = "/usr/local/bin/crispasr" 
COHERE_MODEL_PATH = os.path.expanduser("~/lavoro/translate/crispASR/cohere-transcribe-q4_k.gguf")

# --- 备用方案 2：VibeASR（vibeasr） ---
VIBEASR_BIN = os.path.expanduser("~/lavoro/vibeASR/build/bin/asr_infer")
VAE_MODEL_PATH = os.path.expanduser("~/lavoro/vibeASR/models/vibeasr/vibeasr-vae-encoder-i8_s.gguf")
LM_MODEL_PATH = os.path.expanduser("~/lavoro/vibeASR/models/vibeasr/vibeasr-lm-i2_s-embed-q6_k.gguf")

# --- 备用方案 3：Whisper.cpp（whisper） ---
WHISPER_LIB_DIR = os.path.expanduser("~/lavoro/translate/whisper.cpp/build/src")
os.environ["DYLD_LIBRARY_PATH"] = (
    WHISPER_LIB_DIR + ":" + os.environ.get("DYLD_LIBRARY_PATH", "")
).rstrip(":")
WHISPER_BIN = os.path.expanduser("~/lavoro/translate/whisper/main")
WHISPER_MODEL = os.path.expanduser("~/lavoro/translate/whisper/models/ggml-large-v3-turbo.bin")
WHISPER_LANG = "auto"

# ============================================
# STT API Keys（内嵌配置，方便编辑）
# ============================================
STT_API_KEYS = {
    "azure": {
        "key": "CGyKY7toOZlcSATK6UDOJW9EoZbzOr72AHRb5uyvuUwB7HAVUNX7JQQJ99CHAC3pKaRXJ3w3AAAYACOGsPfc",
        "region": "eastasia"
    }
}

DEFAULT_ROOT = Path.home() / "Downloads" / "youtube_video_scoops"
YOUTUBE_LOG_FILE = os.path.expanduser("~/Downloads/youtube_video_scoops/video_list_history.csv")
MEDIA_LOG_FILE = os.path.expanduser("~/Downloads/youtube_video_scoops/media_list_history.csv")
NOTIFY_CONFIG_FILE = str(SCRIPT_DIR / ".youtube_scoops_notify.json")
URL_RE = re.compile(r"https?://(?:www\.)?(?:youtube\.com|youtu\.be)/\S+", re.I)
MEDIA_SUFFIXES = {".mp3", ".wav", ".m4a", ".opus", ".aac", ".flac", ".ogg", ".wma", ".mp4", ".mkv", ".webm", ".mov", ".avi", ".m4v", ".ts"}
VIDEO_SUFFIXES = {".mp4", ".mkv", ".webm", ".mov", ".avi", ".m4v", ".ts"}
AUDIO_SUFFIXES = MEDIA_SUFFIXES - VIDEO_SUFFIXES


# ============================================
# AI Services (for text generation if needed)
# ============================================
AI_SERVICES = [
    {
        "name": "Xkiro1 qwen/qwen3.8-max:free",
        "apiKey": "sk-xt-2c8e0cd0f60b988c1e3ac7c4fdb861d9ad469a9b2b8c463a",
        "apiUrl": "https://api.xkiro.com/v1/chat/completions",
        "modelName": "qwen/qwen3.8-max:free"
    },
    {
        "name": "AgnesAI agnes-2.0-flash",
        "apiKey": "sk-40tGLaeHdZkWPHjbpR4K5xY1aURbC8mPrTcye714ovu3s03q",
        "apiUrl": "https://apihub.agnes-ai.com/v1/chat/completions",
        "modelName": "agnes-2.0-flash",
    }
]


"""
在原 stt_batch_processor.py 基础上的最小改动说明：

1. 增加 CRISP_ASR 长音频分段配置：
   CRISP_ASR_MAX_DURATION_MINUTES = 26
   CRISP_ASR_CHUNK_OVERLAP_SECONDS = 15

2. 当 STT Provider 为 CRISP_ASR 且音频超过阈值时：
   - 使用 ffmpeg 按时间切分为多个低于阈值的 WAV 片段；
   - 每个片段分别调用原有 CRISP_ASR；
   - 使用带时间戳的 CRISP_ASR SRT 结果进行重叠文本去重合并；
   - 如果某个片段没有 SRT，则退回使用 TXT，并保留片段文本。

请将以下代码合并到原脚本对应位置。完整的原脚本内容未在此重复，以避免删减原有功能。
"""

# =====================================================================
# 修改 1：放在 VIBEASR_MAX_DURATION 后面
# =====================================================================
CRISP_ASR_MAX_DURATION_MINUTES = 30
CRISP_ASR_CHUNK_OVERLAP_SECONDS = 15
CRISP_ASR_MAX_DURATION_SECONDS = CRISP_ASR_MAX_DURATION_MINUTES * 60




# ============================================
# AI Services (for text generation if needed)
# ============================================

# 之后 (本地 Ollama)
# ~ API_KEY = os.getenv("OLLAMA_API_KEY", "ollama").strip()
# ~ API_URL = os.getenv("OLLAMA_API_URL", "http://localhost:11434/v1/chat/completions").strip()
# ~ MODEL_NAME = os.getenv("OLLAMA_MODEL_NAME", "command-r7b:7b").strip()

#MODEL_NAME = "llama3.2:1b"
#MODEL_NAME = "qwen2.5:14b"
#MODEL_NAME = "mistral:7b"
#MODEL_NAME = "granite3.1-moe:3b"
#MODEL_NAME = "translategemma:12b"

def progress(message: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {message}", flush=True)


def clean_name(value: str) -> str:
    value = re.sub(r"[\\/:*?\"<>|\x00-\x1f]", "_", value).strip(" .")
    return value[:180] or "untitled"


def video_id_from_url(url: str) -> str:
    match = re.search(r"(?:v=|youtu\.be/|shorts/|embed/)([A-Za-z0-9_-]{6,})", url)
    return match.group(1) if match else ""


def media_key(path: Path) -> str:
    return str(path.expanduser().resolve())

# 唯一修复点：完整保留 --urls 列表，不把多个 URL 当作单个参数。

URL_RE = re.compile(
    r"https?://(?:www\.)?(?:youtube\.com|youtu\.be)/[^\s<>\]）)]+",
    re.IGNORECASE,
)


def read_urls(args: argparse.Namespace) -> list[str]:
    if args.file:
        values = Path(args.file).expanduser().read_text(
            encoding="utf-8"
        ).splitlines()
    elif args.urls:
        values = list(args.urls)
    elif args.stdin:
        values = sys.stdin.read().splitlines()
    elif args.url:
        values = [args.url]
    else:
        values = []

    urls: list[str] = []
    seen: set[str] = set()

    for raw in values:
        line = str(raw).strip()

        if not line or line.startswith("#"):
            continue

        for match in URL_RE.finditer(line):
            url = match.group(0).rstrip(
                ".,;，。；:：!?！？）)]}>"
            )

            if url and url not in seen:
                seen.add(url)
                urls.append(url)

    return urls
    

def scan_media(directory: Path, recursive: bool) -> list[Path]:
    iterator = directory.rglob("*") if recursive else directory.glob("*")
    return sorted((p for p in iterator if p.is_file() and p.suffix.lower() in MEDIA_SUFFIXES), key=lambda p: str(p).lower())


def read_history(path: str) -> dict[str, dict[str, str]]:
    latest = {}
    if not os.path.exists(path):
        return latest
    try:
        with open(path, newline="", encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                key = row.get("视频ID") or row.get("媒体路径") or row.get("URL") or ""
                if key:
                    latest[key] = row
    except Exception as exc:
        progress(f"⚠️ 读取历史日志失败：{path}：{exc}")
    return latest


def append_history(path: str, fields: list[str], row: dict[str, Any]) -> None:
    target = Path(path).expanduser()
    target.parent.mkdir(parents=True, exist_ok=True)
    exists = target.exists() and target.stat().st_size > 0
    with open(target, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        if not exists:
            writer.writeheader()
        writer.writerow({key: row.get(key, "") for key in fields})


def log_youtube_completion(url: str, result: dict[str, Any], task_dir: Path) -> None:
    fields = ["视频ID", "URL", "状态", "总结时间", "备注", "模式", "输出文件", "任务目录"]
    append_history(YOUTUBE_LOG_FILE, fields, {"视频ID": result.get("video_id") or video_id_from_url(url), "URL": url, "状态": result.get("status", "failed"), "总结时间": datetime.now(timezone.utc).isoformat(), "备注": result.get("error") or json.dumps(result.get("steps", {}), ensure_ascii=False), "模式": result.get("mode", ""), "输出文件": result.get("files", [""])[0] if result.get("files") else "", "任务目录": str(task_dir)})
    progress(f"📝 YouTube 日志已写入：{YOUTUBE_LOG_FILE}")


def log_media_completion(source: Path, result: dict[str, Any], task_dir: Path) -> None:
    fields = ["媒体路径", "媒体类型", "转换状态", "状态", "总结时间", "备注", "音频文件", "转录文件", "报告文件", "任务目录"]
    append_history(MEDIA_LOG_FILE, fields, {"媒体路径": media_key(source), "媒体类型": result.get("media_type", ""), "转换状态": result.get("conversion_status", "not_needed"), "状态": result.get("status", "failed"), "总结时间": datetime.now(timezone.utc).isoformat(), "备注": result.get("error") or json.dumps(result.get("steps", {}), ensure_ascii=False), "音频文件": result.get("audio_input", ""), "转录文件": next((p for p in result.get("files", []) if str(p).lower().endswith(".txt")), ""), "报告文件": next((p for p in result.get("files", []) if str(p).lower().endswith(".md")), ""), "任务目录": str(task_dir)})
    progress(f"📝 本地媒体日志已写入：{MEDIA_LOG_FILE}")


def load_notify_config() -> dict:
    default = {"enabled": False, "channels": {"qq_email": {"enabled": False, "user": "", "password": "", "from_name": "YouTubeScoops", "recipients": ""}, "bark": {"enabled": False, "url": "", "device_key": ""}, "wxpusher": {"enabled": False, "token": "", "uid": ""}, "pushplus": {"enabled": False, "token": ""}, "resend": {"enabled": False, "api_key": "", "to_email": ""}, "telegram": {"enabled": False, "bot_token": "", "chat_id": ""}}}
    try:
        saved = json.loads(Path(NOTIFY_CONFIG_FILE).read_text(encoding="utf-8"))
        default["enabled"] = saved.get("enabled", False)
        for name, cfg in default["channels"].items():
            cfg.update(saved.get("channels", {}).get(name, {}))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass
    return default


def _send_qq_email(cfg, title, content):
    recipients = [x.strip() for x in re.split(r"[,，;；\s]+", cfg.get("recipients", "")) if x.strip()]
    if not cfg.get("user") or not cfg.get("password") or not recipients:
        return False, "配置不完整"
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"], msg["From"], msg["To"] = title, f"{cfg.get('from_name', 'YouTubeScoops')} <{cfg['user']}>", ", ".join(recipients)
        msg.attach(MIMEText(content.replace("\n", "<br>"), "html", "utf-8"))
        with smtplib.SMTP_SSL("smtp.qq.com", 465, timeout=15) as server:
            server.login(cfg["user"], cfg["password"])
            server.sendmail(cfg["user"], recipients, msg.as_string())
        return True, "发送成功"
    except Exception as exc:
        return False, str(exc)


def _post_json(url, payload, headers=None):
    if requests is None:
        return False, "缺少 requests 库"
    try:
        response = requests.post(url, headers=headers or {"Content-Type": "application/json"}, json=payload, timeout=15)
        response.raise_for_status()
        return True, "发送成功"
    except Exception as exc:
        return False, str(exc)


def _send_bark(cfg, title, content):
    if not cfg.get("url") or not cfg.get("device_key"):
        return False, "配置不完整"
    return _post_json(cfg["url"].rstrip("/") + "/push", {"title": title, "body": content, "sound": "alarm", "group": "YouTubeScoops", "level": "active", "device_keys": [cfg["device_key"]]})


def _send_wxpusher(cfg, title, content):
    if not cfg.get("token") or not cfg.get("uid"):
        return False, "配置不完整"
    return _post_json("https://wxpusher.zjiecode.com/api/send/message", {"appToken": cfg["token"], "content": content, "summary": title, "contentType": 3, "uids": [cfg["uid"]]})


def _send_pushplus(cfg, title, content):
    if not cfg.get("token"):
        return False, "配置不完整"
    return _post_json("http://www.pushplus.plus/send", {"token": cfg["token"], "title": title, "content": content, "template": "markdown"})


def _send_resend(cfg, title, content):
    if not cfg.get("api_key") or not cfg.get("to_email"):
        return False, "配置不完整"
    return _post_json("https://api.resend.com/emails", {"from": "onboarding@resend.dev", "to": cfg["to_email"], "subject": title, "html": content.replace("\n", "<br>")}, {"Authorization": "Bearer " + cfg["api_key"], "Content-Type": "application/json"})


def _send_telegram(cfg, title, content):
    if not cfg.get("bot_token") or not cfg.get("chat_id"):
        return False, "配置不完整"
    return _post_json("https://api.telegram.org/bot" + cfg["bot_token"] + "/sendMessage", {"chat_id": cfg["chat_id"], "text": f"*{title}*\n\n{content}", "parse_mode": "Markdown"})


CHANNEL_SENDERS = {"qq_email": _send_qq_email, "bark": _send_bark, "wxpusher": _send_wxpusher, "pushplus": _send_pushplus, "resend": _send_resend, "telegram": _send_telegram}
CHANNEL_NAMES = {"qq_email": "QQ 邮箱", "bark": "Bark", "wxpusher": "WxPusher", "pushplus": "PushPlus", "resend": "Resend 邮件", "telegram": "Telegram"}


def dispatch_notifications(title: str, content: str, config: dict) -> None:
    if not config.get("enabled"):
        progress("🔕 通知总开关关闭，跳过通知")
        return
    progress(f"📨 正在发送通知：{title}")
    for name, sender in CHANNEL_SENDERS.items():
        cfg = config.get("channels", {}).get(name, {})
        if not cfg.get("enabled"):
            continue
        ok, message = sender(cfg, title, content)
        progress(f"{'✅' if ok else '❌'} {CHANNEL_NAMES[name]}：{message}")


def run_command(command: list[str], log_path: Path, timeout: int, label: str) -> tuple[int, str]:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    progress(f"▶️ 开始：{label}")
    progress(f"   命令：{shlex.join(command)}")
    started = time.monotonic()
    stop = threading.Event()

    def heartbeat():
        while not stop.wait(15):
            progress(f"⏳ 仍在进行：{label}，已耗时 {time.monotonic() - started:.0f} 秒")

    thread = threading.Thread(target=heartbeat, daemon=True)
    thread.start()
    try:
        proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, env=os.environ.copy())
        lines = []
        assert proc.stdout is not None
        for raw in proc.stdout:
            lines.append(raw)
            line = raw.rstrip()
            if line:
                progress(f"   [{label}] {line}")
        code = proc.wait()
        output = "".join(lines)
        log_path.write_text(f"$ {shlex.join(command)}\n\n{output}", encoding="utf-8", errors="replace")
        progress(f"{'✅ 完成' if code == 0 else '❌ 失败'}：{label}，耗时 {time.monotonic() - started:.2f} 秒，返回码 {code}")
        return code, output
    except Exception as exc:
        log_path.write_text(f"$ {shlex.join(command)}\n\n[EXCEPTION] {exc}", encoding="utf-8", errors="replace")
        progress(f"❌ 异常：{label}：{exc}")
        return 1, str(exc)
    finally:
        stop.set()
        thread.join(timeout=1)




def build_ai_ssl_context() -> ssl.SSLContext:
    """使用当前已验证可用的 AI SSL 连接方案。"""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx

def call_ai(service: dict, prompt: str) -> str:
    """调用 OpenAI-compatible Chat Completions API（使用 curl_cffi）。"""
    from curl_cffi import requests

    payload = {
        "model": service["modelName"],
        "messages": [
            {
                "role": "user",
                "content": prompt,
            }
        ],
        "temperature": 0.3,
    }

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {service['apiKey']}",
        "Accept": "application/json",
    }

    resp = requests.post(
        service["apiUrl"].rstrip("/"),
        json=payload,
        headers=headers,
        timeout=300,
        impersonate="chrome",  # 关键修复：伪装 TLS/HTTP2 指纹，避免 Cloudflare 1010 封禁
    )

    if resp.status_code != 200:
        raise RuntimeError(
            f"AI API 请求失败：HTTP {resp.status_code} - {resp.text[:500]}"
        )

    try:
        data = resp.json()
        content = data["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError) as exc:
        raise RuntimeError(
            "AI API 返回格式异常："
            + json.dumps(data, ensure_ascii=False)[:1000]
        ) from exc

    if not isinstance(content, str) or not content.strip():
        raise RuntimeError("AI API 返回内容为空")

    return content.strip()


    
def call_ai_vieux(service: dict, prompt: str) -> str:
    """调用 OpenAI-compatible Chat Completions API。"""
    payload = json.dumps(
        {
            "model": service["modelName"],
            "messages": [
                {
                    "role": "user",
                    "content": prompt,
                }
            ],
            "temperature": 0.3,
        }
    ).encode("utf-8")

    request = urllib.request.Request(
        service["apiUrl"].rstrip("/"),
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {service['apiKey']}",
        },
    )

    ctx = build_ai_ssl_context()

    with urllib.request.urlopen(
        request,
        context=ctx,
        timeout=300,
    ) as response:
        data = json.loads(
            response.read().decode("utf-8")
        )

    try:
        content = data["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError) as exc:
        raise RuntimeError(
            "AI API 返回格式异常："
            + json.dumps(data, ensure_ascii=False)[:1000]
        ) from exc

    if not isinstance(content, str) or not content.strip():
        raise RuntimeError("AI API 返回内容为空")

    return content.strip()


def summarize_transcript(
    transcript: str,
    title: str,
    source_label: str = "YouTube 视频",
) -> tuple[str, str]:
    """使用多个 AI Provider 按顺序 fallback 总结文本。"""
    prompt = f"""请用中文分析下面{source_label}的字幕或转录文本，生成 Markdown 报告。必须包含：视频概述、2-5 分钟粒度章节摘要、关键要点、3-8 个关键词、小红书文案、抖音文案、微信公众号文案。不要编造文本中没有的事实。

标题：{title}

文本：
{transcript}
"""

    errors: list[str] = []

    for service in AI_SERVICES:
        service_name = service.get("name", "Unnamed AI Service")
        api_key = service.get("apiKey", "")

        if not api_key or api_key.startswith("你的"):
            message = f"[跳过] {service_name} 未配置 API Key"
            errors.append(message)
            progress(f"⚠️ {message}")
            continue

        progress(f"🤖 正在使用 AI 服务总结：{service_name}")

        try:
            content = call_ai(service, prompt)
            progress(f"✅ AI 总结成功：{service_name}")
            return content, service_name

        except ssl.SSLError as exc:
            message = f"[SSL 失败] {service_name}: {exc}"
            errors.append(message)
            progress(f"⚠️ {message}")

        except urllib.error.URLError as exc:
            message = f"[网络失败] {service_name}: {exc}"
            errors.append(message)
            progress(f"⚠️ {message}")

        except Exception as exc:
            message = f"[失败] {service_name}: {exc}"
            errors.append(message)
            progress(f"⚠️ {message}")

    fallback = (
        "> AI 服务全部失败，以下为文本提取报告。\n\n"
        "## 文本摘录\n\n"
        + transcript[:5000]
    )

    progress("⚠️ 所有 AI 服务均失败，生成文本提取 fallback 报告")
    progress("错误详情：" + " | ".join(errors))
    return fallback, "fallback：" + " | ".join(errors)
    
    

def summarize_transcript22(transcript: str, title: str, source_label: str = "YouTube 视频") -> tuple[str, str]:
    prompt = f"""请用中文分析下面{source_label}的字幕或转录文本，生成 Markdown 报告。必须包含：视频概述、2-5 分钟粒度章节摘要、关键要点、3-8 个关键词、小红书文案、抖音文案、微信公众号文案。不要编造文本中没有的事实。

标题：{title}

文本：
{transcript}
"""
    errors = []
    for service in AI_SERVICES:
        if not service["apiKey"]:
            errors.append(f"{service['name']}: 未配置 API Key")
            continue
        progress(f"🤖 正在使用 AI 服务总结：{service['name']}")
        try:
            payload = json.dumps({"model": service["modelName"], "messages": [{"role": "user", "content": prompt}], "temperature": 0.3}).encode()
            request = urllib.request.Request(service["apiUrl"].rstrip("/"), data=payload, headers={"Content-Type": "application/json", "Authorization": f"Bearer {service['apiKey']}"})
            with urllib.request.urlopen(request, timeout=300) as response:
                data = json.loads(response.read().decode())
            return data["choices"][0]["message"]["content"], service["name"]
        except Exception as exc:
            progress(f"⚠️ AI 服务失败：{service['name']}：{exc}")
            errors.append(f"{service['name']}: {exc}")
    return "> AI 服务全部失败，以下为文本提取报告。\n\n## 文本摘录\n\n" + transcript[:5000], "fallback：" + " | ".join(errors)


def new_files(directory: Path, suffixes: set[str], before: set[Path]) -> list[Path]:
    return [p for p in directory.rglob("*") if p.is_file() and p.suffix.lower() in suffixes and p not in before]


def no_subtitles(output: str) -> bool:
    text = output.lower()
    return any(x in text for x in ("视频没有可用字幕", "没有可用字幕", "no subtitles", "no available subtitles", "字幕解析后没有有效内容"))




def get_audio_duration(wav_path: str) -> Optional[float]:
    """使用 ffprobe 获取音频/视频时长（秒）；失败返回 None。"""
    try:
        cmd = [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", wav_path
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0 and result.stdout.strip():
            return float(result.stdout.strip())
    except Exception:
        pass
    return None



# =====================================================================
# 修改 2：放在 get_audio_duration() 后面
# =====================================================================
def _parse_srt_timestamp(value: str) -> float:
    """将 SRT 时间戳转换为秒。"""
    value = value.strip().replace(",", ".")
    parts = value.split(":")
    if len(parts) != 3:
        raise ValueError(f"无效的 SRT 时间戳：{value}")
    hours, minutes, seconds = parts
    return int(hours) * 3600 + int(minutes) * 60 + float(seconds)


def _format_srt_timestamp(seconds: float) -> str:
    """将秒转换为 SRT 时间戳。"""
    seconds = max(0.0, float(seconds))
    milliseconds = int(round(seconds * 1000))
    hours, remainder = divmod(milliseconds, 3600000)
    minutes, remainder = divmod(remainder, 60000)
    secs, millis = divmod(remainder, 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def _read_srt_cues(srt_path: str) -> List[Dict[str, Any]]:
    """读取 SRT，保留每条字幕的起止时间和文本。"""
    raw = Path(srt_path).read_text(encoding="utf-8", errors="replace")
    cues = []
    blocks = re.split(r"\n\s*\n", raw.strip())
    for block in blocks:
        lines = [line.strip("\ufeff") for line in block.splitlines() if line.strip()]
        if len(lines) < 2:
            continue
        time_index = next((i for i, line in enumerate(lines) if "-->" in line), None)
        if time_index is None:
            continue
        try:
            start_text, end_text = [x.strip() for x in lines[time_index].split("-->", 1)]
            start = _parse_srt_timestamp(start_text)
            end = _parse_srt_timestamp(end_text)
        except (ValueError, IndexError):
            continue
        text = " ".join(lines[time_index + 1:]).strip()
        if text:
            cues.append({"start": start, "end": end, "text": text})
    return cues


def _normalise_overlap_text(value: str) -> str:
    """仅用于匹配重叠内容，不改变最终输出文本。"""
    return re.sub(r"\s+", "", value).lower()


def _merge_crisp_segments(
    segment_srt_paths: List[Tuple[str, float]],
    segment_txt_paths: List[Tuple[str, float]],
) -> str:
    """按原始时间轴合并 CRISP_ASR 分段结果，并去除重叠字幕。"""
    all_cues: List[Dict[str, Any]] = []

    for srt_path, offset in segment_srt_paths:
        try:
            for cue in _read_srt_cues(srt_path):
                cue = dict(cue)
                cue["start"] += offset
                cue["end"] += offset
                all_cues.append(cue)
        except OSError:
            continue

    if not all_cues:
        texts = []
        for txt_path, _ in segment_txt_paths:
            try:
                text = Path(txt_path).read_text(encoding="utf-8", errors="replace").strip()
            except OSError:
                text = ""
            if text:
                texts.append(text)
        return "\n\n".join(texts).strip()

    all_cues.sort(key=lambda item: (item["start"], item["end"]))
    merged: List[Dict[str, Any]] = []
    for cue in all_cues:
        if not merged:
            merged.append(cue)
            continue

        previous = merged[-1]
        previous_norm = _normalise_overlap_text(previous["text"])
        current_norm = _normalise_overlap_text(cue["text"])

        # 完全重复，通常是相邻片段的重叠区域。
        if current_norm == previous_norm:
            previous["end"] = max(previous["end"], cue["end"])
            continue

        # 当前字幕完全包含于上一条字幕，跳过重复内容。
        if current_norm and current_norm in previous_norm:
            previous["end"] = max(previous["end"], cue["end"])
            continue

        # 上一条字幕完全包含于当前字幕，用较完整的当前文本替换。
        if previous_norm and previous_norm in current_norm:
            cue["start"] = min(previous["start"], cue["start"])
            merged[-1] = cue
            continue

        # 处理两条字幕之间的最长字符后缀/前缀重叠。
        max_overlap = min(len(previous_norm), len(current_norm))
        overlap = 0
        for size in range(max_overlap, 0, -1):
            if previous_norm[-size:] == current_norm[:size]:
                overlap = size
                break

        if overlap >= 4:
            # 保留当前字幕的原始文本，但去掉开头重复部分。
            prefix_len = 0
            seen = 0
            for ch in cue["text"]:
                if not ch.isspace():
                    seen += 1
                prefix_len += 1
                if seen >= overlap:
                    break
            cue["text"] = cue["text"][prefix_len:].lstrip(" ，。,.!?！？;；:：")
            if not cue["text"]:
                previous["end"] = max(previous["end"], cue["end"])
                continue

        merged.append(cue)

    # 输出为带原始时间轴的纯文本；保留字幕换行边界，便于后续人工检查。
    return "\n".join(cue["text"].strip() for cue in merged if cue["text"].strip()).strip()


def _split_audio_for_crisp(
    source_path: Path,
    chunks_dir: Path,
    duration: float,
) -> List[Tuple[Path, float]]:
    """将长音频切分为低于配置阈值的片段，返回 (片段路径, 原始偏移秒数)。"""
    chunks_dir.mkdir(parents=True, exist_ok=True)
    # 片段最大时长比阈值略小，避免编码/容器误差使片段达到或超过阈值。
    chunk_duration = max(60, CRISP_ASR_MAX_DURATION_SECONDS - 2)
    overlap = min(max(0, CRISP_ASR_CHUNK_OVERLAP_SECONDS), chunk_duration / 2)
    step = chunk_duration - overlap

    chunks: List[Tuple[Path, float]] = []
    index = 0
    offset = 0.0
    while offset < duration:
        remaining = duration - offset
        current_duration = min(chunk_duration, remaining)
        # 最后一段也从 offset 开始；前一段的重叠由 step 自动产生。
        chunk_path = chunks_dir / f"chunk_{index:04d}.wav"
        cmd = [
            "ffmpeg", "-y", "-ss", f"{offset:.3f}",
            "-i", str(source_path), "-t", f"{current_duration:.3f}",
            "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le",
            str(chunk_path),
        ]
        code, _ = run_command(
            cmd,
            chunks_dir / f"chunk_{index:04d}.ffmpeg.log",
            3600,
            f"CRISP_ASR 长音频分段 {index + 1}",
        )
        if code != 0 or not chunk_path.exists() or chunk_path.stat().st_size == 0:
            raise RuntimeError(f"长音频分段失败：{chunk_path.name}")
        chunks.append((chunk_path, offset))
        index += 1
        offset += step
    return chunks

       
def _transcribe_cohere(wav_path: str) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    """CRISP_ASR 本地转录。

    关键修复：run_command 返回的第二个值是完整 stdout 日志文本，不能当作
    "有内容即失败"的错误标志。判断是否成功应以返回码 + 是否生成 TXT 文件为准。
    """
    try:
        cmd = [
            CRISPASR_BIN,
            "--backend", "cohere",
            "-m", COHERE_MODEL_PATH,
            "-f", str(wav_path),
            "-l", "auto",
            "-t", "8",
            "--output-srt",
            "--output-txt",
            "--no-gpu"
        ]
        code, output = run_command(cmd, Path(str(wav_path) + ".crispasr.log"), 3600, "CRISP_ASR 本地转录")

        srt_path = str(wav_path).rsplit('.', 1)[0] + ".srt"
        txt_path = str(wav_path).rsplit('.', 1)[0] + ".txt"

        # 只有返回码非 0 且没有生成 TXT 时，才是真正的失败
        if code != 0 and not os.path.exists(txt_path):
            return None, output, None, None

        if not os.path.exists(txt_path):
            return None, "TXT 未生成：" + txt_path, None, None

        with open(txt_path, "r", encoding="utf-8") as f:
            transcript = f.read().strip()

        if not transcript:
            return None, "TXT 内容为空：" + txt_path, None, None

        return transcript, None, txt_path, srt_path if os.path.exists(srt_path) else None

    except Exception as e:
        return None, "转录异常：" + str(e), None, None
        
        
        
def _transcribe_crisp_long_audio(
    wav_path: str,
) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    """CRISP_ASR 长音频分段转录与重叠合并。"""
    duration = get_audio_duration(wav_path)
    if duration is None:
        return _transcribe_cohere(wav_path)

    if duration <= CRISP_ASR_MAX_DURATION_SECONDS:
        return _transcribe_cohere(wav_path)

    source = Path(wav_path)
    chunks_dir = source.parent / f"{source.stem}.crisp_chunks"
    progress(
        f"📊 CRISP_ASR 音频时长：{duration / 60:.2f} 分钟；"
        f"超过 {CRISP_ASR_MAX_DURATION_MINUTES} 分钟，开始分段"
    )
    progress(
        f"✂️ 分段参数：每段约 {CRISP_ASR_MAX_DURATION_SECONDS - 2:.0f} 秒，"
        f"重叠 {CRISP_ASR_CHUNK_OVERLAP_SECONDS} 秒"
    )

    chunks = _split_audio_for_crisp(source, chunks_dir, duration)
    segment_srt_paths: List[Tuple[str, float]] = []
    segment_txt_paths: List[Tuple[str, float]] = []
    errors = []

    for index, (chunk_path, offset) in enumerate(chunks, 1):
        progress(f"🎙️ CRISP_ASR 转录分段 [{index}/{len(chunks)}]：{chunk_path.name}")
        transcript, error, txt_path, srt_path = _transcribe_cohere(str(chunk_path))
        if error or not transcript:
            errors.append(f"{chunk_path.name}: {error or '输出为空'}")
            continue
        if txt_path:
            segment_txt_paths.append((txt_path, offset))
        if srt_path:
            segment_srt_paths.append((srt_path, offset))

    if not segment_txt_paths and not segment_srt_paths:
        return None, "CRISP_ASR 所有长音频分段均失败：" + "；".join(errors), None, None

    merged_text = _merge_crisp_segments(segment_srt_paths, segment_txt_paths)
    if not merged_text:
        return None, "CRISP_ASR 分段转录结果合并后为空", None, None

    merged_txt_path = str(source.with_suffix("")) + ".crispasr_merged.txt"
    Path(merged_txt_path).write_text(merged_text, encoding="utf-8")

    # 不返回合并 SRT，避免在原脚本中引入不准确的字幕重编号逻辑；
    # 原有单文件 CRISP_ASR 路径仍然会正常返回并复制 SRT。
    warning = "；".join(errors) if errors else None
    return merged_text, warning, merged_txt_path, None

# ~ def _find_fasterwhisper_transcript(output_dir: Path, source_path: str) -> Path | None:
    # ~ reports = sorted(
        # ~ output_dir.glob("*/report.json"),
        # ~ key=lambda p: p.stat().st_mtime,
        # ~ reverse=True,
    # ~ )
    # ~ source_resolved = str(Path(source_path).expanduser().resolve())
    # ~ for report_path in reports:
        # ~ try:
            # ~ report = json.loads(report_path.read_text(encoding="utf-8"))
        # ~ except (OSError, json.JSONDecodeError):
            # ~ continue
        # ~ for item in report.get("items", []):
            # ~ item_source = item.get("source", "")
            # ~ if item_source and str(Path(item_source).expanduser().resolve()) != source_resolved:
                # ~ continue
            # ~ merged_txt = item.get("merged_txt_path")
            # ~ if merged_txt and Path(merged_txt).is_file():
                # ~ return Path(merged_txt)
    # ~ return None
    
def _find_fasterwhisper_transcript(output_dir: Path, source_path: str) -> Path | None:
    """从最新的 faster-whisper report.json 中查找 merged_txt_path（按文件名匹配）。"""
    # 获取输入文件的 basename（不含扩展名），用于匹配 job_dir 名称
    source_name = Path(source_path).stem

    reports = sorted(
        output_dir.glob("*/report.json"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    for report_path in reports:
        try:
            report = json.loads(report_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue

        for item in report.get("items", []):
            # 方法 1：通过 job_dir 的父目录名称匹配（推荐）
            job_dir = item.get("job_dir", "")
            if job_dir:
                job_name = Path(job_dir).name
                if job_name == source_name:
                    merged_txt = item.get("merged_txt_path")
                    if merged_txt and Path(merged_txt).is_file():
                        return Path(merged_txt)
                    continue

            # 方法 2：通过 items[].source 的文件名匹配（备用）
            item_source = item.get("source", "")
            if item_source:
                item_source_name = Path(item_source).stem
                # 如果 item_source 以 /source 结尾，取其父目录名
                if item_source.endswith("/source"):
                    item_source_name = Path(item_source).parent.name
                if item_source_name == source_name:
                    merged_txt = item.get("merged_txt_path")
                    if merged_txt and Path(merged_txt).is_file():
                        return Path(merged_txt)

    return None

def _transcribe_fasterwhisper_batch(wav_path: str) -> tuple[str | None, str | None]:
    """调用 stt_fasterwhisper_batch.py 并返回 transcript_merged.txt 内容。"""
    output_dir = Path.home() / "Downloads" / "stt_transcripts"
    command = [
        sys.executable,
        str(FASTERWHISPER_STT_SCRIPT),
        "--file",
        str(Path(wav_path).expanduser()),
        "--output",
        str(output_dir),
    ]
    log_path = Path(str(wav_path) + ".fasterwhisper_batch.log")
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=3600,
            env=os.environ.copy(),
        )
        log_path.write_text(
            "$ " + " ".join(command) + "\n\n"
            + completed.stdout
            + "\n"
            + completed.stderr,
            encoding="utf-8",
            errors="replace",
        )
    except Exception as exc:
        return None, f"fasterwhisper_batch 异常：{exc}"

    transcript_path = _find_fasterwhisper_transcript(output_dir, wav_path)
    if completed.returncode != 0 and transcript_path is None:
        return None, (
            f"fasterwhisper_batch 返回码 {completed.returncode}；"
            f"详见日志：{log_path}"
        )
    # ~ if transcript_path is None:
        # ~ return None, f"未从 report.json 找到 merged_txt_path；详见日志：{log_path}"

    if transcript_path is None:
        # 增加调试日志，方便排查
        progress(f"⚠️ 查找失败：source_path={wav_path}")
        progress(f"⚠️ 扫描 output_dir={output_dir}")
        for rp in sorted(output_dir.glob("*/report.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:3]:
            progress(f"  最新 report: {rp}")
        return None, f"未从 report.json 找到 merged_txt_path；详见日志：{log_path}"
        
                
    try:
        transcript = transcript_path.read_text(
            encoding="utf-8", errors="replace"
        ).strip()
    except OSError as exc:
        return None, f"读取 transcript_merged.txt 失败：{exc}"
    return (transcript, None) if transcript else (None, "transcript_merged.txt 内容为空")




# ============================================
# STT 转录方案集成（本地化方案：crispasr / vibeasr / whisper）
# ============================================

def parse_srt_to_text(raw_srt: str) -> str:
    """将 SRT 字幕内容解析为纯文本（去除序号、时间轴、空行）。"""
    lines = []
    for line in raw_srt.splitlines():
        line = line.strip()
        if not line:
            continue
        if re.fullmatch(r"\d+", line):
            continue
        if "-->" in line:
            continue
        lines.append(line)
    return " ".join(lines)


def _transcribe_cohere_orig(wav_path: str) -> tuple:
    """备用方案 1：CRISP_ASR（crispasr 本地进程调用）。"""
    try:
        cmd = [
            CRISPASR_BIN,
            "--backend", "cohere",
            "-m", COHERE_MODEL_PATH,
            "-f", str(wav_path),
            "-l", "auto",
            "-t", "8",
            "--output-srt",
            "--output-txt",
            "--no-gpu",
        ]
        _, err = run_command(cmd, Path(str(wav_path) + ".crispasr.log"), 3600, "CRISP_ASR 本地转录")
        if err and not os.path.exists(str(wav_path).rsplit(".", 1)[0] + ".txt"):
            return None, err

        srt_path = str(wav_path).rsplit(".", 1)[0] + ".srt"
        txt_path = str(wav_path).rsplit(".", 1)[0] + ".txt"

        if not os.path.exists(txt_path):
            return None, "TXT 未生成：" + txt_path

        with open(txt_path, "r", encoding="utf-8") as f:
            transcript = f.read().strip()

        try:
            if os.path.exists(srt_path):
                os.remove(srt_path)
            if os.path.exists(txt_path):
                os.remove(txt_path)
        except OSError:
            pass

        return transcript, None

    except Exception as e:
        return None, "转录异常：" + str(e)


def _transcribe_vibeasr(wav_path: str) -> tuple:
    """备用方案 2：VibeASR（asr_infer 本地进程调用）。"""
    try:
        txt_path = str(wav_path).rsplit(".", 1)[0] + ".vibeasr.txt"
        log_path = str(wav_path).rsplit(".", 1)[0] + ".vibeasr.log"
        cmd = [
            VIBEASR_BIN,
            "--vae-model", VAE_MODEL_PATH,
            "--lm-model", LM_MODEL_PATH,
            "--audio", str(wav_path),
            "--prompt-format", "text",
            "--greedy",
            "-t", "8",
            "-b", "4096",
        ]
        progress(f"▶️ 开始：VibeASR 本地转录")
        progress(f"   命令：{shlex.join(cmd)}")
        try:
            with open(txt_path, "w", encoding="utf-8") as out_f, open(log_path, "w", encoding="utf-8") as err_f:
                proc = subprocess.run(cmd, stdout=out_f, stderr=err_f, env=os.environ.copy())
            code = proc.returncode
        except Exception as exc:
            return None, "转录异常：" + str(exc)

        if code != 0:
            return None, f"VibeASR 返回码非 0（{code}），详见日志：{log_path}"

        if not os.path.exists(txt_path):
            return None, "TXT 未生成：" + txt_path

        with open(txt_path, "r", encoding="utf-8") as f:
            transcript = f.read().strip()

        try:
            os.remove(txt_path)
        except OSError:
            pass

        return transcript, None

    except Exception as e:
        return None, "转录异常：" + str(e)


def _transcribe_whispercpp(wav_path: str) -> tuple:
    """备用方案 3：Whisper.cpp（本地进程调用）。"""
    try:
        cmd = [WHISPER_BIN, "-m", WHISPER_MODEL, "-f", str(wav_path),
               "-l", WHISPER_LANG, "--no-gpu", "--output-srt"]
        _, err = run_command(cmd, Path(str(wav_path) + ".whisper.log"), 3600, "Whisper.cpp 本地转录")
        srt_path = str(wav_path) + ".srt"
        if not os.path.exists(srt_path):
            return None, "SRT 未生成：" + srt_path
        with open(srt_path, "r", encoding="utf-8") as f:
            raw_srt = f.read()
        transcript = parse_srt_to_text(raw_srt).strip()
        try:
            os.remove(srt_path)
        except OSError:
            pass
        return transcript, None
    except Exception as e:
        return None, "转录异常：" + str(e)

    try:
        import azure.cognitiveservices.speech as speechsdk
        import datetime as _dt
        file_path = Path(wav_path)
        lang = language_code if language_code != "auto" else "zh-CN"
        speech_config = speechsdk.SpeechConfig(
            subscription=api_key.strip(), region=region.strip()
        )
        speech_config.speech_recognition_language = lang
        tmp_wav = file_path.with_suffix(".tmp.wav")
        needs_cleanup = False
        if file_path.suffix.lower() != ".wav":
            subprocess.run(
                ["ffmpeg", "-y", "-i", str(file_path), "-ar", "16000", "-ac", "1", str(tmp_wav)],
                check=True, capture_output=True
            )
            needs_cleanup = True
        else:
            tmp_wav = file_path
        try:
            audio_config = speechsdk.audio.AudioConfig(filename=str(tmp_wav))
            transcriber = speechsdk.transcription.ConversationTranscriber(
                speech_config=speech_config, audio_config=audio_config
            )
            results = []
            done_event = threading.Event()

            def on_transcribed(evt):
                if evt.result.reason == speechsdk.ResultReason.RecognizedSpeech:
                    start_time = str(_dt.timedelta(microseconds=evt.result.offset / 10)).split(".")[0]
                    speaker = getattr(evt.result, "speaker_id", "Unknown")
                    if not speaker or speaker == "Unknown":
                        speaker = "Guest"
                    results.append(f"[{start_time}] Speaker {speaker}: {evt.result.text}")

            def on_session_stopped(evt):
                done_event.set()

            def on_canceled(evt):
                done_event.set()

            transcriber.transcribed.connect(on_transcribed)
            transcriber.session_stopped.connect(on_session_stopped)
            transcriber.canceled.connect(on_canceled)
            transcriber.start_transcribing_async()
            done_event.wait(timeout=600)
            transcriber.stop_transcribing_async()
            return "\n".join(results), None
        finally:
            if needs_cleanup and tmp_wav.exists():
                tmp_wav.unlink()
    except Exception as e:
        return None, "Azure 转录失败：" + str(e)

def transcribe_audio_azure(wav_path: str, api_key: str, region: str, language_code: str = "auto") -> Tuple[Optional[str], Optional[str]]:
    try:
        import azure.cognitiveservices.speech as speechsdk
        import datetime as _dt
        file_path = Path(wav_path)
        lang = language_code if language_code != "auto" else "zh-CN"
        speech_config = speechsdk.SpeechConfig(
            subscription=api_key.strip(), region=region.strip()
        )
        speech_config.speech_recognition_language = lang
        tmp_wav = file_path.with_suffix(".tmp.wav")
        needs_cleanup = False
        if file_path.suffix.lower() != ".wav":
            subprocess.run(
                ["ffmpeg", "-y", "-i", str(file_path), "-ar", "16000", "-ac", "1", str(tmp_wav)],
                check=True, capture_output=True
            )
            needs_cleanup = True
        else:
            tmp_wav = file_path
        try:
            audio_config = speechsdk.audio.AudioConfig(filename=str(tmp_wav))
            transcriber = speechsdk.transcription.ConversationTranscriber(
                speech_config=speech_config, audio_config=audio_config
            )
            results = []
            done_event = threading.Event()

            def on_transcribed(evt):
                if evt.result.reason == speechsdk.ResultReason.RecognizedSpeech:
                    start_time = str(_dt.timedelta(microseconds=evt.result.offset / 10)).split(".")[0]
                    speaker = getattr(evt.result, "speaker_id", "Unknown")
                    if not speaker or speaker == "Unknown":
                        speaker = "Guest"
                    results.append(f"[{start_time}] Speaker {speaker}: {evt.result.text}")

            def on_session_stopped(evt):
                done_event.set()

            def on_canceled(evt):
                done_event.set()

            transcriber.transcribed.connect(on_transcribed)
            transcriber.session_stopped.connect(on_session_stopped)
            transcriber.canceled.connect(on_canceled)
            transcriber.start_transcribing_async()
            done_event.wait(timeout=600)
            transcriber.stop_transcribing_async()
            return "\n".join(results), None
        finally:
            if needs_cleanup and tmp_wav.exists():
                tmp_wav.unlink()
    except Exception as e:
        return None, "Azure 转录失败：" + str(e)


def transcribe_audio(wav_path: str, stt_provider: str = DEFAULT_STT_PROVIDER,
                      stt_lang: str = "auto", stt_kwargs: dict = None) -> tuple:
    """带自动 fallback 的 STT 方案统一入口。

    若首选 STT 方案失败，会自动按顺序尝试其他方案，确保文本提取成功。

    stt_provider 可选值：
      - "elevenlabs" -> 默认方案（外部脚本）
      - "crispasr"  -> 备用方案 1：CRISP_ASR
      - "vibeasr"   -> 备用方案 2：VibeASR
      - "whisper"   -> 备用方案 3：Whisper.cpp
      - "azurestt"  -> 备用方案 4：Azure Speech Services
    """
    if stt_kwargs is None:
        stt_kwargs = {}

    # 定义 fallback 顺序：elevenlabs -> crispasr -> vibeasr -> whisper -> azurestt
    # ~ fallback_chain = ["elevenlabs", "crispasr", "vibeasr", "whisper", "azurestt"]
    # 定义 fallback 顺序：azurestt -> crispasr -> vibeasr -> whisper -> elevenlabs    
    fallback_chain = ["azurestt", "fasterwhisper", "crispasr", "vibeasr", "whisper", "elevenlabs"]

    # 如果指定了 provider，优先尝试
    provider = (stt_provider or DEFAULT_STT_PROVIDER).strip().lower()
    if provider and provider in fallback_chain:
        fallback_chain = [provider] + [x for x in fallback_chain if x != provider]

    errors = []
    for prov in fallback_chain:
        progress(f"🎤 尝试 STT 方案：{prov}")
        result, err = None, None

        if prov == "fasterwhisper":  # ← 新增分支
        	result, err = _transcribe_fasterwhisper_batch(wav_path)
        elif prov == "elevenlabs":
            # ElevenLabs 外部脚本方案
            try:
                cmd = [str(STT_SCRIPT), str(wav_path), "--output-dir", str(Path(wav_path).parent), "--output-format", "txt"]
                proc_result = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
                txt_files = list(Path(wav_path).parent.rglob("*.txt"))
                if txt_files:
                    result = txt_files[-1].read_text(encoding="utf-8", errors="replace").strip()
                    if not result:
                        err = "ElevenLabs 输出为空"
                else:
                    err = f"ElevenLabs 未生成 TXT: {proc_result.stderr}"
            except Exception as e:
                err = f"ElevenLabs 异常：{e}"
        elif prov == "crispasr":
            # ~ result, err = _transcribe_cohere(wav_path)
            # ~ result, err = _transcribe_crisp_long_audio(wav_path)
            # ~ return merged_text, warning, merged_txt_path, None
            # ~ transcript, error, txt_path, srt_path = _transcribe_cohere(str(chunk_path))
            result, err, merged_txt_path, autre = _transcribe_crisp_long_audio(wav_path)
        elif prov == "vibeasr":
            result, err = _transcribe_vibeasr(wav_path)
        elif prov == "whisper":
            result, err = _transcribe_whispercpp(wav_path)
        elif prov == "azurestt":
            az_config = STT_API_KEYS.get("azure", {})
            result, err = transcribe_audio_azure(
                wav_path,
                az_config.get("key", ""),
                az_config.get("region", ""),
                stt_lang
            )

        if result:
            progress(f"✅ STT 成功：{prov}")
            return result, None
        else:
            progress(f"❌ STT 失败：{prov} - {err}")
            errors.append(f"{prov}: {err}")

    return None, f"所有 STT 方案均失败： | ".join(errors)


def process_youtube_if_needed(url: str, task_dir: Path, args: argparse.Namespace, notify_config: dict) -> dict[str, Any]:
    """
    每个 URL 真正进入处理线程前，再次读取最新 YouTube 日志并决定是否执行。
    规则：
      - 有记录且 status == "failed"  -> 继续执行
      - 有记录且 status == "success" -> 跳过
      - 没有记录                   -> 继续执行
    """
    history = read_history(YOUTUBE_LOG_FILE)
    key = video_id_from_url(url) or url
    old = history.get(key) or history.get(url)
    status = (old.get("状态", "") if old else "").strip().lower()

    if status in {"success", "成功", "ok"} and not args.force:
        progress(f"⏭️ 历史成功，跳过：{url}")
        return {
            "url": url,
            "video_id": key,
            "status": "skipped",
            "mode": "history_success",
            "seconds": 0,
            "steps": {},
            "files": [old.get("输出文件", "")],
            "error": "历史记录显示已成功",
        }

    if status in {"failed", "失败"}:
        progress(f"🔁 历史状态为 failed，继续执行：{url}")
    elif not old:
        progress(f"🆕 日志中没有记录，继续执行：{url}")
    else:
        progress(f"▶️ 历史状态为 {status or '未知'}，继续执行：{url}")

    return process_youtube(url, task_dir, args, notify_config)


def process_youtube(url: str, task_dir: Path, args: argparse.Namespace, notify_config: dict) -> dict[str, Any]:
    """
    原有 YouTube 处理逻辑，保持功能不变。
    仅作为 process_youtube_if_needed 的底层执行函数。
    """
    started = time.monotonic()
    result: dict[str, Any] = {
        "url": url,
        "video_id": video_id_from_url(url),
        "status": "failed",
        "mode": "",
        "steps": {},
        "files": [],
        "error": "",
    }
    subtitle_dir, audio_dir, stt_dir, report_dir = [
        task_dir / x for x in ("subtitle_reports", "audio", "transcripts", "reports")
    ]
    for directory in (subtitle_dir, audio_dir, stt_dir, report_dir):
        directory.mkdir(parents=True, exist_ok=True)

    def step(name: str, command: list[str], log_name: str, label: str) -> tuple[int, str]:
        t = time.monotonic()
        code, output = run_command(
            command,
            task_dir / "logs" / log_name,
            args.timeout,
            label,
        )
        result["steps"][name] = {
            "seconds": round(time.monotonic() - t, 3),
            "returncode": code,
        }
        return code, output

    try:
        progress(f"📌 开始处理 YouTube：{url}")
        before_reports = set(subtitle_dir.rglob("*.md"))
        code, output = step(
            "subtitle_summary",
            [
                str(args.summarizer),
                url,
                "--output",
                str(subtitle_dir),
                "--workers",
                "1",
            ]
            + (["--no-cookies"] if args.no_cookies else []),
            "subtitle_summary.log",
            "YouTube 步骤 1/4：获取字幕并总结",
        )
        reports = [p for p in subtitle_dir.rglob("*.md") if p not in before_reports]
        if code == 0 and reports:
            result.update(
                status="success",
                mode="subtitle",
                files=[str(p) for p in reports],
            )
            progress(f"✅ YouTube 字幕报告已生成：{reports[0]}")
        elif code != 0 and not no_subtitles(output):
            raise RuntimeError("字幕总结脚本失败；详见 subtitle_summary.log")
        else:
            progress("ℹ️ YouTube 没有可用字幕，进入音频转录流程")
            result["mode"] = "audio_stt"
            suffixes = {".mp3", ".wav", ".m4a", ".opus", ".aac", ".flac", ".mp4", ".webm"}
            before_audio = set(new_files(audio_dir, suffixes, set()))
            code, _ = step(
                "audio_download",
                [
                    str(args.downloader),
                    url,
                    "--output",
                    str(audio_dir),
                    "--format",
                    args.audio_format,
                    "--workers",
                    "1",
                ]
                + (["--no-cookies"] if args.no_cookies else []),
                "audio_download.log",
                "YouTube 步骤 2/4：下载音频",
            )
            audio_files = new_files(audio_dir, suffixes, before_audio)
            if code != 0 or not audio_files:
                raise RuntimeError("音频下载失败或未找到音频")
            audio = max(audio_files, key=lambda p: p.stat().st_mtime)
            provider = (args.stt_provider or DEFAULT_STT_PROVIDER).strip().lower()
            t_stt = time.monotonic()
            if provider == "elevenlabs":
                before_txt = set(stt_dir.rglob("*.txt"))
                code, _ = step(
                    "speech_to_text",
                    [
                        str(args.stt),
                        str(audio),
                        "--output-dir",
                        str(stt_dir),
                        "--output-format",
                        "txt",
                        "--model",
                        args.stt_model,
                    ],
                    "speech_to_text.log",
                    "YouTube 步骤 3/4：语音转文字",
                )
                txt_files = [p for p in stt_dir.rglob("*.txt") if p not in before_txt]
                if code != 0 or not txt_files:
                    raise RuntimeError("STT 失败或未找到 TXT")
                transcript_file = max(txt_files, key=lambda p: p.stat().st_mtime)
                transcript = transcript_file.read_text(encoding="utf-8", errors="replace").strip()
            else:
                progress(f"▶️ 开始：YouTube 步骤 3/4：语音转文字（本地方案：{provider}）")
                transcript, stt_err = transcribe_audio(str(audio), stt_provider=provider)
                result["steps"]["speech_to_text"] = {
                    "seconds": round(time.monotonic() - t_stt, 3),
                    "returncode": 0 if transcript else 1,
                    "provider": provider,
                }
                if stt_err or not transcript:
                    raise RuntimeError(f"STT（{provider}）失败：{stt_err or '输出为空'}")
                transcript_file = stt_dir / f"{clean_name(audio.stem)}.txt"
                transcript_file.write_text(transcript, encoding="utf-8")
                progress(f"✅ 完成：YouTube 步骤 3/4：语音转文字（本地方案：{provider}）")
            if not transcript:
                raise RuntimeError("STT 输出为空")
            t = time.monotonic()
            content, provider = summarize_transcript(
                transcript, audio.stem, "YouTube 视频的音频转录文本"
            )
            result["steps"]["transcript_summary"] = {
                "seconds": round(time.monotonic() - t, 3),
                "provider": provider,
            }
            report_path = report_dir / f"{clean_name(audio.stem)}.md"
            report_path.write_text(
                f"# {audio.stem}\n\n"
                f"## 基本信息\n"
                f"- 来源：YouTube\n"
                f"- URL：{url}\n"
                f"- 视频 ID：{result['video_id']}\n"
                f"- 生成日期：{datetime.now().date().isoformat()}\n\n"
                + content.lstrip("# ")
                + f"\n\n## 转录文本\n\n{transcript}\n",
                encoding="utf-8",
            )
            result.update(
                status="success",
                files=[str(report_path), str(transcript_file), str(audio)],
                ai_provider=provider,
            )
            progress(f"✅ YouTube 最终报告已生成：{report_path}")
    except Exception as exc:
        result["error"] = str(exc)
        progress(f"❌ YouTube 处理失败：{url}：{exc}")

    result["seconds"] = round(time.monotonic() - started, 3)
    log_youtube_completion(url, result, task_dir)
    dispatch_notifications(
        ("✅" if result["status"] == "success" else "❌") + f" YouTube 总结：{url}",
        item_message(result, "url"),
        notify_config,
    )
    return result
    
    
    
def ffmpeg_extract(source: Path, target: Path, task_dir: Path, timeout: int) -> tuple[bool, str]:
    if not shutil.which("ffmpeg"):
        return False, "未找到 ffmpeg，请安装并加入 PATH"
    command = ["ffmpeg", "-y", "-i", str(source), "-vn", "-map", "0:a:0?", "-ac", "1", "-ar", "16000", "-codec:a", "libmp3lame", "-b:a", "128k", str(target)]
    code, output = run_command(command, task_dir / "logs" / f"ffmpeg_{clean_name(source.stem)}.log", timeout, f"视频转音频：{source.name}")
    return bool(code == 0 and target.exists() and target.stat().st_size > 0), output


def process_media(source: Path, task_dir: Path, args: argparse.Namespace, notify_config: dict) -> dict[str, Any]:
    started = time.monotonic()
    is_video = source.suffix.lower() in VIDEO_SUFFIXES
    result: dict[str, Any] = {"source": media_key(source), "media_type": "video" if is_video else "audio", "conversion_status": "pending" if is_video else "not_needed", "status": "failed", "mode": "local_media", "steps": {}, "files": [], "error": "", "audio_input": ""}
    audio_dir, stt_dir, report_dir = task_dir / "converted_audio", task_dir / "transcripts", task_dir / "reports"
    for directory in (audio_dir, stt_dir, report_dir):
        directory.mkdir(parents=True, exist_ok=True)
    try:
        progress(f"📌 开始处理本地媒体：{source}")
        if is_video:
            target = audio_dir / f"{clean_name(source.stem)}.mp3"
            t = time.monotonic()
            ok, error = ffmpeg_extract(source, target, task_dir, args.timeout)
            result["steps"]["video_to_audio"] = {"seconds": round(time.monotonic() - t, 3), "returncode": 0 if ok else 1}
            if not ok:
                raise RuntimeError("ffmpeg 转换失败或未生成有效音频" if error else "视频没有可用音轨")
            result["conversion_status"] = "success"
            result["audio_input"] = str(target)
            stt_input = target
        else:
            result["audio_input"] = str(source)
            stt_input = source
        provider = (args.stt_provider or DEFAULT_STT_PROVIDER).strip().lower()
        t = time.monotonic()
        if provider == "elevenlabs":
            before_txt = set(stt_dir.rglob("*.txt"))
            code, _ = run_command([str(args.stt), str(stt_input), "--output-dir", str(stt_dir), "--output-format", "txt", "--model", args.stt_model], task_dir / "logs" / f"stt_{clean_name(source.stem)}.log", args.timeout, f"语音转文字：{source.name}")
            result["steps"]["speech_to_text"] = {"seconds": round(time.monotonic() - t, 3), "returncode": code}
            txt_files = [p for p in stt_dir.rglob("*.txt") if p not in before_txt]
            if code != 0 or not txt_files:
                raise RuntimeError("STT 失败或未生成 TXT")
            transcript_file = max(txt_files, key=lambda p: p.stat().st_mtime)
            transcript = transcript_file.read_text(encoding="utf-8", errors="replace").strip()
        else:
            progress(f"▶️ 开始：语音转文字（本地方案：{provider}）：{source.name}")
            transcript, stt_err = transcribe_audio(str(stt_input), stt_provider=provider)
            result["steps"]["speech_to_text"] = {
                "seconds": round(time.monotonic() - t, 3),
                "returncode": 0 if transcript else 1,
                "provider": provider,
            }
            if stt_err or not transcript:
                raise RuntimeError(f"STT（{provider}）失败：{stt_err or '输出为空'}")
            transcript_file = stt_dir / f"{clean_name(source.stem)}.txt"
            transcript_file.write_text(transcript, encoding="utf-8")
            progress(f"✅ 完成：语音转文字（本地方案：{provider}）：{source.name}")
        if not transcript:
            raise RuntimeError("STT 输出为空")
        t = time.monotonic()
        content, provider = summarize_transcript(transcript, source.stem, "本地音频或视频的转录文本")
        result["steps"]["transcript_summary"] = {"seconds": round(time.monotonic() - t, 3), "provider": provider}
        report_path = report_dir / f"{clean_name(source.stem)}.md"
        report_path.write_text(f"# {source.stem}\n\n## 基本信息\n- 来源：本地媒体文件\n- 原始文件：{source}\n- 媒体类型：{'视频（已提取音频）' if is_video else '音频'}\n- 生成日期：{datetime.now().date().isoformat()}\n\n" + content.lstrip("# ") + f"\n\n## 转录文本\n\n{transcript}\n", encoding="utf-8")
        result.update(status="success", files=[str(report_path), str(transcript_file), str(stt_input)], ai_provider=provider)
        progress(f"✅ 本地媒体报告已生成：{report_path}")
    except Exception as exc:
        result["error"] = str(exc)
        progress(f"❌ 本地媒体处理失败：{source}：{exc}")
    result["seconds"] = round(time.monotonic() - started, 3)
    log_media_completion(source, result, task_dir)
    dispatch_notifications(("✅" if result["status"] == "success" else "❌") + f" 本地媒体总结：{source.name}", item_message(result, "source"), notify_config)
    return result


def item_message(result: dict[str, Any], source_key: str) -> str:
    lines = [f"**来源**: `{result.get(source_key, '')}`", f"**状态**: {'✅ 成功' if result['status'] == 'success' else '❌ 失败'}", f"**模式**: {result.get('mode') or '未开始'}", f"**总耗时**: {result.get('seconds', 0):.2f} 秒", "", "### 步骤耗时"]
    for name, item in result.get("steps", {}).items():
        lines.append(f"- {name}: {item.get('seconds', 0):.2f} 秒")
    if result.get("files"):
        lines += ["", "### 输出文件"] + [f"- `{x}`" for x in result["files"]]
    if result.get("error"):
        lines += ["", f"### 错误\n{result['error']}"]
    return "\n".join(lines)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="YouTube 与本地音频/视频统一总结编排器")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("url", nargs="?", help="单个 YouTube URL")
    group.add_argument("--file", "-f", help="URL 文本列表文件")
    group.add_argument("--urls", "-u", nargs="+", help="多个 YouTube URL")
    group.add_argument("--stdin", action="store_true", help="从标准输入读取 URL")
    group.add_argument("--dir", "-d", metavar="FOLDER", help="本地音频/视频文件目录")
    parser.add_argument("-o", "--output", default=str(DEFAULT_ROOT))
    parser.add_argument("-w", "--workers", type=int, default=1)
    parser.add_argument("--no-recursive", action="store_true", help="--dir 只扫描当前目录")
    parser.add_argument("--summarizer", default=str(SUMMARIZER_SCRIPT))
    parser.add_argument("--downloader", default=str(DOWNLOADER_SCRIPT))
    parser.add_argument("--stt", default=str(STT_SCRIPT))
    parser.add_argument("--stt-model", default="scribe_v2")


    parser.add_argument(
        "--stt-provider",
        choices=("fasterwhisper", "elevenlabs", "azurestt", "crispasr", "vibeasr", "whisper"),
        default=DEFAULT_STT_PROVIDER,
        help="选择 STT 语音转文字方案：fasterwhisper（默认，stt_fasterwhisper_batch.py 外部脚本）"
        "/ elevenlabs（原默认方案）"
        "/ azurestt（Azure Speech Services）"
        "/ crispasr（本地 CRISP_ASR）"
        "/ vibeasr（本地 VibeASR）"
        "/ whisper（本地 Whisper.cpp）",
    )

    
    parser.add_argument("--audio-format", choices=("mp3", "wav", "m4a", "opus"), default="mp3")
    parser.add_argument("--no-cookies", action="store_true")
    parser.add_argument("--timeout", type=int, default=3600)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--no-notify", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    if not 1 <= args.workers <= 10:
        parser.error("--workers 必须在 1 到 10 之间")
        
    if not args.dir:
        required_scripts = [("summarizer", args.summarizer), ("downloader", args.downloader)]
        if args.stt_provider == "elevenlabs":
            required_scripts.append(("stt", args.stt))
        if args.stt_provider == "fasterwhisper":
            if not FASTERWHISPER_STT_SCRIPT.is_file():
                parser.error(f"fasterwhisper_batch 脚本不存在：{FASTERWHISPER_STT_SCRIPT}")            
        for label, script in required_scripts:
            if not Path(script).expanduser().exists():
                parser.error(f"{label} 脚本不存在：{script}")
        urls = read_urls(args)
        if not urls:
            parser.error("没有找到有效 URL")
    else:
        source_dir = Path(args.dir).expanduser().resolve()
        if not source_dir.is_dir():
            parser.error(f"本地媒体目录不存在：{source_dir}")
        if args.stt_provider == "elevenlabs" and not Path(args.stt).expanduser().exists():
            parser.error(f"STT 脚本不存在：{args.stt}")
        if args.stt_provider == "fasterwhisper" and not FASTERWHISPER_STT_SCRIPT.is_file():
            parser.error(f"fasterwhisper_batch 脚本不存在：{FASTERWHISPER_STT_SCRIPT}")            

                        
        if not scan_media(source_dir, not args.no_recursive):
            parser.error(f"没有找到支持的音频/视频文件：{source_dir}")

    if args.dry_run:
        if args.dir:
            for path in scan_media(Path(args.dir).expanduser().resolve(), not args.no_recursive):
                print(f"{'视频 -> ffmpeg MP3 -> STT' if path.suffix.lower() in VIDEO_SUFFIXES else '音频 -> STT'}: {path}")
        else:
            print("有效 URL：\n" + "\n".join(urls))
        return 0

    task_dir = Path(args.output).expanduser().resolve() / datetime.now().strftime("%Y%m%d_%H%M_task")
    (task_dir / "logs").mkdir(parents=True, exist_ok=True)
    notify_config = {"enabled": False, "channels": {}} if args.no_notify else load_notify_config()
    started = time.monotonic()
    results = []

    if args.dir:
        source_dir = Path(args.dir).expanduser().resolve()
        files = scan_media(source_dir, not args.no_recursive)
        history = read_history(MEDIA_LOG_FILE)
        pending = []
        progress(f"任务目录：{task_dir}")
        progress(f"本地媒体目录：{source_dir}")
        progress(f"扫描到：{len(files)} 个文件；视频：{sum(p.suffix.lower() in VIDEO_SUFFIXES for p in files)}；音频：{sum(p.suffix.lower() in AUDIO_SUFFIXES for p in files)}")
        for path in files:
            key = media_key(path)
            old = history.get(key)
            if old and old.get("状态", "").lower() in {"success", "成功", "ok"} and not args.force:
                progress(f"⏭️ 历史成功，跳过：{path.name}")
                results.append({"source": key, "status": "skipped", "mode": "local_media_history_success", "seconds": 0, "steps": {}, "files": [old.get("报告文件", "")], "error": "历史记录显示已成功"})
            else:
                pending.append(path)
        with ThreadPoolExecutor(max_workers=min(args.workers, max(1, len(pending)))) as pool:
            futures = [pool.submit(process_media, path, task_dir, args, notify_config) for path in pending]
            for future in as_completed(futures):
                results.append(future.result())
        source_mode = "local_media"
    else:
        history = read_history(YOUTUBE_LOG_FILE)
        pending = []
        progress(f"任务目录：{task_dir}")
        progress(f"输入：{len(urls)} 个 YouTube URL")
        for url in urls:
            key = video_id_from_url(url) or url
            old = history.get(key) or history.get(url)
            if old and old.get("状态", "").lower() in {"success", "成功", "ok"} and not args.force:
                progress(f"⏭️ 历史成功，跳过：{url}")
                results.append({"url": url, "video_id": key, "status": "skipped", "mode": "history_success", "seconds": 0, "steps": {}, "files": [old.get("输出文件", "")], "error": "历史记录显示已成功"})
            else:
                pending.append(url)
                
        # 关键修复：为 pending 中每个 URL 创建独立 future，并建立 future -> URL 映射。
        progress(f"📋 YouTube 待处理 URL 数量：{len(pending)}")
        for index, pending_url in enumerate(pending, start=1):
            progress(f"  [{index}/{len(pending)}] 已加入处理队列：{pending_url}")

        if pending:
            with ThreadPoolExecutor(max_workers=min(args.workers, len(pending))) as pool:
                future_to_url = {
                    # ~ pool.submit(process_youtube, pending_url, task_dir, args, notify_config): pending_url
                    pool.submit(process_youtube_if_needed, pending_url, task_dir, args, notify_config): pending_url
                    for pending_url in pending
                }
                for future in as_completed(future_to_url):
                    pending_url = future_to_url[future]
                    try:
                        results.append(future.result())
                    except Exception as exc:
                        progress(f"❌ URL 任务异常：{pending_url}：{exc}")
                        results.append({"url": pending_url, "video_id": video_id_from_url(pending_url), "status": "failed", "mode": "exception", "steps": {}, "files": [], "error": str(exc), "seconds": 0})
        source_mode = "youtube"
                        

    total_seconds = round(time.monotonic() - started, 3)
    report = {"task_dir": str(task_dir), "source_mode": source_mode, "total_seconds": total_seconds, "total": len(results), "success": sum(x["status"] in {"success", "skipped"} for x in results), "failed": sum(x["status"] == "failed" for x in results), "skipped": sum(x["status"] == "skipped" for x in results), "results": sorted(results, key=lambda x: x.get("url", x.get("source", "")))}
    report_path = task_dir / "task_report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    summary = [f"## {'YouTube' if source_mode == 'youtube' else '本地媒体'}总结批处理完成", f"- 任务目录：`{task_dir}`", f"- 总数：{report['total']}", f"- 成功或历史跳过：{report['success']}", f"- 失败：{report['failed']}", f"- 历史跳过：{report['skipped']}", f"- 总耗时：{total_seconds:.3f} 秒", "", "### 明细"]
    for item in report["results"]:
        source = item.get("url", item.get("source", ""))
        summary.append(f"- {'✅' if item['status'] in {'success', 'skipped'} else '❌'} {source} | {item.get('mode')} | {item.get('seconds', 0):.2f}s")
        for name, step in item.get("steps", {}).items():
            summary.append(f"  - {name}: {step.get('seconds', 0):.2f}s")
        if item.get("error"):
            summary.append(f"  - 错误：{item['error']}")
    summary_content = "\n".join(summary)
    dispatch_notifications("📊 YouTube/本地媒体总结批处理报告", summary_content, notify_config)
    progress("✅ 全部任务结束")
    print("\n" + summary_content + f"\n\nJSON 报告：{report_path}")
    return 0 if report["failed"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
