"""Offline regression tests: no model or TTS network calls are made."""
import ast
import asyncio
import importlib.util
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, Mock, patch


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "tts.py"
spec = importlib.util.spec_from_file_location("edge_tts_skill", SCRIPT)
tts = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tts)


def assistant(text='{"ok":true}', **overrides):
    message = {
        "role": "assistant", "provider": "omnirush", "model": "gpt-6-astra",
        "stopReason": "stop", "content": [{"type": "text", "text": text}],
    }
    message.update(overrides)
    return message


def events(message=None, extra=()):
    message = assistant() if message is None else message
    return "\n".join(json.dumps(item, ensure_ascii=False) for item in [
        {"type": "session", "version": 3},
        {"type": "message_start", "message": {"role": "assistant", "content": []}},
        {"type": "message_update", "assistantMessageEvent": {
            "type": "text_delta", "delta": "NOT THE FINAL ANSWER"}},
        *extra,
        {"type": "message_end", "message": message},
        {"type": "turn_end", "message": message},
        {"type": "agent_end", "messages": [message]},
    ]) + "\n"


def process(stdout=None, returncode=0, stderr=""):
    result = Mock()
    result.returncode = returncode
    result.pid = 99999999
    result.communicate.return_value = (events() if stdout is None else stdout, stderr)
    return result


class OmniRushTransportTests(unittest.TestCase):
    def setUp(self):
        self.env_patch = patch.dict(os.environ, {
            "OMNIRUSH_MODEL": "gpt-6-astra", "OMNIRUSH_REASONING_LEVEL": "xhigh",
            "EDGE_TTS_AI_TIMEOUT": "30", "OMNIRUSH_CODING_AGENT_DIR": "/existing/account",
        })
        self.env_patch.start()
        self.addCleanup(self.env_patch.stop)
        self.bin_patch = patch.object(tts, "_omnirush_executable", return_value="/native/omnirush")
        self.bin_patch.start()
        self.addCleanup(self.bin_patch.stop)
        self.sleep_patch = patch.object(tts.time, "sleep")
        self.sleep = self.sleep_patch.start()
        self.addCleanup(self.sleep_patch.stop)
        self.stdout_patch = patch("sys.stdout", new_callable=io.StringIO)
        self.stdout = self.stdout_patch.start()
        self.addCleanup(self.stdout_patch.stop)
        self.stderr_patch = patch("sys.stderr", new_callable=io.StringIO)
        self.stderr = self.stderr_patch.start()
        self.addCleanup(self.stderr_patch.stop)
        self.messages = [{"role": "system", "content": "Return JSON"},
                         {"role": "user", "content": "PRIVATE 中文 SOURCE"}]

    def test_complete_assistant_only_and_guarded_ephemeral_invocation(self):
        completed = assistant(content=[
            {"type": "thinking", "thinking": "DO NOT USE THINKING"},
            {"type": "text", "text": '{"ok":'},
            {"type": "text", "text": 'true}'},
        ])
        child = process(events(completed, [{"type": "message_end", "message": {
            "role": "user", "content": "DO NOT USE USER TEXT"}}]))
        observed = {}

        def spawn(command, **kwargs):
            observed.update(command=command, kwargs=kwargs)
            self.assertEqual(list(Path(kwargs["cwd"]).iterdir()), [])
            return child

        with patch.object(tts.subprocess, "Popen", side_effect=spawn):
            self.assertEqual(tts._ai_call(self.messages), '{"ok":true}')
        command, kwargs = observed["command"], observed["kwargs"]
        self.assertEqual(command[0], "/native/omnirush")
        for flag in ("--print", "--no-session", "--no-tools", "--no-extensions",
                     "--no-skills", "--no-prompt-templates", "--no-themes", "--no-context-files"):
            self.assertIn(flag, command)
        self.assertEqual(command[command.index("--mode") + 1], "json")
        self.assertEqual(command[command.index("--engine") + 1], "pi")
        self.assertEqual(command[command.index("--provider") + 1], "omnirush")
        self.assertEqual(command[command.index("--model") + 1], "gpt-6-astra")
        self.assertEqual(command[command.index("--thinking") + 1], "xhigh")
        self.assertNotIn("--skill", command)
        self.assertNotIn("--extension", command)
        self.assertNotIn("--api-key", command)
        self.assertNotIn("PRIVATE 中文 SOURCE", " ".join(command))
        self.assertNotIn("shell", kwargs)
        self.assertEqual(kwargs["stdin"], subprocess.PIPE)
        self.assertEqual(kwargs["env"]["OMNIRUSH_CODING_AGENT_DIR"], "/existing/account")
        self.assertEqual(kwargs["env"]["OMNIRUSH_AUTO_UPDATE"], "0")
        self.assertEqual(kwargs["env"]["OMNIRUSH_CRASH_REPORTS"], "0")
        self.assertEqual(kwargs["start_new_session"], os.name == "posix")
        self.assertFalse(Path(kwargs["cwd"]).exists())
        call = child.communicate.call_args.kwargs
        self.assertEqual(json.loads(call["input"]), {"messages": self.messages})
        self.assertEqual(call["timeout"], 30)
        self.assertNotIn("PRIVATE", self.stdout.getvalue() + self.stderr.getvalue())

    def test_missing_cli_returns_none_without_subprocess(self):
        with patch.object(tts, "_omnirush_executable", return_value=None), \
                patch.object(tts.subprocess, "Popen") as spawn:
            self.assertIsNone(tts._ai_call(self.messages))
        spawn.assert_not_called()

    def test_executable_disappeared_does_not_retry(self):
        with patch.object(tts.subprocess, "Popen", side_effect=FileNotFoundError) as spawn:
            self.assertIsNone(tts._ai_call(self.messages, max_retries=3))
        self.assertEqual(spawn.call_count, 1)

    def test_cli_failure_retries_same_model_without_echoing_stderr(self):
        failure = process(returncode=1, stderr="PRIVATE KEY OR PROMPT")
        success = process()
        with patch.object(tts.subprocess, "Popen", side_effect=[failure, success]) as spawn:
            self.assertEqual(tts._ai_call(self.messages), '{"ok":true}')
        self.assertEqual(spawn.call_count, 2)
        self.assertEqual(spawn.call_args_list[0].args, spawn.call_args_list[1].args)
        self.sleep.assert_called_once_with(2)
        self.assertNotIn("PRIVATE", self.stderr.getvalue())

    def test_timeout_stops_launcher_process_group_then_retries(self):
        timed = process()
        timed.communicate.side_effect = [subprocess.TimeoutExpired("PRIVATE COMMAND", 30), ("", "")]
        with patch.object(tts.subprocess, "Popen", side_effect=[timed, process()]), \
                patch.object(tts.os, "killpg") as killpg:
            self.assertEqual(tts._ai_call(self.messages), '{"ok":true}')
        if os.name == "posix":
            killpg.assert_called_once_with(timed.pid, signal.SIGTERM)
        else:
            timed.terminate.assert_called_once()
        self.assertEqual(timed.communicate.call_count, 2)
        self.assertNotIn("PRIVATE", self.stderr.getvalue())

    def test_shutdown_escalates_when_engine_will_not_exit(self):
        child = process()
        child.communicate.side_effect = [subprocess.TimeoutExpired("ignored", 3), ("", "")]
        with patch.object(tts.os, "killpg") as killpg:
            tts._stop_ai_process(child)
        if os.name == "posix":
            self.assertEqual(killpg.call_args_list[0].args, (child.pid, signal.SIGTERM))
            self.assertEqual(killpg.call_args_list[1].args, (child.pid, signal.SIGKILL))
        else:
            child.terminate.assert_called_once()
            child.kill.assert_called_once()

    def test_malformed_empty_partial_or_failed_output_is_not_success(self):
        cases = [
            "", "not json", "[]", '{"choices":[{"message":{"content":"fake"}}]}',
            events(assistant(content=[])),
            events(assistant(content=[{"type": "thinking", "thinking": "not text"}])),
            events(assistant(stopReason="length")), events(assistant(stopReason="error")),
            events(assistant(stopReason="aborted")), events(assistant(errorMessage="SECRET")),
            events(assistant(provider="other")), events(assistant(model="different-model")),
            events(assistant(content=[{"type": "toolCall", "name": "bash"}])),
            events(extra=[{"type": "tool_execution_start", "toolName": "bash"}]),
            json.dumps({"type": "message_end", "message": assistant()}),
            json.dumps({"type": "agent_end", "messages": 42}),
        ]
        for output in cases:
            with self.subTest(output=output), patch.object(tts.subprocess, "Popen", return_value=process(output)):
                self.assertIsNone(tts._ai_call(self.messages, max_retries=1))
        self.assertNotIn("SECRET", self.stderr.getvalue())

    def test_stream_agent_end_can_supply_completed_message(self):
        output = json.dumps({"type": "agent_end", "messages": [assistant()]})
        with patch.object(tts.subprocess, "Popen", return_value=process(output)):
            self.assertEqual(tts._ai_call(self.messages), '{"ok":true}')

    def test_transport_attempts_have_hard_limit(self):
        with patch.object(tts.subprocess, "Popen", return_value=process("bad")) as spawn:
            self.assertIsNone(tts._ai_call(self.messages, max_retries=999))
        self.assertEqual(spawn.call_count, 3)
        self.assertEqual(self.sleep.call_count, 2)

    def test_timeout_configuration_bounds_and_invalid_value(self):
        for value in ("0", "601", "nan", "not-an-integer"):
            with self.subTest(value=value), patch.dict(os.environ, {"EDGE_TTS_AI_TIMEOUT": value}), \
                    patch.object(tts.subprocess, "Popen") as spawn:
                self.assertIsNone(tts._ai_call(self.messages))
                spawn.assert_not_called()

    def test_cli_default_model_is_not_overridden_without_metadata(self):
        with patch.dict(os.environ, {"OMNIRUSH_MODEL": "", "OMNIRUSH_REASONING_LEVEL": ""}), \
                patch.object(tts.subprocess, "Popen", return_value=process()) as spawn:
            self.assertEqual(tts._ai_call(self.messages), '{"ok":true}')
        self.assertNotIn("--model", spawn.call_args.args[0])
        self.assertNotIn("--thinking", spawn.call_args.args[0])

    def test_current_qualified_model_and_effort_suffix_are_retained(self):
        with patch.dict(os.environ, {"OMNIRUSH_MODEL": "omnirush/gpt-6-astra:xhigh"}), \
                patch.object(tts.subprocess, "Popen", return_value=process()) as spawn:
            self.assertEqual(tts._ai_call(self.messages), '{"ok":true}')
        command = spawn.call_args.args[0]
        self.assertEqual(command[command.index("--model") + 1], "omnirush/gpt-6-astra:xhigh")

    def test_external_provider_model_is_never_invoked(self):
        with patch.dict(os.environ, {"OMNIRUSH_MODEL": "external/model"}), \
                patch.object(tts.subprocess, "Popen") as spawn:
            self.assertIsNone(tts._ai_call(self.messages))
        spawn.assert_not_called()

    def test_no_key_specific_reads_or_http_ai_request_code(self):
        original_getenv = os.getenv
        reads = []

        def getenv(name, default=None):
            reads.append(name)
            return original_getenv(name, default)

        with patch.object(tts.os, "getenv", side_effect=getenv), \
                patch.object(tts.subprocess, "Popen", return_value=process()):
            self.assertEqual(tts._ai_call(self.messages), '{"ok":true}')
        self.assertFalse(any("KEY" in name or "TOKEN" in name for name in reads), reads)
        tree = ast.parse(SCRIPT.read_text(encoding="utf-8"))
        imports = [alias.name for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names]
        self.assertNotIn("requests", imports)
        names = {node.id for node in ast.walk(tree) if isinstance(node, ast.Name)}
        self.assertNotIn("AI_SERVICES", names)
        self.assertNotIn("requests", names)
        literal_strings = [node.value for node in ast.walk(tree) if isinstance(node, ast.Constant)
                           and isinstance(node.value, str)]
        self.assertFalse(any("chat/completions" in value for value in literal_strings))


class ExecutableDiscoveryTests(unittest.TestCase):
    def test_explicit_nonsecret_native_path(self):
        with patch.dict(os.environ, {"EDGE_TTS_OMNIRUSH_BIN": "/custom/native/omnirush"}), \
                patch.object(tts.shutil, "which", return_value="/custom/native/omnirush") as which:
            self.assertEqual(tts._omnirush_executable(), "/custom/native/omnirush")
        which.assert_called_once_with("/custom/native/omnirush")

    def test_native_npm_launcher_precedes_skill_injecting_shim(self):
        with tempfile.TemporaryDirectory() as home:
            native = Path(home) / ".npm-global/bin/omnirush"
            native.parent.mkdir(parents=True)
            native.write_text("#!/bin/sh\n", encoding="utf-8")
            native.chmod(0o700)
            with patch.dict(os.environ, {"EDGE_TTS_OMNIRUSH_BIN": ""}), \
                    patch.object(tts.Path, "home", return_value=Path(home)), \
                    patch.object(tts.shutil, "which") as which:
                self.assertEqual(tts._omnirush_executable(), str(native))
            which.assert_not_called()

    def test_unsafe_known_shim_is_not_a_fallback_or_explicit_override(self):
        with tempfile.TemporaryDirectory() as home:
            shim = str(Path(home) / ".omnirush/agent/bin/omnirush")
            for configured in ("", shim):
                with self.subTest(configured=configured), \
                        patch.dict(os.environ, {"EDGE_TTS_OMNIRUSH_BIN": configured}), \
                        patch.object(tts.Path, "home", return_value=Path(home)), \
                        patch.object(tts.shutil, "which", return_value=shim):
                    self.assertIsNone(tts._omnirush_executable())


class TextPathRegressionTests(unittest.TestCase):
    def setUp(self):
        self.logs = patch("sys.stdout", new_callable=io.StringIO)
        self.logs.start()
        self.addCleanup(self.logs.stop)
        self.errors = patch("sys.stderr", new_callable=io.StringIO)
        self.errors.start()
        self.addCleanup(self.errors.stop)

    def test_compatibility_entry_point_routes_to_same_adapter(self):
        messages = [{"role": "user", "content": "source"}]
        with patch.object(tts, "_ai_call", return_value="response") as call:
            self.assertEqual(tts._ai_call_with_fallback(messages, 3), "response")
        call.assert_called_once_with(messages, max_retries=3)

    def test_valid_semantic_segments_cover_source(self):
        segments = ["第一句字幕。", "第二句字幕。", "第三句字幕。"]
        source = "".join(segments)
        reply = json.dumps({"segments": [{"index": i, "text": x} for i, x in enumerate(segments)]})
        with patch.object(tts, "_ai_call", return_value=reply):
            self.assertEqual(tts.split_text_semantic(source, max_chars=8), segments)

    def test_semantic_retry_then_success(self):
        segments = ["第一句字幕。", "第二句字幕。", "第三句字幕。"]
        reply = json.dumps({"segments": [{"index": i, "text": x} for i, x in enumerate(segments)]})
        with patch.object(tts, "_ai_call", side_effect=["malformed", reply]) as call:
            self.assertEqual(tts.split_text_semantic("".join(segments), max_chars=8), segments)
        self.assertEqual(call.call_count, 2)

    def test_exhausted_requests_or_invalid_semantic_output_use_local_fallback(self):
        source = "第一句字幕。第二句字幕。第三句字幕。第四句字幕。"
        expected = tts.local_semantic_fallback(source, 8)
        for reply in (None, "bad json", '{"segments":[{"index":0,"text":"invented"}]}'):
            with self.subTest(reply=reply), patch.object(tts, "_ai_call", return_value=reply) as call:
                self.assertEqual(tts.split_text_semantic(source, max_chars=8, retries=999), expected)
                self.assertEqual(call.call_count, 3)
        self.assertEqual(tts.validate_segments_against_source(source, expected), expected)

    def test_short_semantic_input_does_not_call_model(self):
        with patch.object(tts, "_ai_call") as call:
            self.assertEqual(tts.split_text_semantic("短文本。", max_chars=8), ["短文本。"])
        call.assert_not_called()

    def test_translation_and_highlights_share_subprocess_transport(self):
        replies = [
            events(assistant('{"items":[{"index":0,"text":"Hello"}]}')),
            events(assistant('{"keywords":["Hello","Hello","World"]}')),
        ]
        with patch.object(tts, "_omnirush_executable", return_value="/native/omnirush"), \
                patch.dict(os.environ, {"OMNIRUSH_MODEL": "gpt-6-astra", "EDGE_TTS_AI_TIMEOUT": "30"}), \
                patch.object(tts.subprocess, "Popen", side_effect=[process(reply) for reply in replies]):
            self.assertEqual(tts.translate_batch(["你好"], "en"), ["Hello"])
            with tempfile.TemporaryDirectory() as folder:
                output = Path(folder) / "keywords.txt"
                self.assertEqual(tts.generate_highlight_keywords_with_ai("你好世界", ["en"], output), ["Hello", "World"])
                self.assertEqual(output.read_text(encoding="utf-8"), "Hello\nWorld\n")

    def test_unavailable_translation_or_highlights_are_not_fake_results(self):
        with patch.object(tts, "_ai_call", return_value=None):
            with self.assertRaises(tts.TranslationError):
                tts.translate_batch(["你好"], "en")
            with self.assertRaises(tts.TranslationError):
                tts.generate_highlight_keywords_with_ai("你好", ["en"])

    def test_failed_ai_punctuation_preserves_local_fallback_and_paired_marks(self):
        source = ["《标题》。", "你好！"]
        with patch.object(tts, "_ai_call", return_value=None):
            result, report = tts.apply_subtitle_punctuation(source, mode="ai", fallback="trim-edge")
        self.assertEqual(result, ["《标题》", "你好"])
        self.assertTrue(report["fallback_used"])
        self.assertTrue(report["verified"])

    def test_ai_punctuation_cannot_remove_paired_marks(self):
        response = '{"items":[{"index":0,"text":"标题"},{"index":1,"text":"你好"}]}'
        with patch.object(tts, "_ai_call", return_value=response):
            result, _ = tts.apply_subtitle_punctuation(["《标题》。", "你好！"], mode="ai")
        self.assertEqual(result, ["《标题》。", "你好"])

    def test_basic_cli_text_file_voice_rate_volume_output_and_no_ai_controls(self):
        with tempfile.TemporaryDirectory() as folder:
            keywords = Path(folder) / "empty-keywords.txt"
            keywords.write_text("", encoding="utf-8")
            source = Path(folder) / "input.txt"
            source.write_text("测试语音", encoding="utf-8")
            output = str(Path(folder) / "speech.mp3")
            for input_args in (["测试语音"], ["-f", str(source)]):
                args = ["tts.py", *input_args, "-v", "zh-CN-YunxiNeural", "-r", "+20%",
                        "-V", "+50%", "-o", output, "--provider", "edge",
                        "--highlight-keyword-file", str(keywords), "--punctuation-mode", "keep"]
                with self.subTest(input_args=input_args), patch("sys.argv", args), \
                        patch.object(tts, "generate_speech", new_callable=AsyncMock, return_value=True) as speech, \
                        patch.object(tts, "get_audio_duration", return_value=1.0), \
                        patch.object(tts.os.path, "expanduser", return_value=folder), \
                        patch.object(tts, "_ai_call", side_effect=AssertionError("LLM must be disabled")):
                    tts.main()
                speech.assert_awaited_once_with(
                    "测试语音", output, "zh-CN-YunxiNeural", "+20%", "+50%", "edge", 3, 1.5)

    def test_edge_speech_backend_and_basic_voice_parameters_unchanged(self):
        with tempfile.TemporaryDirectory() as folder:
            output = str(Path(folder) / "speech.mp3")

            async def save(path):
                Path(path).write_bytes(b"mock edge speech")

            communicate = Mock(return_value=SimpleNamespace(save=save))
            with patch.object(tts, "edge_tts", SimpleNamespace(Communicate=communicate)), \
                    patch.object(tts, "_ai_call", side_effect=AssertionError("TTS must not invoke LLM")):
                success = asyncio.run(tts.generate_speech_once(
                    "语音", output, "zh-CN-YunxiNeural", "+20%", "+50%", provider="edge"))
            self.assertTrue(success)
            communicate.assert_called_once_with("语音", "zh-CN-YunxiNeural", rate="+20%", volume="+50%")


if __name__ == "__main__":
    unittest.main()
