# Telegram Skill

Telegram 聊天管理工具 - 获取聊天 ID 列表、批量导出聊天记录。

## 功能

1. **列出所有聊天** - 获取 Telegram 账户中所有对话的 ID 和名称
2. **导出聊天记录** - 批量导出指定聊天ID的完整记录（JSON格式）

## 前置要求

- Python 3.8+
- `telethon` 包: `pip install telethon`
- Telegram API 凭证 (api_id, api_hash) from https://my.telegram.org/apps/

## 使用方法

### 1. 列出所有聊天

```bash
python scripts/list-chats.py
```

或使用已配置的 session:

```bash
python scripts/list-chats.py --session session_name
```

输出示例:
```
1. ID: -1001943736638
   名称: 我的频道
   类型: Channel
2. ID: -1001844516320
   名称: 测试群组
   类型: Chat
...
```

### 2. 导出单个聊天

```bash
python scripts/export-chats.py -1001943736638
```

### 3. 批量导出多个聊天

```bash
python scripts/export-chats.py -1001943736638 -1001844516320 7973899019
```

### 4. 指定输出目录

```bash
python scripts/export-chats.py -1001943736638 --output /path/to/output
```

### 5. 列出所有可用命令

```bash
python scripts/export-chats.py --help
```

## 配置

### 方式一：命令行参数

```bash
python scripts/list-chats.py --api-id YOUR_API_ID --api-hash YOUR_API_HASH --phone "+447849125206"
```

### 方式二：config.json

在技能目录创建 `config.json`:

```json
{
  "api_id": "34723814",
  "api_hash": "aae73c3e664656ea0f19eb65c8022dd1",
  "phone": "+447849125206"
}
```

首次运行时会自动提示登录（需要验证码）。

## 聊天 ID 格式

- **频道/群组**: 负数，如 `-1001943736638`
- **私聊**: 正数，如 `7973899019`

## 输出格式

导出的 JSON 文件包含每条消息:
```json
{
  "id": 1,
  "date": "2024-01-01 12:00:00",
  "sender": 123456789,
  "text": "消息内容",
  "media": null
}
```

## 相关文件

- `scripts/list-chats.py` - 列出所有聊天
- `scripts/export-chats.py` - 导出聊天记录
- `config.json` - API 凭证配置