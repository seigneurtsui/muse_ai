#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""batch-image-merge 回归测试。

只在临时目录生成合成图片，不触碰用户数据。
运行：
    python3 -m unittest discover -s <skill>/tests -v
"""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

from PIL import Image

SCRIPTS_DIR = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))

import merge_images  # noqa: E402


def make_image(path: Path, size=(120, 80), color=(200, 30, 30), fmt=None, orientation=None):
    image = Image.new("RGB", size, color)
    save_kwargs = {}
    if fmt:
        save_kwargs["format"] = fmt
    if orientation is not None:
        exif = Image.Exif()
        exif[274] = orientation
        save_kwargs["exif"] = exif
    image.save(path, **save_kwargs)
    return path


class MergeImagesTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.input_dir = self.root / "fotos"
        self.input_dir.mkdir()
        self.output_root = self.root / "out"
        sizes = [(120, 80), (100, 140), (160, 60), (90, 90), (200, 100), (50, 50), (130, 130)]
        for index, size in enumerate(sizes, 1):
            # 每张用不同颜色，避免 GIF 因相邻帧完全相同而被合并。
            color = (20 * index, 255 - 20 * index, 100)
            make_image(self.input_dir / f"img_{index:02d}.png", size=size, color=color)

    def tearDown(self):
        self._tmp.cleanup()

    def run_tool(self, *extra):
        argv = [str(self.input_dir), "--output-root", str(self.output_root),
                "--output-subdir", "batch", "--no-manifest", *extra]
        return merge_images.main(argv)

    def out(self):
        return self.output_root / "batch"

    def test_dry_run(self):
        code = merge_images.main([
            str(self.input_dir), "--output-root", str(self.output_root),
            "--dry-run", "--no-manifest",
        ])
        self.assertEqual(code, 0)
        self.assertFalse(self.output_root.exists())

    def test_vertical_and_horizontal(self):
        self.assertEqual(self.run_tool("--mode", "vertical", "--gap", "5"), 0)
        v = Image.open(self.out() / "vertical_merged.jpg")
        self.assertEqual(v.width, 200)  # 统一到最大宽度
        self.assertGreater(v.height, 140)  # 多张纵向叠加后高于单张
        self.assertEqual(self.run_tool("--mode", "horizontal"), 0)
        h = Image.open(self.out() / "horizontal_merged.jpg")
        self.assertEqual(h.height, 140)  # 统一到最大高度
        self.assertGreater(h.width, 200)  # 多张横向拼接后宽于单张

    def test_grid_with_pagination(self):
        self.assertEqual(self.run_tool("--mode", "grid", "--grid", "3x2"), 0)
        page1 = Image.open(self.out() / "grid_3x2_p01.jpg")
        page2 = Image.open(self.out() / "grid_3x2_p02.jpg")
        cell_w, cell_h = 200, 140
        self.assertEqual((page1.width, page1.height), (3 * cell_w, 2 * cell_h))
        self.assertEqual((page2.width, page2.height), (3 * cell_w, 2 * cell_h))

    def test_grid_single_page_no_suffix(self):
        self.assertEqual(self.run_tool("--mode", "grid", "--grid", "4x2"), 0)
        self.assertTrue((self.out() / "grid_4x2.jpg").exists())

    def test_gif_frame_count(self):
        self.assertEqual(self.run_tool("--mode", "gif", "--gif-width", "64"), 0)
        gif = Image.open(self.out() / "images.gif")
        frames = 0
        try:
            while True:
                frames += 1
                gif.seek(gif.tell() + 1)
        except EOFError:
            pass
        self.assertEqual(frames, 7)

    def test_pdf_pages(self):
        self.assertEqual(self.run_tool("--mode", "pdf"), 0)
        self.assertTrue((self.out() / "album.pdf").exists())
        self.assertGreater((self.out() / "album.pdf").stat().st_size, 0)

    def test_dedup(self):
        make_image(self.input_dir / "copy_of_img_01.png", size=(120, 80), color=(200, 30, 30))
        self.assertEqual(
            self.run_tool("--mode", "vertical", "--dedup", "--limit", "1"),
            0,
        )

    def test_exif_orientation_dimensions(self):
        # 竖拍旋转图（orientation=6）方向校正后宽高应为 (80, 120)。
        make_image(self.input_dir / "rot.png", size=(120, 80), orientation=6)
        self.assertEqual(merge_images.image_size(self.input_dir / "rot.png"), (80, 120))

    def test_parallel_matches_serial(self):
        self.assertEqual(self.run_tool("--mode", "vertical", "--workers", "4"), 0)
        p = self.out() / "vertical_merged.jpg"
        serial_out = self.output_root / "serial"
        self.assertEqual(
            merge_images.main([str(self.input_dir), "--output-root", str(self.output_root),
                               "--output-subdir", "serial", "--mode", "vertical", "--workers", "1"]),
            0,
        )
        self.assertEqual(Image.open(p).size, Image.open(serial_out / "vertical_merged.jpg").size)

    def test_manifest_written(self):
        self.assertEqual(
            merge_images.main([str(self.input_dir), "--output-root", str(self.output_root),
                               "--output-subdir", "m", "--mode", "vertical"]),
            0,
        )
        manifest = self.output_root / "m" / "manifest.json"
        self.assertTrue(manifest.exists())
        self.assertIn("outputs", manifest.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
