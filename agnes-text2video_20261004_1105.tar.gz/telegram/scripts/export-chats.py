#!/usr/bin/env python3
"""
Telegram Chat Exporter - 批量导出聊天记录
"""

import argparse
import asyncio
import json
import os
import sys
from datetime import datetime
from telethon import TelegramClient

DEFAULT_CONFIG_PATH = os.path.join(os.path.join(os.path.dirname(__file__), '..'), 'config.json')
DEFAULT_OUTPUT_DIR = os.path.expanduser('~/Downloads')

def load_config(config_path=DEFAULT_CONFIG_PATH):
    """加载配置文件"""
    if os.path.exists(config_path):
        with open(config_path, 'r') as f:
            return json.load(f)
    return {}

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='导出Telegram聊天记录')
    parser.add_argument('chat_ids', nargs='*', type=int, help='聊天ID列表')
    parser.add_argument('--api-id', help='Telegram API ID')
    parser.add_argument('--api-hash', help='Telegram API Hash')
    parser.add_argument('--phone', help='手机号')
    parser.add_argument('--session', default='telegram_session', help='Session名称')
    parser.add_argument('--config', default=DEFAULT_CONFIG_PATH, help='配置文件路径')
    parser.add_argument('--output', '-o', default=DEFAULT_OUTPUT_DIR, help='输出目录')
    parser.add_argument('--list', '-l', action='store_true', help='列出所有聊天')
    parser.add_argument('--limit', type=int, help='限制每条聊天导出的消息数')
    parser.add_argument('--json', action='store_true', help='JSON格式输出')
    return parser.parse_args()

async def export_single_chat(client, chat_id, output_dir, limit=None):
    """导出单个聊天"""
    try:
        os.makedirs(output_dir, exist_ok=True)

        print(f"\n{'='*60}")
        print(f"开始导出聊天ID: {chat_id}")
        print(f"{'='*60}")

        # 获取聊天实体
        try:
            entity = await client.get_entity(chat_id)
            chat_name = getattr(entity, 'title', None) or getattr(entity, 'username', None) or str(chat_id)
            print(f"✓ 聊天名称: {chat_name}")
        except Exception as e:
            print(f"⚠️  无法获取聊天信息: {e}")
            chat_name = str(chat_id)

        # 获取消息
        messages = []
        count = 0

        print(f"正在获取消息...")

        async for message in client.iter_messages(chat_id, limit=limit):
            messages.append({
                'id': message.id,
                'date': str(message.date),
                'sender_id': message.sender_id,
                'text': message.text,
                'media': str(message.media) if message.media else None
            })
            count += 1
            if count % 1000 == 0:
                print(f"  已获取 {count} 条消息...")

        # 生成文件名
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_name = "".join(c if c.isalnum() or c in (' ', '_', '-') else '_' for c in str(chat_name))
        filename = f"{safe_name}_{chat_id}_{timestamp}.json"
        filepath = os.path.join(output_dir, filename)

        # 保存JSON
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(messages, f, ensure_ascii=False, indent=2)

        print(f"✓ 导出成功: {len(messages)} 条消息")
        print(f"✓ 保存位置: {filepath}")

        return {
            'chat_id': chat_id,
            'chat_name': chat_name,
            'message_count': len(messages),
            'filepath': filepath,
            'status': 'success'
        }

    except Exception as e:
        print(f"❌ 导出失败: {e}")
        return {
            'chat_id': chat_id,
            'status': 'failed',
            'error': str(e)
        }

async def list_chats(client, json_output=False):
    """列出所有聊天"""
    dialogs = await client.get_dialogs()
    
    if json_output:
        chats = []
        for dialog in dialogs:
            chats.append({
                'id': dialog.id,
                'name': dialog.name,
                'type': dialog.entity.__class__.__name__
            })
        print(json.dumps(chats, ensure_ascii=False, indent=2))
    else:
        print(f"\n{'='*60}")
        print(f"您的所有对话 (共 {len(dialogs)} 个)")
        print(f"{'='*60}\n")
        
        for idx, dialog in enumerate(dialogs, 1):
            chat_type = dialog.entity.__class__.__name__
            print(f"{idx}. ID: {dialog.id}")
            print(f"   名称: {dialog.name}")
            print(f"   类型: {chat_type}")
            print(f"   {'-'*50}")
        
        print(f"\n共 {len(dialogs)} 个对话")

async def export_multiple_chats(client, chat_ids, output_dir, limit=None):
    """批量导出多个聊天"""
    results = []

    print(f"\n{'='*60}")
    print(f"准备导出 {len(chat_ids)} 个聊天记录")
    print(f"输出目录: {output_dir}")
    print(f"{'='*60}")

    for idx, chat_id in enumerate(chat_ids, 1):
        print(f"\n[{idx}/{len(chat_ids)}] 处理中...")
        result = await export_single_chat(client, chat_id, output_dir, limit)
        results.append(result)

    # 汇总报告
    print(f"\n{'='*60}")
    print(f"导出完成汇总")
    print(f"{'='*60}")

    success_count = sum(1 for r in results if r['status'] == 'success')
    failed_count = len(results) - success_count

    print(f"总计: {len(results)} 个聊天")
    print(f"成功: {success_count}")
    print(f"失败: {failed_count}")

    if success_count > 0:
        print(f"\n成功导出的聊天:")
        for r in results:
            if r['status'] == 'success':
                print(f"  ✓ {r['chat_name']} ({r['chat_id']})")
                print(f"    消息数: {r['message_count']}")
                print(f"    文件: {r['filepath']}")

    if failed_count > 0:
        print(f"\n失败的聊天:")
        for r in results:
            if r['status'] == 'failed':
                print(f"  ✗ {r['chat_id']}")
                print(f"    错误: {r['error']}")

    return results

async def main():
    args = parse_args()
    
    if '--help' in sys.argv or '-h' in sys.argv:
        print("""
Telegram 聊天导出工具 - 使用说明
========================================== 

1. 列出所有聊天:
   python scripts/export-chats.py --list
   或
   python scripts/export-chats.py -l

2. 导出单个聊天:
   python scripts/export-chats.py -1001943736638

3. 批量导出多个聊天:
   python scripts/export-chats.py -1001943736638 -1001844516320 7973899019

4. 指定输出目录:
   python scripts/export-chats.py -1001943736638 --output exports
   或
   python scripts/export-chats.py -1001943736638 -o exports

5. 限制消息数量:
   python scripts/export-chats.py -1001943736638 --limit 1000

6. JSON格式输出:
   python scripts/export-chats.py -l --json

说明:
- 聊天ID格式:
  * 频道/群组: 负数，如 -1001943736638
  * 私聊: 正数，如 7973899019
- 首次运行需要输入验证码
- 导出的文件保存为JSON格式
- 默认输出目录为 'exports'
        """)
        return
    
    # 加载配置
    config = {}
    if os.path.exists(args.config):
        config = load_config(args.config)
    
    # 命令���参��优先
    api_id = args.api_id or config.get('api_id')
    api_hash = args.api_hash or config.get('api_hash')
    phone = args.phone or config.get('phone')
    
    if not api_id or not api_hash:
        print("错误: 请提供 API ID 和 API Hash")
        print("方式一: 通过 --api-id 和 --api-hash 参数")
        print("方式二: 创建 config.json 配置文件")
        sys.exit(1)
    
    client = TelegramClient(args.session, int(api_id), api_hash)
    
    async with client:
        if phone:
            await client.start(phone)
        else:
            await client.start()
        
        # 列出所有聊天
        if args.list:
            await list_chats(client, json_output=args.json)
            return
        
        # 导出聊天
        if not args.chat_ids:
            print("错误: 请提供聊天ID")
            print("使用 --list 查看所有聊天")
            print("使用 --help 查看帮助")
            sys.exit(1)
        
        await export_multiple_chats(client, args.chat_ids, args.output, args.limit)

if __name__ == "__main__":
    asyncio.run(main())