#!/usr/bin/env python3
"""Original local-table -> AI errata workflow, adapted for current OmniRush session.

Exit 10 means current-session AI responses are pending, not correction success.
No provider URLs, API keys, HTTP clients, TLS bypass, or child model processes.
"""

from __future__ import annotations
import argparse
import bisect
from datetime import datetime, timezone
import os
from pathlib import Path
import re
import sys
import time
import uuid

from file_support import (
    ErratumError,
    reason,
    sha,
    packed,
    loads,
    read_regular,
    read_json,
    write_json,
    atomic_write,
    mkdir,
    root_path,
    linklike,
    collect,
    key,
    Document,
    snapshot_bom,
    decode,
    encode,
    ENCODINGS,
    MAX_FILE,
    MAX_BATCH,
    MAX_FILES,
)
from document_core import (
    HomophoneCorrector,
    TextSegment,
    extract_segments,
    apply_segments,
    contains_chinese,
    validate_replacement,
    extract_ai_error_terms,
)
from current_session_ai import (
    AICorrector,
    AIRequestPending,
    AIResponseInvalid,
    PROVIDER,
    GUARD,
    PROTOCOL_VERSION,
    request_identity,
    validate_response,
)

WORKFLOW_VERSION = 1
DEFAULT_DICTIONARY = (
    Path(__file__).resolve().parent.parent / "assets/chinese_homophone_errors.json"
)


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _extract_ai_error_terms(before, after):
    try:
        return extract_ai_error_terms(before, after)
    except Exception as error:
        if getattr(error, "code", None) != "diff_too_large":
            raise
    # Preserve long-line processing without quadratic diff work. Report the
    # bounded changed envelope honestly, not invented word-level opcodes.
    start = 0
    limit = min(len(before), len(after))
    while start < limit and before[start] == after[start]:
        start += 1
    end_before = len(before)
    end_after = len(after)
    while (
        end_before > start
        and end_after > start
        and before[end_before - 1] == after[end_after - 1]
    ):
        end_before -= 1
        end_after -= 1
    old = before[start:end_before]
    new = after[start:end_after]
    return [
        {
            "before": old,
            "after": new,
            "type": "replace" if old and new else "delete" if old else "insert",
            "before_start": start,
            "before_end": end_before,
            "after_start": start,
            "after_end": end_after,
            "detail": "bounded_changed_span_not_full_diff",
        }
    ]


def relative_path(text):
    p = Path(text)
    if (
        not isinstance(text, str)
        or p.is_absolute()
        or ".." in p.parts
        or not p.parts
        or "\\" in text
        or "\0" in text
    ):
        raise ErratumError("invalid_relative_output")
    return p


def work_document(path, root, corrector, args):
    raw = read_regular(path, MAX_FILE, root)
    document = decode(raw, args.encoding)
    segments = extract_segments(document.text, path.suffix.lower())
    if len(segments) > 100000:
        raise ErratumError("document_segment_limit")
    starts = [0] + [m.end() for m in re.finditer(r"\r\n|\r|\n", document.text)]
    local = []
    changes = []
    rule_hits = {}
    for i, segment in enumerate(segments):
        corrected, hits, rules = corrector.correct_with_details(segment.text)
        validate_replacement(segment.text, corrected)
        line = bisect.bisect_right(starts, segment.start)
        local.append(corrected)
        for wrong, right, count in rules:
            item = rule_hits.setdefault(
                wrong + " => " + right,
                {"wrong": wrong, "right": right, "count": 0, "locations": []},
            )
            item["count"] += count
            item["locations"].append(line)
        if corrected != segment.text:
            changes.append(
                {
                    "segment": i,
                    "line": line,
                    "stage": "local",
                    "before": segment.text,
                    "after": corrected,
                    "provider": "local-json",
                    "error_terms": _extract_ai_error_terms(segment.text, corrected),
                }
            )
    # apply_segments is the authoritative framing validation for both stages.
    preliminary = apply_segments(document.text, segments, local)
    encoded = encode(preliminary, document, args.output_encoding)
    work = {
        "version": WORKFLOW_VERSION,
        "source": str(path),
        "source_sha256": sha(raw),
        "source_bytes": len(raw),
        "relative": path.relative_to(root).as_posix(),
        "text": document.text,
        "encoding": document.encoding,
        "bom": document.bom.hex(),
        "segments": [
            {
                "start": s.start,
                "end": s.end,
                "text": s.text,
                "line": bisect.bisect_right(starts, s.start),
            }
            for s in segments
        ],
        "local_texts": local,
        "local_rule_hits": rule_hits,
        "local_changes": changes,
        "local_sha256": sha(encoded),
    }
    candidates = {
        wrong: choices
        for wrong, choices in corrector.script_sensitive.items()
        if any(wrong in text for text in local)
    }
    if candidates:
        # Optional to keep old snapshots and their existing request IDs valid.
        work["script_sensitive_candidates"] = candidates
    return work, encoded


def batch_units(work, max_chars):
    """Bound long lines without dropping text; preserve ordered local replacement first."""
    cap = max(32, max_chars // 2)
    units = []
    mapping = []
    local = work["local_texts"]
    raw_segments = work["segments"]
    for segment_id, text in enumerate(local):
        pos = 0
        while pos < len(text):
            end = min(len(text), pos + cap)
            if end < len(text):
                split = max(
                    text.rfind(mark, pos + cap // 2, end) for mark in "。！？；， \t"
                )
                if split >= 0:
                    end = split + 1
            fragment = text[pos:end]
            if contains_chinese(fragment):
                original = raw_segments[segment_id]["text"]
                # Whole original span is supplied when bounded; never label a
                # guessed offset in the original as an exact aligned source.
                original = original if len(original) <= max_chars else None
                rules = [
                    {"before": c["wrong"], "after": c["right"]}
                    for c in work["local_rule_hits"].values()
                    if c["right"] and c["right"] in fragment
                ][:24]
                unit = {
                    "id": len(units),
                    "text": fragment,
                    "original": original,
                    "context": {
                        "before": text[max(0, pos - 100) : pos]
                        or (local[segment_id - 1][-100:] if segment_id else ""),
                        "after": text[end : end + 100]
                        or (
                            local[segment_id + 1][:100]
                            if segment_id + 1 < len(local)
                            else ""
                        ),
                        "local_substitutions": rules,
                    },
                }
                candidates = [
                    {"before": wrong, **choices}
                    for wrong, choices in work.get(
                        "script_sensitive_candidates", {}
                    ).items()
                    if wrong in fragment
                ][:12]
                if candidates:
                    unit["context"]["script_sensitive_candidates"] = candidates
                units.append(unit)
                mapping.append((segment_id, pos, end))
                if len(units) > 30000:
                    raise ErratumError("document_ai_fragment_limit")
            pos = end
    groups = []
    group = []
    size = 0
    for unit in units:
        cost = len(packed(unit).decode("utf-8"))
        if group and size + cost > max_chars:
            groups.append(group)
            group = []
            size = 0
        group.append(unit)
        size += cost
    if group:
        groups.append(group)
    return groups, mapping


def start(args):
    output = root_path(args.output_root)
    files, input_root, excluded = collect(args.input, output, not args.no_recursive)
    if not files:
        return {"status": "no_supported_files", "total": 0, "excluded": excluded}, 1
    dictionary = Path(args.homophone_json).expanduser().absolute()
    dictionary_raw = read_regular(dictionary, 2 * 1024 * 1024)
    corrector = HomophoneCorrector(dictionary)
    if read_regular(dictionary, 2 * 1024 * 1024) != dictionary_raw:
        raise ErratumError("dictionary_changed_during_preflight")
    total = 0
    prepared = []
    outputs = set()
    # Full local preflight before creating a run directory or request files.
    for path in files:
        if total + path.stat().st_size > MAX_BATCH:
            raise ErratumError("batch_over_64_mib")
        work, local_raw = work_document(path, input_root, corrector, args)
        total += work["source_bytes"]
        if total > MAX_BATCH:
            raise ErratumError("batch_over_64_mib")
        rel = Path(work["relative"])
        destination = rel.with_name(rel.stem + "_corrected" + rel.suffix)
        portable = key(output / destination)
        if portable in outputs:
            raise ErratumError("portable_output_name_collision")
        outputs.add(portable)
        prepared.append((work, local_raw, destination.as_posix()))
    if args.dry_run:
        return {
            "status": "dry_run",
            "total": len(prepared),
            "source_bytes": total,
            "excluded": excluded,
            "ai": "not_called",
            "documents": [
                {
                    "source": w["source"],
                    "relative_output": dest,
                    "local_changed_segments": len(w["local_changes"]),
                    "ai_required": not args.no_ai
                    and any(contains_chinese(t) for t in w["local_texts"]),
                }
                for w, _, dest in prepared
            ],
        }, 0
    mkdir(output, output)
    job = output / (
        datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:10]
    )
    job.mkdir(mode=0o700)
    for name in (
        ".work/docs",
        ".work/completed",
        ".work/intents",
        ".work/ai",
        ".work/progress",
        ".work/accepted",
        "local",
        "files",
    ):
        mkdir(job, job / name)
    options = {
        "use_ai": not args.no_ai,
        "ai_batch_chars": args.ai_batch_chars,
        "encoding": args.encoding,
        "output_encoding": args.output_encoding,
        "recursive": not args.no_recursive,
    }
    if args.learn:
        options["learn"] = True
        options["learning_store"] = str(
            (
                args.learning_store
                or (Path.home() / ".local/state/omnirush/erratum-correction/learning")
            )
            .expanduser()
            .absolute()
        )
    manifest = {
        "kind": "omnirush-erratum-job",
        "version": WORKFLOW_VERSION,
        "created_at": now(),
        "input_root": str(input_root),
        "options": options,
        "dictionary_sha256": sha(dictionary_raw),
        "excluded": excluded,
        "documents": [],
    }
    atomic_write(job / ".work/dictionary.json", dictionary_raw)
    for index, (work, local_raw, destination) in enumerate(prepared):
        identity = f"{index:06d}"
        work_raw = packed(work) + b"\n"
        atomic_write(job / ".work/docs" / f"{identity}.json", work_raw)
        local_path = job / "local" / destination
        mkdir(job, local_path.parent)
        atomic_write(local_path, local_raw)
        manifest["documents"].append(
            {
                "id": identity,
                "source": work["source"],
                "source_sha256": work["source_sha256"],
                "work_sha256": sha(work_raw),
                "output": destination,
            }
        )
    manifest["plan_id"] = sha(packed(manifest))
    write_json(job / "manifest.json", manifest)
    try:
        result, code = resume(job, args.request_window)
    except Exception as error:
        result = {
            "status": "error",
            "reason": reason(error),
            "job_dir": str(job),
            "partial_state_preserved": True,
        }
        code = 2
    result["compatibility_warnings"] = (
        [
            "--retries is not an HTTP retry setting; invalid current-session responses must be corrected explicitly."
        ]
        if args.retries is not None
        else []
    )
    return result, code


def load_job(job):
    job = Path(job).expanduser().absolute()
    if not job.is_dir() or linklike(job):
        raise ErratumError("resume_job_missing_or_link")
    job = job.resolve()
    manifest = read_json(job / "manifest.json", 4 * 1024 * 1024, job)
    if (
        not isinstance(manifest, dict)
        or manifest.get("kind") != "omnirush-erratum-job"
        or manifest.get("version") != WORKFLOW_VERSION
    ):
        raise ErratumError("unsupported_job_manifest")
    copy = dict(manifest)
    plan = copy.pop("plan_id", None)
    if sha(packed(copy)) != plan:
        raise ErratumError("manifest_changed")
    docs = manifest.get("documents")
    if not isinstance(docs, list) or not 0 < len(docs) <= MAX_FILES:
        raise ErratumError("invalid_manifest_documents")
    root = Path(manifest["input_root"])
    if not root.is_absolute() or not root.is_dir() or linklike(root):
        raise ErratumError("input_root_changed")
    total = 0
    works = []
    for index, item in enumerate(docs):
        if item["id"] != f"{index:06d}":
            raise ErratumError("invalid_document_identity")
        relative_path(item["output"])
        raw = read_regular(job / ".work/docs" / f"{item['id']}.json", MAX_FILE * 8, job)
        if sha(raw) != item["work_sha256"]:
            raise ErratumError("document_snapshot_changed")
        work = loads(raw)
        if (
            work["source"] != item["source"]
            or work["source_sha256"] != item["source_sha256"]
        ):
            raise ErratumError("snapshot_source_mismatch")
        source = Path(item["source"])
        source_raw = read_regular(source, MAX_FILE, root)
        total += len(source_raw)
        if total > MAX_BATCH:
            raise ErratumError("batch_over_64_mib")
        if sha(source_raw) != item["source_sha256"]:
            raise ErratumError("source_changed_start_new_job")
        works.append(work)
    if (
        sha(read_regular(job / ".work/dictionary.json", 2 * 1024 * 1024, job))
        != manifest["dictionary_sha256"]
    ):
        raise ErratumError("dictionary_snapshot_changed")
    return job, manifest, works


def process_document(job, item, work, options, ai, window=4):
    final_path = job / "files" / relative_path(item["output"])
    receipt_path = job / ".work/completed" / f"{item['id']}.json"
    if receipt_path.exists():
        receipt = read_json(receipt_path, MAX_FILE * 8, job)
        if receipt.get("work_sha256") != item["work_sha256"] or sha(
            read_regular(final_path, MAX_FILE * 4, job)
        ) != receipt.get("output_sha256"):
            raise ErratumError("completed_output_changed")
        return receipt, []
    row = {
        "source": item["source"],
        "source_sha256": item["source_sha256"],
        "work_sha256": item["work_sha256"],
        "local_output": str(job / "local" / item["output"]),
        "local_rule_hits": work["local_rule_hits"],
        "local_changed_lines": len(work["local_changes"]),
        "local_replacement_count": sum(
            r["count"] for r in work["local_rule_hits"].values()
        ),
        "ai_checked_lines": 0,
        "ai_changed_lines": 0,
        "provider_usage": {},
        "script_sensitive_candidate_types": len(
            work.get("script_sensitive_candidates", {})
        ),
        "local_only_script_sensitive_unresolved": bool(
            not options["use_ai"] and work.get("script_sensitive_candidates")
        ),
        "changes": list(work["local_changes"]),
    }
    local = work["local_texts"]
    final = list(local)
    pending = []
    accepted = {}
    mapping = []
    if options["use_ai"]:
        groups, mapping = batch_units(work, options["ai_batch_chars"])
        accepted_dir = job / ".work/accepted" / item["id"]
        mkdir(job, accepted_dir)
        progress_path = job / ".work/progress" / f"{item['id']}.json"
        signature = sha(
            packed(
                [
                    item["work_sha256"],
                    options["ai_batch_chars"],
                    PROTOCOL_VERSION,
                    GUARD,
                ]
            )
        )
        progress = (
            read_json(progress_path, 4096, job)
            if progress_path.exists()
            else {"signature": signature, "next_group": 0, "checked_fragments": 0}
        )
        if (
            progress.get("signature") != signature
            or type(progress.get("next_group")) is not int
            or not 0 <= progress["next_group"] <= len(groups)
        ):
            raise ErratumError("ai_progress_changed")
        # Commit validated groups once. Later resumes skip their model requests
        # and response parsing; final assembly revalidates committed answers.
        for number in range(progress["next_group"], len(groups)):
            group = groups[number]
            payload = {"document_sha256": item["work_sha256"], "items": group}
            path = accepted_dir / f"{number:06d}.json"
            try:
                if path.exists():
                    data = read_json(path, 1024 * 1024, job)
                    validate_response(data, request_identity(payload), group)
                else:
                    response, provider = ai.correct(payload)
                    data = {
                        "request_id": request_identity(payload),
                        "corrections": [
                            {"id": u["id"], "text": response[u["id"]]} for u in group
                        ],
                    }
                    write_json(path, data)
                # Only advance a contiguous prefix. Out-of-order responses stay
                # available and will be adopted once earlier requests are ready.
                if number == progress["next_group"]:
                    progress["next_group"] += 1
                    progress["checked_fragments"] += len(group)
                    write_json(progress_path, progress, replace=True)
            except AIRequestPending as error:
                if row.get("status") != "invalid_ai_response":
                    row["status"] = "awaiting_ai"
                pending.append(error.request)
            except AIResponseInvalid as error:
                row.update(status="invalid_ai_response", reason=error.code)
                pending.append(error.request)
            if len(pending) >= window:
                break
        row["ai_checked_fragments"] = progress["checked_fragments"]
        if pending:
            return row, pending
        if progress["next_group"] != len(groups):
            raise ErratumError("ai_progress_incomplete")
        for number, group in enumerate(groups):
            payload = {"document_sha256": item["work_sha256"], "items": group}
            accepted.update(
                validate_response(
                    read_json(accepted_dir / f"{number:06d}.json", 1024 * 1024, job),
                    request_identity(payload),
                    group,
                )
            )
        if groups:
            row["provider_usage"][PROVIDER] = len(groups)
        replacements = {}
        checked = set()
        for index, text in accepted.items():
            segment, start, end = mapping[index]
            replacements.setdefault(segment, []).append((start, end, text))
            checked.add(segment)
        for segment, edits in replacements.items():
            position = 0
            pieces = []
            for start, end, text in sorted(edits):
                pieces.extend((local[segment][position:start], text))
                position = end
            pieces.append(local[segment][position:])
            final[segment] = "".join(pieces)
        row["ai_checked_lines"] = len(checked)
        for segment, (before, after) in enumerate(zip(local, final)):
            if before != after:
                row["changes"].append(
                    {
                        "segment": segment,
                        "line": work["segments"][segment]["line"],
                        "stage": "ai",
                        "provider": PROVIDER,
                        "before": before,
                        "after": after,
                        "error_terms": _extract_ai_error_terms(before, after),
                    }
                )
                row["ai_changed_lines"] += 1
    segments = [TextSegment(s["start"], s["end"], s["text"]) for s in work["segments"]]
    result = apply_segments(work["text"], segments, final)
    document = Document(work["text"], work["encoding"], snapshot_bom(work["bom"]))
    raw = encode(result, document, options["output_encoding"])
    # Recheck immediately before publishing; no input is ever opened for writing.
    if sha(read_regular(Path(item["source"]), MAX_FILE)) != item["source_sha256"]:
        raise ErratumError("source_changed_before_output")
    mkdir(job, final_path.parent)
    intent_path = job / ".work/intents" / f"{item['id']}.json"
    intent = {
        "work_sha256": item["work_sha256"],
        "output_sha256": sha(raw),
        "output": item["output"],
    }
    if intent_path.exists():
        if read_json(intent_path, 4096, job) != intent:
            raise ErratumError("output_intent_changed")
    else:
        if final_path.exists() or final_path.is_symlink():
            raise ErratumError("unowned_output_exists")
        write_json(intent_path, intent)
    if final_path.exists() or final_path.is_symlink():
        if sha(read_regular(final_path, MAX_FILE * 4, job)) != sha(raw):
            raise ErratumError("existing_output_does_not_match_intent")
    else:
        atomic_write(final_path, raw)
    row.update(
        status=(
            "corrected"
            if options["use_ai"] and mapping
            else "no_ai_needed" if options["use_ai"] else "local_only"
        ),
        output=str(final_path),
        output_sha256=sha(raw),
        output_bytes=len(raw),
        completed_at=now(),
        ai={
            "provider": PROVIDER if mapping else None,
            "model": (
                "invoking-session (not independently attested)" if mapping else None
            ),
        },
    )
    write_json(receipt_path, row)
    return row, []


def write_correction_reports(job, report):
    lines = [
        "中文文字勘误前后对照报告",
        "=" * 60,
        "状态：" + report["status"],
        "AI 检查计数按可编辑片段统计；带样式的一行可能有多个片段。",
        "local/ 是词表初步结果，不表示 AI 已完成；本地规则可能误改正确用词。",
        "本地修改片段数：" + str(report["summary"]["local_changed_lines"]),
        "本地替换总数：" + str(report["summary"]["local_replacement_count"]),
        "已完成 AI 检查的正文片段数：" + str(report["summary"]["ai_checked_lines"]),
        "AI 修改片段数：" + str(report["summary"]["ai_changed_lines"]),
        "",
    ]
    for row in report["documents"]:
        lines.extend(["原文件：" + row["source"], "状态：" + row["status"]])
        if row.get("script_sensitive_candidate_types"):
            lines.append(
                "简繁目标需判别的候选词条数："
                + str(row["script_sensitive_candidate_types"])
            )
        if row.get("local_only_script_sensitive_unresolved"):
            lines.append("仅本地模式：未猜测上述候选的简繁目标，相关原文保持不变。")
        for change in row.get("changes", []):
            lines.append(f"阶段：{change['stage']} | 原文物理行：{change['line']}")
            for diff in change["error_terms"]:
                lines.append(
                    f"  {diff['before'] or '[新增]'} => {diff['after'] or '[删除]'} | 字符位置 {diff['before_start']}:{diff['before_end']}"
                    + (
                        " | 长文本：合并变更范围，非完整逐词差异"
                        if diff.get("detail")
                        else ""
                    )
                )
            lines.extend(
                ["修改前：" + change["before"], "修改后：" + change["after"], ""]
            )
    # Reports may be refreshed, but never replace symlinks/hardlinks/user documents.
    atomic_write(
        job / "correction_report.txt", ("\n".join(lines) + "\n").encode(), replace=True
    )
    write_json(job / "correction_report.json", report, replace=True)


def resume(path, window=4):
    job = Path(path).expanduser().absolute()
    if not job.is_dir() or linklike(job):
        raise ErratumError("resume_job_missing_or_link")
    job = job.resolve()
    lock = job / ".lock"
    try:
        lock.mkdir(mode=0o700)
    except FileExistsError:
        raise ErratumError("job_locked_review_before_removing_lock") from None
    try:
        write_json(lock / "owner.json", {"pid": os.getpid(), "created_at": now()})
        job, manifest, works = load_job(job)
        options = manifest["options"]
        ai = AICorrector(job) if options["use_ai"] else None
        report = {
            "status": "complete",
            "job_dir": str(job),
            "created_at": manifest["created_at"],
            "updated_at": now(),
            "plan_id": manifest["plan_id"],
            "use_ai": options["use_ai"],
            "documents": [],
            "pending_requests": [],
            "excluded": manifest["excluded"],
            "total": len(works),
        }
        for item, work in zip(manifest["documents"], works):
            if len(report["pending_requests"]) >= window:
                report["documents"].append(
                    {
                        "source": item["source"],
                        "status": "deferred",
                        "local_output": str(job / "local" / item["output"]),
                        "local_rule_hits": work["local_rule_hits"],
                        "local_changed_lines": len(work["local_changes"]),
                        "local_replacement_count": sum(
                            r["count"] for r in work["local_rule_hits"].values()
                        ),
                        "changes": work["local_changes"],
                        "ai_checked_lines": 0,
                        "ai_changed_lines": 0,
                    }
                )
                continue
            try:
                row, requests = process_document(
                    job,
                    item,
                    work,
                    options,
                    ai,
                    window - len(report["pending_requests"]),
                )
            except Exception as error:
                row = {
                    "source": item["source"],
                    "status": "failed",
                    "reason": reason(error),
                }
                requests = []
            report["documents"].append(row)
            report["pending_requests"].extend(requests)
        report["document_count"] = len(report["documents"])
        report["summary"] = {
            field: sum(r.get(field, 0) for r in report["documents"])
            for field in (
                "local_changed_lines",
                "local_replacement_count",
                "ai_checked_lines",
                "ai_changed_lines",
            )
        }
        report["summary"]["total_changed_lines"] = (
            report["summary"]["local_changed_lines"]
            + report["summary"]["ai_changed_lines"]
        )
        report["completed"] = sum(
            r["status"] in ("corrected", "no_ai_needed", "local_only")
            for r in report["documents"]
        )
        report["failed"] = sum(r["status"] == "failed" for r in report["documents"])
        invalid = any(r["status"] == "invalid_ai_response" for r in report["documents"])
        if report["failed"] or invalid:
            report["status"] = "incomplete"
            code = 1
        elif report["pending_requests"]:
            report["status"] = "awaiting_ai"
            code = 10
        else:
            code = 0
        report["report_path"] = str(job / "correction_report.json")
        try:
            write_correction_reports(job, report)
        except Exception as error:
            report.pop("report_path", None)
            report.update(status="report_error", reason=reason(error))
            code = 2
        # Only counts/paths go to stdout. Full before/after text is in private reports.
        return {k: v for k, v in report.items() if k != "documents"} | {
            "documents": [
                {
                    k: v
                    for k, v in row.items()
                    if k not in ("changes", "local_rule_hits")
                }
                for row in report["documents"]
            ]
        }, code
    finally:
        (lock / "owner.json").unlink(missing_ok=True)
        lock.rmdir()


def collect_requested_experience(result, code, args):
    """Separate optional learning from document completion; never publish here."""
    if getattr(args, "no_learn", False):
        result["learning"] = {
            "status": "disabled_for_this_invocation",
            "dictionary_changed": False,
        }
        return result, code
    job = result.get("job_dir")
    try:
        saved = (
            read_json(Path(job) / "manifest.json", 4 * 1024 * 1024, Path(job)).get(
                "options", {}
            )
            if job
            else {}
        )
    except Exception as error:
        # Even post-processing state errors must retain completed correction facts.
        result["learning"] = {
            "status": "error",
            "reason": reason(error),
            "dictionary_changed": False,
        }
        result["correction_exit_code"] = code
        return result, code if code else 1
    enabled = args.learn or saved.get("learn", False)
    if not enabled:
        return result, code
    if code != 0 or not job or result.get("status") != "complete":
        result["learning"] = {
            "status": "deferred_until_complete",
            "dictionary_changed": False,
        }
        return result, code
    if not result.get("use_ai"):
        result["learning"] = {
            "status": "not_applicable",
            "reason": "local_only_not_ai_evidence",
            "dictionary_changed": False,
        }
        return result, code
    from learning_store import collect_job, DEFAULT_STORE

    store = args.learning_store or saved.get("learning_store") or DEFAULT_STORE
    try:
        result["learning"] = collect_job(job, store)
    except Exception as error:
        result["learning"] = {
            "status": "error",
            "reason": reason(error),
            "dictionary_changed": False,
        }
        result["correction_exit_code"] = code
        code = 1
    return result, code


def build_arg_parser():
    p = argparse.ArgumentParser(
        description="批量中文勘误：原词表顺序替换 + 当前 OmniRush 会话模型；无外部 API。"
    )
    choice = p.add_mutually_exclusive_group(required=True)
    choice.add_argument("-i", "--input", type=Path, help="指定单文件或目录；默认递归")
    choice.add_argument(
        "--resume", type=Path, help="继续已有批次，不重建请求或覆盖成品"
    )
    p.add_argument(
        "--output-root", type=Path, default=Path.home() / "Downloads/erratum_correction"
    )
    p.add_argument("--homophone-json", type=Path, default=DEFAULT_DICTIONARY)
    p.add_argument(
        "--no-ai", action="store_true", help="明确只做本地词表替换；不算 AI 勘误"
    )
    learning = p.add_mutually_exclusive_group()
    learning.add_argument(
        "--learn",
        action="store_true",
        help="完成后积累私有经验候选，不自动修改词表；本批次续跑自动继承",
    )
    learning.add_argument(
        "--no-learn",
        action="store_true",
        help="本次运行不采集经验，包括已开启学习的批次续跑；不删除已有候选",
    )
    p.add_argument("--learning-store", type=Path, help="指定私有经验库，配合 --learn")
    p.add_argument("--no-recursive", action="store_true")
    p.add_argument("--ai-batch-chars", type=int, default=1500)
    p.add_argument(
        "--request-window",
        type=int,
        default=4,
        help="一次最多暴露多少篇文档的待处理请求，1–32",
    )
    p.add_argument("--encoding", choices=ENCODINGS, default="auto")
    p.add_argument("--output-encoding", choices=("same", "utf-8"), default="same")
    p.add_argument(
        "--dry-run", action="store_true", help="只做本地预检，不创建批次、不请求 AI"
    )
    p.add_argument(
        "--retries", type=int, default=None, help="兼容旧参数；不再进行服务商网络重试"
    )
    return p


def main(argv=None):
    args = build_arg_parser().parse_args(argv)
    try:
        if args.learning_store is not None and not args.learn:
            raise ErratumError("learning_store_requires_learn")
        if not 128 <= args.ai_batch_chars <= 12000:
            raise ErratumError("ai_batch_chars_must_be_128_to_12000")
        if not 1 <= args.request_window <= 32:
            raise ErratumError("request_window_must_be_1_to_32")
        if args.retries is not None and not 0 <= args.retries <= 10:
            raise ErratumError("invalid_retries")
        if args.resume:
            if (
                args.dry_run
                or args.no_ai
                or args.no_recursive
                or args.homophone_json != DEFAULT_DICTIONARY
                or args.encoding != "auto"
                or args.output_encoding != "same"
                or args.ai_batch_chars != 1500
            ):
                raise ErratumError("resume_uses_saved_options_start_new_job_to_change")
            result, code = resume(args.resume, args.request_window)
        else:
            result, code = start(args)
        result, code = collect_requested_experience(result, code, args)
    except Exception as error:
        result = {"status": "error", "reason": reason(error)}
        code = 2
    print(packed(result).decode())
    return code


if __name__ == "__main__":
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", newline="")
    raise SystemExit(main())
