"""Bounded, stdlib-only document extraction and structural translation guards.

Plans contain source text and are private data, not model instructions. Only units
are intended for translation. No linguistic or semantic correctness is inferred.
"""

import json
import math
import re
import unicodedata

VERSION = 1
SUPPORTED_EXTENSIONS = frozenset(
    {".txt", ".md", ".markdown", ".srt", ".vtt", ".csv", ".json"}
)
MAX_DOCUMENT_CHARS = 4_000_000
MAX_OUTPUT_CHARS = 16_000_000
MAX_UNIT_CHARS = 65_536
MAX_UNITS = 100_000
MAX_CONTAINERS = 100_000
MAX_TOKENS = 200_000
MAX_JSON_DEPTH = 64
_NEWLINE = re.compile(r"\r\n|[\r\n\v\f\x85\u2028\u2029]")
_NUMBER = re.compile(r"[+-]?\d+(?:[.,:/]\d+)*(?:[eE][+-]?\d+)?%?")
_URL = re.compile(r"(?:[A-Za-z][A-Za-z0-9+.-]*://|mailto:|www\.)[^\s<>\[\]{}\"'`]+")
_PRINTF = re.compile(
    r"%(?:\([A-Za-z_]\w{0,255}\))?[-+#0 ']{0,16}(?:\d{1,10}|\*)?(?:\.(?:\d{1,10}|\*))?[diouxXeEfFgGcrsa%]"
)
_TAG_NAME = re.compile(r"</?[^\W\d][\w:.-]*")
_AUTOLINK = re.compile(
    r"<(?:[A-Za-z][A-Za-z0-9+.-]*:[^\s<>]+|[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+)>"
)
_RAW_OPEN = re.compile(r"<(pre|code|script|style)(?:\s[^>]*|)>", re.I)
_ENTITY = re.compile(r"&(?:#[0-9]+|#x[0-9a-fA-F]+|[A-Za-z][A-Za-z0-9]*);")
_FENCE = re.compile(
    r"^[ \t]*(?:>[ \t]*)*(?:(?:[-+*]|[0-9]+[.)])[ \t]+)?(?P<run>`{3,}|~{3,})(?P<info>.*)$"
)
_PREFIX = re.compile(
    r"^[ \t]*(?:>[ \t]*)*(?:(?:#{1,6}|[-+*]|[0-9]+[.)])[ \t]+(?:\[[ xX]\][ \t]+)?)?"
)
_REFERENCE = re.compile(r"^[ \t]{0,3}\[[^\]\r\n]+\]:")
_SRT_TIME = r"[0-9]{2,9}:[0-5][0-9]:[0-5][0-9],[0-9]{3}"
_VTT_TIME = r"(?:[0-9]{2,9}:)?[0-5][0-9]:[0-5][0-9]\.[0-9]{3}"
_SRT_TIMING = re.compile(
    rf"[ \t]*(?P<start>{_SRT_TIME})[ \t]+-->[ \t]+(?P<end>{_SRT_TIME})[ \t]*"
)
_VTT_TIMING = re.compile(
    rf"[ \t]*(?P<start>{_VTT_TIME})[ \t]+-->[ \t]+(?P<end>{_VTT_TIME})(?P<settings>(?:[ \t]+[^\s]+)*)[ \t]*"
)


class DocumentError(ValueError):
    """Safe diagnostic code only; never includes source text or a path."""

    def __init__(self, code):
        self.code = (
            code
            if isinstance(code, str) and re.fullmatch(r"[a-z][a-z0-9_]{0,79}", code)
            else "document_error"
        )
        super().__init__(self.code)


def _check_text(text, limit=MAX_DOCUMENT_CHARS):
    if not isinstance(text, str):
        raise DocumentError("text_type")
    if len(text) > limit:
        raise DocumentError("document_size")
    if "\x00" in text or any(0xD800 <= ord(c) <= 0xDFFF for c in text):
        raise DocumentError("text_encoding")


def _meaningful(text):
    return any(c.isalpha() for c in text)


def _edges(text):
    left = 0
    right = len(text)
    while left < right and text[left].isspace():
        left += 1
    while right > left and text[right - 1].isspace():
        right -= 1
    return text[:left], text[right:]


def _lines(text):
    """(start, content end, end including line ending), including empty lines."""
    start = 0
    for match in _NEWLINE.finditer(text):
        yield start, match.start(), match.end()
        start = match.end()
    if start < len(text):
        yield start, len(text), len(text)


def _merge(ranges):
    result = []
    for start, end in sorted(ranges):
        if start >= end:
            continue
        if result and start <= result[-1][1]:
            result[-1] = (result[-1][0], max(end, result[-1][1]))
        else:
            result.append((start, end))
    return result


def _gaps(length, ranges):
    pos = 0
    for start, end in _merge(ranges):
        if start > pos:
            yield pos, start
        pos = end
    if pos < length:
        yield pos, length


def _balanced(text, pos, opening="{", closing="}"):
    depth = 0
    for index in range(pos, len(text)):
        if text[index] == opening:
            depth += 1
            if depth > MAX_JSON_DEPTH:
                raise DocumentError("markup_depth")
        elif text[index] == closing:
            depth -= 1
            if depth == 0:
                return index + 1
    raise DocumentError("markup_unclosed")


def _destination_end(text, pos):
    depth = 1
    quote = ""
    index = pos + 1
    while index < len(text):
        char = text[index]
        if char in "\r\n":
            raise DocumentError("markdown_multiline_destination")
        if char == "\\":
            index += 2
            continue
        if quote:
            if char == quote:
                quote = ""
        elif char in "\"'" and (index == pos + 1 or text[index - 1].isspace()):
            quote = char
        elif char == "(":
            depth += 1
            if depth > MAX_JSON_DEPTH:
                raise DocumentError("markup_depth")
        elif char == ")":
            depth -= 1
            if depth == 0:
                return index + 1
        index += 1
    raise DocumentError("markdown_destination")


def _tag_end(text, pos):
    """A quote-aware linear tag scan; not a full HTML/XML validator."""
    name = _TAG_NAME.match(text, pos)
    if name is None:
        if text[pos + 1 : pos + 2] in ("!", "?"):
            raise DocumentError("markup_tag")
        return None
    index = name.end()
    if index < len(text) and not text[index].isspace() and text[index] not in "/>":
        raise DocumentError("markup_tag")
    quote = ""
    while index < len(text):
        char = text[index]
        if quote:
            if char == quote:
                quote = ""
        elif char in "\"'":
            quote = char
        elif char == ">":
            return index + 1
        elif char == "<":
            raise DocumentError("markup_tag")
        index += 1
    raise DocumentError("markup_unclosed")


def _tokens(text, markdown=False):
    """Yield indivisible protected spans; translation may not add/remove tokens."""
    # Index code delimiters once, avoiding repeated searches on hostile input.
    following = {}
    next_tick = {}
    ticks = []
    for match in re.finditer(r"`+", text):
        if len(ticks) >= MAX_TOKENS:
            raise DocumentError("document_complexity")
        ticks.append(match)
    for match in reversed(ticks):
        width = match.end() - match.start()
        if width in following:
            next_tick[match.start()] = following[width]
        following[width] = match.end()
    pos = 0
    while pos < len(text):
        char = text[pos]
        end = pos
        if text.startswith("<!--", pos):
            close = text.find("-->", pos + 4)
            if close < 0:
                raise DocumentError("markup_unclosed")
            end = close + 3
        elif text.startswith("<![CDATA[", pos) or text.startswith("<?", pos):
            terminator = "]]>" if text.startswith("<![CDATA[", pos) else "?>"
            close = text.find(terminator, pos + 2)
            if close < 0:
                raise DocumentError("markup_unclosed")
            end = close + len(terminator)
        elif char == "<" and (raw := _RAW_OPEN.match(text, pos)):
            close = re.compile(r"</" + raw[1] + r"\s*>", re.I).search(text, raw.end())
            if close is None:
                raise DocumentError("markup_unclosed")
            end = close.end()
        elif char == "<":
            autolink = _AUTOLINK.match(text, pos)
            end = autolink.end() if autolink else (_tag_end(text, pos) or pos + 1)
        elif char == "`":
            if pos not in next_tick:
                raise DocumentError("code_unclosed")
            end = next_tick[pos]
        elif char == "{" or text.startswith("${", pos):
            end = _balanced(text, pos + (char == "$"))
        elif markdown and text.startswith("![", pos):
            end = pos + 1
        elif markdown and char == "[":
            close = pos + 1
            while close < len(text) and text[close] != "]":
                if text[close] in "[\r\n":
                    raise DocumentError("markdown_nested_label")
                if text[close] == "\\":
                    close += 1
                close += 1
            if close == len(text):
                raise DocumentError("markdown_label")
            if text.startswith("[]", close + 1):
                end = close + 3  # Collapsed reference label is an identifier.
            elif text[close + 1 : close + 2] not in ("(", "["):
                end = close + 1  # Conservative: shortcut references stay exact.
            else:
                end = pos + 1
        elif markdown and text.startswith("](", pos):
            end = _destination_end(text, pos + 1)
        elif markdown and text.startswith("][", pos):
            close = text.find("]", pos + 2)
            if close < 0 or any(c in text[pos + 2 : close] for c in "[\r\n"):
                raise DocumentError("markdown_reference")
            end = close + 1
        else:
            token = None
            if char == "%":
                token = _PRINTF.match(text, pos)
                if token is None and text.startswith("%(", pos):
                    raise DocumentError("placeholder_syntax")
            if token is None and char == "&":
                token = _ENTITY.match(text, pos)
            if token is None and (char.isdigit() or char in "+-"):
                token = _NUMBER.match(text, pos)
            if token is None and char.isascii() and char.isalpha():
                # Only test at a possible scheme start, not every suffix of a word.
                if pos == 0 or not (
                    text[pos - 1].isascii()
                    and (text[pos - 1].isalnum() or text[pos - 1] in "+.-")
                ):
                    token = _URL.match(text, pos)
            if token is not None:
                end = token.end()
            elif text.startswith("-->", pos):
                end = pos + 3
            elif char == "\\":
                end = min(len(text), pos + 2)
            elif text.startswith("\r\n", pos):
                end = pos + 2
            elif (
                char in "<>}[]*_#~|"
                or char.isspace()
                and char not in " \u00a0"
                or unicodedata.category(char).startswith("C")
                or unicodedata.category(char) == "Sc"
            ):
                end = pos + 1
        if end > pos:
            yield pos, end
            pos = end
        else:
            pos += 1


def _markdown_blocks(text):
    protected = []
    decoration = []
    fence = None
    frontmatter = None
    reference_block = False
    for index, (start, end, _) in enumerate(_lines(text)):
        if index >= MAX_TOKENS:
            raise DocumentError("document_complexity")
        line = text[start:end]
        match = _FENCE.fullmatch(line)
        if reference_block:
            if line.strip():
                protected.append((start, end))
                continue
            reference_block = False
        if index == 0 and line in ("---", "+++"):
            frontmatter = line
            protected.append((start, end))
        elif frontmatter:
            protected.append((start, end))
            if line in (frontmatter, "..." if frontmatter == "---" else "+++"):
                frontmatter = None
        elif fence:
            protected.append((start, end))
            if (
                match
                and match["run"][0] == fence[0]
                and len(match["run"]) >= fence[1]
                and not match["info"].strip()
            ):
                fence = None
        elif match:
            if match["run"][0] == "`" and "`" in match["info"]:
                raise DocumentError("markdown_fence")
            fence = (match["run"][0], len(match["run"]))
            protected.append((start, end))
        elif _REFERENCE.match(line):
            protected.append((start, end))
            reference_block = True
        elif line.startswith(("    ", "\t")):
            protected.append((start, end))
        elif re.fullmatch(r"[ \t]*(?:[-*_][ \t]*){3,}|[ \t]*[=-]+[ \t]*", line):
            protected.append((start, end))
        else:
            prefix = _PREFIX.match(line)
            if prefix and prefix.end():
                if re.match(
                    r"(?:[-+*]|[0-9]+[.)]|#{1,6}|>)[ \t]+", line[prefix.end() :]
                ):
                    raise DocumentError("markdown_nested_prefix")
                decoration.append((start, start + prefix.end()))
            # A Markdown hard-break suffix must not turn into inner whitespace.
            trailing = re.search(r" {2,}$", line)
            if trailing:
                decoration.append((start + trailing.start(), end))
    if frontmatter or fence:
        raise DocumentError("markdown_block_unclosed")
    return _merge(protected), decoration


def _protection(text, markdown=False):
    blocks, decoration = _markdown_blocks(text) if markdown else ([], [])
    tokens = []
    for start, end in _gaps(len(text), blocks):
        for a, b in _tokens(text[start:end], markdown):
            if len(tokens) + len(blocks) + len(decoration) >= MAX_TOKENS:
                raise DocumentError("document_complexity")
            tokens.append((start + a, start + b))
    # Separate token boundaries in signatures: changing inner spaces is permitted.
    signature = (
        [text[a:b] for a, b in blocks],
        [text[a:b] for a, b in decoration],
        [text[a:b] for a, b in tokens],
    )
    return _merge(blocks + decoration + tokens), signature


def validate_translation(before: str, after: str) -> None:
    """Check structure, not language: punctuation and inner word spaces may change."""
    _check_text(before, MAX_OUTPUT_CHARS)
    _check_text(after, MAX_OUTPUT_CHARS)
    if len(after) > max(256, len(before) * 8):
        raise DocumentError("translation_size")
    if _meaningful(before) and not _meaningful(after):
        raise DocumentError("translation_empty")
    if _edges(before) != _edges(after):
        raise DocumentError("translation_whitespace")
    if _protection(before)[1] != _protection(after)[1]:
        raise DocumentError("translation_structure")


def validate_unit_translation(unit: dict, after: str) -> None:
    """Permit natural target-language spaces only at explicitly internal joins.

    Source whitespace and physical line margins remain immutable. For example,
    separate units around the protected 3 in 支持3种语言 may add word spaces.
    """
    _check_text(after, MAX_OUTPUT_CHARS)
    context = unit.get("context", {})
    candidate = after
    if context.get("allow_leading_space") is True:
        if len(candidate) - len(candidate.lstrip(" ")) > 1:
            raise DocumentError("translation_whitespace")
        candidate = candidate.lstrip(" ")
    if context.get("allow_trailing_space") is True:
        if len(candidate) - len(candidate.rstrip(" ")) > 1:
            raise DocumentError("translation_whitespace")
        candidate = candidate.rstrip(" ")
    validate_translation(unit["text"], candidate)


def _padding_neighbor(char):
    return bool(char) and (
        char.isalnum() or char in "{}%$" or unicodedata.category(char) == "Sc"
    )


def _time_value(text):
    parts = text.replace(",", ".").split(":")
    seconds, fraction = parts[-1].split(".")
    return (
        ((int(parts[0]) * 60 if len(parts) == 3 else 0) + int(parts[-2])) * 60_000
        + int(seconds) * 1000
        + int(fraction)
    )


def _vtt_settings(settings):
    patterns = {
        "vertical": r"(?:rl|lr)",
        "line": r"(?:auto|-?[0-9]+|[0-9]+(?:\.[0-9]+)?%)(?:,(?:start|center|end))?",
        "position": r"[0-9]+(?:\.[0-9]+)?%(?:,(?:line-left|center|line-right|auto))?",
        "size": r"[0-9]+(?:\.[0-9]+)?%",
        "align": r"(?:start|center|end|left|right)",
        "region": r"[^\s:]+",
    }
    seen = set()
    for setting in settings.split():
        key, separator, value = setting.partition(":")
        if (
            not separator
            or key not in patterns
            or key in seen
            or not re.fullmatch(patterns[key], value)
        ):
            raise DocumentError("vtt_settings")
        if "%" in value and not 0 <= float(value.split("%", 1)[0]) <= 100:
            raise DocumentError("vtt_settings")
        seen.add(key)


def _subtitle_containers(text, vtt):
    blocks = []
    block = []
    for line_number, (start, end, full_end) in enumerate(_lines(text)):
        if line_number >= MAX_TOKENS:
            raise DocumentError("document_complexity")
        if text[start:end].strip():
            block.append((start, end, full_end))
        elif block:
            blocks.append(block)
            block = []
    if block:
        blocks.append(block)
    if not blocks:
        raise DocumentError("subtitle_structure")
    if vtt:
        header = blocks.pop(0)
        if (
            header[0][0] != 0
            or not re.fullmatch(
                r"WEBVTT(?:[ \t].*)?", text[header[0][0] : header[0][1]]
            )
            or any("-->" in text[a:b] for a, b, _ in header)
        ):
            raise DocumentError("vtt_header")
    containers = []
    seen_cue = False
    for cue, block in enumerate(blocks):
        first = text[block[0][0] : block[0][1]]
        if vtt and re.match(r"NOTE(?:[ \t]|$)", first):
            continue
        if vtt and first in ("STYLE", "REGION"):
            if seen_cue:
                raise DocumentError("vtt_metadata_order")
            continue
        seen_cue = True
        timing_index = 0
        if not vtt:
            if not re.fullmatch(r"[ \t]*[0-9]{1,9}[ \t]*", first):
                raise DocumentError("srt_index")
            timing_index = 1
        elif not _VTT_TIMING.fullmatch(first):
            if "-->" in first:
                raise DocumentError("subtitle_timing")
            timing_index = 1
        if len(block) <= timing_index + 1:
            raise DocumentError("subtitle_structure")
        start, end, _ = block[timing_index]
        timing = (_VTT_TIMING if vtt else _SRT_TIMING).fullmatch(text[start:end])
        if timing is None:
            raise DocumentError("subtitle_timing")
        if _time_value(timing["end"]) <= _time_value(timing["start"]):
            raise DocumentError("subtitle_time_order")
        if vtt:
            _vtt_settings(timing["settings"])
        for line, (start, end, _) in enumerate(block[timing_index + 1 :]):
            value = text[start:end]
            if _SRT_TIMING.fullmatch(value) or _VTT_TIMING.fullmatch(value):
                raise DocumentError("subtitle_missing_separator")
            containers.append(
                _container(
                    start,
                    end,
                    value,
                    "raw",
                    {"format": "vtt" if vtt else "srt", "cue": cue, "line": line},
                )
            )
    return containers


def _container(start, end, value, kind, context, **extra):
    return {
        "start": start,
        "end": end,
        "value": value,
        "kind": kind,
        "context": context,
        **extra,
    }


def _csv_parse(text, delimiter):
    """Strict rectangular RFC-style records, preserving exact raw field spans."""
    containers = []
    pos = 0
    row = 0
    column = 0
    width = None
    while pos < len(text):
        start = pos
        quoted = text[pos] == '"'
        if quoted:
            pos += 1
            chunks = []
            chunk_start = pos
            while True:
                quote = text.find('"', pos)
                if quote < 0:
                    raise DocumentError("csv_quote")
                chunks.append(text[chunk_start:quote])
                pos = quote + 1
                if pos < len(text) and text[pos] == '"':
                    chunks.append('"')
                    pos += 1
                    chunk_start = pos
                else:
                    break
            value = "".join(chunks)
            if pos < len(text) and text[pos] not in (delimiter, "\r", "\n"):
                raise DocumentError("csv_quote")
        else:
            while pos < len(text) and text[pos] not in (delimiter, "\r", "\n"):
                if text[pos] == '"':
                    raise DocumentError("csv_quote")
                pos += 1
            value = text[start:pos]
        containers.append(
            _container(
                start,
                pos,
                value,
                "csv",
                {"format": "csv", "row": row, "column": column, "header": row == 0},
                quoted=quoted,
            )
        )
        if len(containers) > MAX_CONTAINERS:
            raise DocumentError("document_complexity")
        column += 1
        if pos < len(text) and text[pos] == delimiter:
            pos += 1
            if pos == len(text):
                containers.append(
                    _container(
                        pos,
                        pos,
                        "",
                        "csv",
                        {
                            "format": "csv",
                            "row": row,
                            "column": column,
                            "header": row == 0,
                        },
                        quoted=False,
                    )
                )
                column += 1
            else:
                continue
        if width is None:
            width = column
        if column != width:
            raise DocumentError("csv_columns")
        column = 0
        row += 1
        if text.startswith("\r\n", pos):
            pos += 2
        elif pos < len(text):
            pos += 1
    return containers, row, width or 0


def _csv_containers(text):
    # Do not let Sniffer silently guess a dialect from a small document sample.
    candidates = []
    for delimiter in (",", ";", "\t", "|"):
        try:
            containers, rows, width = _csv_parse(text, delimiter)
        except DocumentError:
            continue
        if width > 1:
            candidates.append((delimiter, containers, rows, width))
    if len(candidates) > 1:
        raise DocumentError("csv_ambiguous_dialect")
    if candidates:
        return candidates[0]
    containers, rows, width = _csv_parse(text, ",")
    if width > 1 or any(
        not c["quoted"] and any(d in c["value"] for d in ";\t|") for c in containers
    ):
        raise DocumentError("csv_dialect")
    return ",", containers, rows, width


def _formula(value):
    # A tab is dangerous even after other whitespace; never strip it away.
    pos = 0
    while (
        pos < len(value)
        and value[pos] != "\t"
        and (value[pos].isspace() or value[pos] == "\ufeff")
    ):
        pos += 1
    return value[pos : pos + 1] in ("=", "+", "-", "@", "\t")


class _JSONParser:
    """Bounded recursive descent, retaining source spans for string VALUES only."""

    def __init__(self, text):
        self.text = text
        self.pos = 0
        self.containers = []
        self.nodes = 0

    def whitespace(self):
        while self.pos < len(self.text) and self.text[self.pos] in " \t\r\n":
            self.pos += 1

    def string(self):
        start = self.pos
        self.pos += 1
        while self.pos < len(self.text):
            char = self.text[self.pos]
            if char == '"':
                self.pos += 1
                try:
                    value = json.loads(self.text[start : self.pos])
                except (ValueError, RecursionError):
                    raise DocumentError("json_string") from None
                _check_text(value)
                return start, self.pos, value
            if ord(char) < 32:
                raise DocumentError("json_string")
            if char == "\\":
                self.pos += 1
            self.pos += 1
        raise DocumentError("json_string")

    def value(self, path, depth=0):
        if depth > MAX_JSON_DEPTH:
            raise DocumentError("json_depth")
        self.nodes += 1
        if self.nodes > MAX_CONTAINERS:
            raise DocumentError("document_complexity")
        self.whitespace()
        if self.pos >= len(self.text):
            raise DocumentError("json_syntax")
        char = self.text[self.pos]
        if char == '"':
            start, end, value = self.string()
            self.containers.append(
                _container(start, end, value, "json", {"format": "json", "path": path})
            )
        elif char in "[{":
            is_object = char == "{"
            closing = "}" if is_object else "]"
            self.pos += 1
            self.whitespace()
            seen = set()
            index = 0
            if self.text[self.pos : self.pos + 1] == closing:
                self.pos += 1
                return
            while True:
                self.whitespace()
                if is_object:
                    if self.text[self.pos : self.pos + 1] != '"':
                        raise DocumentError("json_key")
                    _, _, key = self.string()
                    if key in seen:
                        raise DocumentError("json_duplicate_key")
                    seen.add(key)
                    self.whitespace()
                    if self.text[self.pos : self.pos + 1] != ":":
                        raise DocumentError("json_syntax")
                    self.pos += 1
                else:
                    key = index
                self.value(path + [key], depth + 1)
                index += 1
                self.whitespace()
                next_char = self.text[self.pos : self.pos + 1]
                if next_char == closing:
                    self.pos += 1
                    return
                if next_char != ",":
                    raise DocumentError("json_syntax")
                self.pos += 1
        else:
            match = re.compile(
                r"(?:true|false|null|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)"
            ).match(self.text, self.pos)
            if match is None:
                raise DocumentError("json_syntax")
            spelling = match.group()
            if spelling not in ("true", "false", "null") and not math.isfinite(
                float(spelling)
            ):
                raise DocumentError("json_nonfinite")
            self.pos = match.end()

    def parse(self):
        self.value([])
        self.whitespace()
        if self.pos != len(self.text):
            raise DocumentError("json_syntax")
        return self.containers


def _extract(text, extension):
    metadata = {}
    if extension == ".json":
        containers = _JSONParser(text).parse()
    elif extension == ".csv":
        delimiter, containers, rows, width = _csv_containers(text)
        metadata = {"delimiter": delimiter, "rows": rows, "columns": width}
    elif extension in (".srt", ".vtt"):
        containers = _subtitle_containers(text, extension == ".vtt")
    else:
        containers = [_container(0, len(text), text, "raw", {"format": extension[1:]})]
    if len(containers) > MAX_CONTAINERS:
        raise DocumentError("document_complexity")
    return containers, metadata


def _fragments(text, start, end, max_chars):
    """Source whitespace at every fragment edge remains outside the AI unit."""
    while start < end:
        while start < end and text[start].isspace():
            start += 1
        if start == end:
            return
        stop = min(end, start + max_chars)
        if stop < end:
            window = text[start:stop]
            sentences = list(re.finditer(r"[。！？]|[.!?](?:\s+|$)", window))
            spaces = list(re.finditer(r"\s+", window))
            if sentences:
                stop = start + sentences[-1].end()
            elif spaces:
                stop = start + spaces[-1].end()
        trimmed = stop
        while trimmed > start and text[trimmed - 1].isspace():
            trimmed -= 1
        if trimmed > start and _meaningful(text[start:trimmed]):
            yield start, trimmed
        start = stop


def prepare_document(text: str, ext: str, max_chars: int = 1500) -> dict:
    """Return a JSON-serializable immutable-source extraction/reassembly plan."""
    _check_text(text)
    if not isinstance(ext, str):
        raise DocumentError("extension")
    extension = ext.lower()
    if not extension.startswith("."):
        extension = "." + extension
    if extension not in SUPPORTED_EXTENSIONS:
        raise DocumentError("extension")
    if type(max_chars) is not int or not 1 <= max_chars <= MAX_UNIT_CHARS:
        raise DocumentError("unit_size")
    containers, metadata = _extract(text, extension)
    units = []
    markdown = extension in (".md", ".markdown")
    for container in containers:
        value = container["value"]
        pieces = []
        if container["kind"] == "csv" and _formula(value):
            container["pieces"] = pieces
            continue
        ranges, _ = _protection(value, markdown)
        for start, end in _gaps(len(value), ranges):
            for a, b in _fragments(value, start, end, max_chars):
                unit_id = len(units)
                if unit_id >= MAX_UNITS:
                    raise DocumentError("document_complexity")
                context = {
                    **container["context"],
                    "before": value[max(0, a - 120) : a],
                    "after": value[b : b + 120],
                    "allow_leading_space": (
                        _padding_neighbor(value[a - 1 : a]) if a else False
                    ),
                    "allow_trailing_space": _padding_neighbor(value[b : b + 1])
                    or bool(_NUMBER.match(value, b)),
                }
                units.append({"id": unit_id, "text": value[a:b], "context": context})
                pieces.append([a, b, unit_id])
        container["pieces"] = pieces
    return {
        "version": VERSION,
        "extension": extension,
        "text": text,
        "max_chars": max_chars,
        "units": units,
        "_containers": containers,
        "_metadata": metadata,
    }


def _join_pieces(value, pieces, translations):
    result = []
    cursor = 0
    length = 0
    for start, end, unit_id in pieces:
        original = value[cursor:start]
        replacement = translations[unit_id]
        length += len(original) + len(replacement)
        if length > MAX_OUTPUT_CHARS:
            raise DocumentError("translation_size")
        result.extend((original, replacement))
        cursor = end
    if length + len(value) - cursor > MAX_OUTPUT_CHARS:
        raise DocumentError("translation_size")
    result.append(value[cursor:])
    return "".join(result)


def render_document(plan: dict, translations: dict[int, str]) -> str:
    """Validate all IDs, guards, framing and grammar before returning any output."""
    if not isinstance(plan, dict):
        raise DocumentError("plan_invalid")
    try:
        expected = prepare_document(plan["text"], plan["extension"], plan["max_chars"])
        if plan != expected:
            raise DocumentError("plan_invalid")
    except (KeyError, TypeError, RecursionError):
        raise DocumentError("plan_invalid") from None
    plan = expected  # Never use caller-supplied offsets or reconstruction metadata.
    if not isinstance(translations, dict) or any(
        type(key) is not int for key in translations
    ):
        raise DocumentError("translation_ids")
    if set(translations) != set(range(len(plan["units"]))):
        raise DocumentError("translation_ids")
    output_bound = len(plan["text"])
    for unit in plan["units"]:
        replacement = translations[unit["id"]]
        validate_unit_translation(unit, replacement)
        output_bound += len(replacement) - len(unit["text"])
    if output_bound > MAX_OUTPUT_CHARS:
        raise DocumentError("translation_size")
    markdown = plan["extension"] in (".md", ".markdown")
    result = []
    cursor = 0
    length = 0
    for container in plan["_containers"]:
        original = container["value"]
        value = _join_pieces(original, container["pieces"], translations)
        if value == original:
            raw = plan["text"][container["start"] : container["end"]]
        else:
            if _protection(original, markdown)[1] != _protection(value, markdown)[1]:
                raise DocumentError("translation_structure")
            if [_edges(original[a:b]) for a, b, _ in _lines(original)] != [
                _edges(value[a:b]) for a, b, _ in _lines(value)
            ]:
                raise DocumentError("translation_whitespace")
            if container["kind"] == "csv":
                if _formula(value) and not _formula(original):
                    raise DocumentError("csv_formula")
                delimiter = plan["_metadata"]["delimiter"]
                quoted = container["quoted"] or any(
                    c in value for c in (delimiter, '"', "\r", "\n")
                )
                raw = '"' + value.replace('"', '""') + '"' if quoted else value
            elif container["kind"] == "json":
                raw = json.dumps(value, ensure_ascii=False)
            else:
                raw = value
        gap = plan["text"][cursor : container["start"]]
        length += len(gap) + len(raw)
        if length > MAX_OUTPUT_CHARS:
            raise DocumentError("translation_size")
        result.extend((gap, raw))
        cursor = container["end"]
    length += len(plan["text"]) - cursor
    if length > MAX_OUTPUT_CHARS:
        raise DocumentError("translation_size")
    result.append(plan["text"][cursor:])
    output = "".join(result)
    # Reparse with the known dialect (not a new heuristic after translation).
    if plan["extension"] == ".csv":
        cells, rows, width = _csv_parse(output, plan["_metadata"]["delimiter"])
        if (rows, width) != (plan["_metadata"]["rows"], plan["_metadata"]["columns"]):
            raise DocumentError("csv_structure")
        if any(
            _formula(new["value"]) and not _formula(old["value"])
            for old, new in zip(plan["_containers"], cells)
        ):
            raise DocumentError("csv_formula")
    elif plan["extension"] == ".json":
        cells = _JSONParser(output).parse()
        if [c["context"] for c in cells] != [c["context"] for c in plan["_containers"]]:
            raise DocumentError("json_structure")
    elif plan["extension"] in (".srt", ".vtt"):
        cells = _subtitle_containers(output, plan["extension"] == ".vtt")
        if [c["context"] for c in cells] != [c["context"] for c in plan["_containers"]]:
            raise DocumentError("subtitle_structure")
    return output
