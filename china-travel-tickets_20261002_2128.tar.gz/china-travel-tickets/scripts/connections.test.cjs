'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parseArgs, query, recordDetails, recordAirlines } = require('./flight_query.cjs');
const { sendWithRetry } = require('./send_report.cjs');

const segments = [
  { marketingTransportNo: 'MU1234', marketingTransportName: '东航', depDateTime: '2099-01-02 08:00:00', arrDateTime: '2099-01-02 10:00:00', arrStationCode: 'SHA', arrTerm: 'T2' },
  { marketingTransportNo: 'CA1234', depDateTime: '2099-01-02 11:00:00', arrDateTime: '2099-01-02 13:00:00', depStationCode: 'SHA', depTerm: 'T2' },
];
function search(records, flags = []) {
  const options = parseArgs(['--from', '甲', '--to', '乙', '--date', '2099-01-02', ...flags]);
  return query(options, { runner: () => ({ exitCode: 0, stdout: JSON.stringify({ status: 0, data: { itemList: records } }) }) });
}

test('matches real FlyAI carrier name/designator and preserves raw payload', () => {
  const flight = { ticketPrice: '200', journeys: [{ segments }] };
  assert.deepEqual(recordAirlines(flight), ['东航', 'MU', 'CA']);
  assert.deepEqual(search([flight], ['--prefer-airline', 'MU']).results, [flight]);
});

test('missing fares sort last instead of becoming zero', () => {
  const unknown = { journeys: [{ segments }] };
  const priced = { ticketPrice: '219.50', journeys: [{ segments }] };
  assert.equal(recordDetails(unknown).price, null);
  assert.deepEqual(search([unknown, priced], ['--sort', 'price']).results, [priced, unknown]);
});

test('connection airport/terminal/time constraints exclude unknown data', () => {
  const valid = { journeys: [{ segments }] };
  const different = { journeys: [{ segments: [segments[0], { ...segments[1], depStationCode: 'PVG' }] }] };
  const unknown = { journeys: [{ segments: [segments[0], { ...segments[1], depTerm: null }] }] };
  assert.equal(recordDetails(valid).transfer, 60);
  assert.equal(search([valid, different], ['--same-airport-only']).resultCount, 1);
  assert.equal(search([valid, unknown], ['--same-terminal-only']).resultCount, 1);
  assert.equal(search([valid], ['--min-connection-minutes', '90']).resultCount, 0);
  const noTime = { journeys: [{ segments: [segments[0], { ...segments[1], depDateTime: null }] }] };
  assert.equal(search([noTime], ['--max-transfer-minutes', '240']).resultCount, 0);
});

test('nonstop filter excludes empty journeys and explicit stopovers', () => {
  assert.equal(search([{ journeys: [] }], ['--direct-only']).resultCount, 0);
  const stop = { journeys: [{ segments: [{ ...segments[0], stopInfos: [{ city: '中间站' }] }] }] };
  assert.equal(search([stop], ['--direct-only']).resultCount, 0);
});

test('mail auth and ambiguous delivery errors are never blindly retried', async () => {
  for (const error of [Object.assign(new Error('secret'), { code: 'EAUTH', responseCode: 535 }),
    Object.assign(new Error('secret'), { code: 'ETIMEDOUT', deliveryUncertain: true })]) {
    let calls = 0;
    const result = await sendWithRetry({ payload: {}, retryDelayMs: 0, send: async () => { calls++; throw error; } });
    assert.equal(calls, 1);
    assert.equal(result.success, false);
    assert.doesNotMatch(JSON.stringify(result), /secret/);
  }
});
