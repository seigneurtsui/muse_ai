# 实现与安全边界

## 架构

1. **路径校验** `_validate_paths`：输入目录必须存在；非就地模式下输出目录不得等于输入、也不得位于输入内部（`output_equals_input` / `output_within_input`），防止把生成的 HTML 再次当作源扫描。`--in-place` 时跳过输出边界检查（输出 = 输入）。
2. **扫描** `scan_files`：`*.html`（`--recursive` 时为 `**/*.html`），排除符号链接与非普通文件、命中 `--exclude-pattern` 的文件名，并且**始终排除位于输出目录内的文件**——就地模式下输出等于输入，此时跳过该过滤（这是修复过的一个真实缺陷：原先就地模式会把所有源文件都过滤掉）。结果按路径（忽略大小写）稳定排序。
3. **目标路径** `_target_for`：就地 → 源文件；递归 → `output/<相对路径>`；扁平 → `output/<文件名>`。
4. **处理** `process_one`：读取（`errors="replace"`）→ `process_html` → 计算字节数/耗时；`--dry-run` 标记 `planned`；`--incremental` 且目标未变则标 `skipped`；否则原子写入。
   - `batch` 在有界线程池（`--jobs`，文件数 > 4 时启用）中并行 `process_one`，再按源路径顺序重排结果。
5. **报告与 CLI**：`batch` 汇总 `summary` 与逐文件记录；`run` 设定 `status`（`complete`/`partial_failure`/`dry_run`）与退出码；`_emit` 写 `--report` 并打印 `--json`；`_print_summary` 输出一行日志摘要。

## 转换流水线 `process_html`

对单篇文档，按顺序执行（每一步都可安全重复执行）：

1. `strip_injections`：删除本工具此前注入的一切（目录块、CSS 层、脚本）并**解包**此前包裹的表格；同时兼容清理源工具的旧形式注入。这是**严格幂等**的核心。
2. `add_viewport`：缺失 `<meta name="viewport">` 时补入 `<head>`。
3. `add_table_wrappers`：为每个 `<table>` 外层包裹 `<div class="rainman-table-wrapper" data-rainman-table="1">`（`--no-wrap-tables` 可关闭），并给表格类名补 `rainman-table`。
4. `inject_css`：把 `BASE_CSS` 包在 `/* rainman-toc-embed:start */ … /* rainman-toc-embed:end */` 之间插入样式（复用已有 `<style>`，或新建带 `data-rainman-toc-style="1"` 的 `<style>`）。
5. 标题处理：为纳入 `--levels` 的标题生成唯一 ID `rainman-section-N`（已有 ID 保留；重复标题自动去重），收集目录条目。
6. `_toc_aside` + 脚本：若条目数 ≥ `--min-headings`，把 `<aside class="rainman-toc" data-rainman-toc="1">`（可折叠面板 + 阅读进度条）插到 `<body>` 起始处，并以 `data-rainman-toc-script="1"` 标记追加交互脚本。

## 幂等标记

所有注入都用可精确匹配的标记包围，保证「去掉旧的 → 重新注入」得到字节一致的输出：

| 标记 | 用途 |
|---|---|
| `<!--rainman-toc-embed:start-->` / `<!--rainman-toc-embed:end-->` | 目录面板块 |
| `/* rainman-toc-embed:start */` / `/* rainman-toc-embed:end */` | CSS 层 |
| `data-rainman-toc-script="1"` | 交互脚本 `<script>` |
| `data-rainman-toc-style="1"` | 新建的 `<style>` 元素 |
| `data-rainman-toc="1"` | 目录面板 `<aside>` |
| `data-rainman-table="1"` | 表格包裹 `<div>` |

> 使用 `data-rainman-table="1"`（而非类名）判定「是否已包裹」，因为类名 `rainman-table-wrapper` 也出现在 CSS 文本里，会造成误判。

## 关键策略

- **唯一 ID**：用 `rainman-section-<index>` 顺序编号，已存在的 `id` 原样保留、不入目录（尊重作者），重复生成的 ID 自动加后缀。
- **进度条**：由注入脚本按滚动比例更新，并在目录面板中高亮当前章节（`rainman-toc-progress-bar` / `rainman-toc-h*`）。
- **argv 规范化**：`_normalize_argv` 把值可能以 `-` 开头的长选项改写为 `opt=value`。
- **原子写** `write_atomic`：临时文件（`mkstemp`）→ `fsync` → `os.replace`。

## 性能设计

- **有界并行**：`--jobs`（默认 auto，上限 8；文件数 > 4 时启用）重叠多文档的解析与写入。文本处理以读小文件为主，线程池足够。
- **增量**：`--incremental` 在目标内容不变时跳过写入。
- **就地**：`--in-place` 省去复制/镜像，适合原地升级既有站点。

## 安全边界

- 只读取用户明确指定的输入目录；不扫描家目录/Downloads。
- 非就地时输出目录不得等于或位于输入目录内部，避免自反馈扫描；就地时明确只改写被扫描的源文件。
- 不联网、不上传、不发送通知、不访问密钥/账户、不创建后台任务。
- 输入内容按数据处理，不执行其中的脚本或指令；注入的脚本是本工具生成的固定本地脚本。

## 与源脚本的差异

| 方面 | `/tmp/batch_add_toc.py` | 本技能 |
|---|---|---|
| 依赖 | 标准库 | 标准库（保持一致） |
| 幂等 | 尽力移除旧注入，未保证字节一致 | 显式标记 + 解包旧包裹，**字节级幂等** |
| 标题级别 | 固定 H2/H3 | `--levels 1–6` 可配置 |
| 空目录处理 | 无 | `--min-headings`（保留 CSS、跳过面板） |
| 表格包裹 | 固定开启 | `--no-wrap-tables` 可关闭 |
| 就地基改 | 无 | `--in-place`（原子写） |
| 增量 | 无 | `--incremental` / `--force` |
| 并行 | 无 | `--jobs auto`（上限 8） |
| 报告 | 仅打印 | `--json` / `--report`（结构化） |
| dry-run | 无 | `--dry-run`（不写任何文件） |
| 路径边界 | 无校验 | 拒绝输出==输入 / 输出在输入内 |
| 退出码 | 0/1 | 0 / 2（partial_failure）/ 1 |
| 参数健壮性 | 以 `-` 开头的正则值易被 argparse 误判 | `_normalize_argv` 修正 |

## 尚未实现

- 目录面板的多级折叠（当前为单层滚动高亮）。
- 为已存在于正文中的旧锚点做「重命名迁移」（当前只保留原 `id` 而不纳入目录）。
- 超大目录（数万文件）的流式处理；并行上限固定为 8。
