"""Single-pass EPUB NAV/NCX + spine/anchor extraction and DOCX heading extraction.

Adapted in purpose from /tmp/pdf/split_booklets.py; no imports from that script,
no package installation, ZIP extraction, remote resource fetch or AI requests.
"""
from html.parser import HTMLParser
import posixpath
import re
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET
from zipfile import ZipFile, BadZipFile

from models import Boundary, Extracted, SplitError

BLOCKS = {"p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "br", "tr", "blockquote", "section", "article", "pre", "hr", "table"}


def local(tag):
    return tag.rsplit("}", 1)[-1]


class Archive:
    def __init__(self, path):
        try:
            self.zip = ZipFile(path)
        except (OSError, BadZipFile):
            raise SplitError("无法读取 EPUB/DOCX ZIP 容器") from None
        infos = self.zip.infolist()
        names = [i.filename for i in infos]
        if len(names) != len(set(names)) or len(names) > 20000 or sum(i.file_size for i in infos) > 256 * 1024 * 1024:
            self.zip.close()
            raise SplitError("ZIP 条目重复或超过安全容量（20000 项 / 256 MiB）")
        if any(i.file_size > 64 * 1024 * 1024 or i.flag_bits & 1 for i in infos):
            self.zip.close()
            raise SplitError("ZIP 条目加密或单项超过 64 MiB；不绕过 DRM")
        self.names = set(names)

    def __enter__(self): return self
    def __exit__(self, *args): self.zip.close()

    def read(self, name):
        if name not in self.names:
            raise SplitError("书籍引用的内部文件缺失")
        try:
            return self.zip.read(name)
        except (BadZipFile, RuntimeError, OSError):
            raise SplitError("内部文件读取或 CRC 校验失败") from None

    def xml(self, name):
        raw = self.read(name)
        if b"<!ENTITY" in raw.upper().replace(b"\0", b""):
            raise SplitError("不支持带自定义 XML 实体的书籍")
        try:
            return ET.fromstring(raw)
        except ET.ParseError:
            raise SplitError("书籍结构 XML 无法解析") from None


def reference(base, href):
    """Resolve archive-internal references without extracting or fetching anything."""
    if not isinstance(href, str):
        raise SplitError("内部引用必须是文本")
    parts = urlsplit(href)
    if parts.scheme or parts.netloc or parts.query:
        raise SplitError("拒绝外部或带查询参数的结构引用")
    try:
        path, fragment = unquote(parts.path, errors="strict"), unquote(parts.fragment, errors="strict")
    except UnicodeError:
        raise SplitError("内部引用编码无效") from None
    if any(c in path for c in ("\\", "\0")) or path.startswith("/"):
        raise SplitError("不安全的 ZIP 内部路径")
    resolved = posixpath.normpath(posixpath.join(posixpath.dirname(base), path)) if path else base
    if resolved == ".." or resolved.startswith("../"):
        raise SplitError("内部引用越出容器根目录")
    return resolved, fragment


def decode_html(raw):
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        encoding = "utf-16"
    else:
        match = re.match(br'\s*<\?xml[^>]*encoding=[\'"]([^\'"]+)', raw[:250], re.I)
        encoding = match[1].decode("ascii").lower() if match else "utf-8-sig"
    if encoding not in {"utf-8", "utf-8-sig", "utf-16", "utf-16le", "utf-16be", "gb18030", "gbk", "big5", "iso-8859-1", "windows-1252"}:
        raise SplitError("XHTML 字符编码不支持；未静默忽略字符")
    try:
        return raw.decode(encoding)
    except UnicodeError:
        raise SplitError("XHTML 字符编码损坏；未静默忽略字符") from None


class BodyText(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.anchors = [], {}
        self.length = 0
        self.ignored = []
        self.pre = 0

    def add(self, text):
        if text:
            self.parts.append(text)
            self.length += len(text)

    def block(self):
        if self.parts and not self.parts[-1].endswith("\n\n"):
            self.add("\n\n")

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in ("head", "script", "style"):
            self.ignored.append(tag)
        if self.ignored:
            return
        if tag in BLOCKS:
            self.block()
        attrs = dict(attrs)
        for key in (attrs.get("id"), attrs.get("name") if tag == "a" else None):
            if key:
                if key in self.anchors and self.anchors[key] != self.length:
                    self.anchors[key] = None
                else:
                    self.anchors[key] = self.length
        if tag == "pre": self.pre += 1
        if tag == "br": self.add("\n")

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        self.handle_endtag(tag)

    def handle_endtag(self, tag):
        if self.ignored:
            if tag == self.ignored[-1]: self.ignored.pop()
            return
        if tag == "pre": self.pre = max(0, self.pre - 1)
        if tag in BLOCKS: self.block()

    def handle_data(self, data):
        if not self.ignored:
            self.add(data if self.pre else re.sub(r"[\t\r\n ]+", " ", data))


def nav_entries(root):
    nav = next((e for e in root.iter() if local(e.tag) == "nav" and any(local(k) == "type" and "toc" in v.split() for k, v in e.attrib.items())), None)
    if nav is None: return []
    output = []
    def walk(ol, level):
        for li in ol:
            if local(li.tag) != "li": continue
            label = next((e for e in li if local(e.tag) in ("a", "span")), None)
            nested = [e for e in li if local(e.tag) in ("ol", "ul")]
            if label is not None:
                title = " ".join("".join(label.itertext()).split())
                if title:
                    output.append((title, label.get("href"), level, sum(sum(local(c.tag) == "li" for c in ol2) for ol2 in nested)))
            for child in nested: walk(child, level + 1)
    for ol in nav:
        if local(ol.tag) in ("ol", "ul"): walk(ol, 1)
    return output


def ncx_entries(root):
    output = []
    def walk(node, level):
        for point in node:
            if local(point.tag) != "navPoint": continue
            label = next((e for e in point if local(e.tag) == "navLabel"), None)
            content = next((e for e in point if local(e.tag) == "content"), None)
            title = " ".join("".join(label.itertext()).split()) if label is not None else ""
            if title:
                output.append((title, content.get("src") if content is not None else None, level,
                               sum(local(c.tag) == "navPoint" for c in point)))
            walk(point, level + 1)
    navmap = next((e for e in root.iter() if local(e.tag) == "navMap"), None)
    if navmap is not None: walk(navmap, 1)
    return output


def extract_epub(path):
    warnings = []
    with Archive(path) as archive:
        container = archive.xml("META-INF/container.xml")
        packages = [e.get("full-path") for e in container.iter() if local(e.tag) == "rootfile" and e.get("full-path")]
        if not packages: raise SplitError("EPUB 缺少 OPF 根文件")
        package, _ = reference("container.xml", packages[0])
        root = archive.xml(package)
        manifest = {}
        for e in root.iter():
            if local(e.tag) == "item":
                identifier = e.get("id")
                if not identifier or identifier in manifest: raise SplitError("OPF manifest ID 缺失或重复")
                try:
                    resource = reference(package, e.get("href", ""))[0]
                except SplitError:
                    resource = None
                    warnings.append("已忽略不可用的远程/越界资源；不访问任何外链")
                manifest[identifier] = (resource, e.get("media-type", ""), e.get("properties", "").split())
        spine = next((e for e in root.iter() if local(e.tag) == "spine"), None)
        if spine is None: raise SplitError("EPUB 缺少 spine 阅读顺序")
        paths = []
        for entry in spine:
            if local(entry.tag) != "itemref": continue
            item = manifest.get(entry.get("idref"))
            if item is None or item[0] is None or item[1] not in ("application/xhtml+xml", "text/html"):
                raise SplitError("spine 正文缺失或类型不支持；拒绝悄悄丢弃")
            paths.append(item[0])
        if not paths: raise SplitError("EPUB 阅读顺序为空")
        if "META-INF/encryption.xml" in archive.names:
            encrypted = archive.xml("META-INF/encryption.xml")
            for e in encrypted.iter():
                if local(e.tag) == "CipherReference":
                    uri, _ = reference("root.xml", e.get("URI", ""))
                    if uri in paths or uri == package: raise SplitError("EPUB 正文带加密/DRM，需无加密版本")
        parsed, offsets, chunks = {}, {}, []
        total = 0
        for name in paths:
            if name not in parsed:
                parser = BodyText()
                parser.feed(decode_html(archive.read(name)))
                parser.close()
                parsed[name] = ("".join(parser.parts), parser.anchors)
            text, anchors = parsed[name]
            offsets.setdefault(name, []).append(total)
            chunks.append(text + "\n\n")
            total += len(text) + 2
        text = "".join(chunks)
        if not text.strip(): raise SplitError("EPUB 未提取到正文（图片型 EPUB 不等于文字电子书）")
        navs = [item[0] for item in manifest.values() if "nav" in item[2] and item[0]]
        ncxs = [manifest[spine.get("toc")][0]] if spine.get("toc") in manifest else [item[0] for item in manifest.values() if item[1] == "application/x-dtbncx+xml"]
        ncxs = [name for name in ncxs if name]
        entries, toc_file, present = [], "", bool(navs or ncxs)
        for candidate, reader in [(p, nav_entries) for p in navs] + [(p, ncx_entries) for p in ncxs]:
            try:
                candidate_entries = reader(archive.xml(candidate))
            except SplitError:
                warnings.append("一个目录文件无法解析，尝试其他结构目录")
                continue
            if candidate_entries:
                entries, toc_file = candidate_entries, candidate
                break
        resolved = []
        unresolved = 0
        for title, href, level, children in entries:
            position = None
            if href:
                try:
                    name, anchor = reference(toc_file, href)
                    positions = offsets.get(name, [])
                    if len(positions) == 1:
                        anchor_pos = parsed[name][1].get(anchor) if anchor else 0
                        if anchor_pos is not None: position = positions[0] + anchor_pos
                except SplitError:
                    pass
            resolved.append([position, title, level, children, href])
        # Navigation-only section labels inherit the first resolvable descendant.
        for i in range(len(resolved) - 1, -1, -1):
            row = resolved[i]
            if row[0] is None and not row[4] and row[3]:
                for child in resolved[i+1:]:
                    if child[2] <= row[2]: break
                    if child[0] is not None:
                        row[0] = child[0]
                        break
        boundaries = []
        for position, title, level, children, href in resolved:
            if position is None:
                unresolved += 1
            else:
                boundaries.append(Boundary(position, title, level, children, {"href": href or ""}))
        if unresolved: warnings.append(f"{unresolved} 个目录目标无法唯一映射（锚点缺失/外链/重复 spine 等）")
        return Extracted(text, boundaries, "epub_toc", warnings,
                         {"toc_present": present, "structure_uncertain": bool(unresolved or (present and not entries)),
                          "spine_items": len(paths), "documents_parsed": len(parsed), "toc_unresolved": unresolved,
                          "toc_source": toc_file, "incomplete": False})


W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def paragraph_text(paragraph):
    return "".join(e.text or "" if e.tag == W + "t" else "\t" if e.tag == W + "tab" else "\n"
                   for e in paragraph.iter() if e.tag in (W + "t", W + "tab", W + "br", W + "cr"))


def paragraphs_in_order(node):
    if node.tag == W + "p":
        yield node  # Includes nested text boxes once; do not emit their paragraphs twice.
    else:
        for child in node:
            yield from paragraphs_in_order(child)


def extract_docx(path):
    with Archive(path) as archive:
        root = archive.xml("word/document.xml")
        styles = {}
        if "word/styles.xml" in archive.names:
            for style in archive.xml("word/styles.xml"):
                if style.tag == W + "style": styles[style.get(W + "styleId")] = style
        def level_for(style_id, seen=None):
            seen = set() if seen is None else seen
            if style_id in seen: return None
            seen.add(style_id)
            style = styles.get(style_id)
            if style is None: return None
            outline = style.find("./" + W + "pPr/" + W + "outlineLvl")
            if outline is not None and outline.get(W + "val", "").isdigit():
                value = int(outline.get(W + "val"))
                return value + 1 if value < 9 else None
            name = style.find(W + "name")
            value = name.get(W + "val", "") if name is not None else style_id
            match = re.fullmatch(r"(?:heading|标题|標題)\s*([1-9])", value, re.I)
            if match: return int(match[1])
            base = style.find(W + "basedOn")
            return level_for(base.get(W + "val"), seen) if base is not None else None
        chunks, toc, position = [], [], 0
        body = root.find(W + "body")
        if body is None: raise SplitError("DOCX 缺少 document body")
        for paragraph in paragraphs_in_order(body):
            text = paragraph_text(paragraph)
            style = paragraph.find("./" + W + "pPr/" + W + "pStyle")
            outline = paragraph.find("./" + W + "pPr/" + W + "outlineLvl")
            level = level_for(style.get(W + "val")) if style is not None else None
            if outline is not None and outline.get(W + "val", "").isdigit():
                n = int(outline.get(W + "val"))
                level = n + 1 if n < 9 else None
            if level and text.strip(): toc.append(Boundary(position, text.strip(), level, locator={"paragraph": len(chunks)}))
            chunks.append(text + "\n\n")
            position += len(text) + 2
        stack = []
        for boundary in toc:
            while stack and stack[-1].level >= boundary.level: stack.pop()
            if stack: stack[-1].children += 1
            stack.append(boundary)
        for filename, label in (("footnotes.xml", "脚注"), ("endnotes.xml", "尾注")):
            name = "word/" + filename
            if name in archive.names:
                notes = []
                for note in archive.xml(name):
                    if note.get(W + "type") in ("separator", "continuationSeparator"): continue
                    notes.extend(paragraph_text(p) for p in paragraphs_in_order(note))
                if any(t.strip() for t in notes): chunks.append("\n\n" + label + "\n\n" + "\n\n".join(notes))
        text = "".join(chunks)
        if not text.strip(): raise SplitError("DOCX 未提取到正文")
        return Extracted(text, toc, "docx_heading", [], {"toc_present": bool(toc), "incomplete": False,
                         "paragraphs": sum(1 for _ in body.iter(W + "p")), "tables": sum(1 for _ in body.iter(W + "tbl"))})
