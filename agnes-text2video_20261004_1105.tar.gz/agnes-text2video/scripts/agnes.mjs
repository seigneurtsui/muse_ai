#!/usr/bin/env node
/**
 * Shared Agnes AI API client
 *
 * Reads AGNES_API_KEY from environment. All calls go through this module
 * so auth and base URL are configured once.
 */

const BASE = 'https://apihub.agnes-ai.com/v1';

function getKey() {
  const key = process.env.AGNES_API_KEY;
  if (!key) {
    console.error('Error: AGNES_API_KEY is not set.');
    console.error('Create a .env file with: AGNES_API_KEY=sk-...');
    process.exit(1);
  }
  return key;
}

function headers() {
  return {
    'Authorization': `Bearer ${getKey()}`,
    'Content-Type': 'application/json',
  };
}

/**
 * POST /v1/images/generations
 */
export async function generateImage({ prompt, model, size }) {
  const body = {
    model: model || 'agnes-image-2.1-flash',
    prompt,
    size: size || '2048x2048',
  };

  const res = await fetch(`${BASE}/images/generations`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Image API ${res.status}: ${text}`);
  }

  return res.json();
}

/**
 * POST /v1/videos — create async video task
 */
export async function createVideoTask({ prompt, model, width, height, numFrames, frameRate, negativePrompt, image, extraBody }) {
  const body = {
    model: model || 'agnes-video-v2.0',
    prompt,
    width: width || 1920,
    height: height || 1080,
    num_frames: numFrames || 241,
    frame_rate: frameRate || 24,
    ...(negativePrompt ? { negative_prompt: negativePrompt } : {}),
    ...(image ? { image } : {}),
    ...(extraBody ? { extra_body: extraBody } : {}),
  };

  const res = await fetch(`${BASE}/videos`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Video API ${res.status}: ${text}`);
  }

  return res.json();
}

/**
 * GET /agnesapi?video_id={videoId} — poll video status (recommended)
 */
export async function pollVideoByVideoId(videoId) {
  const res = await fetch(`${BASE}/agnesapi?video_id=${encodeURIComponent(videoId)}`, {
    headers: headers(),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Poll API ${res.status}: ${text}`);
  }

  return res.json();
}

/**
 * GET /v1/videos/{taskId} — legacy polling
 */
export async function pollVideoByTaskId(taskId) {
  const res = await fetch(`${BASE}/videos/${encodeURIComponent(taskId)}`, {
    headers: headers(),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Poll API ${res.status}: ${text}`);
  }

  return res.json();
}

/**
 * POST /v1/chat/completions — text chat / prompt expansion
 */
export async function chat({ prompt, model }) {
  const body = {
    model: model || 'agnes-2.0-flash',
    messages: [{ role: 'user', content: prompt }],
  };

  const res = await fetch(`${BASE}/chat/completions`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Chat API ${res.status}: ${text}`);
  }

  return res.json();
}
