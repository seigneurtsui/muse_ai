---
name: r2explorer-share
description: "通过 API 在 R2 Explorer（disk.allez.cc.cd）上上传文件并生成公开分享链接：upload 上传文档、share 生成可设有效期/密码/下载次数的分享 URL、shares/revoke 管理链接。Use when the user wants to share a file via a public link, upload a document to disk.allez.cc.cd, or manage R2 share links."
---

# R2 Explorer Share

通过 API 工作模式在 `https://disk.allez.cc.cd`（R2 Explorer）上上传文档并生成公开分享链接。
完整 API 路由见 [references/api.md](references/api.md)。

## Purpose

用户说"分享文件/生成分享链接/传个文档到 disk"时使用：把本地文件上传到 bucket，
再按需生成带有效期、密码、下载次数限制的公开 URL。免登录访问，适合发给别人下载。

## Tooling

```bash
R2X=~/workspace/skills/r2explorer-share/bin/r2x.py
PY=python3   # 纯标准库

# 1) 检查连接与鉴权
$PY $R2X info

# 2) 上传本地文件（key 默认 = 文件名）
$PY $R2X upload /path/to/report.pdf --key docs/report.pdf

# 3) 生成分享链接（全可选：有效期/密码/下载次数）
$PY $R2X share docs/report.pdf --expires-in 86400 --password s3cret --max-downloads 10
# → {"shareId": "abc123xyz9", "shareUrl": "https://disk.allez.cc.cd/share/abc123xyz9?password=s3cret", ...}

# 4) 管理
$PY $R2X shares            # 列出所有分享链接
$PY $R2X revoke abc123xyz9 # 撤销
$PY $R2X ls docs/          # 列 bucket 对象（v1.2.0 上 500，不可用）
$PY $R2X download docs/report.pdf /tmp/report.pdf

# 5) 复制 / 文件夹改名（R2 底层不支持 move/rename，只能复制+删除；
#    本服务端 delete 接口 500，所以只做复制，原对象需手动删除）
$PY $R2X copy docs/a.pdf docs/b.pdf
$PY $R2X rename-folder MuseAI/old MuseAI/new --keys MuseAI/old/a.pdf MuseAI/old/b.pdf
```

## Auth

凭据**只从环境变量读取**，绝不写进代码、仓库、日志或记忆：

| 变量 | 说明 | 默认值 |
|---|---|---|
| `R2X_USER` | Basic Auth 用户名 | （必填） |
| `R2X_PASS` | Basic Auth 密码 | （必填） |
| `R2X_BASE_URL` | API 根地址 | `https://disk.allez.cc.cd` |
| `R2X_BUCKET` | 默认 bucket | `bucket` |

未设置 `R2X_USER`/`R2X_PASS` 时命令直接报错退出，不会裸奔请求。
敏感文件分享时务必加 `--password` 和 `--expires-in`（见 Operating Rules）。

## Workflow

1. **确认鉴权**：`r2x.py info` 返回 200 才继续；401 → 凭据错，找用户要新的。
2. **上传**：`upload <本地文件> --key <对象key>`。key 建议带目录前缀（如 `docs/`）。
3. **分享**：`share <key>` 按需加 `--expires-in`（秒）、`--password`、`--max-downloads`。
   有密码的链接输出已自动拼接 `?password=xxx`，直接发给对方即可。
4. **收尾**：把 `shareUrl` 给用户；如需回收用 `revoke`。

## Operating Rules

1. **分享链接默认永久有效**——临时分享必须显式传 `--expires-in`；敏感文档必须加 `--password`。
2. ✅ **服务端状态（2026-10-10 实测）**：`disk.allez.cc.cd` 已升级到 R2 Explorer **v1.2.0**，
   分享子系统恢复正常——`share`/`shares`/`revoke` 全部可用（分享接口为
   `POST /api/buckets/:bucket/:base64Key/share`，key 经 base64 编码放 path）。
   分享链接实测可直接下载文件内容。`upload`/`download`/`info` 均可用；
   `ls` 仍返回 500（服务端问题，暂不可用）。
3. `/share/:shareId` 免鉴权公开访问：分享前确认文件内容可公开；密码用 SHA-256 存储但 URL 里是明文参数，重要文件走"密码 + 有效期 + 下载次数"三件套。
4. 写操作（upload）若报 403，可能是服务端 `readonly` 模式，先确认再排查（本机实测 `readonly: false`）。
5. 上传大文件（>100MB）用分片接口（见 references/api.md），不要单次 POST 硬传。
6. 凭据问题一律找用户要，不猜测、不复用其他服务的密码。
