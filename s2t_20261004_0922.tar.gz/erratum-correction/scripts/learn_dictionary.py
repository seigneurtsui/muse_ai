#!/usr/bin/env python3
"""Collect observations, record explicit reviews, stage/publish/undo dictionary releases."""

from __future__ import annotations
import argparse
from pathlib import Path
import sys
from copy import deepcopy

from file_support import ErratumError, packed, read_json, sha, reason
from build_dictionary import SOURCE, OUTPUT, REPORT
from learning_store import (
    DEFAULT_STORE,
    collect_job,
    list_candidates,
    inspect_candidate,
    review_candidates,
    store_session,
    save_store,
    conflicts,
    refresh,
    now,
    MAX_RELEASES,
)


def stage_candidates(
    ids,
    store=DEFAULT_STORE,
    source_path=SOURCE,
    output_path=OUTPUT,
    report_path=REPORT,
    converter=None,
):
    from dictionary_releases import stage_release

    if (
        not isinstance(ids, list)
        or not 1 <= len(ids) <= 100
        or any(not isinstance(x, str) for x in ids)
        or len(set(ids)) != len(ids)
    ):
        raise ErratumError("select_1_to_100_unique_approved_candidates")
    with store_session(store) as (root, data):
        if len(data["releases"]) >= MAX_RELEASES:
            raise ErratumError("learning_release_limit")
        rows = []
        bindings = {}
        unique_rules = {}
        for identity in ids:
            item = data["candidates"].get(identity)
            if (
                item is None
                or item["status"] != "approved"
                or not item.get("approved_rule")
            ):
                raise ErratumError("candidate_not_human_approved")
            if (
                conflicts(data, item)
                and item["approved_rule"]["wrong"] == item["wrong"]
            ):
                raise ErratumError("candidate_has_unresolved_alternative_targets")
            rule = item["approved_rule"]
            if (
                rule["wrong"] in unique_rules
                and unique_rules[rule["wrong"]] != rule["right"]
            ):
                raise ErratumError("refined_rules_have_conflicting_targets")
            if rule["wrong"] not in unique_rules:
                rows.append(deepcopy(rule))
                unique_rules[rule["wrong"]] = rule["right"]
            bindings[identity] = item["revision"]
        descriptor = stage_release(
            rows,
            Path(source_path),
            Path(output_path),
            Path(report_path),
            root / "releases",
            converter=converter,
        )
        identity = descriptor["plan_id"]
        data["releases"][identity] = {
            "plan_id": identity,
            "release_dir": descriptor["release_dir"],
            "candidates": bindings,
            "status": "staged",
            "created_at": now(),
        }
        save_store(root, data)
    return {
        "status": "staged",
        "plan_id": identity,
        "release_dir": descriptor["release_dir"],
        "candidate_ids": ids,
        "rule_count": len(rows),
        "preview": descriptor["preview"],
        "targets": descriptor["targets"],
        "dictionary_changed": False,
        "instruction": "Review the local release preview. Publication requires explicit --execute --expect-plan matching this plan.",
    }


def release_summary(descriptor):
    # Explicit inspect/preview files, not routine stdout, reveal candidate text.
    return {
        key: descriptor[key]
        for key in (
            "status",
            "plan_id",
            "release_dir",
            "targets",
            "before",
            "after",
            "preview",
        )
    }


def transition_release(plan, operation, store=DEFAULT_STORE, execute=False):
    if not execute:
        raise ErratumError("dictionary_change_requires_explicit_execute")
    from dictionary_releases import (
        publish_release,
        rollback_release,
        recover_release,
        inspect_release,
    )

    operations = {
        "publish": publish_release,
        "rollback": rollback_release,
        "recover": recover_release,
    }
    if operation not in operations:
        raise ErratumError("unknown_release_operation")
    with store_session(store) as (root, data):
        record = data["releases"].get(plan)
        if record is None:
            raise ErratumError("release_not_staged_in_this_store")
        directory = Path(record["release_dir"])
        if not directory.resolve().is_relative_to(root / "releases"):
            raise ErratumError("release_outside_learning_store")
        actual = inspect_release(directory, plan)
        expected_status = {
            "publish": "published",
            "rollback": "rolled_back",
            "recover": "recovered",
        }[operation]
        already_done = actual["status"] == expected_status
        if operation == "publish" and not already_done:
            if record["status"] in ("rolled_back", "recovered"):
                raise ErratumError("terminal_release_requires_new_review_and_stage")
            for identity, reviewed_revision in record["candidates"].items():
                item = data["candidates"][identity]
                if (
                    item["status"] != "approved"
                    or item["revision"] != reviewed_revision
                ):
                    raise ErratumError("approval_changed_since_release_plan")
                if (
                    conflicts(data, item)
                    and item["approved_rule"]["wrong"] == item["wrong"]
                ):
                    raise ErratumError("candidate_has_unresolved_alternative_targets")
        if already_done and record["status"] == expected_status:
            # A retry must not undo a later human review after a finished rollback.
            return {
                "status": record["status"],
                "plan_id": plan,
                "release_dir": str(directory),
                "already_completed": True,
                "publication": release_summary(actual),
            }
        result = actual if already_done else operations[operation](directory, plan)
        old_record_status = record["status"]
        if operation == "publish":
            record["status"] = "published"
            for identity in record["candidates"]:
                item = data["candidates"][identity]
                if (
                    already_done
                    and item["status"] != "published"
                    and item["revision"] != record["candidates"][identity]
                ):
                    if (
                        "review_changed_after_publication_check_rollback"
                        not in item["flags"]
                    ):
                        item["flags"].append(
                            "review_changed_after_publication_check_rollback"
                        )
                item["status"] = "published"
                item["published_plan"] = plan
                refresh(item)
        else:
            record["status"] = "rolled_back" if operation == "rollback" else "recovered"
            for identity in record["candidates"]:
                item = data["candidates"][identity]
                if item.get("published_plan") not in (None, plan):
                    continue
                item["status"] = "rejected"
                item.pop("approved_rule", None)
                item.pop("published_plan", None)
                if old_record_status != record["status"]:
                    item["review_history"].append(
                        {
                            "decision": "reject",
                            "reason": "release_" + operation,
                            "at": now(),
                        }
                    )
                refresh(item)
        record["updated_at"] = now()
        save_store(root, data)
    return {
        "status": record["status"],
        "plan_id": plan,
        "release_dir": str(directory),
        "publication": release_summary(result),
    }


def release_status(plan, store=DEFAULT_STORE):
    from dictionary_releases import inspect_release

    with store_session(store) as (root, data):
        record = data["releases"].get(plan)
        if record is None:
            raise ErratumError("release_not_staged_in_this_store")
        directory = Path(record["release_dir"])
        if not directory.resolve().is_relative_to(root / "releases"):
            raise ErratumError("release_outside_learning_store")
        actual = inspect_release(directory, plan)
        return {
            "status": actual["status"],
            "ledger_status": record["status"],
            "plan_id": plan,
            "release_dir": str(directory),
            "targets": actual["targets"],
            "before": actual["before"],
            "after": actual["after"],
        }


def parser():
    p = argparse.ArgumentParser(
        description="经验只进候选池；显式复核、预览与授权后才更新通用词表。"
    )
    p.add_argument(
        "--store",
        type=Path,
        default=DEFAULT_STORE,
        help="私有经验库，不放进技能源码或公共仓库",
    )
    commands = p.add_subparsers(dest="command", required=True)
    c = commands.add_parser(
        "collect", help="只采集明确选定的已完成批次，绝不回扫历史目录"
    )
    c.add_argument("--job", type=Path, required=True)
    c = commands.add_parser("list", help="默认只显示标识和计数，不显示私密正文")
    c.add_argument("--show-text", action="store_true", help="明确显示候选原词/目标")
    c.add_argument("--offset", type=int, default=0)
    c.add_argument("--limit", type=int, default=100)
    c = commands.add_parser("inspect", help="显示指定候选及有限的私密上下文")
    c.add_argument("candidate_id")
    c = commands.add_parser("review", help="读入用户已明确确认的审核 JSON；不发布词表")
    c.add_argument("--file", type=Path, required=True)
    c = commands.add_parser("stage", help="只生成版本预览/快照，不改当前词表")
    c.add_argument("--ids-file", type=Path, required=True, help="JSON 候选 ID 数组")
    c.add_argument("--source", type=Path, default=SOURCE)
    c.add_argument("--output", type=Path, default=OUTPUT)
    c.add_argument("--report", type=Path, default=REPORT)
    c = commands.add_parser(
        "release-status", help="核验发布日志和实际词表哈希，不写词表"
    )
    c.add_argument("--expect-plan", required=True)
    for name in ("publish", "rollback", "recover"):
        c = commands.add_parser(name)
        c.add_argument("--expect-plan", required=True)
        c.add_argument("--execute", action="store_true")
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        if args.command == "collect":
            result = collect_job(args.job, args.store)
        elif args.command == "list":
            result = list_candidates(
                args.store, args.show_text, args.offset, args.limit
            )
        elif args.command == "inspect":
            result = inspect_candidate(args.candidate_id, args.store)
        elif args.command == "review":
            result = review_candidates(
                read_json(args.file.expanduser(), 1024 * 1024), args.store
            )
        elif args.command == "stage":
            result = stage_candidates(
                read_json(args.ids_file.expanduser(), 65536),
                args.store,
                args.source,
                args.output,
                args.report,
            )
        elif args.command == "release-status":
            result = release_status(args.expect_plan, args.store)
        else:
            result = transition_release(
                args.expect_plan, args.command, args.store, args.execute
            )
        code = 0
    except Exception as error:
        result = {"status": "error", "reason": reason(error)}
        code = 2
    print(packed(result).decode("utf-8"))
    return code


if __name__ == "__main__":
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", newline="")
    raise SystemExit(main())
