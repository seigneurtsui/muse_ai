---
name: rainman-travel
description: "Deep travel research workflow. Input a city name, auto-profiles the city's character, dynamically selects research dimensions, generates structured Markdown document + standalone HTML page + portable reference cards (PNG). Adapts to any city type: ancient capitals, coastal cities, ethnic regions, modern metropolises. Use when user says '旅行研究', '出发前功课', 'travel research', or provides a city name with intent to do deep travel preparation. Default output: ~/Downloads/rainman-travel"
user_invocable: true
version: "2.0.0"
---

# rainman-travel: 旅行研究

一条命令完成：城市画像 → 动态维度研究 → Markdown 文档 + HTML 页面 + 便携卡片。

方法论：**维度从城市本身生长出来**，不是把城市塞进固定框架。西安用考古框架，成都用美食框架，拉萨用宗教框架，威海用海洋框架——每座城市自带它该被研究的方式。

## 模式

**强制 NATIVE 模式。** 本 workflow 是多 skill 管道（城市画像 → 并行 Agent 研究 → rainman-card），不走 Algorithm 七步流程。

## 环境变量配置

```bash
# ~/.config/opencode/.env
VERCEL_TOKEN=your_vercel_token
```

## 参数

| 参数 | 说明 | 示例 |
|------|------|------|
| 城市名 | 必填，目标城市 | 西安、威海、成都、拉萨 |
| `-f` | 聚焦主题（可选） | `-f 川菜` `-f 甲午` `-f 藏传佛教` |
| `-q` | 快速模式，跳过内容提炼，只做研究+文档 | |
| 天数 | 行程天数（可选，默认3天） | `3天` `5天` |

## 执行

### 1. 城市画像（City Profiling）

这是与原版最关键的区别。**不直接进入研究，先判断这座城市的性格。**

用 WebSearch 快速搜索「{城市} 旅游特色」「{城市} 文化标签」，结合自身知识，从以下维度池中选出 **4—6 个最匹配的研究维度**：

**维度池（选，不是全做）：**

| 维度 | 触发信号 | 典型城市 |
|------|---------|---------|
| 历史分层 | 古都、朝代更迭、建都史 | 西安、洛阳、南京、北京 |
| 博物馆重点 | 有国家一级博物馆或特色专题馆 | 西安、故宫、三星堆 |
| 古建遗存 | 有全国重点文物保护单位、古建筑群 | 大同、平遥、泉州 |
| 考古发现 | 有重大考古遗址或正在进行的发掘 | 安阳、良渚、三星堆 |
| 宗教与信仰 | 佛教/道教/伊斯兰圣地、寺庙建筑群 | 拉萨、五台山、敦煌 |
| 美食体系 | 有独立的地方菜系或小吃文化 | 成都、潮汕、西安、长沙 |
| 海洋与海岸 | 沿海城市、渔业文化、海防历史 | 威海、厦门、泉州、舟山 |
| 自然地理 | 地质奇观、国家公园、特殊地貌 | 张家界、九寨沟、喀纳斯 |
| 民族与民俗 | 少数民族文化、非遗、节庆 | 丽江、大理、凤凰、西双版纳 |
| 近现代史 | 近代历史事件遗址、红色文化 | 威海、旅顺、延安、遵义 |
| 当代城市 | 建筑设计、艺术区、夜生活、咖啡/酒吧 | 上海、深圳、成都、重庆 |
| 人文脉络 | 重要历史人物、文学作品、地方文化性格 | （所有城市共享，但权重不同） |

**输出城市画像：**

```
城市：{城市名}
性格标签：{2—3个关键词，如"甲午之殇·道教圣山·海洋渔村"}
选定维度：{列出4—6个维度及选择理由}
排除维度：{哪些维度不适用及原因}
```

如有 `-f` 聚焦主题，该主题对应的维度必选，其余维度权重降低但不完全排除。

### 2. 并行研究（12 个 Agent）

根据步骤 1 选定的维度，生成研究提纲，启动 12 个并行 Agent（每个维度中英文各一个 Agent，加上通用的「深度内容发现」和「实用信息」Agent）。

**Agent 分配规则：**

- 每个选定维度分配 2 个 Agent（中文 + 英文），共用 8—10 个 Agent 槽位
- 1 个 Agent 固定分配给「深度内容发现」（B站/知乎/公众号/小红书搜索）
- 1 个 Agent 固定分配给「实用信息」（交通、住宿、门票、预约、当季注意事项）
- 剩余槽位分配给权重最高的维度做加深

**每个维度的研究提纲模板：**

```
对「{城市}」的「{维度名}」进行深度研究。这不是旅游攻略，是出发前的案头研究。

{根据维度类型生成具体研究问题，示例：}

【历史分层】经历哪些重要历史时期？每个时期留下什么物质遗存？
【博物馆】有哪些重要博物馆？镇馆之宝？具体文物名称和展厅位置？
【古建遗存】现存哪些重要古建筑？营造年代、形制、保护级别？看什么细节？
【美食体系】地方菜系的核心逻辑？必吃菜品的历史和讲究？去哪家吃？
【海洋与海岸】海岸线特征？渔业文化？海防历史？海洋地质？
【宗教与信仰】核心寺庙/道观？宗派传承？建筑特色？参拜礼仪？
【自然地理】地质成因？核心景观？最佳观赏时间和角度？
【民族与民俗】主要民族？核心非遗项目？节庆日历？禁忌？
【近现代史】重大历史事件？遗址现状？历史人物？
【当代城市】建筑地标？艺术区？本地人去的地方？

用 WebSearch 搜索以下关键词（每个都搜）：
{根据维度和城市生成6—8个具体搜索关键词}

返回详细的、有据可查的信息。不编造，没有确切信息就说明。
```

**深度内容发现 Agent 的搜索范围：**

搜索 B站、知乎、公众号、小红书上关于该城市 **所有选定维度** 的深度内容（不限于博物馆和古建）。筛选标准不变：要知识增量，不要打卡和软文。

**实用信息 Agent 的搜索范围：**

```
搜索「{城市}」的实用旅行信息：
- 交通：如何到达？市内交通方式？租车是否必要？
- 住宿：推荐住宿区域及理由？不同预算的选择？
- 门票与预约：核心景点门票价格？哪些需要提前预约？预约渠道？
- 当季信息：{当前月份}去的天气和穿衣？淡旺季？特殊注意事项？
- 行程节奏：各景点之间的距离和交通时间？一天能看几个？
```

### 3. 内容提炼（可选，同原版）

`-q` 快速模式跳过。否则对步骤 2 中发现的有效 URL 并行调用 ContentAnalysis 提取核心知识点。失败不阻塞。

### 4. 合成 Markdown 文档 + HTML 页面

**文档结构是动态的**，跟着步骤 1 选定的维度走。

**固定章节**（所有城市都有）：

```markdown
# {城市}旅行研究

> 生成日期：{当前日期}
> 性格标签：{步骤1的标签}

## 城市概览

这座城市的独特坐标——为什么值得去，去了看什么。


## {维度1章节}
...

## {维度2章节}
...

## {维度N章节}
...

## 实用信息
### 交通
### 住宿
### 门票与预约
### 当季贴士

## 参观路线
### 路线一：{主题名}（{预计时间}）
适合谁：{描述}
1. {地点} → 重点看/吃/体验 {什么}（{停留建议时间}）
2. ...

## 深度内容推荐
- **视频**：...
- **文章**：...
- **书籍**：...
```

**每个维度的章节模板参照其类型：**

- 博物馆 → 镇馆之宝 / 重点展厅 / 容易错过的
- 古建 → 形制概述 / 看什么
- 美食 → 菜系逻辑 / 必吃清单（菜名+去哪吃+为什么） / 避雷
- 海洋 → 海岸地理 / 渔业文化 / 海防历史
- 宗教 → 核心寺庙 / 宗派传承 / 参拜须知
- 自然 → 地质成因 / 核心景观 / 最佳时间角度
- 民族 → 文化背景 / 非遗项目 / 节庆日历 / 禁忌

**写作要求**（同原版）：
- 每个推荐必须有「为什么看/吃/去」和「具体怎么看/吃/去」
- 语气是给自己写的笔记，不是导游词
- 有确切信息写确切的，没有的不编

**文件命名**：`{YYYYMMDDTHHMMSS}==z--{城市}旅行研究.md`，保存到 `~/Downloads/rainman-travel/`

**同时生成 HTML 版本**：将 .md 文件转换为独立 HTML 页面（通过 `send-report.js`），保存为同名 `.html` 文件。默认采用 **water.css 极简排版**（与 `南京 · 城市知识档案` 页面一致），带自动生成目录导航（TOC）。

```bash
# 默认：water.css 页面模板（带 TOC 目录导航）
node {baseDir}/scripts/send-report.js {md文件路径} gc40800@gmail.com

# --email 参数：使用旧版邮件兼容模板（内联样式，适合邮件客户端）
node {baseDir}/scripts/send-report.js --email {md文件路径} gc40800@gmail.com
```

> 邮件发送内部始终使用 `--email` 模板。`--email` 参数仅控制本地 `.html` 文件的生成风格。

### 5. 铸造便携卡片（rainman-card）

并行铸造两张卡片：

**卡片 A — 城市概览（信息图 -i）：**

内容从 Markdown 文档提取：城市性格标签 + 各维度核心信息的精华摘要。一张图看懂这座城市。

**卡片 B — 参观路线速查（长图 -l）：**

参观路线建议 + 每个地点的核心看点/吃点 + 实用信息速查。手机上随时查看。

### 6. 邮件投递

将生成的 Markdown 报告自动发送到指定邮箱 `gc40800@gmail.com`。

**SMTP 配置**（预置，勿修改）：

| 参数 | 值 |
|------|-----|
| Host | smtp.qq.com |
| Port | 587 |
| User | 2826824650@qq.com |
| Pass | bmuvxqexvqqoddhe |
| From | Rainman Travel <2826824650@qq.com> |
| To | gc40800@gmail.com |

**执行方式**：

```bash
# 使用美化版邮件模板（推荐）
node {baseDir}/scripts/send-report.js "{md文件路径}" "gc40800@gmail.com"
```

或使用原始命令（简化版）：
```bash
node {baseDir}/../smtp-email/index.js send \
  --to "gc40800@gmail.com" \
  --subject "🗺️ {城市名}旅行研究" \
  --file "{md文件路径}" \
  --style blue
```

**注意**：
- 邮件投递失败**不阻塞**主流程，在汇总报告中标注失败状态即可
- 发送成功后，`~/Downloads/rainman-travel/delivery.log` 会记录投递历史
- 如需发送到其他邮箱，在调用时修改 `to` 参数

### 7. 汇总报告

```
════ 旅行研究完成 ═══════════════════════
🏛️ 城市: {城市名}
🏷️ 性格: {性格标签}
📝 知识文档: {.md 文件路径}
🌐 HTML 页面: {.html 文件路径}
🖼️ 概览卡: {PNG 文件路径}
🖼️ 路线卡: {PNG 文件路径}
📊 研究维度: {列出选定维度}
📎 深度内容: {X}个视频 | {Y}篇文章
📧 邮件投递: gc40800@gmail.com ✅
🌐 在线访问: https://city.allez.cc.cd ✅
```

### 8. 部署到 Vercel

```bash
bash {baseDir}/scripts/deploy-travel.sh "{html文件所在目录}"
```

**配置**：
| 配置项 | 值 |
|--------|-----|
| Vercel Project | `zhongnanshan-fakwo6mqy` |
| 域名 | `city.allez.cc.cd` |
| Scope | `seigneurtsuis-projects` |

**流程**：
1. 查找目录中最新的 HTML 文件
2. 部署到 Vercel 生产环境
3. 清理临时目录

> 仅部署，不产生本地备份。如需备份请使用 Step 10 的独立备份脚本。

**部署确认**：
```bash
echo "[$(date)] 已部署 {城市名} 到 https://city.allez.cc.cd — ✅" >> ~/Downloads/rainman-travel/delivery.log
```

### 9. 存档到 /toc/ 目录页

```bash
bash {baseDir}/scripts/deploy-subpath.sh "{html文件所在目录}"
```

**存档流程**：
1. 扫描目录中的 HTML 文件（子目录 index.html + 根 index.html）
2. 每个城市存档到 `/{slug}/` 子路径
3. 生成 `/toc/` 目录页（搜索、排序、分页、CSV 导出，自包含 HTML 模板）
4. 同步根页面到部署目录
5. 部署到 Vercel

**目录页功能**：
- 🔍 搜索：支持城市名、标签模糊匹配
- 📊 排序：最新优先 / 最早优先 / 名称 A→Z
- 📄 分页：12条/页，智能省略号
- 📥 导出：CSV 格式（含 BOM，Excel 兼容）

**访问地址**：
- 目录页：`https://city.allez.cc.cd/toc/`

### 10. 备份到本地存档（可选）

```bash
# 在线模式（默认）：从 Vercel 下载所有已发布的城市页面
bash {baseDir}/scripts/backup-travel.sh

# 本地模式：从 ~/Downloads/rainman-travel/ 拷贝
bash {baseDir}/scripts/backup-travel.sh --local

# 指定备份目录
bash {baseDir}/scripts/backup-travel.sh ~/my/backups
bash {baseDir}/scripts/backup-travel.sh --local ~/my/backups
```

**备份流程**：
1. **在线模式**：从 `https://city.allez.cc.cd/toc/` 下载目录页 → 解析所有城市链接 → 逐个下载
2. **本地模式**：从 `~/Downloads/rainman-travel/` 拷贝 `index-*.html` 历史备份、`index.html`、`.md` 文件
3. 生成 `MANIFEST.md` 备份清单
4. 打包为 `travel_{YYYYMMDD_HHMMSS}.tar.gz`
5. 保存到默认备份目录 `~/Downloads/rainman-travel-backups/`

> 此脚本独立于部署流程，可在任意时间执行。`--local` 模式需要之前产生了历史备份文件（如 `index-*.html`），否则只打包当前文件。

## 关键约束

- **步骤 1（城市画像）是灵魂**——维度选错，后面全偏。宁可多花30秒判断，不要机械套用
- 步骤 2 的 12 个 Agent 分配跟着维度走，不是固定6×2
- 「实用信息」Agent 是新增的，必须有——研究再深，不知道怎么去也白搭
- 美食维度不是"推荐餐厅"，是研究菜系背后的文化逻辑，然后才给出具体去处
- Markdown 文档是主产出，HTML 页面和卡片是衍生产出——文档质量优先
- 邮件投递为默认流程，自动执行，失败不阻塞主流程
- 不产出泛泛的旅游攻略，每个推荐必须有「为什么」和「具体怎么做」
- 中英文双语搜索，扩大覆盖面
- 没有确切信息时宁可留空，不编造

## Known Pitfalls

- 威海实测：原版6个固定文化维度遗漏了海洋文化、渔民民俗、海草房建筑、美食等威海真正独特的内容。新版通过城市画像动态选维度解决。
- rainman-card skill 首次使用需安装 playwright：`cd {baseDir} && npm install playwright && npx playwright install chromium`
- Research / ContentAnalysis skill 如不可用，直接用 Agent + WebSearch 替代，效果一致

### TOC 导航锚点失效

**症状**：页面顶部 TOC 导航链接点击无效，不跳转到对应章节。

**原因**：marked v18+ 默认不给标题标签（`<h1>`-`<h6>`）生成 `id` 属性。TOC 链接指向的 `#xxx` 锚点与实际渲染的 `<h2 id="xxx">` 不匹配时，点击无反应。旧版 `generateToc()` 函数用线性栈管理嵌套标签，在多级标题混排（如 `h2→h3→h2`）时还会产生多余 `<ul>` 导致布局混乱。

**修复方案**（`send-report.js`）：

1. **共享 slugify 函数**：定义一个 `slugify(text)` 函数，同时用于 TOC 链接生成和标题 ID 生成，确保两端一致：
   ```js
   function slugify(text) {
     return text.replace(/[`*_~]/g, '').trim().toLowerCase()
       .replace(/[^\w\u4e00-\u9fff]+/g, '-')
       .replace(/^-+|-+$/g, '');
   }
   ```

2. **marked 自定义渲染器**：使用 `marked.use({renderer: {heading({text, depth}) {...}}})` 将 `slugify(text)` 作为每个标题的 `id`：
   ```js
   marked.use({
     renderer: {
       heading({text, depth}) {
         return `<h${depth} id="${slugify(text)}">${text}</h${depth}>`;
       }
     }
   });
   ```

3. **TOC 树构建**：用递归建树代替线性栈管理嵌套：
   ```js
   function generateToc(mdContent) { /* build tree → parseFrom → renderNodes */ }
   ```
   - `parseFrom(idx, maxLevel)` 递归解析标题为树结构
   - `renderNodes(nodes)` 递归渲染嵌套 `<ul>`/`<li>`
   - 标签完全平衡，不产生多余嵌套

**验证方式**：`node -e "const html = fs.readFileSync(...); const tocLinks = html.match(/href=\"#[^\"]+\"/g); const headingIds = html.match(/id=\"[^\"]+\"/g); console.log('Missing:', tocLinks.filter(l => !html.includes(...)))"` — 输出 0 个缺失即为正常。

### TOC 导航层级缩进失效

**症状**：页面顶部的 TOC 目录中，h3 子章节与 h2 父章节显示在同一层级，没有缩进，视觉上扁平无层级。

**原因**：TOC 的 HTML 结构使用了扁平 `<ul>`，所有 `<li>` 平铺在一层。water.css 的 CSS 选择器 `nav#TOC > ul > li > ul` 依赖真正的嵌套 `<ul>` 结构来实现缩进：

```html
<!-- 错误：扁平结构，CSS 选择器不匹配 -->
<ul>
  <li><a href="#城市概览">城市概览</a></li>
  <li><a href="#自然地理">自然地理</a></li>
    <li><a href="#石林-世界喀斯特的教科书">石林——世界喀斯特的教科书</a></li>  <!-- 有空格但仍是同层 -->
</ul>

<!-- 正确：嵌套结构，CSS padding-left: 1.5em 生效 -->
<ul>
  <li><a href="#城市概览">城市概览</a></li>
  <li><a href="#自然地理">自然地理</a>
    <ul>
      <li><a href="#石林-世界喀斯特的教科书">石林——世界喀斯特的教科书</a></li>
    </ul>
  </li>
</ul>
```

**触发场景**：非 `send-report.js` 手动生成 HTML 时（如在 agent 对话中直接用 Python/Node 脚本组装 HTML），TOC 容易退化为扁平列表。

**修复方案**：

1. **递归建树**：解析标题后，用递归将 h2→h3 构建为嵌套树结构，不要用缩进空格模拟层级：

```javascript
function buildTocTree(headings, startIdx, parentLevel) {
  const items = [];
  let i = startIdx;
  while (i < headings.length) {
    const h = headings[i];
    if (h.level <= parentLevel) break;
    const res = buildTocTree(headings, i + 1, h.level);
    items.push({ ...h, children: res.items });
    i = res.nextIdx;
  }
  return { items, nextIdx: i };
}
```

2. **递归渲染**：父节点包含 `<a>` 链接 + 嵌套 `<ul>`，子节点只包含 `<a>` 链接：

```javascript
function renderToc(items) {
  if (!items || items.length === 0) return '';
  const out = [];
  for (const item of items) {
    if (item.children && item.children.length > 0) {
      out.push('<li><a href="#' + item.slug + '">' + item.text + '</a>\n'
        + renderToc(item.children) + '</li>');
    } else {
      out.push('<li><a href="#' + item.slug + '">' + item.text + '</a></li>');
    }
  }
  return '<ul>\n' + out.join('\n') + '\n</ul>';
}
```

3. **每个节点都生成 `<a>` 链接**（包括有子节点的 h2），确保锚点可点击。

4. **保持 slug 一致性**：TOC 中 `href="#{slug}"` 必须与 marked 标题渲染器生成的 `id="{slug}"` 使用同一 slugify 函数，参考上一条「TOC 导航锚点失效」的共享 slugify 方案。

**验证方式**：
```bash
node -e "
const html = require('fs').readFileSync('{html文件路径}', 'utf-8');
const tocMatch = html.match(/<nav[^>]*>[\s\S]*?<\/nav>/);
if (tocMatch) {
  const t = tocMatch[0];
  const ulCount = (t.match(/<ul>/g) || []).length;
  const liCount = (t.match(/<li>/g) || []).length;
  console.log(ulCount > 1 ? 'TOC 层级正确 ✓ (' + ulCount + ' ul, ' + liCount + ' li)' : 'TOC 扁平 ✗');
}
"
```
输出 `TOC 层级正确 ✓ (9 ul, 48 li)` 即为正常（`ul` 数量 > 1 表示有嵌套）。

**总原则**：永远使用 `send-report.js` 的 `generateToc` 函数生成 TOC，不要手动组装。`send-report.js` 已经有正确的递归算法。在 agent 对话中如果绕开 `send-report.js` 直接生成 HTML，必须实现等价的递归建树逻辑。
