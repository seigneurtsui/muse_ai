---
name: md-upload
description: "Batch upload .md files to any md2mindmap-compatible API. Dynamic URL selection with known presets and custom input."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [markdown, upload, mindmap, batch]
    category: productivity
---

# Markdown Upload

Batch upload markdown files to any md2mindmap-compatible API endpoint.

## Key Feature: Dynamic API URL

Unlike other upload skills with hardcoded endpoints, this tool supports:
- **Preset selection** — choose from known APIs by number
- **Custom URL** — input any compatible endpoint
- **Auto-complete** — type domain only, auto-appends `/api/upload`

## Commands

### Interactive Mode (推荐)
```bash
# 完全交互: 选择 API → 输入 Token
python ~/.hermes/skills/productivity/md-upload/scripts/md_upload.py ~/output

# 只指定 Token，交互选择 API
python ~/.hermes/skills/productivity/md-upload/scripts/md_upload.py ~/output --token eyJ...
```

### Direct Mode
```bash
# 指定全部参数
python ~/.hermes/skills/productivity/md-upload/scripts/md_upload.py ~/output \
  --url https://md.goallez.dpdns.org/api/upload \
  --token eyJhbGciOi...

# 域名简写（自动补全 /api/upload）
python ~/.hermes/skills/productivity/md-upload/scripts/md_upload.py ~/output \
  --url https://md3.allez.cc.cd \
  --token eyJ...
```

## Known API Presets

| # | Name | URL |
|---|------|-----|
| 1 | md2.allez | https://md2.allez.de5.net/api/upload |
| 2 | md3.allez | https://md3.allez.cc.cd/api/upload |
| 3 | goallez | https://md.goallez.dpdns.org/api/upload |

## Options

| Flag | Description |
|------|-------------|
| `--url`, `-u` | API 上传地址（不传则交互选择） |
| `--token`, `-t` | JWT Bearer Token（不传则交互输入） |

## Dependencies

- `requests`
