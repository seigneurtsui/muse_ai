"""Strict SRT parsing and safe, configurable ASS rendering (stdlib only).

Adapted from the user's srt2ass_batch.py: timing, bilingual rows, folding,
keyword highlighting, positioning and periodic overlays. No network code.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, fields, replace
import html
import math
from pathlib import Path
import re
import unicodedata


class SubtitleError(ValueError):
    pass


@dataclass(frozen=True)
class Cue:
    index: str
    start: int  # integer milliseconds
    end: int
    text: str


TIME = r"(\d{1,4}):([0-5]\d):([0-5]\d)[,.](\d{3})"
TIMELINE = re.compile(rf"^\s*{TIME}\s*-->\s*{TIME}\s*$")
MARKUP = re.compile(r"</?(?:b|i|u|s|font|span)(?:\s+[^<>]*)?\s*/?>", re.IGNORECASE)
EFFECTS = ("static", "fade", "slide-up", "slide-down", "slide-left", "slide-right", "pop", "blur", "karaoke", "typewriter")
EFFECT_ALIASES = {"slide-bottom": "slide-up", "slide-top": "slide-down"}


def read_text(path: Path) -> tuple[str, str]:
    if path.stat().st_size > 32 * 1024 * 1024:
        raise SubtitleError("input exceeds the 32 MiB safety limit")
    raw = path.read_bytes()
    encodings = ("utf-16",) if raw.startswith((b"\xff\xfe", b"\xfe\xff")) else ("utf-8-sig", "gb18030")
    for encoding in encodings:
        try:
            result = raw.decode(encoding)
            if "\x00" in result:
                raise SubtitleError("NUL characters found; UTF-16 inputs need a byte-order mark")
            return result, encoding
        except UnicodeError:
            continue
    raise SubtitleError("cannot decode input as UTF-8, BOM-marked UTF-16 or GB18030")


def parse_srt(text: str) -> list[Cue]:
    text = text.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n").strip()
    if not text:
        raise SubtitleError("empty SRT")
    cues, seen = [], set()
    for block_number, block in enumerate(re.split(r"\n[ \t]*\n+", text), 1):
        lines = block.splitlines()
        has_index = bool(lines and re.fullmatch(r"\d+", lines[0].strip()))
        index = lines[0].strip() if has_index else str(block_number)
        at = 1 if has_index else 0
        match = TIMELINE.fullmatch(lines[at]) if len(lines) > at else None
        if not match or len(lines) <= at + 1:
            raise SubtitleError(f"block {block_number}: invalid timestamp or missing subtitle text")
        numbers = list(map(int, match.groups()))
        start, end = [((numbers[i] * 60 + numbers[i + 1]) * 60 + numbers[i + 2]) * 1000 + numbers[i + 3] for i in (0, 4)]
        content = "\n".join(line.rstrip() for line in lines[at + 1:]).strip()
        if any(TIMELINE.fullmatch(line) for line in lines[at + 1:]):
            raise SubtitleError(f"block {block_number}: missing blank separator between cues")
        if end <= start:
            raise SubtitleError(f"block {block_number}: end must be later than start")
        if not content or not plain_text(content).strip():
            raise SubtitleError(f"block {block_number}: empty visible subtitle text")
        if index in seen:
            raise SubtitleError(f"block {block_number}: duplicate subtitle index")
        if any(ord(c) < 32 and c not in "\n\t" for c in content):
            raise SubtitleError(f"block {block_number}: invalid control character")
        seen.add(index)
        cues.append(Cue(index, start, end, content))
    return cues


def plain_text(text: str) -> str:
    return html.unescape(MARKUP.sub("", text)).replace("\r\n", "\n").replace("\r", "\n")


def srt_time(milliseconds: int) -> str:
    hours, remainder = divmod(milliseconds, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    seconds, fraction = divmod(remainder, 1000)
    return f"{hours:02}:{minutes:02}:{seconds:02},{fraction:03}"


def ass_time(milliseconds: int, end=False) -> str:
    # Expand the end to the next centisecond rather than introduce float drift.
    cs = (milliseconds + (9 if end else 0)) // 10
    hours, remainder = divmod(cs, 360_000)
    minutes, remainder = divmod(remainder, 6000)
    seconds, fraction = divmod(remainder, 100)
    return f"{hours}:{minutes:02}:{seconds:02}.{fraction:02}"


def srt_text(cues: list[Cue], rows: list[list[str]]) -> str:
    if len(rows) != len(cues) or any(not row or any(not isinstance(v, str) or not v.strip() for v in row) for row in rows):
        raise SubtitleError("incomplete language rows; refusing partial output")
    return "\n\n".join(f"{cue.index}\n{srt_time(cue.start)} --> {srt_time(cue.end)}\n" + "\n".join(row) for cue, row in zip(cues, rows)) + "\n"


def ass_color(value: str) -> str:
    """RRGGBB / AARRGGBB (AA = ASS transparency) -> &HAABBGGRR."""
    if not isinstance(value, str):
        raise SubtitleError("color must be a string")
    value = value.strip().upper()
    if re.fullmatch(r"&H(?:[0-9A-F]{6}|[0-9A-F]{8})&?", value):
        return "&H" + value[2:].rstrip("&").zfill(8)
    raw = value.lstrip("#")
    if not re.fullmatch(r"(?:[0-9A-F]{6}|[0-9A-F]{8})", raw):
        raise SubtitleError("invalid color; use RRGGBB, AARRGGBB or &HAABBGGRR")
    alpha, rgb = (raw[:2], raw[2:]) if len(raw) == 8 else ("00", raw)
    return f"&H{alpha}{rgb[4:6]}{rgb[2:4]}{rgb[:2]}"


def color_tags(color: str) -> str:
    color = ass_color(color)[2:]
    return f"\\1c&H{color[2:]}&\\1a&H{color[:2]}&"


def ass_escape(text: str) -> str:
    # ASS has no portable literal escaping for every override/parser combination.
    # Full-width equivalents prevent untrusted source/AI text becoming override code.
    return text.replace("\\", "＼").replace("{", "｛").replace("}", "｝").replace("\t", " ").replace("\n", r"\N")


def safe_font(name: str) -> str:
    if not isinstance(name, str) or not name.strip() or any(c in name for c in ",\\{}\r\n") or any(ord(c) < 32 for c in name):
        raise SubtitleError("font names must be nonempty and cannot contain commas, braces, backslashes or controls")
    return name


@dataclass(frozen=True)
class Style:
    width: int = 1920
    height: int = 1080
    font_name: str = "Arial"
    font_size: int = 64
    secondary_font: str = "Arial"
    secondary_size: int = 44
    primary_color: str = "FFFFFF"
    secondary_color: str = "DCE6F0"
    karaoke_color: str = "687080"
    outline_color: str = "101018"
    back_color: str = "80000000"
    outline: float = 3
    shadow: float = 1
    bold: bool = True
    position: str = "bottom"
    margin_x: int = 80
    margin_y: int = 65
    wrap: int = 26  # CJK-width cells; Latin glyphs average half a cell
    min_font_size: int = 16
    effect: str = "fade"
    animation_ms: int = 280
    fade_in_ms: int = 180
    fade_out_ms: int = 140
    glow: float = 0
    highlight_color: str = "FFD166"
    highlight_scale: float = 1.12
    highlight_font: str = ""
    overlay_text: str = ""
    overlay_interval: int = 300
    overlay_duration: int = 6

    @classmethod
    def from_mapping(cls, mapping: dict) -> Style:
        if not isinstance(mapping, dict) or set(mapping) - {field.name for field in fields(cls)}:
            raise SubtitleError("unknown style field or invalid style JSON object")
        if "effect" in mapping:
            if not isinstance(mapping["effect"], str):
                raise SubtitleError("effect must be a string")
            mapping = {**mapping, "effect": EFFECT_ALIASES.get(mapping["effect"], mapping["effect"])}
        result = cls(**mapping)
        result.validate()
        return result

    def validate(self):
        integer_ranges = {"width": (160, 8192), "height": (160, 8192), "font_size": (8, 600), "secondary_size": (8, 600),
                          "min_font_size": (6, 200), "margin_x": (0, 3000), "margin_y": (0, 3000), "wrap": (0, 300),
                          "animation_ms": (0, 10000), "fade_in_ms": (0, 10000), "fade_out_ms": (0, 10000),
                          "overlay_interval": (1, 86400), "overlay_duration": (1, 3600)}
        for key, (low, high) in integer_ranges.items():
            value = getattr(self, key)
            if type(value) is not int or not low <= value <= high:
                raise SubtitleError(f"{key} must be an integer in [{low}, {high}]")
        for key, low, high in (("outline", 0, 30), ("shadow", 0, 30), ("glow", 0, 30), ("highlight_scale", 1, 2)):
            value = getattr(self, key)
            if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
                raise SubtitleError(f"{key} must be a number in [{low}, {high}]")
        for key in ("font_name", "secondary_font"):
            safe_font(getattr(self, key))
        if not isinstance(self.highlight_font, str):
            raise SubtitleError("highlight_font must be a string")
        if self.highlight_font:
            safe_font(self.highlight_font)
        for key in ("primary_color", "secondary_color", "karaoke_color", "outline_color", "back_color", "highlight_color"):
            ass_color(getattr(self, key))
        if type(self.bold) is not bool or self.position not in ("bottom", "top", "center") or self.effect not in EFFECTS:
            raise SubtitleError("invalid bold, position or effect")
        if self.margin_x * 2 + 30 >= self.width or self.margin_y * 2 + 30 >= self.height:
            raise SubtitleError("margins leave no usable canvas")
        if self.min_font_size > min(self.font_size, self.secondary_size):
            raise SubtitleError("min_font_size cannot exceed either subtitle font size")
        if not isinstance(self.overlay_text, str) or len(self.overlay_text) > 200 or any(ord(c) < 32 for c in self.overlay_text):
            raise SubtitleError("overlay text must be one line, at most 200 characters")


def graphemes(text: str) -> list[str]:
    """Small stdlib approximation: keep combining marks, emoji modifiers and ZWJ attached."""
    result = []
    for char in text:
        attached = unicodedata.combining(char) or char in ("\ufe0e", "\ufe0f", "\u200d") or 0x1F3FB <= ord(char) <= 0x1F3FF
        if result and (attached or result[-1].endswith("\u200d")):
            result[-1] += char
        else:
            result.append(char)
    return result


def cell_width(cluster: str) -> int:
    return max((2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in cluster if not unicodedata.combining(c) and c not in "\u200d\ufe0e\ufe0f"), default=0)


def fold_text(text: str, max_cells: int) -> list[str]:
    if max_cells < 2:
        raise SubtitleError("canvas is too narrow for the selected font")
    lines = []
    for paragraph in text.split("\n"):
        clusters = graphemes(re.sub(r"[ \t\u3000]+", " ", paragraph).strip())
        current, width, last_space = [], 0, -1
        for cluster in clusters:
            unit = cell_width(cluster)
            if current and width + unit > max_cells:
                if last_space > 0:
                    lines.append("".join(current[:last_space]).rstrip())
                    current = current[last_space + 1:]
                else:
                    lines.append("".join(current).rstrip())
                    current = []
                width = sum(cell_width(c) for c in current)
                last_space = max((i for i, c in enumerate(current) if c == " "), default=-1)
            if not current and cluster == " ":
                continue
            current.append(cluster)
            width += unit
            if cluster == " ":
                last_space = len(current) - 1
        if current:
            lines.append("".join(current).rstrip())
    return lines or [""]


class Highlighter:
    def __init__(self, keywords: list[str], ignore_case=False):
        values = set()
        for word in keywords:
            if not isinstance(word, str) or not word.strip() or len(word) > 200 or any(ord(c) < 32 for c in word):
                raise SubtitleError("highlight keywords must be nonempty, single-line strings of at most 200 characters")
            values.add(word.strip())
        if len(values) > 1000:
            raise SubtitleError("at most 1000 highlight keywords are supported")
        self.keywords = sorted(values, key=lambda v: (-len(v), v))
        self.regex = re.compile("|".join(re.escape(k) for k in self.keywords), re.IGNORECASE if ignore_case else 0) if values else None

    def spans(self, text):
        return [(m.start(), m.end()) for m in self.regex.finditer(text)] if self.regex else []


@dataclass(frozen=True)
class Row:
    text: str
    font: str
    size: int
    color: str


def layout(segments: list[str], style: Style, highlighter: Highlighter) -> tuple[list[Row], float, bool]:
    scale, padding = 1.0, 2 * (style.outline + style.shadow + style.glow + 3)
    available_h = style.height - 2 * style.margin_y - padding
    for _ in range(30):
        rows = []
        for i, segment in enumerate(segments):
            base = style.font_size if i == 0 else style.secondary_size
            size = max(style.min_font_size, int(base * scale))
            font = style.font_name if i == 0 else style.secondary_font
            color = style.primary_color if i == 0 else style.secondary_color
            pixels = style.width - 2 * style.margin_x - padding
            max_cells = max(2, int(pixels / (size * 0.58 * style.highlight_scale)))
            if style.wrap:
                max_cells = min(max_cells, max(2, int(style.wrap * 2 * style.font_size / size)))
            for line in fold_text(plain_text(segment), max_cells):
                rows.append(Row(line, font, size, color))
        block_h = sum(row.size * 1.3 * (style.highlight_scale if highlighter.spans(row.text) else 1) for row in rows)
        if block_h <= available_h:
            return rows, block_h, scale < 1
        if all(row.size == style.min_font_size for row in rows):
            raise SubtitleError("subtitle is too tall even at min_font_size; split the cue or increase canvas size")
        scale *= max(0.5, min(0.9, available_h / max(block_h, 1)))
    raise SubtitleError("cannot fit subtitle safely inside the frame")


def row_tags(row: Row) -> str:
    return f"\\fn{row.font}\\fs{row.size}" + color_tags(row.color)


def timed_units(text: str) -> list[tuple[int, int]]:
    """Latin words (with following space), CJK/emoji graphemes; no audio alignment."""
    units, offset, word_start = [], 0, None
    for cluster in graphemes(text):
        is_word = cluster[0].isascii() and (cluster[0].isalnum() or cluster[0] in "'-")
        if is_word:
            if word_start is None:
                word_start = offset
        elif cluster.isspace() and word_start is not None:
            units.append((word_start, offset + len(cluster)))
            word_start = None
        else:
            if word_start is not None:
                units.append((word_start, offset))
                word_start = None
            units.append((offset, offset + len(cluster)))
        offset += len(cluster)
    if word_start is not None:
        units.append((word_start, len(text)))
    return units


def rich_row(row: Row, highlighter: Highlighter, style: Style, timing: dict[int, str] | None = None) -> str:
    spans = highlighter.spans(row.text)
    starts = {a: b for a, b in spans}
    ends = {b for a, b in spans}
    timing = timing or {}
    boundaries = sorted({0, len(row.text), *starts, *ends, *timing})
    parts = ["{" + row_tags(row) + "}"]
    active_timing = ""
    for a, b in zip(boundaries, boundaries[1:]):
        if a in ends:
            # Never use \r: it would reset position/motion/animation and bilingual font.
            parts.append("{" + row_tags(row) + "}")
        if a in starts:
            parts.append("{" + color_tags(style.highlight_color) + f"\\fs{round(row.size * style.highlight_scale)}" + (f"\\fn{style.highlight_font}" if style.highlight_font else "") + "}")
        if a in timing:
            active_timing = timing[a]
        if a in timing or (style.effect == "typewriter" and active_timing):
            parts.append("{" + active_timing + "}")
        parts.append(ass_escape(row.text[a:b]))
    return "".join(parts)


def rendered_rows(rows: list[Row], highlighter: Highlighter, style: Style, duration_cs: int) -> str:
    timing = [{} for row in rows]
    if style.effect in ("karaoke", "typewriter"):
        units = [(i, a, b, max(1, sum(cell_width(c) for c in graphemes(row.text[a:b])))) for i, row in enumerate(rows) for a, b in timed_units(row.text)]
        total_weight = sum(weight for _, _, _, weight in units) or 1
        previous, weight_so_far = 0, 0
        for i, start, end, weight in units:
            weight_so_far += weight
            point = duration_cs * weight_so_far // total_weight
            if style.effect == "karaoke":
                timing[i][start] = f"\\kf{point - previous}"
            else:
                reveal = int(previous * 10 * 0.85)
                timing[i][start] = f"\\alpha&HFF&\\t({reveal},{reveal + 1},\\alpha&H00&)"
            previous = point
    return r"\N".join(rich_row(row, highlighter, style, marks) for row, marks in zip(rows, timing))


def animation(style: Style, duration_ms: int) -> str:
    x = style.width // 2
    if style.position == "top":
        alignment, y = 8, style.margin_y
    elif style.position == "center":
        alignment, y = 5, style.height // 2
    else:
        alignment, y = 2, style.height - style.margin_y
    length = min(style.animation_ms, max(1, duration_ms // 2))
    tag = f"\\an{alignment}"
    if style.effect.startswith("slide-") and length > 0:
        dx, dy = {"slide-up": (0, 120), "slide-down": (0, -120), "slide-left": (160, 0), "slide-right": (-160, 0)}[style.effect]
        tag += f"\\move({x + dx},{y + dy},{x},{y},0,{length})"
    else:
        tag += f"\\pos({x},{y})"
    fade_in = min(style.fade_in_ms, duration_ms // 2)
    fade_out = min(style.fade_out_ms, duration_ms // 2)
    if style.effect not in ("static", "typewriter") and (fade_in or fade_out):
        tag += f"\\fad({fade_in},{fade_out})"
    if style.effect == "pop" and length:
        tag += f"\\fscx75\\fscy75\\t(0,{length},\\fscx100\\fscy100)"
    elif style.effect == "blur" and length:
        tag += f"\\blur8\\t(0,{length},\\blur0)"
    return tag


def style_line(name: str, style: Style, *, glow=False) -> str:
    return f"Style: {name},{style.font_name},{style.font_size},{ass_color(style.primary_color)},{ass_color(style.karaoke_color if style.effect == 'karaoke' else style.secondary_color)},{ass_color(style.outline_color)},{ass_color(style.back_color)},{-1 if style.bold else 0},0,0,0,100,100,0,0,1,{style.outline + (3 if glow else 0)},{style.shadow},2,{style.margin_x},{style.margin_x},{style.margin_y},1"


def render_ass(cues: list[Cue], segments: list[list[str]], style: Style, keywords: list[str] | None = None, ignore_case=False) -> tuple[str, dict]:
    style.validate()
    if len(cues) != len(segments) or not cues or any(not row or any(not isinstance(text, str) or not text.strip() for text in row) for row in segments):
        raise SubtitleError("ASS requires complete nonempty cue/language rows")
    if len({len(row) for row in segments}) != 1:
        raise SubtitleError("inconsistent language counts between cues")
    highlighter = Highlighter(keywords or [], ignore_case)
    output = ["[Script Info]", "Title: SRT ASS Studio", "ScriptType: v4.00+", "WrapStyle: 2", "ScaledBorderAndShadow: yes",
              f"PlayResX: {style.width}", f"PlayResY: {style.height}", "", "[V4+ Styles]",
              "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
              style_line("Default", style), style_line("Glow", style, glow=True), "", "[Events]",
              "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"]
    resized, overlaps, events = 0, 0, 0
    previous_end = 0
    for cue, row_segments in zip(cues, segments):
        if cue.start < 0 or cue.end <= cue.start:
            raise SubtitleError("invalid cue timing")
        rows, height, shrunk = layout(row_segments, style, highlighter)
        resized += int(shrunk)
        overlaps += int(cue.start < previous_end)
        previous_end = max(previous_end, cue.end)
        start, end = ass_time(cue.start), ass_time(cue.end, end=True)
        duration_cs = (cue.end + 9) // 10 - cue.start // 10
        tags = animation(style, duration_cs * 10)
        text = rendered_rows(rows, highlighter, style, duration_cs)
        if style.glow:
            output.append(f"Dialogue: 0,{start},{end},Glow,,0,0,0,,{{{tags}\\blur{style.glow}}}{text}")
            events += 1
        output.append(f"Dialogue: 1,{start},{end},Default,,0,0,0,,{{{tags}}}{text}")
        events += 1
    overlay_count = 0
    if style.overlay_text:
        maximum = max(cue.end for cue in cues)
        if maximum // (style.overlay_interval * 1000) > 10000:
            raise SubtitleError("overlay would exceed 10000 events; increase its interval")
        overlay_size = min(style.secondary_size, max(8, int((style.width - 2 * style.margin_x) / max(1, sum(cell_width(c) for c in graphemes(style.overlay_text))) / 0.6)))
        for start in range(style.overlay_interval * 1000, maximum, style.overlay_interval * 1000):
            end = min(maximum, start + style.overlay_duration * 1000)
            duration = end - start
            fade = min(200, duration // 2)
            tags = f"\\an9\\pos({style.width - style.margin_x},{style.margin_y})\\fs{overlay_size}\\fad({fade},{fade})"
            output.append(f"Dialogue: 10,{ass_time(start)},{ass_time(end, end=True)},Default,,0,0,0,,{{{tags}}}{ass_escape(style.overlay_text)}")
            overlay_count += 1
    return "\n".join(output) + "\n", {"cues": len(cues), "events": events + overlay_count, "overlay_events": overlay_count,
                                          "resized_cues": resized, "overlapping_cues": overlaps, "effect": style.effect}
