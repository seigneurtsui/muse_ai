---
name: edge-tts
description: "Microsoft Edge 免费 TTS 语音合成。支持中英文多音色、语速/音量调节、批量生成、SRT/ASS字幕、语义断句、长文本分段合成。Use when user asks for TTS, text-to-speech, voice synthesis, 语音合成, 文字转语音, or needs to generate audio from text."
version: 2.1.0
metadata:
  needs:
    pythonPackages:
      - edge-tts
---

# edge-tts

基于 Microsoft Edge 免费 TTS 服务的语音合成技能，无需本地语音模型。语音合成仍使用 Edge 云端服务；语义断句、字幕翻译、关键字提取和 AI 标点处理统一调用已登录的 OmniRush CLI 内置模型，不使用额外的 AI API Key、第三方 LLM 服务或自定义端点。

## 功能特性

- **多语言支持**: 中文 (10+ 音色)、英文 (4+ 音色)
- **实时合成**: 无需等待模型加载，毫秒级响应
- **批量生成**: 支持多段文本并行合成
- **参数调节**: 语速 (-50% ~ +100%)、音量 (-50% ~ +100%)
- **SRT 字幕**: 自动生成带时间戳的字幕文件
- **ASS 字幕**: 自动生成带特效的 ASS 字幕 (滑入/淡入/位置可调)
- **语义断句**: AI 语义断句 + 标点感知分段，长文本自动切分
- **长文本合成**: 超长文本自动分段 → 逐段合成 → 音频拼接
- **格式输出**: MP3 (默认)、WAV

## 前置要求

```bash
pip install edge-tts
# 可选: 音频拼接增强
pip install pydub
```

## AI 文本功能：复用 OmniRush 登录与当前模型

```bash
omnirush login  # 已登录则不必重复登录；纯语音合成不需要此步骤
```

- AI 调用使用原生 OmniRush CLI 的非交互 JSON 模式（`--engine pi --provider omnirush --print --mode json`），固定使用内置服务并复用 CLI 已登录账户。技能不打开登录凭据文件、不读取 AI API Key，也不配置 AI 服务地址。
- 在 OmniRush 会话中运行时，继承 `OMNIRUSH_MODEL`（以及存在时的 `OMNIRUSH_REASONING_LEVEL`），不切换账户或固定为另一模型。会校验返回模型；不匹配、截断或失败的回答不会冒充成功。独立终端运行时遵循 CLI 的 `OMNIRUSH_MODEL` / 默认模型规则；不会猜测另一个进程中未导出的模型选择。
- 默认优先使用 `~/.npm-global/bin/omnirush`，否则在 PATH 查找。此安装的 `~/.omnirush/agent/bin/omnirush` 包装脚本会额外注入 `--skill`，因此不用于 AI 子进程。其他安装位置可通过非密钥变量 `EDGE_TTS_OMNIRUSH_BIN=/absolute/path/to/native/omnirush` 指定；必须是支持上述参数、不额外加载技能/扩展的原生 CLI，不是其他 AI 工具。
- 每次调用禁用工具、扩展、技能、提示模板、主题和 AGENTS/CLAUDE 上下文；在临时空目录运行，正文经 stdin 传入，不放在进程参数或临时提示文件中。使用 `--no-session`，不保存子会话历史；不会继续或修改父会话。仅读取完成的 assistant 文本，忽略进度、增量和 thinking。
- 默认每次超时 180 秒，可用 `EDGE_TTS_AI_TIMEOUT=60` 调整（1–600 秒）；最多尝试 3 次，短暂退避。超时会停止启动器及其引擎子进程。CLI 登录失败、缺失或响应无效时，语义分段回退本地规则；高亮跳过、标点按本地回退模式处理；真正需要翻译的字幕明确报错，绝不拿原文冒充译文。
- **隐私 / 网络：** 内置模型仍通过已登录 OmniRush 服务联网，发送启用 AI 功能所需的文本，计入同一账户用量；不是离线 LLM。技能不写 AI 提示/原始响应文件，也不打印子进程 stderr 或 thinking，但正常音频、字幕、用户指定的高亮关键字文件仍会输出。CLI 自己可能更新登录/模型元数据；本流程禁用自动升级与崩溃报告，不承诺服务端零保留。

当前脚本在未指定手动关键字输入时会自动尝试 AI 高亮提取（即使没有 `--ass`）；标点默认 `ai`。如果只需云端 TTS 且完全不调用 LLM，提供空关键字文件、不加 `--semantic`，并选择本地标点模式：

```bash
# 使用本地现有空文件，或新建一个空关键字文件
: > empty-keywords.txt
python3 {baseDir}/scripts/tts.py "仅语音合成" \
  --highlight-keyword-file empty-keywords.txt --punctuation-mode keep \
  -o ~/Downloads/speech.mp3
```

具体用法见 [scripts/usage.md](scripts/usage.md)，离线回归测试：

```bash
python3 -B -m unittest discover -s {baseDir}/tests -v
```

## 可用音色

### 中文音色

| 音色 ID | 性别 | 风格 |
|---------|------|------|
| `zh-CN-XiaoxiaoNeural` | 女 | 温柔 (默认女声) |
| `zh-CN-XiaoyiNeural` | 女 | 活泼 |
| `zh-CN-XiaohanNeural` | 女 | 知性 |
| `zh-CN-XiaomengNeural` | 女 | 甜美 |
| `zh-CN-XiaoruiNeural` | 女 | 成熟 |
| `zh-CN-XiaoshuangNeural` | 女 | 童声 |
| `zh-CN-YunxiNeural` | 男 | 阳光 (默认男声) |
| `zh-CN-YunjianNeural` | 男 | 磁性 |
| `zh-CN-YunyangNeural` | 男 | 新闻播报 |
| `zh-CN-YunxiaNeural` | 男 | 少年 |

### 英文音色

| 音色 ID | 性别 | 风格 |
|---------|------|------|
| `en-US-JennyNeural` | 女 | 自然 (默认) |
| `en-US-GuyNeural` | 男 | 自然 |
| `en-GB-SoniaNeural` | 女 | 英式 |
| `en-GB-RyanNeural` | 男 | 英式 |

## 使用方法

### 基础用法 - 单句合成

```bash
python3 {baseDir}/scripts/tts.py "你好，欢迎使用语音合成"
```

### 指定音色

```bash
# 中文男声
python3 {baseDir}/scripts/tts.py -v zh-CN-YunxiNeural "这是阳光男声"

# 英文女声
python3 {baseDir}/scripts/tts.py -v en-US-JennyNeural "Hello world"
```

### 调节语速和音量

```bash
# 加速 20%
python3 {baseDir}/scripts/tts.py -r "+20%" "加速播放"

# 减速 30%
python3 {baseDir}/scripts/tts.py -r "-30%" "减速播放"

# 音量加倍
python3 {baseDir}/scripts/tts.py -V "+50%" "大音量"
```

### 指定输出路径

```bash
python3 {baseDir}/scripts/tts.py -o ~/Downloads/speech.mp3 "保存到指定路径"
```

### 生成 SRT 字幕

```bash
python3 {baseDir}/scripts/tts.py --srt "这是带字幕的语音" -o ~/Downloads/
```

### 生成 ASS 字幕 (含特效)

```bash
# 默认: 底部滑入特效
python3 {baseDir}/scripts/tts.py --ass "带特效字幕" -o ~/Downloads/

# 同时生成 SRT + ASS
python3 {baseDir}/scripts/tts.py --srt --ass "双格式字幕" -o ~/Downloads/
```

### 批量生成

```bash
# 从文件读取 (每行一句)
python3 {baseDir}/scripts/tts.py -f input.txt -o ~/Downloads/tts_output/

# 批量生成并生成字幕
python3 {baseDir}/scripts/tts.py -f input.txt --srt --ass -o ~/Downloads/tts_output/
```

### 长文本分段合成

```bash
# 标点感知自动分段 (文本超过 max_chars 自动触发)
python3 {baseDir}/scripts/tts.py -f long_article.txt -o output.mp3

# 显式启用标点分段
python3 {baseDir}/scripts/tts.py -f long_article.txt --split --max-chars 3000 -o output.mp3

# OmniRush 内置模型语义断句 (需已登录 CLI 和网络)
python3 {baseDir}/scripts/tts.py -f long_article.txt --semantic --srt --ass -o output.mp3

# 自定义段间静音
python3 {baseDir}/scripts/tts.py -f long_article.txt --split --gap-ms 500 -o output.mp3
```

## CLI 参数

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `text` | 要合成的文本 (位置参数) | - |
| `-v, --voice` | 音色 ID | `zh-CN-YunxiNeural` |
| `-r, --rate` | 语速 (如 `+20%`, `-30%`) | `+0%` |
| `-V, --volume` | 音量 (如 `+50%`) | `+0%` |
| `-o, --output` | 输出路径 (文件或目录) | `~/Downloads/edge-tts/` |
| `-f, --file` | 从文件读取文本 | - |
| `--srt` | 生成 SRT 字幕 | false |
| `--ass` | 生成 ASS 字幕 (含特效) | false |
| `--prefix` | 批量输出文件名前缀 | `segment` |
| `--split` | 启用标点感知分段 | false |
| `--semantic` | 启用 OmniRush 内置模型语义断句 | false |
| `--languages` | 1 或 2 个目标字幕语言，如 `zh-Hant,en` | `zh-Hant` |
| `--highlight-keyword-file` | 手动关键字文件；空文件可禁用 AI 高亮提取 | - |
| `--punctuation-mode` | 字幕标点 `ai` / `keep` / `trim-edge` / `remove-all` | `ai` |
| `--max-chars` | 每段最大字符数 | `2000` |
| `--gap-ms` | 段间静音间隔 (毫秒) | `300` |
| `--list-voices` | 列出所有可用音色 | false |

## ASS 字幕特效配置

在 `tts.py` 顶部修改以下变量可自定义 ASS 字幕样式：

```python
# 字体
ASS_FONT_NAME = "Microsoft YaHei"     # 字体名称
ASS_FONT_SIZE = 48                     # 字体大小 (px)

# 颜色 (ASS 格式: &HBBGGRR，B=透明度 00=不透明 FF=全透明)
ASS_FONT_COLOR = "&H00FFFFFF"         # 字体颜色
#   可选: "&H00FFFFFF" 白色, "&H000000FF" 红色, "&H0000FFFF" 黄色,
#         "&H00FF0000" 蓝色, "&H0000FF00" 绿色, "&H00000000" 黑色
ASS_OUTLINE_COLOR = "&H00000000"      # 描边颜色 (黑色)
ASS_BACK_COLOR = "&H80000000"         # 阴影颜色 (半透明黑)

# 描边与阴影
ASS_OUTLINE_WIDTH = 3                  # 描边宽度 (0-4)
ASS_SHADOW_WIDTH = 1                   # 阴影宽度 (0-3)

# 字幕位置
ASS_POSITION = "bottom"               # bottom / top / center

# 字幕特效
ASS_EFFECT = "slide-bottom"           # slide-bottom / slide-top / fade / static / none

# 特效参数 (毫秒)
ASS_SLIDE_MS = 400                     # 滑入动画时长 (100-1000)
ASS_FADE_IN_MS = 250                   # 淡入时长 (50-500)
ASS_FADE_OUT_MS = 150                  # 淡出时长 (50-500)
```

## 语义断句说明

### 标点感知分段 (`--split`)

纯规则分段，无需网络，按以下优先级断句：
1. 句号/问号/感叹号 (`。！？!?.`)
2. 逗号/顿号/分号 (`，,、；;：:`)
3. 空格
4. 强制截断 (在 `max_chars` 处)

### AI 语义断句 (`--semantic`)

通过已登录 OmniRush CLI 的当前内置模型按语义切分文本，更适合复杂长文本（实际字幕段长限制为 8–22 字）：
- 自然语义边界断句
- 保持词语完整性
- 验证段落连续完整覆盖原文；请求或解析重试耗尽时自动 fallback 到本地语义/标点规则，不依赖其他 AI 服务

## 批量输入文件格式

`input.txt` 每行一句文本:

```
第一句话
第二句话
第三句话
```

## 输出说明

### 单句输出
- 默认: `~/Downloads/edge-tts/tts_output.mp3`
- 指定路径: `-o /path/to/output.mp3`

### 长文本分段输出
- 音频: `-o` 指定的路径 (多段自动拼接)
- SRT: `{output}.srt` (使用 `--srt`)
- ASS: `{output}.ass` (使用 `--ass`)

### 批量输出
- 默认目录: `~/Downloads/edge-tts/`
- 指定目录: `-o /path/to/output/`
- 文件命名: `segment_001.mp3`, `segment_002.mp3`, ...
- 字幕文件: `subtitles.srt` / `subtitles.ass`

## 示例

```bash
# 快速测试
python3 {baseDir}/scripts/tts.py "测试语音合成"

# 中文新闻播报风格
python3 {baseDir}/scripts/tts.py -v zh-CN-YunyangNeural "今日新闻摘要"

# 英文旁白
python3 {baseDir}/scripts/tts.py -v en-US-GuyNeural -r "-10%" "Narration text here"

# 长文章语义断句 + 双字幕
python3 {baseDir}/scripts/tts.py -f article.txt --semantic --srt --ass -o ~/Downloads/article.mp3

# 批量生成视频字幕音频
python3 {baseDir}/scripts/tts.py -f script.txt --srt --ass -r "+5%" -o ~/Downloads/video_audio/
```
