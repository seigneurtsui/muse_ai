"""Explicit, local dictionary releases; staging never writes dictionary targets.

Public API: stage_release(pairs, source_path, output_path, report_path,
releases_root, converter=None), publish_release(release_dir, expected_plan),
rollback_release(release_dir, expected_plan), recover_release(release_dir,
expected_plan), inspect_release(release_dir, expected_plan), and
 dictionary_lock(source_path).

Plans and six read-only snapshots are content-addressed, not cryptographically
signed. Keep the returned plan_id outside the release and pass it back explicitly.
The lock is cooperative and NEVER automatically removed after a crash. An operator
must establish that the writer has stopped before manually removing a stale lock.
Each replacement is atomic and fsynced individually, NOT a multi-file transaction.
Readers can see an intermediate set; writers must honor dictionary_lock. Hash
checks detect intervening edits, but cannot provide compare-and-swap against a
noncooperative writer racing between a check and os.replace. Recovery fails closed
on unknown bytes, missing files, links, or aliases and never guesses at ownership.
Only bytes, not original permissions/timestamps, are restored. No OpenCC is needed
for publication, rollback, or recovery. Directory fsync support is required.
"""

from __future__ import annotations

from contextlib import contextmanager
import os
from pathlib import Path
import stat
import tempfile
import unicodedata

import build_dictionary as builder
from file_support import (
    ErratumError,
    atomic_write,
    linklike,
    loads,
    packed,
    read_regular,
    reason,
    sha,
)

VERSION = 1
NAMES = ("source", "runtime", "report")
MAX_PAIRS = 10000
PLAN_LIMIT = 4 * 1024 * 1024
STATE_LIMIT = 4096
STATUSES = {
    "staged",
    "publishing",
    "published",
    "rolling_back",
    "rolled_back",
    "recovering",
    "recovered",
}


class ReleaseError(ErratumError):
    def __init__(self, code, details=None):
        super().__init__(code)
        self.details = details or []


def _path(value):
    try:
        path = Path(value).absolute()
    except (TypeError, ValueError):
        raise ReleaseError("invalid_release_path") from None
    if ".." in path.parts:
        raise ReleaseError("parent_traversal_in_release_path")
    return path


def _directory(path, private=False, create=False):
    # Check every ancestor, not just the final component. Do not resolve links.
    for current in (*reversed(path.parents), path):
        created = False
        if create:
            try:
                current.mkdir(mode=0o700)
                created = True
            except FileExistsError:
                pass
        info = current.lstat()
        if linklike(current) or not stat.S_ISDIR(info.st_mode):
            raise ReleaseError("release_parent_is_link_or_not_directory")
        if created:
            # Nested new archive roots must survive a crash too, not just their
            # final component. _sync checks ancestors without creating them.
            _sync(current.parent)
    if private:
        info = path.stat()
        if stat.S_IMODE(info.st_mode) & 0o077:
            raise ReleaseError("release_directory_not_private")
        if hasattr(os, "getuid") and info.st_uid != os.getuid():
            raise ReleaseError("release_directory_not_owned")


def _regular(path):
    _directory(path.parent)
    info = path.lstat()
    if linklike(path) or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ReleaseError("release_file_is_link_or_not_regular")
    return info


def _identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def _read(path, limit=builder.LIMIT):
    before = _regular(path)
    raw = read_regular(path, limit)
    after = _regular(path)
    if _identity(before) != _identity(after):
        raise ReleaseError("release_file_changed_during_read")
    return raw


def _sync(directory):
    _directory(directory)
    fd = os.open(
        directory,
        os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0),
    )
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _store(path, raw, replace=False, immutable=False):
    _directory(path.parent)
    atomic_write(path, raw, replace=replace)
    if immutable:
        _regular(path)
        os.chmod(path, 0o400, follow_symlinks=False)
        # Persist the permission change as well as the bytes from atomic_write.
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    _sync(path.parent)


def _hashes(raw):
    return {name: sha(raw[name]) for name in NAMES}


def _digest(value):
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(c in "0123456789abcdef" for c in value)
    )


def _targets(source, runtime, report):
    targets = dict(zip(NAMES, map(_path, (source, runtime, report))))
    folded = {unicodedata.normalize("NFC", str(p)).casefold() for p in targets.values()}
    if len(folded) != len(NAMES):
        raise ReleaseError("release_targets_must_be_distinct")
    identities = set()
    for path in targets.values():
        info = _regular(path)
        identity = (info.st_dev, info.st_ino)
        if identity in identities:
            raise ReleaseError("release_target_alias")
        identities.add(identity)
    return targets


def _separate(targets, root):
    # A release archive must not include the files it will later replace.
    for target in targets.values():
        left = unicodedata.normalize("NFC", str(target)).casefold()
        right = unicodedata.normalize("NFC", str(root)).casefold()
        if left == right or left.startswith(right + os.sep):
            raise ReleaseError("release_archive_overlaps_targets")


@contextmanager
def dictionary_lock(source_path):
    """Acquire source.parent/.dictionary-write.lock; stale locks fail closed.

    Does not require source to exist, so initial compiler writes can use it too.
    The parent must already exist and must not be reached through a link.
    """
    source = _path(source_path)
    _directory(source.parent)
    if source.exists() or source.is_symlink():
        _regular(source)
    lock = source.parent / ".dictionary-write.lock"
    try:
        lock.mkdir(mode=0o700)
    except FileExistsError:
        raise ReleaseError("dictionary_writer_locked") from None
    owned = lock.lstat()
    try:
        _sync(lock.parent)
        yield
    finally:
        # Do not delete a replacement lock, its contents, or a link.
        try:
            current = lock.lstat()
            if linklike(lock) or (current.st_dev, current.st_ino) != (
                owned.st_dev,
                owned.st_ino,
            ):
                raise ReleaseError("dictionary_lock_changed")
            lock.rmdir()
            _sync(lock.parent)
        except FileNotFoundError:
            raise ReleaseError("dictionary_lock_changed") from None


def _pairs(pairs):
    if not isinstance(pairs, list) or not pairs or len(pairs) > MAX_PAIRS:
        raise ReleaseError("invalid_release_pairs")
    result = []
    seen = {}
    for pair in pairs:
        if not isinstance(pair, dict) or set(pair) != {"wrong", "right"}:
            raise ReleaseError("invalid_release_pair")
        wrong, right = pair["wrong"], pair["right"]
        builder.text_pair(wrong, right)
        if any(unicodedata.category(c) in {"Cc", "Cf", "Cs"} for c in wrong + right):
            raise ReleaseError("control_in_release_pair")
        if wrong in seen:
            raise ReleaseError(
                "duplicate_release_pair"
                if seen[wrong] == right
                else "conflicting_release_pair"
            )
        seen[wrong] = right
        result.append({"wrong": wrong, "right": right})
    return result


def _compile(source_raw, converter):
    table, report = builder.compile_dictionary(
        loads(source_raw), converter, sha(source_raw)
    )
    runtime = builder.render(table)
    report["runtime_sha256"] = sha(runtime)
    result = {
        "source": source_raw,
        "runtime": runtime,
        "report": builder.render(report),
    }
    if any(len(raw) > builder.LIMIT for raw in result.values()):
        raise ReleaseError("release_artifact_over_limit")
    return result, report["metadata"]


def _state(release, plan, status, create=False):
    value = {"version": VERSION, "plan_id": plan["plan_id"], "status": status}
    _store(release / "state.json", packed(value) + b"\n", replace=not create)
    if loads(_read(release / "state.json", STATE_LIMIT)) != value:
        raise ReleaseError("release_status_readback_failed")
    return value


def _descriptor(plan, status):
    return {**plan, "status": status}


def stage_release(
    pairs, source_path, output_path, report_path, releases_root, converter=None
):
    """Validate exact new Hans pairs and archive a preview without target writes.

    The returned JSON-safe descriptor contains plan_id, release_dir, targets,
    pairs, before/after SHA-256 maps (source/runtime/report), preview, and status.
    Source order and candidate order are retained; text is never normalized.
    Existing artifacts must exactly match the current compiler and converter.
    """
    pairs = _pairs(pairs)
    targets = _targets(source_path, output_path, report_path)
    root = _path(releases_root)
    _separate(targets, root)
    converter = converter if converter is not None else builder.Converter()
    with dictionary_lock(targets["source"]):
        before = {name: _read(path) for name, path in targets.items()}
        rebuilt, old_meta = _compile(before["source"], converter)
        if rebuilt != before:
            raise ReleaseError("dictionary_artifacts_outdated")
        source = loads(before["source"])
        runtime = loads(before["runtime"])
        for pair in pairs:
            wrong, right = pair["wrong"], pair["right"]
            if wrong in source.get("_review_only", {}):
                raise ReleaseError("release_pair_is_review_only")
            if (
                wrong in source
                or wrong in runtime
                or wrong in runtime.get("_script_sensitive", {})
            ):
                existing = source.get(wrong, runtime.get(wrong))
                raise ReleaseError(
                    "release_pair_already_known"
                    if existing == right
                    else "release_pair_conflicts_with_existing"
                )
            source[wrong] = right
        after, new_meta = _compile(builder.render(source), converter)
        if before == after or _hashes(before) == _hashes(after):
            raise ReleaseError("release_has_no_changes")
        _directory(root, private=True, create=True)
        _sync(root.parent)
        release = Path(tempfile.mkdtemp(prefix="release-", dir=root))
        _sync(root)
        preview = {
            "selected_pairs": len(pairs),
            "before": old_meta,
            "after": new_meta,
            "source_rules_added": new_meta["source_rules"] - old_meta["source_rules"],
            "runtime_rules_added": new_meta["runtime_rules"]
            - old_meta["runtime_rules"],
            "script_sensitive_rules_added": new_meta["script_sensitive_rules"]
            - old_meta["script_sensitive_rules"],
        }
        body = {
            "version": VERSION,
            "release_dir": str(release),
            "targets": {name: str(path) for name, path in targets.items()},
            "pairs": pairs,
            "before": _hashes(before),
            "after": _hashes(after),
            "preview": preview,
        }
        plan = {**body, "plan_id": sha(packed(body))}
        if len(packed(plan)) + 1 > PLAN_LIMIT:
            raise ReleaseError("release_plan_over_limit")
        for phase, artifacts in (("before", before), ("after", after)):
            directory = release / phase
            directory.mkdir(mode=0o700)
            _sync(release)
            for name in NAMES:
                _store(directory / (name + ".json"), artifacts[name], immutable=True)
        _store(release / "plan.json", packed(plan) + b"\n", immutable=True)
        _state(release, plan, "staged", create=True)
        # Reject a noncooperating edit during the relatively expensive build.
        _expect(targets, plan["before"])
        _load(release, plan["plan_id"])
        return _descriptor(plan, "staged")


def _load(release_dir, expected_plan):
    if not _digest(expected_plan):
        raise ReleaseError("invalid_expected_release_plan")
    release = _path(release_dir)
    _directory(release.parent, private=True)
    _directory(release, private=True)
    plan = loads(_read(release / "plan.json", PLAN_LIMIT))
    required = {
        "version",
        "release_dir",
        "targets",
        "pairs",
        "before",
        "after",
        "preview",
        "plan_id",
    }
    if not isinstance(plan, dict) or set(plan) != required:
        raise ReleaseError("invalid_release_plan")
    body = {key: value for key, value in plan.items() if key != "plan_id"}
    if plan["plan_id"] != expected_plan or sha(packed(body)) != expected_plan:
        raise ReleaseError("release_plan_hash_mismatch")
    if (
        type(plan["version"]) is not int
        or plan["version"] != VERSION
        or plan["release_dir"] != str(release)
    ):
        raise ReleaseError("release_plan_location_or_version_mismatch")
    _pairs(plan["pairs"])
    if not isinstance(plan["targets"], dict) or set(plan["targets"]) != set(NAMES):
        raise ReleaseError("invalid_release_targets")
    if any(
        not isinstance(p, str) or not Path(p).is_absolute()
        for p in plan["targets"].values()
    ):
        raise ReleaseError("invalid_release_targets")
    targets = _targets(*(plan["targets"][name] for name in NAMES))
    _separate(targets, release.parent)
    snapshots = {}
    for phase in ("before", "after"):
        hashes = plan[phase]
        if (
            not isinstance(hashes, dict)
            or set(hashes) != set(NAMES)
            or not all(_digest(h) for h in hashes.values())
        ):
            raise ReleaseError("invalid_release_hashes")
        _directory(release / phase, private=True)
        snapshots[phase] = {
            name: _read(release / phase / (name + ".json")) for name in NAMES
        }
        if _hashes(snapshots[phase]) != hashes:
            raise ReleaseError("release_snapshot_hash_mismatch")
    if any(plan["before"][name] == plan["after"][name] for name in NAMES):
        raise ReleaseError("release_has_unchanged_artifact")
    state = loads(_read(release / "state.json", STATE_LIMIT))
    if (
        not isinstance(state, dict)
        or set(state) != {"version", "plan_id", "status"}
        or type(state["version"]) is not int
        or state["version"] != VERSION
        or state["plan_id"] != expected_plan
        or not isinstance(state["status"], str)
        or state["status"] not in STATUSES
    ):
        raise ReleaseError("invalid_release_status")
    return release, plan, targets, snapshots, state["status"]


def _expect(targets, expected):
    actual = _hashes({name: _read(path) for name, path in targets.items()})
    if actual != expected:
        raise ReleaseError("dictionary_target_hash_mismatch")
    return actual


def _transition(
    release, plan, targets, snapshots, current, destination, intent, completed
):
    # A durable, read-back intent precedes even the first dictionary write.
    _expect(targets, current)
    _state(release, plan, intent)
    try:
        for name in NAMES:
            _expect(targets, current)
            if current[name] != plan[destination][name]:
                _store(targets[name], snapshots[destination][name], replace=True)
                current = {**current, name: plan[destination][name]}
                _expect(targets, current)
        _expect(targets, plan[destination])
        _state(release, plan, completed)
    except Exception as error:
        # NEVER auto-restore here: another actor may have written unknown bytes.
        # The durable intent remains sufficient to classify every artifact.
        raise ReleaseError(
            "release_transition_incomplete",
            [
                {
                    "release_dir": str(release),
                    "reason": reason(error),
                    "recovery": "inspect state.json; recover interrupted states with the original plan_id, or rollback if published; preserve unknown edits",
                }
            ],
        ) from error
    return _descriptor(plan, completed)


def _operate(release_dir, expected_plan, operation):
    loaded = _load(release_dir, expected_plan)
    with dictionary_lock(loaded[2]["source"]):
        release, plan, targets, snapshots, status = _load(release_dir, expected_plan)
        if operation == "publish":
            if status != "staged":
                raise ReleaseError("release_not_staged")
            return _transition(
                release,
                plan,
                targets,
                snapshots,
                dict(plan["before"]),
                "after",
                "publishing",
                "published",
            )
        if operation == "rollback":
            if status != "published":
                raise ReleaseError("release_not_published")
            return _transition(
                release,
                plan,
                targets,
                snapshots,
                dict(plan["after"]),
                "before",
                "rolling_back",
                "rolled_back",
            )
        if status not in {"publishing", "rolling_back", "recovering"}:
            raise ReleaseError("release_not_interrupted")
        current = _hashes({name: _read(path) for name, path in targets.items()})
        if any(
            current[name] not in {plan["before"][name], plan["after"][name]}
            for name in NAMES
        ):
            raise ReleaseError("release_recovery_unknown_target")
        return _transition(
            release,
            plan,
            targets,
            snapshots,
            current,
            "before",
            "recovering",
            "recovered",
        )


def inspect_release(release_dir, expected_plan):
    """Read back journaled state and known target bytes; enables ledger reconciliation."""
    loaded = _load(release_dir, expected_plan)
    with dictionary_lock(loaded[2]["source"]):
        _, plan, targets, _, status = _load(release_dir, expected_plan)
        if status == "published":
            _expect(targets, plan["after"])
        elif status in {"staged", "rolled_back", "recovered"}:
            _expect(targets, plan["before"])
        else:
            current = _hashes({name: _read(path) for name, path in targets.items()})
            if any(
                current[name] not in {plan["before"][name], plan["after"][name]}
                for name in NAMES
            ):
                raise ReleaseError("release_recovery_unknown_target")
        return _descriptor(plan, status)


def publish_release(release_dir, expected_plan):
    """Publish a staged plan only when every target still has its exact old hash."""
    return _operate(release_dir, expected_plan, "publish")


def rollback_release(release_dir, expected_plan):
    """Restore originals only from the exact published set; reject newer edits."""
    return _operate(release_dir, expected_plan, "rollback")


def recover_release(release_dir, expected_plan):
    """Restore an interrupted transition iff all targets have known old/new bytes.

    Recovery is itself journaled and retryable after interruption. A recovered
    release is terminal: create a new staged release for another publication.
    """
    return _operate(release_dir, expected_plan, "recover")
