#!/usr/bin/env python3
"""
Telegram Chat List - 使用已保存的 session 文件
"""

import asyncio
import json
import os
import sys
from telethon import TelegramClient

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(os.path.dirname(SCRIPT_DIR), 'config.json')

def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, 'r') as f:
            return json.load(f)
    return {}

async def main():
    config = load_config()
    
    if not config.get('api_id') or not config.get('api_hash'):
        print("错误: 请在 config.json 中配置 api_id 和 api_hash")
        sys.exit(1)
    
    # Session 文件位置
    session_files = [
        '/tmp/telegram/session_name',
        os.path.join(SCRIPT_DIR, 'session_name'),
        os.path.join(os.path.dirname(SCRIPT_DIR), 'session_name'),
    ]
    
    session_path = None
    for s in session_files:
        if os.path.exists(s + '.session'):
            session_path = s
            break
    
    if not session_path:
        # 使用默认路径创建客户端
        session_path = os.path.join(SCRIPT_DIR, 'session_name')
    
    print(f"使用 session: {session_path}")
    
    client = TelegramClient(session_path, int(config['api_id']), config['api_hash'])
    
    async with client:
        # 检查是否已认证
        if not await client.is_user_authorized():
            print("需要重新认证。请在 Telegram 桌面端扫码登录。")
            await client.send_code_request(config.get('phone', '+447849125206'))
            code = input("请输入验证码: ")
            await client.sign_in(config.get('phone', '+447849125206'), code)
        
        # 获取所有对话
        dialogs = await client.get_dialogs()
        
        print(f"\n{'='*60}")
        print(f"您的所有对话 (共 {len(dialogs)} 个)")
        print(f"{'='*60}\n")
        
        for idx, dialog in enumerate(dialogs, 1):
            chat_type = dialog.entity.__class__.__name__
            print(f"{idx}. ID: {dialog.id}")
            print(f"   名称: {dialog.name}")
            print(f"   类型: {chat_type}")
            print(f"   {'-'*50}")
        
        print(f"\n共 {len(dialogs)} 个对话")
        
        # 保存到 JSON 文件
        chats_data = []
        for dialog in dialogs:
            chats_data.append({
                'id': dialog.id,
                'name': dialog.name,
                'type': dialog.entity.__class__.__name__
            })
        
        output_file = os.path.join(SCRIPT_DIR, 'chats.json')
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(chats_data, f, ensure_ascii=False, indent=2)
        
        print(f"JSON 已保存到: {output_file}")

if __name__ == "__main__":
    asyncio.run(main())