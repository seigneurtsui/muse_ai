import json
from pathlib import Path
import re
import sys
import tempfile
import unittest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
from subtitles import (Cue, EFFECTS, Highlighter, Style, SubtitleError, ass_color, ass_escape, ass_time,
                       fold_text, graphemes, parse_srt, read_text, render_ass, srt_text)


SAMPLE = "7\n00:00:01,005 --> 00:00:02,999\n你好\nSecond line\n\n19\n00:00:03,000 --> 00:00:03,001\n2026\n"


class SubtitleTests(unittest.TestCase):
    def test_srt_keeps_indexes_milliseconds_multiline_numbers(self):
        cues = parse_srt(SAMPLE.replace("\n", "\r\n"))
        self.assertEqual([cue.index for cue in cues], ["7", "19"])
        self.assertEqual(cues[0].start, 1005)
        self.assertEqual(cues[0].end, 2999)
        self.assertEqual(cues[0].text, "你好\nSecond line")
        self.assertEqual(cues[1].text, "2026")
        self.assertEqual(parse_srt(srt_text(cues, [[cue.text] for cue in cues])), cues)

    def test_missing_blank_separator_is_not_silently_merged(self):
        with self.assertRaises(SubtitleError):
            parse_srt(SAMPLE.replace("\n\n19", "\n19"))

    def test_srt_omitted_index_and_decimal_dot(self):
        cues = parse_srt("00:00:01.200 --> 00:00:02.400\nHello")
        self.assertEqual(cues[0], Cue("1", 1200, 2400, "Hello"))

    def test_srt_rejects_malformed_instead_of_skipping(self):
        for value in ("", "not srt", "1\n00:60:00,000 --> 00:00:02,000\nx",
                      "1\n00:00:03,000 --> 00:00:02,000\nx", "1\n00:00:01,000 --> 00:00:02,000",
                      "1\n00:00:01,000 --> 00:00:02,000\n<b></b>", SAMPLE + "\ninvalid block",
                      SAMPLE + "\n7\n00:00:10,000 --> 00:00:11,000\nduplicate"):
            with self.subTest(value=value), self.assertRaises(SubtitleError):
                parse_srt(value)

    def test_read_encodings_and_no_silent_replacement(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "input.srt"
            for encoding in ("utf-8-sig", "utf-16", "gb18030"):
                path.write_bytes(SAMPLE.encode(encoding))
                text, detected = read_text(path)
                self.assertEqual(parse_srt(text), parse_srt(SAMPLE))
            path.write_bytes(b"\x00bad")
            with self.assertRaises(SubtitleError):
                read_text(path)

    def test_ass_integer_quantization_and_hour_carry(self):
        self.assertEqual(ass_time(59999), "0:00:59.99")
        self.assertEqual(ass_time(59999, end=True), "0:01:00.00")
        self.assertEqual(ass_time(3599999, end=True), "1:00:00.00")
        self.assertEqual(ass_time(1005), "0:00:01.00")
        self.assertEqual(ass_time(1005, end=True), "0:00:01.01")

    def test_color_order_alpha_and_invalid(self):
        self.assertEqual(ass_color("FF0000"), "&H000000FF")
        self.assertEqual(ass_color("80FF0000"), "&H800000FF")
        self.assertEqual(ass_color("&H800000FF&"), "&H800000FF")
        for value in ("RED", "1234567", "FFFFFF\\fs90", None):
            with self.assertRaises(SubtitleError):
                ass_color(value)

    def test_ass_text_cannot_inject_overrides(self):
        source = r"{\pos(0,0)}hello\Nworld"
        escaped = ass_escape(source)
        self.assertNotIn("{", escaped)
        self.assertNotIn("\\", escaped)
        self.assertIn("hello", escaped)

    def test_literal_keywords_longest_match_and_style_restore(self):
        highlighter = Highlighter(["New", "New York", "a+b", "New York"])
        self.assertEqual(highlighter.spans("New York and a+b"), [(0, 8), (13, 16)])
        cue = Cue("1", 0, 3000, "New York and a+b")
        text, stats = render_ass([cue], [[cue.text]], Style(effect="pop"), highlighter.keywords)
        self.assertNotIn(r"{\r", text)
        self.assertIn(r"\fscx75", text)
        self.assertIn("New York", text)
        self.assertIn(r"\1c&H66D1FF&", text)

    def test_unicode_folding_preserves_text_and_combining_characters(self):
        original = "字幕高亮测试没有文字被丢弃"
        self.assertEqual("".join(fold_text(original, 6)), original)
        self.assertEqual(fold_text("one two three four", 8), ["one two", "three", "four"])
        self.assertEqual(graphemes("e\u0301👩\u200d💻"), ["e\u0301", "👩\u200d💻"])
        self.assertEqual("".join(fold_text("averylongwordwithoutspaces", 5)), "averylongwordwithoutspaces")

    def test_bilingual_order_and_multiline_never_drop_rows(self):
        cue = Cue("1", 0, 3000, "placeholder")
        text, stats = render_ass([cue], [["English first\nEnglish second", "中文第一行\n中文第二行"]], Style(wrap=0))
        for value in ("English first", "English second", "中文第一行", "中文第二行"):
            self.assertIn(value, text)
        self.assertLess(text.index("English first"), text.index("中文第一行"))
        self.assertIn(r"\fs44", text)
        self.assertGreaterEqual(text.count(r"\N"), 3)

    def test_all_effects_emit_valid_dialogue_and_short_cue_bounds(self):
        cue = Cue("9", 1005, 1010, "test")
        for effect in EFFECTS:
            with self.subTest(effect=effect):
                text, stats = render_ass([cue], [[cue.text]], Style(effect=effect))
                line = next(line for line in text.splitlines() if line.startswith("Dialogue:"))
                self.assertEqual(len(line.split(",", 9)), 10)
                self.assertIn("0:00:01.00,0:00:01.01", line)
                if r"\fad(" in line:
                    numbers = re.search(r"\\fad\((\d+),(\d+)\)", line)
                    self.assertLessEqual(sum(map(int, numbers.groups())), 10)

    def test_slide_direction_independent_of_position(self):
        cue = Cue("1", 0, 2000, "test")
        for position in ("top", "center", "bottom"):
            for effect, sign in (("slide-up", 1), ("slide-down", -1)):
                text, _ = render_ass([cue], [[cue.text]], Style(position=position, effect=effect))
                move = re.search(r"\\move\((\d+),(-?\d+),(\d+),(-?\d+),0,(\d+)\)", text)
                self.assertEqual((int(move[2]) - int(move[4])) // 120, sign)

    def test_karaoke_duration_sums_exactly(self):
        cue = Cue("1", 0, 1257, "你好 world!")
        text, _ = render_ass([cue], [[cue.text]], Style(effect="karaoke"))
        self.assertEqual(sum(map(int, re.findall(r"\\kf(\d+)", text))), 126)

    def test_typewriter_highlight_boundaries_keep_text_hidden(self):
        cue = Cue("1", 0, 3000, "first testing")
        text, _ = render_ass([cue], [[cue.text]], Style(effect="typewriter"), ["test"])
        # Both the highlighted prefix and the unhighlighted suffix get the same reveal gate.
        self.assertRegex(text, r"\\alpha&HFF&\\t\([^}]+\}ing")

    def test_typewriter_does_not_explode_event_count(self):
        cue = Cue("1", 0, 6000, "This is a typewriter test 字幕测试")
        text, stats = render_ass([cue], [[cue.text]], Style(effect="typewriter"))
        self.assertEqual(stats["events"], 1)
        self.assertIn(r"\alpha&HFF&", text)
        self.assertGreater(text.count(r"\t("), 5)

    def test_layout_shrinks_or_fails_without_truncation(self):
        cue = Cue("1", 0, 5000, "\n".join("完整文字" for _ in range(10)))
        text, stats = render_ass([cue], [[cue.text]], Style(height=400, margin_y=30))
        self.assertEqual(text.count("完整文字"), 10)
        self.assertEqual(stats["resized_cues"], 1)
        with self.assertRaises(SubtitleError):
            render_ass([cue], [["\n".join("完整文字" for _ in range(100))]], Style(height=400, margin_y=30))

    def test_glow_layers_and_optional_overlay_use_canvas(self):
        cue = Cue("1", 0, 5500, "test")
        text, stats = render_ass([cue], [[cue.text]], Style(width=1080, height=1920, glow=3, overlay_text="欢迎订阅", overlay_interval=2, overlay_duration=1))
        self.assertEqual(stats["events"], 4)
        self.assertEqual(stats["overlay_events"], 2)
        self.assertIn(r"\pos(1000,65)", text)
        without, info = render_ass([cue], [[cue.text]], Style())
        self.assertEqual(info["overlay_events"], 0)
        self.assertNotIn("欢迎订阅", without)

    def test_invalid_style_and_partial_rows_rejected(self):
        for value in ({"unknown": 3}, {"font_name": "Arial,Injected"}, {"font_size": 0}, {"width": 160}, {"glow": float("nan")}, {"bold": "yes"}, {"effect": []}, {"highlight_font": 123}):
            with self.subTest(value=value), self.assertRaises(SubtitleError):
                Style.from_mapping(value)
        cues = parse_srt(SAMPLE)
        with self.assertRaises(SubtitleError):
            render_ass(cues, [["one"]], Style())
        with self.assertRaises(SubtitleError):
            render_ass(cues, [["one"], ["two", "extra"]], Style())
        with self.assertRaises(SubtitleError):
            srt_text(cues, [["one"], [""]])

    def test_presets_validate(self):
        data = json.loads((SCRIPTS.parent / "assets/presets.json").read_text())
        self.assertEqual(len(data), 6)
        for name, values in data.items():
            with self.subTest(preset=name):
                Style.from_mapping(values)


if __name__ == "__main__":
    unittest.main()
