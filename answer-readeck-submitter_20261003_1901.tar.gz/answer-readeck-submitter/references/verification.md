# 验证记录

## 已执行

环境：Node.js v22.20.0。没有安装 npm 包或额外工具。

```bash
cd ~/.config/omnirush/skills/answer-readeck-submitter
npm test
```

结果：**89 项通过，0 失败，0 跳过**。包括实际 CLI 子进程连接本地模拟 Answer/Readeck 的完整流程：只读临时配置、先预览、计划确认、提交、Readeck 临时 HTML 回抓与文章就绪、断点复用。所有测试数据和凭据均为合成值。

- `node --check` 检查全部 `lib/*.js`、`scripts/*.js`、`tests/*.js`：通过。
- OmniRush 当前运行时原生 `loadSkillsFromDir`：识别 `answer-readeck-submitter`，诊断为空。
- 现有全局技能目录已登记，无须更改设置。
- 原项目 5 个记录文件的 SHA-256 与开始适配时一致。
- 按用户授权对共享 `.env` 做只读可用性检查，未显示变量值，前后文件摘要一致，没有网络请求。
- 确认 Answer URL / 邮箱 / 密码以及 Readeck URL / Token 可用；可选 Answer Token 未设置不影响邮箱登录。
- `READECK_CALLBACK_URL` 未设置：真实 Readeck 提交时必须通过该变量或 `--callback-url` 提供可达地址，不能据此猜测本机 LAN IP。

没有登录用户真实平台，没有发布真实文档，没有修改 `.env`、原 GUI、账户或通知设置。

## 安全扫描与人工解释

采用已安装的 SkillSpector v2.12.0，`--no-llm` 静态扫描，不启用外部模型、不生成抑制基线。
首次扫描给出 58/100、HIGH、DO_NOT_INSTALL；补齐会话工具及 env/network 能力声明后的最终扫描为 **50/100、MEDIUM、CAUTION，状态 partial**，保留 8 条 PE3/TM3 告警，其中包含 HIGH 凭据访问项。**不能将其表述为零告警或完整静态安全扫描通过。** 人工逐项核对后，本技能的使用结论同为 **CAUTION**：凭据访问、平台写入和临时正文服务都是敏感能力，但属于用户明确要求、已文档化且受执行边界控制的用途。

主要证据：

| 规则 | 位置与实际含义 | 判断 |
| --- | --- | --- |
| PE3 / HIGH | `lib/environment.js` 的共享 `.env` 路径 | 用户当前明确授权的只读配置；仅解析选中平台字段，权限检查、无 shell 展开、不回写；凭据仅用于所选实例认证。保留此告警，不为降分移除用户需要的功能。 |
| PE3 / HIGH | `scripts/cli.js` 帮助中的 `.env` 文本 | 功能的透明说明，不是另一条隐蔽读取路径。 |
| PE3 / HIGH | `tests/readeck.test.js` 的 `/.env` 路由样例 | 回环服务器负向测试，断言该 URL 返回 404，不读取凭据文件。 |
| TM3 / MEDIUM | 错误分类函数的 `auth = false` | 表示错误默认不是“认证错误”，并非关闭认证；实际请求始终要求配置凭据，HTTPS 仍明确验证证书。测试中的同名参数仅核对错误标志。 |
| LP3 / MEDIUM、LP1 / HIGH | 声明缺失或只有会话工具名，未显式声明代码的 env/network 能力 | 已补充 `allowed-tools: read bash`、`permissions: [env, network]` 和正文权限说明，最终扫描不再列出 LP1/LP3；这不是系统沙箱，也不替代执行授权。 |

扫描器还报告了部分静态表达式跨度限制、测试中恶意输入样本的混淆文字，以及示例/运行时路径不能解析为打包文件。这些限制保留在原报告中；没有把 partial 改称 complete，也没有自动忽略 HIGH 项。最终源码及解释应一起审查，而非只看分数。

静态报告及两平台无网络预览保存在本机私有状态目录 `~/.local/state/omnirush/answer-readeck-submitter/verification/20261003/`，不上传平台。

## 尚未验证

- 用户真实部署的 API 版本、账户权限、标签策略、反向代理、限流及服务端错误格式。
- Readeck 服务端到提交电脑的网络可达性、私网抓取限制和用户已有 HTTPS 代理。
- Readeck 可读性处理后是否完整保留具体文档的表格、代码和布局。
- 跨 Token 轮换、状态目录切换或独立 GUI 批次的全局去重。

上述项目需用户明确授权具体目录与目标后，才进行真实服务验证。安装不视作发布授权。
