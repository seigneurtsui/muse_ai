# PDF 提取与本地 OCR

Python API（在 `scripts` 目录运行，或先将其加入 `sys.path`）：

```python
from pathlib import Path
from pdf_backend import extract_pdf

result = extract_pdf(Path("sample.pdf"), cache_dir=Path("private-cache"),
                     ocr="off", ocr_language="eng", dpi=150,
                     min_page_chars=40, timeout=120)
```

- 仅在调用时导入 **PyMuPDF**；OCR 仅调用已安装的本地 **Tesseract**。不会自动安装依赖、下载模型、联网，或读写凭据/`.env`。语言包须自行预先安装。
- 加密或需要认证的 PDF 会明确报错；不会尝试密码、认证或绕过 DRM。损坏/非 PDF 文件也会报错。
- 文档只打开一次；每个未缓存页只解析一次文本层，复用同一 TextPage 检查实际显示的图像（含内联图像）。按全部页面顺序提取，不从首个书签开始，因此不会丢掉前言，也不会因同页书签重复提取正文。

## 正文与书签

`Extracted.text` 是各页选定文本以 `"\n\f\n"` 相接的唯一正文；不清洗、不去除页内空白，不跳过空页。OCR 成功时使用该页 OCR 文本；OCR 失败或过少时保留已有文本/字符更多的结果，不把两份重复正文相加。原文本层另保留在私有页缓存中。

`toc` 返回所有有效层级，按页位置稳定排序：

- `Boundary.position`：该页起点在最终正文中的 **Python 字符偏移**，不是字节偏移。
- `level`：PDF 原层级；`children`：原目录层级中直接子项数量。
- `locator.page`：从 1 开始的页码；`page_index`、`toc_index` 从 0 开始。
- 同页不同书签保留，但明确警告无法在页内精确分界；不复制页面正文。非法页码/标题/层级会忽略并警告；逆序位置、层级跳跃也会警告。书签读取失败不阻止全文提取。

后端不判断“单本还是合集”，也不自行选择一级/章节边界；这些由上层处理。`method` 是 `pdf_toc` 或 `pdf_text`，OCR 使用情况见元数据。

## OCR 规则与限制

| `ocr` | 行为 |
|---|---|
| `off`（默认） | 只读文本层；带图像且文本稀少的页面必须标记可能不完整，即使 PDF 有书签。 |
| `auto` | 仅处理文本层出错，或字符数低于阈值且含少量文本/图像的页面；真正无文本无图像的空白页跳过。 |
| `force` | 对每一页请求 OCR；已成功缓存的页面不重复 OCR。 |

阈值按非空白字符数计算。空白页、仅少量文字装饰的页面不会仅因字符少而导致整书失败；无法可靠区分“只有装饰图”和“扫描正文”，因此无足够文字的图像页保守标为不完整/待检查，而不是抛弃或宣称完整。OCR 字少的结果也会保留，并在下次运行重试。OCR 失败保留文本层，继续其他页。

- 语言格式：如 `eng`、`chi_sim+eng`；仅允许安全的语言代码，不接受路径/选项（不支持 `script/Latin` 这种路径形式）。
- 后端 API 的 DPI：整数 **72–600**；阈值：整数 **1–100000**；超时：有限数值 **(0, 3600] 秒/页**。批量 CLI 使用更保守的 DPI **72–400**、阈值 **1–10000** 和整数秒超时。
- 每页单独渲染灰度图，最长边不超过 **6000 像素**、总像素不超过 **1200 万**；大页面会降低实际 DPI（记录在页面 `render` 中）。图像通过标准输入传给 Tesseract，不落临时图片文件。每页最多一次 OCR 子进程，带超时；渲染和 PDF 解析本身没有强制执行时限。
- 不猜测语言，不调用 PaddleOCR/ocrmypdf，不采用 PDF→EPUB 的转换路径。OCR 不保证排版、栏序、公式、手写或识别准确率。纯矢量描边文字、已有但错误/不完整的文本层可能无法自动识别，需要人工选择 `force` 并审阅。

## 可恢复私有缓存

缓存仅写入指定 `cache_dir`，不写到原书旁边。目录权限 `0700`，页 JSON `0600`；JSON **包含正文，属于私有数据**。每页先保存文本层，再独立保存 OCR 结果，使用临时文件、`fsync` 与原子替换。中断后可从已完成页恢复。

缓存键包含源内容 **SHA-256**、后端版本、PyMuPDF 版本及全部 OCR 设置（含语言/DPI/阈值/超时）。同名源内容或设置改变不会误跳过；不仅依赖大小/mtime。成功 OCR 跳过，失败和稀疏 OCR 重试。每次读取验证页索引、页数、状态、字符数、渲染边界等模式；损坏缓存重新提取。缓存根、命名空间、页面入口禁止符号链接，页面也禁止硬链接；根以外的调用方父路径可包含系统链接（如 macOS `/tmp`）。根内通过目录 FD 操作，防止链接重定向。目录须由当前用户拥有。

缓存不含 Tesseract 可执行文件/语言包的内容指纹；更换 OCR 引擎或语言数据后，若要重新识别已有成功结果，应使用批量 CLI 的 `--refresh-cache`（保留旧副本），或为后端 API 指定新的缓存目录。调用方负责整书任务锁；后端原子写入不替代任务锁。

## 元数据与验收

- `toc_present` / `structure_uncertain`：标记书签存在和结构异常；目录损坏时，上层不会悄悄改用正文猜测。不同层级在同页的正常父子书签不单独触发结构异常；所选层同位置的不同标题由上层合并并提示。
- `incomplete` / `incomplete_pages`：存在未解决的文本层错误、OCR 失败或稀疏图像页时为真/大于零。调用方应显示部分提取，不能报告无条件成功。
- 页统计：`page_count`、`pages_with_text`、`native_text_pages`、`ocr_text_pages`、`sparse_pages`、`image_pages`、`textless_image_pages`、`blank_pages`、`text_error_pages`。
- OCR/缓存统计：`ocr_attempted_pages`（本次请求，包括缺失程序/渲染失败）、`ocr_success_pages`、`ocr_sparse_pages`、`ocr_failed_pages`、`cache_hits`（复用文本层页）、`ocr_cache_hits`、`native_extraction_calls`。
- `characters` 为最终非空白字符数。`pages` 含页码、正文起点、原/最终字符数、图像数、选用来源、OCR 状态、缓存命中、不完整标志、安全错误代码及实际渲染尺寸；不重复存放正文。成功/稀疏/失败统计包含本次最终使用的缓存状态。

测试只生成合成 PDF，不读取用户书籍。`tests/test_pdf_backend.py` 使用标准库 unittest；真正的英文 Tesseract 冒烟测试单独标注，缺少程序/英文包时跳过。

来源说明：`/tmp/pdf/README.md` 混有多个版本的说明与预测，不能当作已验证能力。指定旧代码实际使用一级书签页范围、全文回退，以及独立 `ocrmypdf` 路径；“pdftotext 更擅长扫描版”不代表它能 OCR。此实现不导入或执行旧脚本（旧脚本可能自动安装包），不继承 README 中自动下载 PaddleOCR 模型等行为。
