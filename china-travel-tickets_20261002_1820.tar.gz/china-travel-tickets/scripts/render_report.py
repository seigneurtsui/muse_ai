#!/usr/bin/env python3
"""Render a ticket-query JSON result as Markdown and email-friendly HTML."""
from __future__ import annotations

import argparse
import html
import json
import re
from pathlib import Path


def unique_prices(row):
    seen = set()
    prices = []
    for item in row.get("prices", []):
        key = (item.get("seat"), item.get("price"), item.get("availability"))
        if key not in seen:
            seen.add(key)
            prices.append(item)
    return prices


def get_price(row, seat):
    return next((item for item in unique_prices(row) if item.get("seat") == seat), None)


def price_text(row, seat):
    item = get_price(row, seat)
    if not item:
        return "—"
    return f"¥{item['price']:.0f} / {item['availability']}"


def duration_minutes(value):
    hours, minutes = map(int, value.split(":"))
    return hours * 60 + minutes


def safe_slug(value):
    value = re.sub(r"[^A-Za-z0-9._-]+", "-", value).strip("-._")
    return value or "ticket-report"


def _flight_record(raw):
    journey = (raw.get("journeys") or [{}])[0]
    segments = journey.get("segments") or []
    if not segments:
        return None
    first, last = segments[0], segments[-1]
    try:
        price = float(raw.get("ticketPrice") or raw.get("adultPrice"))
    except (TypeError, ValueError):
        price = None
    try:
        duration = int(raw.get("totalDuration") or journey.get("totalDuration"))
    except (TypeError, ValueError):
        duration = None
    try:
        transfer = int(raw.get("transferDuration") or journey.get("transferDuration") or 0)
    except (TypeError, ValueError):
        transfer = 0
    return {
        "segments": segments,
        "from": first.get("depCityName") or first.get("depStationName") or "出发地",
        "to": last.get("arrCityName") or last.get("arrStationName") or "目的地",
        "departure": first.get("depDateTime") or "",
        "arrival": last.get("arrDateTime") or "",
        "duration": duration,
        "transfer": transfer,
        "price": price,
        "flight_numbers": [segment.get("marketingTransportNo") or "—" for segment in segments],
        "airports": [
            f"{segment.get('depStationName', '—')} → {segment.get('arrStationName', '—')}"
            for segment in segments
        ],
    }


def _duration_text(minutes):
    if minutes is None:
        return "—"
    return f"{minutes // 60}小时{minutes % 60:02d}分"


def _flight_time(value):
    return value.replace("T", " ")[:16] if value else "—"


def render_flight(input_path: Path, output_dir: Path, slug: str | None, data: dict):
    flights = [item for raw in data.get("results", []) if (item := _flight_record(raw))]
    if not flights:
        raise SystemExit("航班查询结果为空，无法生成报告")
    first = flights[0]
    date = first["departure"][:10] or "未注明日期"
    origin, destination = first["from"], first["to"]
    query_time = str(data.get("timestamp", "")).replace("T", " ")[:19]
    slug = safe_slug(slug or f"{origin}-{destination}-{date}-flight")
    md_path = output_dir / f"{slug}.md"
    html_path = output_dir / f"{slug}.html"
    cheapest = min((item for item in flights if item["price"] is not None), key=lambda item: item["price"], default=None)
    fastest = min((item for item in flights if item["duration"] is not None), key=lambda item: item["duration"], default=None)
    earliest = min(flights, key=lambda item: item["arrival"] or "9999")

    def flight_line(item):
        return ", ".join(item["flight_numbers"])

    def price_text(item):
        return f"¥{item['price']:.0f}" if item["price"] is not None else "未提供"

    lines = [
        f"# {origin} → {destination} 机票出行报告", "",
        f"> 查询日期：**{date}**  · 数据源：{data.get('source', '航班查询')}  · 共 {len(flights)} 条方案", "",
        "## 结论速览", "",
        f"- **查询结果**：{len(flights)} 条，均为中转方案；本次结果未返回直飞航班。",
        f"- **最早抵达**：{flight_line(earliest)}，{_flight_time(earliest['departure'])} → {_flight_time(earliest['arrival'])}，票价 {price_text(earliest)}。",
    ]
    if fastest:
        lines.append(f"- **总耗时最短**：{flight_line(fastest)}，总耗时 {_duration_text(fastest['duration'])}，票价 {price_text(fastest)}。")
    if cheapest:
        lines.append(f"- **价格最低**：{flight_line(cheapest)}，票价 {price_text(cheapest)}，总耗时 {_duration_text(cheapest['duration'])}。")
    lines += ["", "## 推荐选择", "", "| 适合场景 | 航班 | 时间 | 中转 | 总耗时 | 价格 |", "|---|---|---|---|---:|---:|"]
    for label, item in [("最早抵达", earliest), ("总耗时最短", fastest), ("价格优先", cheapest)]:
        if item:
            transfer = " → ".join(item["airports"])
            lines.append(f"| {label} | {flight_line(item)} | {_flight_time(item['departure'])} → {_flight_time(item['arrival'])} | {transfer} | {_duration_text(item['duration'])} | {price_text(item)} |")
    lines += ["", "## 全部查询结果", "", "| # | 航班 | 出发 → 到达 | 中转航段 | 总耗时 | 中转等待 | 价格 |", "|---:|---|---|---|---:|---:|---:|"]
    for index, item in enumerate(flights, 1):
        lines.append(f"| {index} | {flight_line(item)} | {_flight_time(item['departure'])} → {_flight_time(item['arrival'])} | {' / '.join(item['airports'])} | {_duration_text(item['duration'])} | {_duration_text(item['transfer'])} | {price_text(item)} |")
    lines += ["", "## 说明", "", f"- 查询时间：`{query_time}`（中国标准时间）", "- 结果中的价格、航班计划、机场和中转信息会动态变化，且可能未包含全部税费或行李规则。", "- 本次结果没有直飞航班；购买前请在官方航空公司或正规平台再次核对。", "- 本报告仅提供查询信息，不执行登录、下单或支付。"]
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    def esc(value):
        return html.escape(str(value), quote=True)

    cards = []
    for title, item, accent in [("最早抵达", earliest, "#0f766e"), ("总耗时最短", fastest, "#2563eb"), ("价格最低", cheapest, "#b45309")]:
        if item:
            cards.append(f'<div class="card" style="border-top-color:{accent}"><div class="label">{title}</div><div class="big">{esc(flight_line(item))}</div><div>{esc(_flight_time(item["departure"]))} → {esc(_flight_time(item["arrival"]))}</div><div class="small">{esc(_duration_text(item["duration"]))} · <strong>¥{item["price"]:.0f}</strong></div></div>')
    rows = []
    for index, item in enumerate(flights, 1):
        rows.append(f'<tr><td>{index}</td><td><strong>{esc(flight_line(item))}</strong></td><td>{esc(_flight_time(item["departure"]))}<br>→ {esc(_flight_time(item["arrival"]))}</td><td>{esc(" / ".join(item["airports"]))}</td><td>{esc(_duration_text(item["duration"]))}</td><td>{esc(_duration_text(item["transfer"]))}</td><td class="fare">{esc(price_text(item))}</td></tr>')
    html_doc = f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(origin)} → {esc(destination)} 机票报告</title><style>body{{margin:0;background:#f3f6fb;color:#172033;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",Arial,sans-serif;line-height:1.6}}.wrap{{max-width:920px;margin:0 auto;background:#fff}}.hero{{padding:36px 42px;background:linear-gradient(135deg,#172554,#2563eb);color:#fff}}.eyebrow{{font-size:12px;letter-spacing:2px;opacity:.78}}h1{{margin:10px 0 6px;font-size:30px}}.subtitle{{opacity:.88}}.content{{padding:28px 42px 40px}}.meta{{padding:12px 14px;background:#eff6ff;border-left:4px solid #2563eb;border-radius:6px;font-size:13px;color:#425466}}.cards{{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0 24px}}.card{{flex:1 1 210px;min-width:190px;border:1px solid #e5eaf1;border-top:4px solid #2563eb;border-radius:10px;padding:14px 16px;background:#fbfcfe}}.label,.small{{font-size:12px;color:#64748b}}.big{{font-size:17px;font-weight:700;color:#172554;margin:4px 0}}h2{{margin:28px 0 14px;font-size:20px;color:#172554}}table{{width:100%;border-collapse:collapse;font-size:12px}}th{{background:#172554;color:#fff;text-align:left;padding:10px 8px}}td{{padding:9px 8px;border-bottom:1px solid #e8edf3;vertical-align:middle}}tr:nth-child(even){{background:#f8fafc}}td:first-child{{color:#94a3b8;text-align:center}}.fare{{font-weight:700;color:#172554}}.note{{font-size:12px;color:#64748b;margin-top:22px;padding-top:15px;border-top:1px solid #e8edf3}}.footer{{padding:18px 42px;background:#f8fafc;color:#94a3b8;font-size:11px}}@media(max-width:680px){{.hero,.content,.footer{{padding-left:20px;padding-right:20px}}h1{{font-size:25px}}th,td{{padding:7px 5px}}}}</style></head><body><div class="wrap"><div class="hero"><div class="eyebrow">FLIGHT SEARCH · LIVE QUERY</div><h1>{esc(origin)} → {esc(destination)}</h1><div class="subtitle">{esc(date)} · {len(flights)} 条中转方案 · 未返回直飞结果</div></div><div class="content"><div class="meta"><strong>查询时间：</strong>{esc(query_time)}（中国标准时间）<br><strong>数据源：</strong>{esc(data.get('source', '航班查询'))}</div><div class="cards">{"".join(cards)}</div><h2>全部查询结果</h2><table><thead><tr><th>#</th><th>航班</th><th>起降时间</th><th>中转航段</th><th>总耗时</th><th>中转等待</th><th>票价</th></tr></thead><tbody>{"".join(rows)}</tbody></table><div class="note">价格、税费、行李和退改规则请以购票页面为准。本次查询未返回直飞航班；报告不执行登录、下单或支付。</div></div><div class="footer">Omnirush 中国票务查询技能 · 仅供出行决策参考</div></div></body></html>'''
    html_path.write_text(html_doc, encoding="utf-8")
    return md_path, html_path


def render(input_path: Path, output_dir: Path, slug: str | None):
    data = json.loads(input_path.read_text(encoding="utf-8"))
    results = data.get("results", [])
    if results and isinstance(results[0], dict) and results[0].get("journeys"):
        return render_flight(input_path, output_dir, slug, data)
    if not results:
        raise SystemExit("查询结果为空，无法生成报告")

    first = results[0]
    date = first.get("date") or "未注明日期"
    origin = first.get("from", "出发地")
    destinations = sorted({row.get("to", "目的地") for row in results})
    destination = " / ".join(destinations)
    queried_at = data.get("queried_at", "")
    query_time = queried_at.replace("T", " ")[:19]
    slug = safe_slug(slug or f"{origin}-{destination}-{date}")
    md_path = output_dir / f"{slug}.md"
    html_path = output_dir / f"{slug}.html"

    fastest = min(results, key=lambda row: duration_minutes(row["duration"]))
    earliest = min(results, key=lambda row: row["arrival"])
    available_second_class = [
        (get_price(row, "二等座")["price"], row)
        for row in results
        if get_price(row, "二等座")
        and get_price(row, "二等座").get("availability") not in {"无票", "候补"}
    ]
    cheap = min(available_second_class, default=(None, None), key=lambda pair: pair[0])

    def recommendation(label, row):
        if not row:
            return
        lines.append(
            f"| {label} | {row['train']} | {row['to']} | "
            f"{row['departure']} → {row['arrival']} | {row['duration']} | "
            f"{price_text(row, '二等座')} | {price_text(row, '一等座')} |"
        )

    lines = [
        f"# {origin} → {destination} 高铁出行报告",
        "",
        f"> 查询日期：**{date}**  · 查询范围：直达高铁/城际（G/C）  · 数据源：12306",
        "",
        "## 结论速览",
        "",
        f"- **直达方案**：{len(results)} 条（包含不同到站车站）",
        f"- **最早抵达**：{earliest['train']}，{earliest['departure']} → {earliest['arrival']}，抵达{earliest['to']}，历时 {earliest['duration']}，二等座 {price_text(earliest, '二等座')}。",
        f"- **历时最短**：{fastest['train']}，{fastest['departure']} → {fastest['arrival']}，历时 {fastest['duration']}，二等座 {price_text(fastest, '二等座')}。",
    ]
    if cheap[1]:
        lines.append(f"- **当前二等座最低价**：{cheap[1]['train']} 到 {cheap[1]['to']}，二等座 {price_text(cheap[1], '二等座')}。")
    lines += ["", "## 推荐选择", "", "| 适合场景 | 车次 | 到达站 | 时间 | 历时 | 二等座 | 一等座 |", "|---|---:|---|---|---:|---:|---:|"]
    recommendation("尽早抵达", earliest)
    recommendation("历时最短", fastest)
    recommendation("价格优先", cheap[1])
    lines += ["", "## 全部直达车次", "", "| # | 车次 | 到达站 | 出发 | 到达 | 历时 | 二等座 | 一等座 | 商务座 |", "|---:|---:|---|---:|---:|---:|---:|---:|---:|"]
    for index, row in enumerate(results, 1):
        lines.append(
            f"| {index} | {row['train']} | {row['to']} | {row['departure']} | {row['arrival']} | {row['duration']} | "
            f"{price_text(row, '二等座')} | {price_text(row, '一等座')} | {price_text(row, '商务座')} |"
        )
    lines += [
        "",
        "## 说明",
        "",
        f"- 查询时间：`{query_time}`（中国标准时间）",
        "- “有票”“余 N 张”“无票”“候补”按查询时返回状态整理；票价和余票会动态变化。",
        "- 购买前请在官方平台再次核对出发日期、车站、余票、票价和退改规则。",
        "- 本报告仅提供查询信息，不执行登录、购票或支付。",
    ]
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    def esc(value):
        return html.escape(str(value), quote=True)

    def html_price(row, seat):
        item = get_price(row, seat)
        if not item:
            return '<span class="muted">—</span>'
        availability = item["availability"]
        cls = "available" if availability in {"有票", "充足"} or availability.startswith("余") else ("wait" if availability == "候补" else "sold")
        return f'<span class="fare">¥{item["price"]:.0f}</span><br><span class="{cls}">{esc(availability)}</span>'

    cards = []
    for title, row, accent in [("最早抵达", earliest, "#0f766e"), ("历时最短", fastest, "#2563eb"), ("二等座低价", cheap[1], "#b45309")]:
        if row:
            cards.append(
                f'<div class="card" style="border-top-color:{accent}"><div class="card-label">{title}</div>'
                f'<div class="card-train">{esc(row["train"])}</div><div class="card-main">{esc(row["departure"])} → {esc(row["arrival"])}</div>'
                f'<div class="card-sub">{esc(row["to"])} · {esc(row["duration"])} · 二等座 {html_price(row, "二等座")}</div></div>'
            )

    table_rows = []
    for index, row in enumerate(results, 1):
        table_rows.append(
            f'<tr><td>{index}</td><td><strong>{esc(row["train"])}</strong></td><td>{esc(row["to"])}</td>'
            f'<td>{esc(row["departure"])}</td><td>{esc(row["arrival"])}</td><td>{esc(row["duration"])}</td>'
            f'<td>{html_price(row, "二等座")}</td><td>{html_price(row, "一等座")}</td><td>{html_price(row, "商务座")}</td></tr>'
        )

    html_doc = f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(origin)} → {esc(destination)} 出行报告</title><style>
body{{margin:0;background:#f3f6fb;color:#172033;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",Arial,sans-serif;line-height:1.6}}.wrap{{max-width:920px;margin:0 auto;background:#fff}}.hero{{padding:36px 42px;background:linear-gradient(135deg,#0f3d56,#0f766e);color:#fff}}.eyebrow{{font-size:12px;letter-spacing:2px;text-transform:uppercase;opacity:.78}}h1{{margin:10px 0 6px;font-size:30px;line-height:1.2}}.subtitle{{font-size:15px;opacity:.88}}.content{{padding:28px 42px 40px}}.meta{{padding:12px 14px;background:#f0f7f8;border-left:4px solid #0f766e;border-radius:6px;font-size:13px;color:#425466}}h2{{margin:28px 0 14px;font-size:20px;color:#123b52}}.cards{{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0 24px}}.card{{flex:1 1 210px;min-width:190px;border:1px solid #e5eaf1;border-top:4px solid #2563eb;border-radius:10px;padding:14px 16px;background:#fbfcfe}}.card-label{{font-size:12px;color:#64748b}}.card-train{{font-size:22px;font-weight:700;color:#0f3d56}}.card-main{{font-size:16px;font-weight:600;margin-top:2px}}.card-sub{{font-size:12px;color:#64748b;margin-top:5px}}table{{width:100%;border-collapse:collapse;font-size:12px;margin-top:10px}}th{{background:#123b52;color:#fff;text-align:left;padding:10px 8px;white-space:nowrap}}td{{padding:9px 8px;border-bottom:1px solid #e8edf3;vertical-align:middle}}tr:nth-child(even){{background:#f8fafc}}td:first-child{{color:#94a3b8;text-align:center}}.fare{{font-weight:700;color:#172033}}.available{{color:#0f766e;font-size:11px}}.wait{{color:#b45309;font-size:11px}}.sold,.muted{{color:#94a3b8;font-size:11px}}.note{{font-size:12px;color:#64748b;margin-top:22px;padding-top:15px;border-top:1px solid #e8edf3}}.footer{{padding:18px 42px;background:#f8fafc;color:#94a3b8;font-size:11px}}@media(max-width:680px){{.hero,.content,.footer{{padding-left:20px;padding-right:20px}}h1{{font-size:25px}}table{{font-size:11px}}th,td{{padding:7px 5px}}}}
</style></head><body><div class="wrap"><div class="hero"><div class="eyebrow">12306 · LIVE QUERY REPORT</div><h1>{esc(origin)} → {esc(destination)}</h1><div class="subtitle">{esc(date)} · 直达高铁/城际 · 共 {len(results)} 条方案</div></div><div class="content"><div class="meta"><strong>查询时间：</strong>{esc(query_time)}（中国标准时间）<br><strong>数据源：</strong>12306 公开查询接口</div><div class="cards">{"".join(cards)}</div><h2>全部直达车次</h2><table><thead><tr><th>#</th><th>车次</th><th>到达站</th><th>出发</th><th>到达</th><th>历时</th><th>二等座</th><th>一等座</th><th>商务座</th></tr></thead><tbody>{"".join(table_rows)}</tbody></table><div class="note">“有票”“余 N 张”“无票”“候补”按查询时返回状态整理。票价和余票会动态变化；购票前请在官方 12306 页面再次核对日期、车站、余票、票价及退改规则。本报告不执行登录、购票或支付。</div></div><div class="footer">Omnirush 中国票务查询技能 · 仅供出行决策参考</div></div></body></html>'''
    html_path.write_text(html_doc, encoding="utf-8")
    return md_path, html_path


def main():
    parser = argparse.ArgumentParser(description="把票务 JSON 查询结果渲染为 Markdown 和 HTML 报告")
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path.home() / "Downloads")
    parser.add_argument("--slug")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    md_path, html_path = render(args.input, args.output_dir, args.slug)
    print(json.dumps({"markdown": str(md_path), "html": str(html_path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
