# HyperFrames Setup Notes

HyperFrames renders video from HTML through a deterministic, seekable timeline
and headless Chromium. The exact CLI version, browser path, registry, and
temporary cache are environment-dependent; never hard-code a historical
workspace path into this skill.

## Check the current environment

```bash
npx --yes hyperframes doctor --json
```

If the doctor command reports a missing browser or native dependency, follow the
currently installed `hyperframes-cli` skill. Do not upload
source media or use cloud rendering unless the user explicitly authorizes it.

## Useful commands

```bash
npx --yes hyperframes init <project> --non-interactive --example blank
npx --yes hyperframes lint <project>
npx --yes hyperframes validate <project>
npx --yes hyperframes preview <project>
npx --yes hyperframes render <project> -o <project>/render.mp4
npx --yes hyperframes catalog --query "component keyword"
npx --yes hyperframes add <registry-item>
```

Use the HyperFrames router as the entry point. Keep composition source, rendered
video, captions, and QA reports in the user's project directory.
