"""Private, review-gated experience collection. No self-approval or model calls."""

from __future__ import annotations
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import unicodedata

from file_support import (
    ErratumError,
    sha,
    packed,
    loads,
    read_regular,
    read_json,
    write_json,
    mkdir,
    root_path,
    linklike,
    MAX_FILE,
    Document,
    encode,
    snapshot_bom,
)
from document_core import TextSegment, apply_segments, extract_ai_error_terms
from current_session_ai import validate_response, request_identity, PROVIDER
from build_dictionary import Converter

VERSION = 1
DEFAULT_STORE = Path.home() / ".local/state/omnirush/erratum-correction/learning"
MAX_STORE_BYTES = 16 * 1024 * 1024
MAX_CANDIDATES = 5000
MAX_RELEASES = 500
MAX_EVIDENCE = 50
HAN = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\U00020000-\U0002fa1f]+")
NUMERALS = re.compile(
    r"[〇零一二三四五六七八九十百千万亿兆两壹贰叁肆伍陆柒捌玖拾佰仟萬億兩貳參陸廿卅卌]"
)
SENSITIVE_CONTEXT = re.compile(
    r"身份证|身分證|银行卡|銀行卡|信用卡|账户|賬戶|帳戶|账号|賬號|帳號|手机号|手機號|住址|家庭地址|护照|護照|密码|密碼|口令|令牌|API[ -]?KEY|TOKEN|SECRET|PASSWORD",
    re.I,
)


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def directory_lock(path):
    try:
        path.mkdir(mode=0o700)
    except FileExistsError:
        raise ErratumError("learning_or_job_locked_review_before_removing") from None
    identity = path.stat()
    owner_identity = None
    try:
        write_json(path / "owner.json", {"pid": os.getpid(), "created_at": now()})
        owner_identity = (path / "owner.json").lstat()
        yield
    finally:
        current = path.lstat()
        if linklike(path) or (current.st_dev, current.st_ino) != (
            identity.st_dev,
            identity.st_ino,
        ):
            raise ErratumError("learning_lock_changed")
        owner = path / "owner.json"
        if owner.exists() or owner.is_symlink():
            observed = owner.lstat()
            if (
                owner_identity is None
                or linklike(owner)
                or (observed.st_dev, observed.st_ino)
                != (owner_identity.st_dev, owner_identity.st_ino)
            ):
                raise ErratumError("learning_lock_owner_changed")
            owner.unlink()
        path.rmdir()


def candidate_id(wrong, right):
    return sha(packed([VERSION, wrong, right]))


def revision(candidate):
    return sha(packed({k: v for k, v in candidate.items() if k != "revision"}))


def refresh(candidate):
    candidate["revision"] = revision(candidate)
    return candidate


def validate_store(data):
    if (
        not isinstance(data, dict)
        or type(data.get("version")) is not int
        or data.get("version") != VERSION
        or not isinstance(data.get("candidates"), dict)
        or not isinstance(data.get("releases"), dict)
    ):
        raise ErratumError("invalid_learning_store")
    if len(data["candidates"]) > MAX_CANDIDATES:
        raise ErratumError("learning_candidate_limit")
    if len(data["releases"]) > MAX_RELEASES:
        raise ErratumError("learning_release_limit")
    for identity, item in data["candidates"].items():
        if (
            not isinstance(item, dict)
            or identity != item.get("id")
            or identity != candidate_id(item.get("wrong"), item.get("right"))
            or item.get("revision") != revision(item)
        ):
            raise ErratumError("learning_candidate_changed")
        if item.get("status") not in ("pending", "approved", "rejected", "published"):
            raise ErratumError("invalid_learning_status")
        if (
            any(
                not isinstance(item.get(key), str)
                or not 2 <= len(item[key]) <= 80
                or not HAN.fullmatch(item[key])
                for key in ("wrong", "right")
            )
            or item["wrong"] == item["right"]
        ):
            raise ErratumError("invalid_learning_candidate_text")
        if not isinstance(item.get("flags"), list) or any(
            not isinstance(flag, str) for flag in item["flags"]
        ):
            raise ErratumError("invalid_learning_flags")
        if not isinstance(item.get("review_history"), list) or any(
            not isinstance(event, dict) for event in item["review_history"]
        ):
            raise ErratumError("invalid_learning_history")
        if (
            not isinstance(item.get("evidence"), dict)
            or not 1 <= len(item["evidence"]) <= MAX_EVIDENCE
        ):
            raise ErratumError("invalid_learning_evidence")
        for content_id, evidence in item["evidence"].items():
            if (
                not isinstance(evidence, dict)
                or evidence.get("content_id") != content_id
                or not re.fullmatch(r"[0-9a-f]{64}", content_id)
                or any(
                    not isinstance(evidence.get(key), str)
                    for key in (
                        "source_sha256",
                        "source_path",
                        "job_dir",
                        "work_sha256",
                        "before_context",
                        "after_context",
                    )
                )
                or max(len(evidence["before_context"]), len(evidence["after_context"]))
                > 128
            ):
                raise ErratumError("invalid_learning_evidence")
        if item["status"] == "approved":
            rule = item.get("approved_rule")
            if (
                not isinstance(rule, dict)
                or set(rule) != {"wrong", "right"}
                or any(
                    not isinstance(rule[key], str)
                    or not 4 <= len(rule[key]) <= 24
                    or not HAN.fullmatch(rule[key])
                    for key in ("wrong", "right")
                )
                or rule["wrong"] not in item["wrong"]
                or item["wrong"].replace(rule["wrong"], rule["right"]) != item["right"]
            ):
                raise ErratumError("invalid_learning_approved_rule")
    for plan, record in data["releases"].items():
        if (
            not isinstance(record, dict)
            or record.get("plan_id") != plan
            or not re.fullmatch(r"[0-9a-f]{64}", plan)
            or not isinstance(record.get("release_dir"), str)
            or not Path(record["release_dir"]).is_absolute()
            or record.get("status")
            not in ("staged", "published", "rolled_back", "recovered")
            or not isinstance(record.get("candidates"), dict)
            or not 1 <= len(record["candidates"]) <= 100
            or any(
                key not in data["candidates"]
                or not isinstance(value, str)
                or not re.fullmatch(r"[0-9a-f]{64}", value)
                for key, value in record["candidates"].items()
            )
        ):
            raise ErratumError("invalid_learning_release_record")
    return data


@contextmanager
def store_session(directory, create=False):
    root = root_path(directory)
    if root.is_relative_to(Path(__file__).resolve().parents[1]):
        raise ErratumError("private_learning_store_must_be_outside_skill_source")
    if not root.exists() and not create:
        raise ErratumError("learning_store_not_found")
    mkdir(root, root)
    info = root.stat()
    if os.name == "posix" and (
        (info.st_mode & 0o077) or (hasattr(os, "getuid") and info.st_uid != os.getuid())
    ):
        raise ErratumError("learning_store_must_be_private_and_owned")
    with directory_lock(root / ".lock"):
        path = root / "candidates.json"
        if path.exists():
            data = validate_store(read_json(path, MAX_STORE_BYTES, root))
        elif create:
            data = {
                "version": VERSION,
                "created_at": now(),
                "candidates": {},
                "releases": {},
            }
        else:
            raise ErratumError("learning_store_not_found")
        yield root, data


def save_store(root, data):
    validate_store(data)
    if len(packed(data)) > MAX_STORE_BYTES:
        raise ErratumError("learning_store_over_16_mib_use_another_store")
    write_json(root / "candidates.json", data, replace=True)


def reconstruct_final(job, item, work, options):
    """Do not learn from report prose alone: replay validated accepted answers."""
    from correct_chinese_errata import batch_units, relative_path

    receipt = read_json(
        job / ".work/completed" / f"{item['id']}.json", MAX_FILE * 8, job
    )
    if (
        receipt.get("status") not in ("corrected", "no_ai_needed", "local_only")
        or receipt.get("work_sha256") != item["work_sha256"]
    ):
        raise ErratumError("learning_requires_completed_document")
    local = work["local_texts"]
    final = list(local)
    groups, mapping = (
        batch_units(work, options["ai_batch_chars"]) if options["use_ai"] else ([], [])
    )
    by_segment = {}
    for number, group in enumerate(groups):
        payload = {"document_sha256": item["work_sha256"], "items": group}
        accepted = read_json(
            job / ".work/accepted" / item["id"] / f"{number:06d}.json", 1024 * 1024, job
        )
        values = validate_response(accepted, request_identity(payload), group)
        for index, text in values.items():
            segment, start, end = mapping[index]
            by_segment.setdefault(segment, []).append((start, end, text))
    for segment, edits in by_segment.items():
        cursor = 0
        parts = []
        for start, end, text in sorted(edits):
            parts.extend((local[segment][cursor:start], text))
            cursor = end
        parts.append(local[segment][cursor:])
        final[segment] = "".join(parts)
    segments = [TextSegment(s["start"], s["end"], s["text"]) for s in work["segments"]]
    text = apply_segments(work["text"], segments, final)
    expected = encode(
        text,
        Document(work["text"], work["encoding"], snapshot_bom(work["bom"])),
        options["output_encoding"],
    )
    output = job / "files" / relative_path(item["output"])
    actual = read_regular(output, MAX_FILE * 4, job)
    if actual != expected or sha(actual) != receipt.get("output_sha256"):
        raise ErratumError("learning_output_or_receipt_mismatch")
    # The receipt's AI diff list must describe the actual accepted transformations.
    derived = {
        i: (before, after)
        for i, (before, after) in enumerate(zip(local, final))
        if before != after
    }
    claimed = {}
    for change in receipt.get("changes", []):
        if change.get("stage") != "ai":
            continue
        idx = change.get("segment")
        if type(idx) is not int or idx in claimed or change.get("provider") != PROVIDER:
            raise ErratumError("learning_ai_report_invalid")
        claimed[idx] = (change.get("before"), change.get("after"))
    if derived != claimed:
        raise ErratumError("learning_ai_report_not_supported_by_output")
    return derived


def changed_numerals(before, after):
    try:
        diffs = extract_ai_error_terms(before, after)
    except Exception:
        return True
    return any(NUMERALS.search(d["before"] + d["after"]) for d in diffs)


def extract_observations(path, converter):
    from correct_chinese_errata import load_job

    job = Path(path).expanduser().absolute()
    if not job.is_dir() or linklike(job):
        raise ErratumError("learning_job_missing_or_link")
    job = job.resolve()
    observations = []
    skipped = Counter()
    with directory_lock(job / ".lock"):
        job, manifest, works = load_job(job)
        # One immutable completed receipt per document, not merely an old report.
        for item in manifest["documents"]:
            if not (job / ".work/completed" / f"{item['id']}.json").exists():
                raise ErratumError("learning_job_incomplete")
        dictionary = read_json(job / ".work/dictionary.json", 2 * 1024 * 1024, job)
        known = {}
        for wrong, right in dictionary.items():
            if not wrong.startswith("_") and isinstance(right, str):
                known.setdefault(converter.simplify(wrong), set()).add(
                    converter.simplify(right)
                )
        for wrong, options in dictionary.get("_script_sensitive", {}).items():
            known.setdefault(converter.simplify(wrong), set()).add(
                converter.simplify(options["simplified"])
            )
        for item, work in zip(manifest["documents"], works):
            changes = reconstruct_final(job, item, work, manifest["options"])
            if not manifest["options"]["use_ai"]:
                skipped["local_only_not_ai_evidence"] += 1
                continue
            # Same content in different paths/encodings/line endings/scripts is
            # counted once. This is content diversity, not statistical independence.
            normalized = unicodedata.normalize("NFC", converter.simplify(work["text"]))
            content_id = sha(re.sub(r"\s+", " ", normalized).strip().encode())
            for segment, (before, after) in changes.items():
                if before != work["segments"][segment]["text"]:
                    skipped["local_stage_modified_segment_not_learned"] += 1
                    continue
                if len(before) > 10000 or len(after) > 10000:
                    skipped["very_long_segment_requires_manual_review"] += 1
                    continue
                if SENSITIVE_CONTEXT.search(before + after):
                    skipped["sensitive_context_not_collected"] += 1
                    continue
                if any(
                    word in before
                    for word in ("错别字示例", "错误写法", "误写为", "不要写成")
                ):
                    skipped["instructional_example_not_collected"] += 1
                    continue
                parts_before = list(HAN.finditer(before))
                parts_after = list(HAN.finditer(after))
                if len(parts_before) != len(parts_after):
                    skipped["unmatched_phrase_boundaries"] += 1
                    continue
                for old, new in zip(parts_before, parts_after):
                    a, b = old.group(), new.group()
                    if a == b:
                        continue
                    if not (2 <= len(a) <= 80 and 2 <= len(b) <= 80):
                        skipped["phrase_length_requires_manual_analysis"] += 1
                        continue
                    if changed_numerals(a, b) or (
                        NUMERALS.search(a + b)
                        and any(
                            unit in a + b
                            for unit in (
                                "元",
                                "角",
                                "分",
                                "米",
                                "斤",
                                "吨",
                                "噸",
                                "克",
                                "升",
                                "度",
                                "年",
                                "月",
                                "日",
                                "天",
                                "时",
                                "時",
                                "秒",
                                "人",
                                "个",
                                "個",
                            )
                        )
                    ):
                        skipped["numeric_or_quantity_change_not_learned"] += 1
                        continue
                    wrong, right = converter.simplify(a), converter.simplify(b)
                    if wrong == right:
                        skipped["script_only_or_normalized_noop"] += 1
                        continue
                    if (
                        len(wrong) < 2
                        or len(right) < 2
                        or not HAN.fullmatch(wrong)
                        or not HAN.fullmatch(right)
                    ):
                        skipped["non_chinese_or_single_character_rule"] += 1
                        continue
                    if any(
                        key in wrong and wrong.replace(key, target) == right
                        for key, targets in known.items()
                        for target in targets
                    ):
                        skipped["already_known_rule_not_new_experience"] += 1
                        continue
                    identity = candidate_id(wrong, right)
                    flags = [
                        "unverified_ai_observation",
                        "context_and_names_require_human_review",
                    ]
                    if min(len(wrong), len(right)) < 4:
                        flags.append("too_short_for_global_release")
                    if max(len(wrong), len(right)) > 24:
                        flags.append("long_phrase_requires_refinement")
                    evidence = {
                        "content_id": content_id,
                        "source_sha256": item["source_sha256"],
                        "source_path": item["source"],
                        "job_dir": str(job),
                        "document_id": item["id"],
                        "work_sha256": item["work_sha256"],
                        "segment": segment,
                        "line": work["segments"][segment]["line"],
                        "before_context": before[
                            max(0, old.start() - 24) : min(len(before), old.end() + 24)
                        ],
                        "after_context": after[
                            max(0, new.start() - 24) : min(len(after), new.end() + 24)
                        ],
                        "observed_at": now(),
                        "provider": PROVIDER,
                        "dictionary_sha256": manifest["dictionary_sha256"],
                        "normalization": getattr(
                            converter, "info", {"unspecified": True}
                        ),
                    }
                    observations.append(
                        {
                            "id": identity,
                            "wrong": wrong,
                            "right": right,
                            "flags": flags,
                            "evidence": evidence,
                        }
                    )
                    if len(observations) > 20000:
                        raise ErratumError("learning_observation_limit")
    return observations, dict(skipped)


def collect_job(job, store=DEFAULT_STORE, converter=None):
    converter = converter or Converter()
    observations, skipped = extract_observations(job, converter)
    added = 0
    new_candidates = 0
    duplicates = 0
    capped = 0
    with store_session(store, create=True) as (root, data):
        for observation in observations:
            identity = observation["id"]
            evidence = observation["evidence"]
            content_id = evidence["content_id"]
            item = data["candidates"].get(identity)
            if item is None:
                if len(data["candidates"]) >= MAX_CANDIDATES:
                    raise ErratumError("learning_candidate_limit")
                item = {
                    "id": identity,
                    "wrong": observation["wrong"],
                    "right": observation["right"],
                    "status": "pending",
                    "flags": observation["flags"],
                    "evidence": {},
                    "review_history": [],
                    "created_at": now(),
                }
                data["candidates"][identity] = item
                new_candidates += 1
            if content_id in item["evidence"] or any(
                old["source_sha256"] == evidence["source_sha256"]
                for old in item["evidence"].values()
            ):
                duplicates += 1
                continue
            if len(item["evidence"]) >= MAX_EVIDENCE:
                capped += 1
                continue
            item["evidence"][content_id] = evidence
            added += 1
            if item["status"] == "approved":
                item["status"] = "pending"
                item.pop("approved_rule", None)
            refresh(item)
        save_store(root, data)
    return {
        "status": "collected",
        "store": str(root),
        "new_candidates": new_candidates,
        "new_content_evidence": added,
        "duplicate_content_evidence": duplicates,
        "evidence_limit_skipped": capped,
        "skipped": skipped,
        "dictionary_changed": False,
        "automatically_approved": 0,
    }


def conflicts(data, item):
    return [
        x["id"]
        for x in data["candidates"].values()
        if x["id"] != item["id"]
        and x["wrong"] == item["wrong"]
        and x["right"] != item["right"]
        and x["status"] != "rejected"
    ]


def summaries(data):
    return [
        {
            "id": item["id"],
            "revision": item["revision"],
            "status": item["status"],
            "unique_contents": len(item["evidence"]),
            "flags": item["flags"],
            "conflicts": conflicts(data, item),
        }
        for item in data["candidates"].values()
    ]


def list_candidates(store=DEFAULT_STORE, show_text=False, offset=0, limit=100):
    if (
        type(offset) is not int
        or offset < 0
        or type(limit) is not int
        or not 1 <= limit <= 200
    ):
        raise ErratumError("invalid_candidate_page")
    if not root_path(store).exists():
        return {
            "status": "listed",
            "candidates": [],
            "total": 0,
            "next_offset": None,
            "dictionary_changed": False,
            "store_not_created": True,
        }
    with store_session(store) as (_, data):
        all_rows = sorted(
            summaries(data),
            key=lambda row: (
                {"pending": 0, "approved": 1, "published": 2, "rejected": 3}[
                    row["status"]
                ],
                -row["unique_contents"],
                row["id"],
            ),
        )
        result = all_rows[offset : offset + limit]
        if show_text:
            for row in result:
                row.update(
                    wrong=data["candidates"][row["id"]]["wrong"],
                    right=data["candidates"][row["id"]]["right"],
                )
        return {
            "status": "listed",
            "candidates": result,
            "total": len(all_rows),
            "next_offset": offset + limit if offset + limit < len(all_rows) else None,
            "dictionary_changed": False,
        }


def inspect_candidate(identity, store=DEFAULT_STORE):
    with store_session(store) as (_, data):
        if identity not in data["candidates"]:
            raise ErratumError("candidate_not_found")
        item = data["candidates"][identity]
        return {
            "status": "unverified_candidate",
            "candidate": item,
            "conflicts": conflicts(data, item),
            "warning": "Contains private excerpts. Observations are not proof of correct or globally safe spelling. No model training or automatic publication occurs.",
        }


def review_candidates(decisions, store=DEFAULT_STORE, converter=None):
    if not isinstance(decisions, list) or not 1 <= len(decisions) <= 100:
        raise ErratumError("review_file_requires_1_to_100_decisions")
    if len({d.get("candidate_id") for d in decisions if isinstance(d, dict)}) != len(
        decisions
    ):
        raise ErratumError("duplicate_or_invalid_review_decisions")
    converter = converter or Converter()
    reviewed = []
    with store_session(store) as (root, data):
        for decision in decisions:
            if not isinstance(decision, dict) or set(decision) - {
                "candidate_id",
                "expect_revision",
                "decision",
                "wrong",
                "right",
                "reason",
                "confirmed_by_user",
            }:
                raise ErratumError("invalid_review_decision")
            item = data["candidates"].get(decision.get("candidate_id"))
            if item is None:
                raise ErratumError("candidate_not_found")
            if decision.get("expect_revision") != item["revision"]:
                raise ErratumError("candidate_revision_changed")
            if (
                decision.get("confirmed_by_user") is not True
                or not isinstance(decision.get("reason"), str)
                or not 1 <= len(decision["reason"].strip()) <= 500
            ):
                raise ErratumError("explicit_human_review_and_reason_required")
            if item["status"] == "published":
                raise ErratumError("published_candidate_requires_rollback")
            action = decision.get("decision")
            if action not in ("approve", "reject"):
                raise ErratumError("invalid_review_action")
            event = {
                "decision": action,
                "reason": decision["reason"],
                "at": now(),
                "reviewed_revision": item["revision"],
                "confirmation": "user-confirmed by invoking workflow; not independently authenticated",
            }
            if action == "approve":
                wrong = decision.get("wrong", item["wrong"])
                right = decision.get("right", item["right"])
                if (
                    not isinstance(wrong, str)
                    or not isinstance(right, str)
                    or not (4 <= len(wrong) <= 24 and 4 <= len(right) <= 24)
                    or not HAN.fullmatch(wrong)
                    or not HAN.fullmatch(right)
                    or wrong == right
                ):
                    raise ErratumError(
                        "approved_rule_requires_4_to_24_chinese_characters"
                    )
                if (
                    converter.simplify(wrong) != wrong
                    or converter.simplify(right) != right
                ):
                    raise ErratumError("approved_rule_must_be_simplified")
                if (
                    wrong not in item["wrong"]
                    or item["wrong"].replace(wrong, right) != item["right"]
                ):
                    raise ErratumError("refined_rule_not_supported_by_observed_change")
                if wrong == item["wrong"] and conflicts(data, item):
                    raise ErratumError("candidate_has_unresolved_alternative_targets")
                item["approved_rule"] = {"wrong": wrong, "right": right}
                event["rule"] = item["approved_rule"]
                item["status"] = "approved"
            else:
                item["status"] = "rejected"
                item.pop("approved_rule", None)
            item["review_history"].append(event)
            if len(item["review_history"]) > 100:
                raise ErratumError("review_history_limit")
            refresh(item)
            reviewed.append(
                {
                    "id": item["id"],
                    "status": item["status"],
                    "revision": item["revision"],
                }
            )
        save_store(root, data)
    return {"status": "reviewed", "candidates": reviewed, "dictionary_changed": False}
