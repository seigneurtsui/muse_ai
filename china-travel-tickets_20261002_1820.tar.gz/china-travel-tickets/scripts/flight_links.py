#!/usr/bin/env python3
"""Build browser search links for current China flight information.

No API key, login, booking, or payment is involved. Links are only search entry
points; the caller must inspect the live result page before reporting fares.
"""
from __future__ import annotations

import argparse
import json
import urllib.parse
from datetime import datetime
from zoneinfo import ZoneInfo

# Common airport codes make the Ctrip/Google links more useful. Unknown cities
# still work through the Chinese web-search links below.
AIRPORTS = {
    "北京": "PEK", "上海": "SHA", "广州": "CAN", "深圳": "SZX", "成都": "CTU",
    "重庆": "CKG", "杭州": "HGH", "南京": "NKG", "武汉": "WUH", "西安": "XIY",
    "厦门": "XMN", "长沙": "CSX", "郑州": "CGO", "青岛": "TAO", "昆明": "KMG",
    "海口": "HAK", "三亚": "SYX", "天津": "TSN", "大连": "DLC", "沈阳": "SHE",
    "哈尔滨": "HRB", "贵阳": "KWE", "南宁": "NNG", "福州": "FOC", "济南": "TNA",
    "合肥": "HFE", "南昌": "KHN", "太原": "TYN", "乌鲁木齐": "URC",
}


def airport_or_city(value: str) -> tuple[str, str]:
    value = value.strip()
    upper = value.upper()
    if len(upper) == 3 and upper.isalpha():
        return value, upper
    return value, AIRPORTS.get(value, "")


def main() -> int:
    parser = argparse.ArgumentParser(description="生成无需 API Key 的国内机票实时查询入口")
    parser.add_argument("--from", dest="origin", required=True, help="出发城市或机场三字码")
    parser.add_argument("--to", dest="destination", required=True, help="到达城市或机场三字码")
    parser.add_argument("--date", required=True, help="出发日期 YYYY-MM-DD")
    parser.add_argument("--format", choices=("text", "json"), default="text")
    args = parser.parse_args()
    try:
        datetime.strptime(args.date, "%Y-%m-%d")
    except ValueError:
        parser.error("--date 必须是 YYYY-MM-DD")
    origin_name, origin_code = airport_or_city(args.origin)
    destination_name, destination_code = airport_or_city(args.destination)
    query = f"{origin_name} 到 {destination_name} 机票 {args.date} 价格 航班"
    links = {
        "百度搜索": "https://www.baidu.com/s?" + urllib.parse.urlencode({"wd": query}),
        "Google Flights": "https://www.google.com/travel/flights?" + urllib.parse.urlencode({"q": f"Flights from {origin_name} to {destination_name} on {args.date}", "hl": "zh-CN", "curr": "CNY"}),
        "携程航班": "https://flights.ctrip.com/online/list/oneway-{}-{}?depdate={}".format(origin_code or urllib.parse.quote(origin_name), destination_code or urllib.parse.quote(destination_name), args.date),
        "去哪儿搜索": "https://flight.qunar.com/site/oneway_list.htm?" + urllib.parse.urlencode({"searchDepartureAirport": origin_name, "searchArrivalAirport": destination_name, "searchDepartureTime": args.date}),
    }
    result = {
        "source": "browser-search-links",
        "queried_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
        "origin": {"name": origin_name, "airport_code": origin_code or None},
        "destination": {"name": destination_name, "airport_code": destination_code or None},
        "date": args.date,
        "query": query,
        "links": links,
        "note": "这些是实时查询入口，不是已验证的票价。打开页面后再报告航班、价格、税费和行李规则。",
    }
    if args.format == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"{origin_name} → {destination_name}，日期：{args.date}")
        print("以下入口无需 API Key；请打开页面查看实时结果：")
        for name, url in links.items():
            print(f"- {name}: {url}")
        print("注意：链接本身不代表当前票价，需以实时页面为准。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
