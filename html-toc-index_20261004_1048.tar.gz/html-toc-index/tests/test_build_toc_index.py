from __future__ import annotations

import json
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import build_toc_index as app


def page(title: str, body: str) -> str:
    return f"<!doctype html><html><head><title>{title}</title></head><body>{body}</body></html>"


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        self.input = self.root / "in"
        self.output = self.root / "out"
        self.input.mkdir()

    def write(self, name: str, content: str) -> Path:
        path = self.input / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return path

    def args(self, *extra: str):
        return app.build_parser().parse_args(
            [str(self.input), "-o", str(self.output), *extra]
        )

    def run_tool(self, *extra: str):
        return app.run(self.args(*extra))


class TextTests(unittest.TestCase):
    def test_clean_text_collapses_whitespace_and_fullwidth(self):
        self.assertEqual(app.clean_text("  a\u3000 b \n c "), "a b c")
        self.assertEqual(app.clean_text(""), "")

    def test_parse_filename_timestamp_both_patterns(self):
        dt, rest = app.parse_filename_timestamp("20240101_120000_nanjing")
        self.assertEqual((dt.year, dt.month, dt.day, dt.hour), (2024, 1, 1, 12))
        self.assertEqual(rest, "nanjing")
        dt, rest = app.parse_filename_timestamp("20231231T235959==z--shanghai")
        self.assertEqual((dt.year, dt.month, dt.day, dt.minute), (2023, 12, 31, 59))
        self.assertEqual(rest, "shanghai")
        dt, rest = app.parse_filename_timestamp("plain")
        self.assertIsNone(dt)
        self.assertEqual(rest, "plain")

    def test_extract_title_strips_timestamp_and_falls_back(self):
        raw = page("20240101T120000==z--南京周末", "<p>x</p>")
        self.assertEqual(
            app.extract_title(raw, "20240101T120000==z--x.html"), "南京周末"
        )
        self.assertEqual(
            app.extract_title("<html></html>", "20240101_090000_beijing.html"),
            "beijing",
        )
        self.assertEqual(app.extract_title(page("untitled", ""), "file.html"), "file")

    def test_summary_and_word_count(self):
        raw = page("t", "<h1>标题</h1><script>bad()</script><p>正文内容</p>")
        summary = app.extract_summary(raw)
        self.assertIn("正文内容", summary)
        self.assertNotIn("bad()", summary)
        self.assertEqual(app.count_words(raw), len("标题 正文内容"))

    def test_summary_truncates(self):
        raw = page("t", "x" * 500)
        self.assertTrue(app.extract_summary(raw, max_len=10).endswith("…"))

    def test_date_from_content(self):
        self.assertEqual(
            app.extract_date_from_content("日期 2024年3月5日 天气").isoformat()[:10],
            "2024-03-05",
        )
        self.assertIsNone(app.extract_date_from_content("no date here"))


class IdTests(unittest.TestCase):
    def test_doc_id_stable_and_sensitive(self):
        first = app.compute_doc_id("a.html", "body")
        self.assertEqual(first, app.compute_doc_id("a.html", "body"))
        self.assertEqual(len(first), 6)
        self.assertNotEqual(first, app.compute_doc_id("a.html", "other"))
        self.assertNotEqual(first, app.compute_doc_id("b.html", "body"))


class TagsTests(unittest.TestCase):
    def test_place_dictionary_and_email(self):
        tags = app.guess_tags(
            "南京周末", "20240101T120000==z--nanjing.html", app.KNOWN_PLACES
        )
        self.assertIn("南京", tags)
        email_tags = app.guess_tags("X", "trip-email.html", app.KNOWN_PLACES)
        self.assertIn("email 版", email_tags)

    def test_fallback_keywords_and_uncategorized(self):
        tags = app.guess_tags("阿里-徒步-线路", "x.html", app.KNOWN_PLACES)
        self.assertTrue(tags)
        self.assertNotEqual(tags, ["未分类"])
        uncategorized = app.guess_tags("", "x.html", [])
        self.assertEqual(uncategorized, ["未分类"])


class PlacesTests(Base):
    def test_missing_places_file_uses_builtin(self):
        self.assertEqual(app.load_places_file(self.root / "nope.txt"), app.KNOWN_PLACES)

    def test_custom_places_file_ignores_comments(self):
        path = self.root / "places.txt"
        path.write_text("# comment\n敦煌\n\n张掖\n", encoding="utf-8")
        self.assertEqual(app.load_places_file(path), ["敦煌", "张掖"])

    def test_none_returns_builtin_copy(self):
        result = app.load_places_file(None)
        self.assertEqual(result, app.KNOWN_PLACES)
        self.assertIsNot(result, app.KNOWN_PLACES)


class ScanTests(Base):
    def test_scan_skips_index_non_html_and_symlink(self):
        self.write("a.html", page("A", "a"))
        self.write("b.txt", "not html")
        self.write("index.html", page("Index", "i"))
        nested = self.input / "sub" / "c.html"
        nested.parent.mkdir()
        nested.write_text(page("C", "c"), encoding="utf-8")
        link = self.input / "link.html"
        try:
            link.symlink_to(self.input / "a.html")
            has_symlink = True
        except OSError:
            has_symlink = False

        top = app.scan_files(self.input, False, [])
        self.assertEqual([p.name for p in top], ["a.html"])
        recursive = app.scan_files(self.input, True, [])
        names = {p.name for p in recursive}
        self.assertIn("c.html", names)
        self.assertNotIn("index.html", names)
        if has_symlink:
            self.assertNotIn("link.html", names)

    def test_exclude_pattern(self):
        self.write("keep.html", page("K", "k"))
        self.write("drop-email.html", page("D", "d"))
        files = app.scan_files(self.input, False, [r"-email"])
        self.assertEqual([p.name for p in files], ["keep.html"])


class InjectTests(unittest.TestCase):
    def test_inject_adds_ids_and_nav(self):
        raw = page("T", "<h1>标题</h1><h2>第一节</h2><h2>第二节</h2>")
        injected, count = app.inject_doc_toc(raw)
        self.assertEqual(count, 3)
        self.assertIn(app.DOC_TOC_MARKER, injected)
        self.assertIn('id="标题"', injected)
        self.assertIn('href="#第一节"', injected)

    def test_inject_idempotent(self):
        raw = page("T", "<h1>A</h1><h2>B</h2>")
        once, _ = app.inject_doc_toc(raw)
        twice, count = app.inject_doc_toc(once)
        self.assertEqual(count, 0)
        self.assertEqual(twice, once)
        self.assertEqual(once.count('class="doc-toc"'), 1)

    def test_inject_skips_when_too_few_headings(self):
        raw = page("T", "<h1>Only one</h1>")
        injected, count = app.inject_doc_toc(raw)
        self.assertEqual((injected, count), (raw, 0))

    def test_inject_preserves_existing_ids_and_dedupes(self):
        raw = page("T", '<h1 id="keep">标题</h1><h2>重复</h2><h2>重复</h2>')
        injected, _ = app.inject_doc_toc(raw)
        self.assertIn('id="keep"', injected)
        self.assertIn('id="重复"', injected)
        self.assertIn('id="重复-1"', injected)


class WriteTests(Base):
    def _record(self, name: str, content: str):
        return app.process_file(self.write(name, content), app.KNOWN_PLACES)

    def test_write_atomic_creates_and_replaces(self):
        target = self.root / "deep" / "file.txt"
        app.write_atomic(target, "one")
        self.assertEqual(target.read_text(encoding="utf-8"), "one")
        app.write_atomic(target, "two")
        self.assertEqual(target.read_text(encoding="utf-8"), "two")

    def test_full_update_writes_doc_dirs(self):
        records = [self._record("a.html", page("A", "a"))]
        written = app.full_update(self.output, records)
        self.assertEqual(written, [records[0]["doc_id"]])
        self.assertTrue(
            (self.output / f"doc-{records[0]['doc_id']}" / "index.html").is_file()
        )

    def test_incremental_skips_and_prunes(self):
        first = self._record("a.html", page("A", "a"))
        app.incremental_update(self.output, [first])
        written, skipped, deleted = app.incremental_update(self.output, [first])
        self.assertEqual((written, skipped, deleted), ([], [first["doc_id"]], []))
        # A different document set prunes the stale folder.
        second = self._record("b.html", page("B", "b"))
        written, skipped, deleted = app.incremental_update(self.output, [second])
        self.assertEqual(written, [second["doc_id"]])
        self.assertEqual(deleted, [first["doc_id"]])
        self.assertFalse((self.output / f"doc-{first['doc_id']}").exists())

    def test_clean_output_only_removes_owned(self):
        self.output.mkdir()
        (self.output / "doc-abc").mkdir()
        (self.output / "index.html").write_text("x", encoding="utf-8")
        (self.output / "data.json").write_text("x", encoding="utf-8")
        keep = self.output / "keepme.txt"
        keep.write_text("keep", encoding="utf-8")
        removed = app.clean_output(self.output)
        self.assertEqual(removed, 3)
        self.assertTrue(keep.is_file())
        self.assertFalse((self.output / "doc-abc").exists())


class ExportTests(Base):
    def test_exports(self):
        records = [
            app.process_file(self.write("a.html", page("Alpha", "a")), app.KNOWN_PLACES)
        ]
        self.output.mkdir()
        app.export_json(self.output, records)
        app.export_markdown(self.output, records)
        app.export_txt(self.output, records)
        payload = json.loads((self.output / "data.json").read_text(encoding="utf-8"))
        self.assertEqual(payload[0]["title"], "Alpha")
        self.assertNotIn("content", payload[0])
        self.assertIn(
            "文档索引", (self.output / "INDEX.md").read_text(encoding="utf-8")
        )
        self.assertEqual(
            (self.output / "file_list.txt").read_text(encoding="utf-8"), "a.html"
        )


class IndexTests(Base):
    def test_render_index_has_no_leftover_tokens_and_parses_data(self):
        records = [
            app.process_file(
                self.write("a.html", page("标题 <b>x</b>", "hello")), app.KNOWN_PLACES
            )
        ]
        rendered = app.render_index("我的索引", records, "2026-01-01 00:00:00")
        for token in (
            "__PAGE_TITLE__",
            "__TOTAL__",
            "__GENERATED_AT__",
            "__DATA_JSON__",
            "__ITEMS__",
        ):
            self.assertNotIn(token, rendered)
        self.assertIn("我的索引", rendered)
        match = re.search(r"const DATA = (\[.*?\]);", rendered, re.DOTALL)
        data = json.loads(match.group(1))
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0]["title"], "标题 <b>x</b>")

    def test_render_index_escapes_page_title(self):
        rendered = app.render_index("<script>", [], "now")
        self.assertIn("&lt;script&gt;", rendered)


class RunTests(Base):
    def test_run_complete_and_writes_index(self):
        self.write("a.html", page("Alpha", "a"))
        self.write("b.html", page("Beta", "b"))
        report, code = self.run_tool("--json")
        self.assertEqual(code, 0)
        self.assertEqual(report["status"], "complete")
        self.assertEqual(report["summary"]["written"], 2)
        self.assertTrue((self.output / "index.html").is_file())

    def test_dry_run_writes_nothing(self):
        self.write("a.html", page("Alpha", "a"))
        report, code = self.run_tool("--dry-run")
        self.assertEqual(code, 0)
        self.assertEqual(report["status"], "dry_run")
        self.assertFalse(self.output.exists())

    def test_empty_input_is_complete(self):
        report, code = self.run_tool()
        self.assertEqual(code, 0)
        self.assertEqual(report["summary"]["total"], 0)

    def test_output_within_input_rejected(self):
        with self.assertRaisesRegex(app.BuildError, "output_within_input"):
            app.run(
                app.build_parser().parse_args(
                    [str(self.input), "-o", str(self.input / "out")]
                )
            )

    def test_output_equals_input_rejected(self):
        with self.assertRaisesRegex(app.BuildError, "output_equals_input"):
            app.run(
                app.build_parser().parse_args([str(self.input), "-o", str(self.input)])
            )

    def test_missing_input_rejected(self):
        with self.assertRaisesRegex(app.BuildError, "input_not_found"):
            app.run(
                app.build_parser().parse_args(
                    [str(self.root / "nope"), "-o", str(self.output)]
                )
            )

    def test_partial_failure_on_read_error(self):
        self.write("a.html", page("A", "a"))
        self.write("b.html", page("B", "b"))
        original = app.process_file

        def flaky(path, places, *, inject_toc=False):
            if path.name == "b.html":
                raise app.BuildError("read_failed")
            return original(path, places, inject_toc=inject_toc)

        with patch.object(app, "process_file", side_effect=flaky):
            report, code = self.run_tool()
        self.assertEqual(code, 2)
        self.assertEqual(report["status"], "partial_failure")
        self.assertEqual(report["summary"]["failed"], 1)

    def test_inject_flag_reports_toc_items(self):
        self.write("a.html", page("T", "<h1>A</h1><h2>B</h2>"))
        report, _ = self.run_tool("--inject-doc-toc")
        self.assertEqual(report["docs"][0]["toc_items"], 2)
        doc = self.output / f"doc-{report['docs'][0]['doc_id']}" / "index.html"
        self.assertIn(app.DOC_TOC_MARKER, doc.read_text(encoding="utf-8"))


class CliTests(Base):
    def test_resolve_jobs(self):
        self.assertEqual(app.resolve_jobs("auto", 100), app.DEFAULT_JOBS_CAP)
        self.assertEqual(app.resolve_jobs("3", 10), 3)
        self.assertEqual(app.resolve_jobs("99", 2), 2)
        self.assertEqual(app.resolve_jobs(None, 0), 1)
        with self.assertRaisesRegex(app.BuildError, "invalid_jobs_value"):
            app.resolve_jobs("many", 5)

    def test_help_and_version(self):
        script = Path(app.__file__)
        for flag in ("--help", "--version"):
            result = subprocess.run(
                [sys.executable, "-B", str(script), flag],
                capture_output=True,
                text=True,
                timeout=30,
            )
            self.assertEqual(result.returncode, 0, result.stderr)

    def test_real_subprocess_dry_run_and_run(self):
        script = Path(app.__file__)
        source = self.root / "src"
        source.mkdir()
        (source / "a.html").write_text(page("Alpha", "a"), encoding="utf-8")
        out = self.root / "site"
        dry = subprocess.run(
            [
                sys.executable,
                "-B",
                str(script),
                str(source),
                "-o",
                str(out),
                "--dry-run",
                "--json",
            ],
            capture_output=True,
            text=True,
            timeout=60,
        )
        self.assertEqual(dry.returncode, 0, dry.stderr)
        self.assertEqual(json.loads(dry.stdout)["status"], "dry_run")
        self.assertFalse(out.exists())
        real = subprocess.run(
            [sys.executable, "-B", str(script), str(source), "-o", str(out), "--json"],
            capture_output=True,
            text=True,
            timeout=60,
        )
        self.assertEqual(real.returncode, 0, real.stderr)
        self.assertEqual(json.loads(real.stdout)["status"], "complete")
        self.assertTrue((out / "index.html").is_file())

    def test_normalize_argv_keeps_dash_values(self):
        normalized = app._normalize_argv(
            ["in", "--exclude-pattern", "-email", "-o", "out"]
        )
        self.assertEqual(normalized, ["in", "--exclude-pattern=-email", "-o", "out"])
        args = app.build_parser().parse_args(normalized)
        self.assertEqual(args.exclude_pattern, ["-email"])

    def test_real_subprocess_dash_exclude_pattern(self):
        script = Path(app.__file__)
        source = self.root / "src"
        source.mkdir()
        (source / "keep.html").write_text(page("K", "k"), encoding="utf-8")
        (source / "drop-email.html").write_text(page("D", "d"), encoding="utf-8")
        out = self.root / "site"
        result = subprocess.run(
            [
                sys.executable,
                "-B",
                str(script),
                str(source),
                "-o",
                str(out),
                "--exclude-pattern",
                "-email",
                "--json",
            ],
            capture_output=True,
            text=True,
            timeout=60,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        report = json.loads(result.stdout)
        self.assertEqual(report["summary"]["total"], 1)
        self.assertEqual(report["docs"][0]["filename"], "keep.html")

    def test_real_subprocess_bad_input_json_error(self):
        script = Path(app.__file__)
        result = subprocess.run(
            [
                sys.executable,
                "-B",
                str(script),
                str(self.root / "nope"),
                "-o",
                str(self.root / "site"),
                "--json",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stdout)["status"], "error")


if __name__ == "__main__":
    unittest.main()
