
请创建一个新的　消息通知　功能的skill


实现向多个渠道发送消息的目的





成熟的函数代码如下：



NOTIFY_CONFIG_FILE='pipeline_notify.json'

def load_notify_config() -> dict:
    default = {"enabled": False, "channels": {"qq_email": {"enabled": False, "user": "", "password": "", "from_name": "YouTubeScoops", "recipients": ""}, "bark": {"enabled": False, "url": "", "device_key": ""}, "wxpusher": {"enabled": False, "token": "", "uid": ""}, "pushplus": {"enabled": False, "token": ""}, "resend": {"enabled": False, "api_key": "", "to_email": ""}, "telegram": {"enabled": False, "bot_token": "", "chat_id": ""}}}
    try:
        saved = json.loads(Path(NOTIFY_CONFIG_FILE).read_text(encoding="utf-8"))
        default["enabled"] = saved.get("enabled", False)
        for name, cfg in default["channels"].items():
            cfg.update(saved.get("channels", {}).get(name, {}))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass
    return default


def _send_qq_email(cfg, title, content):
    recipients = [x.strip() for x in re.split(r"[,，;；\s]+", cfg.get("recipients", "")) if x.strip()]
    if not cfg.get("user") or not cfg.get("password") or not recipients:
        return False, "配置不完整"
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"], msg["From"], msg["To"] = title, f"{cfg.get('from_name', 'YouTubeScoops')} <{cfg['user']}>", ", ".join(recipients)
        msg.attach(MIMEText(content.replace("\n", "<br>"), "html", "utf-8"))
        with smtplib.SMTP_SSL("smtp.qq.com", 465, timeout=15) as server:
            server.login(cfg["user"], cfg["password"])
            server.sendmail(cfg["user"], recipients, msg.as_string())
        return True, "发送成功"
    except Exception as exc:
        return False, str(exc)


def _post_json(url, payload, headers=None):
    if requests is None:
        return False, "缺少 requests 库"
    try:
        response = requests.post(url, headers=headers or {"Content-Type": "application/json"}, json=payload, timeout=15)
        response.raise_for_status()
        return True, "发送成功"
    except Exception as exc:
        return False, str(exc)


def _send_bark(cfg, title, content):
    if not cfg.get("url") or not cfg.get("device_key"):
        return False, "配置不完整"
    return _post_json(cfg["url"].rstrip("/") + "/push", {"title": title, "body": content, "sound": "alarm", "group": "YouTubeScoops", "level": "active", "device_keys": [cfg["device_key"]]})


def _send_wxpusher(cfg, title, content):
    if not cfg.get("token") or not cfg.get("uid"):
        return False, "配置不完整"
    return _post_json("https://wxpusher.zjiecode.com/api/send/message", {"appToken": cfg["token"], "content": content, "summary": title, "contentType": 3, "uids": [cfg["uid"]]})


def _send_pushplus(cfg, title, content):
    if not cfg.get("token"):
        return False, "配置不完整"
    return _post_json("http://www.pushplus.plus/send", {"token": cfg["token"], "title": title, "content": content, "template": "markdown"})


def _send_resend(cfg, title, content):
    if not cfg.get("api_key") or not cfg.get("to_email"):
        return False, "配置不完整"
    return _post_json("https://api.resend.com/emails", {"from": "onboarding@resend.dev", "to": cfg["to_email"], "subject": title, "html": content.replace("\n", "<br>")}, {"Authorization": "Bearer " + cfg["api_key"], "Content-Type": "application/json"})


def _send_telegram(cfg, title, content):
    if not cfg.get("bot_token") or not cfg.get("chat_id"):
        return False, "配置不完整"
    return _post_json("https://api.telegram.org/bot" + cfg["bot_token"] + "/sendMessage", {"chat_id": cfg["chat_id"], "text": f"*{title}*\n\n{content}", "parse_mode": "Markdown"})


CHANNEL_SENDERS = {"qq_email": _send_qq_email, "bark": _send_bark, "wxpusher": _send_wxpusher, "pushplus": _send_pushplus, "resend": _send_resend, "telegram": _send_telegram}
CHANNEL_NAMES = {"qq_email": "QQ 邮箱", "bark": "Bark", "wxpusher": "WxPusher", "pushplus": "PushPlus", "resend": "Resend 邮件", "telegram": "Telegram"}


def dispatch_notifications(title: str, content: str, config: dict) -> None:
    if not config.get("enabled"):
        progress("🔕 通知总开关关闭，跳过通知")
        return
    progress(f"📨 正在发送通知：{title}")
    for name, sender in CHANNEL_SENDERS.items():
        cfg = config.get("channels", {}).get(name, {})
        if not cfg.get("enabled"):
            continue
        ok, message = sender(cfg, title, content)
        progress(f"{'✅' if ok else '❌'} {CHANNEL_NAMES[name]}：{message}")
