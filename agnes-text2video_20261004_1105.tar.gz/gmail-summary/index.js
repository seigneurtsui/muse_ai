const fs = require('fs');
const path = require('path');
const { google } = require('googleapis');

const SKILL_DIR = path.join(__dirname);
const DEFAULT_TOKEN_PATH = path.join(SKILL_DIR, 'token.json');
const DEFAULT_CREDS_PATH = path.join(SKILL_DIR, 'credentials.json');

async function initializeGmailClient() {
  let credentials;
  if (process.env.GOOGLE_GMAIL_CREDENTIALS) {
    credentials = JSON.parse(process.env.GOOGLE_GMAIL_CREDENTIALS);
  } else if (process.env.GOOGLE_GMAIL_CREDENTIALS_JSON) {
    const credsPath = process.env.GOOGLE_GMAIL_CREDENTIALS_JSON;
    if (!fs.existsSync(credsPath)) {
      throw new Error(`Credentials file does not exist: ${credsPath}`);
    }
    credentials = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
  } else if (fs.existsSync(DEFAULT_CREDS_PATH)) {
    credentials = JSON.parse(fs.readFileSync(DEFAULT_CREDS_PATH, 'utf8'));
  } else {
    throw new Error('No credentials found. Please set GOOGLE_GMAIL_CREDENTIALS or GOOGLE_GMAIL_CREDENTIALS_JSON, or place credentials.json in skill directory');
  }

  let token;
  const tokenPath = process.env.GOOGLE_GMAIL_TOKEN_PATH || DEFAULT_TOKEN_PATH;
  if (fs.existsSync(tokenPath)) {
    token = JSON.parse(fs.readFileSync(tokenPath, 'utf8'));
  } else {
    throw new Error(`Authentication token not found. Please run 'node index.js auth' first.`);
  }

  const { client_secret, client_id, redirect_uris } = credentials.installed || credentials.web;
  const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);
  oAuth2Client.setCredentials(token);

  return google.gmail({ version: 'v1', auth: oAuth2Client });
}

async function authenticate() {
  let credentials;
  if (process.env.GOOGLE_GMAIL_CREDENTIALS) {
    credentials = JSON.parse(process.env.GOOGLE_GMAIL_CREDENTIALS);
  } else if (process.env.GOOGLE_GMAIL_CREDENTIALS_JSON) {
    const credsPath = process.env.GOOGLE_GMAIL_CREDENTIALS_JSON;
    credentials = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
  } else if (fs.existsSync(DEFAULT_CREDS_PATH)) {
    credentials = JSON.parse(fs.readFileSync(DEFAULT_CREDS_PATH, 'utf8'));
  } else {
    throw new Error('No credentials found');
  }

  const { client_secret, client_id, redirect_uris } = credentials.installed || credentials.web;
  const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);

  const SCOPES = ['https://www.googleapis.com/auth/gmail.modify', 'https://www.googleapis.com/auth/gmail.readonly'];
  const authUrl = oAuth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: SCOPES,
    prompt: 'consent'
  });

  console.log('Please visit this URL to authorize:');
  console.log(authUrl);
  console.log('\nEnter the authorization code:');

  const readline = require('readline');
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  
  return new Promise((resolve) => {
    rl.question('', async (code) => {
      rl.close();
      const { tokens } = await oAuth2Client.getToken(code);
      const tokenPath = process.env.GOOGLE_GMAIL_TOKEN_PATH || DEFAULT_TOKEN_PATH;
      fs.writeFileSync(tokenPath, JSON.stringify(tokens));
      console.log('Authentication successful! Token saved.');
      resolve(tokens);
    });
  });
}

async function fetchGmails({ maxResults = 10, label = 'INBOX', daysBack = 7 } = {}) {
  const gmail = await initializeGmailClient();
  
  const fromDate = new Date();
  fromDate.setDate(fromDate.getDate() - daysBack);
  const dateString = fromDate.toISOString().split('T')[0];
  
  const query = `label:${label} after:${dateString}`;
  
  const response = await gmail.users.messages.list({
    userId: 'me',
    q: query,
    maxResults: maxResults
  });

  const messages = response.data.messages || [];
  const detailedMessages = [];
  
  for (const message of messages) {
    try {
      const msgResponse = await gmail.users.messages.get({
        userId: 'me',
        id: message.id,
        format: 'full'
      });

      const msg = msgResponse.data;
      const headers = msg.payload.headers || [];
      const subjectHeader = headers.find(header => header.name === 'Subject');
      const fromHeader = headers.find(header => header.name === 'From');
      const dateHeader = headers.find(header => header.name === 'Date');
      
      let body = '';
      if (msg.payload.parts && msg.payload.parts.length > 0) {
        const plainTextPart = msg.payload.parts.find(part => part.mimeType === 'text/plain');
        if (plainTextPart && plainTextPart.body && plainTextPart.body.data) {
          body = Buffer.from(plainTextPart.body.data, 'base64').toString('utf-8');
          if (body.length > 500) {
            body = body.substring(0, 500) + '...';
          }
        } else {
          const htmlPart = msg.payload.parts.find(part => part.mimeType === 'text/html');
          if (htmlPart && htmlPart.body && htmlPart.body.data) {
            let htmlContent = Buffer.from(htmlPart.body.data, 'base64').toString('utf-8');
            body = htmlContent.replace(/<[^>]*>/g, '').substring(0, 500) + '...';
          }
        }
      }
      
      detailedMessages.push({
        id: msg.id,
        threadId: msg.threadId,
        subject: subjectHeader ? subjectHeader.value : '(No Subject)',
        from: fromHeader ? fromHeader.value : '(No Sender)',
        date: dateHeader ? dateHeader.value : '(No Date)',
        body: body,
        snippet: msg.snippet
      });
    } catch (error) {
      console.error(`Error fetching message ${message.id}:`, error.message);
      continue;
    }
  }

  return {
    success: true,
    total: detailedMessages.length,
    messages: detailedMessages,
    message: `Fetched ${detailedMessages.length} emails from ${label} in the last ${daysBack} days`
  };
}

function summarizeEmails(messages) {
  if (!messages || messages.length === 0) {
    return "No emails found.";
  }

  const emailsBySender = {};
  for (const email of messages) {
    const sender = email.from.split('<')[0].trim();
    if (!emailsBySender[sender]) {
      emailsBySender[sender] = [];
    }
    emailsBySender[sender].push(email);
  }

  let summary = `Email Summary (${messages.length} emails):\n\n`;
  
  for (const [sender, emails] of Object.entries(emailsBySender)) {
    summary += `📧 From: ${sender} (${emails.length} ${emails.length === 1 ? 'email' : 'emails'})\n`;
    
    for (const email of emails) {
      const subject = email.subject.length > 60 ? 
        email.subject.substring(0, 60) + '...' : email.subject;
      summary += `   • ${subject} (${new Date(email.date).toLocaleDateString()})\n`;
    }
    summary += '\n';
  }

  return summary;
}

async function listLabels() {
  const gmail = await initializeGmailClient();
  
  const response = await gmail.users.labels.list({ userId: 'me' });
  const labels = response.data.labels;
  
  console.log('Gmail Labels:');
  console.log('-' .repeat(40));
  for (const label of labels) {
    console.log(`${label.name} (${label.type})`);
  }
  console.log('-' .repeat(40));
  console.log(`Total: ${labels.length} labels`);
  
  return { success: true, labels };
}

function checkCredentials() {
  const hasEnvCreds = !!process.env.GOOGLE_GMAIL_CREDENTIALS;
  const hasEnvPath = !!process.env.GOOGLE_GMAIL_CREDENTIALS_JSON;
  const hasFileCreds = fs.existsSync(DEFAULT_CREDS_PATH);
  const hasToken = fs.existsSync(DEFAULT_TOKEN_PATH);

  console.log(`credentials.json: ${hasFileCreds ? '✓' : '✗'}`);
  console.log(`token.json: ${hasToken ? '✓' : '✗'}`);
  console.log(`GOOGLE_GMAIL_CREDENTIALS: ${hasEnvCreds ? '✓' : '✗'}`);
  console.log(`GOOGLE_GMAIL_CREDENTIALS_JSON: ${hasEnvPath ? '✓' : '✗'}`);

  return hasFileCreds || hasEnvCreds || hasEnvPath;
}

// CLI
if (require.main === module) {
  const args = process.argv.slice(2);

  if (args.length === 0) {
    console.log('Gmail Summary CLI - 读取和总结 Gmail 邮件');
    console.log('\n用法:');
    console.log('  node index.js auth                    # 授权');
    console.log('  node index.js check                  # 检查凭据');
    console.log('  node index.js fetch                  # 获取最近邮件');
    console.log('  node index.js fetch --label INBOX --days 7 --max 10');
    console.log('  node index.js labels                 # 列出所有标签');
    process.exit(1);
  }

  const action = args[0];

  const run = async () => {
    try {
      switch (action) {
        case 'auth':
          await authenticate();
          break;

        case 'check':
          checkCredentials();
          break;

        case 'fetch':
          const options = { maxResults: 10, label: 'INBOX', daysBack: 7 };
          
          for (let i = 1; i < args.length; i++) {
            if (args[i] === '--label' && args[i + 1]) {
              options.label = args[i + 1];
              i++;
            } else if (args[i] === '--days' && args[i + 1]) {
              options.daysBack = parseInt(args[i + 1]);
              i++;
            } else if (args[i] === '--max' && args[i + 1]) {
              options.maxResults = parseInt(args[i + 1]);
              i++;
            }
          }

          const result = await fetchGmails(options);
          console.log(summarizeEmails(result.messages));
          break;

        case 'labels':
          await listLabels();
          break;

        default:
          console.error('未知操作:', action);
          console.error('可用操作: auth, check, fetch, labels');
          process.exit(1);
      }
    } catch (error) {
      console.error('错误:', error.message);
      process.exit(1);
    }
  };

  run();
}

module.exports = {
  fetchGmails,
  summarizeEmails,
  listLabels,
  checkCredentials
};
