#!/usr/bin/env python3
"""One-shot change monitor for cron/systemd. No scheduler is installed by this tool."""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from travel_report import (add_query_arguments, validate_query, build_query_command,
                           run_json, save_report, send_report, CommandError, DOWNLOADS)

DEFAULT_STATE_DIR = Path.home() / ".cache/omnirush/china-travel-tickets/watch"


def flight_signature(item):
    journey = (item.get("journeys") or [{}])[0]
    return {
        "price": item.get("ticketPrice") if item.get("ticketPrice") is not None else item.get("adultPrice"),
        "duration": item.get("totalDuration", journey.get("totalDuration")),
        "transfer": item.get("transferDuration", journey.get("transferDuration")),
        "segments": [{key: segment.get(key) for key in (
            "marketingTransportNo", "depStationCode", "arrStationCode", "depStationName",
            "arrStationName", "depDateTime", "arrDateTime", "depTerm", "arrTerm", "quantity",
        )} for segment in journey.get("segments", [])],
    }


def train_signature(item):
    return {key: item.get(key) for key in (
        "train", "from", "to", "date", "departure", "arrival", "duration",
        "departure_datetime", "arrival_datetime", "transfer_station", "transfer_wait",
    )} | {"prices": sorted(item.get("prices", []), key=lambda p: json.dumps(p, sort_keys=True)),
         "legs": [train_signature(leg) for leg in item.get("legs", [])]}


def signature(data):
    # Ignore query timestamps, volatile booking links, and result order.
    return sorted((flight_signature(item) if item.get("journeys") else train_signature(item)
                   for item in data.get("results", [])), key=lambda item: json.dumps(item, sort_keys=True))


def atomic_state(path, value):
    fd, temporary = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".tmp-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def check_once(args, state_path, key):
    previous = {}
    if state_path.exists():
        # Do not silently overwrite a corrupt or unrelated snapshot.
        previous = json.loads(state_path.read_text(encoding="utf-8"))
        if not isinstance(previous, dict) or previous.get("queryKey") != key:
            raise ValueError("监测状态不匹配；请为此查询选择新的 --state 文件")
    data = run_json(build_query_command(args))
    current = signature(data)
    changed = not previous or previous.get("signature") != current
    checked_at = datetime.now(ZoneInfo("Asia/Shanghai")).isoformat()
    delivery_key = hashlib.sha256(json.dumps([key, args.to_email], ensure_ascii=False).encode()).hexdigest()
    deliveries = dict(previous.get("deliveries", {}))
    notice = deliveries.get(delivery_key, {})
    pending = args.send_on_change and notice.get("signature") != current
    # First empty result is still a valid baseline and may be notified.
    pending = pending or (args.send_on_change and not notice)
    state = {"version": 2, "queryKey": key, "checkedAt": checked_at,
             "signature": current, "data": data, "deliveries": deliveries}
    output = {"changed": changed, "firstCheck": not bool(previous), "checkedAt": checked_at,
              "state": str(state_path), "resultCount": len(data.get("results", [])), "email": None}
    report = previous.get("report")
    if changed or pending or not report:
        # Include timestamp; never overwrite a user's earlier delivered report.
        slug = f"watch-{args.mode}-{args.date}-{key[:12]}-{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        report = save_report(data, args.output_dir, slug)
        output.update(report)
    state["report"] = report
    atomic_state(state_path, state)
    if pending:
        # Persist an in-flight marker before contacting SMTP. If the process
        # crashes or delivery is ambiguous, manual verification is safer than
        # blindly sending a duplicate on the next scheduled invocation.
        if notice.get("status") in {"sending", "unknown"}:
            output.update(success=False, notification="unknown", message="上次邮件投递状态不确定；核对邮箱和发送记录后再重置状态")
            return output, 1
        deliveries[delivery_key] = {"status": "sending", "signature": notice.get("signature")}
        atomic_state(state_path, state)
        try:
            sent = send_report(report, args.to_email, f"票务变化提醒：{args.origin} → {args.destination}｜{args.date}")
        except CommandError as exc:
            status = exc.payload.get("status", "unknown")
            deliveries[delivery_key] = {"status": status, "signature": notice.get("signature"), "email": exc.payload}
            atomic_state(state_path, state)
            output.update(success=False, email=exc.payload)
            return output, exc.code
        deliveries[delivery_key] = {"status": "sent", "signature": current, "email": sent}
        atomic_state(state_path, state)
        output["email"] = sent
    output["success"] = True
    return output, 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    add_query_arguments(parser)
    parser.add_argument("--state", type=Path)
    parser.add_argument("--output-dir", type=Path, default=DOWNLOADS)
    parser.add_argument("--send-on-change", action="store_true")
    parser.add_argument("--to-email", default=os.environ.get("TICKET_REPORT_TO") or "gc40800@gmail.com")
    args = parser.parse_args(argv)
    validate_query(args, parser)
    command = build_query_command(args)
    key = hashlib.sha256(json.dumps(command, ensure_ascii=False).encode()).hexdigest()
    state_path = args.state or DEFAULT_STATE_DIR / f"{args.mode}-{args.date}-{key[:16]}.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)
    # Kernel releases the lock on exit or crash; no stale lock recovery needed.
    lock_path = state_path.with_suffix(state_path.suffix + ".lock")
    with os.fdopen(os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600), "w") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print(json.dumps({"success": True, "skipped": True, "reason": "同一查询正在运行"}, ensure_ascii=False))
            return 0
        try:
            output, code = check_once(args, state_path, key)
        except (ValueError, OSError, CommandError) as exc:
            print(json.dumps({"success": False, "error": str(exc)}, ensure_ascii=False))
            return 1
        print(json.dumps(output, ensure_ascii=False, indent=2))
        return code


if __name__ == "__main__":
    raise SystemExit(main())
