#!/usr/bin/env python3
"""Audit long silent intervals against frozen-picture evidence."""
from __future__ import annotations

import argparse
import json
import re
import subprocess
from pathlib import Path


def probe_duration(video: Path) -> float:
    completed = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(video)],
        capture_output=True,
        text=True,
        check=True,
    )
    return float(completed.stdout.strip() or 0)


def run_filter(video: Path, option: str, filter_value: str) -> str:
    command = ["ffmpeg", "-hide_banner", "-i", str(video)]
    if option == "audio":
        command += ["-af", filter_value, "-f", "null", "-"]
    else:
        command += ["-vf", filter_value, "-an", "-f", "null", "-"]
    completed = subprocess.run(command, capture_output=True, text=True)
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr[-4000:] or "ffmpeg detector failed")
    return completed.stderr


def parse_intervals(text: str, kind: str, duration: float) -> list[tuple[float, float]]:
    if kind == "silence":
        starts = [float(value) for value in re.findall(r"silence_start:\s*([0-9.]+)", text)]
        ends = [(float(start), float(end)) for start, end in re.findall(r"silence_start:\s*([0-9.]+).*?silence_end:\s*([0-9.]+)", text, re.S)]
        intervals = ends[:]
        if len(starts) > len(ends) and duration > starts[-1]:
            intervals.append((starts[-1], duration))
        return normalize(intervals)

    starts = [float(value) for value in re.findall(r"freeze_start:\s*([0-9.]+)", text)]
    ends = [(float(start), float(end)) for start, end in re.findall(r"freeze_start:\s*([0-9.]+).*?freeze_end:\s*([0-9.]+)", text, re.S)]
    intervals = ends[:]
    if len(starts) > len(ends) and duration > starts[-1]:
        intervals.append((starts[-1], duration))
    return normalize(intervals)


def normalize(intervals: list[tuple[float, float]]) -> list[tuple[float, float]]:
    ordered = sorted((max(0.0, start), max(0.0, end)) for start, end in intervals if end > start)
    merged: list[tuple[float, float]] = []
    for start, end in ordered:
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    return merged


def overlap_duration(interval: tuple[float, float], candidates: list[tuple[float, float]]) -> float:
    start, end = interval
    return sum(max(0.0, min(end, other_end) - max(start, other_start)) for other_start, other_end in candidates)


def audit(video: Path, silence_db: str, silence_duration: float, freeze_noise: str, freeze_duration: float) -> dict:
    duration = probe_duration(video)
    silence_log = run_filter(video, "audio", f"silencedetect=noise={silence_db}:d={silence_duration}")
    freeze_log = run_filter(video, "video", f"freezedetect=n={freeze_noise}:d={freeze_duration}")
    silences = parse_intervals(silence_log, "silence", duration)
    freezes = parse_intervals(freeze_log, "freeze", duration)
    rows = []
    for start, end in silences:
        length = end - start
        frozen = overlap_duration((start, end), freezes)
        ratio = min(1.0, frozen / length) if length else 0.0
        rows.append({
            "start": round(start, 3),
            "end": round(end, 3),
            "duration": round(length, 3),
            "freeze_overlap": round(frozen, 3),
            "freeze_ratio": round(ratio, 4),
            "eligible_40x": length > 10 and ratio >= 0.8,
        })
    return {
        "video": str(video),
        "duration": duration,
        "thresholds": {
            "silence_db": silence_db,
            "silence_duration": silence_duration,
            "freeze_noise": freeze_noise,
            "freeze_duration": freeze_duration,
        },
        "silent_intervals": rows,
        "freeze_intervals": [{"start": round(start, 3), "end": round(end, 3)} for start, end in freezes],
    }


def to_markdown(report: dict) -> str:
    lines = [
        "# Silence and Motion Audit",
        "",
        f"- Video: `{report['video']}`",
        f"- Duration: `{report['duration']:.3f}s`",
        "- Policy: intervals shorter than 10 seconds remain at base speed; a 40x candidate requires at least 80% freeze overlap.",
        "",
        "## Silent intervals",
        "",
        "| Source range | Duration | Freeze overlap | Freeze ratio | Candidate |",
        "|---|---:|---:|---:|---|",
    ]
    for row in report["silent_intervals"]:
        candidate = "40x pending review" if row["eligible_40x"] else "keep base speed"
        lines.append(f"| {row['start']:.3f}-{row['end']:.3f}s | {row['duration']:.3f}s | {row['freeze_overlap']:.3f}s | {row['freeze_ratio']:.1%} | {candidate} |")
    if not report["silent_intervals"]:
        lines.append("| — | — | — | — | No detected silent interval |")
    lines += [
        "",
        "## Decision boundary",
        "",
        "This report is evidence only. A silent interval is not automatically accelerated. Visible UI operations, readable text, gameplay results, speech, or useful motion require base speed and human review.",
        "",
    ]
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--video", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--silence-db", default="-35dB")
    parser.add_argument("--silence-duration", type=float, default=10.0)
    parser.add_argument("--freeze-noise", default="-50dB")
    parser.add_argument("--freeze-duration", type=float, default=8.0)
    args = parser.parse_args()
    video = args.video.expanduser().resolve()
    if not video.is_file():
        raise SystemExit(f"video not found: {video}")
    report = audit(video, args.silence_db, args.silence_duration, args.freeze_noise, args.freeze_duration)
    output = args.out.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(to_markdown(report), encoding="utf-8")
    output.with_suffix(".json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": "complete", "report": str(output), "json": str(output.with_suffix('.json')), "silent_intervals": len(report["silent_intervals"])}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
