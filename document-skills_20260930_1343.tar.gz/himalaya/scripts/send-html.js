#!/usr/bin/env node
/**
 * send-html.js — Himalaya HTML 邮件发送便捷脚本
 *
 * 用法:
 *   node send-html.js --to recipient@example.com --subject "主题" --body "正文内容"
 *   node send-html.js --to recipient@example.com --subject "主题" --body-file /path/to/content.txt
 *   echo "正文" | node send-html.js --to recipient@example.com --subject "主题"
 *
 * 环境变量:
 *   HIMALAYA_FROM    发件人 (默认: Seigneur Tsui <2826824650@qq.com>)
 *   HIMALAYA_TO      默认收件人 (可通过 --to 覆盖)
 *   HIMALAYA_STYLE   颜色主题 red|blue|green|purple (默认: red)
 */

const { execFileSync } = require('child_process');
const fs = require('fs');

// ── Parse args ────────────────────────────────────────────────
const args = process.argv.slice(2);
let to, subject, body, bodyFile;

for (let i = 0; i < args.length; i++) {
  if (args[i] === '--to' && args[i + 1]) { to = args[++i]; }
  else if (args[i] === '--subject' && args[i + 1]) { subject = args[++i]; }
  else if (args[i] === '--body' && args[i + 1]) { body = args[++i]; }
  else if (args[i] === '--body-file' && args[i + 1]) { bodyFile = args[++i]; }
}

if (!subject) {
  process.stderr.write('Error: --subject is required\n');
  process.exit(1);
}

// Resolve body: --body > --body-file > stdin
if (bodyFile) {
  body = fs.readFileSync(bodyFile, 'utf8');
} else if (!body) {
  // Read from stdin if piped
  if (!process.stdin.isTTY) {
    body = fs.readFileSync('/dev/stdin', 'utf8');
  } else {
    process.stderr.write('Error: --body or --body-file or stdin pipe required\n');
    process.exit(1);
  }
}

to = to || process.env.HIMALAYA_TO || 'gc40800@gmail.com';
const from = process.env.HIMALAYA_FROM || 'Seigneur Tsui <2826824650@qq.com>';
const style = process.env.HIMALAYA_STYLE || 'red';

// ── Color themes ──────────────────────────────────────────────
const themes = {
  red:    { accent: '#e74c3c', heading: '#2c3e50', bg: '#fef5f5', code_bg: '#f8f9fa' },
  blue:   { accent: '#2980b9', heading: '#2c3e50', bg: '#f0f7ff', code_bg: '#f0f4f8' },
  green:  { accent: '#27ae60', heading: '#1a5e2a', bg: '#f0faf4', code_bg: '#f4f9f6' },
  purple: { accent: '#8e44ad', heading: '#4a235a', bg: '#faf5ff', code_bg: '#f8f4fb' },
};
const c = themes[style] || themes.red;

// ── Build HTML ────────────────────────────────────────────────
// Escape HTML entities in body
function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

const bodyHtml = escapeHtml(body).replace(/\n/g, '<br>\n');
const dateStr = new Date().toISOString().slice(0, 10);
const timeStr = new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });

const html = `<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    background: #f5f5f5; padding: 24px; color: #333; line-height: 1.7;
  }
  .wrapper {
    max-width: 640px; margin: 0 auto; background: #fff;
    border-radius: 12px; overflow: hidden;
    box-shadow: 0 2px 12px rgba(0,0,0,0.08);
  }
  .header {
    background: linear-gradient(135deg, ${c.accent}, ${c.heading});
    color: #fff; padding: 28px 32px;
  }
  .header h1 { font-size: 20px; font-weight: 600; letter-spacing: 0.3px; }
  .header .meta { font-size: 13px; opacity: 0.85; margin-top: 6px; }
  .body {
    padding: 28px 32px; background: ${c.bg};
    font-size: 15px; color: #444;
  }
  .body p { margin-bottom: 12px; }
  .body pre, .body code {
    background: ${c.code_bg}; border-radius: 6px; padding: 2px 6px;
    font-family: 'SF Mono', Menlo, monospace; font-size: 13px;
  }
  .body pre { padding: 16px; overflow-x: auto; margin: 12px 0; }
  .footer {
    padding: 16px 32px; border-top: 1px solid #eee;
    font-size: 12px; color: #999; text-align: center;
  }
  .footer a { color: ${c.accent}; text-decoration: none; }
</style></head><body>
<div class="wrapper">
  <div class="header">
    <h1>📬 ${escapeHtml(subject)}</h1>
    <div class="meta">${dateStr} ${timeStr} · via OpenCode</div>
  </div>
  <div class="body">${bodyHtml}</div>
  <div class="footer">
    此邮件通过 <a href="https://github.com/pimalaya/himalaya">Himalaya</a> 发送 · ${dateStr}
  </div>
</div>
</body></html>`;

// ── Build MML ─────────────────────────────────────────────────
const mml = `From: ${from}
To: ${to}
Subject: ${subject}

<#multipart type=alternative>
<#part type=text/plain>
${body}
<#part type=text/html>
${html}
<#/multipart>`;

// ── Send (MML must go through `template send` via pipe) ──────
try {
  const result = require('child_process').spawnSync('himalaya', ['template', 'send'], {
    input: mml,
    timeout: 15000,
    encoding: 'utf8',
  });

  if (result.error) throw result.error;
  if (result.status !== 0) {
    throw new Error((result.stderr || '').trim() || `himalaya exit code ${result.status}`);
  }
  console.log(`✅ HTML 邮件已发送 → ${to}`);
  console.log(`   主题: ${subject}`);
  console.log(`   样式: ${style}`);
} catch (err) {
  process.stderr.write(`❌ 发送失败: ${err.message}\n`);
  process.exit(1);
}
