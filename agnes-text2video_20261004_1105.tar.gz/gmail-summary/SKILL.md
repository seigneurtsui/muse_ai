---
name: gmail-summary
description: 读取并总结 Gmail 邮件。支持按日期、发件人、标签筛选，提取关键信息。
---

# Gmail Summary Skill

使用 Gmail API 读取和总结邮件。

## 功能特性

- 获取 Gmail 收件箱邮件
- 总结邮件内容
- 按日期、发件人、标签筛选
- 提取邮件关键信息

## 前置要求

1. **Gmail API 凭据**: 从 Google Cloud Console 下载 `credentials.json`
   - 启用 Gmail API
   - 创建 OAuth 2.0 客户端 ID
   - 下载凭据文件并重命名为 `credentials.json`

2. **Node.js 依赖**:
   ```bash
   npm install googleapis
   ```

## 配置

设置环境变量：
```bash
# 方式1: 通过文件路径
export GOOGLE_GMAIL_CREDENTIALS_JSON=/path/to/credentials.json

# 方式2: 直接设置 JSON 内容
export GOOGLE_GMAIL_CREDENTIALS='{"installed":{"client_id":"...","client_secret":"..."}}'

# Token 存储路径 (可选)
export GOOGLE_GMAIL_TOKEN_PATH=./token.json
```

## 使用方法

### Node.js 用法

```javascript
const { fetchGmails, summarizeEmails } = require('./index.js');

// 获取并总结最近邮件
const result = await fetchGmails({
  maxResults: 10,
  label: 'INBOX',
  daysBack: 7
});

// 打印邮件摘要
const summary = summarizeEmails(result.messages);
console.log(summary);
```

### CLI 用法

```bash
# 检查凭据
node index.js check-credentials

# 获取最近 10 封邮件
node index.js fetch

# 获取最近 7 天收件箱邮件
node index.js fetch --label INBOX --days 7 --max 20

# 获取特定标签的邮件
node index.js fetch --label AudioSummary --days 30
```

## 示例

```javascript
// 获取并总结最近重要邮件
const result = await fetchGmails({
  maxResults: 20,
  label: 'INBOX',
  daysBack: 3
});

console.log(summarizeEmails(result.messages));
```

## 输出示例

```
Email Summary (10 emails):

📧 From: sender1@example.com (2 emails)
   • Email Subject 1 (2024-03-15)
   • Email Subject 2 (2024-03-14)

📧 From: sender2@example.com (1 email)
   • Another Email (2024-03-15)
```

## 常见问题

### Q: 首次使用需要授权？
A: 是的，首次运行会打开浏览器进行 Google 授权登录

### Q: 如何查看所有标签？
A: 使用 `node index.js labels` 命令查看所有 Gmail 标签
