#!/usr/bin/env python3
"""Import a legacy notification JSON, moving credentials/routing IDs into a shared .env.

Local files only. Never sends messages, prints values, or modifies the source.
"""
import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import sys
import tempfile

from notify import ConfigError, DEFAULT_CONFIG, DEFAULT_ENV, ENV, emit, load_config, parse_dotenv

PRIVATE_FIELDS = {"password", "token", "api_key", "bot_token", "device_key", "device_keys",
                  "uid", "uids", "chat_id", "user", "recipients", "to_email", "from_email",
                  "url", "endpoint", "api_base", "headers"}


def migrate(source, target, env_path):
    if source.resolve() == target.resolve():
        raise ConfigError("source and target must differ; preserve the original JSON")
    config = load_config(source)
    secrets = {}

    def hide(value, prefix):
        if isinstance(value, dict):
            return {k: hide(v, prefix + "_" + re.sub(r"[^A-Z0-9]", "_", k.upper())) for k, v in value.items()}
        if isinstance(value, list):
            return [hide(v, prefix + "_" + str(i + 1)) for i, v in enumerate(value)]
        if value is None or value == "" or type(value) is bool:
            return value
        if isinstance(value, str) and ENV.search(value):
            return value
        value = str(value)
        if prefix in secrets and secrets[prefix] != value:
            raise ConfigError("generated environment variable names collide; rename channel instances")
        secrets[prefix] = value
        return "${" + prefix + "}"

    for name, channel in config["channels"].items():
        prefix = "OMNIRUSH_NOTIFY_" + name.upper().replace("-", "_")
        for key in PRIVATE_FIELDS & channel.keys():
            channel[key] = hide(channel[key], prefix + "_" + key.upper())

    env_path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(env_path, flags, 0o600)
    with os.fdopen(fd, "r+", encoding="utf-8") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX)
        existing_text = stream.read()
        existing = parse_dotenv(existing_text, set(secrets))
        for key, value in secrets.items():
            if key in existing and existing[key] != value:
                raise ConfigError(f".env variable {key} already has a different value; nothing overwritten")
        additions = {k: v for k, v in secrets.items() if k not in existing}
        os.fchmod(stream.fileno(), 0o600)
        if additions:
            stream.seek(0, os.SEEK_END)
            if existing_text and not existing_text.endswith("\n"):
                stream.write("\n")
            stream.write("\n# multiple-channel-notifier (JSON-quoted values; do not source as shell code)\n")
            for key, value in sorted(additions.items()):
                stream.write(key + "=" + json.dumps(value, ensure_ascii=False) + "\n")
            stream.flush()
            os.fsync(stream.fileno())

    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".notify-config-", dir=target.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(config, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, target)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return {"ok": True, "status": "imported", "secret_variables": len(secrets),
            "new_env_variables": len(additions), "message": "source unchanged; shared .env and reference-only config use permissions 0600; no network requests"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--env-file", type=Path, default=DEFAULT_ENV)
    parser.add_argument("--replace-config", action="store_true", help="explicitly allow replacing target config (never overwrites differing .env values)")
    args = parser.parse_args()
    try:
        target = args.config.expanduser()
        if target.exists() and not args.replace_config:
            raise ConfigError("target config exists; review it before using --replace-config")
        emit(migrate(args.source.expanduser(), target, args.env_file.expanduser()))
        return 0
    except ConfigError as exc:
        emit({"ok": False, "status": "configuration_error", "message": str(exc)})
        return 2
    except (OSError, ValueError):
        emit({"ok": False, "status": "local_error", "message": "cannot migrate local files; source retained; details withheld"})
        return 2


if __name__ == "__main__":
    sys.exit(main())
