"""Conservative structural decisions and lossless character-range partitions.

Derived from the reference's volume reset, front-matter and title-line heuristics.
The 4..25 catch-all and destructive numeric chapter deduplication are NOT retained.
"""
from dataclasses import dataclass
import re
from models import Boundary, Extracted, SplitError

NUMBER = r"[零〇一二两三四五六七八九十百千万\d]+"
CHAPTER = re.compile(r"^(?:第\s*(" + NUMBER + r")\s*[章回节節篇]|(?:chapter|part)\s+(\d+)\b)", re.I)
VOLUME = re.compile(r"^(?:第\s*" + NUMBER + r"\s*[本册冊]|[册冊]\s*" + NUMBER + r"|book\s+(?:\d+|[IVX]+)\b|《[^》]+》)", re.I)
BOOK_LINE = re.compile(r"(?:《[^》\n]{1,50}》|第\s*" + NUMBER + r"\s*[本部册冊卷]\s*[:：]?.{0,35}|book\s+(?:\d+|[IVX]+)\b.{0,45})", re.I)
FRONT = {"致谢", "引言", "序言", "前言", "自序", "序", "总序", "编者按", "出版说明", "序章", "楔子", "目录", "版权信息", "内容简介", "推荐序", "扉页", "版权页", "献词", "附录", "参考文献", "后记", "跋", "尾声", "编后记"}


def chinese_number(value):
    if value.isdecimal(): return int(value)
    digits = dict(zip("零〇一二两三四五六七八九", (0, 0, 1, 2, 2, 3, 4, 5, 6, 7, 8, 9)))
    if not any(c in value for c in "十百千万"):
        return int("".join(str(digits[c]) for c in value)) if value else None
    total = section = current = 0
    for char in value:
        if char in digits: current = digits[char]
        elif char in "十百千":
            section += (current or 1) * {"十": 10, "百": 100, "千": 1000}[char]
            current = 0
        elif char == "万":
            total += (section + current or 1) * 10000
            section = current = 0
        else: return None
    return total + section + current


def chapter_number(title):
    match = CHAPTER.match(title.strip())
    return chinese_number(match[1] or match[2]) if match else None


def norm(title): return re.sub(r"[\s　]+", "", title).strip("：:")


def volume_resets(entries):
    """Require strictly falling chapter numbers, not duplicate aliases alone."""
    resets, previous = [0], None
    for index, item in enumerate(entries):
        number = chapter_number(item.title)
        if number is not None:
            if previous is not None and number < previous:
                start = index
                while start > resets[-1] + 1 and norm(entries[start - 1].title) in FRONT:
                    start -= 1
                if start > resets[-1]: resets.append(start)
            previous = number
    return resets


def select_entries(extracted, level=0):
    toc = [b for b in extracted.toc if b.title.strip() and 0 <= b.position < len(extracted.text)]
    if not toc: return [], []
    levels = sorted({b.level for b in toc})
    if level:
        if level not in levels: raise SplitError("所选 --toc-level 不存在")
        chosen = [b for b in toc if b.level == level]
    else:
        chosen = [b for b in toc if b.level == levels[0]]
        for depth in levels[1:]:
            if len(chosen) != 1 or chosen[0].children == 0: break
            chosen = [b for b in toc if b.level == depth]
    warnings = []
    if any(a.position > b.position for a, b in zip(chosen, chosen[1:])):
        warnings.append("目录顺序与正文顺序不一致；按正文位置排序，需复核")
    unique = {}
    for entry in sorted(chosen, key=lambda b: b.position):
        if entry.position in unique:
            if entry.title != unique[entry.position].title:
                warnings.append("同一正文位置有不同目录标题；合并边界而非复制正文")
                old = unique[entry.position]
                unique[entry.position] = Boundary(old.position, old.title + " / " + entry.title, old.level, max(old.children, entry.children), old.locator)
        else: unique[entry.position] = entry
    return list(unique.values()), warnings


def title_candidates(text, *, chapters=False, minimum=3000):
    lines, offset, candidates = text.splitlines(keepends=True), 0, []
    for index, line in enumerate(lines):
        title = line.strip()
        surrounded = (index == 0 or not lines[index - 1].strip()) and (index + 1 == len(lines) or not lines[index + 1].strip())
        match = CHAPTER.match(title) if chapters else BOOK_LINE.fullmatch(title)
        if 2 <= len(title) <= (50 if chapters else 60) and surrounded and match:
            candidates.append(Boundary(offset, title, locator={"line": index + 1}))
        offset += len(line)
    if chapters: return candidates
    # No exception for the last candidate: a short final quotation is not a book.
    return [entry for i, entry in enumerate(candidates)
            if len(text[entry.position:(candidates[i+1].position if i+1 < len(candidates) else len(text))].strip()) >= minimum]


@dataclass
class Part:
    title: str
    start: int
    end: int
    kind: str = "book"
    locator: dict | None = None


def ranges(text, entries, fallback):
    if not entries: return [Part(fallback, 0, len(text))]
    result = []
    start = entries[0].position
    if text[:start].strip(): result.append(Part("前言_或_未分类内容", 0, start, "preface"))
    for i, entry in enumerate(entries):
        left = entry.position if i or result else 0
        right = entries[i+1].position if i+1 < len(entries) else len(text)
        if right > left: result.append(Part(entry.title, left, right, locator=entry.locator))
    assert result and result[0].start == 0 and result[-1].end == len(text)
    assert all(a.end == b.start for a, b in zip(result, result[1:]))
    return result


def decide(extracted, name, *, mode="auto", toc_level=0, min_section_chars=3000):
    entries, issues = select_entries(extracted, toc_level)
    warnings = list(extracted.warnings) + issues
    review = bool(extracted.metadata.get("incomplete"))
    method, reason = extracted.method, ""
    selected = []
    if mode == "single":
        reason = "explicit_single"
    elif entries:
        if mode == "collection":
            selected, reason = entries, "explicit_collection"
            review |= bool(issues or extracted.metadata.get("structure_uncertain"))
        elif issues or extracted.metadata.get("structure_uncertain"):
            reason, review = "uncertain_structure_preserved_whole", True
        else:
            titles = [e.title for e in entries]
            resets = volume_resets(entries)
            chapters = sum(chapter_number(t) is not None for t in titles)
            explicit = sum(bool(VOLUME.match(t.strip())) for t in titles)
            count_hint = re.search(r"(?:共|全|套装|套裝)?\s*(" + NUMBER + r")\s*[本册冊卷]", name)
            matches_count = count_hint and chinese_number(count_hint[1]) == len(entries)
            collection_hint = any(token in name for token in ("全集", "合集", "套装", "套裝", "丛书", "叢書"))
            structural = sum(norm(t) in FRONT for t in titles)
            progressive = any(re.match(r"^(?:第\s*" + NUMBER + r"\s*[部篇卷]|卷\s*" + NUMBER + r")", t.strip()) for t in titles)
            if structural >= 3 and progressive and not matches_count and not collection_hint:
                reason = "single_book_structural_sections"
            elif len(entries) >= 2 and (matches_count or explicit >= max(2, len(entries) * .6)):
                selected, reason = entries, "explicit_volume_labels_or_count"
            elif len(resets) > 1 and collection_hint:
                selected = [Boundary(entries[index].position, f"{name}_第{i+1}册", locator=entries[index].locator) for i, index in enumerate(resets)]
                reason = "chapter_number_resets"
                warnings.append("依据合集名和章节序号回退分组，建议检查册边界")
                review = True
            elif chapters >= max(1, len(entries) * .6) or len(entries) == 1:
                reason = "single_book_chapter_structure"
            elif len(entries) >= 30 and sum(e.children > 0 for e in entries) < 2:
                reason = "many_flat_entries_preserved_whole"
                warnings.append("大量扁平目录未发现可靠分册信号，保留整本；可用 --mode collection 明确拆分")
                review = True
            elif len(entries) >= 2 and (sum(e.children > 0 for e in entries) >= 2 or collection_hint):
                selected, reason = entries, "hierarchical_or_collection_toc"
                if not collection_hint:
                    review = True
                    warnings.append("按分层目录拆分，书名/章名的语义仍需核对")
            else:
                reason, review = "ambiguous_toc_preserved_whole", True
                warnings.append("目录可能是书名也可能是章名，保留整本；确认合集后使用 --mode collection")
    elif extracted.metadata.get("toc_present"):
        reason, review = "unusable_toc_preserved_whole", True
        warnings.append("原书存在目录但无法可靠映射，未降级为正文猜测")
    else:
        candidates = title_candidates(extracted.text, minimum=min_section_chars)
        if len(candidates) >= 2:
            selected, method, reason = candidates, "text_pattern_fallback", "isolated_title_lines"
        else:
            reason = "no_reliable_boundaries_preserved_whole"
        review = True
        warnings.append("没有可用结构化目录，文本标题兜底/整本保留结果需人工复核")
    parts = ranges(extracted.text, selected, name)
    return parts, {"method_used": method, "decision": reason, "needs_review": review,
                   "warnings": warnings, "selected_boundaries": len(selected),
                   "book_count": sum(part.kind == "book" for part in parts), "part_count": len(parts)}


def chapter_parts(text, extracted=None, part=None):
    # Prefer actual child TOC/heading boundaries within this volume. For whole-book
    # preservation, its first branching outline level becomes the chapter view.
    if extracted is not None and part is not None:
        inside = [b for b in extracted.toc if part.start <= b.position < part.end]
        own = next((b for b in inside if b.title == part.title and b.locator == part.locator), None)
        if own is not None:
            inside = [b for b in inside if b.level > own.level]
        shifted = [Boundary(b.position-part.start, b.title, b.level, b.children, b.locator) for b in inside]
        if shifted:
            chosen, _ = select_entries(Extracted(text, shifted, extracted.method))
            if chosen: return ranges(text, chosen, "全文")
    # Never drop unique text just because two headings have the same chapter number.
    # The primary whole-volume TXT remains authoritative and lossless.
    return ranges(text, title_candidates(text, chapters=True), "全文")
