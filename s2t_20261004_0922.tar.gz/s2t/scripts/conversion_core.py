"""Lossless text framing, SRT dialogue selection and bounded glyph confirmation.

Adapted from the user's batch converter and two-confirmation reference. This
module never executes document text and never filters dialogue by its contents.
"""
from __future__ import annotations

import codecs
import re
from dataclasses import dataclass
from typing import Callable


class ConversionError(Exception):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


# Deliberately omit ambiguous/shared forms such as 后、里、台、干、余、云、著.
_PAIRS = "汉漢语語龙龍马馬门門车車书書东東风風国國学學习習体體说說话話见見观觀广廣关關开開时時间間欢歡园園乐樂图圖网網数數据據转轉换換连連线線档檔办辦会會机機电電爱愛亲親纸紙页頁读讀写寫声聲识識标標题題简簡细細节節点點实實际際边邊总總设設录錄"
SIMPLIFIED_MARKERS = frozenset(_PAIRS[::2])
TRADITIONAL_MARKERS = frozenset(_PAIRS[1::2])
_TIME = r"(\d{1,3}):([0-5]\d):([0-5]\d)[,.](\d{3})"
TIMING = re.compile(r"^\s*" + _TIME + r"\s*-->\s*" + _TIME + r"(?:[ \t]+[^\r\n]*)?\s*$")
SUPPORTED_ENCODINGS = ("auto", "utf-8", "utf-8-sig", "utf-16", "utf-16-le", "utf-16-be", "gbk", "gb18030", "big5")


@dataclass(frozen=True)
class TextDocument:
    text: str
    encoding: str
    bom: bytes = b""


def decode_document(raw: bytes, encoding: str = "auto") -> TextDocument:
    if encoding not in SUPPORTED_ENCODINGS:
        raise ConversionError("unsupported_encoding")
    if raw.startswith((codecs.BOM_UTF32_LE, codecs.BOM_UTF32_BE)):
        raise ConversionError("utf32_not_supported")
    known = ((codecs.BOM_UTF8, "utf-8"), (codecs.BOM_UTF16_LE, "utf-16-le"), (codecs.BOM_UTF16_BE, "utf-16-be"))
    for bom, codec in known:
        if raw.startswith(bom):
            allowed = {"auto", codec, "utf-8-sig" if codec == "utf-8" else "utf-16"}
            if encoding not in allowed:
                raise ConversionError("encoding_conflicts_with_bom")
            try:
                text = raw[len(bom):].decode(codec, errors="strict")
            except UnicodeError:
                raise ConversionError("invalid_text_encoding") from None
            if "\0" in text:
                raise ConversionError("nul_in_text")
            return TextDocument(text, codec, bom)
    candidates = ("utf-8", "gb18030") if encoding == "auto" else (encoding,)
    for codec in candidates:
        try:
            text = raw.decode(codec, errors="strict")
        except UnicodeError:
            continue
        if "\0" in text:
            raise ConversionError("nul_in_text_use_explicit_encoding_if_needed")
        return TextDocument(text, "utf-8" if codec == "utf-8-sig" else codec)
    raise ConversionError("invalid_text_encoding")


def encode_document(text: str, original: TextDocument, output_encoding: str = "utf-8") -> bytes:
    if output_encoding not in ("utf-8", "same"):
        raise ConversionError("unsupported_output_encoding")
    codec = original.encoding if output_encoding == "same" else "utf-8"
    bom = original.bom if output_encoding == "same" else (codecs.BOM_UTF8 if original.bom == codecs.BOM_UTF8 else b"")
    try:
        return bom + text.encode(codec, errors="strict")
    except UnicodeError:
        raise ConversionError("output_encoding_cannot_represent_converted_text") from None


def physical_lines(text: str) -> list[str]:
    return re.findall(r"[^\r\n]*(?:\r\n|\r|\n)|[^\r\n]+$", text)


def srt_dialogue_ranges(text: str) -> tuple[list[str], list[tuple[int, int]]]:
    lines = physical_lines(text)
    ranges = []
    i = 0
    while i < len(lines):
        if not lines[i].strip():
            i += 1
            continue
        start = i
        while i < len(lines) and lines[i].strip():
            i += 1
        block = lines[start:i]
        if len(block) < 2 or not re.fullmatch(r"[0-9]+", block[0].strip()):
            raise ConversionError("invalid_srt_cue_index")
        match = TIMING.fullmatch(block[1].rstrip("\r\n"))
        if not match:
            raise ConversionError("invalid_srt_timing")
        numbers = [int(x) for x in match.groups()]
        def millis(values):
            hours, minutes, seconds, fraction = values
            return ((hours * 60 + minutes) * 60 + seconds) * 1000 + fraction
        if millis(numbers[4:]) < millis(numbers[:4]):
            raise ConversionError("srt_end_before_start")
        ranges.append((start + 2, i))
    return lines, ranges


def _assert_framing(source: str, result: str) -> None:
    if not isinstance(result, str) or "\0" in result:
        raise ConversionError("invalid_engine_output")
    if source and not result:
        raise ConversionError("empty_engine_output")
    if re.findall(r"\s+", source) != re.findall(r"\s+", result):
        raise ConversionError("whitespace_or_linebreak_structure_changed")


def convert_document(text: str, convert: Callable[[str], str], file_format: str) -> tuple[str, int | None]:
    if file_format == "text":
        result = convert(text)
        _assert_framing(text, result)
        return result, None
    if file_format != "srt":
        raise ConversionError("unsupported_format")
    lines, ranges = srt_dialogue_ranges(text)
    result = list(lines)
    for start, end in ranges:
        dialogue = "".join(lines[start:end])
        if not dialogue:
            continue
        converted = convert(dialogue)
        _assert_framing(dialogue, converted)
        converted_lines = physical_lines(converted)
        if len(converted_lines) != end - start:
            raise ConversionError("srt_dialogue_line_count_changed")
        result[start:end] = converted_lines
    joined = "".join(result)
    _assert_framing(text, joined)
    _, new_ranges = srt_dialogue_ranges(joined)
    if new_ranges != ranges:
        raise ConversionError("srt_cue_structure_changed")
    return joined, len(ranges)


def dialogue_text(text: str, file_format: str) -> str:
    if file_format == "text":
        return text
    lines, ranges = srt_dialogue_ranges(text)
    return "\n".join("".join(lines[start:end]) for start, end in ranges)


def check_glyphs(text: str, mode: str) -> dict:
    if mode not in ("s2t", "t2s"):
        raise ConversionError("unsupported_mode")
    simplified = sum(ch in SIMPLIFIED_MARKERS for ch in text)
    traditional = sum(ch in TRADITIONAL_MARKERS for ch in text)
    opposite = simplified if mode == "s2t" else traditional
    target = traditional if mode == "s2t" else simplified
    # A conservative marker set, not a language detector or proof of semantics.
    passed = False if opposite else True if target else None
    return {"simplified_markers": simplified, "traditional_markers": traditional,
            "passed": passed, "status": "failed" if passed is False else "passed" if passed else "insufficient_evidence"}


def normalize_document(text: str, engine, mode: str, file_format: str = "text") -> tuple[str, dict]:
    """Convert, check, optionally reconvert once, and check again without dropping lines."""
    restarted = False
    for _ in range(2):
        start_engine = engine.name
        first, cues = convert_document(text, engine.convert, file_format)
        first_check = check_glyphs(dialogue_text(first, file_format), mode)
        second_applied = first_check["passed"] is False
        if second_applied:
            final, cues = convert_document(first, engine.convert, file_format)
        else:
            final = first
        if engine.name != start_engine:
            # If a native failure switched backend between SRT cues, discard all
            # intermediate output and convert the original with the new backend.
            restarted = True
            continue
        final_check = check_glyphs(dialogue_text(final, file_format), mode)
        return final, {"target": mode, "first_check": first_check,
                       "second_conversion_applied": second_applied,
                       "final_check": final_check, "passed": final_check["passed"],
                       "backend_restart_applied": restarted, "structure_preserved": True,
                       "srt_cues": cues, "heuristic_only": True}
    raise ConversionError("backend_changed_repeatedly")
