# Edit Mode

`--edit-mode` is an explicit opt-in on a new batch. The default is subtitle
mode: it preserves the source timeline unless speed/trim is explicitly given.
Resume restores the saved mode; `--no-edit-mode` switches it off.

## What it does

1. Scores subtitle phrases on five axes:
   - hook strength;
   - emotional payoff;
   - quotability;
   - self-contained context;
   - information density.
   These are text heuristics (0–100 per axis, total 500), with cue text and
   signal evidence saved in JSON. They do not measure audio emotion or visual
   drama. The agent can refine the choices after viewing source material.
2. Selects the highest-scoring phrase range as an opening highlight.
3. Places that range before the complete body, so the moment appears twice unless
   the user later approves a different body policy.
4. Validates phrase-safe cuts, expands 120ms handles only into subtitle gaps
   (configurable `--cut-padding-ms 0-200`), then renders independent segments with
   per-range speeds and approximately 30ms output-time audio edge fades.
   Contiguous source joins are not padded into overlapping duplicate material.
5. Rebuilds the subtitle timeline from actual segment durations before ASS
   generation and final burn-in.

The eight-second highlight duration is a source-time target. It expands to
whole phrase boundaries, may exceed the target for a long phrase, and does not
extend past the selected body. Very short videos may repeat most of the body.

## Example

```bash
python3 "$PIPE" <videos> \
  --edit-mode \
  --edit-highlight-duration 8 \
  --edit-highlight-speed 1.0 \
  --edit-body-speed 1.15 \
  --resume
```

Each video receives:

```text
videos/<video-id>/edit-plan.json
videos/<video-id>/edit-review.md
videos/<video-id>/edit_mode/segments/
videos/<video-id>/edl.json
videos/<video-id>/qa/<preview|final>/boundaries/
```

## Custom per-range speeds and order

`--edit-mode --edit-plan /path/to/plan.json` accepts:

```json
{
  "ranges": [
    {"kind": "opening_highlight", "start": 20, "end": 28, "speed": 1, "reason": "selected opening"},
    {"kind": "body", "start": 0, "end": 20, "speed": 1.2},
    {"kind": "body", "start": 20, "end": 60, "speed": 1}
  ]
}
```

All times are source seconds; `ranges` are in output order. Replace example
boundaries with actual phrase edges or silent gaps. A range cannot cut inside
any subtitle phrase. Finite positive speeds, valid source bounds, and a complete
duration mapping are required. Timelapse speeds ≥10x cannot contain speech.
Silence/motion reports remain advisory; no automatic 40x is applied.

For a batch with different plans, wrap per-video plans in a `videos` mapping:
`{"videos": {"<video-id>": {"ranges": [...]}}}`. Every video needs an entry.
The custom plan is authoritative, so omissions/repeats are explicit decisions.

## Pause and resume

```bash
python3 "$PIPE" <videos> --edit-mode --stop-for-review
# After any STT/correction request is resolved, exit 11 means awaiting review.
# Edit videos/<video-id>/edit-plan.json ranges, then:
python3 "$PIPE" --resume-batch <batch> --approve-review
```

The pause happens before segment encoding. Resuming reads the saved plan and
checks source/subtitle/settings bindings rather than reselecting the highlight.
The JSON records `review_status` honestly: automatic, awaiting_review, approved.
Raw `ranges` remain the requested plan; `render_ranges` record actual padded
ranges. Padding is never added cumulatively on resume. The EDL contains source
hashes, quotes/reasons, STT confidence and actual output offsets. Strict custom
ranges can disable handles with `--cut-padding-ms 0`.

For complete preview approval, additionally enable `--stop-for-preview`.
`--approve-review` continues to the preview, not the final; only
`--approve-preview` can approve an existing unchanged QA-passing preview.
An optional voiceover script uses this assembled **output** timeline, not source
seconds. See [review.md](review.md), [edit-evidence.md](edit-evidence.md) and
[voiceover.md](voiceover.md).
Changing mode or render settings invalidates the render fingerprint for batches
created with this version. For older batches, use `--force-render` for style
changes; changing edit mode already triggers a rerender.
