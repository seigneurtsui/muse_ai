# Multi-Platform Publish Pack

Use this reference when the user asks for platform copy, titles, tags, cover
prompts, or a publishing plan. The same finished video is a different package
on each platform: search intent, title length, audience expectation, and risk
boundaries differ.

## Workflow

1. Read the complete `request.json`, final-timeline evidence and frame images;
   `creator-profile.md` is included when present. With merging enabled,
   timestamps are from batch `final.srt`, not the individual source timelines.
2. Extract one honest value proposition, the strongest demonstrated result, and
   the actual high-light timestamps.
3. Write 3–5 title candidates for each of the eight platforms. Consider
   information, curiosity and credibility, then recommend one with a rationale.
4. Write platform-specific descriptions, tags, cover prompts, and a proposed
   publish window.
5. Return JSON matching the request schema and exact request ID, then resume the
   same batch to produce Markdown. Deliver actual files, not just a pending
   request. See [release-package.md](release-package.md) for the protocol.

## Platform tendencies

| Platform | Primary optimization | Copy direction |
|---|---|---|
| B站 | 完播、收藏、三连、章节 | 讲清内容，保留时间戳，允许适度悬念 |
| YouTube | 搜索、CTR、完播、字幕 | 核心关键词前置，前两行说明价值 |
| 抖音 | 前3秒、完播、复播 | 短、口语、结果先行，不站外导流 |
| TikTok | Hook、完播、地区相关性 | 使用真实英文内容和合规话题 |
| 小红书 | 搜索、封面点击、收藏 | 关键词前置，像可保存的经验分享 |
| 视频号 | 熟人传播、完播、互动 | 简洁直给，适合分享语气 |
| 百家号 | 搜索、原创、标题可信度 | 信息型标题，避免夸张 |
| 头条号 | 推荐、完读、信息增量 | 说清主题和结论，不做空悬念 |

These are editorial directions, not verified algorithm weights or guarantees.
Use the actual subject: a landscape video should not acquire “实测成本” or
“完整工具教程” claims. B站 additionally needs a distinct fan post. TikTok uses
English; names can retain original spelling. Refer to supplied evidence IDs;
uncertain ASR words belong in notes rather than unsupported title claims.

Avoid absolute claims, fabricated urgency, medical/financial promises, fake
authority, and prohibited off-platform contact guidance. If the project profile
contains prohibited topics, apply it before drafting.
