"""Tests for the current-session-model handoff in _ai_call.

No subprocess, no CLI, no network. The handoff contract:
- _ai_call writes <id>.request.json and raises AIRequestPending when no
  response file exists yet.
- _ai_call returns the "text" field when <id>.response.json exists.
- Request IDs are deterministic for identical messages.
"""
import importlib.util
import inspect
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "tts.py"
spec = importlib.util.spec_from_file_location("edge_tts_skill", SCRIPT)
tts = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tts)

MESSAGES = [
    {"role": "system", "content": "Return only JSON."},
    {"role": "user", "content": '{"items": [{"index": 0, "text": "hello"}]}'},
]


class HandoffTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="edge-tts-test-")
        self.env_patch = patch.dict(os.environ, {"EDGE_TTS_AI_WORK_DIR": self.tmp.name})
        self.env_patch.start()
        self.addCleanup(self.tmp.cleanup)
        self.addCleanup(self.env_patch.stop)

    def _pending_descriptor(self):
        with self.assertRaises(tts.AIRequestPending) as ctx:
            tts._ai_call(MESSAGES)
        return ctx.exception.descriptor

    def test_missing_response_raises_pending_and_writes_request(self):
        d = self._pending_descriptor()
        self.assertEqual(d["provider"], "omnirush-current-session")
        req = Path(d["request_path"])
        self.assertTrue(req.exists())
        packet = json.loads(req.read_text(encoding="utf-8"))
        self.assertEqual(packet["messages"], MESSAGES)
        self.assertEqual(packet["request_id"], d["request_id"])
        self.assertIn("system_prompt", packet)

    def test_existing_response_returns_text(self):
        d = self._pending_descriptor()
        Path(d["response_path"]).write_text(
            json.dumps({"text": '{"ok": true}'}), encoding="utf-8"
        )
        self.assertEqual(tts._ai_call(MESSAGES), '{"ok": true}')

    def test_request_id_is_deterministic(self):
        id1 = tts._ai_request_id(MESSAGES)
        id2 = tts._ai_request_id([dict(m) for m in MESSAGES])
        self.assertEqual(id1, id2)
        id3 = tts._ai_request_id([{"role": "user", "content": "different"}])
        self.assertNotEqual(id1, id3)

    def test_invalid_response_file_raises_pending(self):
        d = self._pending_descriptor()
        Path(d["response_path"]).write_text("not json {{{", encoding="utf-8")
        with self.assertRaises(tts.AIRequestPending):
            tts._ai_call(MESSAGES)

    def test_empty_text_response_raises_pending(self):
        d = self._pending_descriptor()
        Path(d["response_path"]).write_text(json.dumps({"text": "   "}), encoding="utf-8")
        with self.assertRaises(tts.AIRequestPending):
            tts._ai_call(MESSAGES)

    def test_fallback_passthrough(self):
        # _ai_call_with_fallback delegates to _ai_call (and thus raises too)
        with self.assertRaises(tts.AIRequestPending):
            tts._ai_call_with_fallback(MESSAGES, max_retries=3)

    def test_work_dir_uses_env_override(self):
        work = tts._ai_work_dir()
        self.assertEqual(work, Path(self.tmp.name))
        self.assertTrue(work.is_dir())

    def test_max_retries_kept_for_compatibility(self):
        sig = inspect.signature(tts._ai_call)
        self.assertIn("max_retries", sig.parameters)


if __name__ == "__main__":
    unittest.main()
