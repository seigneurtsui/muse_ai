# Optional scripted voiceover adapter

Voiceover is **opt-in only**: the parent pipeline must call this adapter only when
an explicit JSON script has been supplied. It must not discover a script
implicitly, infer narration from subtitles, generate new text, or enable TTS by
default. This adapter does not edit video, mix source audio, or apply ducking.

## Privacy and engine

**Uncached script text is uploaded to Microsoft Edge cloud TTS.** Edge TTS is not
an offline/local synthesis engine. **No video or source audio is uploaded**; this
adapter receives no video path. Script text and synthesis settings are also kept
locally in the cache and manifest, so treat those output files as potentially
private.

The installed `~/.config/omnirush/skills/edge-tts/scripts/tts.py` is invoked with
`sys.executable` in a subprocess and `--provider=edge`. The adapter implements no
TTS engine. It passes a temporary input text file rather than putting text in
process arguments. An explicitly supplied empty highlight-keyword file disables
the installed CLI's automatic AI highlighting. Semantic splitting, translation,
AI punctuation, pronunciation substitution, and the CLI's SRT/ASS generation are
not used. Captions are written locally from the supplied complete lines.

Requirements: Python 3.10+, FFmpeg and FFprobe on `PATH`, and the installed Edge
TTS CLI with its existing `edge-tts` Python dependency. Valid cached lines can be
reused without cloud access; a new, changed, or corrupted line requires cloud
synthesis. There are no network calls in the adapter's automated tests.

## JSON scripts: seconds on the **output timeline**

A single-video script:

```json
{
  "lines": [
    {"text": "欢迎观看。", "start": 0.5, "end": 2.0},
    {"text": "这里是第二句话。", "start": 3.0, "end": 5.5}
  ]
}
```

A batch script:

```json
{
  "videos": {
    "video-id-from-the-pipeline": {
      "lines": [
        {"text": "这段视频的旁白。", "start": 0.5, "end": 3.0}
      ]
    },
    "another-video-id": {
      "lines": [
        {"text": "另一段视频的旁白。", "start": 1.0, "end": 4.0}
      ]
    }
  }
}
```

Batch keys **must be the exact pipeline video id**, not filenames, stems, or
array positions. `video_id` selects the entry; a missing id is an error. A
single-video script applies to the selected video. In both cases the parent
supplies that video's final output duration. In edit mode, times refer to the
edited output, not source-video times; the parent must determine the final
duration before calling this adapter.

The selected `lines` array must be non-empty. Each line contains exactly `text`,
`start`, and `end`; text is one non-empty line without control characters.
Surrounding text whitespace is stripped. Root keys must be exactly `lines` or
`videos`, not both; duplicate JSON keys are rejected. Times must be finite JSON
numbers (booleans and numeric strings are not accepted), with
`0 <= start < end <= duration`. Declared windows must not overlap, even when
actual speech would be shorter. Unsorted lines are accepted and placed in
chronological order; stable per-line MP3 names retain the original array index.
The selected entry is validated before any cloud synthesis occurs.

## Pipeline CLI

```bash
PIPE="$HOME/.config/omnirush/skills/auto-video-editing-pipeline/scripts/auto_video_pipeline.py"
python3 "$PIPE" /path/to/video.mp4 --voiceover-script /path/to/narration.json \
  --voiceover-voice zh-CN-YunxiNeural --voiceover-rate=+0% \
  --voiceover-volume=+0% --voiceover-duck-db -12 \
  --voiceover-captions voiceover --stop-for-preview --resume
# After watching the complete preview and boundary materials:
python3 "$PIPE" --resume-batch /path/to/batch --approve-preview
```

The installed pipeline uses `videos/<id>/tts/` for this adapter. Source captions
are retained by default (`--voiceover-captions source`); `voiceover` selects the
placed script captions, then the usual srt-ass-studio/ASS/badge path. Source audio
is attenuated only while narration speaks, with approximately 30ms ducking ramps;
audio is not globally muted. A source with no audio still receives narration.
The same mix is used for preview and final. Supplying a script is the explicit
opt-in for Edge text transmission; no script means no adapter call.

## Python interface

```python
from pathlib import Path
from scripts.voiceover import prepare_voiceover

result = prepare_voiceover(
    script_path=Path("narration.json"),
    video_id="video-id-from-the-pipeline",
    output_dir=Path("batch/videos/video-id-from-the-pipeline/tts"),
    duration=8.0,
    voice="zh-CN-YunxiNeural",  # default
    rate="+0%",                # default; signed percentage
    volume="+0%",              # default; signed percentage
    duck_db=-12.0,              # default; finite, <= 0
)
```

The returned dictionary contains:

| Key | Meaning |
| --- | --- |
| `audio_path` | Absolute path to `voiceover.wav`, full-duration stereo 48 kHz signed 16-bit PCM WAV |
| `captions_path` | Absolute path to `voiceover.srt`, one complete supplied line per cue |
| `manifest_path` | Absolute path to `voiceover_manifest.json` |
| `intervals` | Chronological list of `{"start": seconds, "end": seconds}` from placed start to actual decoded speech end |
| `duck_db` | Requested source attenuation in dB, for the parent mixer |
| `duration` | Actual track duration rounded to the nearest 48 kHz sample |

The parent owns command-line opt-in, configuration/fingerprinting, render mixing,
and source ducking. Apply `duck_db` only over `intervals`, not over a line's
unused window or the entire video. There is no implicit source muting or ducking
in this adapter.

## Fit and validation rules

Each synthesized/cache MP3 must have exactly one valid audio stream and a finite
positive FFprobe duration, and must pass a full error-checked FFmpeg decode.
Actual speech duration is determined from all decoded samples after conversion
to stereo 48 kHz PCM; MP3 encoder delay/padding is not mistaken for spoken
content. Stable `voiceover_001.mp3`, `voiceover_002.mp3`, etc. are byte-identical
copies of the validated cache entries, verified by SHA-256.

Speech is placed at `start` on the nearest 48 kHz sample, without time stretching,
compression, or truncation. If it is shorter than `end - start`, the remainder
and any gaps are silence. If it is too long (including a sample-grid boundary
violation), preparation fails with the line number, measured duration, available
window, and instructions to shorten the text, explicitly choose a faster rate,
or widen/move the window. A synthesized overlong line remains cached, so merely
widening its window does not upload it again.

Caption and ducking ends use **actual speech end**, not the declared maximum
`end`. SRT timestamps are rounded inward to millisecond precision so they never
extend past the speech or window. Audio and ducking offsets retain sample
precision. A clip too short for a positive millisecond SRT cue is rejected.

The full track is built sequentially from decoded PCM plus chunked silence,
then encoded and fully decoded/validated by FFmpeg. Memory use and subprocess
argument count do not grow with the number of lines. Disk usage includes the
full temporary PCM track and per-line decoded PCM. No giant input/filter command
is constructed. Final files are published only after every line fits and the
full track passes validation; callers must treat any raised error as a failed
preparation, not reuse previous published files blindly.

## Cache and manifest

`output_dir/.voiceover_cache/<sha256>.mp3` and its adjacent JSON metadata are
content-addressed by normalized text, voice, rate, volume, provider and adapter
cache version. Changing a line synthesizes only that line; changing voice, rate,
or volume invalidates all affected line identities. Changing offsets, output
duration, or ducking does **not** resynthesize otherwise-valid lines. Reordering
identical lines also reuses their cache. The cache is local to the supplied
output directory, so the parent should keep that directory stable on resume.

A cache hit requires matching identity and stored audio SHA-256 **and** successful
probe/full decode. Corrupt metadata, hash mismatch, missing audio, or decode
failure causes regeneration of only that cache entry. The adapter never accepts
an MP3 solely because its filename exists. Cache entries and metadata are
published atomically per file; concurrent preparation into the same output
directory should be serialized by the parent.

The manifest retains the script path/hash, selected video id, complete line text,
requested and sample-placed offsets, declared windows, decoded/probed durations,
cache identities and hit/miss decisions, per-line audio hashes, the synthesis
CLI hash, voice/rate/volume/ducking config, full-track/caption hashes, the return
interface, and an explicit Edge cloud privacy note. No script text is echoed in
Edge subprocess failure messages.

## Offline verification

From the skill directory:

```bash
python3 -m unittest discover -s tests -p 'test_voiceover.py' -v
```

Tests mock the synthesis boundary, use FFmpeg-generated synthetic audio, verify
real placed PCM samples and silence, and exercise invalid scripts, overflow,
line/config cache invalidation, and corrupted caches. They never call the live
Edge service; passing them does not claim cloud availability or voice quality.
