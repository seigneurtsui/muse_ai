#!/usr/bin/env python3
"""
Episode-to-Video: Combined pipeline from episode-text shot list to video generation.

Usage:
    python episode_to_video.py --shot-list <path_to_shot_list.md> [--output-dir <dir>]
    python episode_to_video.py --source-text <path_to_source.md> [--book-title <title>] [--topic <topic>] [--output-dir <dir>]

This script:
1. Parses the episode-text shot list format (or generates one via episode-text skill)
2. Generates images for each shot using agnes-text2image (for static shots)
3. Generates videos for each shot using agnes-text2video (for motion shots)
4. Assembles final video with ffmpeg
"""

import argparse
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional, List

# ─── Constants ───────────────────────────────────────────────────────────────
DEFAULT_OUTPUT_DIR = Path.home() / "Downloads" / "episode-to-video"
NODE_SCRIPTS_DIR = Path.home() / ".config" / "opencode" / "skills" / "agnes-text2video"
TEXT2VIDEO_SCRIPT = NODE_SCRIPTS_DIR / "scripts" / "text2video.mjs"
TEXT2IMAGE_SCRIPT = NODE_SCRIPTS_DIR / "scripts" / "text2image.mjs"
POLL_INTERVAL = 5  # seconds between status checks
MAX_WAIT = 1800  # 30 minutes max wait for async tasks
SHOT_DURATION_DEFAULT = 8  # seconds


@dataclass
class Shot:
    """A single shot parsed from the episode-text shot list."""
    number: int
    duration: int = SHOT_DURATION_DEFAULT
    scene: str = ""
    visual_description: str = ""
    lighting: str = ""
    dialogue: str = ""
    tone_hint: str = ""
    ambient_sound: str = ""
    camera_movement: str = ""
    transition: str = ""
    # Generation metadata
    image_path: Optional[str] = None
    video_path: Optional[str] = None
    prompt: str = ""
    is_motion: bool = False  # True = video, False = still image


@dataclass
class EpisodeSpec:
    """Full episode specification parsed from shot list."""
    title: str = "episode"
    shot_type: str = "实拍"
    target_duration: str = "60-120s"
    aspect_ratio: str = "16:9"
    source: str = ""
    shots: List[Shot] = field(default_factory=list)


# ─── Shot List Parser ────────────────────────────────────────────────────────
def parse_shot_list(file_path: str) -> EpisodeSpec:
    """
    Parse the episode-text shot list format.
    
    Format per shot:
    ## 镜头 NN
    - **时长**: Ns
    - **场景**: ...
    - **画面描述**: ...
    - **光影**: ...
    - **台词/旁白**: ...
    - **语气提示**: ...
    - **环境音效**: ...
    - **镜头运动**: ...
    - **转场方式**: ...
    """
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()

    spec = EpisodeSpec()
    
    # Parse header
    header_match = re.search(
        r"#\s+(.+?)\s*\n.*?类型[：:]\s*(.+?)\n.*?时长[：:]\s*(.+?)\n",
        content,
        re.DOTALL,
    )
    if header_match:
        spec.title = header_match.group(1).strip()
        spec.shot_type = header_match.group(2).strip()
        spec.target_duration = header_match.group(3).strip()

    # Parse individual shots
    shot_blocks = re.split(r"##\s*镜头\s*(\d+)", content)
    # shot_blocks[0] is header, then alternating: number, content
    for i in range(1, len(shot_blocks), 2):
        if i + 1 >= len(shot_blocks):
            break
        shot_num = int(shot_blocks[i])
        shot_content = shot_blocks[i + 1]
        shot = Shot(number=shot_num)

        # Extract fields
        fields = {
            "时长": "duration",
            "场景": "scene",
            "画面描述": "visual_description",
            "光影": "lighting",
            "台词": "dialogue",
            "语气提示": "tone_hint",
            "环境音效": "ambient_sound",
            "镜头运动": "camera_movement",
            "转场方式": "transition",
        }

        for label, attr in fields.items():
            match = re.search(
                rf"\*\*{re.escape(label)}[^*]*\*\*[：:]\s*(.+?)(?:\n|$)",
                shot_content,
            )
            if match:
                value = match.group(1).strip()
                if attr == "duration":
                    shot.duration = int(re.sub(r"[^\d]", "", value) or SHOT_DURATION_DEFAULT)
                else:
                    setattr(shot, attr, value)

        # Determine if this shot has motion
        motion_keywords = ["跟", "推", "拉", "摇", "移", "跟拍", "跟摇", "横移", "航拍"]
        shot.is_motion = any(kw in shot.camera_movement for kw in motion_keywords) or shot.duration > 6

        # Build generation prompt
        shot.prompt = _build_prompt(shot)
        spec.shots.append(shot)

    return spec


def _build_prompt(shot: Shot) -> str:
    """Build a video/image generation prompt from shot fields."""
    parts = []
    if shot.visual_description:
        parts.append(shot.visual_description)
    if shot.lighting:
        parts.append(shot.lighting)
    if shot.camera_movement:
        parts.append(shot.camera_movement)
    if shot.scene:
        parts.append(f"Scene: {shot.scene}")
    return ", ".join(parts) if parts else f"Shot {shot.number}"


# ─── Generation Wrappers ─────────────────────────────────────────────────────
def generate_image(shot: Shot, output_dir: Path, model: str = "flux") -> Optional[str]:
    """Generate a still image for a shot using agnes-text2image."""
    out_file = output_dir / f"shot_{shot.number:02d}.png"
    cmd = [
        "node", str(TEXT2IMAGE_SCRIPT),
        "--prompt", shot.prompt,
        "--model", model,
        "--dir", str(output_dir),
        "--output", f"shot_{shot.number:02d}.png",
    ]
    print(f"  [IMG] Generating image for shot {shot.number}...")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"  [IMG] Error: {result.stderr}", file=sys.stderr)
        return None
    if out_file.exists():
        shot.image_path = str(out_file)
        return str(out_file)
    # Try to find output from stdout
    for line in result.stdout.splitlines():
        if "Saved:" in line or "saved:" in line:
            path = line.split(":", 1)[1].strip()
            if Path(path).exists():
                shot.image_path = path
                return path
    return None


def generate_video(shot: Shot, output_dir: Path, model: str = "hailuo") -> Optional[str]:
    """Generate a video for a shot using agnes-text2video."""
    cmd = [
        "node", str(TEXT2VIDEO_SCRIPT),
        "--prompt", shot.prompt,
        "--model", model,
        "--num-frames", str(shot.duration * 25),  # 25 fps
        "--frame-rate", "25",
        "--dir", str(output_dir),
        "--output", f"shot_{shot.number:02d}.mp4",
        "--poll-interval", str(POLL_INTERVAL),
        "--max-wait", str(MAX_WAIT),
    ]
    print(f"  [VID] Generating video for shot {shot.number} ({shot.duration}s)...")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"  [VID] Error: {result.stderr}", file=sys.stderr)
        return None
    # Find output path from stdout
    for line in result.stdout.splitlines():
        if "Saved:" in line or "saved:" in line or ".mp4" in line:
            match = re.search(r"(/[^ \n]+\.mp4)", line)
            if match and Path(match.group(1)).exists():
                shot.video_path = match.group(1)
                return match.group(1)
    return None


def generate_image_to_video(shot: Shot, output_dir: Path, model: str = "hailuo") -> Optional[str]:
    """Generate video from an existing image using agnes-text2image --image."""
    if not shot.image_path:
        return None
    cmd = [
        "node", str(TEXT2VIDEO_SCRIPT),
        "--prompt", f"Animate this scene: {shot.prompt}",
        "--model", model,
        "--image", shot.image_path,
        "--num-frames", str(shot.duration * 25),
        "--frame-rate", "25",
        "--dir", str(output_dir),
        "--output", f"shot_{shot.number:02d}.mp4",
        "--poll-interval", str(POLL_INTERVAL),
        "--max-wait", str(MAX_WAIT),
    ]
    print(f"  [VID] Generating video from image for shot {shot.number}...")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"  [VID] Error: {result.stderr}", file=sys.stderr)
        return None
    for line in result.stdout.splitlines():
        if ".mp4" in line:
            match = re.search(r"(/[^ \n]+\.mp4)", line)
            if match and Path(match.group(1)).exists():
                shot.video_path = match.group(1)
                return match.group(1)
    return None


# ─── Assembly ────────────────────────────────────────────────────────────────
def assemble_video(spec: EpisodeSpec, output_dir: Path) -> Optional[str]:
    """Concatenate all shot videos into a final episode video using ffmpeg."""
    # Collect all video clips (motion shots have video, still shots need image→video conversion)
    clips = []
    for shot in spec.shots:
        if shot.video_path and Path(shot.video_path).exists():
            clips.append(shot.video_path)

    if not clips:
        print("[ASM] No clips to assemble.", file=sys.stderr)
        return None

    # Write concat list
    concat_file = output_dir / "concat_list.txt"
    with open(concat_file, "w") as f:
        for clip in clips:
            f.write(f"file '{clip}'\n")

    output_file = output_dir / f"{spec.title}.mp4"
    cmd = [
        "ffmpeg", "-y",
        "-f", "concat",
        "-safe", "0",
        "-i", str(concat_file),
        "-c", "copy",
        str(output_file),
    ]
    print(f"[ASM] Assembling {len(clips)} clips into {output_file.name}...")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"[ASM] ffmpeg error: {result.stderr}", file=sys.stderr)
        return None
    if output_file.exists():
        print(f"[ASM] Final video: {output_file}")
        return str(output_file)
    return None


# ─── Main Pipeline ───────────────────────────────────────────────────────────
def run_pipeline(args):
    """Main orchestration pipeline."""
    output_dir = Path(args.output_dir) if args.output_dir else DEFAULT_OUTPUT_DIR
    output_dir.mkdir(parents=True, exist_ok=True)

    # Step 1: Get shot list
    if args.shot_list:
        print(f"[1/4] Parsing shot list: {args.shot_list}")
        spec = parse_shot_list(args.shot_list)
    else:
        print("[1/4] Shot list not provided. Please run episode-text skill first to generate a shot list.")
        print("      Example: python episode_text.py --source-text <file> --output <shotlist.md>")
        sys.exit(1)

    if not spec.shots:
        print("[ERR] No shots found in shot list.", file=sys.stderr)
        sys.exit(1)

    print(f"  → {len(spec.shots)} shots parsed ({spec.target_duration} target)")

    # Step 2: Generate media per shot
    print(f"\n[2/4] Generating media for {len(spec.shots)} shots...")
    for shot in spec.shots:
        if shot.is_motion:
            # Motion shot: try video generation directly
            generate_video(shot, output_dir, model=args.model)
        else:
            # Still shot: generate image, optionally animate
            generate_image(shot, output_dir, model="flux")
            if args.animate_stills:
                generate_image_to_video(shot, output_dir, model=args.model)

    # Step 3: Assembly
    print("\n[3/4] Assembling final video...")
    result = assemble_video(spec, output_dir)

    # Step 4: Report
    print(f"\n[4/4] Done.")
    if result:
        print(f"  Final video: {result}")
    else:
        print("  Assembly failed or no clips generated.")

    # Print shot summary
    print(f"\n{'─' * 60}")
    print(f"{'Shot':<8} {'Type':<8} {'Duration':<10} {'Status':<10}")
    print(f"{'─' * 60}")
    for shot in spec.shots:
        status = "✓" if (shot.video_path or shot.image_path) else "✗"
        typ = "video" if shot.is_motion else "image"
        print(f"{shot.number:<8} {typ:<8} {shot.duration}s{'':<7} {status}")
    print(f"{'─' * 60}")


def main():
    parser = argparse.ArgumentParser(
        description="Episode-to-Video: Generate video from episode-text shot list"
    )
    parser.add_argument("--shot-list", help="Path to episode-text shot list markdown file")
    parser.add_argument("--source-text", help="Path to source text (will generate shot list first)")
    parser.add_argument("--book-title", help="Book title for episode-text generation")
    parser.add_argument("--topic", help="Topic for episode-text generation")
    parser.add_argument("--output-dir", help="Output directory (default: ~/Downloads/episode-to-video)")
    parser.add_argument("--model", default="hailuo", help="Video model (default: hailuo)")
    parser.add_argument("--animate-stills", action="store_true", help="Animate still shots with image-to-video")
    parser.add_argument("--list-models", action="store_true", help="List available models and exit")
    args = parser.parse_args()

    if args.list_models:
        cmd = ["node", str(TEXT2VIDEO_SCRIPT), "--list-models"]
        subprocess.run(cmd)
        return

    if not args.shot_list and not args.source_text:
        parser.error("Either --shot-list or --source-text is required")

    run_pipeline(args)


if __name__ == "__main__":
    main()
