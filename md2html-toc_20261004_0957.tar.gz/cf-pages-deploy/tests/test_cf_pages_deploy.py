from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import cf_pages_deploy as app


class FakeClient:
    """Records API calls; returns preset existence."""

    instances: list["FakeClient"] = []

    def __init__(self, token, account_id, **kwargs):
        self.token = token
        self.account_id = account_id
        self.created: list[tuple] = []
        self.existing: set[str] = set(FakeClient.existing_names)
        FakeClient.instances.append(self)

    # class-level knobs mutated per test
    existing_names: set[str] = set()

    def get_pages_project(self, name):
        return {"name": name} if name in self.existing else None

    def create_pages_project(self, name, branch="main"):
        self.created.append((name, branch))
        return {"name": name}

    def list_pages_projects(self):
        return [{"name": n} for n in sorted(self.existing)]


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        self.state = self.root / "state.json"
        FakeClient.instances = []
        FakeClient.existing_names = set()
        # Isolate from the real user env file.
        self.env_patch = patch.object(
            app, "DEFAULT_ENV_FILE", self.root / "missing.env"
        )
        self.env_patch.start()
        self.addCleanup(self.env_patch.stop)
        self.creds = patch.dict(
            os.environ, {"CF_API_TOKEN": "tok", "CF_ACCOUNT_ID": "acct"}, clear=False
        )
        self.creds.start()
        self.addCleanup(self.creds.stop)

    def write_site(self, name="site", filename="index.html", content="<h1>hi</h1>"):
        site = self.root / name
        site.mkdir(parents=True, exist_ok=True)
        (site / filename).write_text(content, encoding="utf-8")
        return site

    def write_config(self, entries, filename="cf.yaml"):
        lines = ["pages:"]
        for name, source in entries.items():
            lines += [
                f"  {name}:",
                f'    source_dir: "{source}"',
                '    branch: "main"',
                "    create_if_missing: true",
            ]
        path = self.root / filename
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return path

    def deploy_args(self, *extra):
        return app.build_parser().parse_args(
            ["deploy", "--state", str(self.state), "--jobs", "1", *extra]
        )


class EnvTests(Base):
    def test_parse_env_file_handles_quotes_export_and_comments(self):
        env_file = self.root / ".env"
        env_file.write_text(
            textwrap.dedent("""\
                # comment
                CF_API_TOKEN=abc123

                export FOO="bar baz"
                Q='quoted'
                """),
            encoding="utf-8",
        )
        values = app.parse_env_file(env_file)
        self.assertEqual(values["CF_API_TOKEN"], "abc123")
        self.assertEqual(values["FOO"], "bar baz")
        self.assertEqual(values["Q"], "quoted")

    def test_load_env_files_does_not_override_real_env(self):
        env_file = self.root / ".env"
        env_file.write_text("CF_API_TOKEN=from_file\n", encoding="utf-8")
        with patch.dict(os.environ, {"CF_API_TOKEN": "from_env"}, clear=False):
            loaded = app.load_env_files([str(env_file)])
            self.assertEqual(os.environ["CF_API_TOKEN"], "from_env")
        self.assertEqual(loaded, [str(env_file)])

    def test_credentials_accepts_both_prefixes(self):
        with patch.dict(
            os.environ,
            {"CF_API_TOKEN": "", "CLOUDFLARE_API_TOKEN": "t2", "CF_ACCOUNT_ID": "a2"},
            clear=False,
        ):
            os.environ.pop("CF_API_TOKEN", None)
            token, account = app.credentials()
        self.assertEqual(token, "t2")
        self.assertEqual(account, "a2")


class ConfigTests(Base):
    def test_relative_source_resolves_against_config_dir(self):
        self.write_site("site")
        config = self.write_config({"my-site": "./site"})
        specs = app.load_config(str(config))
        self.assertEqual(len(specs), 1)
        self.assertEqual(specs[0].name, "my-site")
        self.assertEqual(Path(specs[0].source), self.root / "site")

    def test_invalid_project_name_is_rejected(self):
        config = self.write_config({"Bad_Name": "./site"})
        with self.assertRaisesRegex(app.DeployError, "invalid_project_name"):
            app.load_config(str(config))

    def test_missing_config_raises(self):
        with self.assertRaisesRegex(app.DeployError, "config_not_found"):
            app.load_config(str(self.root / "nope.yaml"))

    def test_discover_specs_finds_html_dirs_and_normalizes_names(self):
        self.write_site("Site One")
        self.write_site("plain")
        (self.root / "empty").mkdir()
        (self.root / ".hidden").mkdir()
        (self.root / ".hidden" / "index.html").write_text("x", encoding="utf-8")
        specs = app.discover_specs(str(self.root), name_prefix="pre-")
        names = sorted(spec.name for spec in specs)
        self.assertEqual(names, ["pre-plain", "pre-site-one"])

    def test_discover_specs_raises_when_no_sites(self):
        (self.root / "empty").mkdir()
        with self.assertRaisesRegex(app.DeployError, "discover_found_no_sites"):
            app.discover_specs(str(self.root))


class DigestTests(Base):
    def test_dir_digest_is_stable_and_changes_with_content(self):
        site = self.write_site("site")
        (site / "a.css").write_text("body{}", encoding="utf-8")
        first = app.source_digest(site)
        second = app.source_digest(site)
        self.assertEqual(first["sha256"], second["sha256"])
        self.assertEqual(first["mode"], "dir")
        self.assertEqual(first["files"], 2)
        (site / "a.css").write_text("body{color:red}", encoding="utf-8")
        self.assertNotEqual(first["sha256"], app.source_digest(site)["sha256"])

    def test_file_digest_and_html_count(self):
        page = self.root / "page.html"
        page.write_text("<h1>x</h1>", encoding="utf-8")
        digest = app.source_digest(page)
        self.assertEqual(digest["mode"], "file")
        self.assertEqual(app.count_html(page), 1)
        not_html = self.root / "readme.txt"
        not_html.write_text("x", encoding="utf-8")
        self.assertEqual(app.count_html(not_html), 0)

    def test_source_digest_missing_path_raises(self):
        with self.assertRaisesRegex(app.DeployError, "source_not_found"):
            app.source_digest(self.root / "gone")


class WranglerTests(Base):
    def test_command_includes_project_branch_and_options(self):
        spec = app.PageSpec(
            name="my-site",
            source="/tmp/site",
            branch="preview",
            commit_message="hello",
            skip_caching=True,
        )
        command = app.build_wrangler_command(["wrangler"], Path("/tmp/site"), spec)
        self.assertEqual(command[:4], ["wrangler", "pages", "deploy", "/tmp/site"])
        self.assertIn("--project-name", command)
        self.assertIn("my-site", command)
        self.assertIn("--commit-dirty=true", command)
        self.assertIn("--commit-message", command)
        self.assertIn("--skip-caching", command)
        self.assertEqual(command[command.index("--branch") + 1], "preview")

    def test_parse_deploy_url_returns_last_match(self):
        output = "one https://first.pages.dev two https://second.pages.dev/path"
        self.assertEqual(app.parse_deploy_url(output), "https://second.pages.dev/path")
        self.assertIsNone(app.parse_deploy_url("no url here"))

    def test_deploy_wrangler_retries_then_succeeds(self):
        spec = app.PageSpec(name="s", source="/tmp/site")
        opts = app.Options(retries=3)
        results = [
            app.CommandResult(1, "", "boom"),
            app.CommandResult(0, "https://ok.pages.dev", ""),
        ]
        with patch.object(app, "run_wrangler", side_effect=results), patch.object(
            app.time, "sleep"
        ):
            out = app.deploy_wrangler(
                ["wrangler"], Path("/tmp/site"), spec, "t", "a", opts
            )
        self.assertEqual(out.returncode, 0)
        self.assertEqual(out.stdout, "https://ok.pages.dev")

    def test_run_wrangler_timeout_returns_failure(self):
        spec = app.PageSpec(name="s", source="/tmp/site")
        with patch.object(
            app.subprocess, "run", side_effect=app.subprocess.TimeoutExpired("w", 1)
        ):
            out = app.run_wrangler(["wrangler"], Path("/tmp/site"), spec, "t", "a", 1)
        self.assertEqual(out.returncode, 1)
        self.assertIn("timed out", out.stderr)


class PlanTests(Base):
    def test_dry_run_touches_no_network_or_state(self):
        self.write_site("site")
        config = self.write_config({"my-site": "./site"})
        calls = {"run": 0}

        def boom(*args, **kwargs):
            calls["run"] += 1
            raise AssertionError("dry-run must not deploy")

        with patch.object(app, "run_wrangler", side_effect=boom):
            report = app.batch(self.deploy_args("--config", str(config), "--dry-run"))

        self.assertEqual(report["status"], "dry_run")
        self.assertEqual(report["summary"]["planned"], 1)
        self.assertEqual(report["results"][0]["status"], "planned")
        self.assertFalse(self.state.exists())
        self.assertEqual(calls["run"], 0)

    def test_dry_run_isolates_bad_source(self):
        self.write_site("good")
        config = self.write_config({"good": "./good", "bad": "./missing"})
        report = app.batch(
            self.deploy_args("--config", str(config), "--dry-run", "--only", "")
        )
        statuses = {item["name"]: item["status"] for item in report["results"]}
        self.assertEqual(statuses["good"], "planned")
        self.assertEqual(statuses["bad"], "failed")


class DeployTests(Base):
    def _patch_deploy(self, url="https://new.pages.dev"):
        self.runner = patch.object(
            app, "run_wrangler", return_value=app.CommandResult(0, f"done {url}", "")
        )
        self.runner.start()
        self.addCleanup(self.runner.stop)
        self.client_patch = patch.object(app, "CloudflareClient", FakeClient)
        self.client_patch.start()
        self.addCleanup(self.client_patch.stop)
        self.wrangler_patch = patch.object(
            app, "find_wrangler", return_value=["wrangler"]
        )
        self.wrangler_patch.start()
        self.addCleanup(self.wrangler_patch.stop)

    def test_creates_missing_project_and_records_success(self):
        self._patch_deploy()
        site = self.write_site("site")
        config = self.write_config({"my-site": "./site"})
        report = app.batch(self.deploy_args("--config", str(config)))
        self.assertEqual(report["summary"]["success"], 1)
        result = report["results"][0]
        self.assertTrue(result["created_project"])
        self.assertEqual(result["url"], "https://new.pages.dev")
        self.assertEqual(FakeClient.instances[0].created, [("my-site", "main")])
        state = json.loads(self.state.read_text())
        self.assertEqual(state["pages"]["my-site"]["status"], "success")
        self.assertTrue(state["pages"]["my-site"]["content_sha256"])
        self.assertTrue(site.exists())

    def test_existing_project_is_not_recreated(self):
        self._patch_deploy()
        FakeClient.existing_names = {"my-site"}
        self.write_site("site")
        config = self.write_config({"my-site": "./site"})
        report = app.batch(self.deploy_args("--config", str(config)))
        self.assertFalse(report["results"][0]["created_project"])
        self.assertEqual(FakeClient.instances[0].created, [])

    def test_unchanged_site_is_skipped_then_force_redeploys(self):
        self._patch_deploy()
        self.write_site("site")
        config = self.write_config({"my-site": "./site"})
        app.batch(self.deploy_args("--config", str(config)))

        with patch.object(
            app, "run_wrangler", side_effect=AssertionError("should skip")
        ):
            second = app.batch(self.deploy_args("--config", str(config)))
        self.assertEqual(second["results"][0]["status"], "skipped")
        self.assertEqual(second["results"][0]["reason"], "unchanged")
        # state must still remember the successful deploy
        state = json.loads(self.state.read_text())
        self.assertEqual(state["pages"]["my-site"]["status"], "success")

        third = app.batch(self.deploy_args("--config", str(config), "--force"))
        self.assertEqual(third["results"][0]["status"], "success")

    def test_changed_site_redeploys_without_force(self):
        self._patch_deploy()
        site = self.write_site("site")
        config = self.write_config({"my-site": "./site"})
        app.batch(self.deploy_args("--config", str(config)))
        (site / "index.html").write_text("<h1>changed</h1>", encoding="utf-8")
        again = app.batch(self.deploy_args("--config", str(config)))
        self.assertEqual(again["results"][0]["status"], "success")

    def test_retry_failed_skips_successes(self):
        self._patch_deploy()
        self.write_site("site")
        config = self.write_config({"my-site": "./site", "other": "./site"})
        app.batch(self.deploy_args("--config", str(config), "--only", "my-site"))
        report = app.batch(self.deploy_args("--config", str(config), "--retry-failed"))
        statuses = {item["name"]: item for item in report["results"]}
        self.assertEqual(statuses["my-site"]["reason"], "retry_failed_skip")
        self.assertEqual(statuses["other"]["status"], "success")

    def test_failure_has_reason_and_truncated_detail(self):
        self.write_site("site")
        self.client_patch = patch.object(app, "CloudflareClient", FakeClient)
        self.client_patch.start()
        self.addCleanup(self.client_patch.stop)
        with patch.object(
            app, "run_wrangler", return_value=app.CommandResult(1, "", "x" * 5000)
        ), patch.object(app, "find_wrangler", return_value=["wrangler"]), patch.object(
            app.time, "sleep"
        ):
            report = app.batch(
                self.deploy_args("--config", str(self.write_config({"s": "./site"})))
            )
        result = report["results"][0]
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["reason"], "wrangler_failed")
        self.assertLessEqual(len(result["detail"]), app.MAX_WARNING_CHARS + 3)

    def test_project_missing_when_create_disabled(self):
        self.write_site("site")
        config = self.root / "cf.yaml"
        config.write_text(
            "pages:\n  s:\n    source_dir: ./site\n    create_if_missing: false\n",
            encoding="utf-8",
        )
        with patch.object(app, "CloudflareClient", FakeClient), patch.object(
            app, "find_wrangler", return_value=["wrangler"]
        ), patch.object(
            app, "run_wrangler", side_effect=AssertionError("must not run")
        ):
            report = app.batch(self.deploy_args("--config", str(config)))
        self.assertEqual(report["results"][0]["reason"], "project_missing")

    def test_parallel_batch_deploys_all(self):
        self._patch_deploy()
        self.write_site("a")
        self.write_site("b")
        self.write_site("c")
        config = self.write_config({"a": "./a", "b": "./b", "c": "./c"})
        report = app.batch(
            app.build_parser().parse_args(
                [
                    "deploy",
                    "--config",
                    str(config),
                    "--state",
                    str(self.state),
                    "--jobs",
                    "3",
                ]
            )
        )
        self.assertEqual(report["summary"]["success"], 3)
        state = json.loads(self.state.read_text())
        self.assertEqual(sorted(state["pages"]), ["a", "b", "c"])


class ApiTests(Base):
    def test_list_projects_paginates_with_valid_per_page(self):
        client = app.CloudflareClient("t", "a")
        calls = []

        class Resp:
            def __init__(self, payload, status=200):
                self._payload = payload
                self.status_code = status

            def json(self):
                return self._payload

        def fake_request(method, url, timeout=None, **kwargs):
            params = kwargs.get("params") or {}
            calls.append(params)
            result = [{"name": "a"}] if params.get("page", 1) == 1 else [{"name": "b"}]
            return Resp(
                {"success": True, "result": result, "result_info": {"total_pages": 2}}
            )

        with patch.object(client.session, "request", side_effect=fake_request):
            projects = client.list_pages_projects()
        self.assertEqual([p["name"] for p in projects], ["a", "b"])
        self.assertTrue(calls)
        self.assertTrue(all(p.get("per_page") == 10 for p in calls))

    def test_get_project_returns_none_on_404(self):
        client = app.CloudflareClient("t", "a")

        class Resp:
            status_code = 404

            def json(self):
                return {"success": False, "errors": [{"code": 8000007}]}

        with patch.object(client.session, "request", return_value=Resp()):
            self.assertIsNone(client.get_pages_project("nope"))

    def test_missing_credentials_client_raises(self):
        with self.assertRaisesRegex(app.DeployError, "credentials_missing"):
            app.CloudflareClient("", "")


class CliTests(Base):
    def test_jobs_validation(self):
        self.assertEqual(app.resolve_jobs("auto", 10), 4)
        self.assertEqual(app.resolve_jobs("2", 10), 2)
        self.assertEqual(app.resolve_jobs("99", 3), 3)
        with self.assertRaisesRegex(app.DeployError, "invalid_jobs_value"):
            app.resolve_jobs("many", 5)

    def test_missing_credentials_is_reported(self):
        with patch.dict(os.environ, {}, clear=False):
            for key in (
                "CF_API_TOKEN",
                "CF_ACCOUNT_ID",
                "CLOUDFLARE_API_TOKEN",
                "CLOUDFLARE_ACCOUNT_ID",
            ):
                os.environ.pop(key, None)
            site = self.write_site("site")
            code = app.main(
                [
                    "deploy",
                    "--dir",
                    str(site),
                    "--project-name",
                    "s",
                    "--state",
                    str(self.state),
                ]
            )
        self.assertEqual(code, 1)

    def test_no_input_specified(self):
        with self.assertRaisesRegex(app.DeployError, "no_input_specified"):
            app.specs_from_args(app.build_parser().parse_args(["deploy"]))

    def test_discover_command_writes_config(self):
        self.write_site("alpha")
        self.write_site("beta")
        output = self.root / "cf.yaml"
        code = app.main(["discover", "--root", str(self.root), "--output", str(output)])
        self.assertEqual(code, 0)
        specs = app.load_config(str(output))
        self.assertEqual(sorted(s.name for s in specs), ["alpha", "beta"])

    def test_discover_quotes_paths_with_spaces_on_one_line(self):
        self.write_site("Beta Site")
        output = self.root / "cf.yaml"
        code = app.main(["discover", "--root", str(self.root), "--output", str(output)])
        self.assertEqual(code, 0)
        text = output.read_text(encoding="utf-8")
        source_line = next(line for line in text.splitlines() if "source_dir" in line)
        self.assertIn('"', source_line)
        self.assertIn("Beta Site", source_line)
        specs = app.load_config(str(output))
        self.assertEqual(Path(specs[0].source), self.root / "Beta Site")

    def test_cli_help_and_real_dry_run_subprocess(self):
        script = Path(app.__file__)
        help_result = subprocess.run(
            [sys.executable, "-B", str(script), "--help"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        self.assertEqual(help_result.returncode, 0)
        self.assertIn("Pages", help_result.stdout)

        self.write_site("site")
        config = self.write_config({"my-site": "./site"})
        result = subprocess.run(
            [
                sys.executable,
                "-B",
                str(script),
                "deploy",
                "--config",
                str(config),
                "--dry-run",
                "--json",
                "--state",
                str(self.state),
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        report = json.loads(result.stdout)
        self.assertEqual(report["status"], "dry_run")
        self.assertEqual(report["summary"]["planned"], 1)


if __name__ == "__main__":
    unittest.main()
