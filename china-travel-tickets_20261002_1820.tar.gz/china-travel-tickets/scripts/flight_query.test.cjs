'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  AdapterError,
  buildCliArgs,
  classifyError,
  parseArgs,
  query,
  shanghaiDatePlusDays,
} = require('./flight_query.cjs');

test('parses Chinese city flags, date, limit, and official CLI arguments', () => {
  const options = parseArgs([
    '--from',
    '北京',
    '--to',
    '上海',
    '--date',
    '2099-01-02',
    '--limit',
    '3',
  ]);
  assert.equal(options.from, '北京');
  assert.equal(options.to, '上海');
  assert.equal(options.date, '2099-01-02');
  assert.equal(options.limit, 3);
  assert.deepEqual(buildCliArgs(options), [
    'search-flight',
    '--origin',
    '北京',
    '--destination',
    '上海',
    '--dep-date',
    '2099-01-02',
    '--sort-type',
    '3',
  ]);
});

test('accepts airport-code aliases and defaults to Shanghai date plus seven days', () => {
  const now = new Date('2026-10-02T15:00:00.000Z');
  const options = parseArgs(['--origin', 'PEK', '--destination', 'SHA']);
  assert.equal(options.from, 'PEK');
  assert.equal(options.to, 'SHA');
  assert.equal(shanghaiDatePlusDays(7, now), '2026-10-09');
});

test('limits but does not rewrite or fabricate upstream records', () => {
  const records = [
    { ticketPrice: '419.00', journeys: [{ segments: [{ marketingTransportNo: 'KN5977' }] }] },
    { adultPrice: '¥500.0', journeys: [] },
  ];
  const result = query(
    { from: '北京', to: '上海', date: '2099-01-02', limit: 1 },
    {
      now: new Date('2026-10-02T09:00:00.000Z'),
      runner: () => ({
        exitCode: 0,
        stdout: JSON.stringify({ status: 0, message: 'success', data: { itemList: records } }),
        stderr: '',
      }),
    },
  );
  assert.equal(result.source, 'FlyAI official CLI (@fly-ai/flyai-cli@1.0.16)');
  assert.equal(result.timestamp, '2026-10-02T09:00:00.000Z');
  assert.equal(result.availableCount, 2);
  assert.equal(result.resultCount, 1);
  assert.deepEqual(result.results, [records[0]]);
});

test('classifies quota and authentication failures clearly', () => {
  assert.equal(classifyError('HTTP 429 quota exceeded', 1).code, 'TRIAL_QUOTA_EXCEEDED');
  assert.equal(classifyError('HTTP 401 unauthorized API key', 1).code, 'TRIAL_AUTH_REQUIRED');
});

test('does not accept a non-success payload as flight data', () => {
  assert.throws(
    () => query(
      { from: '北京', to: '上海', date: '2099-01-02', limit: 1 },
      {
        runner: () => ({
          exitCode: 1,
          stdout: JSON.stringify({ status: 429, message: 'quota exceeded', data: { itemList: [] } }),
          stderr: '',
        }),
      },
    ),
    (error) => error instanceof AdapterError && error.code === 'TRIAL_QUOTA_EXCEEDED',
  );
});
