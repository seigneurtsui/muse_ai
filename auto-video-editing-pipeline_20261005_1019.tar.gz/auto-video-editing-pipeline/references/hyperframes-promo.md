# HyperFrames Promo Mode

Use this mode for a deterministic 10–30 second webpage promo, product reveal,
feature launch, or HTML composition. It is a separate input mode from spoken
video editing: do not run the STT/erratum path against HTML source.

## Routing

Read the `hyperframes` skill first, then use its specialized workflow such as
`product-launch-video`, `website-to-video`, `faceless-explainer`, or
`motion-graphics`. The current pipeline takes over after HyperFrames produces a
video file, when the user needs final ASS captions, FFmpeg normalization, and
the same QA contract.

```bash
npx --yes hyperframes init <project>/promo --example blank --non-interactive --skip-skills
npx --yes hyperframes lint <project>/promo
npx --yes hyperframes validate <project>/promo
npx --yes hyperframes render <project>/promo -o <project>/promo/render.mp4

# Optional final subtitle/QA pass after the HTML video exists:
python3 "$PIPE" <project>/promo/render.mp4 --subtitle-lang zh-Hans --resume
```

## Composition invariants

- Root element has `data-start="0"` and explicit width/height.
- Timed elements use `class="clip"` with `data-start`, `data-duration`, and
  `data-track-index`.
- Paused GSAP timelines register in `window.__timelines`.
- Child compositions use `<template>`.
- Rendering is deterministic: no `Date.now()`, `Math.random()`, or clock input.
- Do not tween `display` or `visibility`.

Render the promo first, then burn ASS captions as the final visual operation.
Verify nonblank frames, duration, resolution, frame rate, and full decode before
creating any release package.
