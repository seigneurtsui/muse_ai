---
name: china-travel-tickets
description: 查询中国 12306 高铁/动车直达及一次中转车次、余票、票价，以及免 API Key 的国内机票试用数据；生成报告、发送邮件和检测票价/余票变化。
license: MIT
compatibility: Requires Python 3.9+, Node.js 18+, network access; watcher uses Linux/macOS flock. No API key, login, booking, or payment required.
metadata:
  version: "1.2.0"
  upstream_train: "https://github.com/Joooook/12306-mcp"
  upstream_skill_reference: "https://github.com/Joooook/12306-skill"
---

# 中国高铁与机票查询

只查询，不登录、不抢票、不下单、不付款。不要求申请 API Key，不读取 FlyAI 用户密钥，不收集身份或支付信息。

## 默认交付流程

1. 确认出发地、目的地、交通方式、日期及必要筛选。相对日期按 `Asia/Shanghai` 换算；没给日期先询问，不能自行猜测。
2. 高铁使用 12306；机票使用本地隔离 HOME 的 FlyAI 免 Key 试用。失败不能当作无票；可提供网页入口但不能把链接当成已验证票价。
3. 保存查询适配器 JSON（其中上游航班记录不改写）、Markdown 和 HTML 到 `~/Downloads`。一键入口输出一个 JSON 对象，包含文件路径与发送状态。
4. 查询请求默认发邮件；明确说只查看/不发送时加 `--no-send`。收件人优先级：`--to-email` > 进程变量 `TICKET_REPORT_TO` > `gc40800@gmail.com`。直接调用邮件脚本时用 `--to`。
5. 回复查询条数、在本次返回结果中的最快/最低价等结论、报告路径及实际发送状态。SMTP 接受邮件不等于用户已经收到或阅读。

```bash
python3 <skill-dir>/scripts/travel_report.py \
  --mode flight --from "南阳" --to "厦门" --date YYYY-MM-DD

python3 <skill-dir>/scripts/travel_report.py \
  --mode train --from "南阳" --to "重庆" --date YYYY-MM-DD --kind G
```

`YYYY-MM-DD` 必须替换为实际未来日期。仅生成报告加 `--no-send`；`--send` 与 `--no-send` 互斥。用 `--output-dir` 指定目录，`--slug` 指定文件名。默认文件名包含航线及筛选条件的哈希，避免不同中文航线互相覆盖。显式重复使用同一个 slug 会覆盖之前的报告。

查询成功但结果为空时也生成报告，说明没有满足本次条件的方案；上游错误则停止。邮件失败时保留已生成文件并返回非零状态。

## 高铁直达与中转

```bash
python3 <skill-dir>/scripts/train_query.py \
  --from "北京南" --to "上海虹桥" --date YYYY-MM-DD \
  --kind G --limit 10 --format json
```

- 城市名、具体车站名或 12306 三字码均可。城市查询可能返回多个实际车站，报告必须使用实际车站名称。
- `--kind G` 包含 G/C；`--kind D` 查询动车；不传则所有车次类型。
- `--limit` 只截断最终结果；直接查询脚本可用 `--limit 0` 返回全部。
- 车站数据缓存 24 小时、接口路径缓存 1 小时；`--refresh-cache` 强制刷新。票价和余票不作为实时库存缓存使用。
- 网络/临时响应有有限重试；HTML 错误页或失败 JSON 不能被视为无票。

一次同站换乘的一键查询、报告和邮件：

```bash
python3 <skill-dir>/scripts/travel_report.py \
  --mode train --from "北京南" --to "上海虹桥" --date YYYY-MM-DD \
  --kind G --transfers --transfer-stations "南京南" \
  --min-transfer-minutes 30 --max-transfer-minutes 240 \
  --max-total-minutes 1440 --transfer-limit 10 --no-send
```

- `--transfers`：最多一次换乘；`--max-transfers` 当前仅接受 1。不支持跨站交通或任意多段全网路由。
- `--transfer-stations`：逗号分隔，最多 6 个候选；推荐明确具体车站。未传时只尝试郑州东、武汉、西安北、南京南四个枢纽，不是穷举全国的最优路线。
- 只组合两段实际发到站代码相同的换乘，拒绝同车次、回到起点、等待过短/长和总历时超限。
- 默认等待 30–360 分钟、总历时不超过 1440 分钟；可配置等待范围 1–720 分钟、总历时上限 2880 分钟。这些是筛选阈值，不保证站内实际换乘可行。
- 使用查询的上车日期，不把列车始发服务日期误当作上车日期；根据到达/等待窗口查询后续日期，支持跨午夜衔接。
- 分段查询不提前按 `--limit` 截断；`--transfer-limit` 控制最终中转数量。查询结果按总历时排序。
- JSON：`results` 为中转方案，`direct_results` 保留先查到的直达结果。每个方案含 `legs`、`departure_datetime`、`arrival_datetime`、`transfer_station`、`transfer_wait_minutes`、`total_duration`。
- 同类座席价格可分段相加；两段状态分别保留，不能把合计当作可一次购买的联程票。报告显示实际日期、换乘等待、分段价格和余票。

## 机票：筛选、航空公司、换乘与规则

```bash
node <skill-dir>/scripts/flight_query.cjs \
  --from "北京" --to "上海" --date YYYY-MM-DD \
  --direct-only --prefer-airline "MU,CZ" --sort price --limit 10 --json
```

也接受机场三字码，例如 `--origin PEK --destination SHA`。筛选只作用于 FlyAI 试用返回的记录；试用结果可能受限，不能宣称全市场最低价或已穷举。

一键入口和监测入口支持相同筛选：

```text
--direct-only                      非经停、非中转
--max-stops 1                      最多中转/已知经停次数
--max-transfer-minutes 240          总换乘等待上限
--avoid-overnight                  排除跨日到达或日期未知的记录
--departure-after 08:00
--arrival-before 23:00
--sort price|duration|arrival|departure
--prefer-airline "MU,CZ"            可重复或逗号分隔；--airline 为查询脚本别名
--same-airport-only                换乘须已确认同机场
--same-terminal-only               换乘须已确认同机场且同航站楼
--min-connection-minutes 90         每次换乘的用户指定等待下限
```

航空公司筛选为严格保留：任一航段的**营销航空公司**名称/代码匹配指定列表即可；不是实际承运公司保证。支持上游 `marketingTransportName`，以及从显式航班编号提取营销 IATA 代码。没有任何可匹配字段时不会假定匹配。

机场/航站楼判断用上游实际代码、名称和 `arrTerm`/`depTerm`。启用限制时未知连接信息不能假定满足；缺时间时不当作零等待。时间下限不是机场官方 MCT，也不是误机保障。

报告尽量保留方案/行程/各航段的行李、退改签、税费和联程保障原始字段，并带作用范围和字段名；同时存在退票与改签规则、机场税与燃油附加费时不只取第一个。上游没给时显示“未提供”。不得由多段行程推断有行李直挂、联程保障或含税总价。

机票查询使用 `@fly-ai/flyai-cli@1.0.16`，只调用 `search-flight`，清除 FlyAI 密钥变量并隔离 HOME，不误用用户授权。认证、额度或网络失败时可生成备用入口：

```bash
python3 <skill-dir>/scripts/flight_links.py \
  --from "北京" --to "上海" --date YYYY-MM-DD
```

入口指向百度、Google Flights、携程和去哪儿。必须打开页面核对实际票价与规则，不能直接拿链接当报价。

## 报告与邮件

```bash
python3 <skill-dir>/scripts/render_report.py \
  --input ~/Downloads/query-result.json --output-dir ~/Downloads --slug ticket-report

node <skill-dir>/scripts/send_report.cjs \
  --html ~/Downloads/ticket-report.html --text ~/Downloads/ticket-report.md \
  --subject "票务查询报告" --retries 2 --retry-delay-ms 1000
```

- 默认最多 2 次重试（总共 3 次），`--retries` 接受 0–4，指数退避。
- 只重试有明确临时失败证据且安全的情形，如 SMTP 4xx 或连接阶段临时错误。认证失败不盲目重试；提交后断线/超时可能已送达，记为 `unknown`，需人工核对再发送。
- 记录默认保存在 `<html路径>.send-status.json`，可用 `--status-file` 指定。记录包含状态、尝试、时间、message ID；权限 600，不保存 SMTP 主机、用户名、密码或自由文本服务器响应。
- 一键入口也接受 `--retries`、`--retry-delay-ms`、`--status-file`。
- SMTP 凭据**仅**由相邻 `smtp-email` 技能读取 `~/.config/omnirush/.env`。不会从进程 SMTP 变量或 `config.json` 回退，也不把凭据写入命令行。旧 `setup` 已禁用，以免覆盖其他配置。

## 票价/余票变化监测

```bash
python3 <skill-dir>/scripts/watch_tickets.py \
  --mode flight --from "北京" --to "上海" --date YYYY-MM-DD \
  --direct-only --sort price --send-on-change
```

监测高铁可换为 `--mode train`，支持前述中转参数。没有 `--send-on-change` 时只保存本地报告，不发邮件。

- 每次命令只查询一次，不常驻后台，也不自动安装 cron/systemd 任务。
- 默认状态在 `~/.cache/omnirush/china-travel-tickets/watch/`；`--state` 可指定。航线、日期、筛选不同使用不同状态键；显式状态文件不可混用不同查询。
- 首次运行生成基线报告；班次、票价、余票或连接变化时再报告。忽略查询时间、结果顺序和临时购票链接。变成空结果也会通知。
- 启用邮件后首次也通知，之后只通知变化；确定失败的邮件下次运行可补发。投递不确定或发送中进程崩溃时停止自动重发，先核对状态记录和收件箱，再选择新的状态文件恢复。
- 查询失败不覆盖旧快照；原子保存、600 权限和文件锁防止并发同一状态文件。比较范围只限本次返回的结果，不是全网监控。
- 实际启用定时任务前，先确认用户航线、日期、查询频率和收件人；建议不短于 30 分钟，避免额度/限流。不要把 SMTP 凭据放进 crontab。

示意 cron（须替换路径和日期并由用户确认安装；不自动安装）：

```cron
*/30 * * * * /usr/bin/python3 /absolute/skill-dir/scripts/watch_tickets.py --mode train --from 北京南 --to 上海虹桥 --date YYYY-MM-DD --send-on-change
```

## 验证与边界

```bash
cd <skill-dir>
npm test
python3 -m unittest discover -s tests -v
```

测试用离线夹具和模拟 SMTP，不发送真实邮件。实际外部接口可能限流、变更或要求认证。购票前务必到官方平台核对日期、实际车站/机场、换乘距离、票价、税费、行李及退改规则。任何缓存、查询结果或推荐都不是锁价、锁票或购票保障。
