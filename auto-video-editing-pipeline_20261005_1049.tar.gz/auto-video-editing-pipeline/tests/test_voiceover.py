"""Offline voiceover contract tests: never contact a real TTS service."""
import array
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
import wave
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts import voiceover
from scripts.srt_utils import read_cues


class ScriptValidationTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.script = self.root / "script.json"
        self.output = self.root / "output"
        patcher = mock.patch.object(
            voiceover, "_synthesize", side_effect=AssertionError("network synthesis forbidden")
        )
        self.synthesis = patcher.start()
        self.addCleanup(patcher.stop)

    def write_script(self, document):
        self.script.write_text(json.dumps(document), encoding="utf-8")

    def test_reject_invalid_envelopes_and_lines_before_synthesis(self):
        good = {"text": "hello", "start": 0.5, "end": 2.0}
        invalid = [
            [], None, {}, {"lines": []}, {"lines": "hello"},
            {"lines": [good], "videos": {}}, {"line": [good]},
            {"videos": {}}, {"videos": []}, {"videos": {"other-id": {"lines": [good]}}},
            {"videos": {"video-id": []}},
            {"videos": {"video-id": {"lines": [good], "unknown": 1}}},
            {"lines": [None]}, {"lines": [{"text": "hello", "start": 0.5}]},
            {"lines": [{**good, "unknown": True}]},
            {"lines": [{**good, "text": "  "}]}, {"lines": [{**good, "text": 3}]},
            {"lines": [{**good, "text": "first\nsecond"}]},
            {"lines": [{**good, "text": "hello\x00"}]},
        ]
        for document in invalid:
            with self.subTest(document=document):
                self.write_script(document)
                with self.assertRaises(ValueError):
                    voiceover.prepare_voiceover(self.script, "video-id", self.output, 3)
        self.synthesis.assert_not_called()
        self.assertFalse(self.output.exists())

    def test_reject_invalid_nonfinite_bool_and_out_of_bounds_times(self):
        good = {"text": "hello", "start": 0.5, "end": 2.0}
        invalid = [
            {"start": -0.1}, {"start": 2.0}, {"start": 2.1}, {"end": 3.01},
            {"end": 0.0}, {"start": "0.5"}, {"end": "2.0"},
            {"start": True}, {"end": False}, {"start": None},
            {"start": float("nan")}, {"end": float("inf")}, {"start": -float("inf")},
            {"start": 10 ** 500},
        ]
        for replacement in invalid:
            with self.subTest(replacement=replacement):
                self.write_script({"lines": [{**good, **replacement}]})
                with self.assertRaises(ValueError):
                    voiceover.prepare_voiceover(self.script, "video-id", self.output, 3)
        self.synthesis.assert_not_called()

    def test_reject_overlap_even_if_audio_could_be_shorter(self):
        self.write_script({"lines": [
            {"text": "later", "start": 1.0, "end": 2.0},
            {"text": "earlier", "start": 0.5, "end": 1.1},
        ]})
        with self.assertRaisesRegex(ValueError, "overlap"):
            voiceover.prepare_voiceover(self.script, "video-id", self.output, 3)
        self.synthesis.assert_not_called()

    def test_malformed_and_duplicate_json_are_errors(self):
        for text in (
            "{not-json}",
            '{"lines": [], "lines": []}',
            '{"videos": {"video-id": {"lines": []}, "video-id": {"lines": []}}}',
        ):
            with self.subTest(text=text):
                self.script.write_text(text, encoding="utf-8")
                with self.assertRaises(ValueError):
                    voiceover.prepare_voiceover(self.script, "video-id", self.output, 3)
        self.synthesis.assert_not_called()

    def test_explicit_path_required_and_missing_file_fails(self):
        for path in (None, self.root / "missing.json"):
            with self.subTest(path=path), self.assertRaisesRegex(ValueError, "script"):
                voiceover.prepare_voiceover(path, "video-id", self.output, 3)
        self.synthesis.assert_not_called()

    def test_invalid_duration_and_configuration_do_not_synthesize(self):
        self.write_script({"lines": [{"text": "hello", "start": 0.5, "end": 2.0}]})
        for duration in (0, -1, True, "3", float("nan"), float("inf"), 1e308):
            with self.subTest(duration=duration), self.assertRaises(ValueError):
                voiceover.prepare_voiceover(self.script, "video-id", self.output, duration)
        for options in (
            {"voice": ""}, {"voice": "bad voice"}, {"voice": "invalid\x00voice"},
            {"rate": "fast"}, {"rate": "10%"},
            {"volume": "+inf%"}, {"duck_db": float("nan")}, {"duck_db": 1},
        ):
            with self.subTest(options=options), self.assertRaises(ValueError):
                voiceover.prepare_voiceover(self.script, "video-id", self.output, 3, **options)
        for video_id in ("", " ", None):
            with self.subTest(video_id=video_id), self.assertRaises(ValueError):
                voiceover.prepare_voiceover(self.script, video_id, self.output, 3)
        self.synthesis.assert_not_called()

    def test_audio_tools_are_required_before_synthesis(self):
        self.write_script({"lines": [{"text": "hello", "start": 0.5, "end": 2.0}]})
        with mock.patch.object(voiceover.shutil, "which", return_value=None):
            with self.assertRaisesRegex(RuntimeError, "ffprobe"):
                voiceover.prepare_voiceover(self.script, "video-id", self.output, 3)
        self.synthesis.assert_not_called()


class EdgeCLIContractTests(unittest.TestCase):
    def test_installed_cli_subprocess_forces_edge_and_disables_ai_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            cli = root / "tts.py"
            cli.write_text("# installed CLI stand-in, never executed\n")
            text = "Do not turn this into semantic segments. " * 100
            observed = {}

            def inspect(command, **kwargs):
                observed["command"] = command
                source = next(arg.split("=", 1)[1] for arg in command if arg.startswith("--file="))
                observed["text"] = Path(source).read_text(encoding="utf-8")
                keyword_file = next(arg.split("=", 1)[1] for arg in command if arg.startswith("--highlight-keyword-file="))
                observed["keyword_file"] = Path(keyword_file).read_text(encoding="utf-8")
                self.assertEqual(kwargs, {})
                return subprocess.CompletedProcess(command, 0, "", "")

            with mock.patch.object(voiceover, "EDGE_TTS_SCRIPT", cli), mock.patch.object(voiceover, "_run", side_effect=inspect):
                voiceover._synthesize(text, root / "speech.mp3", voice="zh-CN-YunxiNeural", rate="-10%", volume="+5%")
            command = observed["command"]
            self.assertEqual(command[:2], [sys.executable, str(cli)])
            self.assertIn("--provider=edge", command)
            self.assertIn("--rate=-10%", command)
            self.assertIn("--volume=+5%", command)
            self.assertIn("--punctuation-mode=keep", command)
            self.assertIn("--pron-fix-mode=normal", command)
            self.assertIn(f"--max-chars={len(text) + 1}", command)
            self.assertEqual(observed["text"], text)
            self.assertTrue(observed["keyword_file"].startswith("#"))
            self.assertNotIn(text, command)
            self.assertTrue(all(flag not in command for flag in ("--semantic", "--split", "--srt", "--ass")))

    def test_subprocess_failure_does_not_echo_private_script(self):
        result = subprocess.CompletedProcess([sys.executable], 1, "secret text", "secret text")
        with mock.patch.object(voiceover.subprocess, "run", return_value=result):
            with self.assertRaises(RuntimeError) as raised:
                voiceover._run([sys.executable, "installed-tts.py"])
        self.assertNotIn("secret text", str(raised.exception))

    def test_probe_rejects_nonfinite_duration_and_missing_audio(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "audio.mp3"
            path.write_bytes(b"non-empty fixture")
            for info in (
                {"streams": [], "format": {"duration": "1.0"}},
                {"streams": [{"codec_type": "audio", "duration": "nan"}]},
                {"streams": [{"codec_type": "audio", "duration": "inf"}]},
                {"streams": [{"codec_type": "audio", "duration": "0"}]},
            ):
                result = subprocess.CompletedProcess([], 0, json.dumps(info), "")
                with self.subTest(info=info), mock.patch.object(voiceover, "_run", return_value=result):
                    with self.assertRaises(ValueError):
                        voiceover._probe_audio(path)


@unittest.skipUnless(shutil.which("ffmpeg") and shutil.which("ffprobe"), "requires FFmpeg/FFprobe")
class VoiceoverTimelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixtures_dir = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.fixtures_dir.cleanup)
        root = Path(cls.fixtures_dir.name)
        cls.fixtures = {}
        for name, duration, frequency in (("short", 0.4, 440), ("second", 0.7, 880), ("long", 1.5, 660)):
            path = root / f"{name}.mp3"
            subprocess.run([
                "ffmpeg", "-nostdin", "-v", "error", "-y", "-f", "lavfi", "-i",
                f"sine=frequency={frequency}:sample_rate=24000:duration={duration}",
                "-ac", "1", "-c:a", "libmp3lame", "-q:a", "2", str(path),
            ], check=True, capture_output=True)
            cls.fixtures[name] = path

    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.output = self.root / "output"
        self.script = self.root / "script.json"
        self.lines = [
            {"text": "first", "start": 0.5, "end": 1.3},
            {"text": "second", "start": 2.0, "end": 2.9},
        ]
        self.write_script()

        def synthetic_synthesis(text, output, **config):
            fixture = self.fixtures.get(text, self.fixtures["short"])
            shutil.copyfile(fixture, output)

        patcher = mock.patch.object(voiceover, "_synthesize", side_effect=synthetic_synthesis)
        self.synthesis = patcher.start()
        self.addCleanup(patcher.stop)

    def write_script(self, document=None):
        self.script.write_text(json.dumps(document if document is not None else {"lines": self.lines}), encoding="utf-8")

    def prepare(self, **options):
        duration = options.pop("duration", 4.0)
        return voiceover.prepare_voiceover(self.script, "video-id", self.output, duration, **options)

    def manifest(self):
        return json.loads((self.output / "voiceover_manifest.json").read_text(encoding="utf-8"))

    def test_real_ffmpeg_full_timeline_audio_silence_and_full_line_captions(self):
        result = self.prepare()
        self.assertEqual(set(result), {"audio_path", "captions_path", "manifest_path", "intervals", "duck_db", "duration"})
        self.assertEqual(result["duck_db"], -12)
        self.assertEqual(result["duration"], 4)
        self.assertTrue(all(Path(result[key]).is_absolute() for key in ("audio_path", "captions_path", "manifest_path")))
        with wave.open(result["audio_path"], "rb") as audio:
            self.assertEqual((audio.getnchannels(), audio.getsampwidth(), audio.getframerate()), (2, 2, 48000))
            self.assertEqual(audio.getnframes(), 192000)
            samples = array.array("h", audio.readframes(audio.getnframes()))
        if sys.byteorder != "little":
            samples.byteswap()

        def peak(start, end):
            return max(abs(sample) for sample in samples[round(start * 48000) * 2:round(end * 48000) * 2])

        self.assertEqual(peak(0, 0.49), 0)
        self.assertGreater(peak(0.6, 0.8), 100)
        self.assertEqual(peak(1.0, 1.9), 0)
        self.assertGreater(peak(2.1, 2.4), 100)
        self.assertEqual(peak(2.8, 4.0), 0)
        cues = read_cues(Path(result["captions_path"]))
        self.assertEqual([cue[2] for cue in cues], [["first"], ["second"]])
        for cue, interval, line in zip(cues, result["intervals"], self.lines):
            self.assertAlmostEqual(cue[0], line["start"], delta=0.001)
            self.assertLessEqual(cue[1], interval["end"] + 1e-9)
            self.assertLess(cue[1], line["end"])
            self.assertAlmostEqual(cue[1], interval["end"], delta=0.001)
        self.assertAlmostEqual(result["intervals"][0]["end"], 0.9, delta=0.001)
        self.assertAlmostEqual(result["intervals"][1]["end"], 2.7, delta=0.001)
        manifest = self.manifest()
        self.assertIn("cloud", manifest["engine"]["privacy_note"])
        self.assertIn("No video", manifest["engine"]["privacy_note"])
        self.assertFalse(manifest["engine"]["ai_features"])
        self.assertEqual(manifest["config"]["voice"], "zh-CN-YunxiNeural")
        for row in manifest["lines"]:
            self.assertEqual(row["audio_sha256"], voiceover._sha256(Path(row["audio_path"])))
            self.assertEqual(Path(row["audio_path"]).read_bytes(), Path(row["cache_path"]).read_bytes())
            self.assertEqual(row["start_frame"] / 48000, row["placed_start"])

    def test_unchanged_valid_lines_never_resynthesize_and_are_fully_decoded(self):
        self.prepare()
        self.synthesis.reset_mock()
        with mock.patch.object(voiceover, "_decode_audio", wraps=voiceover._decode_audio) as decode:
            self.prepare()
        self.synthesis.assert_not_called()
        self.assertEqual(decode.call_count, 2)
        self.assertTrue(all(row["cache_hit"] for row in self.manifest()["lines"]))

    def test_changed_line_only_invalidates_its_cache(self):
        self.prepare()
        old_keys = [row["cache_key"] for row in self.manifest()["lines"]]
        self.lines[0]["text"] = "changed first"
        self.write_script()
        self.synthesis.reset_mock()
        self.prepare()
        self.assertEqual(self.synthesis.call_count, 1)
        rows = self.manifest()["lines"]
        self.assertNotEqual(rows[0]["cache_key"], old_keys[0])
        self.assertEqual(rows[1]["cache_key"], old_keys[1])
        self.assertTrue(rows[1]["cache_hit"])

    def test_voice_rate_and_volume_invalidate_content_cache(self):
        self.prepare()
        original = [row["cache_key"] for row in self.manifest()["lines"]]
        for config in ({"voice": "en-US-GuyNeural"}, {"rate": "+20%"}, {"volume": "-10%"}):
            with self.subTest(config=config):
                self.synthesis.reset_mock()
                self.prepare(**config)
                self.assertEqual(self.synthesis.call_count, 2)
                self.assertTrue(all(row["cache_key"] != key for row, key in zip(self.manifest()["lines"], original)))
        self.synthesis.reset_mock()
        self.prepare()
        self.synthesis.assert_not_called()

    def test_offsets_duration_and_ducking_reuse_synthesis(self):
        self.prepare()
        self.lines[0].update(start=0.0, end=0.9)
        self.lines[1].update(start=1.2, end=2.1)
        self.write_script()
        self.synthesis.reset_mock()
        result = self.prepare(duration=3.0, duck_db=-6.0)
        self.synthesis.assert_not_called()
        self.assertEqual(result["intervals"][0]["start"], 0)
        self.assertEqual(result["intervals"][1]["start"], 1.2)
        self.assertEqual((result["duck_db"], result["duration"]), (-6, 3))

    def test_corrupt_cache_hash_is_not_trusted_even_for_decodable_audio(self):
        self.prepare()
        bad_cache = Path(self.manifest()["lines"][0]["cache_path"])
        shutil.copyfile(self.fixtures["second"], bad_cache)  # valid audio, wrong hash
        self.synthesis.reset_mock()
        self.prepare()
        self.assertEqual(self.synthesis.call_count, 1)
        self.assertFalse(self.manifest()["lines"][0]["cache_hit"])
        self.assertTrue(self.manifest()["lines"][1]["cache_hit"])

    def test_corrupt_cache_with_matching_hash_must_still_decode(self):
        self.prepare()
        row = self.manifest()["lines"][0]
        bad_cache = Path(row["cache_path"])
        bad_cache.write_bytes(b"not audio")
        meta_path = bad_cache.with_suffix(".json")
        metadata = json.loads(meta_path.read_text())
        metadata["audio_sha256"] = voiceover._sha256(bad_cache)
        meta_path.write_text(json.dumps(metadata))
        self.synthesis.reset_mock()
        self.prepare()
        self.assertEqual(self.synthesis.call_count, 1)

    def test_failed_full_decode_regenerates_only_that_cache(self):
        self.prepare()
        bad_cache = Path(self.manifest()["lines"][0]["cache_path"])
        decode = voiceover._decode_audio

        def fail_one(path, pcm):
            if path == bad_cache:
                raise RuntimeError("synthetic decoder failure after successful probe")
            return decode(path, pcm)

        self.synthesis.reset_mock()
        with mock.patch.object(voiceover, "_decode_audio", side_effect=fail_one):
            self.prepare()
        self.assertEqual(self.synthesis.call_count, 1)

    def test_corrupt_cache_metadata_regenerates_line(self):
        self.prepare()
        cache = Path(self.manifest()["lines"][0]["cache_path"])
        cache.with_suffix(".json").write_text("{broken-json")
        self.synthesis.reset_mock()
        self.prepare()
        self.assertEqual(self.synthesis.call_count, 1)

    def test_overflow_is_actionable_not_truncated_and_widening_reuses_cache(self):
        self.lines = [{"text": "long", "start": 0.5, "end": 1.0}]
        self.write_script()
        with self.assertRaisesRegex(ValueError, "line 1.*Shorten.*not truncated or compressed"):
            self.prepare()
        self.assertFalse((self.output / "voiceover.wav").exists())
        self.assertFalse((self.output / "voiceover_manifest.json").exists())
        self.lines[0]["end"] = 2.5
        self.write_script()
        self.synthesis.reset_mock()
        result = self.prepare()
        self.synthesis.assert_not_called()
        self.assertAlmostEqual(result["intervals"][0]["end"], 2.0, delta=0.001)

    def test_batch_key_selects_only_requested_id_and_unsorted_lines_keep_names(self):
        self.write_script({"videos": {
            "other-id": {"lines": [{"text": "must not synthesize", "start": 0.0, "end": 1.0}]},
            "video-id": {"lines": list(reversed(self.lines))},
        }})
        result = self.prepare()
        self.assertEqual([call.args[0] for call in self.synthesis.call_args_list], ["first", "second"])
        rows = self.manifest()["lines"]
        self.assertEqual([row["audio_name"] for row in rows], ["voiceover_002.mp3", "voiceover_001.mp3"])
        self.assertEqual(result["intervals"][0]["start"], 0.5)

    def test_duplicate_text_different_offsets_reuses_one_content_entry(self):
        self.lines[1]["text"] = "first"
        self.write_script()
        self.prepare()
        self.assertEqual(self.synthesis.call_count, 1)
        rows = self.manifest()["lines"]
        self.assertEqual(rows[0]["cache_key"], rows[1]["cache_key"])

    def test_synthesis_exit_zero_without_valid_audio_is_failure(self):
        self.synthesis.side_effect = None
        self.synthesis.return_value = None
        with self.assertRaisesRegex(ValueError, "missing or empty"):
            self.prepare()
        self.assertFalse((self.output / "voiceover_manifest.json").exists())

    def test_many_lines_assembly_does_not_build_a_giant_ffmpeg_command(self):
        self.lines = [{"text": "first", "start": index * 0.5, "end": index * 0.5 + 0.5} for index in range(10)]
        self.write_script()
        with mock.patch.object(voiceover, "_run", wraps=voiceover._run) as commands:
            result = self.prepare(duration=5)
        self.assertEqual(self.synthesis.call_count, 1)
        self.assertEqual(len(result["intervals"]), 10)
        self.assertTrue(all(len(call.args[0]) < 40 for call in commands.call_args_list))
        self.assertTrue(all("-filter_complex" not in call.args[0] for call in commands.call_args_list))


if __name__ == "__main__":
    unittest.main()
