---
name: cf-pages-deploy
description: 批量将指定目录中的静态 HTML（单文件或整个目录）部署到 Cloudflare Pages。配置驱动、状态持久化、内容哈希跳过未变更站点、可断点重试、支持并行部署和 dry-run 预检，凭证读取 ~/.config/freebuff/.env 的 CF_ACCOUNT_ID / CF_API_TOKEN。
compatibility: Python 3.10+；需要当前环境已有 requests 和 PyYAML；部署需要 wrangler CLI（npm i -g wrangler，v4+）或 npx。不会自动安装依赖或访问除 api.cloudflare.com 之外的网络。
allowed-tools: read write edit bash
permissions:
  - file_write
---

# 批量部署 HTML 到 Cloudflare Pages

安装目录：`~/.config/freebuff/skills/cf-pages-deploy/`。

基于用户提供的 `/tmp/deploy`（`cf_factory.py`、`workers/workers_factory.py`、`cf_voyage.yaml`）改造，聚焦「把一个或多个目录/单文件里的静态 HTML 发布到 Cloudflare Pages」这一目标；原脚本只读未改，SHA-256 见 `references/source-hashes.json`。

## 依赖与凭证

- 运行环境：Python 3.10+、`requests`、`PyYAML`、`wrangler`（v4+，或 `npx wrangler`）。
- 凭证默认从 `~/.config/freebuff/.env` 读取：

  ```ini
  CF_ACCOUNT_ID=xxxxxxxx
  CF_API_TOKEN=xxxxxxxx
  ```

  也接受 `CLOUDFLARE_ACCOUNT_ID` / `CLOUDFLARE_API_TOKEN`。真实环境变量优先于文件；`--env-file` 可追加额外文件。令牌只写入子进程环境，从不打印。

## 快速开始

```bash
CFD="$HOME/.config/freebuff/skills/cf-pages-deploy/scripts/cf_pages_deploy.py"

# 1) 从一个「每个子目录一个站点」的父目录自动生成配置
python3 "$CFD" discover --root ~/Downloads/sites --output cf.yaml

# 2) 预检（不联网、不写文件、不建项目）
python3 "$CFD" deploy --config cf.yaml --dry-run

# 3) 批量部署
python3 "$CFD" deploy --config cf.yaml

# 4) 只部署某个项目 / 重跑失败项
python3 "$CFD" deploy --config cf.yaml --only voyage
python3 "$CFD" deploy --config cf.yaml --retry-failed

# 单目录临时部署，不用配置文件
python3 "$CFD" deploy --dir ./site --project-name my-site --branch main

# 列出账户下的 Pages 项目
python3 "$CFD" list
```

## 三种输入方式（选其一）

| 方式 | 参数 | 说明 |
|---|---|---|
| 配置文件 | `--config cf.yaml` | 一次部署多个命名项目（推荐、可断点续传） |
| 父目录发现 | `--discover-root DIR` | 把 DIR 下含 HTML 的一级子目录各部署为一个项目（项目名=目录名小写化） |
| 单目标 | `--dir PATH --project-name NAME` | 部署一个目录或单个 `.html` 文件 |

配置文件中的 `source_dir` 相对配置文件所在目录解析；`--discover-root` / `--dir` 相对当前工作目录。

## 配置格式

```yaml
pages:
  voyage:                       # 项目名（= Cloudflare Pages 项目名，小写字母/数字/连字符）
    source_dir: "../tsui0086/voyage"   # 目录，或单个 .html 文件
    branch: "main"              # main=生产；其它分支=预览，不影响生产
    create_if_missing: true      # 项目不存在时自动创建
    # commit_message: "..."      # 可选，附加到部署
    # skip_caching: true         # 可选，跳过资源缓存以加速上传
```

完整示例见 `examples/cf_pages.example.yaml`。

## 行为

- **内容哈希跳过**：记录每个站点最近一次成功部署的内容 SHA-256 与分支；内容与分支都未变时标记 `skipped(unchanged)`，不再上传。`--force` 忽略此跳过。
- **断点续传**：`--retry-failed` 只处理状态不是成功的项目（成功项标记 `skipped(retry_failed_skip)`）。
- **并行**：`--jobs` 控制并发项目数（默认 `auto` = min(4, 项目数)，上限 8）。
- **重试**：API 与 wrangler 调用按指数回退重试（`--retries`，默认 3），429/5xx 会等待后重试；单个项目失败不影响整批。
- **dry-run**：只做文件系统校验与计划，不联网、不建项目、不写状态或报告。
- **原子状态**：状态文件（默认与配置文件同目录的 `.cf_pages_deploy_state.json`，可用 `--state` 指定）原子写入；`skipped` 不会把已有的成功记录降级。
- **报告**：`--json` 输出机器可读报告；`--report FILE` 另存 JSON。退出码：0=全部成功/计划完成，2=有失败，1=无法启动（配置/凭证/参数错误）。

## 安全与边界

- 只从用户明确指定的目录/配置读取内容，不扫描 Downloads 或家目录。
- 不打印、不落盘 API Token；只注入 wrangler 子进程环境。
- 不访问除 `api.cloudflare.com`（创建/查询项目）与 wrangler 上传端点之外的网络。
- 不自动安装依赖、不 `wrangler login`、不删除项目或 Worker。
- 部署/创建项目是外部动作：`--dry-run` 可先预检；生产分支谨慎操作。

## 输出结构

```text
cf.yaml
.cf_pages_deploy_state.json     # 状态（可 --state 改路径）
logs/…                          # 仅在使用 --log-file 时
```

参考文档：

- `references/formats.md`：CLI、配置、状态与报告字段、退出码。
- `references/implementation.md`：架构、哈希、跳过策略、并行与安全边界。
- `references/verification.md`：测试与验证结果。
