# 配置参考

## 配置和密钥的位置

- 默认 JSON：`../config.json`（技能根目录），由 `--config` 或 `OMNIRUSH_NOTIFY_CONFIG` 覆盖。
- 默认密钥：`~/.config/omnirush/.env`，由 `--env-file` 或 `OMNIRUSH_NOTIFY_ENV_FILE` 覆盖。
- 优先级：**当前进程环境变量 > .env**。进程变量若为空，视为配置错误，不回退到文件。
- 仅解析本次选中渠道中 `${NAME}` 引用的环境变量。未选择或禁用的渠道不要求提供密钥。
- 不执行 shell，不做命令替换、环境变量二次展开或递归模板求值。`.env` 不需要也不应该 `source`。
- 支持 `NAME=value`、`export NAME=value`、单引号原样值、JSON 格式双引号字符串和行尾注释。双引号转义采用 JSON 规则；不支持跨物理行字符串。迁移器自动生成兼容格式。
- `.env`、实际 `config.json` 保持 `600`；技能根目录本次安装设为 `700`。不要将整个技能目录连同本地配置打包发布，`.gitignore` 不是安全边界。

例子仅含占位值（请在本地安全编辑器中替换，勿将真值粘贴到对话）：

```dotenv
OMNIRUSH_NOTIFY_TELEGRAM_BOT_TOKEN="REPLACE_WITH_BOT_TOKEN"
OMNIRUSH_NOTIFY_TELEGRAM_CHAT_ID="REPLACE_WITH_CHAT_ID"
OMNIRUSH_NOTIFY_BARK_DEVICE_KEY="REPLACE_WITH_DEVICE_KEY"
```

旧脚本配置的 `enabled`、`channels` 和六个原始渠道字段兼容；不静默吞掉损坏 JSON。`scripts/import_config.py` 把密钥、收件地址/ID 和可能带凭据的 URL/请求头转为变量引用，保留开关及其他配置。

## 顶层字段

```json
{
  "enabled": true,
  "workers": 4,
  "timeout": 10,
  "retries": 0,
  "message": {
    "title": "{{project}}：{{status}}",
    "content": "产物：{{artifact}}"
  },
  "channels": {
    "personal_telegram": {
      "type": "telegram",
      "enabled": true,
      "bot_token": "${OMNIRUSH_NOTIFY_TELEGRAM_BOT_TOKEN}",
      "chat_id": "${OMNIRUSH_NOTIFY_TELEGRAM_CHAT_ID}"
    },
    "bark": {
      "enabled": true,
      "url": "https://api.day.app",
      "device_key": "${OMNIRUSH_NOTIFY_BARK_DEVICE_KEY}",
      "options": {"group": "我的任务", "sound": "alarm"}
    }
  },
  "profiles": {"personal": ["personal_telegram", "bark"]}
}
```

| 字段 | 行为 |
|---|---|
| `enabled` | 总开关，必须为 JSON 布尔值；省略为 `false`，`--channels` 不绕过开关 |
| `workers` | 1–16，默认 4；独立渠道并发，输出按选择顺序排列 |
| `timeout` | 0.1–120 秒，默认 10；网络连接/读操作超时，**不是整个批次总时限** |
| `retries` | 0–3，默认 0；仅 HTTP 429/500/502/503/504，可按渠道覆盖；POST 重试可能重复通知 |
| `message` | 可选标题/正文模板；命令行对应字段优先 |
| `channels` | 实例名到配置的映射；实例名 1–64 个字母/数字/下划线/连字符 |
| `profiles` | 分组名到实例名数组的映射；不能引用不存在的渠道 |

每个实例有 `enabled`、可选 `type`、可选 `timeout` 和 `retries`。实例名等于内置类型时可省略 `type`；多个 Telegram/邮箱/Webhook 账号用不同实例名并指定同一个 `type`。

显式指定禁用渠道、未知渠道/分组、没有选中渠道（总开关开启时）会报错，而不是悄悄成功。`--skip` 可排除已知渠道。`--channels` 和 `--profile` 不可同时使用。

## 消息模板

- `{{name}}` 从 `--var name=value` 获取；缺失变量报错，不保留占位符。
- CLI `--title`、`--content` 和文件/标准输入正文都支持模板。
- 自定义变量仅由显式 `--var` 提供，**不会将系统环境变量注入正文**。
- Webhook 的 `payload` 支持嵌套对象/数组的字符串值模板，保留 JSON 类型和安全转义；不替换对象键。
- Webhook 内置 `{{title}}`、`{{content}}` 为最终消息，不能用 `--var` 覆盖；还可用其他 `--var`。
- 消息替换只执行一遍，变量值中的模板字符串不再解释。
- `.env` 引用属于渠道配置，不用于消息模板。不要把秘密注入通知正文。

## 渠道字段

### qq_email / smtp

必填 `user`、`password`、`recipients`。QQ 密码是 SMTP **授权码**，不是登录密码。

- `qq_email` 默认 `smtp.qq.com:465` + SSL。
- `smtp` 需要 `host`；默认 `security: "ssl"`、端口 465。
- 可设 `security: "starttls"`，默认端口 587；不支持明文认证或关闭证书校验。
- 可选 `from_name`（默认 OmniRush）、`from_email`（默认 user）、`port`。
- `recipients` 可以是字符串数组或逗号/中文逗号/分号/空白分隔的裸邮箱地址；去重。不建议带显示名。
- 邮件同时包含纯文本和 HTML，HTML 正文自动转义；标题、地址等阻止控制字符注入。
- SMTP 不自动重试，即使配置了 `retries`；部分收件人被拒绝会标记失败，可能已有其他收件人收到。

### bark

必填 `device_key` 或 `device_keys` 数组；`url` 默认 `https://api.day.app`（服务器根地址，自动追加 `/push`）。

`options` 可设 `sound`、`group`、`level`、`icon`、`url`（点击通知打开的链接）等。和原脚本不同，不强制使用固定图标/分组/声音。响应业务码必须为 `200`。

### wxpusher

必填 `token`、`uid` 或 `uids` 数组。默认发送到 `https://wxpusher.zjiecode.com/api/send/message`。

`options.contentType` 默认 `3`（Markdown），也可按服务 API 设为文本/HTML，其他选项如 `url`/`topicIds` 可直接放入 `options`；本实现仍要求 UID 收件人。可用 `endpoint` 指定兼容服务。检查顶层 `code=1000` 以及响应中各收件人项的 `code`，避免把部分失败当成全部成功。

### pushplus

必填 `token`。默认 `https://www.pushplus.plus/send`，与原片段相比已改用 HTTPS。

`options.template` 默认 `markdown`，可增加 `topic`、`channel` 等服务支持的字段。可选 `endpoint`。检查业务码 `200`；服务端排队成功不等于最终送达。

### resend

必填 `api_key`、`to_email`（字符串/数组，也可用 `recipients`）。`from_email` 默认 `onboarding@resend.dev`，生产使用通常必须设为账号已验证域名上的发件地址；测试域有收件人限制。

自动生成转义后的 HTML 和纯文本正文。`options` 可增加 `reply_to`、`cc`、`bcc` 等；请明确这些字段会扩大收件范围。可选 `endpoint`。HTTP 成功且响应含非空 `id` 才视为接受。

### telegram

必填 `bot_token`、`chat_id`（字符串或整数，包括负群组 ID）。默认 `https://api.telegram.org`；可设兼容 `api_base`。

标题与正文合并并 HTML 转义，固定 `parse_mode: "HTML"`，防止内容中的 `< > &` 破坏解析。`options` 可设 `disable_notification`、`message_thread_id`、`protect_content` 等。正文按 UTF-16 单元保守限制为 4096，不自动截断/拆分/群发。HTTP 成功还需 `ok: true`。

### webhook

仅支持 HTTPS JSON POST（无需为每个无签名 Webhook 新写适配器）；`http://localhost` 和回环 IP 只用于本地测试。

```json
{
  "type": "webhook",
  "enabled": true,
  "url": "${OMNIRUSH_NOTIFY_TEAM_HOOK_URL}",
  "headers": {"Authorization": "Bearer ${OMNIRUSH_NOTIFY_TEAM_HOOK_TOKEN}"},
  "payload": {
    "msgtype": "text",
    "text": {"content": "{{title}}\n{{content}}"}
  },
  "success": {"path": "errcode", "equals": 0}
}
```

- `payload` 默认 `{"title":"{{title}}","content":"{{content}}"}`。
- `headers` 可自定义；拒绝 Host/Content-Length/Transfer-Encoding 及换行注入。
- `success` 可选：从响应对象按点路径（如 `data.ok`）取值并按 JSON 类型比较。未配置时只判断 HTTP 2xx（包括空的 204），因此某些平台必须配置该字段。
- 支持静态 Token/请求头，不提供动态 HMAC/时间戳签名；开启签名验证的机器人需要额外适配，不能假称全部支持。
- 不支持表单/文件上传、任意 HTTP 方法或附件。

HTTP 渠道的 `options` 是额外的服务参数，核心标题、正文、凭据、主收件人字段具有优先权；高级选项本身可能改变行为，应查阅服务商文档。所有目的地只接受 HTTPS（本地回环测试除外），不跟随重定向，避免凭据泄漏到重定向目标。

## 性能、可靠性和隐私

- 一次解析配置，所有选中渠道完成请求构造/校验后再并发发送；一个网络失败不会阻断其他渠道。
- 单个渠道的失败不取消已成功请求，结果包含 `attempts`、`elapsed_ms`。
- `retries > 0` 时只对指定 HTTP 状态退避重试（带抖动）；数值型 `Retry-After` 被遵守，超过 30 秒则本次不重试。网络超时、SMTP、业务码失败不自动重试。
- 没有跨进程去重或 exactly-once 保证，不应承诺只送达一次。
- HTTP 和 SMTP 共用安全 TLS 上下文。若独立安装的 Python 默认 CA 存储为空，尝试加载系统 CA 文件（macOS `/etc/ssl/cert.pem` 等）；始终保留证书及主机名验证，不改变全局设置。显式 `SSL_CERT_FILE`/`SSL_CERT_DIR` 优先，不用其他信任源覆盖。证书验证失败会单独报告，不能通过关闭 TLS 校验来绕过。
- 服务响应最多读取 1 MiB，不记录原始响应/异常、请求 URL、正文、收件地址或密钥。
- `dry-run` 只检查本地配置与请求可构造性，不检查服务可达性、凭据真伪、余额、限流、最终投递。
- 并发的收益取决于网络等待和服务延迟；本地模拟测试只验证并发，不代表真实服务性能。

## 迁移和回滚

```bash
python3 scripts/import_config.py /path/to/old_notify.json \
  --config /path/to/skill/config.json --env-file ~/.config/omnirush/.env
```

- 目标已存在时需显式 `--replace-config`，目标不许等于源文件。
- 导入时使用文件锁保护 `.env` 追加；保留所有既有内容。同名不同值拒绝；同值重复导入不重复添加。
- 识别原六渠道的凭据/ID 字段，也处理自定义 Webhook 的 URL/请求头；如果你在任意其他自定义 `options`/`payload` 字段放密钥，需自行改为环境变量引用。
- JSON 用原子替换，权限 600；不建立新的明文备份，不移除源文件。目标写入失败时 `.env` 可能已添加变量，但源仍保留。
- 本次安装所用 `/tmp/.ebook_video_pipeline_notify.json` 保留不变，它仍含原始明文秘密。确认其他程序不再依赖后，由用户决定是否删除；不要擅自删除或覆盖。
