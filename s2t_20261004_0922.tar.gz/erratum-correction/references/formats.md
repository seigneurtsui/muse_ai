# Document-core format and validation contract

`scripts/document_core.py` is offline, standard-library-only Python 3.10+.
It never calls an AI service, accesses credentials, or writes documents.
The caller owns decoding/encoding, file safety, preview/approval, reporting,
transactional writes, and all current-session AI handoff.

## Public API

```python
from document_core import (
    DocumentError, TextSegment, HomophoneCorrector, contains_chinese,
    extract_segments, apply_segments, validate_replacement,
    extract_ai_error_terms,
)

segments = extract_segments(content, ".srt")
corrector = HomophoneCorrector(dictionary_path)
proposed = [corrector.correct(segment.text)[0] for segment in segments]
result = apply_segments(content, segments, proposed)
```

- `DocumentError.code` and `str(error)` contain only a fixed diagnostic code,
  not the document, dictionary rule, or filesystem path. Catch it at the file
  boundary: do not fall back to guessing a format or partially editing a file.
- `TextSegment(start, end, text, line=None)` is an immutable dataclass. Offsets
  are **Python string/code-point offsets**, not UTF-8 byte offsets. `line` is a
  one-based physical line number when extraction supplies it.
- `extract_segments(content, ext)` accepts the dotted extensions `.txt`, `.md`,
  `.markdown`, `.srt`, `.vtt`, `.ass`, `.ssa`, case-insensitively. Unknown
  extensions and NUL-containing documents fail. An empty plain/Markdown
  document is valid; an empty SRT/VTT document is not.
- `apply_segments(content, segments, new_texts)` requires exactly one replacement
  per segment. Segments must be nonempty, ascending, nonoverlapping, in bounds,
  and still match the original content. It validates every replacement and
  reconstructs with a forward join, **O(input + output size)** rather than
  repeated whole-document slicing. It does not sort, truncate mismatched lists,
  or accept stale offsets. An error yields no result, never a partial result.
- `validate_replacement(before, after)` returns `None` on success; otherwise it
  raises `DocumentError`. It rejects newlines (including Unicode line/paragraph
  separators), NUL, total deletion of nonempty text, changed leading/trailing
  whitespace, and changed ordered whitespace runs, controls, punctuation,
  symbols, tag/override tokens, entities, URLs, and backslash escapes. It is
  deliberately stricter than a general copy editor: punctuation-only edits can
  fail. It does **not** certify linguistic meaning, or parse a whole Markdown
  document. Always apply it to extracted segments via `apply_segments`, not
  arbitrary manually selected ranges that include link destinations or code.
- `HomophoneCorrector(path).pairs` is the ordered list of active `(wrong, right)`
  rules. `.correct(text)` returns `(corrected, hits)`;
  `.correct_with_details(text)` returns `(corrected, hits, [(wrong, right, count),
  ...])` in rule application order. Counts are nonoverlapping `str.count`
  occurrences in the text **at that step**. Earlier replacements can trigger
  later ones. No sorting, longest-match optimization, simultaneous replacement,
  fuzzy matching, or automatic ambiguous-rule filtering occurs. This low-level
  corrector alone does not validate document framing; use `apply_segments`.
- `contains_chinese(text)` retains the source tool's U+4E00–U+9FFF check. It is
  not a language detector and does not recognize all CJK extension blocks.
- `extract_ai_error_terms(before, after)` is a pure local diff, despite its
  historical name. It returns the original `SequenceMatcher(...,
  autojunk=False)` unequal opcodes as dictionaries with `before`, `after`,
  `type`, `before_start`, `before_end`, `after_start`, and `after_end`.
  It does not trim common prefixes or approximate alignment. Changed inputs
  fail with `diff_too_large` when the length product exceeds **4,000,000** or
  their combined length exceeds **100,000**, bounding pathological quadratic
  matching. Identical inputs return `[]` before these limits. The caller must
  handle an oversized diff explicitly, not silently omit a change report.

## Framing and text protection

Extraction never normalizes input. CRLF, LF, bare CR, mixed line endings, a
leading BOM, trailing spaces, blank lines, and presence/absence of a final
newline are retained by the join. Read/write without universal-newline
conversion if exact newline preservation is required.

Leading/trailing whitespace is **outside** each editable segment. A segment
never crosses a physical line, a protected tag, or an escape. Consequently a
correction rule spanning a tag or another protected boundary does not match.
Ordinary internal spaces remain in the segment and validation preserves their
ordered runs; controls (including tabs and zero-width format characters) are
outside segments. No Unicode normalization is performed.

Across text formats, complete angle-bracket tags (including quoted attribute
values), `{...}` override-like tokens, ASCII named/numeric entities, `-->`,
backslash escapes, HTML comments, and simple `http(s)://`/`mailto:` URLs are
protected. Unterminated comments protect the remainder of their parsed region.
This intentionally can skip literal text resembling markup. It is not an HTML
validator, and an unrecognized/malformed tag is not repaired.

## TXT

Nonblank visible line fragments are editable. There is no subtitle-style
filtering of numeric lines or lines containing `-->`.

## SRT

Each blank-line-delimited cue must contain:

1. An ASCII numeric cue index (surrounding spaces/tabs are retained).
2. A timing line `HH:MM:SS,mmm --> HH:MM:SS,mmm`.
3. At least one nonblank payload line.

Hours have 2–9 digits; minutes/seconds are 00–59; milliseconds have exactly
three digits. Spaces/tabs must surround the arrow. End time must exceed start
time. Cue indexes need not be consecutive and cues may overlap. Proprietary
coordinate suffixes, dot-decimal SRT timestamps, and missing indexes are not
supported; convert separately rather than relying on guessing.

Only payload text is editable. **Numeric dialogue is retained**, as is ordinary
dialogue containing `-->`. A payload line that is itself a complete timing
line is rejected as ambiguous (`subtitle_missing_separator`), because it
usually indicates a missing cue separator. Indices, timings, tags, and
whitespace remain untouched.

## WebVTT

The first physical line (after an optional BOM) must be `WEBVTT`, optionally
followed by a space/tab and header text. Header metadata is preserved through
the first blank line; a timing arrow in that header block is rejected.
A header-only VTT file is valid.

Blank-line-delimited `NOTE` blocks (including `NOTE text`), `STYLE`, and `REGION`
blocks are opaque and never corrected. Their placement, CSS, and internal
metadata are not validated. Cues may have an optional identifier, then a timing
line, then at least one nonblank payload line. Numeric identifiers and numeric
**payload** are distinguished by position, not a numeric-line heuristic.

Timestamps use `MM:SS.mmm` or `HH:MM:SS.mmm` (2–9 hour digits, the same range and
order checks as SRT). Supported setting keys are `vertical`, `line`, `position`,
`size`, `align`, and `region`; duplicate/unknown keys and malformed values fail.
Percentages must be 0–100. Settings, identifiers, inline timestamp tags,
voice/class tags, entities, and arrows stay outside segments. Complete timing
lines in a payload are rejected as in SRT. This is conservative cue parsing,
not a complete WebVTT conformance checker.

## ASS / SSA

An `[Events]` section is required. Only the `Text` field of `Dialogue:` and
`Comment:` event records is editable, retaining the source tool's inclusion of
comment events. Script information, styles, font names, speakers, effect fields,
all other event fields, and comments beginning with `;` are untouched.

A preceding Events `Format:` header is **required**. Field names are
case-insensitive, nonempty, unique, and must include `Start`, `End`, and `Text`.
Other fields may be reordered or added, but `Text` must be **last**; otherwise
`ass_text_position` is raised instead of trying to disambiguate commas. Commas
inside final Text are supported. Every event must supply the declared fields.
Start/end use `H:MM:SS.cc` (1–9 hour digits), with a strictly later end. Empty
Text is valid. Unknown event types, malformed sections/overrides, missing
formats, malformed timestamps, or records outside Events fail conservatively.

Override tags remain exact. `\N`, `\n`, `\h`, and other backslash escapes are
protected. `\pN` with positive N enables drawing protection until explicit
`\p0`; all drawing data is skipped, even if it contains Chinese text. Drawing
state resets for each event. `\pbo` is not confused with `\p`. Malformed or
unsupported drawing-mode expressions fail. A style reset `\r` is **not** used
to infer the end of drawing; text following a reset without explicit `\p0`
may therefore be conservatively skipped. This is not an ASS rendering engine.

## Markdown: conservative lexical support, not an AST

Protected constructs:

- Backtick/tilde fenced blocks (matching closing character and at least the
  opening run length), including simple blockquote/list-prefixed openers.
  Unclosed fences protect the remainder of the document.
- Lines starting with four spaces or a tab are conservatively treated as
  indented code, even when a renderer would instead treat them as continuation
  prose.
- Inline backtick spans with matching delimiter-run lengths, including spans
  across consecutive non-block physical lines. An unmatched opener protects
  the remainder of its physical line.
- Inline-link/image destinations and optional titles after `](`, including
  balanced parentheses and escaped punctuation. Visible labels/alt text can
  be corrected. Unterminated destinations protect the rest of their parsed
  region instead of exposing the URL as prose.
- Reference-definition lines and reference identifiers. Explicit reference
  labels can be corrected; collapsed/known shortcut references are wholly
  protected because their label is also their destination identifier.
- Autolinks, complete HTML tags, HTML comments, and `<pre>`, `<code>`, `<script>`,
  `<style>` regions. Text inside other HTML tags is eligible.
- An initial `---`/`+++` metadata block through its matching closer (`...` also
  closes `---`), Markdown heading/list/quote prefixes, task checkboxes, emphasis
  and table delimiters, escapes, and entities.

**Limits:** this is not CommonMark/GFM AST parsing. Complex nested block
containers, code spans crossing a protected block boundary, multiline reference
syntax, renderer-specific extensions, MDX, math syntax, and unusual HTML are
not fully understood. Reference syntax is recognized in its immediate
`[label][id]`/`[label][]` form; intervening whitespace/newline variants are not
resolved. An initial thematic break can be treated as metadata and conservatively
skip following text. Unusual constructs may be skipped or expose text that a
particular renderer treats as code/metadata. Inspect the preview carefully;
use dedicated Markdown-aware tooling for documents that rely on these forms.
No claim of complete AST or rendering equivalence is made.

## Dictionary validation and bundled-table compatibility

**Update:** the shipped runtime table is now generated from a single Simplified
source; see `dictionary.md`. The baseline counts below describe the original
archived `references/legacy-dictionary.json`, not the new generated table.
Generated `_script_sensitive` metadata is validated and exposed as
`.script_sensitive`; those entries are never included in `.pairs` or replaced
locally. The workflow supplies relevant choices to current-session AI only.
Other custom flat dictionaries retain their ordered replacement behavior.

The dictionary is read as UTF-8 (optional BOM), with a hard **2 MiB** byte limit.
The root must be a JSON object. Active keys/values must be nonblank strings;
newlines and NUL in either are rejected. Malformed JSON, invalid UTF-8, nonfinite
JSON constants, duplicate keys, conflicting keys, and malformed active entries
raise an error. Duplicate detection also applies inside metadata objects.
No invalid active entry is silently skipped.

Underscore-prefixed keys are excluded exactly as in the source tool; their
values may be arbitrary valid JSON metadata. Identical key/value self-maps are
intentionally inactive, also matching the source. The exclusions are inspectable
as `.metadata_keys` and `.self_maps`, rather than silently losing track of them.
Duplicate same-value keys raise `dictionary_duplicate_key`; different values
for a repeated key raise `dictionary_conflicting_key`. Other main codes are
`dictionary_read`, `dictionary_too_large`, `dictionary_json`, `dictionary_table`,
and `dictionary_rule`.

Inspection of the supplied `chinese_homophone_errors.json` found:

- **17,422 bytes; 534 unique keys; no duplicate/conflicting keys.**
- **1** underscore metadata key, **133** self-maps, **400** active rules.
- No malformed active entries. The unchanged dictionary is compatible.
- One active-key containment overlap: `人才汇萃` and `汇萃`. Its declared order is
  retained. No later active key occurs inside an earlier replacement value in
  this bundled table; the implementation still supports such cascades.
- Context-dependent/variant substitutions include `从新 → 重新`, `仓促 → 仓猝`,
  `发奋 → 发愤`, `官服 → 官府`, `窜改 → 篡改`, `神智 → 神志`, and `腊梅 → 蜡梅`.
  These can alter valid language. `每况愈下 → 每况愈下` is one of the inactive
  self-maps, not a correction.

**Recommendation:** preserve the bundled file unchanged for provenance and
compatibility, but treat local hits as reviewable suggestions, not proof of an
error. Prefer a user-curated dictionary for a particular domain. Do not silently
remove or reorder ambiguous rules. The core intentionally cannot resolve their
linguistic ambiguity.

## Synthetic checks

Run from the skill directory:

```sh
python3 -m unittest discover -s tests -p test_documents.py -v
```

The tests cover exact framing/offset roundtrips, 10,000-segment reconstruction,
synthetic randomized TXT/Markdown identity, subtitle structure failures, numeric
and arrow dialogue, VTT opaque blocks, ASS format/drawing protection, Markdown
code/link cases, replacement rejection, duplicate/malformed/oversized tables,
ordered rule cascades, and exact bounded diff offsets. They do not read user
documents, call AI/network, execute the original script, or test the separate
CLI/approval/atomic-write workflow.
