"""Offline unit tests plus loopback HTTP integration. No real account is used."""
from contextlib import contextmanager
import json
import os
from pathlib import Path
import smtplib
import subprocess
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import unittest
from unittest.mock import Mock, patch

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import notify as n
from import_config import migrate


@contextmanager
def server(responder):
    records = []
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_POST(self):
            body = self.rfile.read(int(self.headers.get("Content-Length", "0")))
            records.append((self.path, json.loads(body), dict(self.headers)))
            status, response, headers = responder(self.path, records)
            encoded = response if isinstance(response, bytes) else json.dumps(response).encode()
            self.send_response(status)
            for key, value in headers.items():
                self.send_header(key, value)
            self.send_header("Content-Length", str(len(encoded)))
            self.end_headers()
            self.wfile.write(encoded)
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{httpd.server_port}", records
    finally:
        httpd.shutdown()
        httpd.server_close()
        thread.join()


class NotifyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.env = self.root / ".env"
        self.config = self.root / "config.json"

    def config_for(self, channels, **kwargs):
        return {"enabled": True, "channels": channels, **kwargs}

    def hook(self, url="https://example.invalid/hook", **kwargs):
        return {"enabled": True, "type": "webhook", "url": url, **kwargs}

    def run_cli(self, config, *args, stdin=None):
        self.config.write_text(json.dumps(config))
        result = subprocess.run([sys.executable, str(SCRIPTS / "notify.py"), "--config", str(self.config),
                                 "--env-file", str(self.env), *args], input=stdin, text=True, capture_output=True)
        return result, json.loads(result.stdout)

    def dispatch(self, config, names=None, **kwargs):
        return n.dispatch(config, list(config["channels"]) if names is None else names,
                          kwargs.pop("title", "完成 <&>"), kwargs.pop("content", "第一行\n第二行 <script>"),
                          env_file=self.env, **kwargs)

    def write_env(self, source):
        self.env.write_text(source)
        self.env.chmod(0o600)

    def test_original_six_channels_build_without_requests(self):
        channels = {
            "qq_email": {"enabled": True, "user": "sender@example.invalid", "password": "fake", "recipients": "a@example.invalid；b@example.invalid"},
            "bark": {"enabled": True, "url": "https://example.invalid", "device_key": "fake"},
            "wxpusher": {"enabled": True, "token": "fake", "uid": "fake-user"},
            "pushplus": {"enabled": True, "token": "fake"},
            "resend": {"enabled": True, "api_key": "fake", "to_email": "test@example.invalid"},
            "telegram": {"enabled": True, "bot_token": "123:fake", "chat_id": -123},
        }
        with patch.object(n, "send_http", side_effect=AssertionError("network")), patch.object(n, "send_smtp", side_effect=AssertionError("smtp")):
            report = self.dispatch(self.config_for(channels), dry_run=True)
        self.assertTrue(report["ok"])
        self.assertEqual(len(report["results"]), 6)
        self.assertEqual(report["accepted"], 0)
        self.assertNotIn("fake", json.dumps(report))

    def test_http_adapters_and_payloads(self):
        def reply(path, records):
            data = {"/push": {"code": 200}, "/wx": {"code": 1000, "data": [{"code": 1000}]},
                    "/plus": {"code": 200}, "/resend": {"id": "fake-id"},
                    "/bot123:fake/sendMessage": {"ok": True}, "/hook": {"errcode": 0}}
            return 200, data[path], {}
        with server(reply) as (base, records):
            config = self.config_for({
                "bark": {"enabled": True, "url": base, "device_keys": ["one", "two"], "options": {"group": "测试"}},
                "wxpusher": {"enabled": True, "endpoint": base + "/wx", "token": "fake", "uids": ["one", "two"]},
                "pushplus": {"enabled": True, "endpoint": base + "/plus", "token": "fake"},
                "resend": {"enabled": True, "endpoint": base + "/resend", "api_key": "fake", "to_email": ["a@example.invalid"]},
                "telegram": {"enabled": True, "api_base": base, "bot_token": "123:fake", "chat_id": -123},
                "hook": self.hook(base + "/hook", payload={"text": "{{title}}\n{{content}}", "meta": ["{{project}}"]}, success={"path": "errcode", "equals": 0}),
            })
            report = self.dispatch(config, variables={"project": "a\"b"})
        self.assertTrue(report["ok"])
        self.assertEqual(report["accepted"], 6)
        payloads = {p: data for p, data, h in records}
        self.assertEqual(payloads["/push"]["device_keys"], ["one", "two"])
        self.assertEqual(payloads["/push"]["group"], "测试")
        self.assertEqual(payloads["/wx"]["contentType"], 3)
        self.assertEqual(payloads["/plus"]["template"], "markdown")
        self.assertIn("&lt;script&gt;", payloads["/resend"]["html"])
        self.assertIn("&lt;&amp;&gt;", payloads["/bot123:fake/sendMessage"]["text"])
        self.assertEqual(payloads["/hook"]["meta"], ['a"b'])
        self.assertEqual([r["channel"] for r in report["results"]], list(config["channels"]))

    def test_business_failures_are_not_http_success(self):
        responses = [("bark", {"code": 400}), ("pushplus", {"code": 500}),
                     ("wxpusher", {"code": 1000, "data": [{"code": 1000}, {"code": 1001}]}),
                     ("resend", {"message": "rejected"}), ("telegram", {"ok": False}),
                     ("telegram", []), ("bark", {"code": True})]
        for kind, response in responses:
            with self.subTest(kind=kind, response=response), self.assertRaises(n.SendError):
                n.check_response(kind, response, {})

    def test_partial_http_failure_is_reported_and_exit_is_one(self):
        with server(lambda path, records: (200, {"ok": path == "/good"}, {})) as (base, records):
            config = self.config_for({"one": self.hook(base + "/good", success={"path": "ok", "equals": True}),
                                      "two": self.hook(base + "/bad", success={"path": "ok", "equals": True})})
            proc, report = self.run_cli(config, "send", "--title", "test", "--content", "text")
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(report["accepted"], 1)
        self.assertEqual(len(records), 2)

    def test_missing_config_and_malformed_types(self):
        malformed = [{}, [], {"channels": [], "enabled": True},
                     self.config_for({"x": {"enabled": True, "type": []}}),
                     self.config_for({"x": self.hook()}, workers=0),
                     self.config_for({"x": self.hook()}, enabled="false"),
                     self.config_for({"x": self.hook()}, profiles={"p": ["missing"]})]
        for value in malformed:
            with self.subTest(value=value):
                self.config.write_text(json.dumps(value))
                with self.assertRaises(n.ConfigError):
                    n.load_config(self.config)

    def test_selection_profiles_skip_and_duplicates(self):
        config = self.config_for({"one": self.hook(), "two": self.hook(), "off": self.hook(enabled=False)},
                                 profiles={"p": ["one", "two", "one"]})
        self.assertEqual(n.select_channels(config), ["one", "two"])
        self.assertEqual(n.select_channels(config, profile="p", skip="two"), ["one"])
        self.assertEqual(n.select_channels(config, channels="two,one,two"), ["two", "one"])
        for args in ({"channels": "bad"}, {"channels": "off"}, {"profile": "bad"}, {"skip": "bad"}):
            with self.assertRaises(n.ConfigError):
                n.select_channels(config, **args)

    def test_disabled_and_empty_selection_never_send(self):
        with patch.object(n, "send_http", side_effect=AssertionError("network")):
            report = self.dispatch(self.config_for({"one": self.hook(url="${MISSING}")}, enabled=False))
            self.assertEqual(report["status"], "disabled")
            with self.assertRaises(n.ConfigError):
                self.dispatch(self.config_for({}), [])

    def test_all_requests_preflight_before_any_send(self):
        config = self.config_for({"valid": self.hook(), "bad": self.hook(url="http://remote.invalid")})
        with patch.object(n, "send_http") as send:
            with self.assertRaises(n.ConfigError):
                self.dispatch(config)
            send.assert_not_called()

    def test_disabled_channels_do_not_need_secrets(self):
        config = self.config_for({"on": self.hook(), "off": self.hook(enabled=False, url="${NOTIFY_TEST_MISSING}")})
        proc, report = self.run_cli(config, "check")
        self.assertEqual(proc.returncode, 0)
        self.assertEqual([r["channel"] for r in report["results"]], ["on"])

    def test_dotenv_quotes_inert_commands_and_precedence(self):
        marker = self.root / "should-not-exist"
        self.write_env("# comment\nUNRELATED=ignored\nexport NOTIFY_TEST_A='literal $(touch " + str(marker) + ")'\nNOTIFY_TEST_B=unquoted # comment\nNOTIFY_TEST_C=\"line\\nquote\\\"\" # comment\n")
        with patch.dict(os.environ, {"NOTIFY_TEST_B": "process wins"}, clear=True):
            values = n.resolve_environment({"NOTIFY_TEST_A", "NOTIFY_TEST_B", "NOTIFY_TEST_C"}, self.env)
        self.assertIn("$(touch", values["NOTIFY_TEST_A"])
        self.assertEqual(values["NOTIFY_TEST_B"], "process wins")
        self.assertEqual(values["NOTIFY_TEST_C"], 'line\nquote"')
        self.assertNotIn("UNRELATED", values)
        self.assertFalse(marker.exists())

    def test_env_permissions_duplicates_missing_empty(self):
        self.write_env("NOTIFY_TEST_A=one\nNOTIFY_TEST_A=two\n")
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(n.ConfigError):
                n.resolve_environment({"NOTIFY_TEST_A"}, self.env)
            self.env.chmod(0o644)
            with self.assertRaises(n.ConfigError):
                n.resolve_environment({"NOTIFY_TEST_A"}, self.env)
            for values in ({}, {"NOTIFY_TEST_A": ""}):
                with self.assertRaises(n.ConfigError):
                    n.expand_env("${NOTIFY_TEST_A}", values)

    def test_env_resolved_for_nested_headers_not_leaked(self):
        self.write_env('NOTIFY_TEST_TOKEN="fake-super-secret"\n')
        config = self.config_for({"hook": self.hook(headers={"Authorization": "Bearer ${NOTIFY_TEST_TOKEN}"})})
        report = self.dispatch(config, dry_run=True)
        self.assertTrue(report["ok"])
        self.assertNotIn("fake-super-secret", json.dumps(report))

    def test_templates_single_pass_and_missing(self):
        self.assertEqual(n.render("{{name}} / {{ next }}", {"name": "{{next}}", "next": "中文"}), "{{next}} / 中文")
        with self.assertRaises(n.ConfigError):
            n.render("{{missing}}", {})
        proc, report = self.run_cli(self.config_for({"x": self.hook()}), "send", "--title", "{{missing}}", "--content", "text", "--dry-run")
        self.assertEqual(proc.returncode, 2)
        self.assertEqual(report["status"], "configuration_error")

    def test_cli_stdin_and_config_templates(self):
        config = self.config_for({"x": self.hook()}, message={"title": "{{project}}", "content": "old"})
        proc, report = self.run_cli(config, "send", "--content-file", "-", "--var", "project=测试", "--dry-run", stdin="新正文\n")
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(report["status"], "dry_run")
        self.assertNotIn("新正文", proc.stdout)

    def test_cli_content_file_and_missing_body(self):
        body = self.root / "message.txt"
        body.write_text("文本 {{project}}", encoding="utf-8")
        config = self.config_for({"x": self.hook()})
        proc, report = self.run_cli(config, "send", "--title", "test", "--content-file", str(body), "--var", "project=demo", "--dry-run")
        self.assertEqual(proc.returncode, 0)
        proc, report = self.run_cli(config, "send", "--title", "test", "--dry-run")
        self.assertEqual(proc.returncode, 2)

    def test_url_and_header_injection_rejected(self):
        for url in ("http://example.invalid", "file:///tmp/x", "https://u:p@example.invalid", "https://example.invalid/#fragment", "https://example.invalid/\n"):
            with self.subTest(url=url), self.assertRaises(n.ConfigError):
                n.validate_url(url)
        for headers in ({"Authorization": "fake\r\nHost: stolen"}, {"Host": "other"}, {"Content-Length": "0"}):
            with self.assertRaises(n.ConfigError):
                self.dispatch(self.config_for({"x": self.hook(headers=headers)}), dry_run=True)
        for url in ("https://example.invalid", "http://127.0.0.1:123", "http://[::1]:123"):
            self.assertEqual(n.validate_url(url), url)

    def test_telegram_boundary_and_escaping(self):
        cfg = {"enabled": True, "bot_token": "123:fake", "chat_id": -123}
        config = self.config_for({"telegram": cfg})
        self.assertTrue(self.dispatch(config, title="t", content="x" * 4094, dry_run=True)["ok"])
        with self.assertRaises(n.ConfigError):
            self.dispatch(config, title="t", content="x" * 4095, dry_run=True)
        with self.assertRaises(n.ConfigError):
            self.dispatch(config, content="😀" * 2048, dry_run=True)

    def test_reserved_options_cannot_change_core_message(self):
        cfg = {"enabled": True, "token": "fake", "options": {"token": "override", "title": "override", "template": "txt"}}
        delivery = n.prepare("pushplus", cfg, {}, "title", "body", {})
        payload = json.loads(delivery.payload)
        self.assertEqual(payload["token"], "fake")
        self.assertEqual(payload["title"], "title")
        self.assertEqual(payload["template"], "txt")

    def test_smtp_ssl_starttls_html_and_partial(self):
        for kind, security in (("qq_email", "ssl"), ("smtp", "starttls")):
            cfg = {"enabled": True, "user": "a@example.invalid", "password": "fake", "recipients": "b@example.invalid；c@example.invalid；b@example.invalid",
                   "security": security, "host": "smtp.example.invalid"}
            config = self.config_for({kind: cfg})
            with patch.object(n.smtplib, "SMTP_SSL") as ssl_client, patch.object(n.smtplib, "SMTP") as tls_client:
                client = (ssl_client if security == "ssl" else tls_client).return_value
                client.__enter__.return_value = client
                client.send_message.return_value = {}
                report = self.dispatch(config)
                self.assertTrue(report["ok"])
                msg = client.send_message.call_args.args[0]
                self.assertIn("&lt;script&gt;", msg.get_body(preferencelist=("html",)).get_content())
                self.assertEqual(client.send_message.call_args.kwargs["to_addrs"], ["b@example.invalid", "c@example.invalid"])
                self.assertEqual(client.starttls.call_count, int(security == "starttls"))
                client.send_message.return_value = {"c@example.invalid": (550, b"fake-secret")}
                report = self.dispatch(config)
                self.assertFalse(report["ok"])
                self.assertNotIn("fake-secret", json.dumps(report))

    def test_smtp_auth_no_secret_logging_or_retry(self):
        cfg = {"enabled": True, "user": "a@example.invalid", "password": "fake-secret", "recipients": "b@example.invalid", "retries": 3}
        with patch.object(n.smtplib, "SMTP_SSL") as factory:
            factory.return_value.login.side_effect = smtplib.SMTPAuthenticationError(535, b"fake-secret")
            report = self.dispatch(self.config_for({"qq_email": cfg}))
        self.assertEqual(report["results"][0]["attempts"], 1)
        self.assertEqual(report["results"][0]["message"], "SMTP authentication failed")
        self.assertNotIn("fake-secret", json.dumps(report))

    def test_tls_falls_back_to_system_ca_if_default_store_empty(self):
        context = Mock()
        context.cert_store_stats.return_value = {"x509_ca": 0}
        with patch.dict(os.environ, {}, clear=True), patch.object(n.ssl, "create_default_context", return_value=context), patch.object(n.Path, "is_file", return_value=True):
            self.assertIs(n.create_tls_context(), context)
        context.load_verify_locations.assert_called_once_with(cafile="/etc/ssl/cert.pem")

    def test_tls_respects_default_or_explicit_trust(self):
        for count, env in ((10, {}), (0, {"SSL_CERT_FILE": "/custom/ca.pem"}), (0, {"SSL_CERT_DIR": "/custom/ca"})):
            with self.subTest(count=count, env=env):
                context = Mock()
                context.cert_store_stats.return_value = {"x509_ca": count}
                with patch.dict(os.environ, env, clear=True), patch.object(n.ssl, "create_default_context", return_value=context):
                    self.assertIs(n.create_tls_context(), context)
                context.load_verify_locations.assert_not_called()

    def test_tls_errors_are_identified_without_secret_output(self):
        for error in (n.ssl.SSLCertVerificationError(1, "fake-secret"), n.URLError(n.ssl.SSLCertVerificationError(1, "fake-secret"))):
            with patch.object(n, "send_http", side_effect=error):
                report = self.dispatch(self.config_for({"x": self.hook()}))
            self.assertIn("TLS certificate verification failed", report["results"][0]["message"])
            self.assertNotIn("fake-secret", json.dumps(report))

    def test_tls_keeps_certificate_and_hostname_verification(self):
        context = n.create_tls_context()
        self.assertEqual(context.verify_mode, n.ssl.CERT_REQUIRED)
        self.assertTrue(context.check_hostname)

    def test_smtp_header_injection_preflight(self):
        cfg = {"enabled": True, "user": "a@example.invalid", "password": "fake", "recipients": ["b@example.invalid\nBcc: c@example.invalid"]}
        with self.assertRaises(n.ConfigError):
            self.dispatch(self.config_for({"qq_email": cfg}), dry_run=True)

    def test_webhook_empty_response_and_typed_success(self):
        with server(lambda p, r: (204, b"", {})) as (base, records):
            self.assertTrue(self.dispatch(self.config_for({"x": self.hook(base)}))["ok"])
        with server(lambda p, r: (200, {"data": {"ok": 1}}, {})) as (base, records):
            report = self.dispatch(self.config_for({"x": self.hook(base, success={"path": "data.ok", "equals": True})}))
            self.assertFalse(report["ok"])

    def test_bad_json_and_oversized_response(self):
        for body in (b"not json: fake-secret", b"x" * (n.MAX_RESPONSE + 1)):
            with server(lambda p, r: (200, body, {})) as (base, records):
                config = self.config_for({"x": self.hook(base, success={"path": "ok", "equals": True})})
                report = self.dispatch(config)
            self.assertFalse(report["ok"])
            self.assertNotIn("fake-secret", json.dumps(report))

    def test_redirect_not_followed_and_no_secret_logs(self):
        with server(lambda p, r: (307, b"fake-secret", {"Location": "/stolen?token=fake-secret"})) as (base, records):
            report = self.dispatch(self.config_for({"x": self.hook(base + "/initial?token=fake-secret")}))
        self.assertEqual(len(records), 1)
        self.assertFalse(report["ok"])
        self.assertNotIn("fake-secret", json.dumps(report))

    def test_retry_default_off_explicit_backoff_on(self):
        for retries, expected in ((0, 1), (1, 2)):
            with server(lambda p, r: (429, {}, {"Retry-After": "1"}) if len(r) == 1 else (200, {}, {})) as (base, records):
                with patch.object(n.time, "sleep") as sleep:
                    report = self.dispatch(self.config_for({"x": self.hook(base, retries=retries)}))
            self.assertEqual(len(records), expected)
            self.assertEqual(report["results"][0]["attempts"], expected)
            if retries:
                self.assertTrue(report["ok"])
                self.assertGreaterEqual(sleep.call_args.args[0], 1)

    def test_long_retry_after_does_not_retry_early(self):
        with server(lambda p, r: (503, {}, {"Retry-After": "100"})) as (base, records):
            with patch.object(n.time, "sleep") as sleep:
                self.dispatch(self.config_for({"x": self.hook(base, retries=3)}))
                sleep.assert_not_called()
        self.assertEqual(len(records), 1)

    def test_timeout_not_retried_or_logged(self):
        with patch.object(n, "send_http", side_effect=TimeoutError("fake-secret")) as send:
            report = self.dispatch(self.config_for({"x": self.hook(retries=3)}))
        self.assertEqual(send.call_count, 1)
        self.assertFalse(report["ok"])
        self.assertNotIn("fake-secret", json.dumps(report))

    def test_http_concurrency_bounded_by_workers(self):
        for workers in (1, 3):
            active = peak = 0
            lock = threading.Lock()
            def response(path, records):
                nonlocal active, peak
                with lock:
                    active += 1
                    peak = max(peak, active)
                time.sleep(0.08)
                with lock:
                    active -= 1
                return 200, {}, {}
            with server(response) as (base, records):
                report = self.dispatch(self.config_for({f"x{i}": self.hook(base) for i in range(6)}, workers=workers))
            self.assertTrue(report["ok"])
            self.assertLessEqual(peak, workers)
            self.assertEqual(peak, 1) if workers == 1 else self.assertGreater(peak, 1)

    def test_init_private_and_refuses_overwrite(self):
        report = n.init_config(self.config)
        self.assertEqual(report["status"], "initialized")
        self.assertEqual(self.config.stat().st_mode & 0o777, 0o600)
        self.assertFalse(n.load_config(self.config)["enabled"])
        original = self.config.read_bytes()
        with self.assertRaises(n.ConfigError):
            n.init_config(self.config)
        self.assertEqual(self.config.read_bytes(), original)

    def test_migration_roundtrip_preserves_original_and_shared_env(self):
        source = self.root / "original.json"
        source.write_text(json.dumps(self.config_for({"telegram": {"enabled": True, "bot_token": 'fake\\$()"secret', "chat_id": -123}})))
        original = source.read_bytes()
        self.write_env("EXISTING=untouched\n")
        report = migrate(source, self.config, self.env)
        self.assertEqual(report["new_env_variables"], 2)
        self.assertEqual(source.read_bytes(), original)
        self.assertTrue(self.env.read_text().startswith("EXISTING=untouched\n"))
        self.assertNotIn("secret", self.config.read_text())
        self.assertEqual(self.config.stat().st_mode & 0o777, 0o600)
        with patch.dict(os.environ, {}, clear=True):
            loaded = n.load_config(self.config)
            self.assertTrue(self.dispatch(loaded, dry_run=True)["ok"])
        saved = self.env.read_bytes()
        self.assertEqual(migrate(source, self.config, self.env)["new_env_variables"], 0)
        self.assertEqual(self.env.read_bytes(), saved)

    def test_migration_conflict_changes_neither_file(self):
        source = self.root / "original.json"
        source.write_text(json.dumps(self.config_for({"telegram": {"enabled": True, "bot_token": "new-fake", "chat_id": "id"}})))
        self.write_env('OMNIRUSH_NOTIFY_TELEGRAM_BOT_TOKEN="existing-fake"\n')
        self.config.write_text("preserve me")
        before = self.env.read_bytes()
        with self.assertRaises(n.ConfigError):
            migrate(source, self.config, self.env)
        self.assertEqual(self.config.read_text(), "preserve me")
        self.assertEqual(self.env.read_bytes(), before)

    def test_list_never_resolves_or_prints_values(self):
        config = self.config_for({"telegram": {"enabled": True, "bot_token": "fake-secret", "chat_id": "fake-private-id"}})
        proc, report = self.run_cli(config, "list")
        self.assertEqual(proc.returncode, 0)
        self.assertNotIn("fake-secret", proc.stdout)
        self.assertNotIn("fake-private-id", proc.stdout)
        self.assertEqual(report["channels"][0]["name"], "telegram")


if __name__ == "__main__":
    unittest.main()
