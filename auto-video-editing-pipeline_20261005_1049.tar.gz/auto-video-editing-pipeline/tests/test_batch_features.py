import argparse
import contextlib
import io
import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts import auto_video_pipeline as pipeline
from scripts.edit_mode import build_plan, retime_for_ranges, validate_plan
from scripts.release_pack import PLATFORMS, validate_response
from scripts.srt_utils import format_time, read_cues, write_cues


class PlanningTests(unittest.TestCase):
    def test_defaults_and_resume_explicit_overrides(self):
        defaults = pipeline.build_parser().parse_args([])
        self.assertTrue(defaults.merge)
        self.assertFalse(defaults.edit_mode)
        self.assertFalse(defaults.release_pack)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            pipeline.write_json(root / "state.json", {"options": {"merge": True, "edit_mode": True, "release_pack": True, "fps": 24, "highlight": ["襄阳"], "force_render": True, "approve_review": True}})
            args = pipeline.parse_args(["--resume-batch", temp, "--no-merge", "--no-edit-mode"])
            self.assertFalse(args.merge)
            self.assertFalse(args.edit_mode)
            self.assertTrue(args.release_pack)
            self.assertEqual(args.fps, 24)
            self.assertEqual(args.highlight, ["襄阳"])
            self.assertFalse(args.force_render)
            self.assertFalse(args.approve_review)

    def test_filename_order_and_exclude_outputs(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for name in ("dirB/01.mp4", "dirA/02.mp4", "output/old.mp4"):
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.touch()
            self.assertEqual([p.name for p in pipeline.collect_inputs([temp], root / "output")], ["01.mp4", "02.mp4"])

    def test_merge_does_not_skip_failed_input(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            final = root / "single.mp4"
            final.touch()
            state = {"videos": [
                {"id": "a", "source": "01.mp4", "stages": {"edit": {"status": "complete"}, "final_qa": {"status": "complete"}}, "paths": {"final": str(final)}},
                {"id": "b", "source": "02.mp4", "stages": {"edit": {"status": "failed"}}, "paths": {}},
            ]}
            self.assertEqual(pipeline.merge_final_videos(root, state, pipeline.build_parser().parse_args([]))["status"], "blocked")
            self.assertFalse((root / "final.mp4").exists())

    def test_boundaries_speeds_and_actual_segment_offsets(self):
        with tempfile.TemporaryDirectory() as temp:
            srt = Path(temp) / "source.srt"
            write_cues(srt, [(0.1, 0.9, ["开场"]), (1.1, 1.9, ["结果：关键在这里！"]), (2.1, 2.9, ["正文"] )])
            plan = build_plan(srt, 3, 0.5, 1.2, 1)
            validate_plan(plan, srt, 3)
            self.assertEqual(plan["ranges"][-1]["end"], 3)
            self.assertNotIn("approved", plan)
            with self.assertRaisesRegex(ValueError, "cuts a subtitle phrase"):
                validate_plan({"ranges": [{"start": 0.5, "end": 2, "speed": 1}]}, srt, 3)
            with self.assertRaises(ValueError):
                validate_plan({"ranges": [{"start": 0, "end": 3, "speed": float('nan')}]}, srt, 3)
            ranges = [{"start": 1, "end": 2, "speed": 2}, {"start": 0, "end": 3, "speed": 1}]
            out = Path(temp) / "out.srt"
            retime_for_ranges(srt, ranges, [0.52, 3.0], out)
            cues = read_cues(out)
            self.assertAlmostEqual(cues[1][0], 0.62)
            with self.assertRaises(ValueError):
                retime_for_ranges(srt, ranges, [0.52], out)
            self.assertEqual(format_time(59.9999), "00:01:00,000")


@unittest.skipUnless(shutil.which("ffmpeg") and pipeline.ASS_SCRIPT.is_file(), "requires FFmpeg and installed srt-ass-studio")
class BatchIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.batch = self.root / "batch"
        self.batch.mkdir()
        records = []
        # Reverse creation order, mixed dimensions and an absent audio track.
        for name, color, size, audio in [("02-blue.mp4", "blue", "480x360", True), ("01-red.mp4", "red", "640x360", False)]:
            source = self.root / name
            command = ["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", f"color=c={color}:s={size}:r=24:d=3"]
            if audio:
                command += ["-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000:duration=3", "-c:a", "aac", "-ac", "2"]
            command += ["-c:v", "libx264", "-threads", "1", "-pix_fmt", "yuv420p", str(source)]
            subprocess.run(command, check=True, capture_output=True)
            item_id = pipeline.video_id(source)
            srt = self.batch / "videos" / item_id / "transcripts" / "source.srt"
            srt.parent.mkdir(parents=True)
            write_cues(srt, [(0.1, 0.9, [color]), (1.1, 1.9, ["结果：关键在这里！"]), (2.1, 2.9, [color])])
            records.append({"id": item_id, "source": str(source), "source_sha256": pipeline.sha256(source), "probe": pipeline.probe(source), "stages": {}, "paths": {"raw_srt": str(srt), "corrected_srt": str(srt)}})
        pipeline.write_json(self.batch / "state.json", {"version": 2, "videos": records, "options": {"fps": 24, "subtitle_font_name": "DejaVu Sans", "subtitle_font_size": 18, "video_preset": "ultrafast"}, "erratum_job": None})

    def run_pipeline(self, *flags):
        with contextlib.redirect_stdout(io.StringIO()):
            code = pipeline.main(["--resume-batch", str(self.batch), *flags])
        if code == 1:
            state = self.state()
            self.fail(json.dumps({"stages": [item["stages"] for item in state["videos"]], "merge": state.get("merge"), "release_pack": state.get("release_pack")}, ensure_ascii=False, indent=2))
        return code

    def state(self):
        return json.loads((self.batch / "state.json").read_text())

    def test_merge_release_and_resume(self):
        self.assertEqual(self.run_pipeline(), 0)
        state = self.state()
        self.assertEqual([Path(value).name for value in state["merge"]["order"]], ["01-red.mp4", "02-blue.mp4"])
        report = json.loads((self.batch / "qa/merged/report.json").read_text())
        self.assertTrue(report["ok"])
        self.assertEqual(report["fps"], "24/1")
        self.assertEqual(report["resolution"], [640, 360])
        self.assertAlmostEqual(report["duration"], 6, delta=0.1)
        self.assertAlmostEqual(read_cues(self.batch / "final.srt")[3][0], 3.1, delta=0.05)
        # Check order in actual decoded pixels, not only the manifest.
        for position, channel in [(0.5, 0), (3.5, 2)]:
            frame = subprocess.run(["ffmpeg", "-v", "error", "-ss", str(position), "-i", str(self.batch / "final.mp4"), "-vf", "crop=2:2:100:10", "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], check=True, capture_output=True).stdout
            self.assertGreater(frame[channel], 200)
        mtime = (self.batch / "final.mp4").stat().st_mtime_ns
        self.assertEqual(self.run_pipeline("--release-pack"), 10)
        state = self.state()
        self.assertEqual(state["summary"]["failed"], 0)
        for job in state["release_pack"]["pending_requests"]:
            request = json.loads(Path(job["request_path"]).read_text())
            response = request["response_schema"]
            response.update(topic="红蓝画面", cover_landscape="横向红蓝画面", cover_vertical="竖向红蓝画面", publish_plan="按账号历史数据选择时段")
            for name, data in response["platforms"].items():
                data.update(titles=[f"{name}：红蓝画面{n}" for n in range(1, 4)], description=f"{name}红蓝画面的展示。", reason="符合本段画面", tags=["色彩"], evidence_ids=["E1"])
            validate_response(request, response)
            pipeline.write_json(Path(job["response_path"]), response)
            original = response["platforms"]["抖音"]["titles"]
            response["platforms"]["抖音"]["titles"] = response["platforms"]["B站"]["titles"]
            with self.assertRaisesRegex(ValueError, "duplicate"):
                validate_response(request, response)
            response["platforms"]["抖音"]["titles"] = original
            response["request_id"] = "stale"
            with self.assertRaisesRegex(ValueError, "stale"):
                validate_response(request, response)
        self.assertEqual(self.run_pipeline(), 0)
        self.assertEqual((self.batch / "final.mp4").stat().st_mtime_ns, mtime)
        pack = Path(self.state()["release_pack"]["packs"][0])
        self.assertEqual(len(list(pack.glob("*.md"))), 11)
        self.assertEqual(self.run_pipeline("--no-merge"), 10)
        # An old merged file must not be selected when merging is disabled.
        self.assertEqual(len(self.state()["release_pack"]["pending_requests"]), 2)

    def test_edit_review_then_resume_uses_modified_ranges(self):
        self.assertEqual(self.run_pipeline("--edit-mode", "--stop-for-review", "--no-merge", "--cut-padding-ms", "0"), 11)
        state = self.state()
        self.assertEqual(state["summary"]["failed"], 0)
        for item in state["videos"]:
            self.assertFalse((self.batch / "videos" / item["id"] / "final.mp4").exists())
            plan_path = Path(item["paths"]["edit_plan"])
            plan = json.loads(plan_path.read_text())
            plan["ranges"] = [{"kind": "opening_highlight", "start": 1, "end": 2, "speed": 1}, {"kind": "body", "start": 0, "end": 1, "speed": 2}, {"kind": "body", "start": 1, "end": 3, "speed": 0.5}]
            pipeline.write_json(plan_path, plan)
        self.assertEqual(self.run_pipeline("--approve-review"), 0)
        for item in self.state()["videos"]:
            self.assertEqual(len(item["edit"]["ranges"]), 3)
            self.assertTrue(item["stages"]["final_qa"]["report"]["ok"])
            self.assertAlmostEqual(pipeline.media_signature(Path(item["paths"]["final"]))["duration"], 5.5, delta=0.1)
            cues = read_cues(Path(item["paths"]["timeline_srt"]))
            self.assertAlmostEqual(cues[1][0], 1.05, delta=0.05)
            self.assertAlmostEqual(cues[2][0], 1.7, delta=0.05)


if __name__ == "__main__":
    unittest.main()
