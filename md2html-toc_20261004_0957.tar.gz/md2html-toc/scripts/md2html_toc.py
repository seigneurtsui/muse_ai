#!/usr/bin/env python3
"""Batch Markdown -> standalone HTML with a responsive table of contents.

Adapted from the supplied md2html_toc_batch.py. The converter keeps the useful
Markdown extensions and TOC behavior, but defaults to sanitizing raw HTML,
rejects links/aliases that escape the input tree, and writes atomically.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import html
import json
import os
from pathlib import Path
import stat
import re
import shutil
import tempfile
import time
from urllib.parse import unquote, urlsplit

VERSION = "3.0.0"
MD_SUFFIXES = frozenset({".md", ".markdown", ".mdown", ".mkdn"})
DEFAULT_OUTPUT = Path.home() / "Downloads" / "html_toc_silo"
MAX_FILES = 5000
MAX_FILE_BYTES = 16 * 1024 * 1024
MAX_TOTAL_BYTES = 256 * 1024 * 1024
MAX_REPORT_BYTES = 16 * 1024 * 1024

BASE_CSS = r"""
:root{color-scheme:light;--ink:#1e293b;--muted:#64748b;--blue:#1d4ed8;--line:#cbd5e1;--surface:#fff}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;padding:1.25rem;color:var(--ink);background:linear-gradient(135deg,#667eea,#764ba2);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;line-height:1.8}
.container{width:min(100%,920px);margin:0 auto;padding:clamp(1.1rem,4vw,3rem);background:var(--surface);border-radius:16px;box-shadow:0 20px 60px #0f172a4d}h1,h2,h3,h4,h5,h6{scroll-margin-top:1.2rem}h1{margin:0 0 1.5rem;padding-bottom:.7rem;color:#1e3a8a;border-bottom:3px solid #3b82f6}h2{margin:2.3rem 0 1rem;padding-left:1rem;color:#1e3a8a;border-left:5px solid #3b82f6}h3{color:#2563eb}a{color:#2563eb}img.md-image{display:block;max-width:100%;height:auto;margin:1rem auto;border-radius:10px}blockquote{margin:1rem 0;padding:.8rem 1.2rem;color:#475569;background:#f8fafc;border-left:4px solid #0f766e;border-radius:0 8px 8px 0}pre{overflow:auto;padding:1rem;background:#0f172a;color:#e2e8f0;border-radius:9px}code{padding:.1rem .3rem;background:#f1f5f9;border:1px solid #dbe3ef;border-radius:4px}pre code{padding:0;color:inherit;background:transparent;border:0}.table-wrap{overflow:auto;margin:1.25rem 0;border:1px solid #64748b;border-radius:8px}.container table{width:100%;min-width:480px;border-collapse:collapse}.container th,.container td{padding:.65rem .85rem;vertical-align:top;border:1px solid #64748b}.container th{color:#fff;text-align:left;background:#1e3a8a}.container tr:nth-child(even){background:#f8fafc}
.toc{position:fixed;z-index:2;top:24px;left:max(16px,calc(50% - 680px));width:245px;max-height:calc(100vh - 48px);overflow:hidden;color:#fff;background:#172554eF;border:1px solid #ffffff30;border-radius:14px;box-shadow:0 12px 34px #0f172a4d}.toc-head{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid #ffffff30}.toc-title{font-weight:700}.toc-toggle{color:#fff;background:#ffffff18;border:1px solid #ffffff55;border-radius:6px;font-size:1.1rem;cursor:pointer}.toc-progress{padding:8px 14px;color:#ffffffcc;font-size:.75rem;border-bottom:1px solid #ffffff30}.toc-track{height:4px;background:#ffffff30;border-radius:99px}.toc-bar{width:0;height:100%;background:#bfdbfe;border-radius:inherit}.toc-nav{max-height:calc(100vh - 150px);overflow:auto;padding:8px}.toc-nav a{display:block;padding:4px 7px;color:#ffffffd9;text-decoration:none;border-radius:5px;font-size:.85rem}.toc-nav a:hover,.toc-nav a.active{color:#fff;background:#93c5fd3d}.toc-nav a[data-level="1"]{font-weight:700}.toc-nav a[data-level="3"],.toc-nav a[data-level="4"],.toc-nav a[data-level="5"],.toc-nav a[data-level="6"]{padding-left:20px;font-size:.79rem}.toc.collapsed{width:165px;max-height:48px}.toc.collapsed .toc-progress,.toc.collapsed .toc-nav{display:none}
@media(max-width:1100px){.toc{position:relative;top:auto;left:auto;width:auto;max-height:none;margin:0 auto 1rem}.toc-nav{max-height:260px}.container{width:min(100%,920px)}}@media(max-width:600px){body{padding:.5rem}.container{padding:1rem .75rem;border-radius:10px}h1{font-size:1.65rem}h2{font-size:1.35rem;border-left-width:4px}.container table{min-width:420px;font-size:.86rem}}@media print{body{padding:0;background:#fff}.toc{display:none}.container{width:100%;padding:0;box-shadow:none}}
"""

TOC_SCRIPT = r"""
<script>
(()=>{const toc=document.querySelector('[data-md-toc="1"]');if(!toc)return;const button=toc.querySelector('.toc-toggle'),bar=document.querySelector('.toc-bar'),text=document.querySelector('.toc-percent'),links=[...toc.querySelectorAll('a[data-target]')],key='md2html-toc-collapsed';function collapse(v){toc.classList.toggle('collapsed',v);if(button){button.textContent=v?'+':'−';button.setAttribute('aria-expanded',String(!v))}try{localStorage.setItem(key,v?'1':'0')}catch(_){}}try{collapse(localStorage.getItem(key)==='1')}catch(_){}button?.addEventListener('click',()=>collapse(!toc.classList.contains('collapsed')));function progress(){let max=document.documentElement.scrollHeight-innerHeight,p=max?Math.max(0,Math.min(100,Math.round(scrollY/max*100))):0;if(bar)bar.style.width=p+'%';if(text)text.textContent=p+'%'}addEventListener('scroll',progress,{passive:true});addEventListener('resize',progress);progress();const map=new Map();links.forEach(a=>{const e=document.getElementById(a.dataset.target);if(e)map.set(e,a);a.addEventListener('click',()=>{links.forEach(x=>x.classList.remove('active'));a.classList.add('active')})});if('IntersectionObserver'in window){new IntersectionObserver(es=>{const e=es.filter(x=>x.isIntersecting).sort((a,b)=>a.boundingClientRect.top-b.boundingClientRect.top)[0],a=e&&map.get(e.target);if(a){links.forEach(x=>x.classList.remove('active'));a.classList.add('active')}},{rootMargin:'-80px 0px -65% 0px'}).observe([...map.keys()][0])}})();
</script>
"""


class ConversionError(Exception):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def reason(error: BaseException) -> str:
    code = getattr(error, "code", "")
    if isinstance(code, str) and re.fullmatch(r"[a-z][a-z0-9_]{0,79}", code):
        return code
    if isinstance(error, UnicodeError):
        return "text_decode_failed"
    return "conversion_failed"


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def packed(value) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def linklike(path: Path) -> bool:
    try:
        info = path.lstat()
    except OSError:
        return False
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, "st_file_attributes", 0)
        & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    )


def safe_root(path: Path, create: bool = False) -> Path:
    path = path.expanduser().absolute()
    if path.exists() or path.is_symlink():
        if linklike(path) or not path.is_dir():
            raise ConversionError("directory_is_link_or_not_directory")
    elif create:
        path.mkdir(parents=True, mode=0o700)
    else:
        raise ConversionError("input_directory_not_found")
    if create:
        path.mkdir(parents=True, exist_ok=True, mode=0o700)
    return path.resolve()


def ensure_dirs(root: Path, directory: Path) -> None:
    if not directory.absolute().is_relative_to(root.absolute()):
        raise ConversionError("output_path_outside_root")
    current = root
    for part in directory.relative_to(root).parts:
        current = current / part
        if current.exists() or current.is_symlink():
            if linklike(current) or not current.is_dir():
                raise ConversionError("output_parent_is_link_or_not_directory")
        else:
            current.mkdir(mode=0o700)


def atomic_write(path: Path, raw: bytes) -> None:
    if not path.parent.is_dir() or linklike(path.parent):
        raise ConversionError("output_parent_is_link_or_not_directory")
    if path.exists() or path.is_symlink():
        if linklike(path) or not path.is_file() or path.stat().st_nlink > 1:
            raise ConversionError("output_target_is_link_or_not_regular")
    fd, name = tempfile.mkstemp(prefix=".md2html-", suffix=".tmp", dir=path.parent)
    temp = Path(name)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
        if os.name != "nt":
            directory_fd = os.open(
                path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
            )
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
    finally:
        temp.unlink(missing_ok=True)


def read_text(path: Path) -> tuple[str, str, bytes]:
    raw = path.read_bytes()
    if len(raw) > MAX_FILE_BYTES:
        raise ConversionError("input_file_over_limit")
    for encoding in ("utf-8-sig", "utf-8", "gb18030", "gbk"):
        try:
            return raw.decode(encoding), encoding, raw
        except UnicodeDecodeError:
            continue
    raise ConversionError("text_decode_failed")


def split_front_matter(content: str) -> tuple[dict[str, str], str]:
    if not (content.startswith("---\n") or content.startswith("---\r\n")):
        return {}, content
    match = re.match(r"^---\s*\r?\n(.*?)\r?\n---\s*\r?\n", content, re.DOTALL)
    if not match:
        return {}, content
    metadata = {}
    for line in match.group(1).splitlines():
        if ":" in line and line.strip() and not line.lstrip().startswith("#"):
            key, value = line.split(":", 1)
            metadata[key.strip().lower()] = value.strip().strip("'\"")
    return metadata, content[match.end() :]


def text_from_html(fragment: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", html.unescape(fragment))).strip()


def slugify(text: str) -> str:
    value = re.sub(r"[^\w\-\u4e00-\u9fff]+", "-", text.lower(), flags=re.UNICODE)
    return re.sub(r"-+", "-", value).strip("-") or "section"


def unique_id(preferred: str, used: set[str]) -> str:
    candidate = preferred
    index = 2
    while candidate in used:
        candidate = f"{preferred}-{index}"
        index += 1
    used.add(candidate)
    return candidate


def heading_ids(body: str) -> tuple[str, list[dict[str, str | int]]]:
    used = set(re.findall(r'\bid=["\']([^"\']+)["\']', body, re.I))
    items = []
    pattern = re.compile(
        r"<h([1-6])(?P<attrs>[^>]*)>(?P<content>.*?)</h\1>", re.I | re.S
    )

    def replace(match: re.Match[str]) -> str:
        level = int(match.group(1))
        attrs = match.group("attrs") or ""
        content = match.group("content")
        existing = re.search(r'\bid=["\']([^"\']+)["\']', attrs, re.I)
        title = text_from_html(content)
        # Slug the raw heading content, not the tag-stripped text, so literal
        # inline HTML keeps its characters ("# Title <x>" -> "title-x") while
        # the displayed TOC label stays clean ("Title").
        heading_id = (
            existing.group(1) if existing else unique_id(slugify(content), used)
        )
        if not existing:
            attrs += f' id="{html.escape(heading_id, quote=True)}"'
        if title:
            items.append({"level": level, "id": heading_id, "title": title})
        return f"<h{level}{attrs}>{content}</h{level}>"

    return pattern.sub(replace, body), items


def rewrite_links(body: str) -> str:
    def replace(match: re.Match[str]) -> str:
        quote, href = match.group(1), match.group(2)
        parts = urlsplit(href)
        if parts.scheme or parts.netloc or href.startswith(("#", "mailto:", "tel:")):
            return match.group(0)
        path = re.sub(r"\.(md|markdown|mdown|mkdn)$", ".html", parts.path, flags=re.I)
        if path == parts.path:
            return match.group(0)
        rebuilt = (
            path
            + (("?" + parts.query) if parts.query else "")
            + (("#" + parts.fragment) if parts.fragment else "")
        )
        return f"href={quote}{rebuilt}{quote}"

    return re.sub(r"href=([\"'])(.*?)\1", replace, body, flags=re.I | re.S)


def postprocess_tables(body: str) -> str:
    def open_table(match: re.Match[str]) -> str:
        attrs = match.group(1) or ""
        if "md-table" not in attrs:
            attrs += ' class="md-table"'
        return f'<div class="table-wrap"><table{attrs}>'

    body = re.sub(r"<table([^>]*)>", open_table, body, flags=re.I)
    return re.sub(r"</table>", "</table></div>", body, flags=re.I)


def postprocess_images(body: str) -> str:
    def replace(match: re.Match[str]) -> str:
        attrs = match.group(1)
        if not re.search(r"\bclass=", attrs, re.I):
            attrs += ' class="md-image"'
        return f"<img{attrs}>"

    return re.sub(r"<img([^>]*)>", replace, body, flags=re.I)


def external_links_safe(body: str) -> str:
    """Open http(s) links in a new tab with a safe rel attribute."""

    def replace(match: re.Match[str]) -> str:
        attrs = match.group(1)
        href = re.search(r'\bhref=(["\'])(.*?)\1', attrs, re.I | re.S)
        if not href:
            return match.group(0)
        value = html.unescape(href.group(2)).strip().lower()
        if not value.startswith(("http://", "https://")):
            return match.group(0)
        if "target=" not in attrs.lower():
            attrs += ' target="_blank"'
        if "rel=" not in attrs.lower():
            attrs += ' rel="noopener noreferrer"'
        return f"<a{attrs}>"

    return re.sub(r"<a([^>]*)>", replace, body, flags=re.I | re.S)


def sanitize_html(body: str) -> str:
    try:
        import bleach
    except ImportError:
        raise ConversionError("sanitize_dependency_missing") from None
    tags = set(bleach.sanitizer.ALLOWED_TAGS) | {
        "p",
        "div",
        "span",
        "br",
        "hr",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "table",
        "thead",
        "tbody",
        "tr",
        "th",
        "td",
        "pre",
        "code",
        "img",
        "blockquote",
        "ul",
        "ol",
        "li",
        "dl",
        "dt",
        "dd",
        "details",
        "summary",
        "sup",
        "sub",
        "mark",
        "kbd",
    }
    attrs = {
        "*": ["class", "id", "title"],
        "a": ["href", "title", "target", "rel"],
        "img": ["src", "alt", "title", "width", "height"],
        "th": ["align", "colspan", "rowspan"],
        "td": ["align", "colspan", "rowspan"],
        "table": ["class", "border"],
    }
    return bleach.clean(
        body,
        tags=tags,
        attributes=attrs,
        protocols=["http", "https", "mailto", "tel"],
        strip=True,
    )


def markdown_to_html(source: str) -> str:
    try:
        import markdown
    except ImportError:
        raise ConversionError("markdown_dependency_missing") from None
    try:
        return markdown.markdown(
            source,
            extensions=["extra", "admonition", "md_in_html", "sane_lists", "nl2br"],
            output_format="html5",
        )
    except Exception:
        raise ConversionError("markdown_render_failed") from None


def render_markdown(source: str, sanitize: bool) -> tuple[str, dict[str, str]]:
    body, _items, metadata = extract_body_and_toc(source, sanitize)
    return body, metadata


def extract_body_and_toc(source: str, sanitize: bool):
    metadata, body = split_front_matter(source)
    html_body = markdown_to_html(body)
    # Collect heading ids before sanitizing so literal inline HTML in a heading
    # keeps its characters for the anchor while the label is still stripped of
    # tags. Sanitizing afterwards still removes any real raw-HTML payload.
    html_body, toc = heading_ids(html_body)
    if sanitize:
        html_body = sanitize_html(html_body)
    html_body = rewrite_links(html_body)
    html_body = postprocess_tables(html_body)
    html_body = postprocess_images(html_body)
    html_body = external_links_safe(html_body)
    return html_body, toc, metadata


def toc_html(items):
    links = "".join(
        f'<a data-level="{int(item["level"])}" data-target="{html.escape(str(item["id"]), quote=True)}" href="#{html.escape(str(item["id"]), quote=True)}">{html.escape(str(item["title"]))}</a>'
        for item in items
    )
    if not links:
        return ""
    return f"""<aside class="toc" data-md-toc="1"><div class="toc-head"><span class="toc-title">📑 目录导航</span><button class="toc-toggle" type="button" aria-expanded="true">−</button></div><div class="toc-progress"><div><span>阅读进度</span> <span class="toc-percent">0%</span></div><div class="toc-track"><div class="toc-bar"></div></div></div><nav class="toc-nav" aria-label="文档目录">{links}</nav></aside>"""


def build_document(title: str, body: str, items, enhance: bool = True) -> str:
    script = TOC_SCRIPT if (enhance and items) else ""
    return f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=5"><meta name="color-scheme" content="light"><meta name="theme-color" content="#667eea"><title>{html.escape(title)}</title><style>{BASE_CSS}</style></head><body>{toc_html(items)}<main class="container">{body}</main>{script}</body></html>"""


def is_local_asset(value: str) -> bool:
    parts = urlsplit(value)
    return (
        not parts.scheme and not parts.netloc and not value.startswith(("#", "data:"))
    )


def copy_assets(body: str, md_file: Path, input_root: Path, output_file: Path):
    assets_dir = output_file.parent / "assets"
    warnings = []
    copied = 0

    def replace(match: re.Match[str]) -> str:
        nonlocal copied
        quote, raw = match.group(1), html.unescape(match.group(2))
        if not is_local_asset(raw):
            return match.group(0)
        parts = urlsplit(raw)
        source = (md_file.parent / unquote(parts.path)).resolve()
        if (
            not source.is_relative_to(input_root)
            or linklike(source)
            or not source.is_file()
        ):
            warnings.append("asset_not_copied")
            return match.group(0)
        data = source.read_bytes()
        name = f"{source.stem}-{digest(data)[:12]}{source.suffix}"
        ensure_dirs(output_file.parent, assets_dir)
        destination = assets_dir / name
        if not destination.exists():
            atomic_write(destination, data)
            copied += 1
        rebuilt = (
            f"assets/{name}"
            + (("?" + parts.query) if parts.query else "")
            + (("#" + parts.fragment) if parts.fragment else "")
        )
        return f"src={quote}{rebuilt}{quote}"

    return (
        re.sub(r"src=([\"'])(.*?)\1", replace, body, flags=re.I | re.S),
        copied,
        warnings,
    )


def find_files(input_root: Path, output_root: Path, recursive: bool):
    result = []
    visited = 0
    total_bytes = 0

    def walk(directory: Path):
        nonlocal visited, total_bytes
        try:
            entries = sorted(directory.iterdir(), key=lambda p: p.name.casefold())
        except OSError:
            raise ConversionError("input_directory_unreadable") from None
        for path in entries:
            visited += 1
            if visited > MAX_FILES:
                raise ConversionError("directory_entry_limit")
            if path.name.startswith(".") or linklike(path):
                continue
            if path.is_dir() and recursive:
                walk(path)
            elif path.is_file() and path.suffix.lower() in MD_SUFFIXES:
                size = path.stat().st_size
                total_bytes += size
                if size > MAX_FILE_BYTES:
                    raise ConversionError("input_file_over_limit")
                if total_bytes > MAX_TOTAL_BYTES:
                    raise ConversionError("input_batch_over_limit")
                result.append(path)
                if len(result) > MAX_FILES:
                    raise ConversionError("markdown_file_limit")

    walk(input_root)
    return result


def output_for(
    md_file: Path, input_root: Path, output_root: Path, recursive: bool
) -> Path:
    relative = (
        md_file.relative_to(input_root).with_suffix(".html")
        if recursive
        else Path(md_file.name).with_suffix(".html")
    )
    return output_root / relative


def convert_one(
    md_file: Path,
    input_root: Path,
    output_root: Path,
    recursive: bool,
    overwrite: bool,
    sanitize: bool,
    copy_assets_flag: bool,
):
    output = output_for(md_file, input_root, output_root, recursive)
    if output.exists() or output.is_symlink():
        if linklike(output) or not output.is_file():
            raise ConversionError("output_target_is_link_or_not_regular")
        if not overwrite:
            return {
                "source": str(md_file),
                "output": str(output),
                "status": "skipped",
                "reason": "output_exists",
            }
    started = time.perf_counter()
    source, encoding, raw = read_text(md_file)
    body, items, metadata = extract_body_and_toc(source, sanitize)
    copied = 0
    warnings = []
    ensure_dirs(output_root, output.parent)
    if copy_assets_flag:
        body, copied, warnings = copy_assets(body, md_file, input_root, output)
    title = metadata.get("title") or (
        items[0]["title"] if items else md_file.stem.replace("_", " ").replace("-", " ")
    )
    document = build_document(title, body, items, enhance=not sanitize).encode("utf-8")
    atomic_write(output, document)
    return {
        "source": str(md_file),
        "output": str(output),
        "status": "success",
        "encoding": encoding,
        "title": title,
        "toc_items": len(items),
        "assets_copied": copied,
        "warnings": warnings,
        "source_sha256": digest(raw),
        "output_sha256": digest(document),
        "output_bytes": len(document),
        "elapsed_seconds": round(time.perf_counter() - started, 3),
    }


def write_report(output_root: Path, report):
    raw = packed(report) + b"\n"
    if len(raw) > MAX_REPORT_BYTES:
        raise ConversionError("report_over_limit")
    atomic_write(output_root / "conversion_report.json", raw)
    lines = [
        "Markdown → HTML + TOC 报告",
        f"状态：{report['status']}",
        f"总计：{report['summary']['total']}，成功：{report['summary']['success']}，跳过：{report['summary']['skipped']}，失败：{report['summary']['failed']}",
    ]
    lines.extend(
        json.dumps(
            {
                k: item.get(k)
                for k in (
                    "source",
                    "output",
                    "status",
                    "title",
                    "toc_items",
                    "reason",
                    "error",
                )
                if item.get(k) is not None
            },
            ensure_ascii=False,
        )
        for item in report["files"]
    )
    atomic_write(
        output_root / "conversion_report.txt", ("\n".join(lines) + "\n").encode()
    )


def batch(args):
    input_root = safe_root(args.input_dir)
    # Do not resolve() here: resolving would follow a symlinked output directory
    # to its target and hide the link, so the link check in safe_root is done on
    # the literal path. Output is created only after collision pre-checks pass.
    output_root = (
        Path(args.output_dir).expanduser().absolute()
        if args.output_dir
        else DEFAULT_OUTPUT
    )
    if output_root == input_root or output_root.is_relative_to(input_root):
        raise ConversionError("input_output_overlap")
    if output_root.exists() or output_root.is_symlink():
        output_root = safe_root(output_root)
    files = find_files(input_root, output_root, args.recursive)
    outputs = {}
    for md_file in files:
        output = output_for(md_file, input_root, output_root, args.recursive)
        key = os.path.normcase(os.path.normpath(str(output))).casefold()
        if key in outputs:
            raise ConversionError("output_collision")
        outputs[key] = str(md_file)
    if args.dry_run:
        return {
            "version": VERSION,
            "status": "dry_run",
            "input_dir": str(input_root),
            "output_dir": str(output_root),
            "total": len(files),
            "files": [
                {
                    "source": str(p),
                    "output": str(
                        output_for(p, input_root, output_root, args.recursive)
                    ),
                }
                for p in files
            ],
            "writes": False,
        }
    output_root = safe_root(output_root, create=True)
    results = []
    for md_file in files:
        try:
            results.append(
                convert_one(
                    md_file,
                    input_root,
                    output_root,
                    args.recursive,
                    args.overwrite,
                    args.sanitize,
                    args.copy_assets,
                )
            )
        except Exception as error:
            results.append(
                {"source": str(md_file), "status": "failed", "reason": reason(error)}
            )
    summary = {
        "total": len(results),
        "success": sum(x["status"] == "success" for x in results),
        "skipped": sum(x["status"] == "skipped" for x in results),
        "failed": sum(x["status"] == "failed" for x in results),
    }
    report = {
        "version": VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "input_dir": str(input_root),
        "output_dir": str(output_root),
        "recursive": args.recursive,
        "sanitize": args.sanitize,
        "copy_assets": args.copy_assets,
        "summary": summary,
        "files": results,
        "status": "complete" if not summary["failed"] else "partial_failure",
    }
    write_report(output_root, report)
    report["report_path"] = str(output_root / "conversion_report.json")
    return report


def parser():
    p = argparse.ArgumentParser(
        description="批量将 Markdown 转换为带 TOC 的独立 HTML 页面。默认安全清洗原始 HTML。"
    )
    p.add_argument("input_dir", type=Path)
    p.add_argument("output_dir", type=Path, nargs="?", default=None)
    p.add_argument(
        "-r", "--recursive", action="store_true", help="递归转换并保留目录结构"
    )
    p.add_argument("--overwrite", action="store_true", help="明确覆盖已有 HTML")
    p.add_argument(
        "--copy-assets",
        action="store_true",
        help="复制输入目录内的本地图片到输出 assets/",
    )
    p.add_argument(
        "--sanitize",
        action="store_true",
        dest="sanitize",
        default=True,
        help="兼容选项：默认已启用",
    )
    p.add_argument(
        "--unsafe-raw-html",
        action="store_false",
        dest="sanitize",
        help="保留原始 HTML；仅用于已信任输入",
    )
    p.add_argument("--dry-run", action="store_true", help="预检，不写输出或报告")
    p.add_argument("--json", action="store_true", help="单个 JSON 输出")
    p.add_argument(
        "-v", "--version", action="version", version=f"md2html-toc {VERSION}"
    )
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        result = batch(args)
        print(json.dumps(result, ensure_ascii=False, indent=None if args.json else 2))
        return (
            0
            if result["status"] in ("complete", "dry_run")
            and result.get("summary", {}).get("failed", 0) == 0
            else 2
        )
    except Exception as error:
        print(
            json.dumps({"status": "error", "reason": reason(error)}, ensure_ascii=False)
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
