import sys
import unittest
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_DIR / "scripts"))
import watch_tickets  # noqa: E402


class WatchSignatureTests(unittest.TestCase):
    def test_train_signature_changes_when_availability_changes(self):
        base = {
            "results": [{
                "train": "G1", "from": "甲", "to": "乙", "departure": "08:00",
                "arrival": "10:00", "duration": "02:00",
                "prices": [{"seat": "二等座", "price": 100, "availability": "有票"}],
            }]
        }
        changed = {
            "results": [{
                **base["results"][0],
                "prices": [{"seat": "二等座", "price": 100, "availability": "无票"}],
            }]
        }
        self.assertNotEqual(watch_tickets.signature(base), watch_tickets.signature(changed))

    def test_flight_signature_keeps_fare_and_segment_identity(self):
        data = {
            "results": [{
                "ticketPrice": "399.50",
                "journeys": [{"segments": [{
                    "marketingTransportNo": "CA1",
                    "depCityName": "北京", "arrCityName": "上海",
                    "depDateTime": "2099-01-02 08:00:00",
                    "arrDateTime": "2099-01-02 10:00:00",
                }]}],
            }]
        }
        item = watch_tickets.signature(data)[0]
        self.assertEqual(item["price"], "399.50")
        self.assertEqual(item["segments"][0]["marketingTransportNo"], "CA1")


if __name__ == "__main__":
    unittest.main()
