#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const PACKAGE_VERSION = '1.0.16';
const SOURCE = `FlyAI official CLI (@fly-ai/flyai-cli@${PACKAGE_VERSION})`;
const DEFAULT_LIMIT = 10;
const DEFAULT_TIMEOUT_MS = 60_000;
const DEFAULT_SORT_TYPE = 3;
const SHANGHAI_TIME_ZONE = 'Asia/Shanghai';
const CLI_PATH = path.join(
  __dirname,
  '..',
  'node_modules',
  '@fly-ai',
  'flyai-cli',
  'dist',
  'flyai-bundle.cjs',
);

class AdapterError extends Error {
  constructor(code, message, hint) {
    super(message);
    this.name = 'AdapterError';
    this.code = code;
    this.hint = hint;
  }
}

function usage() {
  return `Usage: node china-flight-adapter.cjs --from <city|airport> --to <city|airport> [options]

Query official FlyAI flight inventory without requiring a user API key.

Options:
  --from, --origin <value>       Departure Chinese city or airport code (required)
  --to, --destination <value>   Arrival Chinese city or airport code (required)
  --date, --dep-date <date>     Departure date, YYYY-MM-DD (default: Shanghai date + 7 days)
  --limit <n>                   Number of returned records, 1-50 (default: 10)
  --sort-type <1-8>             FlyAI sort order (default: 3, price ascending)
  --sort <price|duration|arrival|departure>  Local result sort (default: upstream order)
  --direct-only                 Keep direct flights only
  --max-stops <n>               Maximum number of stops (default: unlimited)
  --max-transfer-minutes <n>   Maximum total transfer wait
  --avoid-overnight             Exclude routes arriving on a later date
  --departure-after <HH:MM>     Earliest departure time
  --arrival-before <HH:MM>      Latest arrival time
  --prefer-airline <name|code>  Keep matching marketed airlines (repeatable/comma-separated)
  --same-airport-only          Exclude unknown/change-airport connections
  --same-terminal-only         Exclude unknown/change-terminal connections
  --min-connection-minutes <n> User-specified minimum per connection (not official MCT)
  --timeout-ms <n>              Upstream timeout (default: 60000)
  --json                        Accepted for scripting; JSON is always printed on success
  --help                        Show this help

Examples:
  node china-flight-adapter.cjs --from 北京 --to 上海 --date 2026-10-09 --limit 5
  node china-flight-adapter.cjs --origin PEK --destination SHA --date 2026-10-09
`;
}

function optionValue(argv, index, option) {
  const value = argv[index + 1];
  if (!value || value.startsWith('--')) {
    throw new AdapterError('INVALID_ARGUMENT', `${option} requires a value`, usage());
  }
  return value;
}

function parseArgs(argv) {
  const options = {
    from: undefined,
    to: undefined,
    date: undefined,
    limit: DEFAULT_LIMIT,
    sortType: DEFAULT_SORT_TYPE,
    sort: undefined,
    directOnly: false,
    maxStops: undefined,
    maxTransferMinutes: undefined,
    avoidOvernight: false,
    departureAfter: undefined,
    arrivalBefore: undefined,
    preferredAirlines: [],
    timeoutMs: DEFAULT_TIMEOUT_MS,
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    switch (arg) {
      case '--from':
      case '--origin':
        options.from = optionValue(argv, i, arg);
        i += 1;
        break;
      case '--to':
      case '--destination':
        options.to = optionValue(argv, i, arg);
        i += 1;
        break;
      case '--date':
      case '--dep-date':
        options.date = optionValue(argv, i, arg);
        i += 1;
        break;
      case '--limit':
        options.limit = parsePositiveInteger(optionValue(argv, i, arg), '--limit');
        i += 1;
        if (options.limit > 50) {
          throw new AdapterError('INVALID_ARGUMENT', '--limit must be between 1 and 50', usage());
        }
        break;
      case '--sort-type':
        options.sortType = parsePositiveInteger(optionValue(argv, i, arg), '--sort-type');
        i += 1;
        if (options.sortType < 1 || options.sortType > 8) {
          throw new AdapterError('INVALID_ARGUMENT', '--sort-type must be between 1 and 8', usage());
        }
        break;
      case '--sort':
        options.sort = optionValue(argv, i, arg);
        i += 1;
        if (!['price', 'duration', 'arrival', 'departure'].includes(options.sort)) {
          throw new AdapterError('INVALID_ARGUMENT', '--sort must be price, duration, arrival, or departure', usage());
        }
        break;
      case '--direct-only':
        options.directOnly = true;
        break;
      case '--max-stops':
        options.maxStops = parseNonNegativeInteger(optionValue(argv, i, arg), '--max-stops');
        i += 1;
        break;
      case '--max-transfer-minutes':
        options.maxTransferMinutes = parseNonNegativeInteger(optionValue(argv, i, arg), '--max-transfer-minutes');
        i += 1;
        break;
      case '--avoid-overnight':
        options.avoidOvernight = true;
        break;
      case '--departure-after':
        options.departureAfter = parseClock(optionValue(argv, i, arg), '--departure-after');
        i += 1;
        break;
      case '--arrival-before':
        options.arrivalBefore = parseClock(optionValue(argv, i, arg), '--arrival-before');
        i += 1;
        break;
      case '--same-airport-only':
        options.sameAirportOnly = true;
        break;
      case '--same-terminal-only':
        options.sameTerminalOnly = true;
        break;
      case '--min-connection-minutes':
        options.minConnectionMinutes = parseNonNegativeInteger(optionValue(argv, i, arg), arg);
        i += 1;
        break;
      case '--prefer-airline':
      case '--airline':
        options.preferredAirlines.push(...parseAirlinePreferences(optionValue(argv, i, arg), arg));
        i += 1;
        break;
      case '--timeout-ms':
        options.timeoutMs = parsePositiveInteger(optionValue(argv, i, arg), '--timeout-ms');
        i += 1;
        break;
      case '--json':
        break;
      case '--help':
      case '-h':
        options.help = true;
        break;
      default:
        throw new AdapterError('INVALID_ARGUMENT', `Unknown argument: ${arg}`, usage());
    }
  }

  if (options.help) return options;
  if (!options.from || !options.from.trim()) {
    throw new AdapterError('INVALID_ARGUMENT', '--from is required', usage());
  }
  if (!options.to || !options.to.trim()) {
    throw new AdapterError('INVALID_ARGUMENT', '--to is required', usage());
  }

  options.from = options.from.trim();
  options.to = options.to.trim();
  options.date = options.date || shanghaiDatePlusDays(7);
  validateDate(options.date);
  if (options.date < shanghaiDateString()) {
    throw new AdapterError(
      'INVALID_ARGUMENT',
      `--date must not be before today's Shanghai date (${shanghaiDateString()})`,
      'Use TZ=Asia/Shanghai date context or pass a future YYYY-MM-DD.',
    );
  }
  return options;
}

function parseNonNegativeInteger(value, name) {
  if (!/^\d+$/.test(value)) {
    throw new AdapterError('INVALID_ARGUMENT', `${name} must be a non-negative integer`, usage());
  }
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed < 0) {
    throw new AdapterError('INVALID_ARGUMENT', `${name} must be a non-negative integer`, usage());
  }
  return parsed;
}

function parseClock(value, name) {
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(value)) {
    throw new AdapterError('INVALID_ARGUMENT', `${name} must use HH:MM`, usage());
  }
  return value;
}

function parsePositiveInteger(value, name) {
  if (!/^\d+$/.test(value)) {
    throw new AdapterError('INVALID_ARGUMENT', `${name} must be a positive integer`, usage());
  }
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed < 1) {
    throw new AdapterError('INVALID_ARGUMENT', `${name} must be a positive integer`, usage());
  }
  return parsed;
}

function parseAirlinePreferences(value, option) {
  const preferences = String(value)
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
  if (!preferences.length) {
    throw new AdapterError('INVALID_ARGUMENT', `${option} requires a non-empty airline name or code`, usage());
  }
  return preferences;
}

function normaliseAirlineValue(value) {
  if (typeof value === 'string' || typeof value === 'number') return String(value).trim();
  if (!value || typeof value !== 'object') return '';
  return [value.name, value.airlineName, value.code, value.airlineCode, value.iataCode]
    .find((item) => item !== undefined && item !== null && String(item).trim())?.toString().trim() || '';
}

function segmentAirlineValues(segment) {
  const values = [
    segment?.marketingTransportName,
    segment?.marketingAirlineName,
    segment?.marketingCarrierName,
    segment?.airlineName,
    segment?.carrierName,
    segment?.companyName,
    segment?.airline,
    segment?.carrier,
    segment?.marketingAirline,
    segment?.marketingCarrier,
    segment?.airlineCode,
    segment?.carrierCode,
    segment?.marketingAirlineCode,
    segment?.iataAirlineCode,
  ].flatMap((value) => value && typeof value === 'object'
    ? [value.name, value.code, value.airlineName, value.airlineCode, value.iataCode]
    : [value]).map(normaliseAirlineValue).filter(Boolean);
  // The marketed flight designator explicitly contains its IATA carrier code.
  const code = String(segment?.marketingTransportNo || '').match(/^([A-Z0-9]{2})\d{3,4}$/i)?.[1];
  if (code) values.push(code.toUpperCase());
  return [...new Set(values)];
}

function recordAirlines(record) {
  const journey = (record?.journeys || [])[0] || {};
  return [...new Set([record, journey, ...(journey.segments || [])].flatMap(segmentAirlineValues))];
}

function validateDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    throw new AdapterError('INVALID_ARGUMENT', '--date must use YYYY-MM-DD', usage());
  }
  const [year, month, day] = value.split('-').map(Number);
  const check = new Date(Date.UTC(year, month - 1, day));
  if (
    check.getUTCFullYear() !== year ||
    check.getUTCMonth() !== month - 1 ||
    check.getUTCDate() !== day
  ) {
    throw new AdapterError('INVALID_ARGUMENT', `Invalid calendar date: ${value}`, usage());
  }
}

function shanghaiDateString(now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: SHANGHAI_TIME_ZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(now);
  const values = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function shanghaiDatePlusDays(days, now = new Date()) {
  const date = new Date(`${shanghaiDateString(now)}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

function buildCliArgs(options) {
  return [
    'search-flight',
    '--origin',
    options.from,
    '--destination',
    options.to,
    '--dep-date',
    options.date,
    '--sort-type',
    String(options.sortType),
  ];
}

function keylessEnvironment() {
  const env = { ...process.env };
  // Never read or forward a user's FlyAI/API credential. The official bundle's
  // built-in trial authorization is used when these variables are absent.
  for (const key of [
    'FLYAI_API_KEY',
    'DEBUG_FLYAI_API_KEY',
    'FLYAI_SIGN_SECRET',
    'DEBUG_FLYAI_MCP_URL',
    'FLYAI_MCP_URL',
    'FLYAI_PROFILE',
  ]) {
    delete env[key];
  }

  // Keep the CLI away from a user's home-directory FlyAI config. This also
  // makes the adapter genuinely no-setup for a clean skill subprocess.
  const isolatedHome = fs.mkdtempSync(path.join(os.tmpdir(), 'china-flight-home-'));
  env.HOME = isolatedHome;
  env.USERPROFILE = isolatedHome;
  env.XDG_CONFIG_HOME = path.join(isolatedHome, '.config');
  return { env, isolatedHome };
}

function runOfficialCli(options, cliPath = CLI_PATH) {
  if (!fs.existsSync(cliPath)) {
    throw new AdapterError(
      'DEPENDENCY_MISSING',
      `Official FlyAI CLI bundle not found: ${cliPath}`,
      'Run npm install --ignore-scripts in the china-travel-tickets skill directory.',
    );
  }

  const isolated = keylessEnvironment();
  let result;
  try {
    result = spawnSync(
      process.execPath,
      [cliPath, ...buildCliArgs(options)],
      {
        cwd: __dirname,
        env: isolated.env,
        encoding: 'utf8',
        timeout: options.timeoutMs,
        maxBuffer: 20 * 1024 * 1024,
      },
    );
  } finally {
    fs.rmSync(isolated.isolatedHome, { recursive: true, force: true });
  }

  return {
    exitCode: result.status,
    stdout: result.stdout || '',
    stderr: [result.stderr || '', result.error?.message || ''].filter(Boolean).join('\n'),
    signal: result.signal || undefined,
  };
}

function parsePayload(stdout) {
  const text = String(stdout || '').trim();
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function connectionDetails(segments) {
  const time = (value) => {
    if (!value) return NaN;
    const iso = String(value).replace(' ', 'T');
    return Date.parse(/(?:Z|[+-]\d{2}:?\d{2})$/.test(iso) ? iso : `${iso}+08:00`);
  };
  const compare = (left, right) => left && right ? String(left).trim().toUpperCase() === String(right).trim().toUpperCase() : null;
  return segments.slice(1).map((next, i) => {
    const previous = segments[i];
    const wait = (time(next.depDateTime) - time(previous.arrDateTime)) / 60000;
    const sameAirport = previous.arrStationCode && next.depStationCode
      ? compare(previous.arrStationCode, next.depStationCode)
      : compare(previous.arrStationName, next.depStationName);
    return { waitMinutes: Number.isFinite(wait) && wait >= 0 ? wait : null,
      sameAirport, sameTerminal: sameAirport === true ? compare(previous.arrTerm, next.depTerm) : sameAirport === false ? false : null };
  });
}

function recordDetails(record) {
  const journey = (record?.journeys || [])[0] || {};
  const segments = journey.segments || [];
  const first = segments[0] || {};
  const last = segments[segments.length - 1] || {};
  const departure = first.depDateTime || first.departureDateTime || '';
  const arrival = last.arrDateTime || last.arrivalDateTime || '';
  const numeric = (value, fallback = null) => {
    if (value === null || value === undefined || String(value).trim() === '') return fallback;
    const parsed = Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? parsed : fallback;
  };
  const priceRaw = record.ticketPrice ?? record.adultPrice;
  const price = numeric(String(priceRaw ?? '').replace(/[¥￥,\s]/g, ''));
  const connections = connectionDetails(segments);
  const transfer = segments.length === 1 ? 0 : numeric(record.transferDuration ?? journey.transferDuration,
    connections.length && connections.every((c) => c.waitMinutes !== null) ? connections.reduce((sum, c) => sum + c.waitMinutes, 0) : null);
  return {
    segments,
    airlines: recordAirlines(record),
    connections,
    stops: segments.length ? segments.length - 1 + segments.reduce((sum, s) => sum + (Array.isArray(s.stopInfos) ? s.stopInfos.length : 0), 0) : null,
    departure,
    arrival,
    departureClock: departure.slice(11, 16),
    arrivalClock: arrival.slice(11, 16),
    departureDate: departure.slice(0, 10),
    arrivalDate: arrival.slice(0, 10),
    duration: numeric(record.totalDuration ?? journey.totalDuration),
    transfer,
    price,
  };
}

function filterAndSortResults(records, options) {
  const filtered = records.filter((record) => {
    const details = recordDetails(record);
    if (options.directOnly && details.stops !== 0) return false;
    if (options.maxStops !== undefined && (details.stops === null || details.stops > options.maxStops)) return false;
    if (options.maxTransferMinutes !== undefined && (details.transfer === null || details.transfer > options.maxTransferMinutes)) return false;
    if (options.avoidOvernight && (!details.departureDate || !details.arrivalDate || details.departureDate !== details.arrivalDate)) return false;
    if (options.departureAfter && (!details.departureClock || details.departureClock < options.departureAfter)) return false;
    if (options.arrivalBefore && (!details.arrivalClock || details.arrivalClock > options.arrivalBefore)) return false;
    if ((options.sameAirportOnly || options.sameTerminalOnly || options.minConnectionMinutes !== undefined) && !details.segments.length) return false;
    if (options.sameAirportOnly && details.connections.some((c) => c.sameAirport !== true)) return false;
    if (options.sameTerminalOnly && details.connections.some((c) => c.sameTerminal !== true)) return false;
    if (options.minConnectionMinutes !== undefined && details.connections.some((c) => c.waitMinutes === null || c.waitMinutes < options.minConnectionMinutes)) return false;
    if (
      options.preferredAirlines?.length
      && !details.airlines.some((airline) => options.preferredAirlines.some(
        (preferred) => airline.localeCompare(preferred, undefined, { sensitivity: 'accent' }) === 0,
      ))
    ) return false;
    return true;
  });
  if (!options.sort) return filtered;
  const value = (record) => {
    const details = recordDetails(record);
    if (options.sort === 'price') return details.price ?? Number.POSITIVE_INFINITY;
    if (options.sort === 'duration') return details.duration ?? Number.POSITIVE_INFINITY;
    if (options.sort === 'arrival') return details.arrival || '\uffff';
    return details.departure || '\uffff';
  };
  return filtered.sort((a, b) => {
    const left = value(a);
    const right = value(b);
    return left < right ? -1 : left > right ? 1 : 0;
  });
}

function classifyError(text, exitCode, signal) {
  const lower = String(text || '').toLowerCase();
  if (signal || lower.includes('timed out') || lower.includes('timeout')) {
    return {
      code: 'UPSTREAM_TIMEOUT',
      message: 'FlyAI did not answer before the timeout.',
      hint: 'Retry later; no fare is reported when the official query is incomplete.',
    };
  }
  if (
    lower.includes('quota') ||
    lower.includes('rate limit') ||
    lower.includes('too many') ||
    lower.includes('429') ||
    lower.includes('次数') ||
    lower.includes('额度')
  ) {
    return {
      code: 'TRIAL_QUOTA_EXCEEDED',
      message: 'The FlyAI no-key trial quota appears exhausted or rate-limited.',
      hint: 'Wait and retry, or configure an official key in the upstream FlyAI CLI if permitted.',
    };
  }
  if (
    lower.includes('unauthorized') ||
    lower.includes('forbidden') ||
    lower.includes('authentication') ||
    lower.includes('api key') ||
    lower.includes('token') ||
    lower.includes('401') ||
    lower.includes('403') ||
    lower.includes('鉴权') ||
    lower.includes('认证') ||
    lower.includes('密钥')
  ) {
    return {
      code: 'TRIAL_AUTH_REQUIRED',
      message: 'FlyAI rejected the no-key trial request; registration or an official API key may now be required.',
      hint: 'See https://flyai.open.fliggy.com/docs/quickstart and https://flyai.open.fliggy.com/console.',
    };
  }
  return {
    code: exitCode === null ? 'UPSTREAM_PROCESS_ERROR' : 'FLYAI_QUERY_FAILED',
    message: 'The official FlyAI flight query failed.',
    hint: 'No fare has been fabricated; inspect the upstream status and retry later.',
  };
}

function redactDiagnostics(text) {
  return String(text || '')
    .replace(/Bearer\s+[A-Za-z0-9._+/=-]+/gi, 'Bearer [redacted]')
    .replace(/(?:api[_ -]?key|token|secret|authorization)["'=: ]+[A-Za-z0-9._+/=-]{8,}/gi, '$1 [redacted]')
    .slice(0, 800);
}

function query(options, dependencies = {}) {
  const runner = dependencies.runner || runOfficialCli;
  const now = dependencies.now || new Date();
  const result = runner(options);
  const payload = parsePayload(result.stdout);
  const itemList = payload?.data?.itemList;

  if (result.exitCode === 0 && payload && payload.status === 0 && Array.isArray(itemList)) {
    const filtered = filterAndSortResults(itemList, options);
    const output = {
      source: SOURCE,
      timestamp: now.toISOString(),
      query: {
        from: options.from,
        to: options.to,
        date: options.date,
        limit: options.limit,
        filters: {
          sort: options.sort || null,
          directOnly: options.directOnly,
          maxStops: options.maxStops ?? null,
          maxTransferMinutes: options.maxTransferMinutes ?? null,
          avoidOvernight: options.avoidOvernight,
          departureAfter: options.departureAfter || null,
          arrivalBefore: options.arrivalBefore || null,
          preferredAirlines: options.preferredAirlines || [],
          sameAirportOnly: !!options.sameAirportOnly,
          sameTerminalOnly: !!options.sameTerminalOnly,
          minConnectionMinutes: options.minConnectionMinutes ?? null,
        },
      },
      status: payload.status,
      message: payload.message,
      availableCount: itemList.length,
      filteredCount: filtered.length,
      resultCount: Math.min(filtered.length, options.limit),
      results: filtered.slice(0, options.limit),
    };
    if (typeof payload.systemMessage === 'string' && payload.systemMessage) {
      output.systemMessage = payload.systemMessage;
    }
    return output;
  }

  const upstreamText = [payload?.message, result.stderr, result.stdout]
    .filter(Boolean)
    .join('\n');
  const classified = classifyError(upstreamText, result.exitCode, result.signal);
  throw new AdapterError(
    classified.code,
    `${classified.message}${payload?.message ? ` Upstream: ${payload.message}` : ''}`,
    `${classified.hint}${result.stderr ? ` Diagnostic: ${redactDiagnostics(result.stderr)}` : ''}`,
  );
}

function main() {
  try {
    const options = parseArgs(process.argv.slice(2));
    if (options.help) {
      process.stdout.write(usage());
      return 0;
    }
    process.stdout.write(`${JSON.stringify(query(options))}\n`);
    return 0;
  } catch (error) {
    const adapterError = error instanceof AdapterError
      ? error
      : new AdapterError('UNEXPECTED_ERROR', error.message || String(error), 'No fare was reported.');
    process.stderr.write(`china-flight-adapter: ${adapterError.code}: ${adapterError.message}\n`);
    if (adapterError.hint) process.stderr.write(`${adapterError.hint}\n`);
    return 1;
  }
}

if (require.main === module) {
  process.exitCode = main();
}

module.exports = {
  SOURCE,
  AdapterError,
  buildCliArgs,
  classifyError,
  parseArgs,
  parseAirlinePreferences,
  parsePayload,
  query,
  recordAirlines,
  recordDetails,
  redactDiagnostics,
  shanghaiDatePlusDays,
  shanghaiDateString,
  validateDate,
};
