# 验证

## 自动测试

```bash
cd "$HOME/.config/freebuff/skills/cf-pages-deploy"
python3 -B -m black --config /dev/null scripts/cf_pages_deploy.py tests/test_cf_pages_deploy.py
PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest discover -s tests
```

结果：**34 tests, OK**（Python 3.12.10；requests 2.32.5；PyYAML 6.0.2；wrangler 4.127.1）。
`black --check` 通过（exit 0）。

覆盖范围（`tests/test_cf_pages_deploy.py`）：

- `parse_env_file` 处理注释、空行、`export`、单双引号；`load_env_files` 不覆盖真实环境变量；`credentials()` 兼容 `CF_*` 与 `CLOUDFLARE_*`。
- 配置：`source_dir` 相对配置目录解析；非法项目名报 `invalid_project_name`；缺失配置报 `config_not_found`。
- `discover`：识别含 HTML 的一级子目录、忽略空/隐藏目录、目录名规范化、无站点时报 `discover_found_no_sites`。
- 哈希：目录哈希稳定且随内容变化；文件模式；`count_html`；路径缺失报 `source_not_found`。
- wrangler：命令包含 project/branch/`--commit-dirty=true`/`--commit-message`/`--skip-caching`；URL 解析取最后一个；失败后重试再成功；超时返回失败。
- dry-run：不调用 wrangler、不联网、不写状态；坏站点被隔离为 `failed` 而不中断整批。
- 部署：缺失项目被创建、已存在不重建、成功后记录状态与哈希；未变更站点 `skipped(unchanged)` 且不降级成功记录；`--force` 强制重部署；内容变化自动重部署；`--retry-failed` 跳过成功项。
- 失败路径：`wrangler_failed` 带截断 detail；`create_if_missing=false` 且项目缺失时报 `project_missing` 且不调用 wrangler。
- 并行：`--jobs 3` 三个项目全部成功，状态齐全。
- API 客户端：分页使用 `per_page=10`（避免 Cloudflare 400/8000024）；单项目 404 → `None`；缺凭证报 `credentials_missing`。
- CLI：`--help` 退出 0；真实子进程 `deploy --config … --dry-run --json` 退出 0 且 `status=dry_run`；`discover --output` 生成可被 `load_config` 回读的配置（含空格路径单行加引号）。

## 只读真实集成验证

用 `~/.config/freebuff/.env` 中的凭证对真实账户执行**只读**操作：

```bash
python3 scripts/cf_pages_deploy.py list
```

结果（HTTP 200）：账户下 6 个 Pages 项目被正确列出——
`pont-decode, voyage, voyage-planner-shop, storyline-cloudflare, events-timeline, md2mindmap`。
同时确认单项目端点 `GET …/pages/projects/voyage` → 200，缺失项目 → 404（用于存在性判定）。

## 端到端 smoke（无副作用）

```bash
python3 scripts/cf_pages_deploy.py discover --root <fixture> --output cf.yaml
python3 scripts/cf_pages_deploy.py deploy --config cf.yaml --dry-run --json
```

- `discover` 生成配置，含 `"…/Beta Site"` 单行加引号。
- `dry-run` 报告 `status=dry_run, summary={total:2, planned:2}`，未写入状态文件、无输出目录。

## 未执行

- **真实部署写入**（创建项目 / 上传到生产或预览分支）未在此环境中执行，因为它是对用户 Cloudflare 账户的外部副作用；相关路径已由上述单元测试以 mock 覆盖，凭证与项目查询已用真实只读调用验证。首次真实部署建议先 `--dry-run`，再用非生产 `branch` 试跑。
