#!/bin/bash
# 方案2: 子路径部署 — 检测所有登山路线（本地index-*.html + 子目录index.html）
set -uo pipefail

TOKEN_FILE="$HOME/.config/opencode/.env"
TOKEN=$(grep -s -o 'VERCEL_TOKEN=[^[:space:]]*' "$TOKEN_FILE" | head -1 | cut -d= -f2-)
SCOPE="seigneurtsuis-projects"
PROJECT="toc"
BASE_DIR="$HOME/Downloads/mountain-climber"
DEPLOY_DIR="/tmp/climb-deploy"
PROD_URL="line.allez.cc.cd"

rm -rf "$DEPLOY_DIR"
mkdir -p "$DEPLOY_DIR/toc"

declare -a TRIP_LIST=()
add_trip() {
  local src="$1" slug="$2" name="$3" emoji="$4" elev="$5" dist="$6" gain="$7"
  TRIP_LIST+=("$src|$slug|$name|$emoji|$elev|$dist|$gain")
}

# —— 根页面保底：如果 root index.html 缺失，自动恢复 ——
if [ ! -f "$BASE_DIR/index.html" ]; then
  LATEST=$(ls -t "$BASE_DIR"/index-*.html 2>/dev/null | head -1)
  if [ -n "$LATEST" ]; then
    cp "$LATEST" "$BASE_DIR/index.html"
    echo "⚠️  根 index.html 缺失，已从 $(basename "$LATEST") 自动恢复"
  else
    echo "❌ 错误: $BASE_DIR 下既无 index.html 也无 index-*.html 备份" >&2
    exit 1
  fi
fi

# —— 标题去重表 ——
declare -A SEEN_TITLES

extract_title() {
  local file="$1"
  grep -o '<h1>[^<]*</h1>' "$file" 2>/dev/null | head -1 | sed 's/<h1>//' | sed 's/<\/h1>//' | sed 's/^ *//' | sed 's/ *$//' | xargs
}

# 1. 从 index-*.html 文件自动检测
for f in "$BASE_DIR"/index-*.html; do
  [ -f "$f" ] || continue
  BASENAME=$(basename "$f")
  [[ "$BASENAME" == *"toc"* ]] && continue
  TRIP_NAME=$(echo "$BASENAME" | sed 's/^index-//' | sed 's/-[0-9]\{8\}\.html$//' | sed 's/^-\+//' | sed 's/-$//')
  EMOJI=$(echo "$BASENAME" | grep -o '[🏔️⛰️🌋🗻]' | head -1)
  [ -z "$EMOJI" ] && EMOJI="🏔️"
  ELEV=$(grep -oE '(海拔|elevation)[^0-9]*[0-9]{3,4}m' "$f" 2>/dev/null | head -1 | grep -oE '[0-9]{3,4}m' || echo "")
  DIST=$(grep -oE '全程[^0-9]*[0-9]+' "$f" 2>/dev/null | head -1 | grep -oE '[0-9]+' | head -1 || echo "")
  GAIN=$(grep -oE '累计爬升[^0-9]*[0-9]+' "$f" 2>/dev/null | head -1 | grep -oE '[0-9]+' | head -1 || echo "")
  SLUG="climb-$(echo "$TRIP_NAME" | md5 | head -c 6)"
  FILE_TITLE=$(extract_title "$f")
  if [ -n "$FILE_TITLE" ] && [ -n "${SEEN_TITLES[$FILE_TITLE]:-}" ]; then
    echo "  ⏭️  跳过重复: $BASENAME"
    continue
  fi
  add_trip "$BASENAME" "$SLUG" "$TRIP_NAME" "$EMOJI" "$ELEV" "$DIST" "$GAIN"
  [ -n "$FILE_TITLE" ] && SEEN_TITLES[$FILE_TITLE]="$SLUG"
  echo "📋 /$SLUG/ → $TRIP_NAME ($EMOJI) [file]"
done

# 2. 从子目录 index.html 自动检测
for dir in "$BASE_DIR"/*/; do
  [ -f "${dir}index.html" ] || continue
  DIRNAME=$(basename "$dir")
  [[ "$DIRNAME" == "toc" || "$DIRNAME" == ".vercel" ]] && continue
  FILESIZE=$(wc -c < "${dir}index.html")
  [ "$FILESIZE" -lt 1000 ] && continue
  SLUG="$DIRNAME"
  TRIP_NAME=$(grep -o '<h1>[^<]*</h1>' "${dir}index.html" 2>/dev/null | head -1 | sed 's/<[^>]*>//g' | xargs)
  [ -z "$TRIP_NAME" ] && TRIP_NAME="$DIRNAME"
  EMOJI=$(echo "$TRIP_NAME" | grep -o '[🏔️⛰️🌋🗻]' | head -1)
  [ -z "$EMOJI" ] && EMOJI="🏔️"
  ELEV=$(grep -oE '(海拔|elevation)[^0-9]*[0-9]{3,4}m' "${dir}index.html" 2>/dev/null | head -1 | grep -oE '[0-9]{3,4}m' || echo "")
  DIST=$(grep -oE '全程[^0-9]*[0-9]+' "${dir}index.html" 2>/dev/null | head -1 | grep -oE '[0-9]+' | head -1 || echo "")
  GAIN=$(grep -oE '累计爬升[^0-9]*[0-9]+' "${dir}index.html" 2>/dev/null | head -1 | grep -oE '[0-9]+' | head -1 || echo "")
  DIR_TITLE=$(extract_title "${dir}index.html")
  if [ -n "$DIR_TITLE" ] && [ -n "${SEEN_TITLES[$DIR_TITLE]:-}" ]; then
    echo "  ⏭️  跳过重复子目录: $DIRNAME"
    continue
  fi
  ALREADY=0
  for entry in "${TRIP_LIST[@]}"; do
    E_SLUG=$(echo "$entry" | cut -d'|' -f2)
    [ "$E_SLUG" == "$SLUG" ] && ALREADY=1 && break
  done
  if [ $ALREADY -eq 0 ]; then
    add_trip "$DIRNAME/index.html" "$SLUG" "$TRIP_NAME" "$EMOJI" "$ELEV" "$DIST" "$GAIN"
    [ -n "$DIR_TITLE" ] && SEEN_TITLES[$DIR_TITLE]="$SLUG"
    echo "📋 /$SLUG/ → $TRIP_NAME ($EMOJI) [dir]"
  fi
done

echo ""
echo "📊 共 ${#TRIP_LIST[@]} 条登山路线"

# 复制行程 HTML
echo ""
echo "📦 准备子路径..."
for entry in "${TRIP_LIST[@]}"; do
  IFS='|' read -r SRC SLUG TRIP_NAME EMOJI ELEV DIST GAIN <<< "$entry"
  mkdir -p "$DEPLOY_DIR/$SLUG"
  cp "$BASE_DIR/$SRC" "$DEPLOY_DIR/$SLUG/index.html"
  # 复制 lib 目录（Leaflet 资源）
  if [ -d "$BASE_DIR/lib" ]; then
    cp -r "$BASE_DIR/lib" "$DEPLOY_DIR/$SLUG/"
  fi
  echo "  📁 $SLUG/ → $TRIP_NAME"
done

# 生成 /toc/ 目录页
echo ""
echo "📄 生成 /toc/ 目录页..."
TODAY=$(date +%Y-%m-%d)

TRIPS_JSON="["
FIRST=1
for entry in "${TRIP_LIST[@]}"; do
  IFS='|' read -r SRC SLUG TRIP_NAME EMOJI ELEV DIST GAIN <<< "$entry"
  [ $FIRST -eq 0 ] && TRIPS_JSON+=","
  FIRST=0
  CLEAN_TITLE=$(echo "$TRIP_NAME" | sed 's/"/\\"/g' | sed "s/'/\\\\'/g")
  TRIPS_JSON+="{\"slug\":\"$SLUG\",\"title\":\"$CLEAN_TITLE\",\"date\":\"$TODAY\",\"elev\":\"$ELEV\",\"dist\":\"$DIST\",\"gain\":\"$GAIN\",\"title_lower\":\"$(echo "$CLEAN_TITLE" | tr '[:upper:]' '[:lower:]')\"}"
done
TRIPS_JSON+="]"

# 生成卡片 HTML
CARDS_HTML=""
for entry in "${TRIP_LIST[@]}"; do
  IFS='|' read -r SRC SLUG TRIP_NAME EMOJI ELEV DIST GAIN <<< "$entry"
  CLEAN_TITLE=$(echo "$TRIP_NAME" | sed 's/"/\\"/g' | sed "s/'/\\\\'/g")
  STATS_DISP=""
  if [ -n "$DIST" ] && [ -n "$GAIN" ]; then
    STATS_DISP="📏 ${DIST}km · ⛰️ ${GAIN}m"
  elif [ -n "$DIST" ]; then
    STATS_DISP="📏 ${DIST}km"
  elif [ -n "$GAIN" ]; then
    STATS_DISP="⛰️ ${GAIN}m"
  fi
  if [ -n "$STATS_DISP" ]; then
    STATS_DISP="<div class=\"card-stats\">$STATS_DISP</div>"
  fi
  CARDS_HTML+="<a href=\"/$SLUG/\" target=\"_blank\" rel=\"noopener\" class=\"card\" data-title=\"$CLEAN_TITLE\" data-date=\"$TODAY\" data-slug=\"$SLUG\" data-dist=\"$DIST\" data-elev=\"$GAIN\"><div class=\"card-title\">$EMOJI $CLEAN_TITLE</div>$STATS_DISP<div class=\"card-meta\">📅 $TODAY · 🔗 /$SLUG/</div></a>
"
done

# 使用本地 toc/index.html 作为模板 — 若不存在则生成
TOC_TPL="$BASE_DIR/toc/index.html"
if [ -f "$TOC_TPL" ]; then
  cp "$TOC_TPL" "$DEPLOY_DIR/toc/index.html"
else
  # 生成默认 toc 页面
  cat > "$DEPLOY_DIR/toc/index.html" << 'TOCEOF'
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🏔️ 登山路线目录</title>
<style>
  * { box-sizing: border-box; }
  body {
    margin: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif;
    background: #0a1929; color: #e0e0e0; line-height: 1.6;
    min-height: 100vh; display: flex; flex-direction: column; align-items: center;
    padding: 40px 20px;
  }
  .header { text-align: center; margin-bottom: 32px; }
  .header h1 {
    font-size: 28px; margin: 0 0 8px;
    background: linear-gradient(135deg, #4caf50, #ff9800);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  }
  .header p { color: #90a4ae; font-size: 14px; margin: 0; }
  .toolbar {
    display: flex; flex-wrap: wrap; gap: 10px; align-items: center;
    max-width: 960px; width: 100%; margin-bottom: 20px;
  }
  .search-wrapper {
    flex: 1; min-width: 200px; display: flex; align-items: center;
    position: relative;
  }
  .search-box {
    width: 100%; padding: 10px 36px 10px 14px; border-radius: 8px;
    border: 1px solid rgba(255,255,255,0.12); background: rgba(255,255,255,0.05);
    color: #e0e0e0; font-size: 14px; outline: none;
  }
  .search-box:focus { border-color: #ff9800; }
  .search-box::placeholder { color: #546e7a; }
  .clear-btn {
    position: absolute; right: 8px; top: 50%; transform: translateY(-50%);
    width: 22px; height: 22px; border-radius: 50%; border: none;
    background: rgba(255,255,255,0.1); color: #90a4ae; font-size: 12px;
    cursor: pointer; display: none; align-items: center; justify-content: center;
    line-height: 1; padding: 0; transition: all .15s;
  }
  .clear-btn:hover { background: rgba(255,255,255,0.2); color: #e0e0e0; }
  .clear-btn.visible { display: flex; }
  .sort-btn {
    padding: 8px 14px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.12);
    background: rgba(255,255,255,0.05); color: #b0bec5; font-size: 13px;
    cursor: pointer; transition: all .2s; white-space: nowrap;
  }
  .sort-btn:hover { background: rgba(255,255,255,0.08); color: #e0e0e0; }
  .sort-btn.active { background: rgba(76,175,80,0.15); color: #81c784; border-color: rgba(76,175,80,0.3); }
  .export-btn {
    padding: 8px 14px; border-radius: 8px; border: 1px solid rgba(255,152,0,0.25);
    background: rgba(255,152,0,0.08); color: #ffb74d; font-size: 13px; font-weight: 600;
    cursor: pointer; transition: all .2s; white-space: nowrap;
  }
  .export-btn:hover { background: rgba(255,152,0,0.18); }
  .result-info { color: #546e7a; font-size: 12px; margin-bottom: 8px; max-width: 960px; width: 100%; }
  .grid {
    display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 16px; max-width: 960px; width: 100%;
  }
  .card {
    display: block; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08);
    border-radius: 12px; padding: 20px; text-decoration: none; color: inherit;
    transition: all .2s;
  }
  .card:hover {
    background: rgba(76,175,80,0.08); border-color: rgba(76,175,80,0.3);
    transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,0.3);
  }
  .card-title { font-size: 16px; font-weight: 600; color: #a5d6a7; margin-bottom: 6px; }
  .card-stats { font-size: 12px; color: #78909c; margin-bottom: 4px; }
  .card-meta { font-size: 12px; color: #546e7a; }
  .empty { color: #546e7a; font-size: 14px; text-align: center; padding: 40px; grid-column: 1/-1; display: none; }
  .empty.show { display: block; }
  .pagination {
    display: flex; justify-content: center; align-items: center; gap: 6px;
    margin-top: 24px; max-width: 960px; width: 100%; flex-wrap: wrap;
  }
  .page-btn {
    padding: 8px 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.12);
    background: rgba(255,255,255,0.05); color: #b0bec5; font-size: 13px;
    cursor: pointer; transition: all .2s; min-width: 36px; text-align: center;
  }
  .page-btn:hover { background: rgba(255,255,255,0.08); color: #e0e0e0; }
  .page-btn.active { background: rgba(76,175,80,0.15); color: #81c784; border-color: rgba(76,175,80,0.3); }
  .page-btn:disabled { opacity: 0.3; cursor: not-allowed; }
  .page-info { color: #546e7a; font-size: 13px; padding: 0 2px; letter-spacing: 2px; }
  .footer { margin-top: 48px; text-align: center; color: #455a64; font-size: 12px; }
  @media (max-width: 640px) {
    body { padding: 20px 12px; }
    .header h1 { font-size: 22px; }
    .grid { grid-template-columns: 1fr; gap: 12px; }
    .card { padding: 16px; }
    .card-title { font-size: 15px; }
    .card-stats { font-size: 11px; }
    .card-meta { font-size: 11px; }
    .search-wrapper { min-width: 100%; }
    .search-box { font-size: 16px; }
    .pagination { gap: 4px; }
    .page-btn { padding: 8px; min-width: 34px; font-size: 13px; }
  }
</style>
</head>
<body>
  <div class="header">
    <h1>🏔️ 登山路线目录</h1>
    <p>所有登山路线 · 点此查看详情</p>
  </div>
  <div class="toolbar">
    <div class="search-wrapper">
      <input type="text" class="search-box" id="searchBox" placeholder="🔍 搜索（山名、关键词）...">
      <button class="clear-btn" id="clearBtn">✕</button>
    </div>
    <button class="sort-btn active" data-sort="date-desc">最新优先</button>
    <button class="sort-btn" data-sort="date-asc">最早优先</button>
    <button class="sort-btn" data-sort="name-asc">名称 A→Z</button>
    <button class="sort-btn" data-sort="dist-desc">距离↓</button>
    <button class="sort-btn" data-sort="dist-asc">距离↑</button>
    <button class="sort-btn" data-sort="elev-desc">爬升↓</button>
    <button class="sort-btn" data-sort="elev-asc">爬升↑</button>
    <button class="export-btn" id="exportBtn">📊 导出CSV</button>
  </div>
  <div class="result-info" id="resultInfo"></div>
  <div class="grid" id="grid">
    __CARDS_PLACEHOLDER__
    <div class="empty" id="emptyMsg">未找到匹配的登山路线</div>
  </div>
  <div class="pagination" id="pagination"></div>
  <div class="footer">mountain-climber · 登山路线目录</div>

<script>
const PAGE_SIZE = 12;
let currentSort = 'date-desc';
let currentPage = 1;
let filteredCards = [];
const grid = document.getElementById('grid');
const searchBox = document.getElementById('searchBox');
const clearBtn = document.getElementById('clearBtn');
const pagination = document.getElementById('pagination');
const resultInfo = document.getElementById('resultInfo');
const emptyMsg = document.getElementById('emptyMsg');
const allCards = Array.from(grid.querySelectorAll('.card'));

function getCards() {
  const q = searchBox.value.trim().toLowerCase();
  let cards = allCards.filter(c => true);
  if (q) {
    cards = cards.filter(c => {
      const title = (c.getAttribute('data-title') || '').toLowerCase();
      const slug = (c.getAttribute('data-slug') || '').toLowerCase();
      return title.includes(q) || slug.includes(q);
    });
  }
  cards.sort((a, b) => {
    switch (currentSort) {
      case 'date-desc': return (b.dataset.date || '').localeCompare(a.dataset.date || '');
      case 'date-asc': return (a.dataset.date || '').localeCompare(b.dataset.date || '');
      case 'name-asc': return (a.dataset.title || '').localeCompare(b.dataset.title || '');
      case 'dist-desc': return parseFloat(b.dataset.dist || 0) - parseFloat(a.dataset.dist || 0);
      case 'dist-asc': return parseFloat(a.dataset.dist || 0) - parseFloat(b.dataset.dist || 0);
      case 'elev-desc': return parseInt(b.dataset.elev || 0) - parseInt(a.dataset.elev || 0);
      case 'elev-asc': return parseInt(a.dataset.elev || 0) - parseInt(b.dataset.elev || 0);
      default: return 0;
    }
  });
  return cards;
}

function render() {
  filteredCards = getCards();
  const total = filteredCards.length;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  if (currentPage > totalPages) currentPage = totalPages;
  const start = (currentPage - 1) * PAGE_SIZE;
  const end = start + PAGE_SIZE;
  allCards.forEach(c => { c.style.display = 'none'; });
  filteredCards.slice(start, end).forEach(c => { c.style.display = ''; grid.appendChild(c); });
  filteredCards.slice(0, start).forEach(c => grid.appendChild(c));
  filteredCards.slice(end).forEach(c => grid.appendChild(c));
  grid.appendChild(emptyMsg);
  emptyMsg.classList.toggle('show', total === 0);
  if (total > 0) {
    resultInfo.textContent = `显示 ${start + 1}-${Math.min(end, total)} / 共 ${total} 条路线`;
  } else {
    resultInfo.textContent = '';
  }
  renderPagination(totalPages);
}

function renderPagination(totalPages) {
  if (totalPages <= 1) { pagination.innerHTML = ''; return; }
  let html = '';
  const p = currentPage;
  html += `<button class="page-btn" data-page="prev" ${p === 1 ? 'disabled' : ''}>‹</button>`;
  for (let i = 1; i <= totalPages; i++) {
    const isEdge = i === 1 || i === totalPages;
    const near = Math.abs(i - p) <= 1;
    if (isEdge || near) {
      html += `<button class="page-btn${i === p ? ' active' : ''}" data-page="${i}">${i}</button>`;
    } else if (i < p && !(i+1 < p)) {
      html += `<span class="page-info">…</span>`;
    }
  }
  html += `<button class="page-btn" data-page="next" ${p === totalPages ? 'disabled' : ''}>›</button>`;
  pagination.innerHTML = html;
}

function exportCSV() {
  const rows = [['山名', '距离(km)', '爬升(m)', '日期', '链接']];
  allCards.forEach(c => {
    rows.push([
      c.dataset.title || '',
      c.dataset.dist || '',
      c.dataset.elev || '',
      c.dataset.date || '',
      'https://line.allez.cc.cd/' + (c.dataset.slug || '') + '/'
    ]);
  });
  const csv = rows.map(r => r.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(',')).join('\n');
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = '登山路线汇总.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(a.href);
}

let searchTimer;
function toggleClearBtn() {
  clearBtn.classList.toggle('visible', searchBox.value.length > 0);
}

searchBox.addEventListener('input', () => {
  toggleClearBtn();
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { currentPage = 1; render(); }, 200);
});

clearBtn.addEventListener('click', () => {
  searchBox.value = '';
  toggleClearBtn();
  currentPage = 1;
  render();
  searchBox.focus();
});

document.querySelectorAll('.sort-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentSort = btn.dataset.sort;
    currentPage = 1;
    render();
  });
});

document.getElementById('exportBtn').addEventListener('click', exportCSV);

pagination.addEventListener('click', e => {
  const btn = e.target.closest('.page-btn');
  if (!btn || btn.disabled) return;
  if (btn.dataset.page === 'prev') currentPage--;
  else if (btn.dataset.page === 'next') currentPage++;
  else currentPage = parseInt(btn.dataset.page);
  render();
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

render();
</script>
</body>
</html>
TOCEOF
  echo "  ✅ 已生成默认 toc/index.html"
fi

# 替换卡片
python3 << PYEOF
import re
with open('$DEPLOY_DIR/toc/index.html', 'r') as f:
    content = f.read()
# Replace placeholder or grid content
cards = """$CARDS_HTML"""
# If __CARDS_PLACEHOLDER__ exists, replace it
if '__CARDS_PLACEHOLDER__' in content:
    content = content.replace('__CARDS_PLACEHOLDER__', cards.strip() + '\n    ')
else:
    # Otherwise replace grid content between grid div and empty div
    content = re.sub(
        r'(<div class="grid" id="grid">)\s*(.*?)\s*(<div class="empty")',
        lambda m: m.group(1) + '\n    ' + cards.strip() + '\n    ' + m.group(3),
        content,
        flags=re.DOTALL
    )
with open('$DEPLOY_DIR/toc/index.html', 'w') as f:
    f.write(content)
print('✅ cards updated')
PYEOF

# 确保根页面存在
if [ -f "$BASE_DIR/index.html" ]; then
  cp "$BASE_DIR/index.html" "$DEPLOY_DIR/index.html"
  echo "  ✅ 根页面 index.html 已同步到部署目录"
else
  echo "  ⚠️  根 index.html 不存在，跳过"
fi

# 部署
echo ""
echo "📤 部署到 Vercel..."
cd "$DEPLOY_DIR"
vercel deploy . --prod --token "$TOKEN" --scope "$SCOPE" --project "$PROJECT" -y 2>&1

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🎉 方案2 部署完成！"
echo "  📋 https://$PROD_URL/toc/"
echo "  📊 共 ${#TRIP_LIST[@]} 条登山路线"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
