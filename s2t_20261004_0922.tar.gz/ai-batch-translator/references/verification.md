# 验证记录

## 当前版本结果

- 安装根目录：`~/.config/omnirush/skills/ai-batch-translator/`
- 适配来源：`/tmp/ai_batch_translator.py`
- 来源 SHA-256：见 `source-hashes.json`，来源文件未修改、未执行；原脚本的外部 provider 配置没有复制。
- Python 3.12.10 / macOS x86_64；生产运行模块只使用标准库。
- **82 项测试通过，0 失败，0 跳过**：格式/结构 51 项，批处理/交接/恢复 31 项。机械翻译 fixture 只用于测试协议与结构，不能证明模型翻译质量。
- Black 26.5.1：`python3 -B -m black --config /dev/null scripts/*.py tests/*.py` 后未改动。
- 所有 6 个 Python 文件用 `compile()` 及 `ast.parse(feature_version=(3,10))` 通过；清理后交付目录无 `.pyc`。
- `python3 -B scripts/build...` 不适用；实际入口检查为 `python3 -B scripts/ai_batch_translator.py --language-help`。
- `python3 -S -B ... --dry-run` 通过，证明 dry-run 不要求第三方 site-packages。

测试日志：`/tmp/ai-batch-translator-all-tests.log`。

## 真实当前会话模型合成验证

仅使用技能自带的 `assets/demo.txt/.md/.csv/.json/.srt` 合成文档复制品，未读取其他用户目录。输入复制到临时验证根：

`/private/var/folders/7v/zvv6rv994qq1fhy6yn2sdkb40000gn/T/ai-batch-translator-verification-5saknqn5/`

实际 CLI 生成 10 个任务（5 个文件 × 英语/法语），先返回退出 10 和 4 个有界请求。本会话读取完整请求，实际生成当前会话模型响应 JSON，再续跑分批处理其余请求，最终：

- 10 个任务完成，0 失败，0 待处理。
- 英语、法语各 5 个输出；TXT 的前导空格、SRT 的时间轴/CRLF/数字台词、CSV 的行列与引号、JSON 的键/数值/布尔值、Markdown 的 URL/占位符/代码块均保留。
- 输出保持输入子目录 `manuals/`，没有压平同名文件。
- 输入副本 SHA-256 与开始前记录一致；源文件未写入。
- 默认完成输出已被再次 resume 核验，未重写成品。
- 请求/响应使用 `provider=omnirush-current-session`，不调用 HTTP provider、不读取密钥、不启动第二个模型会话。

证据：

- 开始状态：`start.json`
- 最终报告：`/private/var/folders/7v/zvv6rv994qq1fhy6yn2sdkb40000gn/T/ai-batch-translator-verification-5saknqn5/output/20261004_002108_83656d4b65/report.json`
- 最终 stdout：`/tmp/ai-batch-translator-final.json`

响应 JSON 是本机文件交接，不能独立证明回答者身份，也不能证明语言学语义完全正确。重要翻译仍需人工复核。

## 测试覆盖

结构模块覆盖：

- TXT/Markdown/SRT/VTT/CSV/JSON 的抽取与回填。
- 简繁/拉丁/混合脚本文本均可进入候选；空、纯标点、emoji、数字-only 不虚构 AI 翻译。
- BOM/CRLF/LF/CR/Unicode 换行、首尾空白、长文分段、跨片段保护符号。
- Markdown 标题、列表、代码围栏、链接目标、frontmatter 的有限保护。
- SRT/VTT 索引、时间轴、cue settings、NOTE/STYLE/REGION 和包含数字/箭头的台词。
- CSV 分隔符、引号、嵌入换行、矩形行列、首行标题策略、公式前缀拒绝。
- JSON 只翻译 string value，不翻译 key、数字、布尔/null，拒绝重复键、非有限数、非法字符串、深度/复杂度超限。
- 缺失/多余/布尔 ID、空回答、结构 token/数字/URL/占位符/换行攻击、超大输出拒绝。

工作流覆盖：

- 多目标语言、别名、重复去重、子目录同名布局、可移植名称冲突、隐藏项/链接/输出子树/非递归。
- dry-run 无写入/无模型请求；预检失败不创建批次。
- 当前会话退出 10、完整响应校验、坏响应修复、窗口限制、分段长文、接受答案复用。
- 输入/快照/manifest/已完成输出/response symlink/FIFO/锁篡改 fail-closed。
- 原子输出意图、回执失败恢复、报告失败保留真实成品、完成 resume 不重复调用/写入。
- `--stdin`/兼容 `--text`、UTF-16/BOM、GBK、不可表示目标编码、`python -S` dry-run。

## 静态扫描与人工复核

本次实际运行 SkillSpector 2.12.0 `--no-llm`：

- **72/100 HIGH，`DO_NOT_INSTALL`，退出码 1，7 项问题**。
- 报告：`/tmp/ai-batch-translator-scan-final.json`。

逐项判断：

1. **OH1 / HIGH** 与两个 **AST4 / MEDIUM** 定位到 `tests/test_workflow.py` 的 `subprocess.run`。仅用于测试真实入口和 `python -S` dry-run，使用固定解释器/固定脚本的参数数组、`shell=False` 默认、无用户 shell 命令；生产脚本没有 subprocess。扫描器把测试执行视为生产输出风险，不能把这解释成扫描通过。
2. **RA2 ×2 / MEDIUM** 把文档中的批次 `manifest`/`.work`/续跑状态和技能安装路径跨行匹配为“跨会话持久化”。这些是用户明确调用翻译任务所需的私有、可删除批次恢复状态，不是 cron、launch agent、profile hook、后台启动或自修改；文档已明确没有自动后台任务。
3. **AE4 / MEDIUM** 命中测试中为格式保护构造的多脚本/Unicode 合成数据，无密钥、混淆载荷或动态执行。
4. **TT2 / MEDIUM** 命中测试故意篡改临时文件以证明恢复会拒绝变化，不是生产数据流。

`LP1` 和 `E2` 初始误报来自测试中复制完整环境以及生产变量名 `requests`；已删除测试的 `env={**os.environ,...}`，并将生产局部变量改为 `task_pending`。重扫后的剩余问题如上。**不能把 72 分/DO_NOT_INSTALL 改写成 clean scan；安装前应依照人工复核并只处理用户明确选择的文件。**

人工结论：**CAUTION**。功能与权限边界符合“用户选定文件 → 当前会话翻译 → 本地输出”；生产代码没有网络客户端、凭据读取、shell、动态执行或外部 provider。静态扫描对测试文件和持久化状态仍给出高/中信号，故本技能不取得“安全扫描通过”认证。

## 未声称的事项

未实测 Linux、Windows、Apple Silicon、Python 3.10 解释器、其他编码发行包或大规模吞吐。未生成具体性能倍数。没有处理 PDF/DOCX/EPUB/OCR，没有语言质量基准或自动目标语言证明。当前会话模型的网络/服务边界属于 OmniRush 会话本身，不把它虚称为本地离线翻译。
