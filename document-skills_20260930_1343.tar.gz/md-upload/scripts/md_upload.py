#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
md_upload.py — Markdown 批量上传工具

将指定目录中的 .md 文件批量上传到任意 md2mindmap 兼容 API。
API 地址和 Token 均支持动态输入。

用法:
  python md_upload.py <folder> --url <api_url> --token <token>
  python md_upload.py <folder>                    # 交互式询问 url + token
  python md_upload.py <folder> --token eyJ...     # 交互式询问 url
"""

import argparse
import os
import sys
import time
from pathlib import Path

import requests


# 已知的 API 端点（方便快速选择）
KNOWN_APIS = {
    "1": ("md2.allez", "https://md2.allez.de5.net/api/upload"),
    "2": ("md3.allez", "https://md3.allez.cc.cd/api/upload"),
    "3": ("goallez",   "https://md.goallez.dpdns.org/api/upload"),
}


def validate_token(token):
    if not token:
        return False, "未提供 Token"
    if "eyJ" not in token:
        return False, "Token 格式不正确（应包含 eyJ）"
    return True, None


def find_md_files(folder):
    folder = Path(folder)
    files = set()
    for p in ["*.md", "*.markdown", "*.MD"]:
        files.update(str(f) for f in folder.glob(p))
        files.update(str(f) for f in folder.rglob(p))
    return sorted(files)


def upload_file(file_path, api_url, token):
    try:
        name = Path(file_path).name
        with open(file_path, 'rb') as f:
            payload = {'files': (name, f, 'text/markdown')}
            headers = {'Authorization': f'Bearer {token}'}
            resp = requests.post(api_url, files=payload, headers=headers, timeout=30)
        if resp.status_code == 200:
            return True, None
        err = f"HTTP {resp.status_code}"
        if resp.text:
            err += f": {resp.text[:100]}"
        return False, err
    except requests.Timeout:
        return False, "超时"
    except Exception as e:
        return False, str(e)[:100]


def interactive_setup(api_url, token):
    """交互式获取 API URL 和 Token"""

    # ── API URL ──
    if not api_url:
        print("\n  📡 选择目标 API:")
        for k, (name, url) in KNOWN_APIS.items():
            print(f"    {k}. {name} — {url}")
        print(f"    0. 自定义输入")
        print()

        try:
            choice = input("  请选择 [1/2/3/0]: ").strip()
        except (EOFError, KeyboardInterrupt):
            return None, None

        if choice in KNOWN_APIS:
            api_url = KNOWN_APIS[choice][1]
            print(f"  ✅ 已选择: {api_url}")
        elif choice == "0" or choice not in KNOWN_APIS:
            try:
                api_url = input("  输入 API URL (例: https://example.com/api/upload): ").strip()
            except (EOFError, KeyboardInterrupt):
                return None, None

    if not api_url:
        print("❌ 未提供 API URL", file=sys.stderr)
        return None, None

    # 确保以 /api/upload 结尾（如果用户只输入了域名）
    if not api_url.endswith("/api/upload"):
        if api_url.endswith("/"):
            api_url += "api/upload"
        else:
            api_url += "/api/upload"
        print(f"  ℹ️  自动补全: {api_url}")

    # ── Token ──
    if not token:
        print(f"\n  🔑 输入 Token (eyJ... 格式):")
        try:
            token = input("  Token: ").strip()
        except (EOFError, KeyboardInterrupt):
            return None, None

    ok, err = validate_token(token)
    if not ok:
        print(f"  ❌ {err}", file=sys.stderr)
        return None, None
    print(f"  ✅ Token 验证通过: {token[:20]}...")

    return api_url, token


def cmd_upload(args):
    folder = Path(args.folder).resolve()
    if not folder.is_dir():
        print(f"❌ 目录不存在: {folder}", file=sys.stderr)
        return 1

    # 交互式获取 URL 和 Token
    api_url, token = interactive_setup(args.url, args.token)
    if not api_url or not token:
        return 1

    # 查找文件
    md_files = find_md_files(folder)
    total = len(md_files)
    if total == 0:
        print(f"\n⚠️  未找到 .md 文件: {folder}")
        return 1

    print(f"\n📤 开始上传 {total} 个文件")
    print(f"   目标: {api_url}")
    print(f"   目录: {folder}")
    print()

    t0 = time.time()
    ok, fail, errors = 0, 0, {}

    for i, fp in enumerate(md_files, 1):
        name = Path(fp).name
        success, err = upload_file(fp, api_url, token)
        if success:
            print(f"  [{i}/{total}] ✅ {name}")
            ok += 1
        else:
            print(f"  [{i}/{total}] ❌ {name} — {err}")
            fail += 1
            errors[name] = err

    elapsed = time.time() - t0
    rate = (ok / total * 100) if total else 0
    speed = ok / elapsed if elapsed > 0 else 0

    print(f"\n{'═'*55}")
    print(f"  📊 上传完成")
    print(f"{'═'*55}")
    print(f"  ✅ 成功: {ok}/{total}")
    print(f"  ❌ 失败: {fail}")
    print(f"  📈 成功率: {rate:.1f}%")
    print(f"  ⏱️  耗时: {elapsed:.1f}s")
    print(f"  ⚡ 速度: {speed:.1f} 文件/秒")

    if errors:
        print(f"\n  失败详情:")
        for n, e in sorted(errors.items()):
            print(f"    • {n}: {e}")

    return 0 if fail == 0 else 1


def main():
    parser = argparse.ArgumentParser(
        prog="md_upload",
        description="📤 Markdown 批量上传工具 — 将 .md 文件上传到 md2mindmap 兼容 API",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 交互式选择 API + 输入 Token
  python md_upload.py ~/output

  # 指定 API URL + Token
  python md_upload.py ~/output --url https://md.goallez.dpdns.org/api/upload --token eyJ...

  # 只指定 Token（交互选 API）
  python md_upload.py ~/output --token eyJ...

  # 快捷: 直接输域名也行，自动补全 /api/upload
  python md_upload.py ~/output --url https://md3.allez.cc.cd --token eyJ...

已知 API:
  1. md2.allez  — https://md2.allez.de5.net/api/upload
  2. md3.allez  — https://md3.allez.cc.cd/api/upload
  3. goallez    — https://md.goallez.dpdns.org/api/upload
        """,
    )
    parser.add_argument("folder", nargs="?", default=".", help="包含 .md 文件的目录 (默认当前目录)")
    parser.add_argument("--url", "-u", help="API 上传地址 (不传则交互选择)")
    parser.add_argument("--token", "-t", help="JWT Bearer Token (不传则交互输入)")

    args = parser.parse_args()
    return cmd_upload(args)


if __name__ == "__main__":
    sys.exit(main() or 0)
